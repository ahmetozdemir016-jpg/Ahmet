/* Ortak sorgu ilerleme çubuğu - Diğer Sorgulamalar ekranları */
(function(){
  if (window.__ORTAK_SORGU_PROGRESS_LOADED__) return;
  window.__ORTAK_SORGU_PROGRESS_LOADED__ = true;

  var st = window.__ORTAK_SORGU_PROGRESS_STATE__ = window.__ORTAK_SORGU_PROGRESS_STATE__ || {
    active:false,
    sent:0,
    received:0,
    running:0,
    phase:'',
    startedAt:0,
    finishTimer:null
  };

  function esc(s){
    return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function ensureBox(){
    var box = document.getElementById('ortakSorguProgress');
    if (!box) {
      box = document.createElement('div');
      box.id = 'ortakSorguProgress';
      box.style.cssText = 'display:none;margin:10px 0;padding:10px;border:1px solid #b7d6c4;background:#f2fff7;color:#1f3b2a;font-weight:bold;line-height:1.45;font-size:14px;';
      var anchor = document.getElementById('yazdir') || document.getElementById('tablo5') || document.getElementById('tablo1') || document.body.firstChild;
      if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(box, anchor);
      else document.body.appendChild(box);
    }
    return box;
  }

  function render(){
    try{
      var box = ensureBox();
      var waiting = Math.max(0, (st.sent || 0) - (st.received || 0));
      var pct = (st.sent > 0) ? Math.min(100, Math.round((st.received / st.sent) * 100)) : 0;
      var running = Math.max(0, st.running || 0);
      var elapsed = st.startedAt ? Math.round(((new Date()).getTime() - st.startedAt) / 1000) : 0;
      var phase = st.phase || 'Sorgu yapılıyor...';
      var bar = '<div style="margin-top:6px;width:420px;max-width:95%;height:12px;border:1px solid #99c7aa;background:#fff;">' +
                '<div style="height:12px;width:'+pct+'%;background:#4caf50;"></div></div>';
      box.style.display = 'block';
      box.innerHTML = '<div style="font-size:15px;">' + esc(phase) + '</div>' +
        '<div style="font-size:13px;margin-top:3px;">Atılan sorgu: <b>' + (st.sent || 0) + '</b> | Gelen cevap: <b>' + (st.received || 0) + '</b> | Bekleyen: <b>' + waiting + '</b> | Çalışan: <b>' + running + '</b> | Süre: <b>' + elapsed + ' sn</b></div>' + bar;
    }catch(e){}
  }

  function start(phase){
    if (st.finishTimer) { clearTimeout(st.finishTimer); st.finishTimer = null; }
    st.active = true;
    st.sent = 0;
    st.received = 0;
    st.running = 0;
    st.phase = phase || 'Sorgu yapılıyor...';
    st.startedAt = (new Date()).getTime();
    render();
  }

  function setPhase(phase){
    st.phase = phase || st.phase || 'Sorgu yapılıyor...';
    if (!st.active) st.active = true;
    if (!st.startedAt) st.startedAt = (new Date()).getTime();
    render();
  }

  function finish(phase){
    if (st.finishTimer) { clearTimeout(st.finishTimer); st.finishTimer = null; }
    st.active = false;
    st.running = 0;
    st.phase = phase || 'Sorgu tamamlandı.';
    render();
  }

  function scheduleFinish(){
    if (!st.active) return;
    if ((st.running || 0) > 0) return;
    if (st.finishTimer) clearTimeout(st.finishTimer);
    st.finishTimer = setTimeout(function(){
      if (st.active && (st.running || 0) === 0 && (st.sent || 0) === (st.received || 0) && (st.sent || 0) > 0) {
        finish('Sorgular tamamlandı.');
      }
    }, 900);
  }

  function sent(url){
    try{
      if (!st.active) start('Sorgu yapılıyor...');
      if (st.finishTimer) { clearTimeout(st.finishTimer); st.finishTimer = null; }
      st.sent = (st.sent || 0) + 1;
      st.running = (st.running || 0) + 1;
      render();
    }catch(e){}
  }

  function received(url){
    try{
      if (!st.active) st.active = true;
      st.received = (st.received || 0) + 1;
      if (st.received > st.sent) st.sent = st.received;
      st.running = Math.max(0, (st.running || 0) - 1);
      render();
      scheduleFinish();
    }catch(e){}
  }

  function shouldCountAjax(args){
    var url = '';
    try{
      if (typeof args[0] === 'string') url = args[0];
      else if (args[0] && args[0].url) url = args[0].url;
    }catch(e){}
    return !!(url && (url.indexOf('/dispatch') !== -1 || url.indexOf('gibintranet_server') !== -1));
  }

  function patchAjax(){
    try{
      if (!window.jQuery || !window.jQuery.ajax) { setTimeout(patchAjax, 100); return; }
      if (window.__ORTAK_SORGU_AJAX_PATCHED__) return;
      var origAjax = window.jQuery.ajax;
      window.jQuery.ajax = function(){
        var countIt = shouldCountAjax(arguments);
        if (countIt) sent();
        var jq = origAjax.apply(this, arguments);
        if (countIt) {
          if (jq && typeof jq.always === 'function') jq.always(function(){ received(); });
          else setTimeout(function(){ received(); }, 0);
        }
        return jq;
      };
      if (window.$) window.$.ajax = window.jQuery.ajax;
      window.__ORTAK_SORGU_AJAX_PATCHED__ = true;
    }catch(e){ setTimeout(patchAjax, 200); }
  }

  function labelFromButton(btn){
    var txt = '';
    try { txt = (btn.value || btn.textContent || '').replace(/\s+/g,' ').trim(); } catch(e) {}
    if (!txt) txt = 'Sorgu';
    return txt + ' yapılıyor...';
  }

  document.addEventListener('click', function(ev){
    var t = ev.target;
    if (!t) return;
    var tag = (t.tagName || '').toLowerCase();
    var val = String(t.value || t.textContent || '').toLowerCase();
    var onclick = String(t.getAttribute && t.getAttribute('onclick') || '').toLowerCase();
    if ((tag === 'input' || tag === 'button' || t.className) &&
        (val.indexOf('sorgula') !== -1 || val.indexOf('getir') !== -1 || onclick.indexOf('sorgula') !== -1 || onclick.indexOf('getir') !== -1 || onclick.indexOf('dokum') !== -1)) {
      start(labelFromButton(t));
    }
  }, true);

  window.SorguProgress = {
    start:start,
    setPhase:setPhase,
    finish:finish,
    sent:sent,
    received:received,
    render:render
  };

  patchAjax();
})();
