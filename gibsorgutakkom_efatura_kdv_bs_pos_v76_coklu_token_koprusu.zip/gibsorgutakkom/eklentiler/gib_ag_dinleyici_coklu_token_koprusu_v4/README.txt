# GİB Ağ Dinleyici Chrome Eklentisi v1

## Kurulum
1. Zip dosyasını çıkar.
2. Chrome adres çubuğuna `chrome://extensions` yaz.
3. Sağ üstten **Geliştirici modu**nu aç.
4. **Paketlenmemiş öğe yükle** seç.
5. Çıkardığın klasördeki `gib_ag_dinleyici_chrome_eklenti_v1` klasörünü seç.

## Kullanım
1. Dinlemek istediğin GİB / E-Beyan / TAKKOM sayfasını aç.
2. Eklenti ikonuna tıkla.
3. Önce **Sayfaya Enjekte Et** de.
4. Sorguyu / beyanname açmayı / PDF açmayı yap.
5. Popup açıkken loglar görünür.
6. Daha derin izleme gerekiyorsa **Debugger Başlat** de. Chrome'un debugger uyarısı normaldir.
7. İşin bitince **Debugger Durdur** de.
8. **JSON İndir** ile logu kaydedebilirsin.

## Ne yakalar?
- fetch istekleri
- XMLHttpRequest / dispatch istekleri
- window.open ile açılan beyanname/PDF linkleri
- link tıklamaları
- form gönderimleri
- Chrome debugger modu açıkken response body önizlemesi

## Notlar
- Token ve JSESSIONID popup'ta varsayılan olarak maskelenir.
- `file://` sayfalarında çalıştırmak için Chrome Extensions ekranından eklenti detaylarında "Dosya URL'lerine erişime izin ver" seçeneğini açman gerekebilir.
- Debugger modu sadece aktif sekmeye bağlanır.
- Bu eklenti dışarı veri göndermez; loglar tarayıcında tutulur.


## v1.1 Servis Çözücü ekleri
- CMD ve JP parametresini otomatik ayıklar.
- Popup içinde "Servis Özeti" filtresi eklenmiştir.
- Sayfa konsoluna `🛰️ GİB SERVİS: ...` başlığıyla CMD/JP JSON yazdırır.
- Debugger açıkken yanıt gövdesi de alınmaya çalışılır.

## Beyanname için bakılacak ana şeyler
- `cmd`
- `jp`
- `BEYANNAMELISTESIVDO`
- `BEYANNAMEGORUNTULEVDO`
- `vdintraDispatch`
- `beyannameOid`, `tahakkukOid`, `vergiKodu`, `donem`


## v1.3 Çoklu token yakalama
- GİB intranet / g tokeni yakalanır.
- KEYS / GP tokeni yakalanır.
- EVDB Rapor / evdorapor tokeni yakalanır.
- İzaha Davet / SMİYB izah-server tokeni yakalanır.
- Tokenler dışarı gönderilmez; chrome.storage.local içinde yerelde tutulur.
- Dosya URL'lerine erişim izni açık olmalıdır.
