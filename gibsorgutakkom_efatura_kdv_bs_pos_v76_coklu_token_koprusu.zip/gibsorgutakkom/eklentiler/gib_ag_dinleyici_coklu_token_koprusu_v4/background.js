
const STATE = {
  logs: [],
  maxLogs: 1500,
  debuggerTabs: {},
  requestMap: {}
};

const TOKEN_KEY = 'takkom_token_cache_v1';
const TOKEN_TTL = 8 * 60 * 60 * 1000;
function tokenUsable(v){
  let t=String(v||'').trim();
  if(!t || t.includes('***') || t.includes('...')) return '';
  // token bazen welcome.jsp?token=... veya encode edilmiş tam URL olarak gelebiliyor
  for(let i=0;i<4;i++){
    const m=/[?&]token=([^&\s#]+)/i.exec(t) || /token%3D([^%&#\s]+)/i.exec(t);
    if(m && m[1]) t=m[1];
    try{ const d=decodeURIComponent(t); if(d===t) break; t=d; }catch(_e){ break; }
  }
  t=String(t||'').replace(/["'<>]/g,'').trim();
  if(!t || t.length<20) return '';
  return t;
}
function normalizeTokenModule(m){
  m=String(m||'').trim().toLowerCase();
  if(!m) return '';
  if(m==='g' || m.includes('gibintranet')) return 'gibintranet';
  if(m==='gp' || m==='keys' || m.includes('key')) return 'keys';
  if(m==='evdo' || m==='evdb' || m.includes('evdo') || m.includes('evdb')) return 'evdbrapor';
  if(m==='izah' || m.includes('izah')) return 'izah';
  if(m.includes('smiyb')) return 'izah';
  if(m.includes('istakip')) return 'istakip';
  if(m==='e' || m.includes('edenetis') || m.includes('eys')) return 'eys';
  if(m.includes('ebyn') || m.includes('vdintra')) return 'ebeyan';
  return m;
}
function tokenModuleFromUrl(url, body){
  const u=String(url||'').toLowerCase(); const b=String(body||'').toLowerCase();
  const both=u+' '+b;
  const moduleParam = /(?:^|[?&\s])module=([^&\s]+)/i.exec(both);
  if(moduleParam) return normalizeTokenModule(moduleParam[1]);
  if(u.includes('/izah-server/') || b.includes('module=izah') || both.includes('izahrakor') || both.includes('izahrapor')) return 'izah';
  if(u.includes('evdorapor_server') || b.includes('module=evdorapor') || b.includes('cmd=evdorapor')) return 'evdbrapor';
  if(u.includes('/gp/') || u.includes('/gp/index.jsp') || u.includes('gp_server')) return 'keys';
  if(u.includes('gibintranet_server') || u.includes('/gibintranet/') || u.includes('/gibintranet/welcome.jsp')) return 'gibintranet';
  if(u.includes('istakip_server') || u.includes('/istakip/')) return 'istakip';
  if(u.includes('vdintra') || u.includes('/ebyn/')) return 'ebeyan';
  return '';
}
function tokenAliases(mod){
  mod=normalizeTokenModule(mod);
  const a=[];
  const push=x=>{x=String(x||'').trim(); if(x && !a.includes(x)) a.push(x);};
  push(mod);
  if(mod==='gibintranet'){ push('g'); push('gibIntranet'); push('gib_intranet'); }
  if(mod==='keys'){ push('gp'); push('key'); push('keysToken'); }
  if(mod==='evdbrapor'){ push('evdo'); push('evdb'); push('evdbRapor'); push('evdorapor'); push('evdoRapor'); }
  if(mod==='izah'){ push('izahaDavet'); push('smiyb'); push('izahServer'); }
  if(mod==='eys'){ push('e'); push('edenetis'); }
  return a;
}
function deepFindTokens(obj, out=[], path=''){
  try{
    if(!obj || typeof obj!=='object') return out;
    if(Array.isArray(obj)){
      obj.forEach((v,i)=>deepFindTokens(v,out,path+'['+i+']'));
      return out;
    }
    const token = tokenUsable(obj.token || obj.value || obj.t || obj.accessToken || obj.sessionToken);
    const src = String(obj.source || obj.module || obj.moduleName || obj.modulAdi || obj.name || path || 'object');
    if(token) out.push({token, module:normalizeTokenModule(src), source:src});
    Object.keys(obj).forEach(k=>{
      const v=obj[k];
      if(/token/i.test(k)){
        const t=tokenUsable(v);
        if(t) out.push({token:t, module:normalizeTokenModule(k), source:path?path+'.'+k:k});
      }
      if(v && typeof v==='object') deepFindTokens(v,out,path?path+'.'+k:k);
    });
  }catch(_e){}
  return out;
}
function bodyFromRequestBody(rb){
  try{
    if(!rb) return '';
    if(rb.formData){
      const p=[];
      Object.keys(rb.formData).forEach(k=>{
        const vals=rb.formData[k]||[];
        vals.forEach(v=>p.push(encodeURIComponent(k)+'='+encodeURIComponent(v)));
      });
      return p.join('&');
    }
    if(rb.raw && rb.raw.length){
      return rb.raw.map(r=>{
        try{return r.bytes ? new TextDecoder('utf-8').decode(r.bytes) : '';}catch(_e){return '';}
      }).join('&');
    }
  }catch(_e){}
  return '';
}
async function updateTokenCache(entry){
  try{
    const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
    const cache = old[TOKEN_KEY] || {tokens:{}, updatedAt:0, logs:[]};
    cache.tokens = cache.tokens || {};
    cache.tokensByModule = cache.tokensByModule || {};
    const si = entry.serviceInfo || {};
    const params = si.params || {};
    const url = String(entry.url || '');
    const body = String(entry.body || '');
    const response = String(entry.response || '');
    const baseMod = tokenModuleFromUrl(url, body);
    const candidates = [];
    const add = (tok, mod, source) => {
      tok = tokenUsable(tok);
      if(!tok) return;
      mod = normalizeTokenModule(mod || baseMod || 'last');
      candidates.push({token:tok, module:mod, source:source || ((entry.kind||'')+' '+url)});
    };

    // 1) Sayfa hookundan gelen CSSession token listeleri
    if(Array.isArray(entry.tokens)){
      entry.tokens.forEach(x => add(x && x.token, x && (x.module || x.moduleName || x.source), x && x.source));
    }
    if(entry.payload && Array.isArray(entry.payload.tokens)){
      entry.payload.tokens.forEach(x => add(x && x.token, x && (x.module || x.moduleName || x.source), x && x.source));
    }

    // 2) URL/body parametrelerindeki tokenler
    add(params.token, params.module || params.moduleName || baseMod, 'serviceInfo.params');
    let m = /[?&]token=([^&\s#]+)/i.exec(url);
    if(m) add(decodeURIComponent(m[1]), baseMod, 'url.token');
    m = /(?:^|&)token=([^&\s#]+)/i.exec(body) || /[?&]token=([^&\s#]+)/i.exec(body);
    if(m) add(decodeURIComponent(m[1]), params.module || baseMod, 'body.token');

    // 3) assos-login ve JSON cevaplarda dönen tokenler
    if(response){
      try{
        const j=JSON.parse(response);
        add(j && (j.token || (j.data&&j.data.token) || (j.result&&j.result.token)), baseMod, 'json.response.token');
        deepFindTokens(j, [], 'response').forEach(x => add(x.token, x.module || baseMod, x.source));
      }catch(_e){
        const m2 = /"token"\s*:\s*"([^"]+)"/i.exec(response) || /token=([^&\s#]+)/i.exec(response);
        if(m2) add(m2[1], baseMod, 'response.regex.token');
      }
    }

    // 4) Log nesnesinde farklı isimlerle gelirse
    deepFindTokens(entry, [], 'entry').forEach(x => add(x.token, x.module || baseMod, x.source));

    const now = Date.now();
    for(const c of candidates){
      const aliases = tokenAliases(c.module || 'last');
      if(!aliases.length) aliases.push('last');
      aliases.forEach(a=>{
        cache.tokens[a] = {token:c.token, time:now, source:c.source || ((entry.kind||'')+' '+url)};
        cache.tokensByModule[a] = c.token;
      });
      if(c.module==='izah') cache.izah = cache.izahToken = {token:c.token, time:now, source:c.source || url};
      if(c.module==='gibintranet') cache.gibintranet = cache.gibIntranetToken = {token:c.token, time:now, source:c.source || url};
      if(c.module==='keys') cache.keys = cache.keysToken = cache.gp = cache.gpToken = {token:c.token, time:now, source:c.source || url};
      if(c.module==='evdbrapor') cache.evdbrapor = cache.evdbRapor = cache.evdbRaporToken = {token:c.token, time:now, source:c.source || url};
      cache.last = {token:c.token, module:c.module, time:now, source:c.source || url};
      cache.updatedAt = now;
    }

    // Son loglardan yerel sayfalar da okuyabilsin.
    if(/izah-server|gibintranet_server|gp\/index|\/gp\/|evdorapor_server|assos-login|module=izah|module=evdorapor|vdintra|ebyn|keys\.ggm\.bim/i.test(url+' '+body)){
      cache.logs = cache.logs || [];
      cache.logs.push({url:url, body:body.slice(0,4000), response:response.slice(0,4000), serviceInfo:entry.serviceInfo||{}, tokens:(entry.tokens||[]).slice(0,20), kind:entry.kind||'', createdAt:entry.createdAt||new Date().toISOString()});
      if(cache.logs.length>120) cache.logs.splice(0, cache.logs.length-120);
    }
    await chrome.storage.local.set({[TOKEN_KEY]:cache});
  }catch(_e){}
}
async function getTokenCacheForBridge(){
  try{
    const out = await chrome.storage.local.get([TOKEN_KEY,'logs']);
    const cache = out[TOKEN_KEY] || {tokens:{}, updatedAt:0};
    if(!cache.logs && out.logs) cache.logs = out.logs.slice(-100);
    return cache;
  }catch(_e){ return {tokens:{}}; }
}

function classify(url){
  url = String(url || '');
  if (/dispatch/i.test(url)) return 'dispatch';
  if (/BEYANNAME|vdintra|pdf|goruntule|tahakkuk/i.test(url)) return 'beyan';
  if (/127\.0\.0\.1|localhost|2023/i.test(url)) return 'local-imza';
  return 'other';
}
function cut(s,n){ s=String(s || ''); return s.length > n ? s.slice(0,n) + ' ...[kesildi]' : s; }

function parseQueryString(qs){
  const obj = {};
  String(qs||'').replace(/^\?/,'').split('&').forEach(p=>{
    if(!p) return;
    const i = p.indexOf('=');
    let k = i>=0 ? p.slice(0,i) : p;
    let v = i>=0 ? p.slice(i+1) : '';
    try{k = decodeURIComponent(k.replace(/\+/g,' '));}catch(e){}
    try{v = decodeURIComponent(v.replace(/\+/g,' '));}catch(e){}
    if(k) obj[k]=v;
  });
  return obj;
}
function parseServiceInfo(url, body){
  const info = {cmd:'', jpRaw:'', jp:null, params:{}, serviceHint:''};
  try{
    const u = String(url||'');
    const qi = u.indexOf('?');
    const qu = parseQueryString(qi>=0 ? u.slice(qi+1) : '');
    const bo = parseQueryString(String(body||''));
    const all = {...qu, ...bo};
    info.params = all;
    info.cmd = all.cmd || all.CMD || '';
    info.jpRaw = all.jp || all.JP || all.json || all.JSON || '';
    if(info.jpRaw){
      try{ info.jp = JSON.parse(info.jpRaw); }catch(e){ info.jp = null; }
    }
    if(info.cmd){
      const m = String(info.cmd).match(/^([^_]+)_/);
      info.serviceHint = m ? m[1] : '';
    }
  }catch(e){}
  return info;
}

function addLog(entry){
  entry = entry || {};
  entry.globalId = Date.now() + '-' + Math.random().toString(36).slice(2,8);
  entry.createdAt = new Date().toISOString();
  entry.classType = entry.classType || classify(entry.url);
  entry.serviceInfo = entry.serviceInfo || parseServiceInfo(entry.url, entry.body);
  STATE.logs.push(entry);
  if(STATE.logs.length > STATE.maxLogs) STATE.logs.splice(0, STATE.logs.length - STATE.maxLogs);
  chrome.storage.local.set({logs: STATE.logs.slice(-500)}).catch(()=>{});
  try { updateTokenCache(entry); } catch(_) {}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg) return;

  if(msg.type === 'PAGE_LOG'){
    const e = msg.entry || {};
    e.tabId = sender && sender.tab ? sender.tab.id : undefined;
    e.tabUrl = msg.url || (sender && sender.tab ? sender.tab.url : '');
    e.tabTitle = msg.title || (sender && sender.tab ? sender.tab.title : '');
    addLog(e);
    sendResponse({ok:true});
    return true;
  }

  if(msg.type === 'GET_LOGS'){
    sendResponse({ok:true, logs: STATE.logs});
    return true;
  }

  if(msg.type === 'GET_TOKENS'){
    getTokenCacheForBridge().then(cache => sendResponse({ok:true, cache})).catch(err => sendResponse({ok:false, error:String(err&&err.message||err)}));
    return true;
  }

  if(msg.type === 'CLEAR_LOGS'){
    STATE.logs = [];
    STATE.requestMap = {};
    chrome.storage.local.set({logs: []}).catch(()=>{});
    sendResponse({ok:true});
    return true;
  }

  if(msg.type === 'INJECT_CURRENT'){
    chrome.tabs.query({active:true, currentWindow:true}, async tabs => {
      try{
        const tab = tabs && tabs[0];
        if(!tab || !tab.id) return sendResponse({ok:false, error:'Aktif sekme bulunamadı.'});
        await chrome.scripting.executeScript({target:{tabId:tab.id, allFrames:true}, files:['content.js']});
        chrome.tabs.sendMessage(tab.id, {type:'INJECT_HOOK'}, () => {});
        sendResponse({ok:true});
      }catch(err){
        sendResponse({ok:false, error:String(err && err.message || err)});
      }
    });
    return true;
  }

  if(msg.type === 'START_DEBUGGER'){
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      const tab = tabs && tabs[0];
      if(!tab || !tab.id) return sendResponse({ok:false, error:'Aktif sekme bulunamadı.'});
      startDebugger(tab.id).then(() => sendResponse({ok:true, tabId:tab.id})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    });
    return true;
  }

  if(msg.type === 'STOP_DEBUGGER'){
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      const tab = tabs && tabs[0];
      if(!tab || !tab.id) return sendResponse({ok:false, error:'Aktif sekme bulunamadı.'});
      stopDebugger(tab.id).then(() => sendResponse({ok:true})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    });
    return true;
  }
});

async function startDebugger(tabId){
  if(STATE.debuggerTabs[tabId]) return;
  await chrome.debugger.attach({tabId}, '1.3');
  STATE.debuggerTabs[tabId] = true;
  await chrome.debugger.sendCommand({tabId}, 'Network.enable', {maxResourceBufferSize: 1024*1024*20, maxTotalBufferSize: 1024*1024*50});
  addLog({kind:'debugger', method:'START', url:'tab:'+tabId, body:'Chrome debugger Network.enable aktif', tabId});
}
async function stopDebugger(tabId){
  if(!STATE.debuggerTabs[tabId]) return;
  try{ await chrome.debugger.detach({tabId}); }catch(e){}
  delete STATE.debuggerTabs[tabId];
  addLog({kind:'debugger', method:'STOP', url:'tab:'+tabId, body:'Chrome debugger durduruldu', tabId});
}

chrome.debugger.onEvent.addListener(async (source, method, params) => {
  if(!source || !source.tabId || !STATE.debuggerTabs[source.tabId]) return;
  const tabId = source.tabId;

  if(method === 'Network.requestWillBeSent'){
    const req = params.request || {};
    STATE.requestMap[params.requestId] = {
      tabId,
      requestId: params.requestId,
      kind: 'debugger.request',
      method: req.method,
      url: req.url,
      body: req.postData || '',
      startTs: Date.now(),
      resourceType: params.type
    };
    addLog({
      kind:'debugger.request',
      method:req.method,
      url:req.url,
      body:cut(req.postData || '', 12000),
      tabId,
      requestId: params.requestId,
      resourceType: params.type
    });
  }

  if(method === 'Network.responseReceived'){
    const resp = params.response || {};
    const prev = STATE.requestMap[params.requestId] || {};
    prev.status = resp.status;
    prev.mimeType = resp.mimeType;
    prev.responseUrl = resp.url;
    prev.resourceType = params.type;
    STATE.requestMap[params.requestId] = prev;
  }

  if(method === 'Network.loadingFinished'){
    const prev = STATE.requestMap[params.requestId];
    if(!prev) return;
    let bodyText = '';
    let base64Encoded = false;
    try{
      const body = await chrome.debugger.sendCommand({tabId}, 'Network.getResponseBody', {requestId: params.requestId});
      bodyText = body.body || '';
      base64Encoded = !!body.base64Encoded;
      if(base64Encoded){
        bodyText = '[base64 response, ilk 12000 karakter]\n' + bodyText.slice(0,12000);
      }
    }catch(e){
      bodyText = '[response body alınamadı: '+String(e && e.message || e)+']';
    }
    addLog({
      kind:'debugger.response',
      method:prev.method,
      url:prev.responseUrl || prev.url,
      body:cut(prev.body || '', 12000),
      response:cut(bodyText, 20000),
      status:prev.status,
      mimeType:prev.mimeType,
      durationMs:Date.now()-(prev.startTs||Date.now()),
      tabId,
      requestId: params.requestId,
      resourceType: prev.resourceType,
      base64Encoded
    });
    delete STATE.requestMap[params.requestId];
  }

  if(method === 'Network.loadingFailed'){
    const prev = STATE.requestMap[params.requestId] || {};
    addLog({
      kind:'debugger.error',
      method:prev.method || '',
      url:prev.url || '',
      error:params.errorText || 'loadingFailed',
      tabId,
      requestId: params.requestId
    });
    delete STATE.requestMap[params.requestId];
  }
});

chrome.debugger.onDetach.addListener((source, reason) => {
  if(source && source.tabId) {
    delete STATE.debuggerTabs[source.tabId];
    addLog({kind:'debugger', method:'DETACH', url:'tab:'+source.tabId, body:'Debugger ayrıldı: '+reason, tabId:source.tabId});
  }
});

// Pasif webRequest metadata. Response body vermez, ama doğrudan PDF / navigation URL'lerini yakalar.
chrome.webRequest.onBeforeRequest.addListener(
  details => {
    if(details.tabId < 0) return;
    if(/dispatch|BEYANNAME|vdintra|pdf|goruntule|tahakkuk|assos-login|izah-server|evdorapor_server|gibintranet_server|keys\.ggm\.bim|\/gp\//i.test(details.url)){
      addLog({
        kind:'webRequest.before',
        method:details.method,
        url:details.url,
        body:bodyFromRequestBody(details.requestBody),
        tabId:details.tabId,
        requestId:details.requestId,
        resourceType:details.type
      });
    }
  },
  {urls:["http://*/*", "https://*/*"]},
  ["requestBody"]
);

chrome.webRequest.onCompleted.addListener(
  details => {
    if(details.tabId < 0) return;
    if(/dispatch|BEYANNAME|vdintra|pdf|goruntule|tahakkuk|assos-login|izah-server|evdorapor_server|gibintranet_server|keys\.ggm\.bim|\/gp\//i.test(details.url)){
      addLog({
        kind:'webRequest.completed',
        method:details.method,
        url:details.url,
        status:details.statusCode,
        tabId:details.tabId,
        requestId:details.requestId,
        resourceType:details.type
      });
    }
  },
  {urls:["http://*/*", "https://*/*"]}
);

chrome.runtime.onInstalled.addListener(async () => {
  const old = await chrome.storage.local.get('logs');
  STATE.logs = old.logs || [];
});
