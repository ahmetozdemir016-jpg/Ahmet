
const TOKEN_KEY = 'takkom_token_cache_v1';
const CAPTURE_TTL = 8 * 60 * 60 * 1000;

function cleanToken(v){
  let t = String(v || '').trim();
  if(!t || t.includes('***') || t.includes('...')) return '';
  for(let i=0;i<4;i++){
    const m = /[?&]token=([^&\s#]+)/i.exec(t) || /token%3D([^%&#\s]+)/i.exec(t);
    if(m && m[1]) t = m[1];
    try{ const d = decodeURIComponent(t); if(d === t) break; t = d; }catch(e){ break; }
  }
  t = String(t || '').replace(/["'<>]/g,'').trim();
  if(!t || t.length < 20) return '';
  return t;
}
function normModule(m){
  m = String(m || '').trim().toLowerCase();
  if(!m) return '';
  if(m === 'g' || m.includes('gibintranet') || m.includes('gib_intranet')) return 'gibintranet';
  if(m === 'gp' || m === 'key' || m === 'keys' || m.includes('keyss')) return 'keys';
  if(m === 'evdo' || m === 'evdb' || m.includes('evdo') || m.includes('evdb') || m.includes('evdorapor')) return 'evdbrapor';
  if(m === 'izah' || m.includes('izah') || m.includes('smiyb')) return 'izah';
  if(m.includes('istakip')) return 'istakip';
  if(m === 'e' || m.includes('eys') || m.includes('edenetis')) return 'eys';
  if(m.includes('ebyn') || m.includes('vdintra')) return 'ebeyan';
  return '';
}
function moduleFromContext(url, body, source){
  const u = String(url || '').toLowerCase();
  const b = String(body || '').toLowerCase();
  const s = String(source || '').toLowerCase();
  const all = u + ' ' + b + ' ' + s;
  let mm = /(?:^|[?&\s])module=([^&\s]+)/i.exec(all);
  if(mm) return normModule(mm[1]);
  mm = /cssession\.gettoken\(([^\)]+)\)/i.exec(all);
  if(mm) return normModule(mm[1]);
  if(u.includes('/izah-server/') || all.includes('module=izah') || all.includes('smiybraporservice') || all.includes('izahraporservice')) return 'izah';
  if(u.includes('evdorapor_server') || all.includes('module=evdorapor')) return 'evdbrapor';
  if(u.includes('gibintranet_server') || u.includes('/gibintranet/') || all.includes('module=gibintranet') || all.includes('cssession.gettoken(g)')) return 'gibintranet';
  if(u.includes('keys.ggm') || u.includes('/keyss/') || u.includes('/gp/') || all.includes('module=gp') || all.includes('cssession.gettoken(gp)')) return 'keys';
  if(u.includes('istakip')) return 'istakip';
  if(u.includes('vdintra') || u.includes('/ebyn/')) return 'ebeyan';
  return '';
}
function aliases(mod){
  const m = normModule(mod); const out = [];
  const add = x => { if(x && !out.includes(x)) out.push(x); };
  add(m);
  if(m === 'gibintranet'){ add('g'); add('gibIntranet'); add('gib_intranet'); }
  if(m === 'keys'){ add('gp'); add('key'); add('keysToken'); add('gpToken'); }
  if(m === 'evdbrapor'){ add('evdo'); add('evdb'); add('evdbRapor'); add('evdbRaporToken'); add('evdorapor'); add('evdoRapor'); }
  if(m === 'izah'){ add('izahaDavet'); add('smiyb'); add('izahServer'); add('izahToken'); }
  if(m === 'istakip') add('isTakip');
  if(m === 'eys'){ add('e'); add('edenetis'); }
  return out;
}
async function storeTokens(list, meta={}){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  const cache = old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{}};
  cache.tokens = cache.tokens || {};
  cache.tokensByModule = cache.tokensByModule || {};
  cache.captureStatus = cache.captureStatus || {};
  const now = Date.now();
  let changed = 0;
  for(const item of (Array.isArray(list) ? list : [])){
    const token = cleanToken(item && item.token);
    const mod = normModule((item && item.module) || moduleFromContext(item && item.url, item && item.body, item && item.source));
    if(!token || !mod) continue; // modül belli değilse bilinçli olarak kaydetme; yanlış token karışmasın.
    for(const a of aliases(mod)){
      cache.tokens[a] = {token, time: now, source: (item.source || meta.source || ''), module: mod};
      cache.tokensByModule[a] = token;
    }
    cache[mod] = {token, time: now, source: item.source || meta.source || '', module: mod};
    changed++;
  }
  if(changed){
    cache.updatedAt = now;
    cache.captureStatus.lastSource = meta.source || '';
    cache.captureStatus.lastUrl = meta.url || '';
    cache.captureStatus.modules = Object.keys(cache.tokensByModule || {}).filter(k => ['gibintranet','g','keys','gp','evdbrapor','evdo','evdb','izah','smiyb'].includes(k));
    await chrome.storage.local.set({[TOKEN_KEY]: cache});
  }
  return cache;
}
async function getCache(){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  return old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0};
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg) return;
  if(msg.type === 'TOKEN_ONLY_CAPTURE'){
    const payload = msg.payload || {};
    const tokens = Array.isArray(payload.tokens) ? payload.tokens : [];
    storeTokens(tokens, {source: payload.reason || payload.source || '', url: payload.pageUrl || ''})
      .then(cache => sendResponse({ok:true, cache}))
      .catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'GET_TOKENS'){
    getCache().then(cache => sendResponse({ok:true, cache})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'CLEAR_TOKENS'){
    chrome.storage.local.set({[TOKEN_KEY]: {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{clearedAt:Date.now()}}})
      .then(() => sendResponse({ok:true})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  getCache().then(cache => chrome.storage.local.set({[TOKEN_KEY]: cache})).catch(()=>{});
});
