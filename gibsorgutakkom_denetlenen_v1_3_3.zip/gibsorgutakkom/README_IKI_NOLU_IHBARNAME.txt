2 NOLU İHBARNAME LİSTESİ (Rapor Alma – EVDB Raporları içinde)

Rapor seçimi: "2 Nolu İhbarname Listesi (davalı ihbarnameler · dava dosya no / tebliğ / tahakkuk)".
Kaynak: EVDB Rapor › 2 Nolu İhbarname Listesi
  GET evdorapor_server/pdf  serviceName=evdoIhtilafliReportsServices_ikiNoluIhbarnameListesi, reportName=RP_EVDO_2NOLU_IHBARNAME_LISTESI
  BASLANGICTARIHI / BITISTARIHI (YYYYAAGG, tek sorgu), BASLANGICVKN / BITISVKN, BASLANGICTCKN / BITISTCKN,
  FISDURUMU (0 Geçici, 1 Onaylanmış, 2 İptal Edilmiş, 3 Hepsi), TEBLIGDURUMU (0 Tebliğ Edilmemiş, 1 Tebliğ Edilmiş, 2 Hepsi),
  THKDURUMU (0 Tahakkuk Kesilmemiş, 1 Tahakkuk Kesilmiş, 2 Hepsi), KATPEKBILGI 0.
  Not: "Hepsi" kodları (3 / 2 / 2) PDF başlığından doğrulandı; Tebliğ Durumu 0/1 adları ekran listesinden tahmin.
PDF'teki her kayıt (Sıra, İhbarname Fiş No, Dava Dosya No, Durumu, Mükellef Tipi, VKN, TCKN, Soyad/Ad (Unvan), Vergi Kodu,
Vergilendirme Dönemi, Tebliğ Tarihi, Tahakkuk Fiş No, Referans No) bir satır olur. Tarh Defteri ile aynı tablo altyapısı:
Sütunlar menüsü (ayrı saklanır), sütun başlığına tıklayarak sıralama, sütun süzgeçleri (boş/dolu/içeren/≥/≤/arasında…),
Sorumlu (personel aralıkları), kişi bazlı özet (İhbarname, Mükellef, Tahakkuk fişi yok), Excel (liste + kişi özeti + parametreler),
yatay yazdırma.

v1.1 – DÜZELTME FİŞİ KONTROLÜ ve TEBLİĞ / TAHAKKUK EKSİKLERİ
- Liste alındıktan sonra her 2 nolu ihbarname için "Onaylı 2 Nolu İhbarname Düzeltme Fiş Sorgulama" raporu (Durum: 2 Nolu İhbarname No)
  istenir: serviceName=evdoIhtilafliReportsServices_iptalEdilmisIkiNoluIhbarnameSorgulama,
  reportName=RP_EVDO_2NOLU_IPTALEDILEN_IHB_FISI_SORGULAMA, IPTALDURUMU:'-1', FISNO:<ihbarname fiş no>, TYPE:'MASTER'.
  PDF'te ihbarname numarasından farklı bir fiş numarası (düzeltme fiş no) bulunursa "Düzeltme var" (durumu iptal ise sayılmaz);
  "kayıt bulunamadı" vb. ise "Düzeltme yok"; ikisi de değilse "Belirsiz" + PDF metninin başı (doğrulamak için).
- Yeni sütunlar: "Düzeltme Sorgu Sonucu", "Kontrol" (Düzeltme var – liste dışı / Tebliğ edilmemiş / Tahakkuk verilmemiş / tamam).
- Süzgeç "Kontrol": Tahakkuk verilmemiş (düzeltmesiz) · Tebliğ edilmemiş (düzeltmesiz) · Tebliğ veya tahakkuk eksik (düzeltmesiz) ·
  Düzeltme fişi var · Düzeltme belirsiz. Tebliğ edilmemiş = Tebliğ Tarihi boş veya Durumu "Tebliğ Edilmiş" değil;
  Tahakkuk verilmemiş = Tahakkuk Fiş No boş. Düzeltmesi olanlar bu listelere girmez.
- Kişi özetinde "Tahakkuk fişi yok (düzeltmesiz)".

v1.5: Düzeltme fişi belgesi gerçek düzenine göre okunuyor ("ONAYLI 2 NOLU İHBARNAME DÜZELTME FİŞ SORGULAMA"):
Düzeltme Durumu, Geçici Düzeltme No, Onaylanmış Düzeltme No, Fiş No, Düzeltme Nedeni, Düzeltme Zamanı, Dava/Karar bilgileri.
Onaylanmış Düzeltme No doluysa "Düzeltme var" (durum iptal ise sayılmaz) → liste dışı; yalnız Geçici Düzeltme No varsa
"Geçici düzeltme (onaylanmamış)" olarak işaretlenir, liste dışı bırakılmaz; ikisi de boşsa "Düzeltme yok".
Yeni sütunlar: "Düzeltme No", "Düzeltme Nedeni". Tarh Defteri/2 Nolu PDF'leri 10.251.63.99 vermezse keys.ggm.bim'den istenir
(PDF Okuyucu uzantısı v1.2).

v1.6: EVDB 2 nolu listeyi yıllık verdiği için tarih aralığı yıllara bölünür (ör. 15/03/2024–08/10/2026 → 2024, 2025, 2026 ayrı
sorgulanır), sonuçlar birleştirilir, aynı fiş no tekillenir; 'Sorgu Yılı' sütunu eklendi.
