ONAY YAPILACAK İŞLER (diger/onay-isleri.html)

Ana ekrandaki "Onay Yapılacak İşler" düğmesi açar. Üstteki "İş" listesinden onaylanacak iş seçilir; yeni işler ISLER tablosuna eklenir.

1) e-Defter Analizi – Ceza İşlemleri (müdür onayı)
   GİBİNTRANET › e-Defter Analizi-Yönetici Ekranı › İş Detayı: Onayda Bekleyen İşler
   Liste: gibintranet_server/dispatch edefterService_edefterKullaniciUstundekiMukListesiGetir
     {vdkodu, basVknTckn, bitVknTckn, basDonem, bitDonem, cezaNedeni:'-1', isDurumu:'-1', mudurMu:'1', isDetayi:'0', islemDurumu:'-1'}
     Tüm liste tek cevapta gelir (KEYS ekranda 10'arlı sayfalara böler).
   Onay: edefterService_edefterMudurOnay {oid, durum} → {durum:'4', sonuc:'basarili', onayTarihi}. Satır satır, bekleme süresiyle.
   Durum: 2 = ihbarname düzenlendi, 3 = ihbarname düzenlenmedi (açıklamalı), 4 = onaylandı.
   Süzgeçler: durum, kullanıcı, dayanak kodu, dosya türü, onay (onaylanmamış / bu oturumda onaylanan / hatalı), arama.
   Kullanıcı bazlı özet (tıklayınca süzer), sütun başlığına tıklayarak sıralama, Excel.
