(() => {
  'use strict';

  if (window.__istakipEysLauncherLoaded) return;
  window.__istakipEysLauncherLoaded = true;

  function addBtn() {
    try {
      const existing = document.getElementById('istakip-eys-launcher');
      if (existing) existing.style.display = 'none';
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addBtn, { once: true });
  } else {
    addBtn();
  }
})();
