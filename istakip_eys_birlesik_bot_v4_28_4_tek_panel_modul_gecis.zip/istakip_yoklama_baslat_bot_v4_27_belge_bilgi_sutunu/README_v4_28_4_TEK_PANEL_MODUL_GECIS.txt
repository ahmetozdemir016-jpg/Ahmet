v4.28.4 Tek Panel Modül Geçiş

Yapılanlar:
- Ayrı EYS açıcı kutu kaldırıldı/gizlendi.
- Ana panel üstüne EYS butonu eklendi.
- EYS panel üstüne ANA butonu eklendi.
- Butona basınca ayrı pencere yerine aynı sayfadaki diğer modüle geçer.
- Geçişte diğer panel gizlenir, seçilen panel gösterilir.

Kullanım:
- Ana modüldeyken üstte EYS butonuna bas.
- EYS modülündeyken üstte ANA butonuna bas.
- Panel tek alan mantığında kullanılabilir.
