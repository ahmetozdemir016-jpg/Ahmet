
(function(){
  if(window.__TAKKOM_TOKEN_ONLY_PAGE_HOOK__) return;
  window.__TAKKOM_TOKEN_ONLY_PAGE_HOOK__ = true;
  var stopped = false;
  var found = {};
  var timers = [];

  function normModule(m){
    m=String(m||'').trim().toLowerCase();
    if(!m) return '';
    if(m==='g' || m.indexOf('gibintranet')>=0 || m.indexOf('gib_intranet')>=0) return 'gibintranet';
    if(m==='gp' || m==='keys' || m==='key' || m.indexOf('keyss')>=0) return 'keys';
    if(m==='evdo' || m==='evdb' || m.indexOf('evdo')>=0 || m.indexOf('evdb')>=0 || m.indexOf('evdorapor')>=0) return 'evdbrapor';
    if(m==='izah' || m.indexOf('izah')>=0 || m.indexOf('smiyb')>=0) return 'izah';
    if(m.indexOf('istakip')>=0) return 'istakip';
    if(m==='e' || m.indexOf('eys')>=0 || m.indexOf('edenetis')>=0) return 'eys';
    return '';
  }
  function cleanToken(v){
    var t=String(v||'').trim();
    if(!t || t.length<20 || /\*\*\*|\.\.\./.test(t)) return '';
    for(var i=0;i<4;i++){
      var m=/[?&]token=([^&\s#]+)/i.exec(t) || /token%3D([^%&#\s]+)/i.exec(t);
      if(m && m[1]) t=m[1];
      try{ var d=decodeURIComponent(t); if(d===t) break; t=d; }catch(e){break;}
    }
    t=String(t||'').replace(/["'<>]/g,'').trim();
    return t.length>=20 ? t : '';
  }
  function moduleFromUrl(url, body, source){
    var u=String(url||'').toLowerCase();
    var b=String(body||'').toLowerCase();
    var s=String(source||'').toLowerCase();
    var all=u+' '+b+' '+s;
    var mm=/(?:^|[?&\s])module=([^&\s]+)/i.exec(all);
    if(mm) return normModule(mm[1]);
    mm=/cssession\.gettoken\(([^\)]+)\)/i.exec(all);
    if(mm) return normModule(mm[1]);
    if(u.indexOf('/izah-server/')>=0 || all.indexOf('module=izah')>=0 || all.indexOf('izahraporservice')>=0 || all.indexOf('smiybraporservice')>=0) return 'izah';
    if(u.indexOf('evdorapor_server')>=0 || all.indexOf('module=evdorapor')>=0) return 'evdbrapor';
    if(u.indexOf('gibintranet_server')>=0 || u.indexOf('/gibintranet/')>=0 || all.indexOf('module=gibintranet')>=0) return 'gibintranet';
    if(u.indexOf('keys.ggm')>=0 || u.indexOf('/keyss/')>=0 || u.indexOf('/gp/')>=0 || all.indexOf('module=gp')>=0) return 'keys';
    if(u.indexOf('istakip')>=0) return 'istakip';
    if(u.indexOf('eyoklama')>=0 || u.indexOf('edenetis')>=0 || all.indexOf('module=eys')>=0 || all.indexOf('module=e')>=0) return 'eys';
    if(u.indexOf('vdintra')>=0 || u.indexOf('/ebyn/')>=0) return 'ebeyan';
    return '';
  }

  function sendKeyCapture(item){
    try{
      if(!item || !item.url) return;
      var u=String(item.url||'');
      if(!/\/keyss\/(external_dispatch|flexpaper\/pdf)|\/gibintranet_server\/dispatch/i.test(u)) return;
      item.createdAtMs = Date.now();
      item.pageUrl = location.href;
      window.postMessage({source:'TAKKOM_KEYS_CAPTURE_PAGE', payload:{items:[item], reason:'keys-capture', pageUrl:location.href, at:Date.now()}}, '*');
    }catch(e){}
  }

  function post(tokens, reason){
    tokens=(tokens||[]).filter(function(x){ return x && cleanToken(x.token) && normModule(x.module); });
    if(!tokens.length) return;
    tokens.forEach(function(x){ found[normModule(x.module)] = 1; });
    window.postMessage({source:'TAKKOM_TOKEN_ONLY_PAGE', payload:{tokens:tokens, reason:reason||'', pageUrl:location.href, at:Date.now()}}, '*');
    maybeStop();
  }
  function maybeStop(){
    if(stopped) return;
    if(found.gibintranet && found.keys && found.evdbrapor && found.izah && found.istakip && found.eys){
      stop('hedef-tokenler-yakalandi');
    }
  }
  function stop(reason){
    if(stopped) return;
    stopped = true;
    while(timers.length){ try{ clearTimeout(timers.pop()); }catch(e){} }
    window.postMessage({source:'TAKKOM_TOKEN_ONLY_PAGE', payload:{tokens:[], reason:'stop:'+reason, pageUrl:location.href, at:Date.now()}}, '*');
  }
  function addTimer(fn, ms){ var t=setTimeout(fn,ms); timers.push(t); }
  function safeStr(v){
    try{
      if(v == null) return '';
      if(typeof v === 'string') return v;
      if(v instanceof URLSearchParams) return v.toString();
      if(v instanceof FormData){ var a=[]; v.forEach(function(val,key){ a.push(encodeURIComponent(key)+'='+encodeURIComponent(String(val))); }); return a.join('&'); }
      return JSON.stringify(v);
    }catch(e){ return String(v||''); }
  }
  function extractTokenFromText(txt, mod, source, url, body){
    var out=[]; txt=String(txt||'');
    function add(v,m,s){ v=cleanToken(v); m=normModule(m); if(v && m) out.push({token:v,module:m,source:s||source,url:url||'',body:body||''}); }
    var m;
    m=/(?:^|[?&\s])token=([^&\s#]+)/i.exec(txt); if(m) add(m[1],mod,source+':token-param');
    m=/"token"\s*:\s*"([^"]+)"/i.exec(txt); if(m) add(m[1],mod,source+':json-token');
    return out;
  }
  function collectCssession(reason){
    if(stopped) return;
    var out=[];
    function push(v, moduleName, source){
      var t=cleanToken(v), m=normModule(moduleName);
      if(t && m) out.push({token:t,module:m,source:source||('CSSession.getToken('+moduleName+')'),url:location.href});
    }
    try{
      var C=window.CSSession || {};
      if(C && typeof C.getToken === 'function'){
        [
          ['g','gibintranet'], ['gibintranet','gibintranet'],
          ['gp','keys'], ['keys','keys'],
          ['evdo','evdbrapor'], ['evdb','evdbrapor'], ['evdorapor','evdbrapor'], ['evdbrapor','evdbrapor'],
          ['izah','izah'], ['smiyb','izah'],
          ['istakip','istakip'], ['e','eys'], ['eys','eys']
        ].forEach(function(x){ try{ push(C.getToken(x[0]), x[1], 'CSSession.getToken('+x[0]+')'); }catch(e){} });
      }
    }catch(e){}
    try{
      var href=location.href||'';
      var mod=moduleFromUrl(href,'','url');
      out=out.concat(extractTokenFromText(href, mod, 'location.href', href, ''));
    }catch(e){}
    post(out, reason||'cssession');
  }

  // XHR/fetch sadece token içeren / token üreten URL'lerde çalışır. Cevap gövdesi kaydedilmez, sadece token ayıklanır.
  if(window.fetch && !window.fetch.__takkomTokenOnly){
    var origFetch=window.fetch;
    var wrapped=function(input, init){
      var url=(typeof input==='string')?input:((input&&input.url)||'');
      var body=init&&init.body ? safeStr(init.body) : '';
      var mod=moduleFromUrl(url, body, 'fetch');
      var capUrl=String(url||'');
      if(/\/keyss\/flexpaper\/pdf/i.test(capUrl)) sendKeyCapture({kind:'flexpaperPdf',method:'GET',url:capUrl,source:'fetch'});
      if(/\/keyss\/external_dispatch/i.test(capUrl)) sendKeyCapture({kind:'externalDispatch.before',method:'POST',url:capUrl,body:body,source:'fetch'});
      if(/\/gibintranet_server\/dispatch/i.test(capUrl)) sendKeyCapture({kind:'gibDispatch.before',method:'POST',url:capUrl,body:body,source:'fetch'});
      var should=!!mod || /token|assos-login/i.test(String(url)+' '+body);
      return origFetch.apply(this, arguments).then(function(resp){
        if(!stopped && should){
          var toks=extractTokenFromText(String(url)+'&'+body, mod, 'fetch.request', url, body);
          if(toks.length) post(toks,'fetch-request');
          try{
            var ct=resp.headers && resp.headers.get ? (resp.headers.get('content-type')||'') : '';
            if(/json|text/i.test(ct)){
              resp.clone().text().then(function(txt){
                var toks2=extractTokenFromText(txt, mod, 'fetch.response', url, body);
                if(toks2.length) post(toks2,'fetch-response');
              }).catch(function(){});
            }
          }catch(e){}
        }
        try{ if(/\/keyss\/external_dispatch|\/gibintranet_server\/dispatch/i.test(String(url||''))){ resp.clone().text().then(function(txt){ sendKeyCapture({kind:(/\/gibintranet_server\/dispatch/i.test(String(url||''))?'gibDispatch.completed':'externalDispatch.completed'),method:'POST',url:String(url||''),body:body,responseText:String(txt||'').slice(0,200000),source:'fetch'}); }).catch(function(){}); } }catch(e){}
        return resp;
      });
    };
    wrapped.__takkomTokenOnly=true; window.fetch=wrapped;
  }
  if(window.XMLHttpRequest && !window.XMLHttpRequest.prototype.__takkomTokenOnly){
    var XHR=window.XMLHttpRequest, origOpen=XHR.prototype.open, origSend=XHR.prototype.send;
    XHR.prototype.open=function(method,url){ this.__takkomTok={method:method,url:String(url||''),body:''}; return origOpen.apply(this,arguments); };
    XHR.prototype.send=function(body){
      var xhr=this, meta=xhr.__takkomTok||{}; meta.body=safeStr(body);
      var mod=moduleFromUrl(meta.url, meta.body, 'xhr');
      if(/\/keyss\/flexpaper\/pdf/i.test(String(meta.url||''))) sendKeyCapture({kind:'flexpaperPdf',method:meta.method||'GET',url:String(meta.url||''),source:'xhr'});
      if(/\/keyss\/external_dispatch/i.test(String(meta.url||''))) sendKeyCapture({kind:'externalDispatch.before',method:meta.method||'POST',url:String(meta.url||''),body:meta.body,source:'xhr'});
      if(/\/gibintranet_server\/dispatch/i.test(String(meta.url||''))) sendKeyCapture({kind:'gibDispatch.before',method:meta.method||'POST',url:String(meta.url||''),body:meta.body,source:'xhr'});
      var should=!!mod || /token|assos-login/i.test(String(meta.url)+' '+meta.body);
      if(should && !stopped){
        var toks=extractTokenFromText(String(meta.url)+'&'+meta.body, mod, 'xhr.request', meta.url, meta.body);
        if(toks.length) post(toks,'xhr-request');
        xhr.addEventListener('load', function(){
          if(stopped) return;
          try{
            var txt = xhr.responseType && xhr.responseType !== 'text' ? '' : xhr.responseText;
            var toks2=extractTokenFromText(txt, mod, 'xhr.response', meta.url, meta.body);
            if(toks2.length) post(toks2,'xhr-response');
          }catch(e){}
        });
      }
      try{ if(/\/keyss\/external_dispatch|\/gibintranet_server\/dispatch/i.test(String(meta.url||''))){ xhr.addEventListener('load', function(){ try{ var txt=xhr.responseType&&xhr.responseType!=='text'?'':xhr.responseText; sendKeyCapture({kind:(/\/gibintranet_server\/dispatch/i.test(String(meta.url||''))?'gibDispatch.completed':'externalDispatch.completed'),method:meta.method||'POST',url:String(meta.url||''),body:meta.body,responseText:String(txt||'').slice(0,200000),source:'xhr'}); }catch(e){} }); } }catch(e){}
      return origSend.apply(this,arguments);
    };
    XHR.prototype.__takkomTokenOnly=true;
  }

  collectCssession('start');
  addTimer(function(){ collectCssession('250ms'); },250);
  addTimer(function(){ collectCssession('1000ms'); },1000);
  addTimer(function(){ collectCssession('3000ms'); },3000);
  addTimer(function(){ collectCssession('7000ms'); },7000);
  addTimer(function(){ stop('sure-doldu'); },30000);
})();
