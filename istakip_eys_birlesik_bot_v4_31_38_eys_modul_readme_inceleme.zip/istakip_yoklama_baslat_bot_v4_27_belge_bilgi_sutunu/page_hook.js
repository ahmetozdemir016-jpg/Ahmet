(() => {
  if (window.__istakipPageHookV438) return;
  window.__istakipPageHookV438 = true;
  const currentScript = document.currentScript;
  const EVT = (currentScript && currentScript.dataset && currentScript.dataset.evt) || '__ISTAKIP_BOT_V4_DISCOVERY__';
  const send = (obj) => { try { window.postMessage(Object.assign({ type: EVT }, obj || {}), '*'); } catch (_) {} };
  const parseJson = (txt) => {
    try {
      if (!txt || typeof txt !== 'string') return null;
      txt = txt.trim();
      if (!txt || (txt[0] !== '{' && txt[0] !== '[')) return null;
      return JSON.parse(txt);
    } catch (_) { return null; }
  };
  let pendingModule = '';
  const guessModuleFromUrl = (url) => {
    const s = String(url || '').toLowerCase();
    if (s.includes('/istakip') || s.includes('istakip_server')) return 'istakip';
    if (s.includes('/evdo') || s.includes('evdo_server')) return 'evdo';
    if (s.includes('edenetis') || s.includes('eyoklama')) return 'e';
    if (s.includes('gibintranet')) return 'g';
    if (s.includes('/gp') || s.includes('gp_server')) return 'gp';
    return '';
  };
  const deepCollect = (obj, out = {}, depth = 0, seen = new WeakSet()) => {
    try {
      if (!obj || typeof obj !== 'object' || depth > 6) return out;
      if (seen.has(obj)) return out;
      seen.add(obj);
      const pick = (key, val) => {
        if (val === undefined || val === null || val === '') return;
        const k = String(key || '').toLowerCase();
        const v = typeof val === 'string' ? val.trim() : val;
        if (!v) return;
        if (!out.token && k === 'token') out.token = v;
        if (!out.orgoid && k === 'orgoid') out.orgoid = v;
        if (!out.userId && /^(userid|kullanicikodu|atamayapankullaniciuserid|islemyapanuserid)$/i.test(String(key))) out.userId = v;
        if (!out.moduleName && /^(moduladi|modulename|module|modul)$/i.test(String(key))) out.moduleName = v;
      };
      if (Array.isArray(obj)) {
        for (const item of obj) deepCollect(item, out, depth + 1, seen);
        return out;
      }
      for (const [k, v] of Object.entries(obj)) {
        pick(k, v);
        if (typeof v === 'string') {
          const j = parseJson(v);
          if (j) deepCollect(j, out, depth + 1, seen);
        } else if (v && typeof v === 'object') {
          deepCollect(v, out, depth + 1, seen);
        }
      }
    } catch (_) {}
    return out;
  };
  const learn = (obj, source, cmd = '') => {
    try {
      if (!obj || typeof obj !== 'object') return;
      const found = deepCollect(obj, {});
      let moduleName = (found.moduleName || '').trim();
      if (!moduleName) moduleName = pendingModule || '';
      send({ token: found.token || '', userId: found.userId || '', orgoid: found.orgoid || '', moduleName, cmd, source, payload: obj });
      if (/assos-login-response/i.test(source) && found.token) {
        send({ token: found.token, moduleName: moduleName || '', cmd, source: source + ':module-bound', payload: { moduleName: moduleName || '', token: found.token } });
      }
      if (obj.jp && typeof obj.jp === 'string') {
        const jp = parseJson(obj.jp);
        if (jp) learn(jp, source + ':jp', cmd);
      }
    } catch (_) {}
  };
  const inspectBody = (body, source, url = '') => {
    try {
      const urlModule = guessModuleFromUrl(url);
      if (!body) return;
      if (typeof body === 'string') {
        const usp = new URLSearchParams(body);
        if ([...usp.keys()].length) {
          const cmd = usp.get('cmd') || '';
          const token = usp.get('token') || '';
          const jpText = usp.get('jp') || '';
          let jp = null;
          if (jpText) jp = parseJson(jpText);
          let moduleName = (jp && (jp.moduleName || jp.modulAdi || jp.module || '')) || urlModule || '';
          if (!moduleName && /istakip/i.test(location.href)) moduleName = 'istakip';
          if (moduleName) pendingModule = moduleName;
          if (token || jp) send({ token, cmd, source: source + ':form-combined', moduleName, payload: jp || {} });
          if (token) send({ token, source: source + ':form-token', cmd, moduleName });
          if (jp) learn(jp, source + ':form-jp', cmd);
        } else {
          const j = parseJson(body);
          if (j) learn(j, source + ':json-body', '');
        }
      } else if (body instanceof URLSearchParams) {
        inspectBody(body.toString(), source, url);
      } else if (typeof FormData !== 'undefined' && body instanceof FormData) {
        const o = {};
        for (const [k, v] of body.entries()) o[k] = v;
        let moduleName = urlModule || '';
        if (typeof o.jp === 'string') {
          const jp = parseJson(o.jp);
          if (jp) {
            moduleName = moduleName || jp.moduleName || jp.modulAdi || jp.module || '';
            if (moduleName) pendingModule = moduleName;
            send({ token: o.token || '', cmd: o.cmd || '', source: source + ':formdata-combined', moduleName, payload: jp });
          }
        }
        learn(o, source + ':formdata', o.cmd || '');
      }
    } catch (_) {}
  };


  let lastEysPageCaller = null;

  const rememberEysPageCaller = (name, obj, serviceName) => {
    try {
      if (!obj || typeof obj.call !== 'function') return;
      lastEysPageCaller = { name: name || 'captured-page', obj, serviceName: serviceName || '', at: Date.now() };
      window.__istakipEysPageCaller = obj;
      send({
        source: 'page-call-capture',
        payload: {
          captured: true,
          caller: lastEysPageCaller.name,
          serviceName: lastEysPageCaller.serviceName,
          pageSession: getSessionDataFromPage ? getSessionDataFromPage() : {}
        }
      });
    } catch (_) {}
  };

  const patchLibEDenetisPageCaller = () => {
    try {
      const lib = window.libEDenetis;
      if (!lib || typeof lib.serviceCall !== 'function' || lib.__istakipServiceCallPatched) return !!lastEysPageCaller;
      const orig = lib.serviceCall;
      Object.defineProperty(lib, '__istakipServiceCallPatched', { value: true, configurable: true });
      lib.serviceCall = function(page, serviceName, parameters, returnFunc, errorFunc) {
        rememberEysPageCaller('libEDenetis.serviceCall.page', page, serviceName);
        return orig.apply(this, arguments);
      };
      send({ source: 'page-call-capture', payload: { patched: 'libEDenetis.serviceCall' } });
      return true;
    } catch (_) {
      return false;
    }
  };

  const startLibEDenetisPatchLoop = () => {
    try {
      patchLibEDenetisPageCaller();
      let n = 0;
      const timer = setInterval(() => {
        n += 1;
        const ok = patchLibEDenetisPageCaller();
        if (ok || n > 40) clearInterval(timer);
      }, 250);
    } catch (_) {}
  };


  const PAGE_CALL_REQ = '__ISTAKIP_EYS_PAGE_CALL__';
  const PAGE_CALL_RES = '__ISTAKIP_EYS_PAGE_CALL_RESULT__';

  const getSessionDataFromPage = () => {
    try {
      const C = window.CSSession || {};
      const get = (k) => {
        try { return C && typeof C.get === 'function' ? String(C.get(k) || '').trim() : ''; } catch (_) { return ''; }
      };
      return {
        rol: get('EOSROL'),
        user: get('EOSUSER'),
        giris: get('EOSUSERGIRIS') || get('EOSUSER'),
        birim: get('EOSBIRIMKODU'),
        il: get('EOSDEFILKODU') || String(get('EOSBIRIMKODU') || '').slice(0, 3),
        adi: get('EOSADI'),
        userx: get('EOSUSERGIRISX') || get('EOSUSER')
      };
    } catch (_) {
      return {};
    }
  };

  const findEysPageCaller = () => {
    try {
      patchLibEDenetisPageCaller();
      if (lastEysPageCaller && lastEysPageCaller.obj && typeof lastEysPageCaller.obj.call === 'function') {
        return { score: 999, name: lastEysPageCaller.name || 'captured-page', obj: lastEysPageCaller.obj };
      }
      if (window.__istakipEysPageCaller && typeof window.__istakipEysPageCaller.call === 'function') {
        return { score: 998, name: 'window.__istakipEysPageCaller', obj: window.__istakipEysPageCaller };
      }
    } catch (_) {}
    const scored = [];
    const scoreCandidate = (name, obj) => {
      try {
        if (!obj || typeof obj !== 'object' || typeof obj.call !== 'function') return;
        const text = [
          name,
          obj.$CS$ && obj.$CS$.definition && obj.$CS$.definition.BF_NAME,
          obj.definition && obj.definition.BF_NAME,
          obj.moduleName,
          obj.bfName,
          obj.name
        ].map(x => String(x || '')).join(' ');
        let score = 1;
        if (/edenetis|yoklama|yoklamatalebi|e\./i.test(text)) score += 20;
        if (/^page$/i.test(name)) score += 10;
        scored.push({ score, name, obj });
      } catch (_) {}
    };

    for (const k of ['page', 'Page', 'ePage', 'edenetisPage', 'yoklamaPage']) {
      try { scoreCandidate(k, window[k]); } catch (_) {}
    }

    try {
      for (const k of Object.keys(window)) {
        if (scored.length > 40) break;
        try { scoreCandidate(k, window[k]); } catch (_) {}
      }
    } catch (_) {}

    scored.sort((a, b) => b.score - a.score);
    return scored[0] || null;
  };

  const getEysDispatchUrlFromPage = () => {
    try {
      if (window.SideModuleManager && typeof SideModuleManager.getAppUrl === 'function') {
        return SideModuleManager.getAppUrl('e', '/edenetis/dispatch') || SideModuleManager.getAppUrl('e', 'edenetis/dispatch') || '';
      }
    } catch (_) {}
    return '';
  };

  const collectEysTokensFromPage = () => {
    const tokens = [];
    const push = (v, source) => {
      const s = String(v || '').trim();
      if (s && !tokens.some(x => x.token === s)) tokens.push({ token: s, source });
    };
    try {
      const C = window.CSSession || {};
      if (C && typeof C.getToken === 'function') {
        try { push(C.getToken(), 'CSSession.getToken()'); } catch (_) {}
        for (const arg of ['e', 'edenetis', 'g', 'gp']) {
          try { push(C.getToken(arg), 'CSSession.getToken(' + arg + ')'); } catch (_) {}
        }
        try {
          const mods = window.SideModuleManager && typeof SideModuleManager.getModules === 'function' ? SideModuleManager.getModules() : {};
          for (const [k, v] of Object.entries(mods || {})) {
            try { push(C.getToken(v), 'CSSession.getToken(module:' + k + ')'); } catch (_) {}
          }
        } catch (_) {}
      }
    } catch (_) {}
    return tokens;
  };

  startLibEDenetisPatchLoop();

  window.addEventListener('message', (event) => {
    try {
      if (event.source !== window) return;
      const data = event.data || {};
      if (data.type !== PAGE_CALL_REQ) return;

      const requestId = String(data.requestId || '');
      const cmd = String(data.cmd || '');
      const payload = (data.payload && typeof data.payload === 'object') ? Object.assign({}, data.payload) : {};
      if (!payload.sessionData) payload.sessionData = getSessionDataFromPage();

      const caller = findEysPageCaller();
      if (!caller || !caller.obj) {
        send({
          type: PAGE_CALL_RES,
          requestId,
          ok: false,
          error: 'EYS page.call nesnesi bulunamadı',
          pageSession: getSessionDataFromPage(),
          dispatchUrl: getEysDispatchUrlFromPage(),
          tokens: collectEysTokensFromPage()
        });
        return;
      }

      let ret;
      try {
        ret = caller.obj.call(cmd, payload, { progress: 'Lütfen bekleyiniz..' });
      } catch (err) {
        send({
          type: PAGE_CALL_RES,
          requestId,
          ok: false,
          error: err && err.message ? err.message : String(err),
          caller: caller.name,
          pageSession: getSessionDataFromPage(),
          dispatchUrl: getEysDispatchUrlFromPage(),
          tokens: collectEysTokensFromPage()
        });
        return;
      }

      const done = (resp) => send({
        type: PAGE_CALL_RES,
        requestId,
        ok: true,
        response: resp,
        caller: caller.name,
        pageSession: getSessionDataFromPage(),
        dispatchUrl: getEysDispatchUrlFromPage(),
        tokens: collectEysTokensFromPage()
      });
      const fail = (err) => send({
        type: PAGE_CALL_RES,
        requestId,
        ok: false,
        error: err && err.message ? err.message : String(err),
        response: err,
        caller: caller.name,
        pageSession: getSessionDataFromPage(),
        dispatchUrl: getEysDispatchUrlFromPage(),
        tokens: collectEysTokensFromPage()
      });

      if (ret && typeof ret.then === 'function') {
        try {
          const p = ret.then(done);
          if (p && typeof p.error === 'function') p.error(fail);
          else if (p && typeof p.catch === 'function') p.catch(fail);
          else if (ret && typeof ret.error === 'function') ret.error(fail);
        } catch (err) {
          fail(err);
        }
      } else {
        done(ret);
      }
    } catch (err) {
      try {
        send({
          type: PAGE_CALL_RES,
          requestId: event && event.data ? event.data.requestId : '',
          ok: false,
          error: err && err.message ? err.message : String(err)
        });
      } catch (_) {}
    }
  });

  setTimeout(() => {
    try {
      send({
        source: 'page-runtime-probe',
        payload: {
          pageSession: getSessionDataFromPage(),
          dispatchUrl: getEysDispatchUrlFromPage(),
          tokens: collectEysTokensFromPage(),
          hasPageCaller: !!findEysPageCaller(), lastCapturedPageCaller: lastEysPageCaller ? { name: lastEysPageCaller.name, serviceName: lastEysPageCaller.serviceName, at: lastEysPageCaller.at } : null
        }
      });
    } catch (_) {}
  }, 800);


  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = async function (...args) {
      try {
        const [input, init] = args;
        const url = typeof input === 'string' ? input : input?.url || '';
        const body = init?.body || (typeof input !== 'string' ? input?.body : undefined);
        if (/dispatch|assos-login|index\.jsp/i.test(url)) inspectBody(body, 'page-fetch:' + url, url);
      } catch (_) {}
      const res = await origFetch.apply(this, args);
      try {
        const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
        if (/dispatch|assos-login/i.test(url)) {
          const clone = res.clone();
          clone.text().then(txt => {
            const j = parseJson(txt);
            if (j) {
              const src = /assos-login/i.test(url) ? 'assos-login-response:' + url : 'page-fetch-response:' + url;
              learn(j.data || j, src, '');
            }
          }).catch(() => {});
        }
      } catch (_) {}
      return res;
    };
  }
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__it_v411_url = url;
    return origOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (/dispatch|assos-login|index\.jsp/i.test(this.__it_v411_url || '')) inspectBody(body, 'page-xhr:' + this.__it_v411_url, this.__it_v411_url);
      this.addEventListener('load', () => {
        try {
          if (/dispatch|assos-login/i.test(this.__it_v411_url || '')) {
            const j = parseJson(this.responseText);
            if (j) {
              const src = /assos-login/i.test(this.__it_v411_url || '') ? 'assos-login-response:' + this.__it_v411_url : 'page-xhr-response:' + this.__it_v411_url;
              learn(j.data || j, src, '');
            }
          }
        } catch (_) {}
      });
    } catch (_) {}
    return origSend.call(this, body);
  };
  send({ source: 'page-hook', payload: { ready: true } });
})();
