v4.31.38 EYS Modülü + README İncelemesi

README(8).md içinde görülen ana EYS akışı:
- side-user-lib-e.js içindeki libEDenetis.getSessionData(), CSSession değerlerinden sessionData üretir.
- libEDenetis.serviceCall(page, serviceName, parameters, returnFunc, errorFunc), parameters içine sessionData ekler.
- Sonra page.call(serviceName, parameters, {progress: "Lütfen bekleyiniz.."}) çağırır.
- showPdfSonuc(params,title), /edenetis/getSonuc yolunu popup pencereyle açar.

Bu incelemeye göre yapılan düzeltme:
- Önceki sürüm page.call nesnesini sadece window üzerindeki global objelerde arıyordu.
- README akışında page nesnesi çoğunlukla fonksiyon parametresi olarak geliyor; global olmayabilir.
- Bu sürüm libEDenetis.serviceCall fonksiyonunu sayfa context'inde sarmalar ve oraya gelen gerçek page nesnesini yakalar.
- Bilinen adres sorgusu srvcRemoteCall_getVdAdresleri için artık yakalanan gerçek page.call nesnesini önce kullanır.
- Direkt fetch hâlâ sadece yedek olarak kalır.

Kritik not:
- Panelde v4.31.38 yazmalı.
- EYS sayfası yenilendikten sonra, herhangi bir EYS servis çağrısı olduğunda sayfa gerçek page nesnesini yakalayacaktır.
- Bilinen adres hâlâ boş dönerse monitörde "Page-call durumu" satırı, page nesnesinin yakalanıp yakalanmadığını gösterecek.
