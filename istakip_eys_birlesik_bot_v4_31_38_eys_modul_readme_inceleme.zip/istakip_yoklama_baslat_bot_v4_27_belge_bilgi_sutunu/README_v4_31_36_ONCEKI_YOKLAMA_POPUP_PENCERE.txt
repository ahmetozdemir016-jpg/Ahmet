v4.31.36 Önceki Yoklama Popup Pencere

Düzeltme:
- Önceki yoklama/getSonuc artık iframe içinde açılmaya çalışmaz.
- Tam sekme yerine ekrandaki örneğe benzer küçük Chrome popup penceresi açılır.
- Popup adı getSonuc olarak verildi.
- Popup engellenirse panelde Sekmede Aç butonu yedek olarak kalır.
- Bilinen adres düzeltmeleri v4.31.35'ten korunmuştur.
