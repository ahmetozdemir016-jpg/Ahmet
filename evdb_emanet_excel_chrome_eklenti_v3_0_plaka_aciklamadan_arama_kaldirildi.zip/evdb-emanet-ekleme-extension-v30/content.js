(() => {
  if (window.__evdbEmanetBotV30Loaded) return;
  window.__evdbEmanetBotV30Loaded = true;

  const state = {
    running: false,
    paused: false,
    stopped: false,
    current: 0,
    total: 0,
    results: [],
    options: {},
    selectedFile: null,
    preparedRows: [],
    runId: null,
    completedSet: new Set(),
    skippedNoIdentity: [],
    invalidIdentity: [],
    duplicateExisting: [],
    skippedNonGiris: [],
    identityLookupFailed: []
  };

  const PANEL_ID = 'evdb-emanet-bot-panel-v30';
  const $ = id => document.getElementById(id);

  function norm(s) {
    return String(s || '').toLocaleLowerCase('tr-TR')
      .replace(/ı/g, 'i').replace(/İ/g, 'i')
      .replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c')
      .replace(/[\.：:]/g, '').replace(/\s+/g, ' ').trim();
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
  }

  function makeDraggable(panel, handle) {
    let down = false, sx = 0, sy = 0, sl = 0, st = 0;
    handle.addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;
      down = true; sx = e.clientX; sy = e.clientY;
      const r = panel.getBoundingClientRect(); sl = r.left; st = r.top;
      document.body.style.userSelect = 'none';
    });
    document.addEventListener('mousemove', e => {
      if (!down) return;
      panel.style.left = Math.max(0, sl + e.clientX - sx) + 'px';
      panel.style.top = Math.max(0, st + e.clientY - sy) + 'px';
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => { down = false; document.body.style.userSelect = ''; });
  }

  function ensurePanel(show = true) {
    let panel = $(PANEL_ID);
    if (panel) {
      if (show) panel.style.display = 'block';
      return panel;
    }
    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.style.cssText = `
      position:fixed; right:18px; top:90px; width:430px; z-index:2147483647;
      background:#f6f7fb; color:#1f2933; border:1px solid #4b5563; border-radius:10px;
      font:13px Arial, sans-serif; box-shadow:0 8px 28px rgba(0,0,0,.32); overflow:hidden;
    `;
    panel.innerHTML = `
      <div id="evdb-bot-drag" style="background:#263449;color:#fff;padding:9px 10px;cursor:move;display:flex;align-items:center;justify-content:space-between;gap:8px">
        <div style="font-weight:bold">EVDB Emanet Botu v3.0</div>
        <div>
          <button id="evdb-bot-min" title="Küçült" style="margin-right:4px">—</button>
          <button id="evdb-bot-close" title="Gizle">×</button>
        </div>
      </div>
      <div id="evdb-bot-body" style="padding:10px">
        <div style="font-size:12px;margin-bottom:8px;color:#374151">Emanet MİF(A) &gt; Emanet Bilgileri ekranı açıkken çalıştır.</div>
        <div style="border:1px dashed #9ca3af;border-radius:8px;padding:8px;background:#fff;margin-bottom:8px">
          <div style="font-weight:bold;margin-bottom:6px">Excel dosyası (.xlsx)</div>
          <input id="evdb-bot-file" type="file" accept=".xlsx" style="display:none">
          <button id="evdb-bot-choose">Dosya Seç</button>
          <span id="evdb-bot-file-name" style="margin-left:8px;color:#4b5563">Dosya seçilmedi</span>
          <div id="evdb-bot-drop" style="margin-top:7px;padding:8px;text-align:center;background:#eef2ff;border-radius:6px;color:#374151">veya Excel dosyasını buraya sürükle-bırak</div>
        </div>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-only-giris" type="checkbox" checked> Sadece İşlem Yönü = Giriş</label>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-no-save" type="checkbox" checked> Kaydet butonuna basma, sadece alta ekle</label>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-stop-error" type="checkbox" checked> Hata olursa dur</label>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-resume-progress" type="checkbox" checked> Başarılı kayıtları hatırla, yeniden başlatınca kaldığı yerden devam et</label>
        <div style="font-size:12px;color:#374151;background:#fefce8;border:1px solid #fde68a;border-radius:6px;padding:5px;margin:6px 0">Emanet Türü Excel sütunundan okunur; boşsa açıklamaya göre 33/44/39 belirlenir. Plaka No sadece Excel Plaka No sütunu doluysa yazılır.</div>
        <div style="display:flex;align-items:center;gap:8px;margin:7px 0">
          <label>Satır bekleme ms</label><input id="evdb-bot-delay" type="number" value="450" min="100" step="50" style="width:90px">
        </div>
        <div style="margin:8px 0;background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:6px">
          Okunan kayıt: <b id="evdb-bot-total">0</b> &nbsp; İşlenecek kayıt: <b id="evdb-bot-usable">0</b> &nbsp; Hafızadaki başarılı: <b id="evdb-bot-done">0</b> &nbsp; Şu an: <b id="evdb-bot-current">0</b><br>Atlanan boş kimlik: <b id="evdb-bot-skip-count">0</b> &nbsp; Fiş No: <span id="evdb-bot-skip-fis" style="color:#b45309">-</span><br>Mükellef bulunamadı / hatalı kimlik: <b id="evdb-bot-invalid-count">0</b> &nbsp; Fiş No: <span id="evdb-bot-invalid-fis" style="color:#b91c1c">-</span><br>Ad/Soyad gelmeyen / sorgu sonuçsuz: <b id="evdb-bot-lookupfail-count">0</b> &nbsp; Fiş No: <span id="evdb-bot-lookupfail-fis" style="color:#be123c">-</span><br>Emanette mevcut / tekrar kayıt: <b id="evdb-bot-existing-count">0</b> &nbsp; Fiş No: <span id="evdb-bot-existing-fis" style="color:#7c2d12">-</span><br>Çıkış/Aktarım atlandı: <b id="evdb-bot-nongiris-count">0</b> &nbsp; Fiş No: <span id="evdb-bot-nongiris-fis" style="color:#4338ca">-</span>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">
          <button id="evdb-bot-read">Dosyayı Oku</button>
          <button id="evdb-bot-start" disabled>Başlat</button>
          <button id="evdb-bot-pause" disabled>Duraklat</button>
          <button id="evdb-bot-resume" disabled>Devam</button>
          <button id="evdb-bot-stop" disabled>Durdur</button>
          <button id="evdb-bot-clear">Log Temizle</button>
          <button id="evdb-bot-clear-progress">Hafızayı Sıfırla</button>
        </div>
        <div id="evdb-bot-status" style="margin:6px 0;color:#111827;font-weight:bold">Hazır.</div>
        <pre id="evdb-bot-log" style="height:170px;overflow:auto;white-space:pre-wrap;background:#111827;color:#d1fae5;padding:8px;margin:0;border-radius:6px;font-size:12px"></pre>
      </div>`;
    document.documentElement.appendChild(panel);
    makeDraggable(panel, $('evdb-bot-drag'));
    wirePanel();
    log('Bot penceresi hazır. Excel dosyasını seçip “Dosyayı Oku” deyin.');
    if (!show) panel.style.display = 'none';
    return panel;
  }

  function setStatus(msg) {
    const s = $('evdb-bot-status');
    if (s) s.textContent = msg;
    log(msg, false);
  }
  function log(msg, includeStatus = true) {
    ensurePanel(false);
    const line = `[${new Date().toLocaleTimeString('tr-TR')}] ${msg}`;
    console.log('[EVDB Emanet Bot]', msg);
    const box = $('evdb-bot-log');
    if (box) { box.textContent += line + '\n'; box.scrollTop = box.scrollHeight; }
    if (includeStatus) {
      const cur = $('evdb-bot-current'); if (cur) cur.textContent = String(state.current || 0);
    }
  }
  function updateCounters(total, usable) {
    if ($('evdb-bot-total')) $('evdb-bot-total').textContent = String(total ?? state.total ?? 0);
    if ($('evdb-bot-usable')) $('evdb-bot-usable').textContent = String(usable ?? state.preparedRows.length ?? 0);
    if ($('evdb-bot-current')) $('evdb-bot-current').textContent = String(state.current || 0);
    if ($('evdb-bot-done')) $('evdb-bot-done').textContent = String(state.completedSet ? state.completedSet.size : 0);
    if ($('evdb-bot-skip-count')) $('evdb-bot-skip-count').textContent = String(state.skippedNoIdentity ? state.skippedNoIdentity.length : 0);
    if ($('evdb-bot-skip-fis')) {
      const arr = state.skippedNoIdentity || [];
      $('evdb-bot-skip-fis').textContent = arr.length ? arr.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ') : '-';
    }
    if ($('evdb-bot-invalid-count')) $('evdb-bot-invalid-count').textContent = String(state.invalidIdentity ? state.invalidIdentity.length : 0);
    if ($('evdb-bot-invalid-fis')) {
      const arr = state.invalidIdentity || [];
      $('evdb-bot-invalid-fis').textContent = arr.length ? arr.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ') : '-';
    }
    if ($('evdb-bot-lookupfail-count')) $('evdb-bot-lookupfail-count').textContent = String(state.identityLookupFailed ? state.identityLookupFailed.length : 0);
    if ($('evdb-bot-lookupfail-fis')) {
      const arr = state.identityLookupFailed || [];
      $('evdb-bot-lookupfail-fis').textContent = arr.length ? arr.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ') : '-';
    }
    if ($('evdb-bot-existing-count')) $('evdb-bot-existing-count').textContent = String(state.duplicateExisting ? state.duplicateExisting.length : 0);
    if ($('evdb-bot-existing-fis')) {
      const arr = state.duplicateExisting || [];
      $('evdb-bot-existing-fis').textContent = arr.length ? arr.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ') : '-';
    }
    if ($('evdb-bot-nongiris-count')) $('evdb-bot-nongiris-count').textContent = String(state.skippedNonGiris ? state.skippedNonGiris.length : 0);
    if ($('evdb-bot-nongiris-fis')) {
      const arr = state.skippedNonGiris || [];
      $('evdb-bot-nongiris-fis').textContent = arr.length ? arr.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ') : '-';
    }
  }

  function wirePanel() {
    $('evdb-bot-close').onclick = () => { $(PANEL_ID).style.display = 'none'; };
    $('evdb-bot-min').onclick = () => {
      const b = $('evdb-bot-body');
      b.style.display = b.style.display === 'none' ? 'block' : 'none';
    };
    $('evdb-bot-clear').onclick = () => { $('evdb-bot-log').textContent = ''; };
    $('evdb-bot-clear-progress').onclick = () => { clearProgress(); };
    $('evdb-bot-choose').onclick = () => $('evdb-bot-file').click();
    $('evdb-bot-file').addEventListener('change', e => setFile(e.target.files && e.target.files[0]));

    const dz = $('evdb-bot-drop');
    ['dragenter','dragover'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.style.background = '#dbeafe'; }));
    ['dragleave','drop'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.style.background = '#eef2ff'; }));
    dz.addEventListener('drop', e => {
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (!file) return setStatus('Bırakılan dosya alınamadı.');
      setFile(file);
    });

    $('evdb-bot-read').onclick = readExcel;
    $('evdb-bot-start').onclick = () => runRows(state.preparedRows, getOptions());
    $('evdb-bot-pause').onclick = () => { state.paused = true; setStatus('Duraklatıldı.'); updateButtons(); };
    $('evdb-bot-resume').onclick = () => { state.paused = false; setStatus('Devam ediyor.'); updateButtons(); };
    $('evdb-bot-stop').onclick = () => { state.stopped = true; state.running = false; setStatus('Durduruluyor...'); updateButtons(); };
  }

  function updateButtons() {
    const start = $('evdb-bot-start'), pause = $('evdb-bot-pause'), resume = $('evdb-bot-resume'), stop = $('evdb-bot-stop');
    if (!start) return;
    start.disabled = state.running || !state.preparedRows.length;
    pause.disabled = !state.running || state.paused;
    resume.disabled = !state.running || !state.paused;
    stop.disabled = !state.running;
  }

  function setFile(file) {
    if (!file) return setStatus('Dosya seçilmedi.');
    if (!file.name.toLowerCase().endsWith('.xlsx')) return setStatus('Sadece .xlsx dosyası seçin.');
    state.selectedFile = file;
    state.preparedRows = [];
    state.runId = null;
    state.completedSet = new Set();
    updateCounters(0,0);
    $('evdb-bot-file-name').textContent = `${file.name} (${Math.round(file.size/1024)} KB)`;
    $('evdb-bot-start').disabled = true;
    setStatus('Dosya seçildi. Şimdi “Dosyayı Oku” butonuna basın.');
  }

  function normalizeDate(v) {
    v = String(v || '').trim();
    if (!v) return '';
    let m = v.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
    if (m) return `${m[1].padStart(2,'0')}.${m[2].padStart(2,'0')}.${m[3]}`;
    if (/^\d+(\.\d+)?$/.test(v)) {
      const n = Number(v);
      if (n > 20000 && n < 80000) {
        const d = new Date(Math.round((n - 25569) * 86400 * 1000));
        return `${String(d.getUTCDate()).padStart(2,'0')}.${String(d.getUTCMonth()+1).padStart(2,'0')}.${d.getUTCFullYear()}`;
      }
    }
    return v;
  }
  function normalizeAmount(v) {
    v = String(v || '').trim();
    if (!v) return '';
    if (v.includes(',') && v.includes('.')) return v.replace(/\./g, '');
    return v.replace(/\s/g, '').replace('.', ',');
  }

  function normalizeUpperTR(s) {
    return String(s || '')
      .toUpperCase()
      .replace(/İ/g, 'I').replace(/İ/g, 'I')
      .replace(/Ş/g, 'S').replace(/Ğ/g, 'G').replace(/Ü/g, 'U').replace(/Ö/g, 'O').replace(/Ç/g, 'C');
  }
  function extractPlakaFromText(text) {
    const raw = normalizeUpperTR(text || '');
    // Örn: 16JME71, 16 APJ 590, 16 ADL 428. FRW gibi bitişik haciz numaralarını yakalamamak için kelime sınırı kullanılır.
    const m = raw.match(/\b(0[1-9]|[1-7][0-9]|8[01])\s*([A-Z]{1,3})\s*(\d{2,4})\b/);
    if (!m) return '';
    return `${m[1]} ${m[2]} ${m[3]}`;
  }
  function inferEmanetTuru(rowObj) {
    const fromExcel = String(pick(rowObj, ['Emanet Türü', 'Emanet Turu', 'EmanetTuru']) || '').trim();
    const txt = normalizeUpperTR([
      fromExcel,
      pick(rowObj, ['Ham Açıklama', 'Ham Aciklama', 'Açıklama', 'Aciklama']),
      pick(rowObj, ['MİF Açıklama Önerisi', 'MIF Aciklama Onerisi']),
      pick(rowObj, ['Gönderen/Ödeyen', 'Gonderen/Odeyen']),
      pick(rowObj, ['Mükellef/Borçlu', 'Mukellef/Borclu']),
      pick(rowObj, ['Belge/Tür', 'Belge/Tur'])
    ].join(' '));
    if (fromExcel) return fromExcel;
    // D.F.I.F / DFIF ile gelenler 33 Kişilere Ait Diğer Emanetler
    if (/D\s*\.?\s*F\s*\.?\s*I\s*\.?\s*F\b/.test(txt) || /\bDFIF\b/.test(txt)) return '33 Kişilere Ait Diğer Emanetler';
    // Teminat / teminat bedeli / ihaleye katılım teminatı gibi açıklamalar 44 Vergi Teminatları
    if (txt.includes('TEMINAT')) return '44 Vergi Teminatları';
    return '39 Diğer Çeşitli Emanetler';
  }
  function pickIdentityFromSpecialText(rowObj, tcNo, vergiNo) {
    const raw = String(pick(rowObj, ['Ham Açıklama', 'Ham Aciklama', 'Açıklama', 'Aciklama']) || '');
    // Örn: BORCNO:...;VKN:10140122630;... bu özel formatta VKN alanındaki 11 hane aslında T.C. No olarak işlenecek.
    const m = raw.match(/BORCNO\s*:\s*[^;\s]+\s*;\s*VKN\s*:\s*(\d{11})/i);
    if (m) return { tcNo: m[1], vergiNo: '' };
    return { tcNo, vergiNo };
  }
  function formatEvdbBelgeNo(raw, tarih, fisNo) {
    let v = String(raw || '').trim();
    const digits = v.replace(/\D/g, '');
    if (digits.length >= 15 && /^20\d{6}/.test(digits)) return `${digits.slice(0,8)}/00-000/${digits.slice(-7)}`;
    const t = String(tarih || '').trim();
    const f = String(fisNo || '').replace(/\D/g, '');
    const m = t.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
    if (!v && m && f) return `${m[3]}${m[2]}${m[1]}/00-000/${f.padStart(7,'0')}`;
    return v;
  }
  function pick(r, names) {
    for (const n of names) if (r[n] !== undefined && r[n] !== null && String(r[n]).trim() !== '') return r[n];
    return '';
  }
  function mapRows(rows) {
    return rows.map(r => {
      const tarih = normalizeDate(pick(r, ['Tarih', 'İşlem Tarihi', 'Duzenleme Tarihi', 'Düzenleme Tarihi']));
      const fisNo = String(pick(r, ['Fiş No', 'Fis No', 'Fiş Numarası']) || '').trim();
      const belgeRaw = String(pick(r, ['Belge No', 'Belge Numarası', 'Belge No.']) || '').trim();
      let tcNo = String(pick(r, ['T.C. No', 'TC No', 'T.C.Kimlik No', 'T.C. Kimlik No']) || '').replace(/\D/g, '');
      let vergiNo = String(pick(r, ['Vergi No', 'Vergi Kimlik No', 'VKN']) || '').replace(/\D/g, '');
      const specialIdentity = pickIdentityFromSpecialText(r, tcNo, vergiNo);
      tcNo = specialIdentity.tcNo;
      vergiNo = specialIdentity.vergiNo;
      return {
        excelRow: r.__rownum,
        tarih,
        fisNo,
        belgeNo: formatEvdbBelgeNo(belgeRaw, tarih, fisNo),
        belgeNoExcel: belgeRaw,
        tutar: normalizeAmount(pick(r, ['İşlem Tutarı', 'Islem Tutari', 'Tutar', 'Tutarı'])),
        islemYonu: String(pick(r, ['İşlem Yönü', 'Islem Yonu', 'Yön']) || '').trim(),
        emanetTuru: inferEmanetTuru(r),
        // v3.0: Plaka No sütunu boşsa açıklamadan plaka aranmaz; EVDB Plaka No alanı boş bırakılır.
        plakaNo: String(pick(r, ['Plaka No', 'Plaka', 'PlakaNo']) || '').trim(),
        tcNo,
        vergiNo,
        ham: r
      };
    }).filter(r => r.tarih || r.belgeNo || r.tutar || r.tcNo || r.vergiNo || r.islemYonu || r.fisNo || r.emanetTuru || r.plakaNo);
  }

  function hashString(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(36);
  }
  function rowKey(row) {
    return [row.excelRow, row.belgeNo, row.tcNo || '', row.vergiNo || '', row.tutar, row.tarih, row.emanetTuru || '', row.plakaNo || ''].join('|');
  }
  function computeRunId(file, preparedRows) {
    const first = preparedRows[0] ? rowKey(preparedRows[0]) : '';
    const last = preparedRows.length ? rowKey(preparedRows[preparedRows.length - 1]) : '';
    const base = `${file?.name || 'dosya'}|${file?.size || 0}|${preparedRows.length}|${first}|${last}`;
    return 'evdb-emanet-v29-' + hashString(base);
  }
  function progressStorageKey() {
    return state.runId ? `EVDB_EMANET_PROGRESS_${state.runId}` : null;
  }
  function loadProgress() {
    state.completedSet = new Set();
    const key = progressStorageKey();
    if (!key) return;
    try {
      const obj = JSON.parse(localStorage.getItem(key) || '{}');
      const arr = Array.isArray(obj.completedKeys) ? obj.completedKeys : [];
      state.completedSet = new Set(arr);
      log(`Hafıza yüklendi. Daha önce başarılı: ${state.completedSet.size}`);
    } catch (e) {
      log('Hafıza okunamadı: ' + e.message);
    }
    updateCounters(state.total, state.preparedRows.length);
  }
  function saveProgress() {
    const key = progressStorageKey();
    if (!key) return;
    try {
      localStorage.setItem(key, JSON.stringify({
        runId: state.runId,
        updatedAt: new Date().toISOString(),
        completedKeys: [...state.completedSet]
      }));
    } catch (e) {
      log('Hafıza kaydedilemedi: ' + e.message);
    }
  }
  function markRowCompleted(row) {
    if (!row) return;
    state.completedSet.add(rowKey(row));
    saveProgress();
    updateCounters(state.total, state.preparedRows.length);
  }
  function isRowCompleted(row) {
    return !!(row && state.completedSet && state.completedSet.has(rowKey(row)));
  }
  function clearProgress() {
    const key = progressStorageKey();
    if (key) localStorage.removeItem(key);
    state.completedSet = new Set();
    updateCounters(state.total, state.preparedRows.length);
    setStatus('Bu Excel için kayıt hafızası sıfırlandı.');
  }

  async function readExcel() {
    const file = state.selectedFile || ($('evdb-bot-file')?.files && $('evdb-bot-file').files[0]);
    if (!file) return setStatus('Önce Excel dosyası seçin.');
    try {
      setStatus('Excel okunuyor...');
      if (!window.XLSXLite) throw new Error('Excel okuyucu yüklenmedi. Eklentiyi yeniden yükleyin.');
      const wb = await XLSXLite.readXlsx(file, 'Emanet_Rapor');
      const allMappedRows = mapRows(wb.rows);
      // Banka çıkışları/aktarımlar emanet girişine işlenmez. Sadece İşlem Yönü = Giriş satırları aktarılır.
      state.skippedNonGiris = allMappedRows.filter(r => norm(r.islemYonu) && norm(r.islemYonu) !== 'giris');
      state.preparedRows = allMappedRows.filter(r => !norm(r.islemYonu) || norm(r.islemYonu) === 'giris');
      state.total = wb.rows.length;
      state.current = 0;
      state.skippedNoIdentity = [];
      state.invalidIdentity = [];
      state.duplicateExisting = [];
      state.identityLookupFailed = [];
      state.runId = computeRunId(file, state.preparedRows);
      loadProgress();
      updateCounters(wb.rows.length, state.preparedRows.length);
      updateButtons();
      setStatus(`Okundu. Sayfa: ${wb.sheetName}. İşlenecek giriş kaydı: ${state.preparedRows.length}. Çıkış/Aktarım atlanan: ${state.skippedNonGiris.length}.`);
      if (state.skippedNonGiris.length) log(`Çıkış/Aktarım olduğu için atlanan kayıt sayısı: ${state.skippedNonGiris.length}. Fiş No: ${state.skippedNonGiris.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ')}`);
      log('İlk giriş kayıt örnekleri: ' + JSON.stringify(state.preparedRows.slice(0,3), null, 2));
    } catch (e) {
      const msg = String(e?.message || e || '');
      setStatus('Excel okuma hatası: ' + msg);
      if (msg.toLowerCase().includes('requested file could not be read') || msg.toLowerCase().includes('permission')) {
        // Chrome bazen seçilmiş dosya referansının iznini kaybediyor. Eklenti aynı dosyayı
        // kullanıcı seçmeden tekrar okuyamaz; bu yüzden dosya alanını temizleyip aynı Excel'in
        // yeniden seçilmesini isteriz. Hafıza/progress silinmez.
        state.selectedFile = null;
        state.preparedRows = [];
        const fi = $('evdb-bot-file');
        if (fi) fi.value = '';
        if ($('evdb-bot-file-name')) $('evdb-bot-file-name').textContent = 'Dosya erişimi koptu; aynı Excel dosyasını yeniden seçin';
        if ($('evdb-bot-start')) $('evdb-bot-start').disabled = true;
        log('Dosya erişim izni kayboldu. Aynı Excel dosyasını Dosya Seç ile yeniden seçip Dosyayı Oku deyin. Hafızadaki başarılı kayıtlar korunur.');
      }
    }
  }
  function getOptions() {
    return {
      noAutoSave: $('evdb-bot-no-save')?.checked ?? true,
      stopOnError: $('evdb-bot-stop-error')?.checked ?? true,
      delay: Number($('evdb-bot-delay')?.value || 450),
      resumeProgress: $('evdb-bot-resume-progress')?.checked ?? true,
      belgeTuru: 'Diğer',
      emanetTuru: '39 Diğer Çeşitli Emanetler'
    };
  }

  function injectConfirmOverride() {
    // v0.6: EVDB sayfasının CSP kuralı inline script çalıştırmaya izin vermiyor.
    // Bu yüzden window.confirm override yapılmıyor; uyarı penceresi görünürse Evet/Tamam butonu tıklanıyor.
  }

  function isTextLike(el) {
    if (!el) return false;
    const tag = el.tagName;
    const type = String(el.getAttribute('type') || '').toLowerCase();
    if (tag === 'TEXTAREA' || el.isContentEditable) return true;
    if (tag !== 'INPUT') return false;
    return !['button','submit','reset','checkbox','radio','hidden','image','file'].includes(type);
  }
  function isComboLike(el) {
    if (!el) return false;
    const tag = el.tagName;
    const role = String(el.getAttribute('role') || '').toLowerCase();
    const cls = String(el.className || '').toLowerCase();
    return tag === 'SELECT' || role === 'combobox' || cls.includes('combo') || cls.includes('x-form-field');
  }
  function allCandidates(kind = 'any') {
    let q = 'input, textarea, select, [contenteditable="true"], [role="combobox"]';
    let arr = [...document.querySelectorAll(q)].filter(visible).filter(c => !c.closest('#' + PANEL_ID));
    if (kind === 'text') arr = arr.filter(isTextLike);
    if (kind === 'combo') arr = arr.filter(c => c.tagName === 'SELECT' || c.getAttribute('role') === 'combobox' || isTextLike(c));
    return arr;
  }
  function findLabelNode(label) {
    const nlabel = norm(label);
    let best = null;
    const nodes = [...document.querySelectorAll('label, td, th, div, span, font, b')].filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    for (const el of nodes) {
      const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      const t = norm(txt);
      if (!t) continue;
      if (t === nlabel || t.includes(nlabel)) {
        // Çok uzun metinler yakın etiket değildir. En kısa ve en soldaki/üstteki gerçek etiketi seç.
        const score = t.length + (el.getBoundingClientRect().width > 250 ? 200 : 0);
        if (!best || score < best._score) { best = el; best._score = score; }
      }
    }
    return best;
  }
  function scoreCandidate(labelRect, r, preferRight = true) {
    const vgap = Math.abs((r.top + r.height/2) - (labelRect.top + labelRect.height/2));
    const rightDist = r.left - labelRect.right;
    const leftPenalty = rightDist < -20 ? 600 : 0;
    const tooFarV = vgap > 75 ? 400 : 0;
    return vgap * 10 + Math.max(0, rightDist) + leftPenalty + tooFarV;
  }
  function findControlAfterLabel(label, kind = 'any') {
    const nlabel = norm(label);
    const controls = allCandidates(kind);

    // 1) Önce attribute üzerinden net eşleşme.
    for (const c of controls) {
      const attrs = [c.name, c.id, c.title, c.placeholder, c.getAttribute('aria-label'), c.getAttribute('fieldLabel'), c.getAttribute('data-qtip')].map(norm).join(' ');
      if (attrs && attrs.includes(nlabel)) return c;
    }

    // 2) Ekrandaki etiketin aynı satırındaki en yakın uygun input/select.
    const labelNode = findLabelNode(label);
    if (!labelNode) return null;
    const lr = labelNode.getBoundingClientRect();
    let best = null, bestScore = Infinity;

    for (const c of controls) {
      const r = c.getBoundingClientRect();
      if (r.width < 15 || r.height < 8) continue;
      // Aynı satırda etiketin sağındaki alanlara öncelik ver.
      const sameLine = Math.abs((r.top + r.height/2) - (lr.top + lr.height/2)) < 35;
      const toRight = r.left > lr.left - 10;
      const closeBelow = r.top >= lr.top - 5 && r.top - lr.top < 95 && r.left > lr.left - 20;
      if (!(sameLine && toRight) && !closeBelow) continue;
      const score = scoreCandidate(lr, r);
      if (score < bestScore) { best = c; bestScore = score; }
    }
    if (best) return best;

    // 3) Eski yöntem: aynı kapsayıcı içinde ilk uygun kontrol.
    const near = labelNode.closest('tr, .x-form-item, .form-group, table, div') || labelNode.parentElement;
    if (near) {
      const inside = [...near.querySelectorAll('input, textarea, select, [contenteditable="true"], [role="combobox"]')]
        .filter(visible).filter(c => !c.closest('#' + PANEL_ID));
      const filtered = kind === 'text' ? inside.filter(isTextLike) : inside;
      if (filtered.length) return filtered[0];
    }
    return null;
  }
  function getValue(el) {
    return String((el && ('value' in el ? el.value : el.textContent)) || '').trim();
  }
  function setNativeValue(el, value) {
    if (!el) throw new Error('Alan bulunamadı.');
    const v = String(value ?? '');
    el.scrollIntoView({ block: 'center', inline: 'center' });
    el.focus();
    if (el.tagName === 'SELECT') {
      const nval = norm(v);
      let opt = [...el.options].find(o => norm(o.textContent).includes(nval) || norm(o.value).includes(nval));
      if (!opt) throw new Error('Açılır listede seçenek yok: ' + v);
      el.value = opt.value;
    } else if (el.isContentEditable) {
      el.textContent = v;
    } else {
      try { el.select && el.select(); } catch(e) {}
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, v); else el.value = v;
    }
    ['focus','input','change','keyup'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Tab', code: 'Tab' }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Tab', code: 'Tab' }));
    el.blur && el.blur();
  }
  async function typeValue(label, value) {
    const el = findControlAfterLabel(label, 'text');
    if (!el) throw new Error(`Alan bulunamadı: ${label}`);
    if (el.tagName === 'SELECT') throw new Error(`Metin alanı yerine liste bulundu: ${label}`);
    setNativeValue(el, String(value || ''));
    await sleep(120);
    log(`${label} yazıldı: ${value}`);
    return el;
  }
  async function typeValueAny(labels, value) {
    for (const label of labels) {
      const el = findControlAfterLabel(label, 'text');
      if (el && el.tagName !== 'SELECT') {
        setNativeValue(el, String(value || ''));
        await sleep(120);
        log(`${label} yazıldı: ${value}`);
        return el;
      }
    }
    throw new Error(`Alan bulunamadı: ${labels.join(' / ')}`);
  }
  function optionScoreForText(el, target) {
    const raw = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    const t = norm(raw);
    if (!t) return Infinity;
    const r = el.getBoundingClientRect();
    if (r.width < 10 || r.height < 6) return Infinity;
    // Çok büyük kapsayıcılar genelde bütün açılır listeyi temsil eder; seçenek satırı değildir.
    const bigBoxPenalty = (r.height > 45 ? 500 : 0) + (r.width > 900 ? 200 : 0);
    if (t === target) return raw.length + bigBoxPenalty;
    if (t.startsWith(target)) return 40 + raw.length + bigBoxPenalty;
    if (t.includes(target)) return 120 + raw.length + bigBoxPenalty;
    return Infinity;
  }

  function findOpenOption(text) {
    const target = norm(text);
    const nodes = [...document.querySelectorAll('div, li, td, tr, span')]
      .filter(visible)
      .filter(el => !el.closest('#' + PANEL_ID));
    let best = null, bestScore = Infinity;
    for (const el of nodes) {
      const score = optionScoreForText(el, target);
      if (score < bestScore) { best = el; bestScore = score; }
    }
    return best;
  }

  function findTextRangeCandidate(text) {
    const target = norm(text);
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const raw = String(node.nodeValue || '').replace(/\s+/g, ' ').trim();
        if (!raw) return NodeFilter.FILTER_REJECT;
        const t = norm(raw);
        if (t.includes(target) || (target.startsWith('39') && t.includes('diger cesitli emanetler')) || (target === 'diger' && t === 'diger')) {
          const pe = node.parentElement;
          if (pe && visible(pe) && !pe.closest('#' + PANEL_ID)) return NodeFilter.FILTER_ACCEPT;
        }
        return NodeFilter.FILTER_REJECT;
      }
    });
    let best = null, bestScore = Infinity;
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const range = document.createRange();
      range.selectNodeContents(node);
      const rects = [...range.getClientRects()].filter(r => r.width > 5 && r.height > 5);
      range.detach && range.detach();
      for (const r of rects) {
        const raw = String(node.nodeValue || '').replace(/\s+/g, ' ').trim();
        const t = norm(raw);
        const score = (t === target ? 0 : t.startsWith(target) ? 20 : 80) + raw.length + (r.height > 35 ? 200 : 0);
        if (score < bestScore) { best = { node, rect: r, raw }; bestScore = score; }
      }
    }
    return best;
  }

  async function realMouseClickAt(x, y) {
    let el = document.elementFromPoint(x, y);
    if (!el) return false;
    // Çok içteki text/span yerine tıklanabilir satıra doğru çık.
    let target = el;
    for (let i=0; i<5 && target; i++) {
      const cls = String(target.className || '').toLowerCase();
      const role = String(target.getAttribute && target.getAttribute('role') || '').toLowerCase();
      if (target.tagName === 'OPTION' || target.tagName === 'LI' || target.tagName === 'TR' || target.tagName === 'TD' || cls.includes('item') || cls.includes('list') || role === 'option') break;
      if (!target.parentElement || target.parentElement === document.body) break;
      target = target.parentElement;
    }
    for (const t of [target, el]) {
      if (!t) continue;
      t.dispatchEvent(new MouseEvent('mouseover', { bubbles:true, cancelable:true, clientX:x, clientY:y, view:window }));
      t.dispatchEvent(new MouseEvent('mousemove', { bubbles:true, cancelable:true, clientX:x, clientY:y, view:window }));
      t.dispatchEvent(new MouseEvent('mousedown', { bubbles:true, cancelable:true, clientX:x, clientY:y, view:window, button:0 }));
      t.dispatchEvent(new MouseEvent('mouseup', { bubbles:true, cancelable:true, clientX:x, clientY:y, view:window, button:0 }));
      t.click && t.click();
    }
    await sleep(350);
    return true;
  }

  async function clickDropdownOptionStrict(text) {
    // 1) Açık listedeki gerçek metin satırını Range koordinatıyla tıkla.
    let candidate = findTextRangeCandidate(text);
    if (!candidate && /^39\b/.test(text)) candidate = findTextRangeCandidate('Diğer Çeşitli Emanetler');
    if (!candidate && norm(text) === 'diger') candidate = findTextRangeCandidate('Diğer');
    if (candidate) {
      const r = candidate.rect;
      const ok = await realMouseClickAt(r.left + Math.min(r.width - 2, Math.max(8, r.width / 2)), r.top + r.height / 2);
      if (ok) return true;
    }

    // 2) Eski DOM elemanı yöntemi.
    let opt = findOpenOption(text);
    if (!opt && /^39\b/.test(text)) opt = findOpenOption('Diğer Çeşitli Emanetler');
    if (!opt && norm(text) === 'diger') opt = findOpenOption('Diğer');
    if (!opt) return false;
    opt.scrollIntoView({ block: 'center', inline: 'nearest' });
    await sleep(120);
    const r = opt.getBoundingClientRect();
    return await realMouseClickAt(r.left + Math.min(r.width - 4, Math.max(10, r.width / 2)), r.top + r.height / 2);
  }

  async function selectByText(label, text) {
    const el = findControlAfterLabel(label, 'combo') || findControlAfterLabel(label, 'text');
    if (!el) throw new Error(`Liste alanı bulunamadı: ${label}`);
    el.scrollIntoView({ block: 'center', inline: 'center' });

    if (el.tagName === 'SELECT') {
      setNativeValue(el, text);
      await sleep(220);
      log(`${label} seçildi: ${text}`);
      return;
    }

    // EVDB eski tip sarı açılır liste: önce listeyi aç, görünen seçenek satırını koordinattan tıkla.
    el.focus();
    el.click();
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles:true }));
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles:true }));
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'ArrowDown', code: 'ArrowDown' }));
    await sleep(250);

    let clicked = await clickDropdownOptionStrict(text);

    // Liste açıldı ama seçenek bulunmadıysa metni yazıp Enter/Tab ile seçtirmeyi dene.
    if (!clicked) {
      try { setNativeValue(el, text); } catch (_) {}
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter' }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', code: 'Enter' }));
      await sleep(300);
      clicked = norm(getValue(el)).includes(norm(text)) || (/^39\b/.test(text) && norm(getValue(el)).includes('39'));
    }

    // Özellikle emanet türü için tekrar açıp 39 satırını tıkla.
    if (!clicked && wantedCode) {
      el.focus(); el.click(); await sleep(300);
      clicked = await clickDropdownOptionStrict(wanted) || await clickDropdownOptionStrict(wantedCode);
    }

    // Son çare: görünen kutuya değeri yazıp change/blur yaptır. EVDB bazı combo alanlarında bunu kabul ediyor.
    if (!clicked) {
      setNativeValue(el, wanted);
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Tab', code: 'Tab' }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Tab', code: 'Tab' }));
      el.blur && el.blur();
      await sleep(300);
      clicked = norm(getValue(el)).includes('39') || norm(getValue(el)).includes('diger cesitli');
    }

    if (!clicked) throw new Error(`Açılır listede seçenek seçilemedi: ${text}`);
    log(`${label} seçildi: ${text}`);
  }
  function clickVisibleText(text, required = true) {
    const target = norm(text);
    const nodes = [...document.querySelectorAll('button, input[type="button"], input[type="submit"], a, span, div, td')].filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    let best = null;
    for (const el of nodes) {
      const val = el.tagName === 'INPUT' ? el.value : (el.innerText || el.textContent || '');
      const t = norm(val);
      if (t === target || t.includes(target)) { best = el; break; }
    }
    if (!best) {
      if (required) throw new Error('Buton/metin bulunamadı: ' + text);
      return false;
    }
    best.scrollIntoView({ block: 'center', inline: 'center' });
    best.focus && best.focus();
    best.click();
    return true;
  }
  async function clickButton(text) { clickVisibleText(text, true); await sleep(300); log(`${text} tıklandı.`); }
  function findVisiblePopup() {
    const nodes = [...document.querySelectorAll('div, table, form')].filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    let best = null, bestZ = -1;
    for (const el of nodes) {
      const txt = norm(el.innerText || el.textContent || '');
      const cls = String(el.className || '').toLowerCase();
      const id = String(el.id || '').toLowerCase();
      const st = getComputedStyle(el);
      const z = Number(st.zIndex) || 0;
      if ((txt.includes('zaman asimi') || txt.includes('onay mesaji') || cls.includes('popup') || id.includes('popup')) && z >= bestZ) {
        best = el; bestZ = z;
      }
    }
    return best;
  }

  function findButtonInScope(scope, texts) {
    const wanted = texts.map(norm);
    const nodes = [...(scope || document).querySelectorAll('button, input[type="button"], input[type="submit"], a, span, div, td')]
      .filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    let best = null, bestScore = Infinity;
    for (const el of nodes) {
      const val = el.tagName === 'INPUT' ? el.value : (el.innerText || el.textContent || '');
      const t = norm(val);
      if (!t) continue;
      for (const w of wanted) {
        if (t === w || t.includes(w)) {
          const r = el.getBoundingClientRect();
          const score = t.length + (r.width > 180 ? 200 : 0) + (r.height > 60 ? 200 : 0);
          if (score < bestScore) { best = el; bestScore = score; }
        }
      }
    }
    return best;
  }

  function confirmPopupVisible() {
    const p = findVisiblePopup();
    if (!p) return false;
    const txt = norm(p.innerText || p.textContent || '');
    return txt.includes('zaman asimi') || txt.includes('onay mesaji') || !!findButtonInScope(p, ['Evet', 'Tamam']);
  }

  async function clickYesIfExists(row = null) {
    // EVDB bazı durumlarda Evet tıklanınca popup DOM'unu ekranda/DOM'da kısa süre bırakıyor.
    // Bu yüzden başarı kriteri sadece popup kapanması değil; üst form temizlendiyse veya Emanet Ekle
    // butonu tekrar aktif hale geldiyse onay verilmiş kabul edilir.
    let sawPopup = false;
    for (let i=0; i<55; i++) {
      await throwEmanetteMevcutIfPopup(row);
      const popup = findVisiblePopup();
      if (popup) sawPopup = true;
      let btn = null;
      if (popup) btn = findButtonInScope(popup, ['Evet', 'Tamam']);
      if (!btn) btn = findButtonInScope(document, ['Evet', 'Tamam']);
      if (btn) {
        clickHard(btn);
        await sleep(350);
        if (confirmPopupVisible()) { clickHard(btn); await sleep(350); }
        if (!confirmPopupVisible()) { log('Onay penceresi: Evet/Tamam tıklandı.'); return true; }
      }

      // Popup kapanmış gibi işlem yapıldıysa EVDB üst formu temizler. Bu durumda popup DOM'u görünür sanılsa
      // bile satır eklenmiştir; hata vermeden devam edelim.
      try {
        if (sawPopup && isTopFormEmptyEnough()) {
          log('Onay sonrası üst form temizlendi; Evet işlemi başarılı kabul edildi.');
          return true;
        }
      } catch (_) {}
      await sleep(250);
    }
    if (confirmPopupVisible()) {
      try {
        if (isTopFormEmptyEnough()) {
          log('Onay penceresi DOM’da görünüyor ama form temiz; başarılı kabul edildi.');
          return true;
        }
      } catch (_) {}
      throw new Error('Onay penceresi açık kaldı; Evet butonu otomatik tıklanamadı.');
    }
    log('Onay penceresi görünmedi.');
    return false;
  }
  function findPopupByText(patterns) {
    const wanted = patterns.map(norm);
    const nodes = [...document.querySelectorAll('div, table, form, span, td')]
      .filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    let best = null, bestZ = -1, bestText = '';
    for (const el of nodes) {
      const raw = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      const txt = norm(raw);
      if (!txt) continue;
      if (!wanted.some(w => txt.includes(w))) continue;
      const st = getComputedStyle(el);
      const z = Number(st.zIndex) || 0;
      const r = el.getBoundingClientRect();
      const scoreZ = z + (r.width > 180 && r.height > 80 ? 1000 : 0);
      if (scoreZ >= bestZ) { best = el; bestZ = scoreZ; bestText = raw; }
    }
    if (best) best._evdbPopupText = bestText;
    return best;
  }

  function findMukellefBulunamadiPopup() {
    // EVDB VKN veya TCKN hatalı/yanlış/geçersiz olduğunda bu tip hata penceresi açıyor.
    return findPopupByText([
      'mükellef bulunamadı', 'mukellef bulunamadi',
      'vergi numarasına ait mükellef bulunamadı', 'vergi numarasina ait mukellef bulunamadi',
      'kimlik numarasına ait mükellef bulunamadı', 'kimlik numarasina ait mukellef bulunamadi',
      'tc kimlik numarasına ait mükellef bulunamadı', 'tc kimlik numarasina ait mukellef bulunamadi',
      // Örn: "Girilen vergi kimlik numarası geçerli değil. Kontrol ediniz. Vergino: ..."
      'vergi kimlik numarası geçerli değil', 'vergi kimlik numarasi gecerli degil',
      'vergi numarası geçerli değil', 'vergi numarasi gecerli degil',
      'girilen vergi kimlik numarası geçerli değil', 'girilen vergi kimlik numarasi gecerli degil',
      'girmiş olduğunuz vergi kimlik numarası geçerli değil', 'girmis oldugunuz vergi kimlik numarasi gecerli degil',
      'tc kimlik numarası geçerli değil', 'tc kimlik numarasi gecerli degil',
      't.c. kimlik numarası geçerli değil', 't.c. kimlik numarasi gecerli degil',
      'girilen tc kimlik numarası geçerli değil', 'girilen tc kimlik numarasi gecerli degil',
      'girilen t.c. kimlik numarası geçerli değil', 'girilen t.c. kimlik numarasi gecerli degil',
      'kimlik numarası geçerli değil', 'kimlik numarasi gecerli degil'
    ]);
  }

  function findEmanetteMevcutPopup() {
    // Aynı tutar/belge/emanet satırı zaten tabloda varsa EVDB bilgi penceresi açıyor.
    // Bu durumda kaydı tekrar denemeden atlayıp Fiş No'yu raporlarız.
    return findPopupByText([
      'emanet tablosunda var',
      'tekrar ekleyemezsiniz', 'tekrar eklenemez',
      'eklemek istediğiniz', 'eklemek istediginiz',
      'emanete eklemek istediğiniz', 'emanete eklemek istediginiz',
      'zaten emanet', 'zaten mevcut'
    ]);
  }

  async function clickTamamOnPopup(popup) {
    let btn = null;
    if (popup) btn = findButtonInScope(popup, ['Tamam']);
    if (!btn) btn = findButtonInScope(document, ['Tamam']);
    if (btn) {
      clickHard(btn);
      await sleep(350);
      log('Hatalı/geçersiz kimlik uyarısında Tamam tıklandı.');
      return true;
    }
    return false;
  }

  async function throwInvalidIdentityIfPopup(row) {
    const popup = findMukellefBulunamadiPopup();
    if (!popup) return false;
    const msg = (popup._evdbPopupText || popup.innerText || popup.textContent || '').replace(/\s+/g, ' ').trim();
    await clickTamamOnPopup(popup);
    try { await clickEmanetBilgileriniTemizleStrict(false); } catch (_) {}
    const kind = row && row.vergiNo ? 'Vergi No hatalı' : (row && row.tcNo ? 'T.C. No hatalı' : 'Kimlik hatalı');
    const err = new Error(`${kind}: Mükellef bulunamadı. ${msg}`.trim());
    err.skipInvalidIdentity = true;
    throw err;
  }

  async function throwEmanetteMevcutIfPopup(row) {
    const popup = findEmanetteMevcutPopup();
    if (!popup) return false;
    const msg = (popup._evdbPopupText || popup.innerText || popup.textContent || '').replace(/\s+/g, ' ').trim();
    await clickTamamOnPopup(popup);
    try { await clickEmanetBilgileriniTemizleStrict(false); } catch (_) {}
    const err = new Error(`Emanette mevcut / tekrar kayıt. ${msg}`.trim());
    err.skipDuplicateExisting = true;
    throw err;
  }

  async function waitForIdentityFilled(timeoutMs = 9000, row = null) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      await throwInvalidIdentityIfPopup(row);
      const ad = findControlAfterLabel('Ad', 'text');
      const soyad = findControlAfterLabel('Soyad', 'text');
      const unvan = findControlAfterLabel('Unvan', 'text') || findControlAfterLabel('Adı Soyadı', 'text') || findControlAfterLabel('Mükellef', 'text');
      const vals = [ad, soyad, unvan].filter(Boolean).map(getValue).filter(Boolean);
      if (vals.length >= 1) return true;
      await sleep(200);
    }
    return false;
  }



  async function nudgeIdentityLookup(identityEl, attempt = 1) {
    try {
      if (identityEl) {
        identityEl.dispatchEvent(new Event('change', { bubbles:true, cancelable:true }));
        identityEl.blur && identityEl.blur();
      }
    } catch (_) {}

    // EVDB bazen kimlik yazıldıktan sonra boş alana tıklamadan sorguyu tetiklemiyor.
    // İlk deneme: Belge No alanına kısa odak/blur.
    const belgeNo = findControlAfterLabel('Belge No', 'text');
    if (belgeNo) {
      try { clickHard(belgeNo); await sleep(120); belgeNo.blur && belgeNo.blur(); } catch (_) {}
    }

    // İkinci deneme: Emanet Türü / Plaka No etiketinin sağındaki boş bölgeye tıkla.
    try {
      const label = findLabelNode('Emanet Türü') || findLabelNode('Plaka No') || findLabelNode('Belge No');
      if (label) {
        const r = label.getBoundingClientRect();
        const x = Math.min(window.innerWidth - 30, Math.max(30, r.right + 80));
        const y = Math.min(window.innerHeight - 30, Math.max(30, r.top + r.height / 2 + (attempt % 3) * 8));
        await realMouseClickAt(x, y);
      } else {
        await realMouseClickAt(Math.min(window.innerWidth - 40, 260), Math.min(window.innerHeight - 40, 330));
      }
    } catch (_) {}
    await sleep(300);
    log(`Kimlik sorgusu için boş alan tıklaması denendi (${attempt}).`);
  }

  async function waitForIdentityFilledWithNudges(identityEl, timeoutMs = 15000, row = null) {
    const start = Date.now();
    let lastNudge = 0;
    let attempt = 0;
    while (Date.now() - start < timeoutMs) {
      await throwInvalidIdentityIfPopup(row);
      const ad = findControlAfterLabel('Ad', 'text');
      const soyad = findControlAfterLabel('Soyad', 'text');
      const unvan = findControlAfterLabel('Unvan', 'text') || findControlAfterLabel('Adı Soyadı', 'text') || findControlAfterLabel('Mükellef', 'text');
      const vals = [ad, soyad, unvan].filter(Boolean).map(getValue).filter(Boolean);
      if (vals.length >= 1) return true;

      if (Date.now() - lastNudge > 1200) {
        attempt += 1;
        await nudgeIdentityLookup(identityEl, attempt);
        lastNudge = Date.now();
      }
      await sleep(200);
    }
    return false;
  }

  function controlCenter(el) {
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2, r };
  }
  function clickHard(el) {
    if (!el) return false;
    el.scrollIntoView({ block: 'center', inline: 'center' });
    const {x,y} = controlCenter(el);
    for (const ev of ['pointerover','pointerenter','mouseover','mousemove','pointerdown','mousedown','pointerup','mouseup','click']) {
      try {
        const E = ev.startsWith('pointer') ? PointerEvent : MouseEvent;
        el.dispatchEvent(new E(ev, { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0, view:window }));
      } catch (_) { try { el.dispatchEvent(new MouseEvent(ev.replace('pointer','mouse'), { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0, view:window })); } catch(e) {} }
    }
    try { el.click && el.click(); } catch(_) {}
    return true;
  }
  function findEmanetTuruControl() {
    const label = findLabelNode('Emanet Türü') || findLabelNode('Emanet Turu');
    const controls = allCandidates('any').filter(c => c.tagName !== 'INPUT' || String(c.type || '').toLowerCase() !== 'hidden');
    if (!label) return findControlAfterLabel('Emanet Türü', 'combo') || findControlAfterLabel('Emanet Turu', 'combo');
    const lr = label.getBoundingClientRect();
    // Bu ekranda emanet türü alanı etiketin sağında, uzun yatay sarı kutu. En geniş ve aynı hizada olanı seç.
    let best = null, bestScore = Infinity;
    for (const c of controls) {
      const r = c.getBoundingClientRect();
      if (r.width < 80 || r.height < 12) continue;
      const cy = r.top + r.height/2, ly = lr.top + lr.height/2;
      const vgap = Math.abs(cy - ly);
      const right = r.left > lr.right - 30;
      const below = r.top > lr.top - 15 && r.top < lr.top + 90;
      if (!right || !below || vgap > 70) continue;
      const yellowPenalty = (getComputedStyle(c).backgroundColor || '').includes('255') ? 0 : 20;
      const score = vgap * 20 - Math.min(r.width, 700) + yellowPenalty;
      if (score < bestScore) { best = c; bestScore = score; }
    }
    return best || findControlAfterLabel('Emanet Türü', 'combo') || findControlAfterLabel('Emanet Turu', 'combo');
  }
  function findDropdownArrowNear(el) {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    const candidates = [...document.querySelectorAll('img, div, span, button, input')].filter(visible).filter(x => !x.closest('#' + PANEL_ID));
    let best = null, bestScore = Infinity;
    for (const c of candidates) {
      if (c === el) continue;
      const cr = c.getBoundingClientRect();
      const nearRight = Math.abs((cr.left + cr.width/2) - r.right) < 45 || (cr.left >= r.right - 35 && cr.left <= r.right + 20);
      const sameY = Math.abs((cr.top + cr.height/2) - (r.top + r.height/2)) < 25;
      if (!nearRight || !sameY) continue;
      const cls = String(c.className || '').toLowerCase();
      const score = Math.abs(cr.left - r.right) + Math.abs((cr.top+cr.height/2)-(r.top+r.height/2))*5 + (cls.includes('trigger') || cls.includes('arrow') ? -80 : 0);
      if (score < bestScore) { best = c; bestScore = score; }
    }
    return best;
  }
  async function chooseEmanetTuru(wanted = '39 Diğer Çeşitli Emanetler') {
    const el = findEmanetTuruControl();
    if (!el) throw new Error('Emanet Türü alanı bulunamadı.');
    const current = norm(getValue(el));
    const wantedNorm = norm(wanted);
    const wantedCode = (String(wanted).match(/^\s*(\d+)/) || [,''])[1];
    const matchesWanted = (v) => { const nv = norm(v); return !!((wantedCode && nv.includes(wantedCode)) || nv.includes(wantedNorm) || wantedNorm.includes(nv)); };
    if (matchesWanted(current)) { log('Emanet Türü zaten seçili: ' + wanted); return; }

    // Native select ise option text/value üzerinden net seç.
    if (el.tagName === 'SELECT') {
      const opts = [...el.options];
      const opt = opts.find(o => matchesWanted(o.textContent || o.value));
      if (!opt) throw new Error('Emanet Türü listesindeki seçenek bulunamadı: ' + wanted);
      el.selectedIndex = opts.indexOf(opt);
      el.value = opt.value;
      ['mousedown','mouseup','click','input','change','keyup','blur'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles:true, cancelable:true })));
      await sleep(300);
      log('Emanet Türü seçildi: ' + wanted)
      return;
    }

    // Ext/özel combo: kutuya odaklan, sağ ok/trigger varsa tıkla, sonra metin/koordinat/klavye denemeleri.
    el.scrollIntoView({ block:'center', inline:'center' });
    el.focus(); clickHard(el);
    const arrow = findDropdownArrowNear(el);
    if (arrow) clickHard(arrow);
    // Bazı combolarda sağ uçtan tıklamak listeyi açar.
    const r = el.getBoundingClientRect();
    await realMouseClickAt(Math.max(r.left + 5, r.right - 12), r.top + r.height/2);
    await sleep(250);

    let clicked = await clickDropdownOptionStrict(wanted);
    if (!clicked && wantedCode) clicked = await clickDropdownOptionStrict(wantedCode);
    if (!clicked && wantedNorm.includes('diger cesitli')) clicked = await clickDropdownOptionStrict('Diğer Çeşitli Emanetler');
    if (!clicked && wantedNorm.includes('kisi')) clicked = await clickDropdownOptionStrict('Kişilere Ait Diğer Emanetler');
    if (!clicked && wantedNorm.includes('teminat')) clicked = await clickDropdownOptionStrict('Vergi Teminatları');
    if (!clicked) {
      // Açık listede option görünmüyorsa doğrudan metin girip ENTER/TAB gönder.
      try {
        el.focus();
        try { el.select && el.select(); } catch(_) {}
        const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        if (setter) setter.call(el, wanted); else el.value = wanted;
        ['input','change'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles:true })));
      } catch (_) { try { setNativeValue(el, wanted); } catch(__) {} }
      for (const key of ['ArrowDown','Enter','Tab']) {
        el.dispatchEvent(new KeyboardEvent('keydown', { bubbles:true, cancelable:true, key, code:key }));
        el.dispatchEvent(new KeyboardEvent('keyup', { bubbles:true, cancelable:true, key, code:key }));
        await sleep(150);
      }
    }
    await sleep(350);
    const now = norm(getValue(el));
    if (!matchesWanted(now)) {
      // Son kez label yöntemi ile dene.
      try { await selectByText('Emanet Türü', wanted); } catch(_) {}
      await sleep(300);
    }
    const finalVal = norm(getValue(el));
    if (!matchesWanted(finalVal)) {
      throw new Error('Emanet Türü seçilemedi: ' + wanted + '. Ekrandaki kutu değeri: ' + getValue(el));
    }
    log('Emanet Türü seçildi: ' + wanted);
  }

  async function triggerIdentityLookup(identityEl) {
    // EVDB bu ekranda TC/VKN yazıldıktan sonra alan focus kaybedince sorgu çalıştırıyor.
    // Sadece input/change yetmeyebiliyor; kullanıcı gibi boş/güvenli bir alana tıklatıyoruz.
    try {
      if (identityEl) {
        ['input','change','keyup','keydown'].forEach(ev => {
          try { identityEl.dispatchEvent(new Event(ev, { bubbles:true, cancelable:true })); } catch (_) {}
        });
        try { identityEl.blur && identityEl.blur(); } catch (_) {}
      }
    } catch (_) {}

    // 1) Önce Belge No kutusuna tıkla; bu kimlik alanından çıkışı tetikler ama henüz değer yazmaz.
    const belgeNo = findControlAfterLabel('Belge No', 'text');
    if (belgeNo) {
      try { clickHard(belgeNo); await sleep(250); } catch (_) {}
    }

    // 2) Sonra boş bir form alanına/etiket civarına tıkla. Bu manuel kullanımda yaptığın “boş alana tıklama” etkisini verir.
    try {
      const group = (findLabelNode('Emanet Bilgileri') || findLabelNode('Plaka No') || document.body);
      const r = (group.getBoundingClientRect && group.getBoundingClientRect()) || {left:80, top:220, width:100, height:30};
      await realMouseClickAt(Math.max(20, r.left + 20), Math.max(20, r.top + 20));
    } catch (_) {}

    // 3) Belge No alanına tekrar odaklanma/blur denemesi. Bazı EVDB alanları blur sonrası ajax çağırıyor.
    if (belgeNo) {
      try { belgeNo.focus(); await sleep(120); belgeNo.blur && belgeNo.blur(); } catch (_) {}
    }
    await sleep(350);
    log('TC/VKN sorgusu için boş alana tıklandı, otomatik bilgi bekleniyor.');
  }



  function findExactButtonText(text) {
    const target = norm(text);
    const nodes = [...document.querySelectorAll('button, input[type="button"], input[type="submit"], a, span, div, td')]
      .filter(visible)
      .filter(el => !el.closest('#' + PANEL_ID));
    let best = null, bestScore = Infinity;
    for (const el of nodes) {
      const raw = el.tagName === 'INPUT' ? el.value : (el.innerText || el.textContent || '');
      const t = norm(raw);
      if (!t) continue;
      if (t === target || t.includes(target)) {
        const r = el.getBoundingClientRect();
        // Uzun panel/kapsayıcı yerine gerçek buton veya kısa metin elemanını seç.
        const score = t.length + (el.tagName === 'BUTTON' || el.tagName === 'INPUT' ? -80 : 0) + (r.width > 260 ? 80 : 0) + (r.height > 45 ? 80 : 0);
        if (score < bestScore) { best = el; bestScore = score; }
      }
    }
    return best;
  }

  async function clickEmanetBilgileriniTemizleStrict(required = true) {
    const btn = findExactButtonText('Emanet Bilgilerini Temizle');
    if (!btn) {
      if (required) throw new Error('Emanet Bilgilerini Temizle butonu bulunamadı.');
      log('Uyarı: Emanet Bilgilerini Temizle butonu bulunamadı, temizleme adımı atlandı.');
      return false;
    }
    clickHard(btn);
    await sleep(450);
    log('Emanet Bilgilerini Temizle tıklandı. Yeni giriş için kısa bekleme yapıldı.');
    return true;
  }

  async function prepareForRowEntry() {
    // v2.7: Temizleme artık başarılı Emanet Ekle + Evet sonrasında hemen yapılır.
    // Yeni satıra başlamadan sadece ekranın hazır/temiz olduğunu doğrularız. Eğer form temiz
    // görünmezse waitForEntryFormReady kendi içinde üstteki "Emanet Bilgilerini Temizle" butonunu dener.
    await waitForEntryFormReady((state.current || 0) > 1 ? 7000 : 5000);
    log('Yeni kayıt için ekran hazır kontrolü tamamlandı; Belge Türü seçilecek.');
  }


  function topFormValues() {
    const fields = {
      vergi: findControlAfterLabel('Vergi Kimlik No', 'text') || findControlAfterLabel('Vergi No', 'text') || findControlAfterLabel('VKN', 'text'),
      tc: findControlAfterLabel('T.C.Kimlik No', 'text') || findControlAfterLabel('T.C. Kimlik No', 'text') || findControlAfterLabel('TC Kimlik No', 'text') || findControlAfterLabel('T.C Kimlik No', 'text'),
      belge: findControlAfterLabel('Belge No', 'text'),
      tutar: findControlAfterLabel('Tutar', 'text'),
      ad: findControlAfterLabel('Ad', 'text'),
      soyad: findControlAfterLabel('Soyad', 'text')
    };
    const vals = {};
    for (const [k, el] of Object.entries(fields)) vals[k] = getValue(el);
    return { fields, vals };
  }

  function isTopFormEmptyEnough() {
    const { vals } = topFormValues();
    // Belge türü sabit kalabilir; emanet türü bazen kalabilir. Yeni satır için kritik olan kimlik/ad/belge/tutar alanları boş olmalı.
    return !vals.vergi && !vals.tc && !vals.ad && !vals.soyad && !vals.belge && (!vals.tutar || vals.tutar === '0,00' || vals.tutar === '0.00');
  }

  async function waitForEntryFormReady(timeoutMs = 9000) {
    // Emanet Ekle sonrası EVDB üst formu bir sonraki boş tıklamada/arka planda temizleyebiliyor.
    // Temizlenme bitmeden ikinci TC/VKN yazılırsa sistem o bilgiyi silebiliyor. Bu yüzden yeni satıra başlamadan bekliyoruz.
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (isTopFormEmptyEnough()) return true;
      await sleep(300);
    }
    // Hala doluysa güvenli temizleme butonunu dene; bu fonksiyon sadece yeni satıra başlamadan çağrılıyor.
    try {
      const clicked = await clickEmanetBilgileriniTemizleStrict(false);
      if (clicked) {
        log('Yeni satır öncesi sadece Emanet Bilgilerini Temizle tıklandı, alanların boşalması bekleniyor.');
        await sleep(1000);
      }
    } catch (_) {}
    const start2 = Date.now();
    while (Date.now() - start2 < 5000) {
      if (isTopFormEmptyEnough()) return true;
      await sleep(300);
    }
    // İşlemi tamamen durdurmayalım; bazen tutar alanı 0,00 veya maske değeri nedeniyle dolu görünebilir.
    log('Uyarı: üst form tam boş görünmedi; yine de yeni satır yazılmaya çalışılacak.');
    return false;
  }

  function validateRow(row) {
    const missing = [];
    if (!row.vergiNo && !row.tcNo) missing.push('Vergi No/T.C. No');
    if (!row.belgeNo) missing.push('Belge No');
    if (!row.tutar) missing.push('Tutar');
    if (!row.tarih) missing.push('Tarih');
    return missing;
  }
  function hasNoIdentity(row) {
    return !!(row && !row.vergiNo && !row.tcNo);
  }
  function noteSkippedNoIdentity(row) {
    if (!state.skippedNoIdentity) state.skippedNoIdentity = [];
    if (!state.skippedNoIdentity.some(x => x.excelRow === row.excelRow)) {
      state.skippedNoIdentity.push({ excelRow: row.excelRow, fisNo: row.fisNo || '', belgeNo: row.belgeNo || '', tutar: row.tutar || '' });
    }
    updateCounters(state.total, state.preparedRows.length);
  }
  function noteInvalidIdentity(row, message) {
    if (!state.invalidIdentity) state.invalidIdentity = [];
    const kind = row && row.vergiNo ? 'Vergi No hatalı' : (row && row.tcNo ? 'T.C. No hatalı' : 'Kimlik hatalı');
    if (!state.invalidIdentity.some(x => x.excelRow === row.excelRow)) {
      state.invalidIdentity.push({ excelRow: row.excelRow, fisNo: row.fisNo || '', belgeNo: row.belgeNo || '', tutar: row.tutar || '', kind, message: message || '' });
    }
    updateCounters(state.total, state.preparedRows.length);
  }
  function noteIdentityLookupFailed(row, message) {
    if (!state.identityLookupFailed) state.identityLookupFailed = [];
    const kind = row && row.vergiNo ? 'Vergi No sorgu sonuçsuz' : (row && row.tcNo ? 'T.C. No sorgu sonuçsuz' : 'Kimlik sorgu sonuçsuz');
    if (!state.identityLookupFailed.some(x => x.excelRow === row.excelRow)) {
      state.identityLookupFailed.push({ excelRow: row.excelRow, fisNo: row.fisNo || '', belgeNo: row.belgeNo || '', tutar: row.tutar || '', kind, message: message || '' });
    }
    updateCounters(state.total, state.preparedRows.length);
  }
  function noteDuplicateExisting(row, message) {
    if (!state.duplicateExisting) state.duplicateExisting = [];
    if (!state.duplicateExisting.some(x => x.excelRow === row.excelRow)) {
      state.duplicateExisting.push({ excelRow: row.excelRow, fisNo: row.fisNo || '', belgeNo: row.belgeNo || '', tutar: row.tutar || '', message: message || '' });
    }
    updateCounters(state.total, state.preparedRows.length);
  }
  async function enterIdentityForRow(row) {
    let identityEl = null;
    if (row.vergiNo) {
      const tc = findControlAfterLabel('T.C. Kimlik No') || findControlAfterLabel('TC Kimlik No') || findControlAfterLabel('T.C.Kimlik No');
      if (tc) setNativeValue(tc, '');
      identityEl = await typeValueAny(['Vergi Kimlik No', 'Vergi No', 'VKN'], row.vergiNo);
    } else {
      const vn = findControlAfterLabel('Vergi Kimlik No') || findControlAfterLabel('Vergi No') || findControlAfterLabel('VKN');
      if (vn) setNativeValue(vn, '');
      identityEl = await typeValueAny(['T.C.Kimlik No', 'T.C. Kimlik No', 'TC Kimlik No', 'T.C Kimlik No'], row.tcNo);
    }
    await triggerIdentityLookup(identityEl);
    return identityEl;
  }

  async function waitIdentityOrRetrySameRow(row, identityEl) {
    log('Ad/Soyad/Unvan dolması bekleniyor...');
    let ok = await waitForIdentityFilledWithNudges(identityEl, 16000, row);
    if (ok) return true;

    log(`Ad/Soyad/Unvan gelmedi. Excel satır ${row.excelRow} (${row.fisNo || 'Fiş No yok'}) için Emanet Bilgilerini Temizle yapılıp aynı satır bir kez daha denenecek.`);
    try { await clickEmanetBilgileriniTemizleStrict(false); } catch (_) {}
    await waitForEntryFormReady(8000);
    await sleep(Math.max(state.options.delay || 450, 650));
    await selectByText('Belge Türü', state.options.belgeTuru || 'Diğer');
    identityEl = await enterIdentityForRow(row);
    log('Ad/Soyad/Unvan dolması tekrar bekleniyor...');
    ok = await waitForIdentityFilledWithNudges(identityEl, 18000, row);
    if (ok) return true;

    const err = new Error('Ad/Soyad/Unvan otomatik dolmadı. Emanet Bilgilerini Temizle sonrası aynı satır tekrar denendi ama bilgi gelmedi.');
    err.skipIdentityLookupFailed = true;
    throw err;
  }

  async function processRow(row) {
    log(`Satır ${row.excelRow} başlıyor: ${row.vergiNo || row.tcNo} / ${row.tutar} / ${row.belgeNo} / ${row.emanetTuru || ''}${row.plakaNo ? ' / Plaka: ' + row.plakaNo : ''}`);
    await prepareForRowEntry();
    const missing = validateRow(row);
    if (missing.length) throw new Error('Eksik alan: ' + missing.join(', '));
    await selectByText('Belge Türü', state.options.belgeTuru || 'Diğer');
    let identityEl = await enterIdentityForRow(row);
    await waitIdentityOrRetrySameRow(row, identityEl);
    if (row.plakaNo) {
      await typeValueAny(['Plaka No', 'Plaka'], row.plakaNo);
    }
    await typeValue('Belge No', row.belgeNo);
    await typeValue('Tutar', row.tutar);
    await typeValue('Düzenleme Tarihi', row.tarih);
    await typeValue('Zaman Aşımı Başlangıç Tarihi', row.tarih);
    await chooseEmanetTuru(row.emanetTuru || state.options.emanetTuru || '39 Diğer Çeşitli Emanetler');
    await clickButton('Emanet Ekle');
    await throwEmanetteMevcutIfPopup(row);
    await clickYesIfExists(row);
    // v2.7: Manuel doğru akışa göre kayıt alta eklendikten sonra biraz bekle,
    // üstteki "Emanet Bilgilerini Temizle" butonuna bas, ekran temizlenince sıradaki kayda geç.
    await sleep(Math.max(state.options.delay || 450, 650));
    await clickEmanetBilgileriniTemizleStrict(false);
    await waitForEntryFormReady(8000);
    log(`Satır ${row.excelRow} eklendi; Emanet Bilgilerini Temizle yapıldı ve ekran temizlenince sıradaki kayda geçilecek.`);
    return { row: row.excelRow, status: 'Eklendi' };
  }
  async function runRows(rows, options) {
    if (state.running) return log('Zaten çalışıyor.');
    if (!rows.length) return setStatus('İşlenecek kayıt yok. Önce dosyayı oku.');
    injectConfirmOverride();
    state.running = true; state.paused = false; state.stopped = false; state.current = 0; state.total = rows.length; state.options = options || {}; state.results = []; state.skippedNoIdentity = []; state.invalidIdentity = []; state.duplicateExisting = []; state.identityLookupFailed = [];
    updateButtons(); updateCounters(state.total, rows.length);
    setStatus(`Aktarım başladı. Kayıt sayısı: ${rows.length}.`);
    for (let i=0; i<rows.length; i++) {
      while (state.paused && !state.stopped) await sleep(300);
      if (state.stopped) break;
      state.current = i + 1; updateCounters(state.total, rows.length);
      try {
        if (hasNoIdentity(rows[i])) {
          noteSkippedNoIdentity(rows[i]);
          const fisTxt = rows[i].fisNo ? `Fiş No: ${rows[i].fisNo}` : `Excel satır: ${rows[i].excelRow}`;
          log(`Atlandı - Vergi No/T.C. No boş. ${fisTxt}`);
          state.results.push({ row: rows[i].excelRow, status: 'Atlandı - Vergi No/T.C. No boş', fisNo: rows[i].fisNo || '' });
          continue;
        }
        if (state.options.resumeProgress && isRowCompleted(rows[i])) {
          log(`Excel satır ${rows[i].excelRow} daha önce başarılı, atlandı.`);
          state.results.push({ row: rows[i].excelRow, status: 'Atlandı - hafızada başarılı' });
          continue;
        }
        const res = await processRow(rows[i]);
        state.results.push(res);
        if (res && res.status === 'Eklendi') markRowCompleted(rows[i]);
      }
      catch (e) {
        const emsgNorm = norm(e && e.message || '');
        if (e && (e.skipDuplicateExisting || emsgNorm.includes('emanet tablosunda var') || emsgNorm.includes('tekrar ekleyemezsiniz') || emsgNorm.includes('tekrar eklenemez'))) {
          noteDuplicateExisting(rows[i], e.message);
          const fisTxt = rows[i]?.fisNo ? `Fiş No: ${rows[i].fisNo}` : `Excel satır: ${rows[i]?.excelRow}`;
          log(`Atlandı - Emanette mevcut / tekrar kayıt. ${fisTxt}`);
          state.results.push({ row: rows[i]?.excelRow, status: 'Atlandı - Emanette mevcut / tekrar kayıt', fisNo: rows[i]?.fisNo || '', message: e.message });
          continue;
        }
        if (e && (e.skipInvalidIdentity || emsgNorm.includes('mukellef bulunamadi'))) {
          noteInvalidIdentity(rows[i], e.message);
          const kind = rows[i]?.vergiNo ? 'Vergi No hatalı' : (rows[i]?.tcNo ? 'T.C. No hatalı' : 'Kimlik hatalı');
          const fisTxt = rows[i]?.fisNo ? `Fiş No: ${rows[i].fisNo}` : `Excel satır: ${rows[i]?.excelRow}`;
          log(`Atlandı - ${kind}. ${fisTxt}`);
          state.results.push({ row: rows[i]?.excelRow, status: `Atlandı - ${kind}`, fisNo: rows[i]?.fisNo || '', message: e.message });
          continue;
        }
        if (e && e.skipIdentityLookupFailed) {
          noteIdentityLookupFailed(rows[i], e.message);
          const kind = rows[i]?.vergiNo ? 'Vergi No sorgu sonuçsuz' : (rows[i]?.tcNo ? 'T.C. No sorgu sonuçsuz' : 'Kimlik sorgu sonuçsuz');
          const fisTxt = rows[i]?.fisNo ? `Fiş No: ${rows[i].fisNo}` : `Excel satır: ${rows[i]?.excelRow}`;
          log(`Atlandı - ${kind} / Ad-Soyad gelmedi. ${fisTxt}`);
          state.results.push({ row: rows[i]?.excelRow, status: `Atlandı - ${kind} / Ad-Soyad gelmedi`, fisNo: rows[i]?.fisNo || '', message: e.message });
          try { await clickEmanetBilgileriniTemizleStrict(false); await waitForEntryFormReady(5000); } catch (_) {}
          continue;
        }
        log(`HATA - Excel satır ${rows[i]?.excelRow}: ${e.message}`);
        state.results.push({ row: rows[i]?.excelRow, status: 'Hata', message: e.message });
        if (state.options.stopOnError) break;
      }
    }
    state.running = false; updateButtons();
    if (!state.stopped && !state.options.noAutoSave) {
      try { await clickButton('Kaydet'); log('Kaydet butonuna basıldı.'); } catch (e) { log('Kaydet basılamadı: ' + e.message); }
    }
    const skipped = state.skippedNoIdentity || [];
    if (skipped.length) {
      log(`Atlanan boş kimlik kayıt sayısı: ${skipped.length}. Fiş No: ${skipped.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ')}`);
    }
    const invalid = state.invalidIdentity || [];
    if (invalid.length) {
      log(`Mükellef bulunamadı / hatalı kimlik kayıt sayısı: ${invalid.length}. Fiş No: ${invalid.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ')}`);
    }
    const lookupFailed = state.identityLookupFailed || [];
    if (lookupFailed.length) {
      log(`Ad/Soyad gelmeyen / sorgu sonuçsuz kayıt sayısı: ${lookupFailed.length}. Fiş No: ${lookupFailed.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ')}`);
    }
    const existing = state.duplicateExisting || [];
    if (existing.length) {
      log(`Emanette mevcut / tekrar kayıt sayısı: ${existing.length}. Fiş No: ${existing.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ')}`);
    }
    const nongiris = state.skippedNonGiris || [];
    if (nongiris.length) {
      log(`İşlem Yönü Çıkış/Aktarım olduğu için emanet girişine işlenmeyen kayıt sayısı: ${nongiris.length}. Fiş No: ${nongiris.map(x => x.fisNo || ('Satır ' + x.excelRow)).join(', ')}`);
    }
    setStatus('İşlem bitti. Sonuçlar log ekranında.');
    log('Sonuçlar: ' + JSON.stringify(state.results));
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      if (message.type === 'EVDB_EMANET_TOGGLE_PANEL') {
        const existing = $(PANEL_ID);
        if (!existing) {
          ensurePanel(true);
        } else {
          existing.style.display = existing.style.display === 'none' ? 'block' : 'none';
        }
        sendResponse({ ok:true });
      } else if (message.type === 'EVDB_EMANET_START') {
        state.preparedRows = message.rows || state.preparedRows;
        runRows(state.preparedRows, message.options || getOptions());
        sendResponse({ ok:true });
      } else if (message.type === 'EVDB_EMANET_PAUSE') { state.paused = true; updateButtons(); sendResponse({ ok:true }); }
      else if (message.type === 'EVDB_EMANET_RESUME') { state.paused = false; updateButtons(); sendResponse({ ok:true }); }
      else if (message.type === 'EVDB_EMANET_STOP') { state.stopped = true; state.running = false; updateButtons(); sendResponse({ ok:true }); }
    } catch (e) { sendResponse({ ok:false, error:e.message }); }
    return true;
  });

  // v2.9: Ad/Soyad gelmezse Emanet Bilgilerini Temizle yapılıp aynı satır bir kez daha denenir; yine gelmezse Fiş No ile atlanır. v2.7 temizle sonrası sıradaki akış korunur.
  // İçerik scripti hazır bekler; böylece EVDB'nin diğer ekranlarında gereksiz pencere görünmez.
})();
