# v4.31.86

- Adi Ortaklık İşe Başlama özel akışında PDF, Önizle sütunundaki gibi popup olarak açılır.
- Popup adres satırındaki gerçek `/keyss/flexpaper/pdf/?token=...&fileID=...pdf` linki yakalanıp okuma adaylarına eklenir.
- Popup içinden metin okunabiliyorsa doğrudan kullanılır.
- Popup okunamazsa aynı gerçek linkten gelen PDF cevabı Blob/ArrayBuffer olarak okunur, sonra iframe ve manuel/kopyala-yapıştır yedekleri denenir.
- Kullanıcı/memur TCKN’sini ortak sanmama filtresi korunur.
