# Sürüm Notu v4.31.82

- Adi Ortaklık İşe Başlama önizleme PDF metin okuması güçlendirildi.
- PDF içindeki ToUnicode/CMap karakter haritası okunarak 10/11 haneli ortak kimliklerinin yakalanması iyileştirildi.
- PDF metni alınıp tablo ayıklanamazsa kopyala-yapıştır yedeği tekrar devreye alınır.
- Oturum/kullanıcı numarasının ortak sanılmasını engelleyen v4.31.81 filtresi korunur.
