# Sürüm Notu v4.31.83

- Adi ortaklık PDF metni kolon kolon/bozuk sırayla geldiğinde ortaklar tablosundan kimlik ayıklama güçlendirildi.
- Ortaklar yalnız T.C./Vergi Kimlik + Hisse/Onay tablosu çevresinden alınır.
- Başvuran, kayıt eden, memur/oturum TCKN ve telefon numaraları ortak sayılmaz.
- PDF metni alınmış ama tablo satırları ayıklanamamış durumdaki hata azaltıldı.
