# v4.31.84

- Adi Ortaklık İşe Başlama PDF okumasında PDF streamleri TextDecoder ile bozulmadan byte olarak ayrıştırıldı.
- FlateDecode streamleri için `deflate` ve `deflate-raw` yedekleri eklendi.
- PDF içindeki sıkıştırılmış metin katmanından Ortaklara İlişkin Bilgiler tablosunu okuma güçlendirildi.
- Ortak olmayan kullanıcı/memur/başvuran numaralarını dışarıda tutan filtre korunur.
