# v4.31.85

- Adi ortaklık önizleme PDF okumasında gelen PDF cevabının ham/Flate stream içeriği daha doğrudan çözülür.
- ToUnicode CMap haritası varsa Tj/TJ dışındaki hex kod koşuları da metne çevrilir.
- Ortaklar tablosu PDF cevabının içinde sıkıştırılmış/kolon sıralı geldiğinde ortak VKN/TCKN yakalama ihtimali artırıldı.
- Kullanıcı/memur TCKN'sini ortak sanmama filtresi korunur.
