# Sürüm Notu v4.31.81

- Adi Ortaklık İşe Başlama PDF okumasında ortak kimlik ayıklama sıkılaştırıldı.
- Oturum kullanıcısı / memur TCKN / başvuran-kayıt eden bilgisi ortak listesine karışmaz.
- Ortaklar yalnızca “Ortaklara İlişkin Bilgiler” tablosundaki satırlardan ve hisse/onay bilgisiyle birlikte okunur.
- Telefon numaraları ve PDF üst sağ köşedeki başvuran bilgileri ortak sayılmaz.
