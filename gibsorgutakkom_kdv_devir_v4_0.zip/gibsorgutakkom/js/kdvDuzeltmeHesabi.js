(function(global){
  'use strict';

  var MAX_MONTHS = 60;

  function numberValue(value){
    if(value === null || value === undefined || value === '') return 0;
    if(typeof value === 'number') return isFinite(value) ? value : 0;
    var text=String(value).trim(), negative=false;
    if(!text || text==='-' || /^HATA$/i.test(text) || /^NaN$/i.test(text)) return 0;
    if(/^\(.*\)$/.test(text)){ negative=true; text=text.slice(1,-1); }
    text=text.replace(/\s/g,'').replace(/[^0-9,\.\-]/g,'');
    if(text.charAt(0)==='-'){ negative=true; text=text.slice(1); }
    var comma=text.lastIndexOf(','), dot=text.lastIndexOf('.');
    if(comma>=0 && dot>=0) text=comma>dot ? text.replace(/\./g,'').replace(',','.') : text.replace(/,/g,'');
    else if(comma>=0){ var cp=text.split(','); text=cp.length===2 && cp[1].length<=2 ? text.replace(',','.') : text.replace(/,/g,''); }
    else if(dot>=0){ var dp=text.split('.'); if(dp.length>2 || (dp.length===2 && dp[1].length===3)) text=text.replace(/\./g,''); }
    var parsed=parseFloat(text); if(!isFinite(parsed)) return 0;
    return negative ? -parsed : parsed;
  }
  function nonNegative(value){ return Math.max(0,numberValue(value)); }
  function roundMoney(value){ return Math.round((numberValue(value)+1e-9)*100)/100; }
  function money(value){ return roundMoney(value).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
  function esc(value){ return String(value==null?'':value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function inputValue(value){ return numberValue(value) ? String(numberValue(value)).replace('.',',') : ''; }
  function differenceClass(value){ return numberValue(value)>0?'kdvh-increase':(numberValue(value)<0?'kdvh-decrease':''); }
  function defaultRateForPeriod(period){ return String(period||'')<'2023-07' ? 18 : 20; }
  function rateListForPeriod(period){ return String(period||'')<'2023-07' ? 'kdvhRatesOld' : 'kdvhRatesNew'; }
  function withholdingRatio(value){
    if(value===null || value===undefined || String(value).trim()==='') return 0;
    var text=String(value).trim().replace(/%/g,'').replace(/\s/g,'');
    if(text.indexOf('/')>=0){ var p=text.split('/'), n=numberValue(p[0]), d=numberValue(p[1]); return d>0 ? Math.max(0,Math.min(1,n/d)) : 0; }
    var n=numberValue(text); if(n>1) n=n/100; return Math.max(0,Math.min(1,n));
  }
  function withholdingDisplay(value){
    var ratio=withholdingRatio(value); if(!ratio) return '';
    var tenths=Math.round(ratio*10); if(Math.abs(ratio-tenths/10)<0.000001) return tenths+'/10';
    return String(roundMoney(ratio*100)).replace('.',',');
  }
  function adjustmentItems(adjustment,period,includeEmpty){
    adjustment=adjustment||{}; var items=[], raw=adjustment.items;
    if(Array.isArray(raw)){
      for(var i=0;i<raw.length;i++) items.push({base:roundMoney(nonNegative(raw[i]&&raw[i].base)),rate:nonNegative(raw[i]&&raw[i].rate),withholding:withholdingDisplay(raw[i]&&raw[i].withholding)});
    }else if(adjustment.base!==undefined || adjustment.rate!==undefined){
      items.push({base:roundMoney(nonNegative(adjustment.base)),rate:nonNegative(adjustment.rate)||defaultRateForPeriod(period),withholding:withholdingDisplay(adjustment.withholding)});
    }else{
      if(nonNegative(adjustment.base1)) items.push({base:roundMoney(nonNegative(adjustment.base1)),rate:1,withholding:''});
      if(nonNegative(adjustment.base10)) items.push({base:roundMoney(nonNegative(adjustment.base10)),rate:10,withholding:''});
      if(nonNegative(adjustment.base20)) items.push({base:roundMoney(nonNegative(adjustment.base20)),rate:20,withholding:''});
    }
    if(includeEmpty && !items.length) items.push({base:0,rate:defaultRateForPeriod(period),withholding:''});
    return items;
  }

  /* ============================================================
     v4.0 – Hesap mantığı
     - Düzeltilmiş zincir: bir ayın önceki dönem devri = önceki ayın DÜZELTİLMİŞ kapanış devri (Aralık→Ocak dahil).
       Beyan edilen açılış, önceki ayın beyan kapanışından farklıysa "devir kopukluğu" olarak gösterilir;
       kullanıcı "Beyan edilen açılışı kabul et" seçip açıklama girmedikçe fark otomatik uygulanmaz ve satır
       "Kontrol gerekiyor" olur.
     - Ret: türü "Cari dönem indirimi" ise bu döneme ait indirimden düşülür; cari indirimi aşan kısım UYGULANMAZ ve
       bildirilir (dönem dağılımı istenir). Türü "Geçmiş devir düzeltmesi" ise açılış devrinden düşülür.
     - Her satır bileşenlerden yeniden hesaplanır: Toplam KDV = Hes + İlave; Toplam indirim = Açılış + Bu dönem + Diğer;
       Ödenecek = max(0, TKDV − Tİ); iade öncesi devir = max(0, Tİ − TKDV); iade = min(beyan iade, devir);
       devir = iade öncesi devir − iade; tecil ayrıca gösterilir ve ödenecekten düşülür (not ile).
     - Tamamen sıfır satır = "Veri yok": hesap yapılmaz, zincir bozulmaz.
     ============================================================ */
  function isNoData(s){
    var keys=['declaredMatrah','declaredCalculatedVat','declaredAddedVat','declaredTotalVat','declaredPreviousCarry','declaredCurrentDeduction','declaredOtherDeduction','declaredTotalDeductible','declaredDeferredVat','declaredPayableVat','declaredRefundVat','declaredNextCarry'];
    for(var i=0;i<keys.length;i++) if(roundMoney(s[keys[i]])!==0) return false;
    return true;
  }
  function near(a,b){ return Math.abs(roundMoney(a)-roundMoney(b))<0.005; }

  function calculate(sourceRows,adjustments){
    var rows=(sourceRows||[]).slice(0,MAX_MONTHS), output=[];
    var prevDeclaredCarry=null, prevAdjCarry=null, prevPeriod=null;
    for(var i=0;i<rows.length;i++){
      var s=rows[i]||{}, adj=(adjustments&&adjustments[s.period])||{}, ctl=[], status='OK';
      var items=adjustmentItems(adj,s.period,false), additionalBase=0, additionalGrossVat=0, withheldVat=0, additionalVat=0;
      for(var j=0;j<items.length;j++){
        var g=roundMoney(items[j].base*items[j].rate/100), w=roundMoney(g*withholdingRatio(items[j].withholding));
        additionalBase=roundMoney(additionalBase+items[j].base); additionalGrossVat=roundMoney(additionalGrossVat+g); withheldVat=roundMoney(withheldVat+w); additionalVat=roundMoney(additionalVat+g-w);
      }
      var d={matrah:roundMoney(s.declaredMatrah),calc:roundMoney(s.declaredCalculatedVat),added:roundMoney(s.declaredAddedVat),totalVat:roundMoney(s.declaredTotalVat),prev:roundMoney(s.declaredPreviousCarry),cur:roundMoney(s.declaredCurrentDeduction),other:roundMoney(s.declaredOtherDeduction),totalDed:roundMoney(s.declaredTotalDeductible),deferred:roundMoney(s.declaredDeferredVat),payable:roundMoney(s.declaredPayableVat),refund:roundMoney(s.declaredRefundVat),next:roundMoney(s.declaredNextCarry)};
      var noData=isNoData(s);
      var red=roundMoney(nonNegative(adj.rejectedInputVat)), redType=adj.rejectedType==='carry'?'carry':'current', redNote=String(adj.rejectedNote||'').trim();
      var openMode=adj.openingMode==='declared'?'declared':'auto', openNote=String(adj.openingNote||'').trim();
      var row={period:s.period,noData:noData,declaredMatrah:d.matrah,declaredCalculatedVat:d.calc,declaredAddedVat:d.added,declaredTotalVat:d.totalVat,declaredPreviousCarry:d.prev,declaredCurrentDeduction:d.cur,declaredOtherDeduction:d.other,declaredTotalDeductible:d.totalDed,declaredDeferredVat:d.deferred,declaredPayableVat:d.payable,refundVat:d.refund,declaredNextCarry:d.next,
        additionalItems:items,additionalBase:additionalBase,additionalGrossVat:additionalGrossVat,withheldVat:withheldVat,additionalVat:additionalVat,rejectedInputVat:red,rejectedType:redType,rejectedNote:redNote,openingMode:openMode,openingNote:openNote,
        chainBreak:0,chainPrevClose:prevDeclaredCarry,rejectedApplied:0,rejectedUnapplied:0,controls:ctl};
      if(noData){
        row.status='Veri yok'; ctl.push('Beyanname verisi yok; hesap yapılmadı, devir zinciri korunarak sonraki aya taşındı.');
        if(red||additionalBase){ ctl.push('Veri olmayan aya girilen ilave matrah / ret dikkate alınmadı.'); }
        var z=['adjustedMatrah','adjustedCalculatedVat','adjustedAddedVat','adjustedTotalVat','adjustedPreviousCarry','adjustedCurrentDeduction','adjustedOtherDeduction','adjustedTotalDeductible','adjustedDeferredVat','adjustedPayable','payableDifference','adjustedRefundVat','refundDifference','adjustedCarry','carryDifference'];
        for(var zi=0;zi<z.length;zi++) row[z[zi]]=0;
        row.adjustedPreviousCarry=prevAdjCarry===null?0:prevAdjCarry; row.adjustedCarry=prevAdjCarry===null?0:prevAdjCarry; row.payableDifference=0;
        output.push(row); continue; /* zincir değişmez */
      }
      /* --- Beyan iç tutarlılık kontrolleri (kaynak veriye dokunulmaz) --- */
      if(!near(d.calc+d.added,d.totalVat)) ctl.push('Beyan: Toplam KDV ('+money(d.totalVat)+') ≠ Hesaplanan + İlave ('+money(d.calc+d.added)+').');
      if(!near(d.prev+d.cur+d.other,d.totalDed)) ctl.push('Beyan: Toplam indirim ('+money(d.totalDed)+') ≠ Önceki devir + Bu dönem + Diğer ('+money(d.prev+d.cur+d.other)+').');
      var bPay=Math.max(0,roundMoney(d.totalVat-d.totalDed)), bPre=Math.max(0,roundMoney(d.totalDed-d.totalVat)), bCarry=roundMoney(bPre-d.refund);
      if(!near(bCarry,d.next)) ctl.push('Beyan: devreden ('+money(d.next)+') bileşenlerden hesaplanan ('+money(bCarry)+') ile uyuşmuyor; iade/tecil işlemi veya veri hatası olabilir.');
      if(!near(Math.max(0,bPay-d.deferred),d.payable)) ctl.push('Beyan: ödenecek ('+money(d.payable)+') bileşenlerden hesaplanan ('+money(Math.max(0,bPay-d.deferred))+') ile uyuşmuyor.');
      /* --- Zincir: açılış devri --- */
      var adjPrev, chainBreak=0;
      if(prevAdjCarry===null){ adjPrev=d.prev; ctl.push('İlk dönem: açılış devri beyandan alındı ('+money(d.prev)+').'); }
      else{
        chainBreak=roundMoney(d.prev-prevDeclaredCarry); row.chainBreak=chainBreak;
        adjPrev=prevAdjCarry;
        if(Math.abs(chainBreak)>=0.005){
          var sign=chainBreak>0?'artış':'azalış';
          if(openMode==='declared'){
            adjPrev=roundMoney(prevAdjCarry+chainBreak);
            ctl.push('Devir farkı KABUL EDİLDİ: '+prevPeriod+' beyan kapanışı '+money(prevDeclaredCarry)+' → '+s.period+' beyan açılışı '+money(d.prev)+' (fark '+money(chainBreak)+' '+sign+'); açılışa eklendi.'+(openNote?' Dayanak: '+openNote:' AÇIKLAMA YOK → Kontrol gerekiyor.'));
            if(!openNote) status='Kontrol gerekiyor';
          }else{
            ctl.push('Devir kopukluğu: '+prevPeriod+' beyan kapanışı '+money(prevDeclaredCarry)+', '+s.period+' beyan açılışı '+money(d.prev)+', fark '+money(chainBreak)+' ('+sign+'). Fark uygulanmadı; önceki ayın düzeltilmiş kapanışı ('+money(prevAdjCarry)+') taşındı.'+(openNote?' Not: '+openNote:'')+' → Kontrol gerekiyor.');
            status='Kontrol gerekiyor';
          }
        }else if(openMode==='declared'){ ctl.push('Devir farkı yok; "beyan edilen açılış" seçimi etkisiz.'); }
        if(adjPrev<0){ ctl.push('Açılış devri negatife düştü ('+money(adjPrev)+'); 0 alındı.'); adjPrev=0; }
      }
      /* --- Ret --- */
      var adjCur=d.cur, applied=0, unapplied=0;
      if(red>0){
        if(redType==='current'){
          applied=Math.min(red,d.cur); unapplied=roundMoney(red-applied); adjCur=roundMoney(d.cur-applied);
          ctl.push('Ret (cari dönem indirimi): '+money(applied)+' bu döneme ait indirimden düşüldü.'+(redNote?' Dayanak: '+redNote:''));
          if(unapplied>0){ ctl.push('Ret cari indirimi ('+money(d.cur)+') aşıyor: '+money(unapplied)+' UYGULANMADI. Ret tutarının hangi dönemlere ait olduğunu ilgili ayların satırına girin veya "Geçmiş devir düzeltmesi" olarak tanımlayın. → Kontrol gerekiyor'); status='Kontrol gerekiyor'; }
        }else{
          applied=Math.min(red,adjPrev); unapplied=roundMoney(red-applied); adjPrev=roundMoney(adjPrev-applied);
          ctl.push('Ret (geçmiş devir düzeltmesi): '+money(applied)+' açılış devrinden düşüldü.'+(redNote?' Dayanak: '+redNote:' AÇIKLAMA YOK → Kontrol gerekiyor.'));
          if(!redNote) status='Kontrol gerekiyor';
          if(unapplied>0){ ctl.push('Açılış devri yetmedi: '+money(unapplied)+' UYGULANMADI. → Kontrol gerekiyor'); status='Kontrol gerekiyor'; }
          if(openMode==='declared'&&Math.abs(chainBreak)>=0.005&&near(Math.abs(chainBreak),red)) ctl.push('Dikkat: devir farkı ('+money(chainBreak)+') ile ret tutarı aynı. Açılış farkı kabul edilip ret de düşüldüğünde net etki sıfırdır; aynı düzeltmenin iki kez uygulanmadığından emin olun.');
          if(openMode!=='declared'&&Math.abs(chainBreak)>=0.005&&near(Math.abs(chainBreak),red)) ctl.push('Dikkat: devir farkı ile ret tutarı aynı; fark uygulanmadığı için ret ikinci kez düşülmüş olabilir. → Kontrol gerekiyor');
          if(openMode!=='declared'&&Math.abs(chainBreak)>=0.005&&near(Math.abs(chainBreak),red)) status='Kontrol gerekiyor';
        }
      }
      row.rejectedApplied=applied; row.rejectedUnapplied=unapplied;
      /* --- Düzeltilmiş hesap --- */
      var aMatrah=roundMoney(d.matrah+additionalBase), aCalc=roundMoney(d.calc+additionalVat), aAdded=d.added, aTK=roundMoney(aCalc+aAdded);
      var aOther=d.other, aTI=roundMoney(adjPrev+adjCur+aOther);
      var aPayGross=Math.max(0,roundMoney(aTK-aTI)), aPre=Math.max(0,roundMoney(aTI-aTK));
      var aRefund=Math.min(d.refund,aPre), aCarry=roundMoney(aPre-aRefund);
      var aDeferred=Math.min(d.deferred,aPayGross), aPay=roundMoney(aPayGross-aDeferred);
      if(d.deferred>0) ctl.push('Tecil edilecek KDV ('+money(d.deferred)+') ödenecekten ayrıca düşüldü (uygulanan '+money(aDeferred)+').');
      if(d.refund>0&&!near(aRefund,d.refund)) ctl.push('İade KDV beyan '+money(d.refund)+' → düzeltilmiş '+money(aRefund)+' (devir yetmedi).');
      if(d.refund>0&&near(bCarry,d.next)) ctl.push('İade beyanda devirden düşülmüş; ikinci kez düşülmedi.');
      row.adjustedMatrah=aMatrah; row.adjustedCalculatedVat=aCalc; row.adjustedAddedVat=aAdded; row.adjustedTotalVat=aTK;
      row.adjustedPreviousCarry=adjPrev; row.adjustedCurrentDeduction=adjCur; row.adjustedOtherDeduction=aOther; row.adjustedTotalDeductible=aTI;
      row.adjustedDeferredVat=aDeferred; row.adjustedPayable=aPay; row.payableDifference=roundMoney(aPay-d.payable);
      row.adjustedRefundVat=aRefund; row.refundDifference=roundMoney(aRefund-d.refund); row.adjustedCarry=aCarry; row.carryDifference=roundMoney(aCarry-d.next);
      if(!near(adjPrev+adjCur+aOther,aTI)) ctl.push('İÇ HATA: düzeltilmiş toplam indirim bileşenlerle uyuşmuyor.');
      if(row.payableDifference<0) ctl.push('Ödenecek KDV beyandan '+money(-row.payableDifference)+' AZALDI (otomatik iade/mahsup anlamına gelmez).');
      row.status=status;
      prevDeclaredCarry=d.next; prevAdjCarry=aCarry; prevPeriod=s.period;
      output.push(row);
    }
    return output;
  }

  function storageKey(vkn){ return 'takkom_kdv_devir_hesabi_v2_'+String(vkn||'').replace(/\D/g,''); }
  function loadAdjustments(vkn){ try{ var d=JSON.parse(localStorage.getItem(storageKey(vkn))||'{}'); return d&&d.adjustments?d.adjustments:{}; }catch(e){ return {}; } }
  function saveAdjustments(vkn,adjustments){ try{ localStorage.setItem(storageKey(vkn),JSON.stringify({version:4,vkn:String(vkn||'').replace(/\D/g,''),updatedAt:(new Date()).toISOString(),adjustments:adjustments})); }catch(e){} }
  function readAdjustments(panel){
    var data={};
    Array.prototype.forEach.call(panel.querySelectorAll('tr[data-kdvh-period]'),function(row){
      var items=[];
      Array.prototype.forEach.call(row.querySelectorAll('.kdvh-entry'),function(entry){
        var base=roundMoney(nonNegative(entry.querySelector('[data-kdvh-field="base"]').value));
        var rate=nonNegative(entry.querySelector('[data-kdvh-field="rate"]').value);
        var withholding=entry.querySelector('[data-kdvh-field="withholding"]');
        if(base) items.push({base:base,rate:rate,withholding:withholdingDisplay(withholding&&withholding.value)});
      });
      function v(n){ var el=row.querySelector('[data-kdvh-field="'+n+'"]'); return el?el.value:''; }
      data[row.getAttribute('data-kdvh-period')]={items:items,rejectedInputVat:roundMoney(nonNegative(v('rejectedInputVat'))),rejectedType:v('rejectedType')||'current',rejectedNote:String(v('rejectedNote')||'').trim(),openingMode:v('openingMode')||'auto',openingNote:String(v('openingNote')||'').trim()};
    });
    return data;
  }

  function entryHtml(period,item){
    item=item||{};
    return '<div class="kdvh-entry"><input class="kdvh-base" data-kdvh-field="base" inputmode="decimal" value="'+esc(inputValue(item.base))+'" placeholder="Matrah"><span class="kdvh-rate-sep">×</span><input class="kdvh-rate" data-kdvh-field="rate" inputmode="decimal" list="'+rateListForPeriod(period)+'" value="'+esc(inputValue(item.rate||defaultRateForPeriod(period)))+'" placeholder="KDV"><span>%</span><span class="kdvh-withholding-label">Tevkifat</span><input class="kdvh-withholding" data-kdvh-field="withholding" inputmode="decimal" list="kdvhWithholdingRates" value="'+esc(withholdingDisplay(item.withholding))+'" placeholder="Yok"><button type="button" class="kdvh-entry-remove" title="Satırı kaldır">−</button></div>';
  }

  var HEAD_GROUPS=[['Matrah',2],['Hesaplanan KDV',2],['İlave Edilecek KDV',2],['Toplam KDV',2],['Önceki Dönem Devri',2],['Bu Döneme Ait İndirim',2],['Diğer İndirimler',2],['Toplam İndirilecek KDV',2],['Tecil Edilecek KDV',2],['İade KDV',2],['Ödenecek KDV',3],['Devreden KDV',2]];
  var NUM_FIELDS=[['declaredMatrah','adjustedMatrah'],['declaredCalculatedVat','adjustedCalculatedVat'],['declaredAddedVat','adjustedAddedVat'],['declaredTotalVat','adjustedTotalVat'],['declaredPreviousCarry','adjustedPreviousCarry'],['declaredCurrentDeduction','adjustedCurrentDeduction'],['declaredOtherDeduction','adjustedOtherDeduction'],['declaredTotalDeductible','adjustedTotalDeductible'],['declaredDeferredVat','adjustedDeferredVat'],['refundVat','adjustedRefundVat'],['declaredPayableVat','adjustedPayable','payableDifference'],['declaredNextCarry','adjustedCarry']];
  function headerHtml(short){
    var h1='<tr><th rowspan="2">Dönem</th><th rowspan="2">İlave Matrah / KDV Oranı / Tevkifat</th><th rowspan="2">Reddedilen İndirim<br>(tutar · türü · dayanak)</th><th rowspan="2">Açılış Devri<br>(seçim · dayanak)</th>', h2='<tr>';
    for(var i=0;i<HEAD_GROUPS.length;i++){ h1+='<th colspan="'+HEAD_GROUPS[i][1]+'">'+HEAD_GROUPS[i][0]+'</th>'; h2+='<th>Beyan</th><th>'+(short?'Düz.':'Düzeltilmiş')+'</th>'+(HEAD_GROUPS[i][1]===3?'<th>Fark</th>':''); }
    h1+='<th rowspan="2">Durum</th><th rowspan="2">Kontrol / Açıklama</th></tr>';
    return h1+h2+'</tr>';
  }
  function numCells(row,cls){
    var h='';
    for(var i=0;i<NUM_FIELDS.length;i++){ var f=NUM_FIELDS[i];
      for(var k=0;k<f.length;k++){ var c=cls[k]||'', v=row[f[k]]; if(f[k]==='payableDifference') c+=' '+differenceClass(v); if(f[k]==='adjustedCurrentDeduction'&&row.rejectedUnapplied>0) c+=' kdvh-warn'; if(f[k]==='adjustedPreviousCarry'&&Math.abs(row.chainBreak)>=0.005) c+=' kdvh-chk';
        h+='<td class="'+c+'">'+(row.noData?'—':money(v))+'</td>'; }
    }
    return h;
  }
  function statusCell(row){ return '<td class="'+(row.status==='Veri yok'?'kdvh-nodata':(row.status==='OK'?'':'kdvh-chk'))+'">'+esc(row.status)+'</td>'; }

  function renderRows(panel,sourceRows,adjustments){
    var result=calculate(sourceRows,adjustments), body=panel.querySelector('#kdvhBody'), html='';
    panel.querySelector('#kdvhTable thead').innerHTML=headerHtml(true);
    var totals={base:0,grossVat:0,withheldVat:0,vat:0,rejected:0,applied:0,unapplied:0,refund:0,adjustedRefund:0,payableDifference:0,rates:{}}, issues=[];
    for(var i=0;i<result.length;i++){
      var row=result[i], input=adjustments[row.period]||{};
      var entries=adjustmentItems(input,row.period,true), entriesHtml='';
      for(var e=0;e<entries.length;e++) entriesHtml+=entryHtml(row.period,entries[e]);
      for(var t=0;t<row.additionalItems.length;t++){ var rk=String(row.additionalItems[t].rate).replace('.',','); totals.rates[rk]=roundMoney((totals.rates[rk]||0)+row.additionalItems[t].base); }
      totals.base+=row.additionalBase; totals.grossVat+=row.additionalGrossVat; totals.withheldVat+=row.withheldVat; totals.vat+=row.additionalVat; totals.rejected+=row.rejectedInputVat; totals.applied+=row.rejectedApplied; totals.unapplied+=row.rejectedUnapplied; totals.refund+=row.refundVat; totals.adjustedRefund+=row.adjustedRefundVat; totals.payableDifference+=row.payableDifference;
      if(row.status!=='OK'&&row.status!=='Veri yok') issues.push('<li><b>'+esc(row.period)+'</b>: '+row.controls.filter(function(c){return /Kontrol gerekiyor|UYGULANMADI|AÇIKLAMA YOK|Dikkat/.test(c);}).map(esc).join(' ')+'</li>');
      var ctlHtml=row.controls.length?'<ul style="margin:0;padding-left:14px">'+row.controls.map(function(c){return '<li>'+esc(c)+'</li>';}).join('')+'</ul>':'';
      var breakInfo=Math.abs(row.chainBreak)>=0.005?'<div style="font-size:10px;color:#7a5a00">fark '+money(row.chainBreak)+'</div>':'';
      html+='<tr data-kdvh-period="'+esc(row.period)+'"'+(row.noData?' class="kdvh-nodata"':'')+'><td class="kdvh-period">'+esc(row.period)+'</td>'+
        '<td class="kdvh-entry-cell">'+entriesHtml+'<button type="button" class="kdvh-entry-add" data-kdvh-add="1">+ Matrah / Oran Ekle</button></td>'+
        '<td><input data-kdvh-field="rejectedInputVat" inputmode="decimal" value="'+esc(inputValue(input.rejectedInputVat))+'" placeholder="0,00"><br><select data-kdvh-field="rejectedType"><option value="current"'+(input.rejectedType!=='carry'?' selected':'')+'>Cari dönem indirimi</option><option value="carry"'+(input.rejectedType==='carry'?' selected':'')+'>Geçmiş devir düzeltmesi</option></select><br><input class="kdvh-note" data-kdvh-field="rejectedNote" value="'+esc(input.rejectedNote||'')+'" placeholder="dayanak / açıklama"></td>'+
        '<td><select data-kdvh-field="openingMode"><option value="auto"'+(input.openingMode!=='declared'?' selected':'')+'>Önceki ayın düzeltilmiş kapanışı</option><option value="declared"'+(input.openingMode==='declared'?' selected':'')+'>Beyan edilen açılışı kabul et</option></select>'+breakInfo+'<input class="kdvh-note" data-kdvh-field="openingNote" value="'+esc(input.openingNote||'')+'" placeholder="fark nedeni / dayanak"></td>'+
        numCells(row,['kdvh-money','kdvh-money','kdvh-money'])+statusCell(row)+'<td class="kdvh-ctl">'+ctlHtml+'</td></tr>';
    }
    body.innerHTML=html;
    var rateSummary=[], rateKeys=Object.keys(totals.rates).sort(function(a,b){ return numberValue(a)-numberValue(b); });
    for(var k=0;k<rateKeys.length;k++) rateSummary.push('%'+rateKeys[k]+' matrah: <b>'+money(totals.rates[rateKeys[k]])+'</b>');
    var nData=result.filter(function(r){return !r.noData;}).length, nNo=result.length-nData;
    panel.querySelector('#kdvhSummary').innerHTML='<b>'+nData+' dönem hesaplandı'+(nNo?', '+nNo+' dönem veri yok':'')+'.</b> İlave matrah: <b>'+money(totals.base)+'</b>'+(rateSummary.length?' ('+rateSummary.join(' | ')+')':'')+' | Brüt ilave KDV: <b>'+money(totals.grossVat)+'</b> | Tevkif edilen: <b>'+money(totals.withheldVat)+'</b> | Beyan edilecek ilave KDV: <b>'+money(totals.vat)+'</b> | Reddedilen indirim: <b>'+money(totals.rejected)+'</b> (uygulanan <b>'+money(totals.applied)+'</b>'+(totals.unapplied>0.004?', <span class="kdvh-warn">uygulanmayan '+money(totals.unapplied)+'</span>':'')+') | Beyan iade: <b>'+money(totals.refund)+'</b> → düzeltilmiş iade: <b>'+money(totals.adjustedRefund)+'</b> | <b>Ödenecek KDV farkı toplamı: <span class="'+differenceClass(totals.payableDifference)+'">'+money(totals.payableDifference)+'</span></b>'+
      '<div style="margin-top:4px;color:#555">Kaynakta oran bazlı (%1 / %10 / %20 / tevkifat) matrah dağılımı bulunmadığından yalnız devir hesabı kontrol edilmiştir; hesaplanan KDV oran kontrolü yapılamaz.</div>';
    var box=panel.querySelector('#kdvhIssues');
    box.innerHTML=issues.length?'<b>Açıklama / kontrol bekleyen dönemler ('+issues.length+'):</b><ul>'+issues.join('')+'</ul><div>Bu dönemler çözülmeden "Ödenecek KDV farkı toplamı" kesin sonuç değil, senaryo sonucudur.</div>':'<b>Açıklama bekleyen dönem yok.</b> Sonuçlar açıklaması doğrulanmış kesin sonuçtur.';
    return result;
  }

  function additionalItemsText(row){
    var parts=[];
    for(var i=0;i<row.additionalItems.length;i++){
      if(row.additionalItems[i].base) parts.push(money(row.additionalItems[i].base)+' × %'+String(row.additionalItems[i].rate).replace('.',',')+(withholdingRatio(row.additionalItems[i].withholding)?' (Tevkifat '+withholdingDisplay(row.additionalItems[i].withholding)+')':''));
    }
    return parts.length ? parts.join(' | ') : '—';
  }
  function rejectedText(x){ if(!x.rejectedInputVat) return '—'; return money(x.rejectedInputVat)+' · '+(x.rejectedType==='carry'?'geçmiş devir düzeltmesi':'cari dönem indirimi')+(x.rejectedNote?' · '+x.rejectedNote:''); }
  function openingText(x){ var t=x.openingMode==='declared'?'Beyan edilen açılış kabul':'Önceki ayın düzeltilmiş kapanışı'; if(Math.abs(x.chainBreak)>=0.005) t+=' · fark '+money(x.chainBreak); if(x.openingNote) t+=' · '+x.openingNote; return t; }

  function buildPrintSheet(result,vkn){
    var old=document.getElementById('kdvhPrintSheet'); if(old&&old.parentNode) old.parentNode.removeChild(old);
    var groups={}, order=[];
    for(var i=0;i<result.length;i++){ var year=String(result[i].period).slice(0,4); if(!groups[year]){groups[year]=[];order.push(year);} groups[year].push(result[i]); }
    var html='';
    for(var g=0;g<order.length;g++){
      var y=order[g], rows=groups[y], body='';
      for(var r=0;r<rows.length;r++){ var x=rows[r];
        body+='<tr><td>'+esc(x.period)+'</td><td class="input">'+esc(additionalItemsText(x))+'</td><td class="input">'+esc(rejectedText(x))+'</td><td class="input">'+esc(openingText(x))+'</td>'+numCells(x,['num old','num new','num strong'])+'<td class="input">'+esc(x.status)+'</td><td class="input">'+esc(x.controls.join(' '))+'</td></tr>';
      }
      html+='<section class="kdvh-print-year"><div class="kdvh-print-title">Yıllık KDV Devir Hesabı</div><div class="kdvh-print-meta"><b>VKN/TCKN:</b> '+esc(vkn||'-')+' &nbsp; <b>Yıl:</b> '+esc(y)+'</div><table class="kdvh-print-table"><thead>'+headerHtml(false)+'</thead><tbody>'+body+'</tbody></table></section>';
    }
    var sheet=document.createElement('div'); sheet.id='kdvhPrintSheet'; sheet.innerHTML=html; document.body.appendChild(sheet);
  }

  function excelEsc(value){ return esc(value).replace(/\r?\n/g,'&#10;'); }
  function excelString(value,style,mergeAcross,mergeDown,index){
    return '<Cell'+(index?' ss:Index="'+index+'"':'')+' ss:StyleID="'+(style||'txt')+'"'+(mergeAcross?' ss:MergeAcross="'+mergeAcross+'"':'')+(mergeDown?' ss:MergeDown="'+mergeDown+'"':'')+'><Data ss:Type="String">'+excelEsc(value)+'</Data></Cell>';
  }
  function excelNumber(value,style){ return '<Cell ss:StyleID="'+(style||'num')+'"><Data ss:Type="Number">'+roundMoney(value)+'</Data></Cell>'; }

  function exportExcel(result,vkn,sourceRows){
    if(!result||!result.length){ global.alert('Excel’e aktarılacak dönem bulunamadı.'); return; }
    var groups={}, order=[];
    for(var i=0;i<result.length;i++){ var year=String(result[i].period).slice(0,4); if(!groups[year]){groups[year]=[];order.push(year);} groups[year].push(result[i]); }
    var NCOL=4+25+2; /* 4 metin + 25 sayı + durum + kontrol */
    var xml='<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>'+
      '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Styles><Style ss:ID="Default" ss:Name="Normal"><Font ss:FontName="Calibri" ss:Size="9"/><Alignment ss:Vertical="Center"/></Style><Style ss:ID="title"><Font ss:Bold="1" ss:Size="14"/><Alignment ss:Horizontal="Center"/></Style><Style ss:ID="meta"><Font ss:Bold="1"/></Style><Style ss:ID="hdr"><Font ss:Bold="1"/><Interior ss:Color="#E7E6E6" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders></Style><Style ss:ID="txt"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders></Style><Style ss:ID="num"><Alignment ss:Horizontal="Right" ss:Vertical="Center"/><NumberFormat ss:Format="#,##0.00"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders></Style><Style ss:ID="chk"><Interior ss:Color="#FFF3CD" ss:Pattern="Solid"/><Alignment ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders></Style></Styles>';
    for(var g=0;g<order.length;g++){
      var y=order[g], rows=groups[y];
      xml+='<Worksheet ss:Name="'+excelEsc(y)+'"><Table><Column ss:Width="60"/><Column ss:Width="190"/><Column ss:Width="150"/><Column ss:Width="150"/>';
      for(var c=0;c<25;c++)xml+='<Column ss:Width="82"/>'; xml+='<Column ss:Width="80"/><Column ss:Width="420"/>';
      xml+='<Row ss:Height="24">'+excelString('Yıllık KDV Devir Hesabı','title',NCOL-1,0)+'</Row><Row>'+excelString('VKN/TCKN: '+(vkn||'-')+'    Yıl: '+y+'    (Sabit rapor: hücreler formül değil hesaplanmış değerdir)','meta',NCOL-1,0)+'</Row>';
      var h1='<Row ss:Height="30">'+excelString('Dönem','hdr',0,1)+excelString('İlave Matrah / Oran / Tevkifat','hdr',0,1)+excelString('Reddedilen İndirim (tutar · tür · dayanak)','hdr',0,1)+excelString('Açılış devri (seçim · fark · dayanak)','hdr',0,1), h2='<Row>';
      for(var hg=0;hg<HEAD_GROUPS.length;hg++){ h1+=excelString(HEAD_GROUPS[hg][0],'hdr',HEAD_GROUPS[hg][1]-1,0); h2+=excelString('Beyan','hdr',0,0,hg===0?5:0)+excelString('Düzeltilmiş','hdr')+(HEAD_GROUPS[hg][1]===3?excelString('Fark','hdr'):''); }
      h1+=excelString('Durum','hdr',0,1)+excelString('Kontrol / Açıklama','hdr',0,1)+'</Row>'; h2+='</Row>';
      xml+=h1+h2;
      for(var r=0;r<rows.length;r++){ var x=rows[r];
        xml+='<Row>'+excelString(x.period,'txt')+excelString(additionalItemsText(x),'txt')+excelString(rejectedText(x),'txt')+excelString(openingText(x),'txt');
        for(var nf=0;nf<NUM_FIELDS.length;nf++) for(var nk=0;nk<NUM_FIELDS[nf].length;nk++) xml+=excelNumber(x[NUM_FIELDS[nf][nk]]);
        xml+=excelString(x.status,x.status==='OK'?'txt':'chk')+excelString(x.controls.join('\n'),'txt')+'</Row>';
      }
      xml+='</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>4</SplitHorizontal><TopRowBottomPane>4</TopRowBottomPane>'+(g===0?'<Selected/>':'')+'</WorksheetOptions></Worksheet>';
    }
    /* Kontrol sayfası */
    xml+='<Worksheet ss:Name="Kontroller"><Table><Column ss:Width="60"/><Column ss:Width="90"/><Column ss:Width="90"/><Column ss:Width="90"/><Column ss:Width="90"/><Column ss:Width="100"/><Column ss:Width="520"/>';
    xml+='<Row ss:Height="24">'+excelString('Kontroller ve Açıklama Bekleyen Noktalar','title',6,0)+'</Row>';
    xml+='<Row ss:Height="30">'+['Dönem','Önceki ay beyan kapanışı','Beyan açılışı','Fark','Ret (uygulanan)','Durum','Kontrol / Açıklama'].map(function(h){return excelString(h,'hdr');}).join('')+'</Row>';
    for(var ri=0;ri<result.length;ri++){ var q=result[ri];
      xml+='<Row>'+excelString(q.period,'txt')+(q.chainPrevClose===null?excelString('—','txt'):excelNumber(q.chainPrevClose))+excelNumber(q.declaredPreviousCarry)+excelNumber(q.chainBreak)+excelNumber(q.rejectedApplied)+excelString(q.status,q.status==='OK'?'txt':'chk')+excelString(q.controls.join('\n'),'txt')+'</Row>'; }
    xml+='</Table></Worksheet>';
    /* KDV beyan verileri (ham beyan tablosu) */
    if(sourceRows&&sourceRows.length){
      var bh=['Dönem','Matrah','Hesaplanan KDV','İlave Edilecek KDV','Toplam KDV','Önceki Dönem Devri','Bu Döneme Ait İndirim','Diğer İndirimler','Toplam İndirilecek KDV','Tecil Edilecek KDV','Ödenecek KDV','İade Edilecek KDV','Sonraki Döneme Devreden KDV'];
      xml+='<Worksheet ss:Name="KDV Beyanları"><Table><Column ss:Width="60"/>';for(var c2=0;c2<12;c2++)xml+='<Column ss:Width="95"/>';
      xml+='<Row ss:Height="24">'+excelString('KDV Beyan Verileri','title',12,0)+'</Row><Row>'+excelString('VKN/TCKN: '+(vkn||'-'),'meta',12,0)+'</Row>';
      xml+='<Row ss:Height="30">'+bh.map(function(h){return excelString(h,'hdr');}).join('')+'</Row>';
      for(var r2=0;r2<sourceRows.length;r2++){var q2=sourceRows[r2];
        if(isNoData(q2)){ xml+='<Row>'+excelString(q2.period,'txt')+excelString('Veri yok','chk',11,0)+'</Row>'; continue; }
        xml+='<Row>'+excelString(q2.period,'txt')+excelNumber(q2.declaredMatrah)+excelNumber(q2.declaredCalculatedVat)+excelNumber(q2.declaredAddedVat)+excelNumber(q2.declaredTotalVat)+excelNumber(q2.declaredPreviousCarry)+excelNumber(q2.declaredCurrentDeduction)+excelNumber(q2.declaredOtherDeduction)+excelNumber(q2.declaredTotalDeductible)+excelNumber(q2.declaredDeferredVat)+excelNumber(q2.declaredPayableVat)+excelNumber(q2.declaredRefundVat)+excelNumber(q2.declaredNextCarry)+'</Row>';}
      xml+='</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>3</SplitHorizontal><TopRowBottomPane>3</TopRowBottomPane></WorksheetOptions></Worksheet>';}
    xml+='</Workbook>';
    var blob=new Blob([xml],{type:'application/vnd.ms-excel;charset=utf-8'}), url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download='Yillik_KDV_Devir_Hesabi_'+(vkn||'mukellef')+'.xls'; document.body.appendChild(a); a.click(); document.body.removeChild(a); setTimeout(function(){URL.revokeObjectURL(url);},1500);
  }

  function ensureStyle(){
    if(document.getElementById('kdvhStyle')) return;
    var style=document.createElement('style'); style.id='kdvhStyle';
    style.textContent='.kdvh-warn{background:#ffd8d8;color:#a00;font-weight:bold}.kdvh-chk{background:#fff3cd;color:#7a5a00;font-weight:bold}.kdvh-nodata{color:#888;font-style:italic;background:#f4f4f4}.kdvh-ctl{font-size:10px;white-space:normal!important;max-width:260px;color:#7a5a00}#kdvhTable select{padding:3px;font-size:11px}#kdvhTable input.kdvh-note{width:150px;text-align:left}#kdvhIssues{margin-top:6px;font-size:12px;background:#fff;border:1px solid #d59d00;padding:6px}#kdvhIssues li{margin:2px 0}#kdvhPrintSheet{display:none}#kdvhPanel{margin:16px 0;padding:12px;border:2px solid #1769aa;background:#eef7ff}#kdvhPanel h2{margin:0 0 6px;color:#0d4775}.kdvh-note{font-size:12px;margin-bottom:8px}.kdvh-actions{margin:8px 0}#kdvhPanel button{border:0;padding:8px 13px;margin-right:6px;cursor:pointer;color:#fff;background:#1769aa}#kdvhPanel button.kdvh-clear{background:#6c757d}#kdvhPanel button.kdvh-print{background:#28783e}#kdvhWrap{overflow:auto;max-height:72vh;border:1px solid #99b8d0;background:#fff}#kdvhTable{border-collapse:collapse;min-width:3200px;margin:0;padding:0}#kdvhTable th{position:sticky;top:0;z-index:2;background:#1769aa;color:#fff;font-size:11px}#kdvhTable td{font-size:11px;white-space:nowrap}#kdvhTable input{width:92px;padding:4px;border:1px solid #d59d00;background:#fff5bf;text-align:right}.kdvh-entry{display:flex;align-items:center;gap:3px;margin:2px 0}.kdvh-entry .kdvh-base{width:88px}.kdvh-entry .kdvh-rate{width:45px}.kdvh-entry .kdvh-withholding{width:62px}.kdvh-withholding-label{margin-left:5px}.kdvh-entry-remove{padding:2px 6px!important;margin:0!important;background:#a94442!important}.kdvh-entry-add{padding:3px 7px!important;margin-top:3px!important;font-size:10px}.kdvh-money{text-align:right}.kdvh-period{font-weight:bold}.kdvh-increase{background:#ffd9d9;color:#a00000;font-weight:bold}.kdvh-decrease{background:#e4f7e8;color:#176b2c;font-weight:bold}#kdvhSummary{margin-top:8px;padding:7px;background:#fff;border:1px solid #99b8d0;font-size:12px}@page{size:A4 landscape;margin:5mm}@media print{body.kdvh-print-mode>*:not(#kdvhPrintSheet){display:none!important}body.kdvh-print-mode{margin:0!important;background:#fff;color:#111}body.kdvh-print-mode #kdvhPrintSheet{display:block!important}.kdvh-print-year{break-after:page;page-break-after:always}.kdvh-print-year:last-child{break-after:auto;page-break-after:auto}.kdvh-print-title{text-align:center;font-size:12pt;font-weight:bold;margin:0 0 1mm}.kdvh-print-meta{font-size:8pt;margin-bottom:1.2mm}.kdvh-print-table{width:100%;border-collapse:collapse;table-layout:fixed;font-family:Arial,sans-serif;font-size:7pt;line-height:1.08;font-variant-numeric:tabular-nums}.kdvh-print-results{margin-top:3mm}.kdvh-print-period-col{width:7%}.kdvh-print-input-col{width:18%}.kdvh-print-main .kdvh-print-number-col{width:7.5%}.kdvh-print-results .kdvh-print-result-col{width:8.455%}.kdvh-print-table th,.kdvh-print-table td{border:0.2mm solid #555;padding:0.65mm 0.35mm;vertical-align:middle}.kdvh-print-table th{background:#d9eaf7!important;color:#111;text-align:center;font-weight:bold;white-space:normal}.kdvh-print-table td.num{text-align:right;white-space:nowrap}.kdvh-print-table td.strong{font-weight:bold}.kdvh-print-table td.old{background:#f5f5f5!important}.kdvh-print-table td.new{background:#eef8ff!important}.kdvh-print-summary{font-size:6.5pt;line-height:1.15;margin-top:1.2mm;padding:1mm;border:0.2mm solid #555;background:#eef7ff!important}}';
    style.textContent+='#kdvhPanel button.kdvh-excel{background:#1f6f43}@media print{.kdvh-print-table{font-size:4.2pt!important;line-height:1.04!important;break-inside:avoid!important;page-break-inside:avoid!important}.kdvh-print-period-col{width:4%!important}.kdvh-print-input-col{width:12%!important}.kdvh-print-rejected-col{width:5%!important}.kdvh-print-number-col{width:4.158%!important}.kdvh-print-table th,.kdvh-print-table td{padding:.45mm .16mm!important;overflow:hidden!important}.kdvh-print-table td.input{font-size:3.8pt!important;white-space:normal!important;overflow-wrap:anywhere!important}.kdvh-print-table td.num{white-space:nowrap!important}.kdvh-print-title{font-size:10pt!important}.kdvh-print-meta{font-size:6.5pt!important}.kdvh-print-summary{font-size:5.5pt!important}}';
    document.head.appendChild(style);
  }

  function init(options){
    options=options||{}; var sourceRows=(options.sourceRows||[]).slice(0,MAX_MONTHS); if(!sourceRows.length) return;
    ensureStyle(); var vkn=String(options.vkn||'').replace(/\D/g,''), old=document.getElementById('kdvhPanel'); if(old&&old.parentNode) old.parentNode.removeChild(old);
    var panel=document.createElement('div'); panel.id='kdvhPanel';
    panel.innerHTML='<h2>Yıllık KDV Devir Hesabı</h2><div class="kdvh-note">KDV beyan verileri otomatik alınmıştır; beyan sütunları değiştirilmez, düzeltilmiş sütunlar bileşenlerden yeniden hesaplanır. Düzeltilmiş zincirde her ayın açılış devri bir önceki ayın <b>düzeltilmiş kapanışıdır</b> (Aralık→Ocak dahil). Beyan edilen açılış önceki ayın beyan kapanışından farklıysa fark otomatik uygulanmaz; "Beyan edilen açılışı kabul et" seçilip dayanak yazılmalıdır, aksi halde satır "Kontrol gerekiyor" olur. Reddedilen indirim "Cari dönem indirimi" ise bu döneme ait indirimden düşülür (cari indirimi aşan kısım uygulanmaz ve bildirilir); "Geçmiş devir düzeltmesi" ise açılış devrinden düşülür. İlave matrah için oran ve isteğe bağlı tevkifat (5/10, 7/10, 9/10 veya 50, 70, 90) girin. En fazla 5 yıl (60 dönem).</div><div class="kdvh-actions"><button type="button" id="kdvhCalculate">Hesapla ve Devret</button><button type="button" class="kdvh-clear" id="kdvhClear">Girdileri Temizle</button><button type="button" class="kdvh-print" id="kdvhPrint">Çıktı Al</button><button type="button" class="kdvh-excel" id="kdvhExcel">Excel\'e Aktar</button></div><datalist id="kdvhRatesOld"><option value="1"><option value="8"><option value="18"></datalist><datalist id="kdvhRatesNew"><option value="1"><option value="10"><option value="20"></datalist><datalist id="kdvhWithholdingRates"><option value="2/10"><option value="3/10"><option value="4/10"><option value="5/10"><option value="7/10"><option value="9/10"></datalist><div id="kdvhWrap"><table id="kdvhTable"><thead></thead><tbody id="kdvhBody"></tbody></table></div><div id="kdvhSummary"></div><div id="kdvhIssues"></div>';
    var anchor=options.anchor||document.body; anchor.appendChild(panel);
    var adjustments=loadAdjustments(vkn); renderRows(panel,sourceRows,adjustments);
    panel.querySelector('#kdvhCalculate').onclick=function(){ adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments); renderRows(panel,sourceRows,adjustments); };
    panel.querySelector('#kdvhClear').onclick=function(){ if(!global.confirm('Bu mükellef için girilen ilave matrah, indirim reddi ve devir açıklamaları temizlensin mi?')) return; adjustments={}; saveAdjustments(vkn,adjustments); renderRows(panel,sourceRows,adjustments); };
    panel.onclick=function(event){
      var add=event.target.closest&&event.target.closest('[data-kdvh-add]');
      if(add){ var row=add.closest('tr[data-kdvh-period]'); add.insertAdjacentHTML('beforebegin',entryHtml(row.getAttribute('data-kdvh-period'),{})); return; }
      var remove=event.target.closest&&event.target.closest('.kdvh-entry-remove');
      if(remove){ var entry=remove.closest('.kdvh-entry'), cell=entry.parentNode; if(cell.querySelectorAll('.kdvh-entry').length>1) entry.parentNode.removeChild(entry); else{ entry.querySelector('[data-kdvh-field="base"]').value=''; } }
    };
    panel.querySelector('#kdvhPrint').onclick=function(){
      adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments);
      var result=renderRows(panel,sourceRows,adjustments); buildPrintSheet(result,vkn);
      document.body.classList.add('kdvh-print-mode');
      function cleanup(){ document.body.classList.remove('kdvh-print-mode'); global.removeEventListener('afterprint',cleanup); }
      global.addEventListener('afterprint',cleanup); global.print(); setTimeout(cleanup,10000);
    };
    panel.querySelector('#kdvhExcel').onclick=function(){ adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments); exportExcel(renderRows(panel,sourceRows,adjustments),vkn,sourceRows); };
  }

  global.KdvDuzeltmeHesabi={version:'4.0.0',maxMonths:MAX_MONTHS,calculate:calculate,init:init,numberValue:numberValue,roundMoney:roundMoney,defaultRateForPeriod:defaultRateForPeriod,withholdingRatio:withholdingRatio};
})(typeof window!=='undefined'?window:this);
