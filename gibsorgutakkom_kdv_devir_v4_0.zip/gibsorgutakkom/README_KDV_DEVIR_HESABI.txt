YILLIK KDV DEVİR HESABI

Normal “Yıllık KDV-BS-POS” ekranı değiştirilmemiştir. Yeni hesaplama ayrı bir sayfadadır.

1. Ana ekranda “Yıllık KDV Devir Hesabı” düğmesine basın.
2. Hesabın başlayacağı yılı girin. Program başlangıç yılından itibaren en fazla 5 yılı getirir.
3. KDV beyan verileri otomatik çekilir.
4. Düzeltme bulunan aylarda yalnızca ilgili sarı alanları doldurun:
   - İlave Matrah
   - İlave matrahın yanındaki KDV Oranı
   - Reddedilen İndirim KDV
5. “Hesapla ve Devret” düğmesine basın.

Aynı ayda birden fazla ilave matrah ve oran girilebilir. “+ Matrah / Oran Ekle” düğmesi yeni satır açar. KDV oranı serbestçe değiştirilebilir. Program 2023/06 ve önceki dönemler için %18, 2023/07 ve sonraki dönemler için %20 oranını başlangıç değeri olarak getirir; eski dönemlerde %1/%8/%18, yeni dönemlerde %1/%10/%20 seçeneklerini de önerir.

Tevkifatlı işlem varsa aynı satırdaki “Tevkifat” alanına 5/10, 7/10, 9/10 gibi kesir veya 50, 70, 90 gibi yüzde yazılabilir. Boş bırakılırsa tevkifat uygulanmaz. Program brüt hesaplanan KDV’den tevkif edilen kısmı ayırır ve satıcının beyan edeceği ilave KDV’yi düzeltme hesabına ekler.

“Çıktı Al” düğmesi önce mevcut girişleri hesaplar. Çıktıda her yıl ayrı bir yatay A4 sayfasında ve tek tabloda gösterilir. Normal beyan ve düzeltilmiş tutarlar yan yana sütunlardadır; ödenecek ve devreden KDV farkları ayrıca gösterilir. Boş matrah giriş alanları çıktıya basılmaz.
Çıktıda Hesaplanan KDV hücrelerinde yalnızca beyan ve düzeltilmiş tutarlar yer alır; okunabilirliği azaltan alt “Toplam KDV” satırı bulunmaz.
Matrah takdirinden hesaplanan yeni vergi, yıllık KDV cevabındaki ayrı “İlave Edilecek KDV” alanına eklenir. Hesaplanan KDV alanı değiştirilmez; Toplam KDV, Hesaplanan KDV ile İlave Edilecek KDV toplamına göre güncellenir. Karşılaştırma ekranı beyan tablosundaki sırayı izler ve Önceki Dönem Devri de beyan/düzeltilmiş olarak gösterilir.

Matrah takdirinden doğan KDV, Hesaplanan KDV'nin düzeltilmiş tutarına eklenir. İlave Edilecek KDV alanı matrah takdiri nedeniyle değiştirilmez.

Çıktıda her yıl aynı A4 yatay sayfada iki geniş tablo halinde gösterilir: üst tabloda Önceki Dönem Devri'ne kadar olan alanlar, alt tabloda Toplam İndirim ve sonrasındaki sonuç alanları bulunur.

İade KDV de “Beyan / Düzeltilmiş / Fark” sütunlarında karşılaştırılır. İlave KDV veya reddedilen indirim nedeniyle kullanılabilir alacak bakiyesi azalırsa düzeltilmiş iade KDV azalabilir ya da sıfırlanabilir. Düzeltme, devreden ve iade bakiyelerinin toplamını da aşarsa kalan kısım ödenecek farkına dönüşür.

Reddedilen indirim toplam indirilecek KDV’den düşülür. Düzeltilmiş devreden KDV bir sonraki aya aktarılır. Beyannamedeki iade edilmesi gereken KDV de korunur; indirim bakiyesi hem toplam KDV’yi hem iadeyi karşılamazsa eksik kalan kısım düzeltilmiş ödenecek KDV’ye ve ödenecek farkına dahil edilir.

Girilen düzeltmeler mükellef VKN’sine göre tarayıcıda saklanır. “Girdileri Temizle” yalnızca bu mükellefe ait ilave matrah ve indirim reddi girişlerini siler.

İlave matrah ve reddedilen indirim girilmemişse beyan ödenecek/devreden sonuçları aynen korunur; iki fark sütunu da 0,00 olur. Bir ayın beyan edilen önceki devri ile önceki ayın sonraki devri farklı olsa bile bu beyan farklılığı düzeltme olarak ileri taşınmaz.

v3.8.0 (12.10.2026) – "Bu Döneme Ait İndirim" sütunu (Beyan / Düzeltilmiş) ekrana, çıktıya ve Excel'e eklendi.
  Düzeltilmiş = beyan − reddedilen indirim. Reddedilen tutar o ayın bu döneme ait indirilecek KDV'sini aşıyorsa hücre
  kırmızı ⚠ ile işaretlenir ve özet satırında uyarı verilir (ret birden çok aya aitse her ay kendi satırına girilmeli).
  Toplam indirilecek / devreden / ödenecek hesabı değişmedi (ret toplam indirimden düşülüyordu; şimdi hangi kalemden
  düştüğü de görünüyor).
v3.9.0 – Excel: başlıklar açık gri (mavi dolgu kaldırıldı); "KDV Beyanları" adlı ek sayfada ham beyan tablosu
  (Dönem, Matrah, Hesaplanan, İlave, Toplam KDV, Önceki Devir, Bu Dönem İndirimi, Diğer İndirimler, Toplam İndirilecek,
  Tecil, Ödenecek, İade, Devreden) da aktarılır.

v4.0.0 (12.10.2026) – Hesap mantığı yeniden kuruldu (js/kdvDuzeltmeHesabi.js)
- Düzeltilmiş sütunlar her ay bileşenlerden yeniden hesaplanır: Toplam KDV = Hesaplanan + İlave; Toplam indirim =
  Açılış devri + Bu dönem indirimi + Diğer indirimler; Ödenecek = max(0, TKDV − Tİ); iade öncesi devir = max(0, Tİ − TKDV);
  iade = min(beyan iade, devir); devreden = devir − iade; tecil ayrıca gösterilir ve ödenecekten düşülür (notla).
- Düzeltilmiş zincir: açılış devri = önceki ayın düzeltilmiş kapanışı (Aralık→Ocak dahil). Beyan açılışı ≠ önceki ay
  beyan kapanışı ise "devir kopukluğu": önceki kapanış, beyan açılışı, fark gösterilir; fark otomatik uygulanmaz,
  satır "Kontrol gerekiyor". "Beyan edilen açılışı kabul et" + dayanak girilirse fark uygulanır ve kaydedilir.
- Ret: "Cari dönem indirimi" → bu dönem indiriminden düşülür, cari indirimi aşan kısım UYGULANMAZ ve bildirilir
  (dönem dağılımı istenir); "Geçmiş devir düzeltmesi" → açılış devrinden düşülür (dayanak istenir). Aynı tutarlı
  devir farkı + ret birlikteyse çift uygulama uyarısı.
- Beyan iç kontrolleri: TKDV bileşenleri, Tİ bileşenleri, devreden/ödenecek bileşenlerle uyum; eksik dönem ("Veri yok",
  zincir korunur); fark sütunu = düzeltilmiş − beyan (negatif azalış gizlenmez).
- Ekran: Diğer İndirimler ve Tecil sütunları, Durum ve Kontrol/Açıklama sütunu, "Açıklama bekleyen dönemler" kutusu.
- Excel: yıl sayfaları + "Kontroller" sayfası + "KDV Beyanları" sayfası; sabit rapor (formül yok), başlıkta belirtilir.
- Oran bazlı dağılım kaynakta olmadığından yalnız devir hesabı kontrol edildiği belirtilir.
Doğrulama (VKN 5110019444): Ocak 2024 açılış kabul + ret devir düzeltmesi, Eylül varsayılan → Eyl 0, Eki 0,
  Kas 15.018,35, Ara 101.317,23 (fark 23.135,81), toplam fark 38.154,16; Eylül açılışı da kabul edilirse 153.655,53.
