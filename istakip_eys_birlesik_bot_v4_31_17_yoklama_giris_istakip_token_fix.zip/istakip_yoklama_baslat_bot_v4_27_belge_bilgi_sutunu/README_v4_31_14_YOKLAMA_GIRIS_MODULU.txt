v4.31.14 Yoklama Giriş Modülü

Taban:
- v4.31.13 çalışan panel tabanı kullanıldı.
- content.js panel yapısına dokunulmadı.
- EYS içine yeni “Yoklama Giriş” sekmesi eklendi.

Eklenen sekme:
- VKN/TCKN sorgulama
- Sicil bilgisi alma
- Terk bilgisi ön kontrolü
- Merkez faaliyet konusu alma
- MERNİS adres no ile adres bilgisi alma
- İşe Başlama yoklaması için srvcYoklama_saveYoklama çağrısı
- Kaydedilen yKodu için Müdür Onayına Gönder çağrısı

Açılır menü seçenekleri:
- Servis listesi mevcut servis listesinden gelir.
- Yoklama türleri görsel/README’ye göre listeye eklendi.
- İşyeri türü: Merkez, Şube, Depo, Mesken, Diğer.
- Mülkiyet: Kendi Mülkü, Kiralık, Bedelsiz Kiralık, Diğer.
- Kira ödeme şekli: Elden, Banka Hesabına, Diğer.
- Kira ödeme dönemi: Aylık, Yıllık, Diğer.
- İşletme/Şirket türü ve mükellef grubu listeye eklendi.

Önemli:
- Doğrudan SİSTEME KAYDET işlemi bu sürümde yalnız README’de kesin payload örneği bulunan “İşe Başlama” için aktiftir.
- Diğer yoklama türleri seçilebilir görünür; doğrudan kaydetme için her türün örnek payload’ı gerekir.
