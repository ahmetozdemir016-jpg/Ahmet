v4.31.12 — README 2 Akış Tek Tek Gönderim

TABAN:
- Bu sürüm, çalışan panel dosyası v4.31.3 temiz tabanı üzerinden hazırlandı.
- content.js panel yapısına dokunulmadı.
- Ana Modül / EYS Modülü panel görünümü değiştirilmedi.

README 2(1).md dosyasına göre eklenenler:
1. Memur → Müdür gönderimi artık yKodu listesi toplu gönderim yerine tek tek yapılır.
   Her istek:
   cmd: srvcYoklama_submitYoklamalarToMudur
   jp: { ykodlari: ["TEK_YKODU"], sessionData: { rol: "10", ... } }

2. Müdür → Koordinatör gönderimi artık yKodu listesi toplu gönderim yerine tek tek yapılır.
   Her istek:
   cmd: srvcYoklama_submitYoklamalarToKoor
   jp: { ykodlari: ["TEK_YKODU"], sessionData: { rol: "20", ... } }

3. Müdür aşamasında önce iade/geri dönen yoklamalar sorgulanır:
   cmd: srvcYoklama_getIadeler
   jp: { data: { koor:"", vd:"016253", vdkodu:"016253", icdis:"0" }, sessionData:{ rol:"20", ... } }

4. İade sorgusunda gelen yKodu'lar tekrar koordinatöre gönderilmez.

5. İşlem monitöründe her yKodu için gönderiliyor/tamam/hata bilgisi ayrı ayrı yazılır.
