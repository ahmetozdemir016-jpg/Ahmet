TARH DEFTERİ SORGULAMA (Rapor Alma – EVDB Raporları içinde)

Rapor seçimi: "Tarh Defteri Sorgulama (geçici / tebliğ edilmemiş / … ihbarnameler · aylık PDF → liste)".
Kaynak (HAR 06.10.2026): EVDB Rapor › Tarh İşlemleri Listeleri › Tarh Defteri Sorgulama
  GET evdorapor_server/pdf  serviceName=evdoLRTarhiyatServices_geciciIhbarnameFisiListesi, reportName=RP_EVDO_GECICI_IHBARNAME_LISTESI
  Parametreler: BASLANGIC_TARIHI/BITIS_TARIHI (YYYYAAGG), BASLANGIC_VNO/BITIS_VNO, BASTCKN/BITTCKN, VKNYEGORESORGULAMA,
  IHBARNAME_DURUMU (+_ACIKLAMA), VERGI_KODU, DAYANAK (+_ACIKLAMA), SIRALAMA (+_SEKLI), MUDURLUK, MUDURLUKSTR.
  İhbarname durumu kodları: 1 Geçici İhbarname, 2 Onaylanmış, 3 Uzlaşılmış,
  4 Tebliğ Edilmiş, 5 Tebliğ Edilmemiş, 6 Uzlaşılmamış, 7 Tebliğ Edilemedi.
  Dayanak: Hepsi veya kod (10 İnceleme Raporu … 21 VUK 353/3 Tutanak, 27 E-Yoklama); listede olmayan kod elle yazılabilir.

Rapor yalnız PDF (her ihbarname bir sayfa). Başlangıç ay/yıl – bitiş ay/yıl arasındaki her ay ayrı istenir, PDF pdf.js ile
sayfa sayfa okunur: İHBARNAME FİŞİ BİLGİLERİ (29 alan, iki sütun, kaydırılmış ünvan satırları birleştirilir),
İHBARNAME EKLERİ ve CEZALAR tabloları (başlıkların konumundan sütunlar bulunur; varsa VERGİLER tablosu da), Toplam Ceza Tutarı.
"Sütunlar ▾" ile ihbarname bilgileri, ek ve ceza sütunları ayrı ayrı seçilir (saklanır); birden çok ek/ceza alt alta yazılır.
Ayrıca Sorumlu (personel VKN aralıkları) ve Sorgu Ayı sütunları. Süzgeç: İhbarname Durumu, Sorumlu, serbest arama.
Excel (.xlsx: liste + parametreler) ve yatay yazdırma.
PDF baytları için TAKKOM PDF Okuyucu uzantısı v1.1 (10.251.63.99/evdorapor_server/pdf izinli) gerekebilir; EVDO rapor tokeni gerekir.
