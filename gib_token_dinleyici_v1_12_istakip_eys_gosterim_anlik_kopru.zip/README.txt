GİB Token Dinleyici v6

Bu uzantı komple ağ kaydı tutmaz. Sadece tokenleri ayıklar ve Chrome yerel hafızasına kaydeder.

Yakaladığı token türleri:
- GİB intranet: gib_token_gibintranet
- KEYS / GP: gib_token_keys
- EVDB Rapor: gib_token_evdbrapor
- İzaha Davet / SMİYB: gib_token_izah
- İsteğe bağlı: istakip / eys / ebeyan

Çalışma mantığı:
1) GİB/KEYS/EVDB/İzaha Davet sekmelerinde CSSession.getToken(...) ve token içeren istek/cevaplardan sadece tokeni ayıklar.
2) Token yakalanınca chrome.storage.local içinde saklar.
3) Dosya URL erişimi açıksa TAKKOM sayfası açıldığında yakalanan tokenleri localStorage'a köprüler.
4) Yanlış token karışmasın diye generic gibToken sadece GİB intranet tokeni ile doldurulur; izah/evdb/keys ayrı anahtarlarda tutulur.
5) Page hook 30 saniye sonra veya ana tokenler yakalanınca durur.

Kurulum:
Chrome > Uzantılar > Geliştirici modu > Paketlenmemiş yükle > bu klasörü seç.
Uzantı detayında Dosya URL'lerine erişime izin ver seçeneğini aç.


v1.12: Popup içine İş Takip ve EYS token durumları eklendi. Token cache değişiklikleri açık sayfalara anlık localStorage köprüsü ile yansıtılır.
