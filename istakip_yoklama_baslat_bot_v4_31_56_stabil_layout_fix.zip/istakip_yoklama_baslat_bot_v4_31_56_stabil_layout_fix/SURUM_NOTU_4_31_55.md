# v4.31.55

- Ana Modül panelinde butonların büyüyüp alanı kaplamasına neden olan genel layout aralıkları temizlendi.
- Log ve tablo alanı tekrar görünür/kompakt hale getirildi.
- Üst keşif/token detayları gizli kalırken VKN başlangıç/bitiş satırı korunur.
- Taşıma, kapatma, sol-alt resize ve tüm-token hook stop düzeltmeleri korunur.
