# v4.31.54

- Panelin yarım/bozuk görünmesine sebep olan yükseklik ve gövde kaydırma düzeni düzeltildi.
- Ana Modül üstündeki keşif/token detayları gizlendi; VKN aralığı ve işlem butonları kaldı.
- Kapatılan panelin kendi kendine tekrar açılmasına sebep olan ilk yükleme zorlaması kaldırıldı.
- Sol kenar, alt kenar ve sol-alt köşe resize davranışı korundu.
- Hook dinleme tüm tokenleri bekleme davranışı korundu.
