# v4.31.56

- Ana Modül ilk açılışta düzgün gelip birkaç saniye sonra alt kısmın siyah boşluğa dönmesi düzeltildi.
- Arka plandaki düzen sabitleme döngüsü artık gövdeyi flex-column olarak koruyor.
- İŞLERİ TARA / UYGUNLARI GÖNDER / LİSTEYİ YENİLE buton satırı 38px sabit kaldı.
- Log ve tablo alanı sabit şekilde görünür bırakıldı; tablo alt alanı kalan yüksekliği dolduruyor.
- Önceki hook tüm tokenleri yakalayınca durma, kapatma/taşıma/resize düzeltmeleri korundu.
