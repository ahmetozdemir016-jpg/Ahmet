(() => {
  'use strict';
  // v4.31.96 Yoklama Durum sütunu dengeli genişliğe alındı; Önizle sütunu ile birleşme düzeltildi.
  try {
    const __itHref = String(location.href || '').toLowerCase();
    const __itPath = String(location.pathname || '').toLowerCase();
    if (__itHref.includes('/flexpaper/pdf') || __itPath.includes('/flexpaper/pdf') || __itHref.includes('/edenetis/getsonuc') || __itPath.includes('/edenetis/getsonuc')) return;
  } catch (_) {}


  function fmtDateYYYYMMDD(d) {
    d = d || new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}${m}${day}`;
  }


  function eysTodayYYYYMMDD() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}${m}${day}`;
  }


  function eysOpenPdfPopup(url) {
    if (!url) return null;
    const fallback = () => {
      try { return isLikelyFrameBlockedEysUrl(url) ? openEysPdfPopupWindow(url, 'getSonuc') : window.open(url, '_blank'); }
      catch (_) { return null; }
    };
    try {
      const sw = window.screen && window.screen.availWidth ? window.screen.availWidth : 1366;
      const sh = window.screen && window.screen.availHeight ? window.screen.availHeight : 768;
      const sl = window.screen && Number.isFinite(window.screen.availLeft) ? window.screen.availLeft : 0;
      const st = window.screen && Number.isFinite(window.screen.availTop) ? window.screen.availTop : 0;
      const w = Math.min(980, Math.max(720, Math.floor(sw * 0.62)));
      const h = Math.min(900, Math.max(620, Math.floor(sh * 0.88)));
      const left = Math.max(0, Math.floor(sl + sw - w - 20));
      const top = Math.max(0, Math.floor(st + 40));
      const features = [
        'popup=yes',
        'noopener=no',
        'noreferrer=no',
        'resizable=yes',
        'scrollbars=yes',
        'toolbar=no',
        'menubar=no',
        'location=yes',
        'status=no',
        `width=${w}`,
        `height=${h}`,
        `left=${left}`,
        `top=${top}`
      ].join(',');
      const winName = `EYS_PDF_POPUP_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const win = window.open(url, winName, features);
      if (win) {
        try { win.focus(); } catch (_) {}
        return win;
      }
      return fallback();
    } catch (_) {
      return fallback();
    }
  }


  function eysLocalGet(key) {
    try {
      const raw = localStorage.getItem('eys_storage_' + key);
      return raw ? JSON.parse(raw) : null;
    } catch (_) { return null; }
  }

  function eysLocalSet(key, value) {
    try { localStorage.setItem('eys_storage_' + key, JSON.stringify(value)); } catch (_) {}
  }

  function eysLocalRemove(key) {
    try { localStorage.removeItem('eys_storage_' + key); } catch (_) {}
  }

  async function eysStorageGet(key) {
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return eysLocalGet(key);
      const data = await chrome.storage.local.get(key);
      return data ? data[key] : eysLocalGet(key);
    } catch (_) {
      return eysLocalGet(key);
    }
  }

  async function eysStorageSet(key, value) {
    eysLocalSet(key, value);
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return;
      await chrome.storage.local.set({ [key]: value });
    } catch (_) {}
  }

  async function eysStorageRemove(key) {
    eysLocalRemove(key);
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return;
      await chrome.storage.local.remove(key);
    } catch (_) {}
  }



  function setupEysPageSessionBridge() {
    if (window.__istakipEysSessionBridgeReady) return;
    window.__istakipEysSessionBridgeReady = true;

    window.__istakipEysPageSession = window.__istakipEysPageSession || {};

    window.addEventListener('message', (event) => {
      try {
        if (event.source !== window) return;
        const data = event.data || {};
        if (data.type === 'ISTAKIP_EYS_PAGE_SESSION') {
          if (data.payload && typeof data.payload === 'object') {
            window.__istakipEysPageSession = Object.assign({}, window.__istakipEysPageSession || {}, data.payload);
          }
          return;
        }
        // v4.31.50: HAR yedek sorgu tiki UI'dan kaldırıldı; filtreler birebir gönderilir.
        // v4.31.49: page_hook.js artık manifest üzerinden MAIN world'de çalışıyor.
        // Oradan gelen genel keşif mesajında pageSession varsa da oturum bilgisini al.
        if (data.type === '__ISTAKIP_BOT_V4_DISCOVERY__' && data.payload && data.payload.pageSession) {
          window.__istakipEysPageSession = Object.assign({}, window.__istakipEysPageSession || {}, data.payload.pageSession);
        }
      } catch (_) {}
    });

    const request = () => {
      try { window.postMessage({ type: '__ISTAKIP_EYS_SESSION_REQUEST__' }, '*'); } catch (_) {}
    };

    request();
    setTimeout(request, 500);
    setTimeout(request, 1500);
    setTimeout(request, 3500);
  }


  function setupEysDispatchCaptureBridge() {
    if (window.__istakipEysDispatchCaptureReady) return;
    window.__istakipEysDispatchCaptureReady = true;
    const EVT = '__ISTAKIP_BOT_V4_DISCOVERY__';
    window.__istakipEysCaptured = window.__istakipEysCaptured || { lastByCmd: {}, tokensByCmd: {} };

    window.addEventListener('message', (event) => {
      try {
        if (event.source !== window) return;
        const data = event.data || {};
        if (data.type !== EVT) return;
        const cmd = String(data.cmd || '');
        const source = String(data.source || '');
        const moduleName = String(data.moduleName || '');
        const payload = (data.payload && typeof data.payload === 'object') ? data.payload : {};
        const isEys = /edenetis|eyoklama/i.test(source) || moduleName === 'e' || /^srvc|^libEDenetis|Yoklama|RemoteCall/i.test(cmd);
        if (!isEys) return;
        const cap = window.__istakipEysCaptured = window.__istakipEysCaptured || { lastByCmd: {}, tokensByCmd: {} };
        cap.lastByCmd = cap.lastByCmd || {};
        cap.tokensByCmd = cap.tokensByCmd || {};
        if (data.token) {
          cap.eysToken = String(data.token || '').trim();
          if (cmd) cap.tokensByCmd[cmd] = cap.eysToken;
        }
        if (cmd) {
          cap.lastByCmd[cmd] = {
            token: String(data.token || cap.eysToken || '').trim(),
            payload,
            source,
            moduleName,
            at: Date.now()
          };
          if (cmd === 'srvcRemoteCall_getVdAdresleri') cap.lastVdAdresleri = cap.lastByCmd[cmd];
        }
      } catch (_) {}
    });

    // v4.31.49: CSP nedeniyle script etiketi ile enjeksiyon yapılmıyor.
    // page_hook.js manifestte world:"MAIN" content script olarak yüklendiği için
    // burada sadece köprü hazır bırakılıyor.
    try { window.postMessage({ type: '__ISTAKIP_EYS_SESSION_REQUEST__' }, '*'); } catch (_) {}
  }


  if (window.__eysTabbedBotLoaded) return;
  window.__eysTabbedBotLoaded = true;
  setupEysPageSessionBridge();
  setupEysDispatchCaptureBridge();

  function isPdfResultPage() {
    try {
      const u = new URL(window.location.href);
      return /\/edenetis\/getSonuc/i.test(u.pathname) && !!u.searchParams.get('yKodu');
    } catch (_) {
      return false;
    }
  }

  function showPdfPrintOverlay(msg) {
    try {
      const id = 'eys-pdf-print-overlay';
      let box = document.getElementById(id);
      if (!box) {
        box = document.createElement('div');
        box.id = id;
        box.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;background:#111827;color:#fff;padding:10px 12px;border:1px solid #334155;border-radius:8px;font:12px/1.4 sans-serif;box-shadow:0 10px 25px rgba(0,0,0,.35)';
        document.documentElement.appendChild(box);
      }
      box.textContent = msg;
    } catch (_) {}
  }

  function setupPdfAutoPrintPage() {
    if (!isPdfResultPage()) return false;
    try {
      const u = new URL(window.location.href);
      const auto = u.searchParams.get('eys_autoprint') === '1';
      if (!auto) return true;
      const delay = Math.max(800, Number(u.searchParams.get('eys_delay') || '1800') || 1800);
      const ykodu = u.searchParams.get('yKodu') || '';
      const closeAfter = u.searchParams.get('eys_close') === '1';
      showPdfPrintOverlay(`EYS yazdırma hazırlanıyor... ${ykodu}`);
      setTimeout(() => {
        try { window.focus(); } catch (_) {}
        showPdfPrintOverlay('Yazdırma komutu gönderiliyor... Sayfa aralığı: 1-2 seçilmeli.');
        try { window.print(); } catch (_) {}
        if (closeAfter) {
          setTimeout(() => { try { window.close(); } catch (_) {} }, 1500);
        }
      }, delay);
    } catch (_) {}
    return true;
  }

  if (setupPdfAutoPrintPage()) return;

  const CFG = {
    PANEL_ID: 'eys-tabbed-bot-panel',
    STYLE_ID: 'eys-tabbed-bot-style',
    STORAGE_KEY: 'eys_pending_action',
    FIXED_SIDE_URL: 'http://10.251.63.99:30870/side/side-dispatch',
    EYS_URL: 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch',
    RESCAN_MS: 5 * 60 * 1000,
    AFTER_MEMUR_SEND_WAIT_MS: 2500,
    SEQUENTIAL_SEND_WAIT_MS: 450,
    SERVICES: [
      ['1', 'MTY'],
      ['2', 'Usul Grup Müdürlüğü'],
      ['3', 'KDV ve Diğer Vergiler Grup Müdürlüğü'],
      ['4', 'İcra Takip Servisi'],
      ['10', '1. Sürekli Vergilendirme Servisi'],
      ['20', '2. Sürekli Vergilendirme Servisi'],
      ['30', '3. Sürekli Vergilendirme Servisi'],
      ['40', '4. Sürekli Vergilendirme Servisi'],
      ['50', 'Tarama-Kontrol Bölümü'],
      ['60', 'Sicil-Yoklama Servisi'],
      ['70', 'KDV İade Servisi'],
      ['80', 'Süreksiz Vergilendirme Servisi'],
      ['90', 'ÖTV Servisi'],
      ['91', 'İnteraktif Vergi Dairesi'],
      ['92', 'Ticaret Sicil Servisi'],
      ['93', 'GİB Robot'],
      ['94', 'GİB Kaşif']
    ],
    COMMANDS: {
      SIDE_GET_MODULE_INFO: 'SIDE.GET_MODULE_INFO',
      SIDE_GET_EAGER_BF_DEFS: 'SIDE.GET_EAGER_BF_DEFS',
      SIDE_GET_SERVICE_DEF_LIST: 'SIDE.GET_SERVICE_DEF_LIST',
      CREATE_SESSION: 'eosKullaniciServices_createSession',
      GET_VD_ADI: 'srvcRefData_getVDAdi',
      GET_KOOR_OF_VD: 'srvcRefData_getKoorOfVd',
      CHECK_USER: 'srvcEysUser_isFatihTopkapiOrHatayIskenderun',
      MEMUR_LIST: 'srvcDashboard_getMemurIslemlerYTum',
      MEMUR_SEND: 'srvcYoklama_submitYoklamalarToMudur',
      MUDUR_LIST: 'srvcDashboard_getMudurIslemlerYOnayBekleyen',
      IADE_LIST: 'srvcYoklama_getIadeler',
      MUDUR_SEND: 'srvcYoklama_submitYoklamalarToKoor',
      GET_YOKLAMALAR: 'srvcYoklama_getYoklamalar',
      ARCHIVE_YOKLAMA: 'srvcArchive_archiveYoklama',
      ISLEM_YAPILDI: 'srvcYoklama_islemYapildiYoklamaSonuc',
      YG_SICIL_BY_VKN: 'srvcRemoteCall_getSicilByVKN',
      YG_UNVAN_BY_TCKN: 'srvcRemoteCall_getUnvanVknByTCKN',
      YG_TERK_BILGI: 'srvcRemoteCall_getMukellefTerkBilgisiX',
      YG_MERKEZ_FAALIYET: 'srvcRemoteCall_getMerkezFaaliyetKonulari',
      YG_VD_OF_VKN: 'srvcRemoteCall_getVDsOfVKN',
      YG_VD_ADRESLER: 'srvcRemoteCall_getVDAdresleri',
      YG_VD_FAALIYETLER: 'srvcRemoteCall_getVdFaaliyetKonulari',
      YG_ESKI_LISTE: 'srvcYoklama_getEskiYoklamaListesi',
      YG_ADRES_AS_STRING: 'srvcRemoteCall_getAdresAsStringByAdresNo',
      YG_ADRES_TEXT: 'srvcRemoteCall_getAdresTextByAdresNo',
      YG_COORDS: 'srvcRemoteCall_getCoordinatesFromAdresno',
      YG_SAVE: 'srvcYoklama_saveYoklama',
      YG_SUBMIT_MUDUR: 'srvcYoklama_submitYoklamaToMudur',
      YG_SUBMIT_KOOR: 'srvcYoklama_submitYoklamaDirectToKoor',
      YG_DELETE: 'srvcYoklama_delYoklama',
      YG_CHECK_DIRECT_EKIP: 'srvcYoklama_checkDirectToEkip',
      YG_CHECK_YOKLAMA_DIRECT_EKIP: 'srvcYoklama_checkYoklamaDirectToEkip',
      YG_SUBMIT_DIRECT_EKIP: 'srvcYoklama_submitToDirectEkip',
      YG_SERMAYE: 'srvcRemoteCall_getSermayeMiktari',
      YG_ARAC_SAHIBI: 'srvcRemoteCall_getAracSahibiByPlaka',
      YG_SUBE_FAALIYETLER: 'srvcRemoteCall_getSubeFaaliyetKonulari',
      YG_YOKLAMA_TUM_BILGI: 'srvcYoklama_getYoklamaTumBilgi',
      YG_IT_PREVIEW: 'isTakipSorgulamalarServices_externalDispatch',
      YG_YOKLAMA_GUNLUK: 'srvcYoklama_getYoklamaGunluk',
      YG_YOKLAMA_PDF: 'srvcYoklama_getSonuc',
      YG_ADRES_COMBO: 'srvcRemoteCall_getAdresDataForCombo',
      YG_TCKN_ADRES: 'srvcRemoteCall_getUnvanAdresByTCKN',
      YG_VDLER_FOR_CMB: 'srvcRefData_getVDLERForCmb',
      YG_GMSI_ADRESLER: 'srvcRemoteCall_getGmsiAdresler',
      YG_ISTAKIP_LIST: 'isTakipSorgulamalarServices_isleriSorgula',
      YG_ACTIVE_COUNTS: 'isTakipSorgulamalarServices_aktifIsSayilariniBul',
    }
  };

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function visible(el) {
    return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  }

  function textOf(el) {
    return ((el?.innerText || el?.textContent || el?.value || el?.title || el?.alt || '') + '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function safeCall(obj, fn) {
    try { return obj && typeof obj[fn] === 'function' ? obj[fn]() : undefined; }
    catch (_) { return undefined; }
  }

  function getToken() {
    try {
      const cap = window.__istakipEysCaptured || {};
      if (cap.eysToken) return String(cap.eysToken || '').trim();
      if (cap.lastVdAdresleri && cap.lastVdAdresleri.token) return String(cap.lastVdAdresleri.token || '').trim();
    } catch (_) {}
    return new URLSearchParams(window.location.search).get('token') || '';
  }

  function formatDateYYYYMMDD(d = new Date()) {
    return d.toISOString().slice(0, 10).replaceAll('-', '');
  }

  function cssessionGet(key) {
    try {
      const c = window.CSSession || {};
      if (c && typeof c.get === 'function') {
        const v = c.get(key);
        if (v !== undefined && v !== null && String(v).trim() !== '') return String(v).trim();
      }
    } catch (_) {}
    try {
      const pg = window.__istakipEysPageSession || {};
      const map = {
        EOSROL: 'rol',
        EOSUSER: 'user',
        EOSUSERGIRIS: 'giris',
        EOSBIRIMKODU: 'birim',
        EOSDEFILKODU: 'il',
        EOSADI: 'adi',
        EOSUSERGIRISX: 'userx'
      };
      const v = pg[map[key] || key];
      if (v !== undefined && v !== null && String(v).trim() !== '') return String(v).trim();
    } catch (_) {}
    return '';
  }

  function getSessionSeed() {
    const c = window.CSSession || {};
    const pg = window.__istakipEysPageSession || {};

    const birim = String(
      pg.birim ||
      cssessionGet('EOSBIRIMKODU') ||
      safeCall(c, 'getVdKodu') ||
      c.vdKodu || c.vdkodu || c.birim || '016253'
    ).trim();

    const user = String(
      pg.user ||
      cssessionGet('EOSUSER') ||
      safeCall(c, 'getUserId') ||
      c.userId || window.userId || '35353114746'
    ).trim();

    const giris = String(
      pg.giris ||
      cssessionGet('EOSUSERGIRIS') ||
      user
    ).trim();

    const adi = String(
      pg.adi ||
      cssessionGet('EOSADI') ||
      safeCall(c, 'getUserName') ||
      c.adi || window.userName || ''
    ).trim();

    const userx = String(
      pg.userx ||
      cssessionGet('EOSUSERGIRISX') ||
      user
    ).trim();

    const il = String(
      pg.il ||
      cssessionGet('EOSDEFILKODU') ||
      birim.slice(0, 3)
    ).trim();

    const rol = String(
      pg.rol ||
      cssessionGet('EOSROL') ||
      ''
    ).trim();

    return {
      rol,
      user,
      giris,
      birim,
      il,
      adi,
      userx
    };
  }

  function buildSessionData(role) {
    const seed = getSessionSeed();
    return {
      rol: String(role || seed.rol || '10'),
      user: seed.user,
      giris: seed.giris || seed.user,
      birim: seed.birim,
      il: seed.il || String(seed.birim || '').slice(0, 3),
      adi: seed.adi,
      userx: seed.userx || seed.user
    };
  }

  function defaultBelgeKoorNo(sessionData = null) {
    const seed = sessionData || getSessionSeed();
    const il = String(seed.il || String(seed.birim || '').slice(0, 3) || '').replace(/\D+/g, '').padStart(3, '0').slice(0, 3);
    return il ? `DKOOR-${il}-01` : '';
  }

  function normalizeServerVknRange(start, end) {
    let basvkn = String(start || '').replace(/\D+/g, '').slice(0, 10);
    let sonvkn = String(end || '').replace(/\D+/g, '').slice(0, 10);
    // EYS ekranında boş bırakılan VKN aralığı botta kolaylık için 000..999 gösteriliyor.
    // Servise bu varsayılanı göndermek sorguyu daraltabiliyor; HAR'daki gerçek akışta boş gidiyor.
    if ((!basvkn && !sonvkn) || (basvkn === '0000000000' && sonvkn === '9999999999')) {
      basvkn = '';
      sonvkn = '';
    }
    return { basvkn, sonvkn };
  }

  function makeEysCallId() {
    try {
      const a = Math.floor(Date.now() + Math.random() * 1000000).toString(16);
      const b = String(Math.floor(Math.random() * 90) + 10);
      return `${a}-${b}`;
    } catch (_) {
      return `${Date.now()}-${Math.floor(Math.random() * 90) + 10}`;
    }
  }


  function maskTokenForLog(v) {
    const s = String(v || '').trim();
    if (!s) return '';
    if (s.length <= 14) return s.slice(0, 3) + '...' + s.slice(-3);
    return s.slice(0, 8) + '...' + s.slice(-6);
  }

  function getEysTokenCandidatesForCmd(cmd) {
    const out = [];
    const push = (v, why) => {
      const s = String(v || '').trim();
      if (!s) return;
      if (!out.some(x => x.token === s)) out.push({ token: s, why: why || '' });
    };
    try {
      const cap = window.__istakipEysCaptured || {};
      push(cap.lastByCmd?.[cmd]?.token, 'captured-lastByCmd');
      push(cap.tokensByCmd?.[cmd], 'captured-tokensByCmd');
      push(cap.lastVdAdresleri?.token, 'captured-lastVdAdresleri');
      push(cap.eysToken, 'captured-eysToken');
    } catch (_) {}
    try { push(new URLSearchParams(window.location.search).get('token'), 'url-token'); } catch (_) {}
    try { push(getToken(), 'getToken'); } catch (_) {}
    return out;
  }

  async function post(url, cmd, jp, tokenOverride = '') {
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', makeEysCallId());
    const token = tokenOverride || getToken();
    if (token) p.append('token', token);
    p.append('jp', JSON.stringify(jp || {}));

    const res = await fetch(url, {
      method: 'POST',
      body: p,
      credentials: 'include'
    });

    if (!res.ok) throw new Error(`Ağ hatası: ${res.status} (${cmd}) @ ${url}`);

    const text = await res.text();
    try { return JSON.parse(text); } catch (_) { return text; }
  }

  function getLocalDispatchUrl() {
    try {
      if (window.SideModuleManager) {
        if (typeof SideModuleManager.getLocalModuleAppUrl === 'function') {
          const u = SideModuleManager.getLocalModuleAppUrl();
          if (u) return u;
        }
        if (typeof SideModuleManager.getAppUrl === 'function') {
          const g = SideModuleManager.getAppUrl('g');
          if (g) return g;
        }
      }
    } catch (_) {}
    try {
      const origin = window.location.origin || '';
      // Side-bc / welcome.jsp dosyalarında g.app ve CSCaller.changeURL bu endpointi gösteriyor.
      if (/keys\.ggm\.bim/i.test(origin) || /\/gibintranet\//i.test(window.location.pathname || '')) {
        return origin + '/gibintranet_server/dispatch';
      }
      return origin + '/gibintranet_server/dispatch';
    } catch (_) {
      return '/gibintranet_server/dispatch';
    }
  }

  function getDirectDispatchUrls() {
    const out = [];
    const add = (u) => {
      if (!u || typeof u !== 'string') return;
      if (out.indexOf(u) < 0) out.push(u);
    };
    try {
      if (window.SideModuleManager) {
        if (typeof SideModuleManager.getLocalModuleAppUrl === 'function') add(SideModuleManager.getLocalModuleAppUrl());
        if (typeof SideModuleManager.getAppUrl === 'function') {
          add(SideModuleManager.getAppUrl('g'));
          add(SideModuleManager.getAppUrl('e'));
        }
      }
    } catch (_) {}
    add(getLocalDispatchUrl());
    add(CFG.EYS_URL);
    return out;
  }

  function callEysPageService(cmd, jp, timeoutMs = 9000) {
    const requestId = `eys-page-call-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    return new Promise((resolve, reject) => {
      let done = false;
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        window.removeEventListener('message', onMsg);
        reject(new Error('EYS page.call zaman aşımı'));
      }, timeoutMs);

      const onMsg = (event) => {
        try {
          if (event.source !== window) return;
          const data = event.data || {};
          if (data.type !== '__ISTAKIP_EYS_PAGE_CALL_RESULT__' || data.requestId !== requestId) return;
          if (done) return;
          done = true;
          clearTimeout(timer);
          window.removeEventListener('message', onMsg);
          if (data.ok) resolve(data);
          else reject(new Error(data.error || 'EYS page.call hata'));
        } catch (err) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          window.removeEventListener('message', onMsg);
          reject(err);
        }
      };

      window.addEventListener('message', onMsg);
      window.postMessage({
        type: '__ISTAKIP_EYS_PAGE_CALL__',
        requestId,
        cmd,
        payload: jp || {}
      }, '*');
    });
  }

  function callEysCSCaller(cmd, jp, timeoutMs = 10000, moduleName = '__local__') {
    const requestId = `eys-cscaller-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    return new Promise((resolve, reject) => {
      let done = false;
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        window.removeEventListener('message', onMsg);
        reject(new Error('EYS CSCaller zaman aşımı'));
      }, timeoutMs);

      const onMsg = (event) => {
        try {
          if (event.source !== window) return;
          const data = event.data || {};
          if (data.type !== '__ISTAKIP_EYS_CS_CALL_RESULT__' || data.requestId !== requestId) return;
          if (done) return;
          done = true;
          clearTimeout(timer);
          window.removeEventListener('message', onMsg);
          if (data.ok) resolve(data);
          else reject(new Error(data.error || 'EYS CSCaller hata'));
        } catch (err) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          window.removeEventListener('message', onMsg);
          reject(err);
        }
      };

      window.addEventListener('message', onMsg);
      window.postMessage({
        type: '__ISTAKIP_EYS_CS_CALL__',
        requestId,
        moduleName,
        cmd,
        payload: jp || {}
      }, '*');
    });
  }



  async function tryPost(url, cmd, jp) {
    try { return await post(url, cmd, jp); }
    catch (e) { return { __error: e.message || String(e) }; }
  }

  function buildSideCandidates() {
    const origin = window.location.origin;
    const path = window.location.pathname || '';
    const firstSeg = path.split('/').filter(Boolean)[0] || '';
    const candidates = [
      CFG.FIXED_SIDE_URL,
      origin + '/side/side-dispatch',
      origin + '/side-dispatch'
    ];
    if (firstSeg) {
      candidates.push(origin + '/' + firstSeg + '/side-dispatch');
      candidates.push(origin + '/' + firstSeg + '/side/side-dispatch');
    }
    return Array.from(new Set(candidates));
  }

  function looksLikeYkodu(value) {
    return typeof value === 'string' && /^\d{8}Y\d{6}[A-Z0-9]+$/i.test(value);
  }

  function collectObjects(root, out = []) {
    if (Array.isArray(root)) {
      for (const item of root) collectObjects(item, out);
      return out;
    }
    if (root && typeof root === 'object') {
      out.push(root);
      for (const value of Object.values(root)) collectObjects(value, out);
    }
    return out;
  }

  function extractYkodlariStrict(resp) {
    const found = new Set();
    const objects = collectObjects(resp);
    for (const obj of objects) {
      if (!obj || typeof obj !== 'object') continue;
      const direct = obj.ykodu || obj.yKod || obj.ykod || obj.yoklamaKodu || obj.yoklamakodu;
      if (looksLikeYkodu(direct)) found.add(direct);
      if (Array.isArray(obj.ykodlari)) {
        for (const value of obj.ykodlari) if (looksLikeYkodu(value)) found.add(value);
      }
    }
    return Array.from(found);
  }

  function extractYoklamaRows(resp) {
    const rows = [];
    const objects = collectObjects(resp);
    const seen = new Set();
    for (const obj of objects) {
      const ykodu = obj?.ykodu || obj?.yKod || obj?.ykod || obj?.yKodu || obj?.yoklamaKodu || obj?.yoklamakodu;
      if (!looksLikeYkodu(ykodu) || seen.has(ykodu)) continue;
      seen.add(ykodu);
      rows.push({
        ykodu,
        durum: obj?.durum || '',
        servis: String(obj?.servis || obj?.servisKodu || obj?.girisServis || obj?.girildigiServis || ''),
        archived: String(obj?.archived || ''),
        ilkislem: obj?.ilkislem || obj?.ilkIslem || '',
        sonislem: obj?.sonislem || obj?.sonIslem || '',
        unvan: obj?.unvan || obj?.adsoyad || obj?.adSoyadUnvan || '',
        vkn: obj?.vkn || obj?.vergiNo || obj?.vergino || '',
        tckn: obj?.tckn || obj?.tcKimlikNo || obj?.tckimlikno || '',
        benzersizKod: obj?.benzersizKod || obj?.benzersizkod || obj?.benzersizNo || obj?.benzersizno || obj?.bzkod || obj?.bzKod || obj?.bzkodu || obj?.bzKodu || obj?.belgeBenzersizKod || ''
      });
    }
    return rows;
  }

  function toYmd(value) {
    return String(value || '').replace(/\D/g, '').slice(0, 8);
  }

  function inYmdRange(ymd, start, end) {
    if (!ymd) return false;
    if (start && ymd < start) return false;
    if (end && ymd > end) return false;
    return true;
  }

  function normalizeCodeText(v) {
    return String(v || '').replace(/\s+/g, '').toUpperCase();
  }

  function normalizeDigitsText(v) {
    return String(v || '').replace(/\D+/g, '');
  }

  function clientFilterRows(rows, cfg = {}) {
    const start = toYmd(cfg.bastar);
    const end = toYmd(cfg.bittar);
    const servis = String(cfg.servis || '').trim();
    const wantedYkodu = normalizeCodeText(cfg.yoklamaKodu || '');
    const wantedBenzersiz = normalizeCodeText(cfg.benzersizKod || '');
    const wantedBenzersizDigits = normalizeDigitsText(cfg.benzersizKod || '');
    return (rows || []).filter(row => {
      const rowYkodu = normalizeCodeText(row?.ykodu || '');
      const rowBenzersiz = normalizeCodeText(row?.benzersizKod || '');
      const rowBenzersizDigits = normalizeDigitsText(row?.benzersizKod || '');
      if (wantedYkodu && !rowYkodu.includes(wantedYkodu)) return false;
      if (wantedBenzersiz) {
        // Benzersiz kodla sorguda EYS cevabı çoğu zaman hashcode/belgekoorno alanını geri döndürmüyor;
        // servis tekil kayıt döndürdüyse istemci filtresiyle kaydı ezmeyelim.
        if (!rowBenzersiz && !rowBenzersizDigits) return true;
        const textHit = rowBenzersiz && rowBenzersiz.includes(wantedBenzersiz);
        const digitHit = wantedBenzersizDigits && rowBenzersizDigits && rowBenzersizDigits.includes(wantedBenzersizDigits);
        if (!textHit && !digitHit) return false;
      }

      // Kodla aramada servis/tarih kısıtını gevşet: EYS kodu zaten tekil kayıt olduğu için
      // tarih veya servis alanı eksik dönerse kaydı liste dışı bırakmayalım.
      if (wantedYkodu || wantedBenzersiz) return true;

      const rowServis = String(row?.servis || '').trim();
      const ilk = toYmd(row?.ilkislem);
      const son = toYmd(row?.sonislem);
      const yk = toYmd(row?.ykodu);
      // EYS ekranındaki tarih alanı "SON İŞLEM TARİHİ"dir.
      // HAR cevaplarında bazı kayıtların ilk işlem tarihi eski, son işlem tarihi bugündür;
      // bu yüzden önce sonislem, sonra ilkislem/yKodu tarihi kontrol edilir.
      const rowDates = [son, ilk, yk].filter(Boolean);
      if (servis && rowServis && rowServis !== servis) return false;
      if (!start && !end) return true;
      return rowDates.some(d => inYmdRange(d, start, end));
    });
  }

  function previewResponse(resp) {
    try {
      const text = JSON.stringify(resp);
      return text.length > 500 ? text.slice(0, 500) + ' ...' : text;
    } catch (_) {
      return String(resp);
    }
  }




  function pickValue(obj, keys) {
    for (const k of keys || []) {
      if (obj && obj[k] !== undefined && obj[k] !== null && obj[k] !== '') return obj[k];
    }
    return '';
  }

  function deepPickValue(obj, keys, depth = 0, seen = new WeakSet()) {
    try {
      if (!obj || typeof obj !== 'object' || depth > 7) return '';
      if (seen.has(obj)) return '';
      seen.add(obj);
      const direct = pickValue(obj, keys);
      if (direct !== undefined && direct !== null && direct !== '') return direct;
      for (const v of Object.values(obj)) {
        if (v && typeof v === 'object') {
          const found = deepPickValue(v, keys, depth + 1, seen);
          if (found !== undefined && found !== null && found !== '') return found;
        }
      }
    } catch (_) {}
    return '';
  }

  function normalizeSicilData(raw, fallback = {}) {
    const o = parsePossiblyJsonData(raw) || {};
    const d = o.data && typeof o.data === 'object' ? o.data : o;
    return {
      vergiNo: String(pickValue(d, ['vergiNo','vkn','VKN','VERGINO','vergi_no']) || fallback.vkn || '').trim(),
      mukellefNo: String(pickValue(d, ['mukellefNo','tckn','TCKN','tcKimlikNo','tc']) || fallback.tckn || '').trim(),
      kimlikUnvan: String(pickValue(d, ['kimlikUnvan','KIMLIKUNVAN','unvan','UNVAN','adi','adsoyad']) || fallback.unvan || '').trim(),
      sirketTuru: pickValue(d, ['sirketTuru','SIRKETTURU','sirket_turu']) || fallback.sirketTuru || '',
      sirketTuruAd: String(pickValue(d, ['sirketTuruAd','SIRKETTURUAD','sirket_turu_ad']) || fallback.sirketTuruAd || '').trim(),
      kimlikPotansiyel: pickValue(d, ['kimlikPotansiyel','KIMLIKPOTANSIYEL']) || fallback.kimlikPotansiyel || '',
      tamDarMukelleffiyet: pickValue(d, ['tamDarMukelleffiyet','TAMDARMUKELLEFIYET']) || fallback.tamDarMukelleffiyet || '',
      adresNo: String(pickValue(d, ['ADRESNO','adresNo','mAdresNo','adres_no']) || '').trim(),
      adresStr: String(pickValue(d, ['ADRESSTR','adresStr','adres','ADRES','mAdresStr']) || '').trim(),
      raw: d
    };
  }


  function extractVdKodu(value) {
    const s = String(value || '').trim();
    const m = s.match(/(?:^|\D)(\d{6})(?:\D|$)/);
    return m ? m[1] : s;
  }

  function getVdOptionCode(o, fallbackText = '') {
    if (!o) return extractVdKodu(fallbackText);
    const direct = pickValue(o, [
      'vdkodu','vdKodu','VDKODU','VDKodu','vd_kodu','VD_KODU',
      'vdkod','vdKod','VDKOD','VD_KOD','kod','KOD','kodu','KODU',
      'code','CODE','id','ID','birimKodu','BIRIMKODU','vdBirimKodu','VDBIRIMKODU'
    ]);
    const d = String(direct || '').trim();
    if (d) {
      const only = d.replace(/\D+/g, '');
      if (only.length === 6) return only;
      const m = d.match(/(?:^|\D)(\d{6})(?:\D|$)/);
      if (m) return m[1];
    }
    // value en son değerlendirilir; çünkü bazı cevaplarda value/text görünen 016253 iken
    // gerçek servis vdkodu ayrı alanda 016258 olarak gelir.
    const val = String(pickValue(o, ['value','VALUE']) || fallbackText || '').trim();
    return extractVdKodu(val);
  }

  function getVdOptionText(o, fallback = '') {
    return String(pickValue(o, ['text','label','vdadi','VDADI','vdAdi','VDAdi','ad','ADI','name','NAME','value','VALUE']) || fallback || '').trim();
  }

  function uniqueNonEmpty(arr) {
    const seen = new Set();
    const out = [];
    for (const x of arr || []) {
      const s = String(x || '').trim();
      if (s && !seen.has(s)) {
        seen.add(s);
        out.push(s);
      }
    }
    return out;
  }

  function collectNativeVdCodesFromPage(matchText = '') {
    const wanted = String(matchText || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const out = [];
    const pushCode = (v) => {
      const s = String(v || '').trim();
      if (!s) return;
      const only = s.replace(/\D+/g, '');
      if (only.length === 6) out.push(only);
      const m = s.match(/(?:^|\D)(\d{6})(?:\D|$)/);
      if (m) out.push(m[1]);
    };
    try {
      document.querySelectorAll('select').forEach(sel => {
        const selected = sel.selectedOptions && sel.selectedOptions[0];
        const opts = selected ? [selected, ...Array.from(sel.options || [])] : Array.from(sel.options || []);
        for (const opt of opts) {
          const text = String(opt.textContent || opt.innerText || opt.label || '').replace(/\s+/g, ' ').trim();
          const low = text.toLowerCase();
          const isMatch = !wanted || low === wanted || low.includes(wanted) || wanted.includes(low);
          if (!isMatch) continue;
          pushCode(opt.value);
          pushCode(opt.getAttribute('value'));
          for (const attr of ['vdkodu','vdKodu','data-vdkodu','data-vd-kodu','data-kod','kod','kodu']) {
            pushCode(opt.getAttribute(attr));
          }
        }
      });
    } catch (_) {}
    return uniqueNonEmpty(out);
  }

  function getSelectedOptionRawCodes(optEl, optRaw, optText, vdRaw) {
    const out = [];
    const push = v => {
      const s = String(v || '').trim();
      if (!s) return;
      const only = s.replace(/\D+/g, '');
      if (only.length === 6) out.push(only);
      const m = s.match(/(?:^|\D)(\d{6})(?:\D|$)/);
      if (m) out.push(m[1]);
    };
    push(optEl?.dataset?.vdkodu);
    push(getVdOptionCode(optRaw, optText));
    push(extractVdKodu(vdRaw));
    push(extractVdKodu(optText));
    try {
      if (optRaw && typeof optRaw === 'object') {
        for (const [k, v] of Object.entries(optRaw)) {
          if (/vd|vergi|kod|birim|id/i.test(k)) push(v);
        }
      }
    } catch (_) {}
    return uniqueNonEmpty(out);
  }

  function buildKnownAddressVdCodes({ capturedPayload = {}, optEl = null, optRaw = null, optText = '', vdRaw = '' } = {}) {
    const out = [];
    const push = (v) => {
      const s = String(v || '').trim();
      if (!s) return;
      const only = s.replace(/\D+/g, '');
      if (only.length === 6) out.push(only);
      else {
        const m = s.match(/(?:^|\D)(\d{6})(?:\D|$)/);
        if (m) out.push(m[1]);
      }
    };

    // Önce EYS'in kendi yakalanan payloadı; sonra seçili optiondaki gerçek vdkodu.
    push(capturedPayload.vdkodu || capturedPayload.vdKodu || capturedPayload.VDKODU);
    push(optEl?.dataset?.vdkodu);
    push(getVdOptionCode(optRaw, optText));
    push(vdRaw);
    push(optText);

    // Çekirge örneğinde görünür 016253 iken doğru getVdAdresleri vdkodu 016258 geliyordu.
    // Bu özel yakın kod sadece son çare olarak denenir; eski sürümlerdeki rastgele 001252/054252 gibi kodlar artık eklenmez.
    const selected = String(extractVdKodu(optText) || extractVdKodu(vdRaw) || '').replace(/\D+/g, '');
    if (selected.length === 6) {
      const plus5 = String(Number(selected) + 5).padStart(6, '0');
      if (/^\d{6}$/.test(plus5)) push(plus5);
    }

    return uniqueNonEmpty(out);
  }




  function parseDeepJsonLike(value, depth = 0) {
    if (depth > 4) return value;
    if (typeof value === 'string') {
      const s = value.trim();
      if ((s.startsWith('{') && s.endsWith('}')) || (s.startsWith('[') && s.endsWith(']'))) {
        try { return parseDeepJsonLike(JSON.parse(s), depth + 1); } catch (_) {}
      }
    }
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      const out = {};
      for (const [k, v] of Object.entries(value)) out[k] = parseDeepJsonLike(v, depth + 1);
      return out;
    }
    if (Array.isArray(value)) return value.map(v => parseDeepJsonLike(v, depth + 1));
    return value;
  }

  function normalizeVdAdresRows(resp) {
    const d = parseDeepJsonLike(parsePossiblyJsonData(resp));
    const candidates = [];
    const pushList = (x) => {
      if (Array.isArray(x)) candidates.push(...x);
    };
    pushList(d);
    pushList(d?.data);
    pushList(d?.liste);
    pushList(d?.rows);
    pushList(d?.result);
    pushList(d?.data?.data);
    pushList(d?.data?.liste);
    pushList(d?.data?.rows);
    pushList(d?.data?.result);

    if (!candidates.length) {
      for (const obj of collectObjects(d)) {
        const adr = obj?.ADRESSTRING || obj?.adresString || obj?.ADRESSTR || obj?.adres || obj?.ADRES;
        const no = obj?.ADRESNO || obj?.adresNo || obj?.mAdresNo || obj?.ano;
        if (adr || no) candidates.push(obj);
      }
    }

    const seen = new Set();
    return candidates.map((o, i) => {
      const raw = o || {};
      const adresString = String(raw.ADRESSTRING || raw.adresString || raw.ADRESSTR || raw.adres || raw.ADRES || raw.text || raw.label || '').trim();
      const adresNo = String(raw.ADRESNO || raw.adresNo || raw.mAdresNo || raw.ano || raw.value || '').trim();
      return { index: i + 1, adresString, adresNo, raw };
    }).filter(r => {
      const key = `${r.adresNo}|${r.adresString}`;
      if ((!r.adresString && !r.adresNo) || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function normalizeComboList(resp) {
    const d = parsePossiblyJsonData(resp);
    const root = d?.data ?? d;
    if (Array.isArray(root)) return root;
    if (Array.isArray(root?.liste)) return root.liste;
    if (Array.isArray(root?.options)) return root.options;
    if (Array.isArray(root?.data)) return root.data;
    return [];
  }

  function htmlEscape(v) {
    return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function ymdFromAny(v) {
    const s = String(v || '').trim();
    const m1 = s.match(/(\d{4})[-./]?(\d{2})[-./]?(\d{2})/);
    if (m1) return `${m1[1]}${m1[2]}${m1[3]}`;
    const m2 = s.match(/(\d{2})[./-](\d{2})[./-](\d{4})/);
    if (m2) return `${m2[3]}${m2[2]}${m2[1]}`;
    return '';
  }

  function getJobField(job, keys) {
    for (const k of keys) {
      if (job && job[k] !== undefined && job[k] !== null && job[k] !== '') return job[k];
    }
    const ek = job?.kaynakEkBilgiler || {};
    for (const k of keys) {
      if (ek && ek[k] !== undefined && ek[k] !== null && ek[k] !== '') return ek[k];
    }
    return '';
  }

  function findJobPreviewOid(job) {
    const ek = job?.kaynakEkBilgiler || {};
    return String(ek.keysEvrakOid || job?.keysEvrakOid || ek.evrakOid || job?.evrakOid || ek.belgeOid || job?.belgeOid || '').trim();
  }


  function ensureYgPreviewModal() {
    // v4.31.65: Her önizleme için ayrı modal oluştur. Böylece ikinci Önizle Aç
    // mevcut pencerenin içeriğini değiştirmez; birden fazla evrak aynı anda açık kalır.
    const uid = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const idx = (window.__istakipYgPreviewModalCount = (window.__istakipYgPreviewModalCount || 0) + 1);
    const off = ((idx - 1) % 6) * 32;
    let modal = document.createElement('div');
    modal.id = `eys-yg-preview-modal-${uid}`;
    modal.className = 'eys-yg-preview-modal-instance';
    modal.style.cssText = [
      'position:fixed','z-index:2147483646',`left:${24 + off}px`,`top:${24 + off}px`,
      'width:min(1100px,calc(100vw - 48px))','height:min(760px,calc(100vh - 48px))',
      'background:#111827','border:1px solid #475569','border-radius:10px',
      'box-shadow:0 18px 60px rgba(0,0,0,.45)','display:none','overflow:hidden'
    ].join(';');
    modal.innerHTML = `
      <div style="height:34px;background:#1f2937;color:#e5e7eb;display:flex;align-items:center;justify-content:space-between;padding:0 10px;font:12px Arial">
        <strong id="eys-yg-preview-title">Önizleme</strong>
        <div>
          <button id="eys-yg-preview-open-tab" style="margin-right:6px;border:1px solid #64748b;background:#0f172a;color:#fff;border-radius:5px;padding:3px 8px">Sekmede Aç</button>
          <button id="eys-yg-preview-close" style="border:1px solid #64748b;background:#0f172a;color:#ffb4b4;border-radius:5px;padding:3px 8px">Kapat</button>
        </div>
      </div>
      <div id="eys-yg-preview-message" style="display:none;height:calc(100% - 34px);padding:22px;color:#e5e7eb;font:14px Arial;line-height:1.45;background:#111827"></div>
      <iframe id="eys-yg-preview-frame" style="width:100%;height:calc(100% - 34px);border:0;background:white"></iframe>
    `;
    document.documentElement.appendChild(modal);
    modal.querySelector('#eys-yg-preview-close').onclick = () => { modal.style.display = 'none'; };
    modal.querySelector('#eys-yg-preview-open-tab').onclick = () => {
      const src = modal.getAttribute('data-preview-url') || modal.querySelector('#eys-yg-preview-frame')?.src;
      if (src) window.open(src, '_blank');
    };
    return modal;
  }

  function isLikelyFrameBlockedEysUrl(url) {
    const u = String(url || '');
    return /(^|\.)eyoklama\.gelirler\.gov\.tr/i.test(u) || /\/edenetis\/getSonuc/i.test(u);
  }


  function rememberYgPdfPopupUrl(url, title = '', source = '') {
    try {
      const u = String(url || '').trim();
      if (!u) return;
      window.__ISTAKIP_EYS_LAST_PDF_URLS = window.__ISTAKIP_EYS_LAST_PDF_URLS || [];
      const arr = window.__ISTAKIP_EYS_LAST_PDF_URLS;
      arr.unshift({ url: u, title: String(title || ''), source: String(source || ''), time: Date.now() });
      const seen = new Set();
      window.__ISTAKIP_EYS_LAST_PDF_URLS = arr.filter(x => {
        const k = String(x?.url || '');
        if (!k || seen.has(k)) return false;
        seen.add(k);
        return Date.now() - Number(x?.time || 0) < 10 * 60 * 1000;
      }).slice(0, 20);
    } catch (_) {}
  }

  function getRememberedYgPdfPopupUrls(maxAgeMs = 5 * 60 * 1000) {
    try {
      const now = Date.now();
      return (window.__ISTAKIP_EYS_LAST_PDF_URLS || [])
        .filter(x => x && x.url && now - Number(x.time || 0) <= maxAgeMs)
        .map(x => x.url);
    } catch (_) { return []; }
  }

  function openEysPdfPopupWindow(url, title = 'getSonuc') {
    if (!url) return null;
    try {
      const sw = window.screen && window.screen.availWidth ? window.screen.availWidth : 1366;
      const sh = window.screen && window.screen.availHeight ? window.screen.availHeight : 768;
      const idx = (window.__istakipEysPdfPopupCount = (window.__istakipEysPdfPopupCount || 0) + 1);
      const w = Math.min(980, Math.max(760, Math.floor(sw * 0.72)));
      const h = Math.min(760, Math.max(560, Math.floor(sh * 0.82)));
      const left = Math.max(0, Math.floor((sw - w) / 2 + ((idx - 1) % 5) * 36));
      const top = Math.max(0, Math.floor((sh - h) / 2 + ((idx - 1) % 5) * 28));
      const features = [
        `width=${w}`,
        `height=${h}`,
        `left=${left}`,
        `top=${top}`,
        'resizable=yes',
        'scrollbars=yes',
        'toolbar=no',
        'menubar=no',
        'location=yes',
        'status=no'
      ].join(',');
      const winName = `${String(title || 'getSonuc').replace(/[^a-z0-9_]+/gi, '_')}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      rememberYgPdfPopupUrl(url, title, 'open');
      const pop = window.open(url, winName, features);
      try {
        if (pop) {
          [250, 900, 1800].forEach(ms => setTimeout(() => {
            try {
              const href = pop.location && pop.location.href ? String(pop.location.href) : '';
              if (href && href !== 'about:blank') rememberYgPdfPopupUrl(href, title, 'popup-location');
            } catch (_) {}
          }, ms));
        }
      } catch (_) {}
      return pop;
    } catch (_) {
      const winName = `${String(title || 'getSonuc').replace(/[^a-z0-9_]+/gi, '_')}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      rememberYgPdfPopupUrl(url, title, 'open-fallback');
      const pop = window.open(url, winName);
      try { setTimeout(() => { try { if (pop?.location?.href) rememberYgPdfPopupUrl(pop.location.href, title, 'popup-location'); } catch (_) {} }, 900); } catch (_) {}
      return pop;
    }
  }

  function openYgPreviewUrl(url, title = 'Önizleme', opts = {}) {
    if (!url) return null;
    const forceIframe = !!(opts && opts.forceIframe);

    // v4.31.80: Normal Önizle sütunu popup akışını korur.
    // Adi ortaklık özel akışı forceIframe=true ile doğrudan panel içi iframe açar ve metni oradan okur.
    if (!forceIframe) {
      const pop = openEysPdfPopupWindow(url, title || 'Önizleme');
      if (pop) return pop;
    }

    const modal = ensureYgPreviewModal();
    const frame = modal.querySelector('#eys-yg-preview-frame');
    const msg = modal.querySelector('#eys-yg-preview-message');
    modal.querySelector('#eys-yg-preview-title').textContent = title;
    modal.setAttribute('data-preview-url', url);

    if (forceIframe) {
      if (msg) { msg.style.display = 'none'; msg.innerHTML = ''; }
      if (frame) {
        frame.style.display = 'block';
        frame.setAttribute('src', url);
      }
      modal.style.display = 'block';
      return modal;
    }

    // Popup engellenirse yedek çoklu modal gösterilir.
    if (frame) {
      frame.removeAttribute('src');
      frame.style.display = 'none';
    }
    if (msg) {
      msg.style.display = 'block';
      msg.innerHTML = `
        <div style="font-weight:700;margin-bottom:8px">Tarayıcı popup penceresini engelledi.</div>
        <div style="margin-bottom:10px">Üstteki <b>Sekmede Aç</b> düğmesine basınca yeni pencere/sekme açılır.</div>
        <div style="font-size:12px;color:#9ca3af;word-break:break-all">${htmlEscape(url)}</div>
      `;
    }
    modal.style.display = 'block';
    return modal;
  }

  function extractFirstUrlDeep(obj) {
    const seen = new Set();
    const walk = (v) => {
      if (v == null) return '';
      if (typeof v === 'string') {
        if (/^https?:\/\//i.test(v) || /^\//.test(v)) return v;
        if (v.includes('http://') || v.includes('https://')) {
          const m = v.match(/https?:\/\/[^"'\s<>]+/i);
          if (m) return m[0];
        }
        try { return walk(JSON.parse(v)); } catch (_) { return ''; }
      }
      if (typeof v !== 'object') return '';
      if (seen.has(v)) return '';
      seen.add(v);
      for (const k of ['url','link','href','evrakUrl','evrakLink','pdfUrl','sonucUrl','location']) {
        if (v[k]) {
          const r = walk(v[k]);
          if (r) return r;
        }
      }
      for (const val of Object.values(v)) {
        const r = walk(val);
        if (r) return r;
      }
      return '';
    };
    return walk(obj);
  }

  function normalizeEysUrl(url) {
    if (!url) return '';
    if (/^https?:\/\//i.test(url)) return url;
    if (url.startsWith('/')) return location.origin + url;
    return url;
  }

  function isEysServiceError(resp) {
    const d = parsePossiblyJsonData(resp);
    if (!d || typeof d !== 'object') return false;
    if (String(d.error || '') === '1') return true;
    if (d.success === false || String(d.success).toLowerCase() === 'false') return true;
    const msg = JSON.stringify(d).toLowerCase();
    return msg.includes('servis hatası') || msg.includes('servis hatasi');
  }

  function extractFirstYkoduText(root) {
    try {
      const text = JSON.stringify(root || '');
      const m = text.match(/20\d{6}Y[0-9A-Z]+/i);
      return m ? m[0] : '';
    } catch (_) {
      const m = String(root || '').match(/20\d{6}Y[0-9A-Z]+/i);
      return m ? m[0] : '';
    }
  }

  function ykoduFromAnyRecord(r) {
    const direct = pickValue(r, [
      'yKodu','ykodu','YKODU','YKodu','yKod','YKod','ykod','YKOD',
      'kod','KOD','kodu','KODU','yoklamaKodu','YOKLAMAKODU',
      'yoklama_kodu','yoklamaKod','yoklamaNo','yoklamaNumarasi',
      'yNo','yno','raporKodu','raporNo','sonucYkodu','sonucYKodu'
    ]);
    const s = String(direct || '').trim();
    if (s) return s;
    return extractFirstYkoduText(r);
  }

  function formatYoklamaRecordLine(r) {
    const y = ykoduFromAnyRecord(r);
    const durum = pickValue(r, ['durum','DURUM','ydurum','YDURUM','durumText','DURUMTEXT','sonuc','sonucText','sonDurum']) || '';
    const tarih = pickValue(r, ['zaman','ZAMAN','optime','OPTIME','tarih','TARIH','kayitTarihi','KAYITTARIHI','ilktarih','ilkTarih','sonislem']) || '';
    const ad = pickValue(r, ['adi','ADI','ymadi','YMADI','memuradi','memurAdi','unvan','UNVAN','adsoyad','adSoyad']) || '';
    return { y, durum, tarih, ad };
  }



  function eysIlAdiFromKod(kod) {
    const k = String(kod || '').padStart(3, '0');
    const map = {
      '001':'ADANA','002':'ADIYAMAN','003':'AFYONKARAHİSAR','004':'AĞRI','005':'AMASYA','006':'ANKARA','007':'ANTALYA','008':'ARTVİN','009':'AYDIN','010':'BALIKESİR',
      '011':'BİLECİK','012':'BİNGÖL','013':'BİTLİS','014':'BOLU','015':'BURDUR','016':'BURSA','017':'ÇANAKKALE','018':'ÇANKIRI','019':'ÇORUM','020':'DENİZLİ',
      '021':'DİYARBAKIR','022':'EDİRNE','023':'ELAZIĞ','024':'ERZİNCAN','025':'ERZURUM','026':'ESKİŞEHİR','027':'GAZİANTEP','028':'GİRESUN','029':'GÜMÜŞHANE','030':'HAKKARİ',
      '031':'HATAY','032':'ISPARTA','033':'MERSİN','034':'İSTANBUL','035':'İZMİR','036':'KARS','037':'KASTAMONU','038':'KAYSERİ','039':'KIRKLARELİ','040':'KIRŞEHİR',
      '041':'KOCAELİ','042':'KONYA','043':'KÜTAHYA','044':'MALATYA','045':'MANİSA','046':'KAHRAMANMARAŞ','047':'MARDİN','048':'MUĞLA','049':'MUŞ','050':'NEVŞEHİR',
      '051':'NİĞDE','052':'ORDU','053':'RİZE','054':'SAKARYA','055':'SAMSUN','056':'SİİRT','057':'SİNOP','058':'SİVAS','059':'TEKİRDAĞ','060':'TOKAT',
      '061':'TRABZON','062':'TUNCELİ','063':'ŞANLIURFA','064':'UŞAK','065':'VAN','066':'YOZGAT','067':'ZONGULDAK','068':'AKSARAY','069':'BAYBURT','070':'KARAMAN',
      '071':'KIRIKKALE','072':'BATMAN','073':'ŞIRNAK','074':'BARTIN','075':'ARDAHAN','076':'IĞDIR','077':'YALOVA','078':'KARABÜK','079':'KİLİS','080':'OSMANİYE','081':'DÜZCE'
    };
    return map[k] || k;
  }



  function ihbarKaynakOptionsHtml(selected = 'BIMER') {
    return [
      ['VIMER', 'VİMER'],
      ['BIMER', 'BİMER'],
      ['CIMER', 'CİMER'],
      ['DIGER', 'DİĞER']
    ].map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }


  function yoklamaTuruOptionsHtml(selected = '10') {
    const opts = [
      ['10', 'İşe Başlama'],
      ['NAKIL_ISE_BASLAMA', 'Nakil İşe Başlama'],
      ['ADRES_DEGISIKLIGI', 'Adres Değişikliği'],
      ['SUBE_ACILIS', 'Şube Açılışı'],
      ['EK_ISE_BASLAMA', 'Ek İşe Başlama'],
      ['EK_ISI_BIRAKMA', 'Ek İşi Bırakma'],
      ['TUZEL_ACILIS', 'Elektronik Ortamda Tüzel Kişilik Açılış Yoklaması'],
      ['ISI_BIRAKMA', 'İşi Bırakma'],
      ['NAKIL_ISI_BIRAKMA', 'Nakil İşi Bırakma'],
      ['SUBE_KAPANIS', 'Şube Kapanışı'],
      ['FAAL_MUK_KONTROL', 'Faal Mükellef Kontrol'],
      ['NAKIL_VASITALARI', 'Nakil Vasıtaları'],
      ['DIGER_UCRETLI_CALISAN', 'Diğer Ücretli Çalışan'],
      ['DIGER_UCRETLI_CALISAN_TERK', 'Diğer Ücretli Çalışan Terk'],
      ['NAKIL_VASITALARI_TERK', 'Nakil Vasıtaları Terk'],
      ['KAYIT_DISI_FAALIYET', 'Kayıt Dışı Faaliyet'],
      ['GMSI_MULK_SAHIBI', 'GMSİ (Mülk Sahibi)'],
      ['GMSI_KIRACI', 'GMSİ (Kiracı)'],
      ['RESEN_TERK_ISYERI', "Re'sen Terk (İşyeri Nezd.)"],
      ['RESEN_TERK_SIRKET', "Re'sen Terk (Şirket Yetk. Nezd./Mükellef İkametgahında)"],
      ['KDV_IADE_IMALATCI', 'KDV İade (İmalatçı)'],
      ['KDV_IADE_IMALATCI_OLMAYAN', 'KDV İade (İmalatçı Olmayan)'],
      ['KDV_IADE_IHRAC_KAYDI', 'KDV İade (İmalatçıların İhraç Kaydı)'],
      ['KDV_INCELEME', 'KDV İadeleri Vergi İncelemesine Tabi Olacak Mükellef Tespit Yoklaması'],
      ['ANLASMALI_MATBAA', 'Anlaşmalı Matbaa Yoklaması'],
      ['VUK_160A', 'VUK 160A Yoklaması'],
      ['SERBEST', 'Serbest Yoklama']
    ];
    return opts.map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }

  function isyeriTuruOptionsHtml(selected = '0') {
    return [
      ['0', 'Merkez'],
      ['1', 'Şube'],
      ['2', 'Depo'],
      ['3', 'Mesken'],
      ['4', 'Diğer']
    ].map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }

  function mulkiyetOptionsHtml(selected = '2') {
    return [
      ['1', 'Kendi Mülkü'],
      ['2', 'Kiralık'],
      ['3', 'Bedelsiz Kiralık'],
      ['4', 'Diğer']
    ].map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }

  function kiraOdemeSekliOptionsHtml(selected = '2') {
    return [
      ['1', 'Elden'],
      ['2', 'Banka Hesabına'],
      ['3', 'Diğer']
    ].map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }

  function kiraOdemeDonemiOptionsHtml(selected = '2') {
    return [
      ['1', 'Aylık'],
      ['2', 'Yıllık'],
      ['3', 'Diğer']
    ].map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }

  function isletmeTuruOptionsHtml(selected = '1') {
    return [
      ['1', 'Gerçek Mükellef'],
      ['2', 'Adi Ortaklık'],
      ['3', 'Kollektif Şirket'],
      ['4', 'Adi Komandit Şirket'],
      ['5', 'Eshamlı Komandit Şirket'],
      ['6', 'Limited Şirket'],
      ['7', 'Anonim Şirket'],
      ['8', 'Kooperatif'],
      ['9', 'Diğer Şirket'],
      ['10', 'Avukat Ortaklığı'],
      ['11', 'İş Ortaklığı']
    ].map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }

  function mukGrupOptionsHtml(selected = '1') {
    return [
      ['1', 'Gelir Vergisi Mükellefi'],
      ['2', 'Kurumlar Vergisi Mükellefi'],
      ['3', 'Basit Usulde Tespit Edilen'],
      ['4', 'Serbest Meslek Kazancı'],
      ['5', 'Diğer']
    ].map(([v, t]) => `<option value="${v}"${v === selected ? ' selected' : ''}>${t}</option>`).join('');
  }

  function parsePossiblyJsonData(resp) {
    const data = resp && Object.prototype.hasOwnProperty.call(resp, 'data') ? resp.data : resp;
    if (typeof data === 'string') {
      try { return JSON.parse(data); } catch (_) { return data; }
    }
    return data;
  }

  function moneyToNumber(v) {
    const s = String(v || '').trim().replace(/\./g, '').replace(',', '.');
    const n = Number(s);
    return Number.isFinite(n) ? n : 0;
  }

  function makeYtextFromAdres(a) {
    if (!a || typeof a !== 'object') return '';
    return ` - [${a.ilAd || ''}/${a.ilceAd || ''}/${a.mahAd || ''}/${a.csbmAd || ''}/${a.disKapiNo || ''}/]`;
  }


  function serviceOptionsHtml(selected = '60') {
    const empty = `<option value="" ${selected === '' ? 'selected' : ''}>Hepsi / servis boş</option>`;
    return empty + CFG.SERVICES.map(([value, label]) =>
      `<option value="${value}" ${value === selected ? 'selected' : ''}>${value} — ${label}</option>`
    ).join('');
  }

  function sourceOptionsHtml(selected = '0') {
    const options = [
      ['0', 'Kullanılan veriler'],
      ['1', 'Sadece arşiv verileri'],
      ['2', 'Arşiv dahil tüm veriler / durum+servis']
    ];
    return options.map(([value, label]) =>
      `<option value="${value}" ${String(value) === String(selected) ? 'selected' : ''}>${value} — ${label}</option>`
    ).join('');
  }

  function ydurumOptionsHtml(selected = '') {
    const options = [
      ['', 'Hepsi / boş'],
      ['10', 'Memurda'],
      ['20', 'Müdürde'],
      ['30', 'Koordinatörde'],
      ['40', 'Ekipte'],
      ['60', 'Yoklama sonuçlandı'],
      ['70', 'Sonuçlanmayanlar'],
      ['80', 'Görevli VD’de'],
      ['90', 'Sonlandırılanlar'],
      ['0', 'İptal edilenler']
    ];
    return options.map(([value, label]) =>
      `<option value="${value}" ${String(value) === String(selected) ? 'selected' : ''}>${value === '' ? '' : value + ' — '}${label}</option>`
    ).join('');
  }

  function sonucIslemOptionsHtml(selected = '1') {
    const options = [
      ['1', 'İşlem yapılacaklar'],
      ['2', 'İşlem yapılanlar'],
      ['0', 'Hepsi']
    ];
    return options.map(([value, label]) =>
      `<option value="${value}" ${String(value) === String(selected) ? 'selected' : ''}>${value} — ${label}</option>`
    ).join('');
  }

  function injectStyle() {
    if (document.getElementById(CFG.STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = CFG.STYLE_ID;
    s.textContent = `
      #${CFG.PANEL_ID}{position:fixed;top:6%;right:1.5%;width:620px;max-width:96vw;z-index:2147483647;background:#060912;color:#eaf0ff;font:12px/1.45 'Segoe UI',sans-serif;border:1px solid #232b3a;border-radius:10px;box-shadow:0 20px 50px rgba(0,0,0,.8)}
      #${CFG.PANEL_ID}, #${CFG.PANEL_ID} *{box-sizing:border-box}
      #${CFG.PANEL_ID} .h{display:flex;justify-content:space-between;align-items:center;padding:10px 15px;background:#121826;border-radius:10px 10px 0 0;border-bottom:1px solid #232b3a}
      #${CFG.PANEL_ID} .w{padding:12px}
      #${CFG.PANEL_ID} label{display:block;font-size:10px;color:#9aa6bf;margin:6px 0 3px;font-weight:bold;text-transform:uppercase}
      #${CFG.PANEL_ID} input,#${CFG.PANEL_ID} select{width:100%;background:#050814;border:1px solid #273048;padding:8px;color:#eaf0ff;border-radius:4px}
      #${CFG.PANEL_ID} input:disabled{opacity:.8;color:#9ddcff}
      #${CFG.PANEL_ID} button.action{width:100%;padding:10px;border:0;border-radius:4px;font-weight:bold;cursor:pointer;margin-top:8px}
      #${CFG.PANEL_ID} .mini{width:auto;background:none;color:#9ddcff;border:0;font-size:18px;margin-left:10px;padding:0;cursor:pointer}
      #${CFG.PANEL_ID} .row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      #${CFG.PANEL_ID} .row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}
      #${CFG.PANEL_ID} .row4{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px}
      #${CFG.PANEL_ID} .bottom-actions{margin-top:10px;border-top:1px solid #273048;padding-top:8px}
      #${CFG.PANEL_ID} .tabs{display:flex;gap:6px;margin:10px 0 12px;flex-wrap:wrap}
      #${CFG.PANEL_ID} .tab-btn{flex:1;min-width:120px;padding:9px 10px;border:1px solid #273048;border-radius:6px;background:#0a1020;color:#c8d5f0;cursor:pointer;font-weight:bold}
      #${CFG.PANEL_ID} .tab-btn.active{background:#173056;color:#fff;border-color:#2d8cff}
      #${CFG.PANEL_ID} .tab-page{display:none}
      #${CFG.PANEL_ID} .tab-page.active{display:block}
      #${CFG.PANEL_ID} .card{margin-top:10px;padding:10px;border:1px solid #273048;border-radius:6px;background:#0a1020}
      #${CFG.PANEL_ID} .mutedtitle{font-weight:bold;color:#c4d5ff;margin-bottom:6px}
      #${CFG.PANEL_ID} .hint{margin-top:5px;color:#93a1c1;font-size:11px}
      #${CFG.PANEL_ID} .subnote{margin-top:6px;color:#9aa6bf;font-size:11px}
      #${CFG.PANEL_ID} .checkline{display:flex;align-items:center;gap:7px;margin-top:7px;color:#d3ddf7;font-size:11px}
      #${CFG.PANEL_ID} .checkline input{width:auto!important;margin:0!important;padding:0!important}
      #${CFG.PANEL_ID} .monitor{background:#000;color:#0f0;font-family:monospace;height:210px;overflow:auto;border:1px solid #333;padding:8px;margin-top:10px;border-radius:4px}
      #${CFG.PANEL_ID} .monitor .err{color:#ff6b6b}
      #${CFG.PANEL_ID} .list{max-height:180px;overflow:auto;border:1px solid #273048;border-radius:4px;margin-top:8px;background:#050814}
      #${CFG.PANEL_ID} .list-row{padding:7px 8px;border-bottom:1px solid #172034;display:flex;justify-content:space-between;gap:10px;align-items:center}
      #${CFG.PANEL_ID} .list-row:last-child{border-bottom:0}
      #${CFG.PANEL_ID} .tiny{font-size:11px;color:#aeb9d4}
      #${CFG.PANEL_ID} .inline-btn{width:auto;margin:0 0 0 6px;padding:5px 8px;font-size:11px;border-radius:4px;border:1px solid #36517d;background:#10213d;color:#fff;cursor:pointer}
      #${CFG.PANEL_ID} .inline-btn.warn{background:#4a3510;border-color:#9b7426}
      #${CFG.PANEL_ID} .inline-btn.good{background:#15391f;border-color:#2f8f4e}
      #${CFG.PANEL_ID} #yg_it_jobs_list{max-height:300px;overflow:auto;background:#050814}
      #${CFG.PANEL_ID} .yg-it-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:11px}
      #${CFG.PANEL_ID} .yg-it-table th{position:sticky;top:0;background:#1a2437;color:#eaf0ff;text-align:left;padding:6px 7px;border-bottom:1px solid #273048;z-index:1}
      #${CFG.PANEL_ID} .yg-it-table td{padding:6px 7px;border-bottom:1px solid #172034;vertical-align:top;word-break:break-word}
      #${CFG.PANEL_ID} .yg-it-table tr:hover td{background:#0c1424}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-no{width:34px;text-align:center;color:#9ddcff}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-act{width:126px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-is{width:132px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-belge{width:135px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-tur{width:120px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-unvan{width:165px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-durum{width:155px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-preview{width:82px;min-width:82px;white-space:nowrap}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-ykdurum{width:122px;min-width:122px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-ykkod{width:190px}
      #${CFG.PANEL_ID} .yg-act-wrap{display:flex;align-items:center;gap:5px;flex-wrap:wrap}
      #${CFG.PANEL_ID} .yg-row-action-btn{min-width:26px;height:26px;border-radius:7px;border:1px solid #405273;background:#eef2f7;color:#172033;font-weight:800;cursor:pointer;padding:0 6px}
      #${CFG.PANEL_ID} .yg-it-table .yg-col-preview .inline-btn{margin-left:0;white-space:nowrap}
      #${CFG.PANEL_ID} .yg-yk-line{display:block;line-height:1.35;margin-bottom:2px}
      #${CFG.PANEL_ID} .yg-yk-muted{color:#94a3b8}
      #${CFG.PANEL_ID} .yg-yk-link{color:#b9d8ff;text-decoration:none;cursor:pointer}
      #${CFG.PANEL_ID} .yg-yk-link:hover{text-decoration:underline}
      #${CFG.PANEL_ID} .yg-it-status-ok{color:#86efac;font-weight:700}
      #${CFG.PANEL_ID} .yg-it-status-bad{color:#fca5a5;font-weight:700}
      #${CFG.PANEL_ID} .yg-it-status-exc{color:#fbbf24;font-weight:700}
      #${CFG.PANEL_ID} .yg-it-filter-info{font-size:11px;color:#86efac;margin-top:5px;font-weight:700}

      #${CFG.PANEL_ID} [data-page="ygiris"] #yg_summary{max-height:58px;min-height:38px;overflow:auto;cursor:pointer;transition:max-height .18s ease;border-color:#334155;background:#050814}
      #${CFG.PANEL_ID} [data-page="ygiris"] #yg_summary::before{content:'Ön Bilgi — tıkla aç/kapat';display:block;position:sticky;top:0;z-index:2;background:#111827;color:#9ddcff;font-size:10px;font-weight:800;padding:3px 7px;border-bottom:1px solid #273048;text-transform:uppercase}
      #${CFG.PANEL_ID} [data-page="ygiris"] #yg_summary.expanded{max-height:220px}
      #${CFG.PANEL_ID} [data-page="ygiris"] #log_ygiris{height:54px;min-height:54px;max-height:54px;cursor:pointer;transition:height .18s ease,max-height .18s ease;margin-top:6px}
      #${CFG.PANEL_ID} [data-page="ygiris"] #log_ygiris::before{content:'İşlem Monitörü — tıkla aç/kapat';display:block;position:sticky;top:0;background:#020617;color:#9ddcff;font:10px 'Segoe UI',sans-serif;font-weight:800;padding:2px 4px;margin:-8px -8px 4px;border-bottom:1px solid #1f2937;text-transform:uppercase}
      #${CFG.PANEL_ID} [data-page="ygiris"] #log_ygiris.expanded{height:230px;max-height:230px}
      #${CFG.PANEL_ID} [data-page="ygiris"] #yg_it_jobs_list{max-height:520px;min-height:300px;overflow:auto;background:#050814}
      #${CFG.PANEL_ID} [data-page="ygiris"] .yg-it-table{font-size:11px}
      #${CFG.PANEL_ID} [data-page="ygiris"] .yg-it-table td{padding:5px 6px}
      #${CFG.PANEL_ID} [data-page="ygiris"] .yg-it-table th{padding:5px 6px}

      #${CFG.PANEL_ID} .today-mini{width:auto!important;margin-left:6px!important;padding:2px 7px!important;font-size:10px!important;line-height:1.2!important;border-radius:4px!important;background:#2563eb!important;color:#fff!important;border:1px solid #60a5fa!important;vertical-align:middle!important}


      #${CFG.PANEL_ID} .filter-tools{display:grid;grid-template-columns:1fr 1fr auto auto;gap:8px;align-items:end;margin-top:8px}
      #${CFG.PANEL_ID} .result-row{padding:7px 8px;border-bottom:1px solid #172034;display:grid;grid-template-columns:24px 1fr auto;gap:8px;align-items:center}
      #${CFG.PANEL_ID} .result-row:last-child{border-bottom:0}
      #${CFG.PANEL_ID} .result-row .code{font-family:monospace;color:#9ddcff}
      #${CFG.PANEL_ID} .result-row .meta{font-size:11px;color:#aeb9d4;margin-top:2px}
      #${CFG.PANEL_ID} .result-actions{display:flex;gap:6px;flex-wrap:wrap}
      #${CFG.PANEL_ID} .result-actions button{width:auto;margin:0;padding:5px 8px;font-size:11px;border-radius:4px;border:1px solid #36517d;background:#10213d;color:#fff;cursor:pointer}
      #${CFG.PANEL_ID} .addr-card{background:#080d18}
      #${CFG.PANEL_ID} .addr-tabs{display:flex;gap:6px;margin:8px 0;flex-wrap:wrap}
      #${CFG.PANEL_ID} .addr-tab{width:auto;padding:8px 10px;border:1px solid #334155;border-radius:5px;background:#111827;color:#cbd5e1;cursor:pointer;font-weight:bold}
      #${CFG.PANEL_ID} .addr-tab.active{background:#991b1b;color:#fff;border-color:#ef4444}
      #${CFG.PANEL_ID} .addr-mode{display:none;border:1px solid #273048;border-radius:6px;padding:8px;background:#070b14;margin-bottom:8px}
      #${CFG.PANEL_ID} .addr-mode.active{display:block}
      #${CFG.PANEL_ID} .addr-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
      #${CFG.PANEL_ID} .addr-list .selected{background:#13213b}
      #${CFG.PANEL_ID} code{color:#93c5fd}

    `;
    document.head.appendChild(s);
  }

  function createPanel() {
    const existing = document.getElementById(CFG.PANEL_ID);
    if (existing) return existing;

    const seed = getSessionSeed();
    const today = formatDateYYYYMMDD();
    const past180 = formatDateYYYYMMDD(new Date(Date.now() - 180 * 24 * 60 * 60 * 1000));

    const panel = document.createElement('div');
    panel.id = CFG.PANEL_ID;
    panel.innerHTML = `
      <div class="h">
        <strong>EYS Modülü</strong>
        <div>
          <button class="mini" id="eys_toggle">−</button>
          <button class="mini" id="eys_close" style="color:#ff6b6b">×</button>
        </div>
      </div>
      <div class="w" id="eys_wrap">
        <div class="row">
          <div><label>Kullanıcı ID</label><input id="u_user" value="${seed.user}" disabled></div>
          <div><label>Birim</label><input id="u_birim" value="${seed.birim}" disabled></div>
        </div>

        <div class="tabs">
          <button class="tab-btn active" data-tab="main">Akış</button>
          <button class="tab-btn" data-tab="filtered">Filtreli İşlem</button>
          <button class="tab-btn" data-tab="daily">Günlük PDF</button>
          <button class="tab-btn" data-tab="ygiris">Yoklama Giriş</button>
        </div>

        <div class="tab-page active" data-page="main">
          <div class="row">
            <div><label>Akış başlangıç</label><input id="main_bastar" value="${past180}"></div>
            <div><label>Akış bitiş</label><input id="main_bittar" value="${today}"></div>
          </div>
          <div class="row3">
            <button class="action" id="runBtn" style="background:#3ccf91;color:#00170c">AKIŞI BAŞLAT</button>
            <button class="action" id="memurBtn" style="background:#2d8cff;color:#fff">MEMUR REFRESH AÇ</button>
            <button class="action" id="mudurBtn" style="background:#8b5cf6;color:#fff">MÜDÜR REFRESH AÇ</button>
          </div>
          <button class="action" id="stopBtn" style="background:#cf3c3c;color:#fff;display:none">DURDUR</button>
          <div class="subnote">Bu sekme yalnız kendi tarih alanlarını kullanır. Memur→Müdür ve Müdür→Koordinatör kayıtları tek tek gönderilir; iade kayıtları tekrar gönderilmez.</div>
          <div class="monitor" id="log_main"></div>
        </div>

        <div class="tab-page" data-page="filtered">
          <div class="row3">
            <div>
              <label>Rol</label>
              <select id="filtered_role">
                <option value="20">Müdür</option>
                <option value="10" selected>Memur</option>
              </select>
            </div>
            <div>
              <label>Servis</label>
              <select id="filtered_servis">${serviceOptionsHtml('91')}</select>
            </div>
            <div>
              <label>Aksiyon</label>
              <select id="filtered_action">
                <option value="archive">Arşive Kaldır</option>
                <option value="islem">İşlem Yapıldı</option>
              </select>
            </div>
          </div>
          <div class="row3">
            <div>
              <label>Veri kaynağı</label>
              <select id="filtered_source">${sourceOptionsHtml('2')}</select>
            </div>
            <div>
              <label>Yoklama durumu</label>
              <select id="filtered_ydurum">${ydurumOptionsHtml('60')}</select>
            </div>
            <div>
              <label>İşlem durumu</label>
              <select id="filtered_sonucislem">${sonucIslemOptionsHtml('0')}</select>
            </div>
          </div>
          <div class="row">
            <div><label>Filtre başlangıç <button type="button" class="inline-btn today-mini" id="filtered_bastar_today">Bugün</button></label><input id="filtered_bastar" value="${today}"></div>
            <div><label>Filtre bitiş</label><input id="filtered_bittar" value="${today}"></div>
          </div>
          <div class="row">
            <div><label>VKN Başlangıç</label><input id="filtered_vkn_start" placeholder="0000000000" maxlength="10" value="0000000000"></div>
            <div><label>VKN Bitiş</label><input id="filtered_vkn_end" placeholder="9999999999" maxlength="10" value="9999999999"></div>
          </div>
          <div class="row3">
            <div>
              <label>Görev Yeri</label>
              <select id="filtered_icdis">
                <option value="0" selected>Hepsi (İç ve Dış)</option>
                <option value="1">Sadece Yetki Alanı</option>
                <option value="2">Gelen Dış Yoklama / KAYNAK</option>
                <option value="3">Giden Dış Yoklama / HEDEF</option>
                <option value="4">Yetki Alanı + Gelen Yoklamalar</option>
              </select>
            </div>
            <div><label>Yoklama Kodu</label><input id="filtered_yoklama_kodu" placeholder="örn 20260511Y..."></div>
            <div><label>Benzersiz Kod</label><input id="filtered_benzersiz_kod" placeholder="örn S170QDQSM9"></div>
          </div>
          <div class="row">
            <div><label>Belge Sahibi Koordinatörlük</label><input id="filtered_belge_koor_no" value="${defaultBelgeKoorNo(seed)}" placeholder="örn DKOOR-016-01"></div>
            <div><label>Ünvan içinde geçen kelime</label><input id="filtered_unvan" placeholder="Boş bırakılırsa tümü"></div>
          </div>
          <div class="row">
            <div><label>Kaynak/Hedef İl Kodu</label><input id="filtered_disil" placeholder="örn 001 / boş = tümü" maxlength="3"></div>
            <div><label>Kaynak/Hedef VD Kodu</label><input id="filtered_disvd" placeholder="örn 001250 / boş = tümü" maxlength="6"></div>
          </div>
          <div class="hint">EYS akışına göre icdis=2 kaynak VD, icdis=3 hedef VD mantığıyla çalışır. Kod alanları boşsa EYS ekranındaki gibi disil/disvd boş gönderilir.</div>
          <div class="row3">
            <button class="action" id="filteredQueryBtn" style="background:#22c55e;color:#04140c">SORGULA / LİSTELE</button>
            <button class="action" id="filteredApplyBtn" style="background:#f59e0b;color:#111">SEÇİLİLERE UYGULA</button>
            <button class="action" id="filteredSelectAllBtn" style="background:#2563eb;color:#fff">TÜMÜNÜ SEÇ / KALDIR</button>
          </div>
          <div class="subnote">Listeyi sorgula, çıkan kayıtlardan istediklerini işaretle, sonra seçilenlere arşiv veya işlem yapıldı uygula.</div>
          <div class="list" id="filtered_list"></div>
          <div class="monitor" id="log_filtered"></div>
        </div>


        <div class="tab-page" data-page="ygiris">
          <div class="section-title">Yoklama Temel Bilgileri</div>
          <div class="row3">
            <div>
              <label>Kullanıcı</label>
              <input id="yg_temel_kullanici" readonly placeholder="Oturumdan alınır">
            </div>
            <div>
              <label>İl</label>
              <input id="yg_temel_il" readonly placeholder="Oturumdan alınır">
            </div>
            <div>
              <label>Kaynak</label>
              <input id="yg_temel_kaynak" value="VERGİ DAİRESİ">
            </div>
          </div>

          <div class="row3">
            <div>
              <label>Birim Kodu</label>
              <input id="yg_temel_birim" readonly placeholder="Oturumdan alınır">
            </div>
            <div>
              <label>Kodu</label>
              <input id="yg_temel_kodu" readonly placeholder="Kayıt sonrası dolar">
            </div>
            <div>
              <label>Durumu</label>
              <input id="yg_temel_durumu" readonly placeholder="Kayıt sonrası dolar">
            </div>
          </div>

          <div class="row3">
            <div>
              <label>Rol</label>
              <select id="yg_role">
                <option value="10" selected>Memur</option>
                <option value="20">Müdür</option>
              </select>
            </div>
            <div>
              <label>Servis</label>
              <select id="yg_servis">${serviceOptionsHtml('60')}</select>
            </div>
            <div>
              <label>Bilgi</label>
              <input readonly value="Yoklama türü aşağıdaki Yoklama Bilgileri bölümünde seçilir">
            </div>
          </div>

          <div class="section-title">Mükellef Bilgileri</div>

          <div class="row3">
            <div>
              <label>İhbara Dayalı Yoklama</label>
              <label class="checkline"><input type="checkbox" id="yg_ihbar_dayali"> İhbara dayalı</label>
            </div>
            <div>
              <label>İhbar Kaynağı</label>
              <select id="yg_ihbar_kaynak" disabled>${ihbarKaynakOptionsHtml('BIMER')}</select>
            </div>
            <div>
              <label>İhbarın Tarih/Sayı Bilgisi</label>
              <input id="yg_ihbar_tarih_sayi" disabled placeholder="Örn: 1212 / 07.05.2026">
            </div>
          </div>

          <div class="row3">
            <div><label>VKN / TCKN</label><input id="yg_vkntckn" maxlength="11" placeholder="10 hane VKN veya 11 hane TCKN"></div>
            <div><label>Unvan</label><input id="yg_unvan" placeholder="Sorgu sonrası dolar"></div>
            <div><label>TCKN</label><input id="yg_tckn" maxlength="11" placeholder="Sorgu sonrası dolar"></div>
          </div>

          <div class="row3">
            <div>
              <label>SMS Bilgilendirme</label>
              <select id="yg_sms">
                <option value="1">SMS Gönderilsin</option>
                <option value="0" selected>SMS Gönderilmesin</option>
              </select>
            </div>
            <div><label>Telefon</label><input id="yg_tel" maxlength="10" placeholder="5551234567"></div>
            <div><label>E-posta</label><input id="yg_eposta" placeholder="İsteğe bağlı"></div>
          </div>

          <div class="row3">
            <div>
              <label>Faaliyet Türü</label>
              <div class="radio-line">
                <label><input type="radio" name="yg_faaliyet_turu" id="yg_faaliyet_merkez" value="MERKEZ" checked> Merkeze Bağlı Faaliyet</label>
                <label><input type="radio" name="yg_faaliyet_turu" id="yg_faaliyet_vd" value="VD"> VD’ye Bağlı Faaliyet</label>
              </div>
            </div>
            <div>
              <label>Faaliyet Konusu İçin VD Seçiniz</label>
              <select id="yg_faaliyet_vd_select" disabled><option value="">---</option></select>
            </div>
            <div>
              <label>Faaliyet Konusu</label>
              <select id="yg_faaliyet_select"><option value="">Sorgu sonrası dolar</option></select>
            </div>
          </div>

          <div class="row3">
            <div><label>İşletme/Şirket Türü</label><select id="yg_isletme_turu">${isletmeTuruOptionsHtml('1')}</select></div>
            <div><label>Mükellef Grubu</label><select id="yg_muk_grup">${mukGrupOptionsHtml('1')}</select></div>
            <div><label>Durum</label><input readonly value="İşyeri türü Yoklama Bilgileri bölümünde seçilir"></div>
          </div>

          <div class="section-title">Yoklama Bilgileri</div>

          <div class="row3">
            <div>
              <label>İşyeri Türü</label>
              <div class="radio-line">
                <label><input type="radio" name="yg_isyeri_radio" value="0" checked> Merkez</label>
                <label><input type="radio" name="yg_isyeri_radio" value="1"> Şube</label>
                <label><input type="radio" name="yg_isyeri_radio" value="2"> Depo</label>
                <label><input type="radio" name="yg_isyeri_radio" value="3"> Mesken</label>
                <label><input type="radio" name="yg_isyeri_radio" value="4"> Diğer</label>
              </div>
              <select id="yg_isyeri_turu" style="display:none">${isyeriTuruOptionsHtml('0')}</select>
            </div>
            <div>
              <label>Yoklama Türü</label>
              <select id="yg_yturu">${yoklamaTuruOptionsHtml('10')}</select>
            </div>
            <div>
              <label>Seçilen Akış</label>
              <input id="yg_yturu_label" readonly value="İşe Başlama">
            </div>
          </div>

          <div id="yg_ise_baslama_fields">
            <div id="yg_tur_special_fields"></div>
          </div>
          ${ygCommonAddressHtml()}

          <div id="yg_diger_yoklama_notice" style="display:none" class="notice-box">
            Yoklama türüne göre görünen alan şablonu değişir. Kaydet/Gönder komutları tüm türlere göre detay alanı üretir; kesinleşmeyen türlerde monitör cevabı kontrol edilmelidir.
          </div>

          <div class="row3">
            <div><label>İş Takip OID / No</label><input id="yg_istakip_oid" placeholder="İş Takip satırındaki oid/no"></div>
            <button class="action" id="yg_it_preview_btn" style="background:#475569;color:#fff">İŞ TAKİP ÖNİZLE</button>
            <button class="action" id="yg_old_yoklama_btn" style="background:#7c3aed;color:#fff">ÖNCEKİ YOKLAMALARI GETİR</button>
          </div>
          <div class="list" id="yg_old_list"></div>
          <div class="row3">
            <button class="action" id="yg_it_jobs_btn" style="background:#0369a1;color:#fff">İŞ TAKİP İŞLERİNİ GETİR</button>
            <div><label>İş Takip Liste Limiti</label><input id="yg_it_limit" value="50"></div>
            <div><label>Seçilen İş</label><input id="yg_selected_job_info" readonly placeholder="Listeden iş seçince dolar"></div>
          </div>
          <div class="row3">
            <div><label>İş Takip VKN Başlangıç</label><input id="yg_it_vkn_start" placeholder="örn 0000000000" maxlength="10"></div>
            <div><label>İş Takip VKN Bitiş</label><input id="yg_it_vkn_end" placeholder="örn 3000000000" maxlength="10"></div>
            <div><label>VKN Filtre</label><div class="yg-it-filter-info" id="yg_it_vkn_info">Boşsa tüm iş takip işleri görünür</div></div>
          </div>
          <div class="list" id="yg_it_jobs_list"></div>

          <div class="row3">
            <button class="action" id="yg_lookup_btn" style="background:#2563eb;color:#fff">VKN/ADRES SORGULA</button>
            <div><label>Son Kayıt Kodu</label><input id="yg_son_kayit_kodu" readonly placeholder="Kaydedince dolar"></div>
            <div><label>Son Durum</label><input id="yg_son_kayit_durum" readonly placeholder="Kaydedince dolar"></div>
          </div>
          <div class="bottom-actions">
            <div class="section-title">Alt İşlem Butonları</div>
            <div class="row4">
              <button class="action" id="yg_clear_btn" style="background:#f8fafc;color:#7f1d1d">TEMİZLE (YENİ KAYIT)</button>
              <button class="action" id="yg_save_btn" style="background:#22c55e;color:#04140c">SİSTEME KAYDET</button>
              <button class="action" id="yg_submit_mudur_btn" style="background:#f59e0b;color:#111">MÜDÜR ONAYINA GÖNDER</button>
              <button class="action" id="yg_delete_btn" style="background:#dc2626;color:#fff">KAYDI SİL</button>
            </div>
            <div class="row3">
              <button class="action" id="yg_submit_koor_btn" style="background:#0ea5e9;color:#04111f">KOORDİNATÖRE GÖNDER</button>
              <button class="action" id="yg_direct_ekip_btn" style="background:#8b5cf6;color:#fff">EKİBE DİREKT GÖNDER</button>
              <div><label>Son İşlem</label><input id="yg_son_islem" readonly placeholder="İşlem sonrası dolar"></div>
            </div>
          </div>
          <div class="hint">Yoklama türüne göre EYS’te görünen özel alan şablonları açılır. Kaydet/Gönder komutları tüm yoklama türleri için genel payload mapping ile bağlandı; ilk denemelerde monitördeki komut/cevap kontrol edilmelidir.</div>
          <div class="list" id="yg_summary"></div>
          <div class="monitor" id="log_ygiris"></div>
        </div>


        <div class="tab-page" data-page="daily">
          <div class="row3">
            <div>
              <label>Rol</label>
              <select id="daily_role">
                <option value="20">Müdür</option>
                <option value="10" selected>Memur</option>
              </select>
            </div>
            <div>
              <label>Servis</label>
              <select id="daily_servis">${serviceOptionsHtml('91')}</select>
            </div>
            <div>
              <label>Günlük tarih</label>
              <input id="daily_date" value="${today}">
            </div>
          </div>
          <div class="row3">
            <div>
              <label>Veri kaynağı</label>
              <select id="daily_source">${sourceOptionsHtml('2')}</select>
            </div>
            <div>
              <label>Yoklama durumu</label>
              <select id="daily_ydurum">${ydurumOptionsHtml('60')}</select>
            </div>
            <div>
              <label>İşlem durumu</label>
              <select id="daily_sonucislem">${sonucIslemOptionsHtml('0')}</select>
            </div>
          </div>
          <div class="row">
            <div>
              <label>Yazıcı adı</label>
              <input id="daily_printer" placeholder="Örn: Lexmark_MS811_230">
            </div>
            <div>
              <label>PDF arası bekleme (ms)</label>
              <input id="daily_delay" value="1800">
            </div>
          </div>
          <div class="row">
            <div><label>VKN Başlangıç</label><input id="daily_vkn_start" placeholder="0000000000" maxlength="10" value="0000000000"></div>
            <div><label>VKN Bitiş</label><input id="daily_vkn_end" placeholder="9999999999" maxlength="10" value="9999999999"></div>
          </div>
          <div class="row3">
            <button class="action" id="dailyQueryBtn" style="background:#22c55e;color:#04140c">BUGÜN SORGULA</button>
            <button class="action" id="dailyOpenAllBtn" style="background:#2563eb;color:#fff">TÜM PDF'LERİ AÇ</button>
            <button class="action" id="dailyQueueBtn" style="background:#a855f7;color:#fff">KUYRUK YAZDIR</button>
          </div>
          <div class="hint">Chrome PDF viewer açılır. Bu sürüm PDF sekmesini otomatik print parametresiyle açar; yazıcı seçimi Linux/Chrome politikasına göre değişebilir.</div>
          <div class="list" id="daily_list"></div>
          <div class="monitor" id="log_daily"></div>
        </div>
      </div>
    `;

    document.body.appendChild(panel);
    return panel;
  }


  function eysTryEmbedIntoMainPanel() {
    try {
      const eysPanel = document.getElementById(CFG.PANEL_ID);
      const eysPage = document.getElementById('it_eys_tab_page');
      if (eysPanel && eysPage && eysPanel.parentElement !== eysPage) {
        eysPage.appendChild(eysPanel);
        eysPanel.classList.add('it-embedded-eys');
        if (!document.getElementById('it_tab_eys')?.classList.contains('active')) eysPage.style.display = 'none';
      }
    } catch (_) {}
  }

  function createLogger(box) {
    return (msg, err = false) => {
      const line = `[${new Date().toLocaleTimeString()}] ${msg}`;
      console.log('[EYS-EXT]', line);
      const row = document.createElement('div');
      if (err) row.className = 'err';
      row.textContent = err ? `HATA: ${line}` : line;
      box.appendChild(row);
      box.scrollTop = box.scrollHeight;
    };
  }



  function ygHtmlEscape(v) {
    return String(v ?? '').replace(/[&<>"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
  }

  function ygCheckListHtml(items, prefix) {
    return `<div class="yg-mini-grid">${items.map((t, i) => `<label class="checkline"><input type="checkbox" id="${prefix}_${i}"> ${ygHtmlEscape(t)}</label>`).join('')}</div>`;
  }

  function ygBildirimHtml() {
    return `<div class="row3">
      <div><label>Bildirimde Bulunan</label><select id="yg_bildirim_kendisi"><option value="1" selected>Kendisi</option><option value="0">Yetkili / Diğer</option></select></div>
      <div><label>Serbest Muhasebeci Mali Müşavir</label><select id="yg_smmm"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div>
      <div><label>Açıklama</label><input id="yg_bildirim_aciklama" placeholder="İsteğe bağlı"></div>
    </div>`;
  }

  function ygCalisanHtml() {
    return `<div class="row3">
      <div><label>Asgari Ücretli Sayısı</label><input id="yg_asgari" value="0"></div>
      <div><label>Diğer Ücretli Sayısı</label><input id="yg_diger" value="0"></div>
      <div><label>Toplam</label><input id="yg_toplam_calisan" value="0" readonly></div>
    </div>`;
  }

  function ygMulkiyetKiraHtml(includeKira = true, label = 'İşyeri Mülkiyeti') {
    return `<div class="row3">
      <div><label>${ygHtmlEscape(label)}</label><select id="yg_mulkiyet">${mulkiyetOptionsHtml('2')}</select></div>
      <div><label>Kira Ödeme Şekli</label><select id="yg_kira_sekli"${includeKira ? '' : ' disabled'}>${kiraOdemeSekliOptionsHtml('2')}</select></div>
      <div><label>Kira Ödeme Dönemi</label><select id="yg_kira_donemi"${includeKira ? '' : ' disabled'}>${kiraOdemeDonemiOptionsHtml('2')}</select></div>
    </div>
    <div class="row3">
      <div><label>Kira Tutarı</label><input id="yg_kira_tutari" value="0"${includeKira ? '' : ' disabled'}></div>
      <div><label>Para Birimi</label><select id="yg_para"><option value="1" selected>TL</option></select></div>
      <div><label>Mülk Sahibi VKN/TCKN</label><input id="yg_mulk_vkntckn" maxlength="11" placeholder="VKN veya TCKN"></div>
    </div>
    <div class="row3">
      <button class="action" id="yg_mulk_lookup_btn" style="background:#475569;color:#fff">MÜLK SAHİBİ SORGULA</button>
      <button class="action" id="yg_mulk_add_btn" style="background:#0ea5e9;color:#fff">MÜLK SAHİBİNİ LİSTEYE EKLE</button>
      <button class="action" id="yg_mulk_clear_btn" style="background:#64748b;color:#fff">MÜLK SAHİBİ LİSTESİNİ TEMİZLE</button>
    </div>
    <div class="list" id="yg_mulk_list"></div>`;
  }

  function ygTarihCalisanMulkiyetHtml(label) {
    return `<div class="flow-subtitle">${ygHtmlEscape(label)}</div>
      <div class="row3"><div><label>${ygHtmlEscape(label)} Tarihi</label><input id="yg_ise_tarih" class="yg-date" placeholder="YYYYMMDD"></div><div></div><div></div></div>
      ${ygCalisanHtml()}${ygMulkiyetKiraHtml(true)}${ygBildirimHtml()}`;
  }

  function ygSimpleDateBildirimHtml(label) {
    return `<div class="flow-subtitle">${ygHtmlEscape(label)}</div>
      <div class="row3"><div><label>${ygHtmlEscape(label)} Tarihi</label><input id="yg_ise_tarih" class="yg-date" placeholder="YYYYMMDD"></div><div></div><div></div></div>
      ${ygBildirimHtml()}`;
  }

  function ygAracHtml(title) {
    return `<div class="flow-title danger">${ygHtmlEscape(title)}</div>
      <div class="row3"><div><label>Araç Plaka No</label><input id="yg_arac_plaka"></div><div><label>Şasi Numarası</label><input id="yg_arac_sasi"></div><div><label>Tescil veya Noter Senedi Tarihi</label><input id="yg_arac_tescil_tarihi" class="yg-date" placeholder="YYYYMMDD"></div></div>
      <div class="row3"><div><label>Cins</label><input id="yg_arac_cins"></div><div><label>Marka</label><input id="yg_arac_marka"></div><div><label>Model</label><input id="yg_arac_model"></div></div>
      <div class="row3"><div><label>Mernis Adresi</label><input id="yg_arac_mernis_adres"></div><div><label>Yoklama Adresi Yap</label><select id="yg_arac_yoklama_adresi_yap"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div><div></div></div>`;
  }

  function ygKiraciHtml() {
    return `<div class="flow-title danger">GMSİ (KİRACI)</div>
      <div class="flow-subtitle">Kiracı</div>
      <div class="row3"><div><label>VKN/TCKN</label><input id="yg_kiraci_vkntckn" maxlength="11"></div><div><label>Adı ve Soyadı</label><input id="yg_kiraci_adsoyad"></div><div><label>Kira Ödeme Şekli</label><select id="yg_kiraci_kira_sekli">${kiraOdemeSekliOptionsHtml('1')}</select></div></div>
      <div class="row3"><div><label>Kira Ödeme Dönemi</label><select id="yg_kiraci_kira_donemi">${kiraOdemeDonemiOptionsHtml('1')}</select></div><div><label>Kira Tutarı</label><input id="yg_kiraci_kira_tutari" value="0"></div><div><label>Para Birimi</label><select id="yg_kiraci_para"><option value="1" selected>TL</option></select></div></div>
      <div class="row3"><div><label>Kiracının Bağlı Olduğu VD</label><select id="yg_kiraci_vd"><option value="">---</option></select></div><div><label>Adresler</label><select id="yg_kiraci_adres"><option value="">---</option></select></div><div></div></div>`;
  }

  function ygYoneticiHtml() {
    return `<div class="flow-title danger">2004/13 RE'SEN TERK (YÖNETİCİ)</div>
      <div class="flow-subtitle">Yönetici</div>
      <div class="row3"><div><label>Yönetici VKN/TCKN</label><input id="yg_yonetici_vkntckn" maxlength="11"></div><div><label>Yöneticinin Bağlı Olduğu VD</label><select id="yg_yonetici_vd"><option value="">---</option></select></div><div><label>Adresler</label><select id="yg_yonetici_adres"><option value="">---</option></select></div></div>
      <div class="row3"><div><label>Mernis Adresini Getir</label><select id="yg_yonetici_mernis_getir"><option value="0">Hayır</option><option value="1" selected>Evet</option></select></div><div><label>Yönetici Mernis Adresi</label><input id="yg_yonetici_mernis_adres"></div><div></div></div>`;
  }

  function ygOzelEsasHtml() {
    return `<div class="flow-title danger">ÖZEL ESAS</div><div class="row3"><div><label>İşyeri Mülkiyeti</label><select id="yg_mulkiyet">${mulkiyetOptionsHtml('1')}</select></div><div></div><div></div></div>`;
  }

  function ygSerbestHtml() {
    return `<div class="flow-title danger">SERBEST YOKLAMA</div>
      ${ygCheckListHtml(['Mülkiyet Bilgisi','Faaliyet Tespiti','Çalışan Tespiti','ÖKC Tespiti','POS Tespiti','Demirbaş Tespiti','Vergi Levhası Kontrolü','Son Düzenlenen Belgeler','Z Raporları Kontrolü','Belge İhlalleri Kontrolü','NACE Kodu Değişikliği'], 'yg_serbest')}`;
  }

  function ygTurSpecialTemplate(type, label) {
    const t = String(type || '10');
    const txt = label || 'Yoklama';
    if (t === '10') return `<div class="flow-title danger">İŞE BAŞLAMA</div>${ygTarihCalisanMulkiyetHtml('İşe Başlama')}`;
    if (t === 'NAKIL_ISE_BASLAMA') return `<div class="flow-title danger">NAKİL İŞE BAŞLAMA</div>${ygTarihCalisanMulkiyetHtml('Nakil İşe Başlama')}`;
    if (t === 'ADRES_DEGISIKLIGI') return `<div class="flow-title danger">ADRES DEĞİŞİKLİĞİ</div><div class="row3"><div><label>Bildirilen Adres Değişiklik Tarihi</label><input id="yg_ise_tarih" class="yg-date" placeholder="YYYYMMDD"></div><div></div><div></div></div>${ygCalisanHtml()}${ygMulkiyetKiraHtml(false, 'İşyeri Mülkiyeti')}<div class="row3"><div><label>Emlak Vergi Değeri</label><input id="yg_emlak_degeri" value="0"></div><div><label>Emlak Sahibi VKN/TCKN</label><input id="yg_emlak_sahibi_vkntckn" maxlength="11"></div><div></div></div>${ygBildirimHtml()}`;
    if (t === 'SUBE_ACILIS') return `<div class="flow-title danger">ŞUBE AÇILIŞI</div><div class="row3"><div><label>Mükellefiyet Türü</label><select id="yg_mukellefiyet_turu"><option value="1" selected>Mükellefiyetli</option><option value="0">Mükellefiyetsiz</option></select></div><div><label>Şube İşe Başlama Tarihi</label><input id="yg_ise_tarih" class="yg-date" placeholder="YYYYMMDD"></div><div></div></div>${ygCalisanHtml()}${ygMulkiyetKiraHtml(false, 'İşyeri Mülkiyeti')}${ygBildirimHtml()}`;
    if (t === 'EK_ISE_BASLAMA') return `<div class="flow-title danger">EK İŞE BAŞLAMA</div>${ygSimpleDateBildirimHtml('Ek İşe Başlama')}`;
    if (t === 'EK_ISI_BIRAKMA') return `<div class="flow-title danger">EK İŞİ BIRAKMA</div>${ygSimpleDateBildirimHtml('Ek İşi Bırakma')}`;
    if (t === 'ISI_BIRAKMA') return `<div class="flow-title danger">İŞİ BIRAKMA</div>${ygSimpleDateBildirimHtml('İşi Bırakma')}`;
    if (t === 'NAKIL_ISI_BIRAKMA') return `<div class="flow-title danger">NAKİL İŞİ BIRAKMA</div>${ygSimpleDateBildirimHtml('Nakil İşi Bırakma')}`;
    if (t === 'SUBE_KAPANIS') return `<div class="flow-title danger">ŞUBE KAPANIŞI</div>${ygSimpleDateBildirimHtml('Şube Kapanış')}`;
    if (t === 'TUZEL_ACILIS') return `<div class="flow-title danger">E-ORTAMDA TÜZEL İŞE BAŞLAMA</div><div class="row3"><div><label>İşe Başlama Tarihi</label><input id="yg_ise_tarih" class="yg-date" placeholder="YYYYMMDD"></div><div></div><div></div></div>`;
    if (t === 'NAKIL_VASITALARI') return ygAracHtml('ARAÇ BİLGİLERİ');
    if (t === 'NAKIL_VASITALARI_TERK') return ygAracHtml('TERK ARAÇ BİLGİLERİ');
    if (t === 'GMSI_MULK_SAHIBI') return `<div class="flow-title danger">GMSİ (MÜLK SAHİBİ)</div><div class="row3"><div><label>Mülk Sahibi Kiralık Gayrimenkulleri</label><select id="yg_gmsi_mulk_gayrimenkul"><option value="">---</option></select></div><div></div><div></div></div>`;
    if (t === 'GMSI_KIRACI') return ygKiraciHtml();
    if (t === 'RESEN_TERK_SIRKET') return ygYoneticiHtml();
    if (t === 'KDV_INCELEME' || t === 'VUK_160A') return ygOzelEsasHtml();
    if (t === 'SERBEST') return ygSerbestHtml();
    return `<div class="flow-title muted">${ygHtmlEscape(txt).toUpperCase()}</div><div class="notice-box">Bu yoklama türünde özel üst alan görünmüyor; Yoklama Adresi, Dış Görev Bilgisi ve Yoklama Açıklama alanları kullanılır.</div>`;
  }

  function ygCommonAddressHtml() {
    return `<div id="yg_common_adres_fields">
      <div class="section-title">Yoklama Adresi</div>

      <div class="card addr-card">
        <div class="mutedtitle">Mükellefin Bilinen Adresleri</div>
        <div class="row3">
          <div><label>Vergi Dairesi</label><select id="yg_bilinen_vd"><option value="">Sorgu sonrası dolar</option></select></div>
          <button class="action" id="yg_bilinen_adres_getir_btn" style="background:#475569;color:#fff">BİLİNEN ADRESLERİ GETİR</button>
          <div><label>Seçilen Adres No</label><input id="yg_bilinen_adres_secili" readonly placeholder="Tablodan seçilince dolar"></div>
        </div>
        <div class="tiny">VD seçilince EYS’teki gibi <code>srvcRemoteCall_getVdAdresleri</code> sorgusu atılır; ADRESSTRING/ADRESNO tabloya düşer.</div>
        <div class="list addr-list" id="yg_bilinen_adres_list"></div>
      </div>

      <div class="section-title">Adres Belirleme</div>
      <div class="addr-tabs">
        <button type="button" class="addr-tab active" data-addr-mode="ililce">İl-İlçe Merkezi</button>
        <button type="button" class="addr-tab" data-addr-mode="belediye">Belediye Adresi</button>
        <button type="button" class="addr-tab" data-addr-mode="koy">Köy Adresi</button>
      </div>

      <div class="addr-mode active" data-addr-panel="ililce">
        <div class="flow-subtitle">İl-İlçe Merkezi</div>
        <div class="addr-grid">
          <div>
            <div><label>İl</label><select id="yg_il"><option value="">---</option></select></div>
            <div><label>İlçe</label><select id="yg_ilce"><option value="">---</option></select></div>
            <div><label>Mahalle</label><select id="yg_mahalle"><option value="">---</option></select></div>
            <div><label>Mernis Adres No</label><input id="yg_adres_no" placeholder="Mernis Adres No"></div>
            <label class="checkline"><input type="checkbox" id="yg_adres_yetersiz_check"> Adres Yetersizdir</label>
            <div><label>Adres Açıklama</label><input id="yg_aciklama" placeholder="Adres açıklama / telefon"></div>
          </div>
          <div>
            <div><label>CSBM</label><select id="yg_csbm"><option value="">---</option></select></div>
            <div><label>Dışkapı No</label><select id="yg_diskapi"><option value="">---</option></select></div>
            <div><label>İçkapı No</label><select id="yg_ickapi"><option value="">---</option></select></div>
            <div><label>Mernis Adres Text</label><input id="yg_adres_text" placeholder="Adres text"></div>
          </div>
        </div>
      </div>

      <div class="addr-mode" data-addr-panel="belediye">
        <div class="flow-subtitle">Belediye Adresi</div>
        <div class="addr-grid">
          <div>
            <div><label>İl</label><select id="yg_bel_il"><option value="">---</option></select></div>
            <div><label>İlçe</label><select id="yg_bel_ilce"><option value="">---</option></select></div>
            <div><label>Bucak</label><select id="yg_bel_bucak"><option value="">---</option></select></div>
            <div><label>Belde</label><select id="yg_bel_belde"><option value="">---</option></select></div>
            <div><label>Mernis Adres No</label><input id="yg_adres_no_bel" placeholder="Mernis Adres No"></div>
            <label class="checkline"><input type="checkbox" id="yg_adres_yetersiz_bel"> Adres Yetersizdir</label>
            <div><label>Adres Açıklama</label><input id="yg_aciklama_bel" placeholder="Adres açıklama"></div>
          </div>
          <div>
            <div><label>Mahalle</label><select id="yg_bel_mahalle"><option value="">---</option></select></div>
            <div><label>CSBM</label><select id="yg_bel_csbm"><option value="">---</option></select></div>
            <div><label>Dışkapı No</label><select id="yg_bel_diskapi"><option value="">---</option></select></div>
            <div><label>İçkapı No</label><select id="yg_bel_ickapi"><option value="">---</option></select></div>
            <div><label>Mernis Adres Text</label><input id="yg_adres_text_bel" placeholder="Mernis adres text"></div>
          </div>
        </div>
      </div>

      <div class="addr-mode" data-addr-panel="koy">
        <div class="flow-subtitle">Köy Adresi</div>
        <div class="addr-grid">
          <div>
            <div><label>İl</label><select id="yg_koy_il"><option value="">---</option></select></div>
            <div><label>İlçe</label><select id="yg_koy_ilce"><option value="">---</option></select></div>
            <div><label>Bucak</label><select id="yg_koy_bucak"><option value="">---</option></select></div>
            <div><label>Köy</label><select id="yg_koy_koy"><option value="">---</option></select></div>
            <div><label>Mernis Adres No</label><input id="yg_adres_no_koy" placeholder="Mernis Adres No"></div>
            <label class="checkline"><input type="checkbox" id="yg_adres_yetersiz_koy"> Adres Yetersizdir</label>
            <div><label>Adres Açıklama</label><input id="yg_aciklama_koy" placeholder="Adres açıklama"></div>
          </div>
          <div>
            <div><label>Mevki/Mezra</label><select id="yg_koy_mevki"><option value="">---</option></select></div>
            <div><label>CSBM</label><select id="yg_koy_csbm"><option value="">---</option></select></div>
            <div><label>Dışkapı No</label><select id="yg_koy_diskapi"><option value="">---</option></select></div>
            <div><label>İçkapı No</label><select id="yg_koy_ickapi"><option value="">---</option></select></div>
            <div><label>Mernis Adres Text</label><input id="yg_adres_text_koy" placeholder="Mernis adres text"></div>
          </div>
        </div>
      </div>

      <input type="hidden" id="yg_adres_yetersiz" value="0">
      <div class="row3">
        <button class="action" id="yg_adres_fetch_btn" style="background:#475569;color:#fff">AKTİF ADRES NO / SEÇİM SORGULA</button>
        <div><label>Aktif Adres Modu</label><input id="yg_adres_mode_label" readonly value="İl-İlçe Merkezi"></div>
        <div><label>Yoklama Adresi Kaynağı</label><input id="yg_adres_source" readonly value="Manuel / bilinen adres seçilmedi"></div>
      </div>

      <div class="section-title">Dış Görev Bilgisi</div>
      <div class="row3"><div><label>Bu bir dış görevdir</label><select id="yg_dis_gorev"><option value="0" selected>Hayır</option><option value="1">Evet</option></select></div><div><label>Dış Görevin Yapılacağı Vergi Dairesi</label><select id="yg_dis_gorev_vd"><option value="">---</option></select></div><div><label>Yetki Alanlarından Tespit Edilen</label><select id="yg_yetki_tespit"><option value="">---</option></select></div></div>
      <div class="section-title">Yoklama Açıklama</div>
      <div class="row"><div><label>Açıklama</label><input id="yg_yoklama_aciklama" placeholder="Yoklama açıklama alanı. İstenilen uzunlukta girilebilir"></div></div>
    </div>`;
  }
  class EysFullBot {
    constructor(panel) {
      this.panel = panel;
      this.logs = {
        main: createLogger(panel.querySelector('#log_main')),
        filtered: createLogger(panel.querySelector('#log_filtered')),
        daily: createLogger(panel.querySelector('#log_daily')),
        ygiris: createLogger(panel.querySelector('#log_ygiris'))
      };
      this.running = false;
      this.timer = null;
      this.inFlight = false;
      this.filteredInFlight = false;
      this.dailyInFlight = false;
      this.dailyQueueInFlight = false;
      this.cycleNo = 0;
      this.sideUrl = null;
      this.dailyRows = [];
      this.filteredRows = [];
      this.filteredSelectAllState = false;
      this.ygLookup = null;
      this.ygLastYkodu = '';
      this.ygMulkSahipleri = [];
      this.ygMulkCurrent = null;
      this.ygItJobs = [];
      this.ygAutoTimers = {};
      this.applyEysDefaultSelections();
      this.bind();
    }

    log(tab, msg, err = false) {
      (this.logs[tab] || this.logs.main)(msg, err);
    }

    bind() {
      this.panel.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', () => this.activateTab(btn.dataset.tab)));
      this.panel.querySelector('#runBtn').addEventListener('click', () => this.start());
      this.panel.querySelector('#stopBtn').addEventListener('click', () => this.stop());
      const oldFilteredBtn = this.panel.querySelector('#filteredBtn');
      if (oldFilteredBtn) oldFilteredBtn.addEventListener('click', () => this.runFilteredWorkflow());
      
      const filteredTodayBtn = this.panel.querySelector('#filtered_bastar_today');
      if (filteredTodayBtn) {
        filteredTodayBtn.addEventListener('click', () => {
          const el = this.panel.querySelector('#filtered_bastar');
          if (el) {
            el.value = eysTodayYYYYMMDD();
            this.log('filtered', `Filtre başlangıç bugüne alındı: ${el.value}`);
          }
        });
      }

      const filteredQueryBtn = this.panel.querySelector('#filteredQueryBtn');
      if (filteredQueryBtn) filteredQueryBtn.addEventListener('click', () => this.runFilteredQueryOnly());
      const filteredApplyBtn = this.panel.querySelector('#filteredApplyBtn');
      if (filteredApplyBtn) filteredApplyBtn.addEventListener('click', () => this.applySelectedFilteredRows());
      const filteredSelectAllBtn = this.panel.querySelector('#filteredSelectAllBtn');
      if (filteredSelectAllBtn) filteredSelectAllBtn.addEventListener('click', () => this.toggleFilteredSelection());
      this.panel.querySelector('#dailyQueryBtn').addEventListener('click', () => this.runDailyQuery());
      this.panel.querySelector('#dailyOpenAllBtn').addEventListener('click', () => this.openAllDailyPdfs());
      this.panel.querySelector('#dailyQueueBtn').addEventListener('click', () => this.queuePrintDailyPdfs());

      
      const ygItPreviewBtn = this.panel.querySelector('#yg_it_preview_btn');
      if (ygItPreviewBtn) ygItPreviewBtn.addEventListener('click', () => this.openYgIsTakipPreview());
      const ygOldBtn = this.panel.querySelector('#yg_old_yoklama_btn');
      if (ygOldBtn) ygOldBtn.addEventListener('click', () => this.fetchYgOldYoklamalar());
      const ygItOid = this.panel.querySelector('#yg_istakip_oid');
      if (ygItOid) ygItOid.addEventListener('input', () => { ygItOid.value = ygItOid.value.trim(); });
      ['#yg_it_vkn_start','#yg_it_vkn_end'].forEach(sel => {
        const el = this.panel.querySelector(sel);
        if (el) el.addEventListener('input', () => {
          el.value = this.onlyDigits ? this.onlyDigits(el.value).slice(0, 10) : String(el.value || '').replace(/\D+/g, '').slice(0, 10);
          this.renderYgItJobs();
        });
      });

      const ygLookupBtn = this.panel.querySelector('#yg_lookup_btn');
      if (ygLookupBtn) ygLookupBtn.addEventListener('click', () => this.lookupYoklamaGiris());
      const ygSaveBtn = this.panel.querySelector('#yg_save_btn');
      if (ygSaveBtn) ygSaveBtn.addEventListener('click', () => this.saveYoklamaGiris());
      const ygSubmitBtn = this.panel.querySelector('#yg_submit_mudur_btn');
      if (ygSubmitBtn) ygSubmitBtn.addEventListener('click', () => this.submitYoklamaGirisMudur());
      const ygSubmitKoorBtn = this.panel.querySelector('#yg_submit_koor_btn');
      if (ygSubmitKoorBtn) ygSubmitKoorBtn.addEventListener('click', () => this.submitYoklamaGirisKoor());
      const ygDirectEkipBtn = this.panel.querySelector('#yg_direct_ekip_btn');
      if (ygDirectEkipBtn) ygDirectEkipBtn.addEventListener('click', () => this.submitYoklamaGirisDirectEkip());
      const ygClearBtn = this.panel.querySelector('#yg_clear_btn');
      if (ygClearBtn) ygClearBtn.addEventListener('click', () => this.clearYoklamaGirisForm());
      const ygDeleteBtn = this.panel.querySelector('#yg_delete_btn');
      if (ygDeleteBtn) ygDeleteBtn.addEventListener('click', () => this.deleteYoklamaGirisNative());
      ['#yg_vkntckn','#yg_tckn','#yg_tel','#yg_mulk_vkntckn','#yg_adres_no','#yg_it_limit'].forEach(sel => {
        const el = this.panel.querySelector(sel);
        if (el) el.addEventListener('input', () => {
          const max = sel === '#yg_tel' ? 10 : (sel === '#yg_adres_no' ? 20 : (sel === '#yg_it_limit' ? 4 : 11));
          el.value = this.onlyDigits(el.value).slice(0, max);
        });
      });

      const mainNo = this.panel.querySelector('#yg_vkntckn');
      if (mainNo) {
        mainNo.addEventListener('input', () => {
          clearTimeout(this.ygAutoTimers.mainNo);
          if (this.onlyDigits(mainNo.value).length === 10 || this.onlyDigits(mainNo.value).length === 11) {
            this.ygAutoTimers.mainNo = setTimeout(() => this.lookupYoklamaGiris(), 650);
          }
        });
        mainNo.addEventListener('blur', () => {
          if (this.onlyDigits(mainNo.value).length === 10 || this.onlyDigits(mainNo.value).length === 11) this.lookupYoklamaGiris();
        });
      }

      const adresNo = this.panel.querySelector('#yg_adres_no');
      if (adresNo) {
        adresNo.addEventListener('input', () => {
          clearTimeout(this.ygAutoTimers.adresNo);
          if (this.onlyDigits(adresNo.value).length >= 7) {
            this.ygAutoTimers.adresNo = setTimeout(() => this.lookupYgAdresNo(), 700);
          }
        });
        adresNo.addEventListener('blur', () => {
          if (this.onlyDigits(adresNo.value).length >= 7) this.lookupYgAdresNo();
        });
      }

      const mulkNo = this.panel.querySelector('#yg_mulk_vkntckn');
      if (mulkNo) {
        mulkNo.addEventListener('input', () => {
          clearTimeout(this.ygAutoTimers.mulkNo);
          if (this.onlyDigits(mulkNo.value).length === 10 || this.onlyDigits(mulkNo.value).length === 11) {
            this.ygAutoTimers.mulkNo = setTimeout(() => this.lookupYgMulkSahibi(), 650);
          }
        });
        mulkNo.addEventListener('blur', () => {
          if (this.onlyDigits(mulkNo.value).length === 10 || this.onlyDigits(mulkNo.value).length === 11) this.lookupYgMulkSahibi();
        });
      }

      const bilinenBtn = this.panel.querySelector('#yg_bilinen_adres_getir_btn');
      if (bilinenBtn) bilinenBtn.addEventListener('click', () => this.loadYgKnownAddressesForSelectedVd());
      const bilinenVd = this.panel.querySelector('#yg_bilinen_vd');
      if (bilinenVd) bilinenVd.addEventListener('change', () => this.loadYgKnownAddressesForSelectedVd()); // yg_bilinen_vd_auto

      this.bindYgAddressModeEvents();
      ['#yg_adres_no_bel','#yg_adres_no_koy'].forEach(sel => {
        const el = this.panel.querySelector(sel);
        if (el) el.addEventListener('input', () => {
          el.value = this.onlyDigits(el.value).slice(0, 20);
          clearTimeout(this.ygAutoTimers[sel]);
          if (el.value.length >= 7 && this.getYgAddressMode() !== 'ililce') this.ygAutoTimers[sel] = setTimeout(() => this.lookupYgAdresNo(), 700);
        });
      });
      const adresFetchBtn = this.panel.querySelector('#yg_adres_fetch_btn');
      if (adresFetchBtn) adresFetchBtn.addEventListener('click', () => this.lookupYgAdresNo());
      const mulkLookupBtn = this.panel.querySelector('#yg_mulk_lookup_btn');
      if (mulkLookupBtn) mulkLookupBtn.addEventListener('click', () => this.lookupYgMulkSahibi());
      const mulkAddBtn = this.panel.querySelector('#yg_mulk_add_btn');
      if (mulkAddBtn) mulkAddBtn.addEventListener('click', () => this.addYgMulkSahibi());
      const mulkClearBtn = this.panel.querySelector('#yg_mulk_clear_btn');
      if (mulkClearBtn) mulkClearBtn.addEventListener('click', () => { this.ygMulkSahipleri = []; this.renderYgMulkList(); });
      const itJobsBtn = this.panel.querySelector('#yg_it_jobs_btn');
      if (itJobsBtn) itJobsBtn.addEventListener('click', () => this.fetchYgItJobs());
      const ygSummary = this.panel.querySelector('#yg_summary');
      if (ygSummary) ygSummary.addEventListener('click', () => ygSummary.classList.toggle('expanded'));
      const ygLog = this.panel.querySelector('#log_ygiris');
      if (ygLog) ygLog.addEventListener('click', () => ygLog.classList.toggle('expanded'));

      const il = this.panel.querySelector('#yg_il');
      const ilce = this.panel.querySelector('#yg_ilce');
      const mahalle = this.panel.querySelector('#yg_mahalle');
      const csbm = this.panel.querySelector('#yg_csbm');
      const diskapi = this.panel.querySelector('#yg_diskapi');
      const ickapi = this.panel.querySelector('#yg_ickapi');
      if (il) il.addEventListener('change', () => this.loadYgCombo('yg_ilce', 2, il.value, ['kod'], ['ad']));
      if (ilce) ilce.addEventListener('change', () => this.loadYgCombo('yg_mahalle', 3, ilce.value, ['value'], ['text']));
      if (mahalle) mahalle.addEventListener('change', () => this.loadYgCombo('yg_csbm', 4, mahalle.value, ['value'], ['text']));
      if (csbm) csbm.addEventListener('change', () => this.loadYgCombo('yg_diskapi', 5, csbm.value, ['value'], ['disKapiNo','text']));
      if (diskapi) diskapi.addEventListener('change', () => this.loadYgCombo('yg_ickapi', 6, diskapi.value, ['adresNo'], ['icKapiNo','text']));
      if (ickapi) ickapi.addEventListener('change', () => {
        if (ickapi.value) {
          this.setYgField('yg_adres_no', ickapi.value);
          this.lookupYgAdresNo();
        }
      });

      setTimeout(() => this.loadYgIlList(), 700);


      this.fillYgTemelBilgileri();
      const ygRoleSel = this.panel.querySelector('#yg_role');
      if (ygRoleSel) ygRoleSel.addEventListener('change', () => this.fillYgTemelBilgileri());
      const ygServisSel = this.panel.querySelector('#yg_servis');
      if (ygServisSel) ygServisSel.addEventListener('change', () => {
        this.log('ygiris', `Servis seçildi: ${ygServisSel.value} — ${ygServisSel.selectedOptions?.[0]?.textContent || ''}`);
      });

      

      const fMerkez = this.panel.querySelector('#yg_faaliyet_merkez');
      const fVd = this.panel.querySelector('#yg_faaliyet_vd');
      const fVdSel = this.panel.querySelector('#yg_faaliyet_vd_select');
      const fSel = this.panel.querySelector('#yg_faaliyet_select');
      if (fMerkez) fMerkez.addEventListener('change', () => this.updateYgFaaliyetTuruUi());
      if (fVd) fVd.addEventListener('change', () => this.updateYgFaaliyetTuruUi());
      if (fVdSel) fVdSel.addEventListener('change', () => this.loadYgFaaliyetForSelectedType());
      if (fSel) fSel.addEventListener('change', () => {
        const opt = fSel.selectedOptions?.[0];
        this.ygLookup = this.ygLookup || {};
        this.ygLookup.faaliyet = Object.assign({}, this.ygLookup.faaliyet || {}, { value: fSel.value, text: opt?.textContent || '' });
      });

            const ihbarChk = this.panel.querySelector('#yg_ihbar_dayali');
      const ihbarKaynak = this.panel.querySelector('#yg_ihbar_kaynak');
      const ihbarTarihSayi = this.panel.querySelector('#yg_ihbar_tarih_sayi');
      const updateIhbarEnabled = () => {
        const on = !!ihbarChk?.checked;
        if (ihbarKaynak) ihbarKaynak.disabled = !on;
        if (ihbarTarihSayi) ihbarTarihSayi.disabled = !on;
        if (!on && ihbarTarihSayi) ihbarTarihSayi.value = '';
      };
      if (ihbarChk) {
        ihbarChk.addEventListener('change', updateIhbarEnabled);
        updateIhbarEnabled();
      }

      
      const ygYturu = this.panel.querySelector('#yg_yturu');
      if (ygYturu) ygYturu.addEventListener('change', () => this.updateYgYoklamaBilgileriUi());
      this.panel.querySelectorAll('input[name="yg_isyeri_radio"]').forEach(r => {
        r.addEventListener('change', () => this.syncYgIsyeriRadioToSelect());
      });
      this.syncYgIsyeriRadioToSelect();
      this.updateYgYoklamaBilgileriUi();

            const ygDate = this.panel.querySelector('#yg_ise_tarih');
      if (ygDate && !ygDate.value) ygDate.value = eysTodayYYYYMMDD();

      ['#daily_vkn_start','#daily_vkn_end'].forEach(sel => {
        const el = this.panel.querySelector(sel);
        if (el) el.addEventListener('input', () => {
          el.value = (this.onlyDigits ? this.onlyDigits(el.value) : String(el.value || '').replace(/\D+/g, '')).slice(0, 10);
          this.renderDailyList();
        });
      });
      ['#filtered_vkn_start','#filtered_vkn_end'].forEach(sel => {
        const el = this.panel.querySelector(sel);
        if (el) el.addEventListener('input', () => {
          el.value = (this.onlyDigits ? this.onlyDigits(el.value) : String(el.value || '').replace(/\D+/g, '')).slice(0, 10);
        });
      });
      this.panel.querySelector('#memurBtn').addEventListener('click', async () => {
        await eysStorageSet(CFG.STORAGE_KEY, { role: '10', t: Date.now() });
        this.log('main', 'Memur için refresh başlatılıyor...');
        location.reload();
      });
      this.panel.querySelector('#mudurBtn').addEventListener('click', async () => {
        await eysStorageSet(CFG.STORAGE_KEY, { role: '20', t: Date.now() });
        this.log('main', 'Müdür için refresh başlatılıyor...');
        location.reload();
      });
      this.panel.querySelector('#eys_toggle').addEventListener('click', () => {
        const wrap = this.panel.querySelector('#eys_wrap');
        wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
      });
      this.panel.querySelector('#eys_close').addEventListener('click', () => {
        this.stop();
        this.panel.remove();
      });
    }

    activateTab(tab) {
      this.panel.querySelectorAll('.tab-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
      this.panel.querySelectorAll('.tab-page').forEach(page => page.classList.toggle('active', page.dataset.page === tab));
    }

    setButtons(running) {
      this.panel.querySelector('#runBtn').style.display = running ? 'none' : 'block';
      this.panel.querySelector('#stopBtn').style.display = running ? 'block' : 'none';
    }

    getMainConfig() {
      return {
        bastar: this.panel.querySelector('#main_bastar').value.trim(),
        bittar: this.panel.querySelector('#main_bittar').value.trim()
      };
    }

    getFilteredConfig() {
      return {
        role: this.panel.querySelector('#filtered_role').value.trim() || '10',
        servis: this.panel.querySelector('#filtered_servis').value.trim(),
        action: this.panel.querySelector('#filtered_action').value.trim(),
        source: this.panel.querySelector('#filtered_source')?.value ?? '0',
        ydurum: this.panel.querySelector('#filtered_ydurum')?.value ?? '',
        sonucislem: this.panel.querySelector('#filtered_sonucislem')?.value ?? '1',
        bastar: this.panel.querySelector('#filtered_bastar').value.trim(),
        bittar: this.panel.querySelector('#filtered_bittar').value.trim(),
        vknStart: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#filtered_vkn_start')?.value || '') : String(this.panel.querySelector('#filtered_vkn_start')?.value || '').replace(/\D+/g, '')).slice(0, 10),
        vknEnd: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#filtered_vkn_end')?.value || '') : String(this.panel.querySelector('#filtered_vkn_end')?.value || '').replace(/\D+/g, '')).slice(0, 10),
        icdis: this.panel.querySelector('#filtered_icdis')?.value ?? '0',
        yoklamaKodu: String(this.panel.querySelector('#filtered_yoklama_kodu')?.value || '').trim(),
        benzersizKod: String(this.panel.querySelector('#filtered_benzersiz_kod')?.value || '').trim(),
        belgeKoorNo: String(this.panel.querySelector('#filtered_belge_koor_no')?.value || '').trim(),
        unvan: String(this.panel.querySelector('#filtered_unvan')?.value || '').trim(),
        disil: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#filtered_disil')?.value || '') : String(this.panel.querySelector('#filtered_disil')?.value || '').replace(/\D+/g, '')).slice(0, 3),
        disvd: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#filtered_disvd')?.value || '') : String(this.panel.querySelector('#filtered_disvd')?.value || '').replace(/\D+/g, '')).slice(0, 6),
        useFallback: false
      };
    }

    getDailyConfig() {
      return {
        role: this.panel.querySelector('#daily_role').value.trim() || '20',
        servis: this.panel.querySelector('#daily_servis').value.trim(),
        date: this.panel.querySelector('#daily_date').value.trim(),
        source: this.panel.querySelector('#daily_source')?.value ?? '2',
        ydurum: this.panel.querySelector('#daily_ydurum')?.value ?? '60',
        sonucislem: this.panel.querySelector('#daily_sonucislem')?.value ?? '0',
        printer: this.panel.querySelector('#daily_printer').value.trim(),
        delay: Number(this.panel.querySelector('#daily_delay').value.trim() || '1800') || 1800,
        icdis: '0',
        unvan: '',
        vknStart: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#daily_vkn_start')?.value || '') : String(this.panel.querySelector('#daily_vkn_start')?.value || '').replace(/\D+/g, '')).slice(0, 10),
        vknEnd: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#daily_vkn_end')?.value || '') : String(this.panel.querySelector('#daily_vkn_end')?.value || '').replace(/\D+/g, '')).slice(0, 10),
        useFallback: false
      };
    }


    onlyDigits(v) {
      return String(v || '').replace(/\D+/g, '');
    }

    rowVkn(row) {
      const raw = String(row?.vkn || row?.vkntckn || row?.tckn || row?.tcKimlikNo || row?.vergiNo || '');
      const nums = raw.match(/\d{10,11}/g) || [];
      return nums.find(x => String(x).length === 10) || '';
    }

    inVknRange(vkn, start, end) {
      start = this.onlyDigits(start || '').slice(0, 10);
      end = this.onlyDigits(end || '').slice(0, 10);
      if (!start && !end) return true;
      if (!vkn || String(vkn).length !== 10) return false;
      if (start && !end) return String(vkn) >= start;
      if (!start && end) return String(vkn) <= end;
      return String(vkn) >= start && String(vkn) <= end;
    }

    filterRowsByVkn(rows, cfg) {
      const start = this.onlyDigits(cfg?.vknStart || '').slice(0, 10);
      const end = this.onlyDigits(cfg?.vknEnd || '').slice(0, 10);
      const exactCodeSearch = String(cfg?.yoklamaKodu || cfg?.benzersizKod || '').trim();
      const isFullDefaultRange = (!start && !end) || (start === '0000000000' && end === '9999999999');
      if (exactCodeSearch || isFullDefaultRange) return rows || [];
      return (rows || []).filter(row => this.inVknRange(this.rowVkn(row), start, end));
    }

    selectedFilteredRows() {
      const box = this.panel.querySelector('#filtered_list');
      if (!box) return [];
      const checked = Array.from(box.querySelectorAll('input[data-fidx]:checked'))
        .map(x => Number(x.dataset.fidx))
        .filter(n => Number.isFinite(n));
      return checked.map(i => this.filteredRows[i]).filter(Boolean);
    }

    renderFilteredList() {
      const box = this.panel.querySelector('#filtered_list');
      if (!box) return;
      box.innerHTML = '';
      if (!this.filteredRows || !this.filteredRows.length) {
        box.innerHTML = '<div class="list-row"><span class="tiny">Kayıt yok.</span></div>';
        return;
      }
      this.filteredRows.forEach((row, index) => {
        const div = document.createElement('div');
        div.className = 'result-row';
        div.innerHTML = `
          <div><input type="checkbox" data-fidx="${index}"></div>
          <div>
            <div><strong class="code">${row.ykodu || '-'}</strong></div>
            <div class="meta">VKN: ${row.vkn || '-'} | TCKN: ${row.tckn || '-'} | servis=${row.servis || '-'} | durum=${row.durum || '-'} | benzersiz=${row.benzersizKod || '-'} | ${row.unvan || ''}</div>
          </div>
          <div class="result-actions">
            <button type="button" data-open-filtered="${index}">PDF Aç</button>
          </div>`;
        box.appendChild(div);
      });
      box.querySelectorAll('[data-open-filtered]').forEach(btn => {
        btn.addEventListener('click', () => this.openFilteredPdf(Number(btn.dataset.openFiltered)));
      });
    }

    openFilteredPdf(index) {
      const row = this.filteredRows?.[index];
      if (!row || !row.ykodu) return this.log('filtered', 'PDF için yKodu bulunamadı.', true);
      const url = this.buildPdfUrl(row.ykodu);
      this.log('filtered', `PDF açılıyor: ${row.ykodu}`);
      eysOpenPdfPopup(url);
    }

    toggleFilteredSelection() {
      const box = this.panel.querySelector('#filtered_list');
      if (!box) return;
      this.filteredSelectAllState = !this.filteredSelectAllState;
      box.querySelectorAll('input[data-fidx]').forEach(x => x.checked = this.filteredSelectAllState);
      this.log('filtered', this.filteredSelectAllState ? 'Tüm kayıtlar seçildi.' : 'Seçimler kaldırıldı.');
    }

    async runFilteredQueryOnly() {
      if (this.filteredInFlight) return this.log('filtered', 'Filtreli sorgu zaten çalışıyor.');
      const cfg = this.getFilteredConfig();
      if (!cfg.bastar || !cfg.bittar) return this.log('filtered', 'Tarih alanları boş bırakılamaz.', true);
      this.filteredInFlight = true;
      try {
        const roleName = cfg.role === '10' ? 'Memur' : 'Müdür';
        this.log('filtered', `Filtreli liste sorgusu başladı. rol=${roleName} kaynak=${cfg.source} servis=${cfg.servis || '-'} ydurum=${cfg.ydurum || '-'} sonucislem=${cfg.sonucislem}`);
        const sessionData = await this.bootRole(cfg.role, 'filtered');
        const listResp = await this.getYoklamalarByConfig(sessionData, cfg, { bastar: cfg.bastar, bittar: cfg.bittar }, 'filtered');
        const rows = extractYoklamaRows(listResp);
        const dateFiltered = clientFilterRows(rows, cfg);
        this.filteredRows = this.filterRowsByVkn(dateFiltered, cfg);
        this.filteredSelectAllState = false;
        this.renderFilteredList();
        this.log('filtered', `Kayıt: ${rows.length}, tarih/servis sonrası: ${dateFiltered.length}, VKN sonrası: ${this.filteredRows.length}`);
      } catch (err) {
        this.log('filtered', err?.message || String(err), true);
      } finally {
        this.filteredInFlight = false;
      }
    }

    async applySelectedFilteredRows() {
      if (this.filteredInFlight) return this.log('filtered', 'İşlem zaten çalışıyor.');
      const cfg = this.getFilteredConfig();
      const selected = this.selectedFilteredRows();
      const ykodlari = selected.map(x => x.ykodu).filter(Boolean);
      if (!ykodlari.length) return this.log('filtered', 'Seçili kayıt yok.', true);
      this.filteredInFlight = true;
      try {
        const sessionData = await this.bootRole(cfg.role, 'filtered');
        this.log('filtered', `Seçili ${ykodlari.length} kayıt için işlem uygulanacak: ${cfg.action}`);
        const actionResp = cfg.action === 'archive'
          ? await this.archiveYoklamalar(ykodlari, sessionData)
          : await this.markIslemYapildi(ykodlari, sessionData);
        this.log('filtered', `${cfg.action === 'archive' ? 'Arşive kaldırma' : 'İşlem yapıldı'} tamamlandı. (${ykodlari.length} kayıt)`);
        this.log('filtered', `Aksiyon response: ${previewResponse(actionResp)}`);
        await this.runFilteredQueryOnly();
      } catch (err) {
        this.log('filtered', err?.message || String(err), true);
      } finally {
        this.filteredInFlight = false;
      }
    }

    getVisibleDailyRows() {
      const cfg = this.getDailyConfig();
      return this.filterRowsByVkn(this.dailyRows || [], cfg);
    }






    async preloadYgMemurGirisFlow(sessionData) {
      try {
        const s = sessionData || await this.bootRole('10', 'ygiris');
        // Gerçek memur ekranı Yoklama Giriş açılışında önce VD combo, sonra İl listelerini çağırıyor.
        // Bu çağrılar paneldeki vergi dairesi / adres zincirinin EYS ile aynı session üzerinden hazır kalmasını sağlar.
        try {
          const vdResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_VDLER_FOR_CMB, { sessionData: s });
          const vdData = parsePossiblyJsonData(vdResp);
          const vdList = Array.isArray(vdData?.data) ? vdData.data : (Array.isArray(vdData) ? vdData : []);
          if (vdList.length) {
            this.ygAllVdOptions = vdList;
            const dis = this.panel.querySelector('#yg_dis_gorev_vd');
            if (dis && dis.options.length <= 1) {
              dis.innerHTML = '<option value="">---</option>';
              for (const o of vdList) {
                const t = getVdOptionText(o);
                const v = getVdOptionCode(o, t);
                if (!v && !t) continue;
                const opt = document.createElement('option');
                opt.value = v || t;
                opt.textContent = t || v;
                opt.dataset.vdkodu = v || '';
                dis.appendChild(opt);
              }
            }
          }
        } catch (e) {
          this.log('ygiris', `Memur açılış VD combo çağrısı atlandı: ${e?.message || e}`, true);
        }
        await this.loadYgIlList();
      } catch (err) {
        this.log('ygiris', `Memur açılış akışı hazırlanamadı: ${err?.message || String(err)}`, true);
      }
    }

    fillYgTemelBilgileri(sessionData = null) {
      try {
        const seed = getSessionSeed();
        const s = sessionData || this.ygLookup?.sessionData || buildSessionData(this.getYoklamaGirisConfig?.().role || '10');
        this.setYgField('yg_temel_kullanici', s.user || seed.user || '');
        this.setYgField('yg_temel_birim', s.birim || seed.birim || '');
        this.setYgField('yg_temel_il', eysIlAdiFromKod(s.il || seed.il || ''));
        const kaynak = this.panel.querySelector('#yg_temel_kaynak');
        if (kaynak && !kaynak.value) kaynak.value = 'VERGİ DAİRESİ';
      } catch (_) {}
    }

    setYgKayitSonucuBilgileri(ykodu = '', durum = '') {
      this.setYgField('yg_temel_kodu', ykodu || '');
      this.setYgField('yg_temel_durumu', durum || '');
      this.setYgField('yg_son_kayit_kodu', ykodu || '');
      this.setYgField('yg_son_kayit_durum', durum || '');
    }


    optionText(id) {
      const el = this.panel.querySelector('#' + id);
      return el?.selectedOptions?.[0]?.textContent || '';
    }

    setSelectOptions(id, list, valueKeys = ['value','kod'], textKeys = ['text','ad']) {
      const el = this.panel.querySelector('#' + id);
      if (!el) return;
      const keep = el.value;
      el.innerHTML = '<option value="">---</option>';
      for (const item of list || []) {
        const value = String(pickValue(item, valueKeys) || '').trim();
        const text = String(pickValue(item, textKeys) || value || '').trim();
        if (!value && !text) continue;
        const opt = document.createElement('option');
        opt.value = value || text;
        opt.textContent = text || value;
        el.appendChild(opt);
      }
      if (keep && Array.from(el.options).some(o => o.value === keep)) el.value = keep;
    }

    setSelectValueText(id, value, text) {
      const el = this.panel.querySelector('#' + id);
      if (!el) return;
      const v = String(value || '').trim();
      const t = String(text || v || '').trim();
      if (!v && !t) return;
      let opt = Array.from(el.options).find(o => o.value === v);
      if (!opt) {
        opt = document.createElement('option');
        opt.value = v || t;
        opt.textContent = t || v;
        el.appendChild(opt);
      } else if (t) {
        opt.textContent = t;
      }
      el.value = opt.value;
    }

    async loadYgCombo(id, type, data = '', valueKeys = ['value','kod'], textKeys = ['text','ad']) {
      try {
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(this.getYoklamaGirisConfig().role || '10', 'ygiris');
        const jp = data ? { type, data, sessionData } : { type, sessionData };
        const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_ADRES_COMBO, jp);
        const list = normalizeComboList(resp);
        this.setSelectOptions(id, list, valueKeys, textKeys);
        this.log('ygiris', `Adres seçenekleri yüklendi: ${id}, adet=${list.length}`);
        return list;
      } catch (err) {
        this.log('ygiris', `Adres seçenekleri yüklenemedi (${id}): ${err?.message || String(err)}`, true);
        return [];
      }
    }

    async loadYgIlList() {
      const targets = ['yg_il', 'yg_bel_il', 'yg_koy_il'];
      for (const id of targets) {
        const el = this.panel.querySelector('#' + id);
        if (el && el.options.length <= 1) {
          await this.loadYgCombo(id, 1, '', ['kod'], ['ad']);
        }
      }
    }

    async fillYgAdresFields(adres = {}, atext = '') {
      if (!adres || typeof adres !== 'object') return;
      await this.loadYgIlList();
      const mode = this.getYgAddressMode ? this.getYgAddressMode() : 'ililce';
      const ids = this.getYgAddressIds ? this.getYgAddressIds(mode) : { il:'yg_il', ilce:'yg_ilce', mahalle:'yg_mahalle', csbm:'yg_csbm', diskapi:'yg_diskapi', ickapi:'yg_ickapi', adresNo:'yg_adres_no', adresText:'yg_adres_text' };
      const ilKod = pickValue(adres, ['ilKod','il','ILKODU','ilKodu']);
      const ilAd = pickValue(adres, ['ilAd','ilAdi','ILADI','il']);
      const ilceKod = pickValue(adres, ['ilceKod','ilce','ILCEKODU','ilceKodu']);
      const ilceAd = pickValue(adres, ['ilceAd','ilceAdi','ILCEADI','ilce']);
      const mahKod = pickValue(adres, ['mahKod','mahalleKod','mahalle','MAHALLEKODU']);
      const mahAd = pickValue(adres, ['mahAd','mahalleAd','mahalleAdi','MAHALLEADI','mahalle']);
      const csbmKod = pickValue(adres, ['csbmKod','csbm','CSBMKODU']);
      const csbmAd = pickValue(adres, ['csbmAd','sicil_Csbm','csbmAdi','CSBMADI']);
      const binaKod = pickValue(adres, ['binaKod','diskapi','DISKAPIKODU']);
      const disKapiNo = pickValue(adres, ['disKapiNo','diskapiNo','DISKAPINO','disKapi']);
      const adresNo = pickValue(adres, ['adresNo','ADRESNO','ano']);
      const icKapiNo = pickValue(adres, ['icKapiNo','ickapiNo','ICKAPINO','icKapi']);
      const text = atext || pickValue(adres, ['atext','adresAciklama','ADRESSTRING','adresString','adresText']) || '';

      this.setSelectValueText(ids.il, ilKod, ilAd);
      if (ilKod && ids.ilce) await this.loadYgCombo(ids.ilce, 2, ilKod, ['kod'], ['ad']);
      this.setSelectValueText(ids.ilce, ilceKod, ilceAd);
      if (ilceKod && ids.mahalle) await this.loadYgCombo(ids.mahalle, 3, ilceKod, ['value'], ['text']);
      this.setSelectValueText(ids.mahalle, mahKod, mahAd);
      if (mahKod && ids.csbm) await this.loadYgCombo(ids.csbm, 4, mahKod, ['value'], ['text']);
      this.setSelectValueText(ids.csbm, csbmKod, csbmAd);
      if (csbmKod && ids.diskapi) await this.loadYgCombo(ids.diskapi, 5, csbmKod, ['value'], ['disKapiNo','text']);
      this.setSelectValueText(ids.diskapi, binaKod, disKapiNo);
      if (binaKod && ids.ickapi) await this.loadYgCombo(ids.ickapi, 6, binaKod, ['adresNo'], ['icKapiNo','text']);
      this.setSelectValueText(ids.ickapi, adresNo, icKapiNo);
      if (ids.adresNo) this.setYgField(ids.adresNo, adresNo || '');
      if (ids.adresText) this.setYgField(ids.adresText, text);
      this.setYgField('yg_adres_source', adresNo ? 'MERNİS / adres no sorgusu' : 'Manuel seçim');
    }

    getYgAdresFromFields() {
      const cfg = this.getYoklamaGirisConfig();
      return {
        ilKod: cfg.il,
        ilAd: cfg.ilText,
        ilceKod: cfg.ilce,
        ilceAd: cfg.ilceText,
        mahKod: cfg.mahalle,
        mahAd: cfg.mahalleText,
        csbmKod: cfg.csbm,
        csbmAd: cfg.csbmText,
        binaKod: cfg.diskapi,
        disKapiNo: cfg.diskapiText,
        adresNo: cfg.adresNo || cfg.ickapi,
        icKapiNo: cfg.ickapiText,
        adresAciklama: cfg.adresText,
        atext: cfg.adresText
      };
    }

    async lookupYgAdresNo() {
      const cfg = this.getYoklamaGirisConfig();
      const adresNo = cfg.adresNo || cfg.ickapi;
      if (!adresNo) {
        // Adres no yoksa en azından elle seçimler payload için kullanılır.
        this.ygLookup = this.ygLookup || { sessionData: await this.bootRole(cfg.role || '10', 'ygiris') };
        this.ygLookup.adres = this.getYgAdresFromFields();
        this.renderYgSummary();
        return;
      }
      try {
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
        const aResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_ADRES_AS_STRING, { adresNo, sessionData });
        const adres = parsePossiblyJsonData(aResp) || {};
        let atext = '';
        try {
          const tResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_ADRES_TEXT, { adresNo, sessionData });
          const td = parsePossiblyJsonData(tResp);
          atext = typeof td === 'string' ? td : (td?.data || td?.adresText || '');
        } catch (_) {}
        try { await post(CFG.EYS_URL, CFG.COMMANDS.YG_COORDS, { adresno: adresNo, sessionData }); } catch (_) {}

        this.ygLookup = this.ygLookup || { sicil: {}, faaliyet: {}, sessionData };
        this.ygLookup.sessionData = this.ygLookup.sessionData || sessionData;
        this.ygLookup.adres = Object.assign({}, adres, { atext: atext || adres.atext || adres.adresAciklama });
        await this.fillYgAdresFields(this.ygLookup.adres, atext);
        const ids = this.getYgAddressIds(this.getYgAddressMode());
        if (adresNo && ids.adresNo !== 'yg_adres_no') this.setYgField(ids.adresNo, adresNo);
        if ((atext || adres.atext || adres.adresAciklama) && ids.adresText !== 'yg_adres_text') this.setYgField(ids.adresText, atext || adres.atext || adres.adresAciklama);
        this.log('ygiris', `Adres no sorgusu tamamlandı: ${adresNo}`);
        this.renderYgSummary();
      } catch (err) {
        this.log('ygiris', `Adres no sorgusu hata: ${err?.message || String(err)}`, true);
      }
    }

    async lookupYgMulkSahibi() {
      const cfg = this.getYoklamaGirisConfig();
      const no = cfg.mulkVkntckn;
      if (!no || (no.length !== 10 && no.length !== 11)) return this.log('ygiris', 'Mülk sahibi VKN 10 hane veya TCKN 11 hane olmalı.', true);
      try {
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
        let raw = null;
        if (no.length === 10) raw = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SICIL_BY_VKN, { vkn: no, sessionData });
        else raw = await post(CFG.EYS_URL, CFG.COMMANDS.YG_UNVAN_BY_TCKN, { tckn: no, sessionData });
        const n = normalizeSicilData(raw, { vkn: no.length === 10 ? no : '', tckn: no.length === 11 ? no : '' });
        this.ygMulkCurrent = {
          vkn: n.vergiNo || (no.length === 10 ? no : ''),
          tckn: n.mukellefNo || (no.length === 11 ? no : ''),
          unvan: n.kimlikUnvan || '',
          hisse: 100
        };
        this.log('ygiris', `Mülk sahibi bulundu: ${this.ygMulkCurrent.vkn || this.ygMulkCurrent.tckn} ${this.ygMulkCurrent.unvan}`);
        this.renderYgMulkList();
      } catch (err) {
        this.log('ygiris', `Mülk sahibi sorgusu hata: ${err?.message || String(err)}`, true);
      }
    }

    addYgMulkSahibi() {
      const cfg = this.getYoklamaGirisConfig();
      if (!this.ygMulkCurrent && cfg.mulkVkntckn) {
        this.ygMulkCurrent = {
          vkn: cfg.mulkVkntckn.length === 10 ? cfg.mulkVkntckn : '',
          tckn: cfg.mulkVkntckn.length === 11 ? cfg.mulkVkntckn : '',
          unvan: '',
          hisse: 100
        };
      }
      if (!this.ygMulkCurrent) return this.log('ygiris', 'Önce mülk sahibi sorgulayın veya VKN/TCKN girin.', true);
      const key = `${this.ygMulkCurrent.vkn}|${this.ygMulkCurrent.tckn}`;
      if (!this.ygMulkSahipleri.some(x => `${x.vkn}|${x.tckn}` === key)) this.ygMulkSahipleri.push(this.ygMulkCurrent);
      this.log('ygiris', `Mülk sahibi listeye eklendi. Toplam=${this.ygMulkSahipleri.length}`);
      this.renderYgMulkList();
    }

    renderYgMulkList() {
      const box = this.panel.querySelector('#yg_mulk_list');
      if (!box) return;
      const rows = this.ygMulkSahipleri || [];
      const current = this.ygMulkCurrent;
      const currentHtml = current ? `<div class="tiny">Sorgulanan: ${htmlEscape(current.vkn || current.tckn)} ${htmlEscape(current.unvan || '')}</div>` : '';
      box.innerHTML = currentHtml + (rows.length ? rows.map((r, i) => `
        <div class="list-row">
          <div><strong>${i + 1}. ${htmlEscape(r.vkn || r.tckn)}</strong><div class="tiny">${htmlEscape(r.unvan || '-')} | Hisse: ${r.hisse || 100}</div></div>
          <button class="inline-btn" data-yg-mulk-del="${i}">Sil</button>
        </div>`).join('') : '<div class="tiny">Mülk sahibi listesi boş.</div>');
      box.querySelectorAll('[data-yg-mulk-del]').forEach(btn => btn.onclick = () => {
        const idx = Number(btn.getAttribute('data-yg-mulk-del'));
        this.ygMulkSahipleri.splice(idx, 1);
        this.renderYgMulkList();
      });
    }


    cleanTokenLikeValue(v) {
      const s = String(v || '').trim();
      if (!s || s === '-' || s === '—' || s === '…' || s === '...') return '';
      if (s.length < 20) return '';
      return s;
    }

    getMainIstakipDiscoveryFromBridge() {
      try {
        if (typeof window.__istakipBotDiscoverFromPage === 'function') {
          window.__istakipBotDiscoverFromPage();
        }
      } catch (_) {}
      try {
        if (typeof window.__istakipBotGetDiscovered === 'function') {
          const d = window.__istakipBotGetDiscovered('istakip') || {};
          const token = this.cleanTokenLikeValue(d.token);
          if (token) return {
            token,
            userId: String(d.userId || getSessionSeed().user || '').trim(),
            orgoid: String(d.orgoid || '').trim(),
            source: 'Ana Modül getDiscovered(istakip)'
          };
        }
      } catch (_) {}
      try {
        if (typeof window.__istakipBotResolveToken === 'function') {
          const token = this.cleanTokenLikeValue(window.__istakipBotResolveToken('istakip'));
          if (token) return { token, userId: getSessionSeed().user, orgoid: '', source: 'Ana Modül resolveToken(istakip)' };
        }
      } catch (_) {}
      return null;
    }

    getYgItDiscovery() {
      const bridge = this.getMainIstakipDiscoveryFromBridge();
      const val = sel => {
        const el = document.querySelector(sel);
        return this.cleanTokenLikeValue(el?.value || el?.textContent || el?.innerText || '');
      };
      const textVal = sel => String(document.querySelector(sel)?.value || document.querySelector(sel)?.textContent || document.querySelector(sel)?.innerText || '').trim();
      const domToken = val('#it_tok_istakip') || val('#it_token') || val('#it_base_tok');
      return {
        token: bridge?.token || domToken,
        userId: bridge?.userId || textVal('#it_user') || textVal('#it_base_user') || getSessionSeed().user,
        orgoid: bridge?.orgoid || textVal('#it_orgoid') || textVal('#it_base_org') || '',
        source: bridge?.source || (domToken ? 'Ana Modül DOM token alanı' : 'bulunamadı')
      };
    }

    async postYgIsTakip(cmd, jp, token = '') {
      // En güvenli yol: Ana modülün kendi post() akışını kullanmak.
      // Böylece İş Takip tokenı, EYS/yoklama tokenı veya URL tokenı ile karışmaz.
      if (typeof window.__istakipBotPostIstakip === 'function') {
        return await window.__istakipBotPostIstakip(cmd, jp);
      }

      const p = new URLSearchParams();
      p.append('cmd', cmd);
      p.append('callid', String(Date.now()) + '-' + Math.random().toString(16).slice(2, 8));
      const clean = this.cleanTokenLikeValue(token);
      if (!clean) throw new Error('İş Takip tokenı bulunamadı. Ana modülde İşleri Tara bir kez çalıştırıp tekrar deneyin.');
      p.append('token', clean);
      p.append('jp', JSON.stringify(jp || {}));
      const url = `${location.origin}/istakip_server/dispatch`;
      const res = await fetch(url, { method: 'POST', body: p, credentials: 'include' });
      if (!res.ok) throw new Error(`İş Takip ağ hatası: ${res.status}`);
      const text = await res.text();
      try { return JSON.parse(text); } catch (_) { return text; }
    }

    buildYgItListPayload(start = 0, limit = 50) {
      const d = this.getYgItDiscovery();
      // v4.31.63: EYS Yoklama Giriş formundaki VKN/TCKN alanı İş Takip listesini daraltmasın.
      // Liste, Ana Modül > İşleri Tara ile aynı ana sorgudan gelsin; VKN aralığı sadece ekranda filtre uygular.
      const raw = '';
      const isDigits = false;
      return {
        userId: String(d.userId || ''),
        nodeId: "",
        isTipi: 5,
        atamaYapilamayacakIsleriSil: 1,
        sonucSayisi: String(limit || 50),
        sorgulamaKriterleri: {
          vergiNo: raw && isDigits && raw.length === 10 ? raw : "",
          tcKimlikNo: raw && isDigits && raw.length === 11 ? raw : "",
          belgeTarihi: "",
          sayi: "",
          basTar: "",
          bitTar: "",
          unvan: raw && !isDigits ? raw : "",
          isTuru: "",
          basBeklenenTamamlanmaTarihi: "",
          bitBeklenenTamamlanmaTarihi: "",
          etiket: "",
          istakipNo: ""
        },
        respKeyParam: "isler",
        isTakipAkisNo: -1,
        isTakipDurumNo: -1,
        pv: { start: Number(start || 0), limit: String(limit || 50), sorters: [] }
      };
    }

    rebuildYgItDetailMapFromCounts(counts) {
      const grouped = counts?.data?.gruplanmisIsler || counts?.data?.groupedJobs || [];
      const map = {};
      for (const row of grouped) {
        const id = Number(row?.txtGizliDetayId ?? row?.is_detayId ?? 0);
        const text = String(row?.txtIsTuru || row?.isTuru || '').trim();
        if (id > 0 && text && text !== 'TOPLAM:') map[id] = text;
      }
      this.ygItDetailMap = map;
      return map;
    }

    async refreshYgItDetailMap() {
      const d = this.getYgItDiscovery();
      const resp = await this.postYgIsTakip(CFG.COMMANDS.YG_ACTIVE_COUNTS, { userId: String(d.userId || ''), nodeId: '' }, d.token);
      const map = this.rebuildYgItDetailMapFromCounts(resp);
      this.log('ygiris', `İş türü eşleştirmeleri Ana Modül akışıyla yüklendi. adet=${Object.keys(map).length}`);
      return map;
    }

    async fetchYgItJobs() {
      const seq = (Number(this.ygItFetchSeq || 0) + 1);
      this.ygItFetchSeq = seq;
      const d = this.getYgItDiscovery();
      const canUseMainPost = typeof window.__istakipBotPostIstakip === 'function';
      if (!d.token && !canUseMainPost) {
        return this.log('ygiris', 'İş Takip tokenı bulunamadı. Ana modülde XHR keşfini yenileyip İşleri Tara bir kez çalıştırın; EYS/Yoklama tokenı bu sorguda kullanılmaz.', true);
      }

      const btn = this.panel.querySelector('#yg_it_jobs_btn');
      const oldBtnText = btn ? btn.textContent : '';
      if (btn) { btn.disabled = true; btn.textContent = 'İŞLER YENİLENİYOR...'; }
      this.ygItJobs = [];
      // v4.31.72: İş Takip İşlerini Getir her basıldığında yoklama durum/kod cache'i temizlenir.
      // Böylece Ana/EYS işlemleri sonrası Müdür/Koordinatör/Ekip durumları eski ekrandan kalmaz.
      try { this.ygItYkStatusCache?.clear(); } catch (_) {}
      const box = this.panel.querySelector('#yg_it_jobs_list');
      if (box) box.innerHTML = '<div class="tiny">İş Takip listesi güncel olarak sorgulanıyor...</div>';
      this.updateYgItVknInfo(0, 0);

      const limit = Math.max(1, Number(this.panel.querySelector('#yg_it_limit')?.value || 50) || 50);
      const all = [];
      let start = 0;
      let total = null;
      let page = 1;
      try {
        await this.refreshYgItDetailMap().catch(e => this.log('ygiris', `İş türü eşleştirmeleri yüklenemedi: ${e?.message || String(e)}`, true));
        this.log('ygiris', `İş Takip listesi Ana Modül > İşleri Tara sorgusuyla çekiliyor. tokenKaynağı=${d.source || (canUseMainPost ? 'Ana Modül post köprüsü' : 'elle')}`);
        while (true) {
          const resp = await this.postYgIsTakip(CFG.COMMANDS.YG_ISTAKIP_LIST, this.buildYgItListPayload(start, limit), d.token);
          const errText = String(resp?.message || resp?.errorMessage || resp?.error || resp?.hata || '');
          if (/hatal[ıi]\s*token|invalid\s*token|token/i.test(errText) && /hatal[ıi]|invalid/i.test(errText)) {
            throw new Error('İş Takip sorgusu hatalı token döndürdü. Bu sorgu için EYS/Yoklama tokenı değil, İş Takip modül tokenı gerekir. Ana modülde “İşleri Tara”yı bir kez çalıştırıp tekrar deneyin.');
          }
          const key = resp?.respKeyParam || 'isler';
          const rows = resp?.data?.isler || resp?.data?.[key] || [];
          const t = Number(resp?.data?.totalCount || resp?.data?.total || resp?.totalCount || 0);
          if (total === null) total = t || rows.length;
          if (seq !== this.ygItFetchSeq) return;
          all.push(...rows);
          this.log('ygiris', `İş Takip sayfa ${page}: gelen=${rows.length}, toplam=${total}`);
          if (!rows.length || rows.length < limit || (total && all.length >= total) || page >= 25) break;
          start += limit;
          page += 1;
        }
        if (seq !== this.ygItFetchSeq) return;
        this.ygItJobs = all;
        this.renderYgItJobs();
        this.log('ygiris', `İş Takip işleri güncel listelendi. Kayıt=${all.length}`);
        this.evaluateYgItJobStatuses(all).catch(err => this.log('ygiris', `İş Takip durum kontrolü hata: ${err?.message || String(err)}`, true));
        this.loadYgItYoklamaStatuses(all).catch(err => this.log('ygiris', `Yoklama durum/kod kontrolü hata: ${err?.message || String(err)}`, true));
      } catch (err) {
        if (seq === this.ygItFetchSeq) this.log('ygiris', `İş Takip listesi alınamadı: ${err?.message || String(err)}`, true);
      } finally {
        if (seq === this.ygItFetchSeq && btn) { btn.disabled = false; btn.textContent = oldBtnText || 'İŞ TAKİP İŞLERİNİ GETİR'; }
      }
    }


    ygItDigitsOnly(v) {
      return String(v || '').replace(/\D+/g, '');
    }

    getYgItVkn(job) {
      const direct = this.ygItDigitsOnly(getJobField(job, ['is_vergiNo','vergiNo','vkn']));
      if (direct.length === 10) return direct;
      const blob = [
        getJobField(job, ['is_vergiNo','vergiNo','vkn']),
        getJobField(job, ['is_tcKimlikNo','tcKimlikNo','tckn']),
        getJobField(job, ['is_isTakipNo','akis_isTakipNo','isTakipNo','akis_oid'])
      ].map(x => String(x || '')).join(' ');
      const nums = blob.match(/\d{10,11}/g) || [];
      return nums.find(n => String(n).length === 10) || '';
    }

    isYgItVknInRange(vkn, start, end) {
      start = this.ygItDigitsOnly(start).slice(0, 10);
      end = this.ygItDigitsOnly(end).slice(0, 10);
      if (!start && !end) return true;
      if (!vkn || vkn.length !== 10) return false;
      if (start && start.length !== 10) start = '';
      if (end && end.length !== 10) end = '';
      if (!start && !end) return true;
      if (start && !end) return vkn >= start;
      if (!start && end) return vkn <= end;
      return vkn >= start && vkn <= end;
    }

    filterYgItJobsByVkn(rows) {
      const sEl = this.panel.querySelector('#yg_it_vkn_start');
      const eEl = this.panel.querySelector('#yg_it_vkn_end');
      if (sEl) sEl.value = this.ygItDigitsOnly(sEl.value).slice(0, 10);
      if (eEl) eEl.value = this.ygItDigitsOnly(eEl.value).slice(0, 10);
      const start = sEl?.value || '';
      const end = eEl?.value || '';
      const list = Array.isArray(rows) ? rows : [];
      if (!start && !end) return list;
      return list.filter(j => this.isYgItVknInRange(this.getYgItVkn(j), start, end));
    }

    updateYgItVknInfo(total, shown) {
      const info = this.panel.querySelector('#yg_it_vkn_info');
      if (!info) return;
      const s = this.panel.querySelector('#yg_it_vkn_start')?.value || '';
      const e = this.panel.querySelector('#yg_it_vkn_end')?.value || '';
      if (!s && !e) info.textContent = `${shown}/${total} gösteriliyor`; 
      else info.textContent = `VKN filtre: ${shown}/${total} gösteriliyor`;
    }


    ygItYkFormatDateYYYYMMDD(d) {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}${m}${day}`;
    }

    ygItYkDateRangeSixMonths() {
      const end = new Date();
      const start = new Date(end);
      start.setMonth(start.getMonth() - 6);
      return { start: this.ygItYkFormatDateYYYYMMDD(start), end: this.ygItYkFormatDateYYYYMMDD(end) };
    }

    ygItYkDurumText(d) {
      const n = Number(d);
      switch (n) {
        case 10: return 'Yoklama Giriş';
        case 20: return 'Müdür Onay';
        case 30: return 'Koordinatör Onay';
        case 40: return 'Ekibe Atandı';
        case 50: return 'Yoklama Memuru';
        case 60: return 'Görev Başladı';
        case 70: return 'Devam Ediyor';
        case 80: return 'Sonuç Alındı';
        case 81: return 'Sonuçlandı';
        default: return n ? `Durum ${n}` : '-';
      }
    }

    ygItYkCollectObjects(root, out = []) {
      if (Array.isArray(root)) {
        for (const item of root) this.ygItYkCollectObjects(item, out);
        return out;
      }
      if (root && typeof root === 'object') {
        out.push(root);
        for (const value of Object.values(root)) this.ygItYkCollectObjects(value, out);
      }
      return out;
    }

    ygItYkGetKod(item) {
      const direct = item?.ykodu || item?.yKod || item?.ykod || item?.yKodu || item?.yoklamaKodu || item?.yoklamakodu || item?.kod || item?.ykodu1 || '';
      return String(direct || '').trim();
    }

    ygItYkGetOptime(item) {
      const raw = String(item?.optime || item?.sonislem || item?.ilkislem || item?.islemZamani || item?.tarih || item?.giris || this.ygItYkGetKod(item).slice(0, 8) || '').replace(/\D+/g, '');
      return Number(raw || 0);
    }

    ygItYkExtractItems(resp) {
      const root = parsePossiblyJsonData(resp);
      const rows = [];
      const seen = new Set();
      for (const obj of this.ygItYkCollectObjects(root)) {
        if (!obj || typeof obj !== 'object') continue;
        const kod = this.ygItYkGetKod(obj);
        const hasUseful = kod || obj.vkn || obj.tckn || obj.unvan || obj.adsoyadunvan || obj.durum || obj.optime || obj.ilkislem || obj.sonislem;
        if (!hasUseful) continue;
        const key = kod || JSON.stringify(obj).slice(0, 120);
        if (seen.has(key)) continue;
        seen.add(key);
        rows.push(obj);
      }
      return rows;
    }

    ygItYkGetLastStatus(items) {
      if (!items || !items.length) return { durum: '-', kod: '', item: null };
      const last = items.reduce((a, b) => this.ygItYkGetOptime(b) > this.ygItYkGetOptime(a) ? b : a, items[0]);
      return { durum: this.ygItYkDurumText(last?.durum), kod: this.ygItYkGetKod(last), item: last };
    }

    ygItYkNormalizeYmdDate(value) {
      return ymdFromAny(value);
    }

    ygItYkDeepFindDateByKey(obj) {
      const wanted = ['gelis', 'geliş', 'kaynak', 'talep', 'basvuru', 'başvuru', 'evrak', 'tarih', 'olusturma', 'oluşturma'];
      const seen = new Set();
      const stack = [obj];
      while (stack.length) {
        const cur = stack.pop();
        if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
        seen.add(cur);
        if (Array.isArray(cur)) { cur.forEach(x => stack.push(x)); continue; }
        for (const [k, v] of Object.entries(cur)) {
          const lk = String(k).toLowerCase();
          if (wanted.some(w => lk.includes(w))) {
            const ymd = this.ygItYkNormalizeYmdDate(v);
            if (ymd) return ymd;
          }
          if (v && typeof v === 'object') stack.push(v);
        }
      }
      return '';
    }

    ygItYkGetJobStartDate(job) {
      const candidates = [
        job?.is_gelisTarihi, job?.gelisTarihi, job?.is_tarih, job?.tarih,
        job?.is_kaynakTarihi, job?.kaynakTarihi, job?.talepTarihi, job?.basvuruTarihi,
        job?.evrakTarihi, job?.olusturmaTarihi, job?.createDate, job?.createdDate,
        job?.is_kaynakbilgisi, job?.is_kaynakBilgisi, job?.belgeBilgi, job?.evrakBilgisi
      ];
      for (const c of candidates) {
        const ymd = this.ygItYkNormalizeYmdDate(c);
        if (ymd) return ymd;
      }
      const deep = this.ygItYkDeepFindDateByKey(job);
      if (deep) return deep;
      try { return this.ygItYkDateRangeSixMonths().start; } catch (_) { return ''; }
    }

    getYgItYoklamaStatusCacheKey(job) {
      const vkn = this.getYgItVkn(job) || String(getJobField(job, ['is_vergiNo','vergiNo','vkn']) || '').trim();
      const tckn = String(getJobField(job, ['is_tcKimlikNo','tcKimlikNo','tckn']) || '').trim();
      const no = String(getJobField(job, ['is_isTakipNo','akis_isTakipNo','isTakipNo','akis_oid']) || '').trim();
      return [vkn, tckn, no].filter(Boolean).join('|') || JSON.stringify(job).slice(0, 120);
    }

    async fetchYgItYoklamaStatus(job) {
      this.ygItYkStatusCache = this.ygItYkStatusCache || new Map();
      const cacheKey = this.getYgItYoklamaStatusCacheKey(job);
      const cached = this.ygItYkStatusCache.get(cacheKey);
      if (cached) { job.__ykStatus = cached; return cached; }

      const storedSpecial = this.readYgAdiOrtaklikStoredStatus(job);
      if (storedSpecial && Array.isArray(storedSpecial.items) && storedSpecial.items.length) {
        try {
          const cfg0 = this.getYoklamaGirisConfig ? this.getYoklamaGirisConfig() : {};
          const sessionData0 = this.ygLookup?.sessionData || await this.bootRole(cfg0.role || '20', 'ygiris');
          const refreshed = [];
          for (const item of storedSpecial.items) {
            const kod0 = this.ygItYkGetKod(item);
            let merged = item;
            if (kod0) {
              let bestDurum = item?.durum;
              let bestOptime = item?.optime;
              let flow = [];
              let liveItem = null;
              try {
                const flowResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_YOKLAMA_GUNLUK, { ykodu: kod0, yKodu: kod0, sessionData: sessionData0 });
                flow = this.ygItYkExtractItems(flowResp);
                if (flow && flow.length) {
                  const lastFlow = this.ygItYkGetLastStatus(flow);
                  bestDurum = lastFlow?.item?.durum || lastFlow?.durum || bestDurum;
                  bestOptime = lastFlow?.item?.optime || lastFlow?.item?.sonislem || lastFlow?.item?.ilkislem || bestOptime;
                }
              } catch (_) {}
              try {
                const liveResp = await this.getYoklamalarFiltered(sessionData0, '', {}, 'ygiris', { yoklamaKodu: kod0 });
                const liveItems = this.ygItYkExtractItems(liveResp).filter(x => this.ygItYkGetKod(x) || x?.durum || x?.optime || x?.sonislem || x?.ilkislem);
                if (liveItems && liveItems.length) {
                  liveItem = liveItems[0];
                  const lastLive = this.ygItYkGetLastStatus(liveItems);
                  bestDurum = liveItem?.durum || lastLive?.item?.durum || lastLive?.durum || bestDurum;
                  bestOptime = liveItem?.optime || liveItem?.sonislem || liveItem?.ilkislem || lastLive?.item?.optime || bestOptime;
                }
              } catch (_) {}
              // canlı sorgudan gelen alanlar alınır; fakat ortak kimlik/etiket bilgisi eski kayıttan korunur.
              merged = Object.assign({}, liveItem || {}, item, {
                durum: bestDurum || item?.durum,
                optime: bestOptime || item?.optime,
                __flow: flow || item?.__flow,
                kisi: item?.kisi || item?.ortakKimlik || item?.ortakNo || item?.vkn || item?.tckn || '',
                ortakKimlik: item?.ortakKimlik || item?.kisi || item?.ortakNo || '',
                ortakLabel: item?.ortakLabel || ''
              });
            }
            refreshed.push(merged);
          }
          const st = this.storeYgAdiOrtaklikStatus(job, refreshed) || storedSpecial;
          this.ygItYkStatusCache.set(cacheKey, st);
          job.__ykStatus = st;
          return st;
        } catch (_) {
          this.ygItYkStatusCache.set(cacheKey, storedSpecial);
          job.__ykStatus = storedSpecial;
          return storedSpecial;
        }
      }

      const vkn = String(this.getYgItVkn(job) || getJobField(job, ['is_vergiNo','vergiNo','vkn']) || '').trim();
      const tckn = String(getJobField(job, ['is_tcKimlikNo','tcKimlikNo','tckn']) || '').trim();
      if (!vkn && !tckn) throw new Error('VKN/TCKN bulunamadı');

      const range = this.ygItYkDateRangeSixMonths();
      range.start = this.ygItYkGetJobStartDate(job) || range.start;
      const cfg = this.getYoklamaGirisConfig ? this.getYoklamaGirisConfig() : {};
      const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '20', 'ygiris');

      const resp = await post(CFG.EYS_URL, CFG.COMMANDS.GET_YOKLAMALAR, {
        data: {
          koor: '', vd: sessionData.birim, vdkodu: sessionData.birim, sorgukaynak: '0', icdis: '0',
          disil: '', disvd: '', basvkn: vkn, sonvkn: vkn, bastckn: tckn, sontckn: tckn,
          yabanci: 0, vkn, tckn, yturu: [], ydurum: '', sonucislem: '1', servis: '',
          bastar: range.start, bittar: range.end, unvan: '', ym: '', usekullanici: false,
          eosusergiris: sessionData.giris, eosuser: sessionData.user, ihbaraDayali: false
        },
        sessionData
      });

      let items = this.ygItYkExtractItems(resp).filter(x => this.ygItYkGetKod(x) || x?.durum || x?.optime || x?.sonislem || x?.ilkislem);
      const seen = new Set();
      items = items.filter(it => {
        const k = this.ygItYkGetKod(it) || JSON.stringify(it).slice(0, 120);
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });

      const enriched = [];
      for (const it of items) {
        const kod = this.ygItYkGetKod(it);
        let merged = it;
        if (kod) {
          try {
            const flowResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_YOKLAMA_GUNLUK, { ykodu: kod, yKodu: kod, sessionData });
            const flow = this.ygItYkExtractItems(flowResp);
            if (flow && flow.length) {
              const lastFlow = this.ygItYkGetLastStatus(flow);
              merged = Object.assign({}, it, { durum: lastFlow?.item?.durum || it?.durum, optime: lastFlow?.item?.optime || it?.optime, __flow: flow });
            }
          } catch (_) {}
        }
        enriched.push(merged);
      }
      const last = this.ygItYkGetLastStatus(enriched);
      const status = { durum: last.durum || '-', kod: last.kod || '', items: enriched, cacheKey, fetchedAt: Date.now() };
      this.ygItYkStatusCache.set(cacheKey, status);
      job.__ykStatus = status;
      return status;
    }

    getYgItYoklamaStatus(job) {
      // v4.31.96: Önce ekrandaki/canlı sorgudan gelen job.__ykStatus kullanılır.
      // Eski localStorage kaydı daha önce dönünce Adi Ortaklıkta Listeyi Yenile sonrası durum
      // akışı ekranda güncellenmiyor, "Yoklama Giriş" gibi eski değer sabit kalıyordu.
      const st = job?.__ykStatus || null;
      if (st && (Array.isArray(st.items) || st.kod || st.durum || st.error)) {
        return { durum: st.durum || '-', kod: st.kod || '', items: Array.isArray(st.items) ? st.items : [], error: st.error || '', special: st.special || '' };
      }
      const special = this.readYgAdiOrtaklikStoredStatus(job);
      if (special && Array.isArray(special.items) && special.items.length) return special;
      return { durum: '-', kod: '', items: [], error: '' };
    }

    hasYgItExistingYoklama(job) {
      const st = this.getYgItYoklamaStatus(job);
      const items = Array.isArray(st.items) ? st.items : [];
      if (items.some(it => this.ygItYkGetKod(it))) return true;
      if (st.kod) return true;
      return false;
    }

    async refreshYgItYoklamaStatusNoCache(job) {
      this.ygItYkStatusCache = this.ygItYkStatusCache || new Map();
      const cacheKey = this.getYgItYoklamaStatusCacheKey(job);
      try { this.ygItYkStatusCache.delete(cacheKey); } catch (_) {}
      try { delete job.__ykStatus; } catch (_) {}
      return await this.fetchYgItYoklamaStatus(job);
    }

    ygItYkGetOrtakLabel(item, index = 0) {
      if (item?.ortakLabel) return String(item.ortakLabel);
      const raw = String(
        item?.kisi || item?.ortakKimlik || item?.ortakNo || item?.partnerId ||
        item?.aktifOrtakId || item?.vkn || item?.tckn || item?.kimlikNo || item?.vkntckn || ''
      ).replace(/\D+/g, '');
      if (raw) {
        const tip = raw.length === 10 ? 'VKN' : (raw.length === 11 ? 'TCKN' : 'Kimlik');
        return `${index + 1}. ${tip} ${raw}`;
      }
      if (item?.aciklama && String(item.aciklama).toLowerCase().includes('adi ortaklık')) return `${index + 1}. Ortak`;
      return '';
    }

    renderYgItYoklamaDurumCell(job) {
      const st = this.getYgItYoklamaStatus(job);
      const items = st.items || [];
      const isAdi = this.isYgAdiOrtaklikIseBaslamaJob(job);
      if (items.length) {
        return items.map((it) => {
          const flowItems = Array.isArray(it?.__flow) ? it.__flow : [];
          const lastFlow = flowItems.length ? this.ygItYkGetLastStatus(flowItems) : null;
          const durumRaw = lastFlow?.item?.durum || lastFlow?.durum || it?.durum;
          const durum = this.ygItYkDurumText(durumRaw);
          const optime = lastFlow?.item?.optime || lastFlow?.item?.sonislem || it?.optime || it?.sonislem || it?.ilkislem || '';
          const flowText = isAdi && flowItems.length
            ? flowItems.map(x => this.ygItYkDurumText(x?.durum)).filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(' → ')
            : '';
          const titleBits = [];
          if (optime) titleBits.push('Tarih: ' + optime);
          if (flowText) titleBits.push('Akış: ' + flowText);
          const title = titleBits.length ? ` title="${htmlEscape(titleBits.join(' | '))}"` : '';
          // Ortak VKN/TCKN etiketi burada gösterilmez; sadece Yoklama Kodu sütununda gösterilir.
          return `<span class="yg-yk-line"${title}>${htmlEscape(durum || '-')}</span>`;
        }).join('');
      }
      return `<span class="yg-yk-line ${st.error ? 'yg-yk-muted' : ''}">${htmlEscape(st.error ? 'Alınamadı' : (st.durum || '-'))}</span>`;
    }

    renderYgItYoklamaKodCell(job) {
      const st = this.getYgItYoklamaStatus(job);
      const items = st.items || [];
      const showOrtakLabel = this.isYgAdiOrtaklikIseBaslamaJob(job);
      if (items.length) {
        return items.map((it, idx) => {
          const kod = this.ygItYkGetKod(it);
          const ortak = showOrtakLabel ? this.ygItYkGetOrtakLabel(it, idx) : '';
          if (!kod) return `<span class="yg-yk-line yg-yk-muted">${ortak ? `<b>${htmlEscape(ortak)}</b><br>` : ''}Kod yok</span>`;
          const title = ortak ? ` title="${htmlEscape('Ortak: ' + ortak)}"` : '';
          return `<span class="yg-yk-line"${title}>${ortak ? `<b>${htmlEscape(ortak)}</b><br>` : ''}<a class="yg-yk-link" data-yg-ykodu="${htmlEscape(kod)}">${htmlEscape(kod)}</a></span>`;
        }).join('');
      }
      if (st.kod) return `<a class="yg-yk-link" data-yg-ykodu="${htmlEscape(st.kod)}">${htmlEscape(st.kod)}</a>`;
      return '<span class="yg-yk-muted">-</span>';
    }

    async loadYgItYoklamaStatuses(rows) {
      const raw = Array.isArray(rows) ? rows : (Array.isArray(this.ygItJobs) ? this.ygItJobs : []);
      if (!raw.length) return;
      this.ygItYkStatusCache = this.ygItYkStatusCache || new Map();
      const batchSeq = (this.__ygItYkBatchSeq || 0) + 1;
      this.__ygItYkBatchSeq = batchSeq;
      const jobsToFetch = raw.filter(job => !this.ygItYkStatusCache.has(this.getYgItYoklamaStatusCacheKey(job)));
      if (!jobsToFetch.length) {
        raw.forEach(job => {
          const cached = this.ygItYkStatusCache.get(this.getYgItYoklamaStatusCacheKey(job));
          if (cached) job.__ykStatus = cached;
        });
        this.renderYgItJobs();
        this.log('ygiris', `Yoklama durum/kod cache kullanıldı. kayıt=${raw.length}`);
        return;
      }
      this.log('ygiris', `Yoklama durum/kod sorgusu başlıyor. yeni=${jobsToFetch.length}, cache=${raw.length - jobsToFetch.length}`);
      let index = 0, done = 0;
      const concurrency = 3;
      const scheduleRender = () => {
        if (this.__ygItYkBatchSeq !== batchSeq) return;
        clearTimeout(this.__ygItYkRenderTimer);
        this.__ygItYkRenderTimer = setTimeout(() => {
          if (this.__ygItYkBatchSeq === batchSeq) this.renderYgItJobs();
        }, 350);
      };
      const worker = async () => {
        while (index < jobsToFetch.length && this.__ygItYkBatchSeq === batchSeq) {
          const job = jobsToFetch[index++];
          try {
            await this.fetchYgItYoklamaStatus(job);
          } catch (e) {
            const status = { durum: 'Alınamadı', kod: '', items: [], error: e?.message || String(e), fetchedAt: Date.now() };
            job.__ykStatus = status;
            this.ygItYkStatusCache.set(this.getYgItYoklamaStatusCacheKey(job), status);
          }
          done += 1;
          if (done === 1 || done % 10 === 0 || done === jobsToFetch.length) this.log('ygiris', `Yoklama durum/kod ilerleme: ${done}/${jobsToFetch.length}`);
          scheduleRender();
        }
      };
      await Promise.all(Array.from({ length: Math.min(concurrency, jobsToFetch.length) }, worker));
      if (this.__ygItYkBatchSeq === batchSeq) {
        clearTimeout(this.__ygItYkRenderTimer);
        this.renderYgItJobs();
        this.log('ygiris', `Yoklama durum/kod sorgusu tamamlandı. yeni=${jobsToFetch.length}, cache=${raw.length - jobsToFetch.length}`);
      }
    }

    ygItFindIsTakipNo(job) {
      return String(getJobField(job, [
        'is_isTakipNo','akis_isTakipNo','isTakipNo','istakipNo','isTakip_no','is_is_takip_no',
        'kaynakEkBilgiler.isTakipNo'
      ]) || job?.kaynakEkBilgiler?.isTakipNo || '').trim();
    }

    ygItNormalizeBeklenenIsBitisZamani(job) {
      const candidates = [
        getJobField(job, ['is_beklenenIsBitisZamani','beklenenIsBitisZamani','beklenenIsBitis','is_beklenenIsBitis']),
        job?.kaynakEkBilgiler?.is_beklenenIsBitisZamani,
        job?.kaynakEkBilgiler?.beklenenIsBitisZamani,
        job?.kaynakEkBilgiler?.beklenenIsBitis
      ];
      for (const c of candidates) {
        const digits = String(c || '').replace(/\D/g, '');
        if (digits.length >= 12) return digits.slice(0, 12);
        if (digits.length === 8) return digits + '1700';
      }
      return '';
    }

    buildYgItSavePayload(job, step) {
      const d = this.getYgItDiscovery();
      const asObj = step?.asJSONObject || {};
      const hedefDurumNo = Number(step?.durumNo ?? asObj?.durumNo ?? 4);
      const akisDurumTip = Number(step?.tip ?? asObj?.tip ?? 24);
      const orgoid = this.ygFindOrgoid(job);
      const isTakipNo = this.ygItFindIsTakipNo(job) || getJobField(job, ['is_isTakipNo','akis_isTakipNo','isTakipNo']);
      const akisOid = this.ygFindAkisOid(job);
      return {
        atanacakNodeId: '',
        atamaYapanKullaniciUserId: String(d.userId || ''),
        orgoid: String(orgoid || ''),
        isTakipNo: String(isTakipNo || ''),
        akisOid: String(akisOid || ''),
        atamaYapilacaklar: [],
        akisDurumKullanicilari: [],
        akisDurumNodeIdler: [],
        islemSahibi: 3,
        akisDurum: 1,
        userId: String(d.userId || ''),
        islemYapanUserId: String(d.userId || ''),
        isiUzerimeAl: 1,
        aciklama: '',
        hedefDurumNo,
        akisDurumTip,
        geriGonderimSebepleri: [],
        beklenenIsBitisZamani: this.ygItNormalizeBeklenenIsBitisZamani(job)
      };
    }

    async sendYgItWorkflowAction(job, action) {
      const label = this.ygItActionLabel(action);
      if (this.isYgYoklamaSureciAction(action)) {
        try {
          await this.refreshYgItYoklamaStatusNoCache(job);
          if (this.hasYgItExistingYoklama(job)) {
            const st0 = this.getYgItYoklamaStatus(job);
            const kodlar = (st0.items || []).map(x => this.ygItYkGetKod(x)).filter(Boolean).join(', ') || st0.kod || '-';
            job.__eligible = false;
            job.__excludeReason = 'Mevcut yoklama kodu var; mükerrer engellendi';
            this.renderYgItJobs();
            this.log('ygiris', `Mükerrer engellendi: ${this.ygItFindIsTakipNo(job) || this.ygFindAkisOid(job) || '-'} için mevcut yoklama kodu var (${kodlar}).`);
            alert(`Bu iş için mevcut yoklama kodu bulundu. Mükerrer yoklama gönderilmedi.\n\nKod: ${kodlar}`);
            return;
          }
        } catch (e) {
          this.log('ygiris', `Mükerrer yoklama kontrolü yapılamadı: ${e?.message || String(e)}`, true);
          if (!confirm('Mevcut yoklama kontrolü tamamlanamadı. Yine de akışa devam edilsin mi?')) return;
        }
      }
      const payload = this.buildYgItSavePayload(job, action);
      const tag = payload.isTakipNo || payload.akisOid || '-';
      if (!payload.isTakipNo) throw new Error('isTakipNo bulunamadı');
      if (!payload.akisOid) throw new Error('akisOid bulunamadı');
      if (!payload.orgoid) throw new Error('orgoid bulunamadı');
      if (!payload.userId) throw new Error('userId bulunamadı');

      const detail = [
        `İşTakip: ${payload.isTakipNo}`,
        `Adım: ${label}`,
        `hedefDurumNo=${payload.hedefDurumNo}`,
        `akisDurumTip=${payload.akisDurumTip}`,
        payload.beklenenIsBitisZamani ? `beklenen=${payload.beklenenIsBitisZamani}` : 'beklenen=boş'
      ].join('\n');
      if (!confirm(`${detail}\n\nBu akış adımı kaydedilsin mi?`)) {
        this.log('ygiris', `Akış iptal edildi: ${label} | isTakip=${tag}`);
        return;
      }
      this.log('ygiris', `Akış gönderiliyor: ${label} | isTakip=${tag} | hedefDurumNo=${payload.hedefDurumNo}, tip=${payload.akisDurumTip}`);
      const d = this.getYgItDiscovery();
      const resp = await this.postYgIsTakip('akisIslemleri_akisYeniAdimKaydet', payload, d.token);
      job.__sent = true;
      job.__lastActionSent = label;
      job.__sendResp = resp;
      this.renderYgItJobs();
      this.log('ygiris', `Akış kaydedildi: ${label} | isTakip=${tag}`);
    }

    ensureYgItActionMenu() {
      let menu = document.getElementById('yg_it_action_menu');
      if (menu) return menu;
      menu = document.createElement('div');
      menu.id = 'yg_it_action_menu';
      menu.style.cssText = 'position:fixed;display:none;z-index:2147483647;min-width:230px;max-width:360px;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:8px;box-shadow:0 12px 30px rgba(0,0,0,.45);padding:6px;font:12px/1.35 Segoe UI,Arial,sans-serif';
      document.documentElement.appendChild(menu);
      menu.addEventListener('mouseenter', () => menu.__inside = true);
      menu.addEventListener('mouseleave', () => {
        menu.__inside = false;
        setTimeout(() => { if (!menu.__inside) menu.style.display = 'none'; }, 180);
      });
      return menu;
    }

    ygItActionLabel(a) {
      return String(a?.aciklama || a?.durumAciklama || a?.asJSONObject?.aciklama || a?.text || a?.label || a?.name || '-').trim();
    }

    ygItActionSub(a) {
      const bits = [];
      if (a?.durumNo !== undefined) bits.push('durumNo=' + a.durumNo);
      if (a?.tip !== undefined) bits.push('tip=' + a.tip);
      if (a?.akisNo !== undefined) bits.push('akisNo=' + a.akisNo);
      return bits.join(' / ');
    }

    positionYgItMenu(menu, anchor) {
      const r = anchor.getBoundingClientRect();
      const w = 310;
      let left = r.left, top = r.bottom + 4;
      if (left + w > innerWidth) left = Math.max(4, innerWidth - w - 8);
      if (top + 270 > innerHeight) top = Math.max(4, r.top - 240);
      menu.style.left = left + 'px';
      menu.style.top = top + 'px';
      menu.style.display = 'block';
    }

    async toggleYgItActionMenu(job, anchor) {
      const menu = this.ensureYgItActionMenu();
      if (menu.style.display === 'block' && menu.__activeAnchor === anchor) {
        menu.style.display = 'none';
        menu.__activeAnchor = null;
        return;
      }
      menu.__activeAnchor = anchor;
      menu.innerHTML = '<div style="padding:8px 10px;color:#9cff9c">Akış seçenekleri yükleniyor...</div>';
      this.positionYgItMenu(menu, anchor);
      try {
        if (!job.__steps) {
          const d = this.getYgItDiscovery();
          const orgoid = this.ygFindOrgoid(job);
          const akisOid = this.ygFindAkisOid(job);
          if (!orgoid) throw new Error('orgoid bulunamadı');
          if (!akisOid) throw new Error('akisOid bulunamadı');
          const resp = await this.postYgIsTakip('akisIslemleri_isTakipSonrakiAdimlariBul', { orgoid, akisOid }, d.token);
          const steps = resp?.data?.hedefAdimlar || resp?.hedefAdimlar || [];
          job.__steps = Array.isArray(steps) ? steps : [];
        }
        const extraActions = [];
        if (this.isYgAdiOrtaklikIseBaslamaJob(job)) {
          extraActions.push({ __systemExternal: 'adiOrtaklik', aciklama: 'Sistem harici Adi Ortaklık Yoklama Çıkar' });
        } else if (this.isYgIseBaslamaJob(job)) {
          extraActions.push({ __systemExternal: 'iseBaslamaTek', aciklama: 'Sistem harici Yeniden Yoklama Çıkart' });
        }
        const actions = (job.__steps || []).concat(extraActions);
        if (!actions.length) {
          menu.innerHTML = '<div style="padding:8px 10px;color:#ffb86b">Akış seçeneği bulunamadı.</div>';
          return;
        }
        menu.innerHTML = actions.map((a, i) => {
          const label = this.ygItActionLabel(a);
          const sub = this.ygItActionSub(a);
          return `<div class="yg-it-menu-item" data-idx="${i}" style="padding:7px 9px;border-radius:6px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06);"><div style="font-weight:700">${htmlEscape(label)}</div>${sub ? `<div style="font-size:10px;color:#aeb9d4;margin-top:2px">${htmlEscape(sub)}</div>` : ''}</div>`;
        }).join('');
        menu.querySelectorAll('.yg-it-menu-item').forEach(el => {
          el.onmouseenter = () => el.style.background = '#12315a';
          el.onmouseleave = () => el.style.background = '';
          el.onclick = async () => {
            const a = actions[Number(el.dataset.idx)];
            menu.style.display = 'none';
            this.log('ygiris', `Akış seçildi: ${this.ygItActionLabel(a)} | durumNo=${a?.durumNo ?? '-'} tip=${a?.tip ?? '-'} akisNo=${a?.akisNo ?? '-'} | isTakip=${this.ygItFindIsTakipNo(job) || '-'}`);
            try {
              if (a && a.__systemExternal === 'adiOrtaklik') await this.handleYgAdiOrtaklikWorkflow(job, null, { ask: true });
              else if (a && a.__systemExternal === 'iseBaslamaTek') await this.handleYgIseBaslamaTekWorkflow(job, null, { ask: true });
              else await this.sendYgItWorkflowAction(job, a);
            } catch (err) {
              const msg = err?.message || String(err);
              this.log('ygiris', `Akış gönderim hatası: ${this.ygItActionLabel(a)} | ${msg}`, true);
              alert(`Akış gönderilemedi:\n${msg}`);
            }
          };
        });
      } catch (e) {
        menu.innerHTML = `<div style="padding:8px 10px;color:#ff8f8f">Akış seçenekleri alınamadı</div><div style="padding:0 10px 8px;font-size:10px;color:#aeb9d4">${htmlEscape(e?.message || String(e))}</div>`;
      }
    }


    isYgAdiOrtaklikIseBaslamaJob(job) {
      const blob = [
        this.getYgItIsTuruText(job),
        this.getYgItBelgeBilgiText(job),
        getJobField(job, ['txtIsTuru','isTuru','is_kaynakbilgi','is_kaynakbilgisi','belgeBilgi']),
        getJobField(job, ['is_unvan','is_unvan_unvan','unvan'])
      ].join(' ').toLocaleLowerCase('tr-TR');
      return (blob.includes('adi ortak') || blob.includes('adi ortaklık')) && (blob.includes('işe başlama') || blob.includes('ise baslama'));
    }

    isYgIseBaslamaJob(job) {
      const blob = [
        this.getYgItIsTuruText(job),
        this.getYgItBelgeBilgiText(job),
        getJobField(job, ['txtIsTuru','isTuru','is_kaynakbilgi','is_kaynakbilgisi','belgeBilgi']),
        getJobField(job, ['is_unvan','is_unvan_unvan','unvan'])
      ].join(' ').toLocaleLowerCase('tr-TR');
      return blob.includes('işe başlama') || blob.includes('ise baslama');
    }

    isYgYoklamaSureciAction(action) {
      const t = this.ygItActionLabel(action).toLocaleLowerCase('tr-TR');
      return t.includes('yoklama süreci başlat') || t.includes('yoklama sureci baslat');
    }

    ygSpecialJobKey(job) {
      return String(this.ygItFindIsTakipNo(job) || this.ygFindAkisOid(job) || findJobPreviewOid(job) || '').trim();
    }

    ygAdiOrtaklikNormalizeKimlikCandidate(n) {
      const s = String(n || '').replace(/\D+/g, '');
      if (s.length !== 10 && s.length !== 11) return '';
      if (/^0+$/.test(s) || /^90/.test(s) || /^05\d{9}$/.test(s) || /^5\d{9}$/.test(s)) return '';
      return s;
    }

    ygAdiOrtaklikObjectToText(value, maxLen = 80000) {
      const out = [];
      const seen = new Set();
      const walk = (v, depth = 0) => {
        if (out.join(' ').length > maxLen || depth > 7 || v == null) return;
        if (typeof v === 'string' || typeof v === 'number') {
          const s = String(v).replace(/\s+/g, ' ').trim();
          if (s) out.push(s);
          return;
        }
        if (typeof v !== 'object') return;
        if (seen.has(v)) return;
        seen.add(v);
        if (Array.isArray(v)) { v.forEach(x => walk(x, depth + 1)); return; }
        Object.entries(v).forEach(([k, val]) => {
          try { if (val != null && (typeof val === 'string' || typeof val === 'number')) out.push(`${k}: ${val}`); }
          catch (_) {}
          walk(val, depth + 1);
        });
      };
      walk(value, 0);
      return out.join(' ').replace(/\s+/g, ' ').trim();
    }

    ygAdiOrtaklikCurrentUserIds() {
      const ids = new Set();
      const add = (v) => {
        const n = this.ygAdiOrtaklikNormalizeKimlikCandidate(v);
        if (n) ids.add(n);
      };
      try { add(getSessionSeed().user); add(getSessionSeed().giris); } catch (_) {}
      try { add(this.ygLookup?.sessionData?.user); add(this.ygLookup?.sessionData?.giris); add(this.ygLookup?.sessionData?.userId); } catch (_) {}
      try { add(window.userId); add(window.CSSession?.userId); add(window.CSSession?.getUserId && window.CSSession.getUserId()); } catch (_) {}
      try { add(window.__istakipEysPageSession?.user); add(window.__istakipEysPageSession?.giris); } catch (_) {}
      return ids;
    }

    ygAdiOrtaklikFilterPartnerIds(ids = []) {
      const current = this.ygAdiOrtaklikCurrentUserIds();
      const out = [];
      for (const x of (ids || [])) {
        const id = this.ygAdiOrtaklikNormalizeKimlikCandidate(x);
        if (!id) continue;
        if (current.has(id)) {
          this.log?.('ygiris', `Adi ortaklık kimlik ayıklama: oturum/kullanıcı no ortak listesinden çıkarıldı: ${id}`, true);
          continue;
        }
        if (!out.includes(id)) out.push(id);
      }
      return out;
    }

    ygAdiOrtaklikExtractKimliksFromObjects(...sources) {
      const scored = new Map();
      const bannedPath = /adres|tel|telefon|cep|gsm|mail|token|session|callid|tarih|zaman|date|time|durum|kod|kodu|sayfa|page|count|adet|limit|org|user|kullanici|kullanıcı|memur|oid|uuid|file|dosya/i;
      const goodPath = /ortak|pay|hisse|kimlik|tckn|tc|vkn|vergi|mukellef|mükellef|kisi|kişi|sahis|şahıs|unvan|bilgi|kaynak/i;
      const push = (num, path = '', val = '') => {
        const id = this.ygAdiOrtaklikNormalizeKimlikCandidate(num);
        if (!id) return;
        let score = 0;
        const p = String(path || '');
        if (goodPath.test(p)) score += 4;
        if (/ortak|pay|hisse/i.test(p)) score += 8;
        if (/kimlik|tckn|tc|vkn|vergi/i.test(p)) score += 6;
        if (/is_vergiNo|vergiNo|vkn|tcKimlikNo|tckn/i.test(p)) score += 5;
        if (bannedPath.test(p) && !/kimlik|tckn|tc|vkn|vergi/i.test(p)) score -= 10;
        const vs = String(val || '');
        if (/ortak|kimlik|tckn|vkn|vergi/i.test(vs)) score += 2;
        const old = scored.get(id);
        if (!old || score > old.score) scored.set(id, { id, score, path: p });
      };
      const walk = (v, path = '', depth = 0, seen = new Set()) => {
        if (v == null || depth > 8) return;
        if (typeof v === 'string' || typeof v === 'number') {
          const s = String(v);
          (s.match(/\b\d{10,11}\b/g) || []).forEach(n => push(n, path, s));
          return;
        }
        if (typeof v !== 'object') return;
        if (seen.has(v)) return;
        seen.add(v);
        if (Array.isArray(v)) { v.forEach((x, i) => walk(x, `${path}[${i}]`, depth + 1, seen)); return; }
        Object.entries(v).forEach(([k, val]) => walk(val, path ? `${path}.${k}` : k, depth + 1, seen));
      };
      sources.forEach(src => walk(src));
      let items = Array.from(scored.values())
        .filter(x => x.score >= 4 && !this.ygAdiOrtaklikCurrentUserIds().has(x.id))
        .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
      // Çok agresif eşleşmelerde adres no / oturum kullanıcısı vb. girmesin diye ilk 6 kimlik ile sınırla.
      return this.ygAdiOrtaklikFilterPartnerIds(items.slice(0, 6).map(x => x.id));
    }

    ygAdiOrtaklikFindDateFromObjects(...sources) {
      const text = sources.map(s => this.ygAdiOrtaklikObjectToText(s, 30000)).join(' ');
      const m1 = text.match(/(\d{2})[.\/-](\d{2})[.\/-](\d{4})/);
      if (m1) return `${m1[3]}${m1[2]}${m1[1]}`;
      const m2 = text.match(/\b(20\d{2})(\d{2})(\d{2})\b/);
      if (m2) return `${m2[1]}${m2[2]}${m2[3]}`;
      return '';
    }

    buildAdiOrtaklikFallbackPreviewText(job, info, failures = []) {
      const ids = this.ygAdiOrtaklikExtractKimliksFromObjects(job, info?.response, info?.data, info);
      if (!ids.length) return '';
      const iseTarih = this.ygAdiOrtaklikFindDateFromObjects(job, info?.response, info?.data, info);
      const unvan = getJobField(job, ['is_unvan','is_unvan_unvan','unvan','mukellefUnvan','mükellefUnvan']) || '';
      const adresNo = this.ygAdiOrtaklikNormalizeKimlikCandidate(getJobField(job, ['adresNo','adres_no','adrNo','is_adresNo'])) || '';
      const txt = [
        'ADI ORTAKLIK İŞE BAŞLAMA BİLDİRİMİ',
        unvan ? `Ünvan: ${unvan}` : '',
        iseTarih ? `İşe Başlama Tarihi: ${iseTarih.slice(6,8)}.${iseTarih.slice(4,6)}.${iseTarih.slice(0,4)}` : '',
        adresNo ? `Adres Numarası: ${adresNo}` : '',
        'Ortaklara İlişkin Bilgiler',
        ids.join(' '),
        'Faaliyet Bilgileri',
        failures?.length ? `PDF metni otomatik okunamadı, İş Takip kayıt alanlarından ortak adayları alındı. ${failures.join(' | ')}` : ''
      ].filter(Boolean).join(' ');
      return txt;
    }

    readYgAdiOrtaklikStoredStatus(job) {
      try {
        const key = this.ygSpecialJobKey(job);
        if (!key) return null;
        const raw = localStorage.getItem('istakip_adi_ortaklik_yoklama_' + key);
        if (!raw) return null;
        const st = JSON.parse(raw);
        if (st && Array.isArray(st.items) && st.items.length) return st;
      } catch (_) {}
      return null;
    }

    storeYgAdiOrtaklikStatus(job, items) {
      const list = (items || []).filter(x => x && (x.ykodu || x.kod));
      if (!list.length) return null;
      const last = list[list.length - 1];
      const st = { durum: last.durum || '10', kod: last.ykodu || last.kod || '', items: list, special: 'adi_ortaklik', fetchedAt: Date.now() };
      job.__ykStatus = st;
      try {
        const key = this.ygSpecialJobKey(job);
        if (key) localStorage.setItem('istakip_adi_ortaklik_yoklama_' + key, JSON.stringify(st));
      } catch (_) {}
      try { this.ygItYkStatusCache?.set(this.getYgItYoklamaStatusCacheKey(job), st); } catch (_) {}
      return st;
    }

    async inflatePdfStreamYg(bytes) {
      // PDF FlateDecode streamleri ikili veridir. Önce zlib-wrapped deflate, olmazsa raw deflate dener.
      if (typeof DecompressionStream === 'undefined') return null;
      const src = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
      for (const fmt of ['deflate', 'deflate-raw']) {
        try {
          const ds = new DecompressionStream(fmt);
          const out = await new Response(new Blob([src]).stream().pipeThrough(ds)).arrayBuffer();
          const arr = new Uint8Array(out);
          if (arr && arr.length) return arr;
        } catch (_) {}
      }
      return null;
    }

    pdfBytesToBinaryStringYg(bytes) {
      // TextDecoder ikili PDF streamlerini bozabildiği için stream arama/dilimleme için 1:1 binary string kullanılır.
      const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
      const chunk = 0x8000;
      let out = '';
      for (let i = 0; i < arr.length; i += chunk) {
        out += String.fromCharCode.apply(null, Array.from(arr.slice(i, i + chunk)));
      }
      return out;
    }

    pdfBytesToStringYg(bytes) {
      try { return new TextDecoder('windows-1254').decode(bytes); } catch (_) {}
      try { return new TextDecoder('iso-8859-9').decode(bytes); } catch (_) {}
      let s = '';
      for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
      return s;
    }

    decodePdfLiteralYg(s) {
      return String(s || '')
        .replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\t/g, '\t').replace(/\\b/g, '\b').replace(/\\f/g, '\f')
        .replace(/\\\(/g, '(').replace(/\\\)/g, ')').replace(/\\\\/g, '\\')
        .replace(/\\([0-7]{1,3})/g, (_, o) => String.fromCharCode(parseInt(o, 8)));
    }

    decodePdfHexYg(hex) {
      const clean = String(hex || '').replace(/[^0-9a-fA-F]/g, '');
      if (!clean) return '';
      const bytes = [];
      for (let i = 0; i < clean.length; i += 2) bytes.push(parseInt(clean.slice(i, i + 2).padEnd(2, '0'), 16));
      if (bytes[0] === 0xfe && bytes[1] === 0xff) {
        let out = '';
        for (let i = 2; i + 1 < bytes.length; i += 2) out += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
        return out;
      }
      return this.pdfBytesToStringYg(new Uint8Array(bytes));
    }

    pdfHexToUnicodeStringYg(hex) {
      const clean = String(hex || '').replace(/[^0-9a-fA-F]/g, '');
      if (!clean) return '';
      const bytes = [];
      for (let i = 0; i < clean.length; i += 2) bytes.push(parseInt(clean.slice(i, i + 2).padEnd(2, '0'), 16));
      if (bytes[0] === 0xfe && bytes[1] === 0xff) {
        let out = '';
        for (let i = 2; i + 1 < bytes.length; i += 2) out += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
        return out;
      }
      // ToUnicode CMap hedefleri genelde UTF-16BE gelir. Türkçe karakter ve rakamlar için bunu önce dene.
      if (bytes.length >= 2 && bytes.length % 2 === 0 && bytes.some((b, i) => i % 2 === 0 && b === 0)) {
        let out = '';
        for (let i = 0; i + 1 < bytes.length; i += 2) out += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
        return out;
      }
      return this.pdfBytesToStringYg(new Uint8Array(bytes));
    }

    buildPdfToUnicodeMapYg(chunks = []) {
      const map = new Map();
      const push = (src, dst) => {
        const s = String(src || '').replace(/[^0-9a-fA-F]/g, '').toUpperCase();
        const d = String(dst || '').replace(/[^0-9a-fA-F]/g, '');
        if (!s || !d) return;
        const val = this.pdfHexToUnicodeStringYg(d);
        if (val) map.set(s, val);
      };
      const parseBody = (body) => {
        const lines = String(body || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
        for (const line of lines) {
          try {
            // <0001> <0041>
            let m = line.match(/^<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>$/);
            if (m) { push(m[1], m[2]); continue; }
            // <0001> <0003> [<0041> <0042> <0043>]
            m = line.match(/^<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*\[([\s\S]*?)\]$/);
            if (m) {
              const start = parseInt(m[1], 16);
              const vals = Array.from(m[3].matchAll(/<([0-9a-fA-F]+)>/g)).map(x => x[1]);
              const width = m[1].length;
              vals.forEach((v, i) => push((start + i).toString(16).toUpperCase().padStart(width, '0'), v));
              continue;
            }
            // <0001> <0003> <0041>
            m = line.match(/^<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>$/);
            if (m) {
              const start = parseInt(m[1], 16);
              const end = parseInt(m[2], 16);
              const dst = parseInt(m[3], 16);
              const width = m[1].length;
              const dstWidth = m[3].length;
              for (let i = 0; i <= Math.min(end - start, 512); i++) {
                push((start + i).toString(16).toUpperCase().padStart(width, '0'), (dst + i).toString(16).toUpperCase().padStart(dstWidth, '0'));
              }
            }
          } catch (_) {}
        }
      };
      const all = (chunks || []).join('\n');
      let m;
      const bfchar = /beginbfchar([\s\S]*?)endbfchar/g;
      while ((m = bfchar.exec(all))) parseBody(m[1]);
      const bfrange = /beginbfrange([\s\S]*?)endbfrange/g;
      while ((m = bfrange.exec(all))) parseBody(m[1]);
      return map;
    }

    decodePdfHexMappedYg(hex, cmap) {
      const clean = String(hex || '').replace(/[^0-9a-fA-F]/g, '').toUpperCase();
      if (!clean) return '';
      if (cmap && cmap.size) {
        const keyLens = Array.from(new Set(Array.from(cmap.keys()).map(k => k.length))).sort((a, b) => b - a);
        let out = '';
        let mapped = 0;
        for (let i = 0; i < clean.length;) {
          let hit = '';
          let len = 0;
          for (const klen of keyLens) {
            const k = clean.slice(i, i + klen);
            if (k.length === klen && cmap.has(k)) { hit = cmap.get(k); len = klen; break; }
          }
          if (len) { out += hit; mapped++; i += len; }
          else {
            // Harita dışı byte/kod gelirse akışı bozmadan ilerle.
            const two = clean.slice(i, i + 2);
            if (two.length === 2) out += this.decodePdfHexYg(two);
            i += 2;
          }
        }
        // En az birkaç karakter map'lendiyse bu metni kullan. Aksi halde eski decode'a düş.
        if (mapped >= 2 || /\d{3,}/.test(out) || /[A-Za-zÇĞİÖŞÜçğıöşü]/.test(out)) return out;
      }
      return this.decodePdfHexYg(clean);
    }

    extractPdfHexRunsFromChunkYg(txt, cmap = null) {
      // Bazı KEYSS PDF'lerinde yazılar Tj/TJ kalıbı ile değil, içerik streaminde CMap kodları olarak dağınık durabiliyor.
      // Gelen PDF cevabının ham/flate açılmış gövdesindeki hex kodlarını ToUnicode haritası ile ayrıca deneriz.
      const body = String(txt || '');
      if (!cmap || !cmap.size || !body) return '';
      const pieces = [];
      const seen = new Set();
      let m;
      const re = /<([0-9a-fA-F\s]{4,})>/g;
      while ((m = re.exec(body))) {
        const clean = String(m[1] || '').replace(/\s+/g, '').toUpperCase();
        if (clean.length < 4 || clean.length > 6000) continue;
        // CMap kaydı yoksa devasa görsel/renk hexlerini decode etmeye çalışma.
        const lens = Array.from(new Set(Array.from(cmap.keys()).map(k => k.length))).sort((a, b) => b - a);
        let hasKnown = false;
        for (const l of lens) {
          for (let i = 0; i + l <= Math.min(clean.length, 80); i += l) {
            if (cmap.has(clean.slice(i, i + l))) { hasKnown = true; break; }
          }
          if (hasKnown) break;
        }
        if (!hasKnown) continue;
        const decoded = this.decodePdfHexMappedYg(clean, cmap).replace(/\s+/g, ' ').trim();
        if (!decoded || decoded.length < 2) continue;
        // Gürültüyü azalt: anlamlı metin, rakam veya Türkçe karakter varsa al.
        if (!(/[0-9A-Za-zÇĞİÖŞÜçğıöşü]/.test(decoded))) continue;
        const key = decoded.slice(0, 160);
        if (seen.has(key)) continue;
        seen.add(key);
        pieces.push(decoded);
      }
      return pieces.join(' ');
    }

    extractPdfTextFromChunkYg(txt, cmap = null) {
      const out = [];
      const body = String(txt || '');
      // Parça parça Tj/TJ operatorlerini al. ToUnicode map varsa 2-byte CID kodlarını gerçek Unicode'a çevirir.
      const re = /\((?:\\.|[^\\)])*\)\s*Tj|\[((?:.|\n|\r)*?)\]\s*TJ|<([0-9a-fA-F\s]+)>\s*Tj/g;
      let m;
      while ((m = re.exec(body))) {
        const full = m[0];
        if (full.includes(' TJ')) {
          const arr = m[1] || '';
          const parts = [];
          let p;
          const r1 = /\((?:\\.|[^\\)])*\)|<([0-9a-fA-F\s]+)>|(-?\d+(?:\.\d+)?)/g;
          while ((p = r1.exec(arr))) {
            const token = p[0];
            if (!token) continue;
            if (token[0] === '(') parts.push(this.decodePdfLiteralYg(token.slice(1, -1)));
            else if (token[0] === '<') parts.push(this.decodePdfHexMappedYg(token.slice(1, -1), cmap));
            else {
              const kern = parseFloat(token);
              if (Number.isFinite(kern) && kern < -120) parts.push(' ');
            }
          }
          if (parts.length) out.push(parts.join(''));
        } else if (m[2]) {
          out.push(this.decodePdfHexMappedYg(m[2], cmap));
        } else {
          const lit = full.match(/\((?:\\.|[^\\)])*\)/);
          if (lit) out.push(this.decodePdfLiteralYg(lit[0].slice(1, -1)));
        }
      }
      // Bazı üreticiler tek tek glyphleri Tm/Td ile yerleştiriyor; araya boşluk koymak tablo okumayı kolaylaştırır.
      return out.join(' ');
    }

    async extractPdfTextYg(arrayBuffer) {
      const bytes = new Uint8Array(arrayBuffer);
      const rawText = this.pdfBytesToStringYg(bytes);
      const rawBinary = this.pdfBytesToBinaryStringYg(bytes);
      const chunks = [rawText];

      // v4.31.85: stream gövdelerini TextDecoder ile bozmayıp byte-byte dilimliyoruz.
      // PDF içindeki Ortaklara İlişkin Bilgiler çoğunlukla FlateDecode stream içinde sıkıştırılmış geliyor.
      const streamRe = /(<<[\s\S]{0,1800}?>>\s*stream\r?\n?)([\s\S]*?)\r?\n?endstream/g;
      let m;
      let inflatedCount = 0;
      while ((m = streamRe.exec(rawBinary))) {
        const header = m[1] || '';
        let body = m[2] || '';
        // stream sonrası tek CR/LF PDF sözdizimine aittir, sıkıştırılmış veriye dahil edilmemeli.
        if (body.charCodeAt(0) === 13 && body.charCodeAt(1) === 10) body = body.slice(2);
        else if (body.charCodeAt(0) === 10 || body.charCodeAt(0) === 13) body = body.slice(1);
        // endstream öncesi satır sonu da çoğu üreticide sözdizimi ayıracıdır.
        if (body.endsWith('\r\n')) body = body.slice(0, -2);
        else if (body.endsWith('\n') || body.endsWith('\r')) body = body.slice(0, -1);
        const b = new Uint8Array(body.length);
        for (let i = 0; i < body.length; i++) b[i] = body.charCodeAt(i) & 255;
        if (/FlateDecode/i.test(header)) {
          const inflated = await this.inflatePdfStreamYg(b);
          if (inflated && inflated.length) {
            inflatedCount++;
            chunks.push(this.pdfBytesToStringYg(inflated));
            chunks.push(this.pdfBytesToBinaryStringYg(inflated));
          }
        } else {
          chunks.push(this.pdfBytesToStringYg(b));
          chunks.push(body);
        }
      }
      try { this.log('ygiris', `Adi ortaklık PDF stream okuma: stream=${(rawBinary.match(/endstream/g) || []).length}, inflate=${inflatedCount}`); } catch (_) {}

      const cmap = this.buildPdfToUnicodeMapYg(chunks);
      const parts = chunks.map(c => this.extractPdfTextFromChunkYg(c, cmap)).filter(Boolean);
      // v4.31.85: Gelen PDF cevabındaki flate açılmış streamlerden Tj/TJ dışındaki CMap hex koşularını da oku.
      // Böylece DevTools > Kaynaklar'da görünen ham PDF cevabındaki tablo, görünür metne çevrilebiliyorsa yakalanır.
      const hexParts = chunks.map(c => this.extractPdfHexRunsFromChunkYg(c, cmap)).filter(Boolean);
      let text = parts.concat(hexParts).join(' ');
      // Son çare: PDF ham/metin parçalarında okunabilir bölümler varsa onları da ekle.
      const allReadable = chunks.join(' ');
      if (!/\b\d{10,11}\b/.test(text) && /Ortaklara|Faaliyet|Kira|Kimlik|Adres/i.test(allReadable)) text += ' ' + allReadable;
      try { this.log('ygiris', `Adi ortaklık PDF metin çözümleme: cmap=${cmap?.size || 0}, tj=${parts.length}, hex=${hexParts.length}, len=${String(text || '').length}`); } catch (_) {}
      return String(text || allReadable || rawText)
        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    }

    async askAdiOrtaklikManualKimliksFromPreview(job, previewUrl, failures = []) {
      // v4.31.91: PDF ayrı popup olarak zaten açıldı. Burada ikinci/üçüncü PDF penceresi açma;
      // sadece popup yanında kopyala-yapıştır/panodan oku penceresini göster.
      const enteredText = await new Promise((resolve) => {
        const old = document.querySelector('.eys-adi-ortaklik-paste-modal');
        try { if (old) old.remove(); } catch (_) {}
        const modal = document.createElement('div');
        modal.className = 'eys-adi-ortaklik-paste-modal';
        modal.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.62);display:flex;align-items:center;justify-content:center;padding:18px;';
        modal.innerHTML = `
          <div style="width:min(980px,96vw);max-height:92vh;background:#10192c;color:#edf4ff;border:1px solid #334a72;border-radius:14px;box-shadow:0 20px 70px rgba(0,0,0,.55);display:flex;flex-direction:column;overflow:hidden;font-family:Segoe UI,Arial,sans-serif;">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px;background:#17233b;border-bottom:1px solid #2d4166;">
              <div style="font-weight:800;font-size:15px;">Adi Ortaklık PDF Metni Girişi</div>
              <button type="button" data-cancel="1" style="background:#3b4963;color:#fff;border:0;border-radius:8px;padding:7px 11px;font-weight:700;cursor:pointer;">Kapat</button>
            </div>
            <div style="padding:12px 14px;color:#c8d4e9;font-size:12px;line-height:1.45;border-bottom:1px solid #263a5f;">
              PDF popup penceresi açık kalsın. PDF penceresinde <b>Ctrl+A</b> ardından <b>Ctrl+C</b> yap. Sonra burada <b>Panodan Oku</b> düğmesine bas; olmazsa metni kutuya elle yapıştır. Bot metinden ortak VKN/TCKN, işe başlama tarihi, faaliyet adresi, adres no, işçi/kira/mülk sahibi bilgilerini yine otomatik ayıklayacak.<br>
              Sadece ortak TC/VKN numaralarını yazarsan da akış devam eder; eksik alanlar mevcut/yedek bilgilerle doldurulur.
            </div>
            <textarea data-text="1" placeholder="PDF'den kopyalanan metni veya ortak TC/VKN numaralarını buraya yapıştır..." style="height:min(420px,48vh);margin:14px;background:#0b1220;color:#e7f3ff;border:1px solid #39547e;border-radius:10px;padding:12px;font:12px/1.45 Consolas,monospace;resize:vertical;outline:none;"></textarea>
            <div style="padding:0 14px 10px;color:#91a4c5;font-size:11px;max-height:70px;overflow:auto;">${htmlEscape((failures || []).slice(0, 5).join(' | '))}</div>
            <div style="display:flex;gap:10px;justify-content:flex-end;padding:12px 14px;background:#121d32;border-top:1px solid #273a5e;">
              <button type="button" data-clipboard="1" style="background:#334a72;color:#fff;border:0;border-radius:9px;padding:9px 13px;font-weight:800;cursor:pointer;">Panodan Oku</button>
              <button type="button" data-ok="1" style="background:#1f7aec;color:#fff;border:0;border-radius:9px;padding:9px 16px;font-weight:900;cursor:pointer;">Metni Oku ve Devam Et</button>
            </div>
          </div>`;
        document.documentElement.appendChild(modal);
        const ta = modal.querySelector('[data-text]');
        const done = (v) => { try { modal.remove(); } catch (_) {} resolve(String(v || '')); };
        modal.querySelector('[data-cancel]').onclick = () => done('');
        modal.querySelector('[data-ok]').onclick = () => done(ta.value || '');
        modal.querySelector('[data-clipboard]').onclick = async () => {
          try {
            let txt = '';
            if (navigator.clipboard && navigator.clipboard.readText) txt = await navigator.clipboard.readText();
            if (txt) {
              ta.value = txt;
              ta.focus();
              this.log?.('ygiris', `Panodan PDF metni alındı. Uzunluk=${txt.length}`);
            } else {
              alert('Pano boş görünüyor. PDF üzerinde Ctrl+A sonra Ctrl+C yapıp tekrar deneyin veya metni kutuya yapıştırın.');
            }
          } catch (e) {
            alert('Pano otomatik okunamadı. PDF üzerinde Ctrl+A / Ctrl+C yaptıktan sonra metni kutuya elle yapıştırın.');
          }
        };
        setTimeout(() => { try { ta.focus(); } catch (_) {} }, 80);
      });

      const ids = Array.from(new Set((String(enteredText || '').match(/\b\d{10,11}\b/g) || [])
        .map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n))
        .filter(Boolean)));
      if (!ids.length && !/ortak|faaliyet|işe başlama|ise baslama|adres numarası|kira|mülk|mulk/i.test(String(enteredText || ''))) return '';
      if (/ortak|faaliyet|işe başlama|ise baslama|adres numarası|kira|mülk|mulk/i.test(String(enteredText || ''))) return String(enteredText || '');
      const iseTarih = this.ygAdiOrtaklikFindDateFromObjects(job);
      const unvan = getJobField(job, ['is_unvan','is_unvan_unvan','unvan','mukellefUnvan','mükellefUnvan']) || '';
      return [
        'ADI ORTAKLIK İŞE BAŞLAMA BİLDİRİMİ',
        unvan ? `Ünvan: ${unvan}` : '',
        iseTarih ? `İşe Başlama Tarihi: ${iseTarih.slice(6,8)}.${iseTarih.slice(4,6)}.${iseTarih.slice(0,4)}` : '',
        'Ortaklara İlişkin Bilgiler',
        ids.join(' '),
        'Faaliyet Bilgileri',
        failures?.length ? `PDF otomatik okunamadı. Manuel girilen ortak kimlikleri kullanıldı. ${failures.join(' | ')}` : 'Manuel girilen ortak kimlikleri kullanıldı.'
      ].filter(Boolean).join(' ');
    }


    async readYgOpenedPreviewTextFromWindow(win, timeoutMs = 3500) {
      if (!win) return '';
      const started = Date.now();
      const readDoc = (doc) => {
        try {
          if (!doc) return '';
          const txt = String(doc.body?.innerText || doc.documentElement?.innerText || '').trim();
          if (txt && txt.length > 50) return txt;
          const frames = Array.from(doc.querySelectorAll('iframe, frame'));
          for (const f of frames) {
            try {
              const t = readDoc(f.contentDocument || f.contentWindow?.document);
              if (t && t.length > 50) return t;
            } catch (_) {}
          }
          const embeds = Array.from(doc.querySelectorAll('embed, object'));
          for (const e of embeds) {
            try {
              const t = String(e.getAttribute('src') || e.getAttribute('data') || '').trim();
              if (t && /pdf|flexpaper|fileid|token/i.test(t)) return t;
            } catch (_) {}
          }
        } catch (_) {}
        return '';
      };
      while (Date.now() - started < timeoutMs) {
        try {
          if (win.closed) break;
          const txt = readDoc(win.document);
          if (txt && (/ortak|başlama|baslama|faaliyet|ünvan|unvan/i.test(txt) || /\b\d{10,11}\b/.test(txt))) return txt;
        } catch (_) {}
        await sleep(250);
      }
      return '';
    }


    async readYgPopupWindowText(pop, timeoutMs = 6000) {
      if (!pop) return '';
      const started = Date.now();
      let best = '';
      const readDeep = (root) => {
        if (!root) return '';
        try {
          const parts = [];
          const push = (v) => { const s = String(v || '').replace(/\s+/g, ' ').trim(); if (s) parts.push(s); };
          push(root.body?.innerText);
          push(root.documentElement?.innerText);
          try { root.querySelectorAll('embed, iframe').forEach(el => push(el.getAttribute('src') || el.src || '')); } catch (_) {}
          try {
            root.querySelectorAll('*').forEach(el => {
              const t = el.innerText || el.textContent || '';
              if (t && t.length > 20) push(t);
            });
          } catch (_) {}
          return parts.join(' ').replace(/\s+/g, ' ').trim();
        } catch (_) { return ''; }
      };
      while (Date.now() - started < timeoutMs) {
        try {
          if (pop.closed) break;
          const href = pop.location?.href || '';
          if (href && href !== 'about:blank') rememberYgPdfPopupUrl(href, 'Adi Ortaklık Önizleme', 'popup-read');
          const doc = pop.document;
          const txt = readDeep(doc);
          if (txt && txt.length > best.length) best = txt;
          if (this.ygAdiOrtaklikIsUsefulPreviewText(txt) && /ortak|kimlik|faaliyet|adres|kira|\b\d{10,11}\b/i.test(txt)) return txt;
        } catch (_) {}
        await sleep(300);
      }
      return this.ygAdiOrtaklikIsUsefulPreviewText(best) ? best : '';
    }

    async readYgPreviewIframeText(timeoutMs = 7000) {
      const started = Date.now();
      let best = '';
      const hasUseful = (txt) => !!(txt && (/ortak|başlama|baslama|faaliyet|ünvan|unvan|adres|kira|mülk|mulk/i.test(txt) || /\b\d{10,11}\b/.test(txt)));
      const readDeep = (root, depth = 0) => {
        if (!root || depth > 4) return '';
        const parts = [];
        try {
          const txt = String(root.body?.innerText || root.documentElement?.innerText || root.textContent || '').trim();
          if (txt) parts.push(txt);
        } catch (_) {}
        let nodes = [];
        try { nodes = Array.from(root.querySelectorAll ? root.querySelectorAll('*') : []); } catch (_) { nodes = []; }
        for (const node of nodes) {
          try {
            if (node.shadowRoot) {
              const t = readDeep(node.shadowRoot, depth + 1);
              if (t) parts.push(t);
            }
          } catch (_) {}
          try {
            const tag = String(node.tagName || '').toLowerCase();
            if (tag === 'iframe' || tag === 'frame') {
              const doc = node.contentDocument || node.contentWindow?.document;
              const t = readDeep(doc, depth + 1);
              if (t) parts.push(t);
            }
          } catch (_) {}
        }
        return parts.join('\n').replace(/[ \t]+/g, ' ').trim();
      };
      while (Date.now() - started < timeoutMs) {
        try {
          const modal = document.querySelector('.eys-yg-preview-modal-instance');
          const frame = modal?.querySelector('#eys-yg-preview-frame');
          const win = frame?.contentWindow;
          const doc = frame?.contentDocument || win?.document;
          try {
            // PDF görüntüleyici sayfaları tembel yükleyebildiği için kısa aralıklarla aşağı/yukarı kaydır.
            if (win && Date.now() - started > 1400) win.scrollTo(0, 999999);
            if (win && Date.now() - started > 3200) win.scrollTo(0, 0);
          } catch (_) {}
          const txt = readDeep(doc);
          if (txt && txt.length > best.length) best = txt;
          if (hasUseful(txt) && txt.length > 80) return txt;
        } catch (_) {}
        await sleep(300);
      }
      return hasUseful(best) ? best : '';
    }

    ygAdiOrtaklikIsUsefulPreviewText(txt) {
      const s = String(txt || '').replace(/\s+/g, ' ').trim();
      return !!(s && s.length > 60 && (/ortak|başlama|baslama|faaliyet|ünvan|unvan|adres|kira|mülk|mulk/i.test(s) || /\b\d{10,11}\b/.test(s)));
    }

    async fetchYgPdfBlobCandidate(c) {
      const url = String(c?.url || '').trim();
      if (!url) throw new Error('PDF URL boş');
      const res = await fetch(url, {
        credentials: 'include',
        cache: 'no-store',
        headers: { 'Accept': 'application/pdf,*/*' }
      });
      if (!res.ok) throw new Error(String(res.status));
      const ct = String(res.headers.get('content-type') || '').toLowerCase();
      const buf = await res.arrayBuffer();
      if (!buf || !buf.byteLength) throw new Error('boş cevap');
      return { url, why: c?.why || 'aday', contentType: ct, buffer: buf, blob: new Blob([buf], { type: ct.includes('pdf') ? 'application/pdf' : (ct || 'application/pdf') }) };
    }

    async readYgPdfBlobViaIframe(blob, title = 'Adi Ortaklık PDF - İndirilen') {
      if (!blob) return '';
      let blobUrl = '';
      try {
        blobUrl = URL.createObjectURL(blob);
        openYgPreviewUrl(blobUrl, title, { forceIframe: true });
        const txt = await this.readYgPreviewIframeText(9000);
        return txt || '';
      } catch (_) {
        return '';
      } finally {
        try { if (blobUrl) setTimeout(() => URL.revokeObjectURL(blobUrl), 45000); } catch (_) {}
      }
    }

    async readYgPreviewPdfByBlobDownload(candidates, failures = []) {
      let iframeTried = false;
      for (const c of (candidates || [])) {
        try {
          this.log('ygiris', `Adi ortaklık PDF dosyası indiriliyor/okunuyor (${c.why || 'aday'}): ${c.url}`);
          const got = await this.fetchYgPdfBlobCandidate(c);
          const text = await this.extractPdfTextYg(got.buffer);
          if (this.ygAdiOrtaklikIsUsefulPreviewText(text)) {
            this.log('ygiris', `Adi ortaklık PDF indirilen dosya içinden okundu (${got.why}).`);
            return text;
          }
          failures.push(`${got.why}=indirildi ama PDF byte metni okunamadı${got.contentType ? ' (' + got.contentType + ')' : ''}`);
          // Aynı PDF'i çok defa pencere/iframe açıp kullanıcıyı boğma; blob iframe yedeğini yalnızca bir kez dene.
          if (!iframeTried) {
            iframeTried = true;
            const iframeText = await this.readYgPdfBlobViaIframe(got.blob, 'Adi Ortaklık PDF - İndirilen Dosya');
            if (this.ygAdiOrtaklikIsUsefulPreviewText(iframeText)) {
              this.log('ygiris', `Adi ortaklık PDF indirilen blob iframe içinden okundu (${got.why}).`);
              return iframeText;
            }
            failures.push(`${got.why}=indirilen blob iframe metni okunamadı`);
          }
        } catch (e) {
          failures.push(`${c?.why || 'aday'}=${e?.message || String(e)}`);
        }
      }
      return '';
    }


    async fetchYgPreviewTextForJob(job) {
      const pOid = findJobPreviewOid(job);
      if (!pOid) throw new Error('Adi ortaklık önizlemesi için keysEvrakOid bulunamadı.');

      const candidates = [];
      const addCandidate = (u, why) => {
        u = String(u || '').trim();
        if (!u) return;
        const base = u.split('#')[0];
        if (!base) return;
        if (!candidates.some(x => x.url === base)) candidates.push({ url: base, why: why || '' });
      };
      const addFileIdVariants = (info, tokenHint) => {
        try {
          const token = String(tokenHint || info?.token || this.resolveYgKeysToken() || '').trim();
          const fid0 = String(info?.fileID || info?.fileId || info?.uuid || '').trim();
          const did = String(info?.dosyaId || info?.dosyaID || '').trim();
          if (!token || !fid0) return;
          const origin = location.origin;
          const fidPdf = fid0.toLowerCase().endsWith('.pdf') ? fid0 : `${fid0}.pdf`;
          addCandidate(`${origin}/keyss/flexpaper/pdf/?token=${encodeURIComponent(token)}&fileID=${fidPdf}#navpanes=0`, 'fileID.pdf');
          addCandidate(`${origin}/keyss/flexpaper/pdf/?token=${encodeURIComponent(token)}&fileID=${encodeURIComponent(fidPdf)}#navpanes=0`, 'fileID.pdf encoded');
          addCandidate(`${origin}/keyss/flexpaper/pdf/?token=${encodeURIComponent(token)}&fileID=${fid0}#navpanes=0`, 'fileID raw');
          if (did) {
            addCandidate(`${origin}/keyss/flexpaper/pdf/?token=${encodeURIComponent(token)}&fileID=${fid0}/${did}#navpanes=0`, 'fileID/dosyaId');
            addCandidate(`${origin}/keyss/flexpaper/pdf/?token=${encodeURIComponent(token)}&fileID=${encodeURIComponent(fid0 + '/' + did)}#navpanes=0`, 'fileID/dosyaId encoded');
          }
        } catch (_) {}
      };

      let info = null;
      const infoObjects = [];
      try {
        if (typeof window.__istakipFetchKeysPreviewInfo === 'function') {
          info = await window.__istakipFetchKeysPreviewInfo(pOid);
          infoObjects.push(info);
          addCandidate(info?.url, 'Ana Modül önizleme bilgisi');
          addFileIdVariants(info, info?.token);
        }
      } catch (e) {
        this.log('ygiris', `Ana Modül önizleme bilgisi alınamadı, EYS yedeği deneniyor: ${e?.message || String(e)}`, true);
      }
      if (!info) {
        info = await this.fetchYgKeysPreviewInfo(pOid);
        infoObjects.push(info);
        addCandidate(info?.url, 'EYS önizleme bilgisi');
        addFileIdVariants(info, info?.token);
      }

      if (!candidates.length) {
        const fallbackNoLink = this.buildAdiOrtaklikFallbackPreviewText(job, info, ['Önizleme PDF linki alınamadı']);
        if (fallbackNoLink) {
          this.log('ygiris', 'PDF linki alınamadı; adi ortaklık kimlikleri İş Takip kayıt alanlarından okunarak devam ediliyor.', true);
          return fallbackNoLink;
        }
        throw new Error('Önizleme PDF linki alınamadı.');
      }
      const failures = [];

      // v4.31.88: Önizle sütunundaki popup nasıl açılıyorsa aynı link önce popup olarak açılır.
      // Popup'ın adres satırındaki gerçek /keyss/flexpaper/pdf linki yakalanıp adaylara eklenir.
      try {
        const pop = openYgPreviewUrl(candidates[0].url, 'Adi Ortaklık Önizleme');
        const popText = await this.readYgPopupWindowText(pop, 3600);
        if (this.ygAdiOrtaklikIsUsefulPreviewText(popText) && /ortak|kimlik|faaliyet|adres|kira|\b\d{10,11}\b/i.test(popText)) {
          this.log('ygiris', 'Adi ortaklık önizleme popup içinden metin olarak okundu.');
          return popText;
        }
        try {
          const href = pop?.location?.href || '';
          if (href && href !== 'about:blank') addCandidate(href, 'popup gerçek linki');
        } catch (_) {}
        getRememberedYgPdfPopupUrls(5 * 60 * 1000).forEach(u => {
          if (/\/keyss\/flexpaper\/pdf\//i.test(u) || /fileID=/i.test(u)) addCandidate(u, 'popup kayıtlı linki');
        });
      } catch (e) {
        failures.push(`popup=${e?.message || String(e)}`);
      }

      // v4.31.91: Popup bir kez açıldıktan sonra PDF cevabını arka planda en fazla URL cevabı olarak okumayı dene.
      // Başarısız olursa yeni PDF/iframe penceresi açma; doğrudan kopyala-yapıştır penceresine geç.
      try {
        const first = candidates[0];
        if (first?.url) {
          const got = await this.fetchYgPdfBlobCandidate(first);
          const text = await this.extractPdfTextYg(got.buffer);
          if (this.ygAdiOrtaklikIsUsefulPreviewText(text)) {
            this.log('ygiris', `PDF gelen cevaptan okundu (${got.why || 'aday'}).`);
            return text;
          }
          failures.push(`${got.why || 'aday'}=gelen PDF cevabı okunamadı${got.contentType ? ' (' + got.contentType + ')' : ''}`);
        }
      } catch (e) {
        failures.push(`gelen-cevap=${e?.message || String(e)}`);
      }

      // İndirilen PDF/Blob ve iframe başarısızsa yedek kayıt alanları veya manuel girişe düşülür.
      const fallbackText = this.buildAdiOrtaklikFallbackPreviewText(job, info, failures);
      if (fallbackText) {
        this.log('ygiris', 'PDF açıldı/indi ancak metin katmanı okunamadı; adi ortaklık kimlikleri İş Takip kayıt alanlarından okunarak devam ediliyor.', true);
        return fallbackText;
      }
      const manualText = await this.askAdiOrtaklikManualKimliksFromPreview(job, candidates[0]?.url, failures);
      if (manualText) {
        this.log('ygiris', 'Gelen PDF cevabı otomatik okunamadı; iframe yedeği açıldı ve manuel girilen ortak kimlikleriyle devam ediliyor.', true);
        return manualText;
      }
      throw new Error('Önizleme PDF indirilemedi/okunamadı. PDF popup/iframe olarak açıldıysa ortak kimliklerini manuel girerek tekrar deneyebilirsiniz. Denenenler: ' + failures.join(' | '));
    }

    parseAdiOrtaklikPdfText(text, job) {
      const raw = String(text || '').replace(/\u00a0/g, ' ');
      const t = raw.replace(/\s+/g, ' ').trim();
      const lower = t.toLocaleLowerCase('tr-TR');
      const normalizeLetters = (s) => String(s || '')
        .replace(/[İIı]/g, 'i').replace(/[Şş]/g, 's').replace(/[Ğğ]/g, 'g')
        .replace(/[Üü]/g, 'u').replace(/[Öö]/g, 'o').replace(/[Çç]/g, 'c');
      const tn = normalizeLetters(t);
      const lown = tn.toLowerCase();
      const sliceBetween = (startRe, endRe, fallback = t) => {
        const m = lown.match(startRe);
        if (!m || m.index == null) return fallback;
        const st = m.index;
        const rest = lown.slice(st + m[0].length);
        const e = rest.match(endRe);
        const en = e && e.index != null ? st + m[0].length + e.index : t.length;
        return t.slice(st, en);
      };
      const labeled = (labelRe, stopRe, src = t) => {
        const sn = normalizeLetters(src);
        const low = sn.toLowerCase();
        const m = low.match(labelRe);
        if (!m || m.index == null) return '';
        const s0 = m.index + m[0].length;
        const rest = src.slice(s0).replace(/^\s*[:：\-]?\s*/, '');
        const restNorm = normalizeLetters(rest).toLowerCase();
        const sm = restNorm.match(stopRe || /$/);
        const cut = sm && sm.index != null ? sm.index : rest.length;
        return rest.slice(0, cut).replace(/\s+/g, ' ').trim();
      };
      const yesNo = (val) => {
        const v = normalizeLetters(val).toLowerCase();
        if (/\bevet\b/.test(v)) return 'Evet';
        if (/\bhayir\b|\bhayır\b/.test(v)) return 'Hayır';
        return '';
      };
      const money = (val) => {
        const s = String(val || '').replace(/[^0-9,\.]/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.');
        const n = parseFloat(s);
        return Number.isFinite(n) ? n : 0;
      };
      const toYmd = (val) => {
        const m = String(val || '').match(/(\d{2})[.\/\-](\d{2})[.\/\-](\d{4})/);
        if (m) return `${m[3]}${m[2]}${m[1]}`;
        const m2 = String(val || '').match(/\b(20\d{2})(\d{2})(\d{2})\b/);
        return m2 ? `${m2[1]}${m2[2]}${m2[3]}` : '';
      };
      const ortakSec = (() => {
        const a = lown.indexOf('ortaklara iliskin');
        let b = a >= 0 ? lown.indexOf('faaliyet bilgileri', a) : -1;
        if (a >= 0 && b > a) return { text: t.slice(a, b), strict: true };
        const h = lown.indexOf('tc/vergi kimlik');
        b = h >= 0 ? lown.indexOf('faaliyet bilgileri', h) : -1;
        if (h >= 0 && b > h) return { text: t.slice(h, b), strict: true };
        return { text: '', strict: false };
      })();
      const ortakSlice = ortakSec.text;
      const extractPartnerIdsFromRows = (src) => {
        const text0 = String(src || '');
        const found = [];
        const re = /\b(\d{10,11})\b/g;
        let mm;
        while ((mm = re.exec(text0))) {
          const id = this.ygAdiOrtaklikNormalizeKimlikCandidate(mm[1]);
          if (!id) continue;
          const before = text0.slice(Math.max(0, mm.index - 80), mm.index);
          const after = text0.slice(mm.index + mm[0].length, mm.index + mm[0].length + 180);
          // Ortak satırındaki kimlik no, hemen sonrasında ad/ünvan ve hisse/onay bilgisi taşır.
          // Telefon, adres no, başvuran/kullanıcı no gibi numaraları bu nedenle almıyoruz.
          const afterTrim = String(after || '').trim();
          const looksPartnerRow = !/^\d{10,11}\b/.test(afterTrim) && /%\s*\d|hisse|onaylad[ıi]|onaylandi/i.test(normalizeLetters(after));
          const looksHeaderOrUser = /tckn\s*\/?\s*vkn|basvuran|başvuran|gonderen|gönderen|kayit eden|kayıt eden|kullanici|kullanıcı|memur|adres\s+numara/i.test(normalizeLetters(before + ' ' + after.slice(0, 50)));
          if (looksPartnerRow && !looksHeaderOrUser && !found.includes(id)) found.push(id);
        }
        return found;
      };
      let ids = extractPartnerIdsFromRows(ortakSlice);
      if (!ids.length && ortakSec.strict) {
        // Son çare: Sadece ortaklar bölümündeki numaraları al; telefonları ve oturum kullanıcısını ayıkla.
        ids = Array.from(new Set((ortakSlice.match(/\b\d{10,11}\b/g) || [])
          .map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n))
          .filter(Boolean)))
          .filter(id => {
            const idx = ortakSlice.indexOf(id);
            const after = ortakSlice.slice(idx + id.length, idx + id.length + 260);
            const around = ortakSlice.slice(Math.max(0, idx - 120), idx + id.length + 360);
            return /%\s*\d|hisse|onaylad[ıi]|onaylandi|onay\s+tarihi|telefon/i.test(normalizeLetters(after + ' ' + around));
          });
      }

      // v4.31.88: Kullanıcı sadece ortak VKN/TCKN numaralarını manuel girerse oluşturulan
      // sentetik metinde hisse/onay satırı bulunmaz. Bu özel durumda yalnızca manuel girilen
      // ortak kimlikleri kabul edilir; oturum/kullanıcı numarası yine çıkarılır.
      if (!ids.length && ortakSec.strict && /manuel\s+girilen\s+ortak\s+kimlikleri|pdf\s+otomatik\s+okunamadi|pdf\s+otomatik\s+okunamadı/i.test(normalizeLetters(t))) {
        const current = this.ygAdiOrtaklikCurrentUserIds();
        ids = Array.from(new Set((ortakSlice.match(/\b\d{10,11}\b/g) || [])
          .map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n))
          .filter(Boolean)
          .filter(id => !current.has(id))));
      }

      // v4.31.85: PDF byte/Chrome PDF text-layer bazen tabloyu satır satır değil, kolon kolon verir.
      // Bu durumda eski "kimlikten hemen sonra hisse/onay gelir" kontrolü ortakları kaçırıyordu.
      // Aşağıdaki gevşek ama güvenli yedek sadece Ortaklara İlişkin Bilgiler / T.C.-Vergi Kimlik tablosu
      // civarından okur; başvuran/kayıt eden/memur ve telefon numaralarını yine dışarıda bırakır.
      const extractPartnerIdsLoose = () => {
        const norm = (s) => normalizeLetters(String(s || '')).toLowerCase();
        const sourceText = String(t || '');
        const sourceNorm = norm(sourceText);
        const makeSection = (startIdx) => {
          if (startIdx < 0) return '';
          const rest = sourceNorm.slice(startIdx);
          const endMatch = rest.match(/faaliyet\s+bilgileri|isci\s+bilgileri|isyeri|is\s*yeri|mulk\s+sahibi|aciklamalar|yukarida\s+bilgileri/i);
          const endIdx = endMatch && endMatch.index != null ? startIdx + endMatch.index : Math.min(sourceText.length, startIdx + 2200);
          return sourceText.slice(startIdx, endIdx);
        };
        const starts = [];
        const addStart = (re) => {
          let m; const r = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
          while ((m = r.exec(sourceNorm))) starts.push(m.index);
        };
        addStart(/ortaklara\s+iliskin/g);
        addStart(/t\.?\s*c\.?\s*\/?\s*vergi\s+kimlik\s+numarasi/g);
        addStart(/vergi\s+kimlik\s+numarasi/g);
        const current = this.ygAdiOrtaklikCurrentUserIds();
        const scoreSection = (sec) => {
          const sn = norm(sec);
          const nums = Array.from(new Set((sec.match(/\b\d{10,11}\b/g) || [])
            .map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n))
            .filter(Boolean)
            .filter(id => !current.has(id))));
          if (!nums.length) return { sec, nums, score: -999 };
          let score = nums.length;
          if (/ortaklara\s+iliskin/.test(sn)) score += 8;
          if (/hisse|%\s*\d/.test(sn)) score += 7;
          if (/onaylad|onaylandi|onay\s+durumu/.test(sn)) score += 5;
          if (/telefon/.test(sn)) score += 2;
          if (/basvuran|kayit\s+eden|kullanici|memur/.test(sn)) score -= 6;
          return { sec, nums, score };
        };
        let sections = starts.map(makeSection).filter(Boolean).map(scoreSection).sort((a,b) => b.score - a.score);
        let best = sections[0];
        if (!best || best.score < 8) {
          // Başlık bulunamadıysa yalnızca hisse/onay çevresindeki dar alanı dene.
          const idx = sourceNorm.search(/hisse|%\s*50|onaylad|onaylandi|onay\s+durumu/);
          if (idx >= 0) best = scoreSection(sourceText.slice(Math.max(0, idx - 650), Math.min(sourceText.length, idx + 1000)));
        }
        if (!best || best.score < 5) return [];
        const sec = best.sec;
        const secNorm = norm(sec);
        const out = [];
        for (const rawNo of (sec.match(/\b\d{10,11}\b/g) || [])) {
          const id = this.ygAdiOrtaklikNormalizeKimlikCandidate(rawNo);
          if (!id || current.has(id) || out.includes(id)) continue;
          const idx = sec.indexOf(rawNo);
          const around = sec.slice(Math.max(0, idx - 180), idx + rawNo.length + 500);
          const ar = norm(around);
          if (/telefon|tel\.?/.test(ar) && /^5\d{9}$/.test(id)) continue;
          if (/basvuran|kayit\s+eden|kullanici|memur|adres\s+numara|vergi\s+dairesi/.test(ar) && !/(hisse|%\s*\d|onaylad|onaylandi)/.test(ar)) continue;
          // Aynı tablo alanında en az bir hisse/onay işareti varsa kolon sıralaması bozuk olsa bile ortak kabul edilir.
          if (/(hisse|%\s*\d|onaylad|onaylandi|onay\s+durumu)/.test(secNorm)) out.push(id);
        }
        // Tablo içinde genellikle ortak sayısı azdır; gereksiz numara kalırsa ilk 6 ile sınırla.
        return out.slice(0, 6);
      };
      if (!ids.length) ids = extractPartnerIdsLoose();
      ids = this.ygAdiOrtaklikFilterPartnerIds(ids);
      const ortaklar = ids.map(id => ({ id, vkn: id.length === 10 ? id : '', tckn: id.length === 11 ? id : '', tip: id.length === 10 ? 'VKN' : 'TCKN' }));

      const iseTarih = toYmd(labeled(/ise\s+baslama\s+tarihi/i, /faaliyet\s+adresi|adres\s+numara|vergi\s+dairesi|ortaklara\s+iliskin/i)) ||
        toYmd((t.match(/itibariyle\s+(\d{2}[.\/\-]\d{2}[.\/\-]\d{4})/i) || [])[1] || '') ||
        this.ygAdiOrtaklikFindDateFromObjects(job);
      const unvan = labeled(/unvani?|unvan[ıi]?/i, /ise\s+baslama\s+tarihi|faaliyet\s+adresi|adres\s+numara|vergi\s+dairesi/i) ||
        getJobField(job, ['is_unvan','is_unvan_unvan','unvan','mukellefUnvan','mükellefUnvan']) || '';
      const adresText = labeled(/faaliyet\s+adresi/i, /adres\s+numara|vergi\s+dairesi|ortaklara\s+iliskin|faaliyet\s+bilgileri/i);
      let adresNo = (t.match(/Adres\s+Numaras[ıiIİ]?\s*[:\-]?\s*(\d{6,20})/i) ||
                     t.match(/Adres\s+No\s*[:\-]?\s*(\d{6,20})/i) ||
                     tn.match(/Adres\s+Numarasi\s*[:\-]?\s*(\d{6,20})/i) || [])[1] || '';
      if (adresNo) adresNo = String(adresNo).replace(/\D+/g, '');
      const faaliyetKod = (t.match(/Faaliyet\s+Kodu[\s\S]{0,140}?(\d{4,8})/i) || [])[1] || '';
      const faaliyetText = (() => {
        const m = t.match(/Faaliyet\s+Kodu[\s\S]{0,260}?\b\d{4,8}\b\s+(.+?)\s+(?:İşçi\s+Bilgileri|Isci\s+Bilgileri|İşyeri\s+Mülk|Is\s*Yeri\s*Mulk|$)/i);
        return m ? m[1].replace(/\s+/g, ' ').trim() : '';
      })();
      const isciCalisacak = yesNo(labeled(/isci\s+calistiracak\s+mi|isçi\s+çalıştıracak\s+m[ıi]/i, /muhtasar\s+beyanname\s+donemi|isyeri\s+mulk|is\s*yeri\s*kira|$|\n/i)) || '';
      const muhtasarDonem = labeled(/muhtasar\s+beyanname\s+donemi/i, /isyeri\s+mulk|is\s*yeri\s*kira|kira\s+donemi|$|\n/i);
      const kiraMi = yesNo(labeled(/is\s*yeri\s+kira\s+mi|iş\s*yeri\s+kira\s+m[ıi]/i, /kira\s+donemi|kira\s+tutar|para\s+cinsi|mulk\s+sahibi|mülk\s+sahibi|aciklamalar|açıklamalar|$|\n/i));
      const kiraDonemiTxt = labeled(/kira\s+donemi|kira\s+dönemi/i, /kira\s+tutar\s+cesidi|kira\s+tutar\s+çeşidi|kira\s+tutari|kira\s+tutarı|para\s+cinsi|mulk\s+sahibi|mülk\s+sahibi|$|\n/i);
      const kiraTutarCesidi = labeled(/kira\s+tutar\s+cesidi|kira\s+tutar\s+çeşidi/i, /kira\s+tutari|kira\s+tutarı|para\s+cinsi|mulk\s+sahibi|mülk\s+sahibi|$|\n/i);
      const kiraSekli = /net/i.test(kiraTutarCesidi) ? '2' : (/brut|brüt/i.test(kiraTutarCesidi) ? '1' : '');
      const kiraTutariTxt = labeled(/kira\s+tutari|kira\s+tutarı/i, /para\s+cinsi|mulk\s+sahibi|mülk\s+sahibi|aciklamalar|açıklamalar|$|\n/i);
      const paraCinsi = labeled(/para\s+cinsi/i, /mulk\s+sahibi|mülk\s+sahibi|aciklamalar|açıklamalar|$|\n/i);
      const mulkSlice = (() => {
        const a = lown.indexOf('mulk sahibine iliskin');
        const b = lown.indexOf('aciklamalar', a >= 0 ? a : 0);
        if (a >= 0 && b > a) return t.slice(a, b);
        return '';
      })();
      const mulkSahibiIds = Array.from(new Set((mulkSlice.match(/\b\d{10,11}\b/g) || [])
        .map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n))
        .filter(Boolean)));
      const kiraDonemi = /aylik|aylık/i.test(kiraDonemiTxt) ? '1' : (/yillik|yıllık/i.test(kiraDonemiTxt) ? '2' : (kiraDonemiTxt ? '3' : ''));
      const para = /tl|try|turk/i.test(paraCinsi) ? '1' : '1';
      const parsed = {
        ids, ortaklar, iseTarih, adresNo, faaliyetKod, faaliyetText,
        unvan: String(unvan || '').trim(), adresText: String(adresText || '').trim(),
        isciCalisacak, muhtasarDonem: String(muhtasarDonem || '').trim(),
        kiraMi, kiraDonemiTxt: String(kiraDonemiTxt || '').trim(), kiraDonemi,
        kiraTutarCesidi: String(kiraTutarCesidi || '').trim(), kiraSekli, kiraTutari: money(kiraTutariTxt),
        paraCinsi: String(paraCinsi || '').trim(), para, mulkSahibiIds,
        mulkSahipleri: [],
        rawText: t.slice(0, 9000)
      };
      try {
        this.log?.('ygiris', `Adi ortaklık metin ayıklandı: ortak=${parsed.ids.join(',') || '-'} tarih=${parsed.iseTarih || '-'} adresNo=${parsed.adresNo || '-'} kira=${parsed.kiraTutari || 0} mülkSahibi=${(parsed.mulkSahibiIds || []).join(',') || '-'}`);
      } catch (_) {}
      return parsed;
    }

    applyAdiOrtaklikParsedFieldsToForm(parsed = {}) {
      if (parsed.iseTarih) this.setYgField('yg_ise_tarih', parsed.iseTarih);
      if (parsed.adresNo) { this.setYgField('yg_adres_no', parsed.adresNo); this.setYgField('yg_adres_no_bel', parsed.adresNo); this.setYgField('yg_adres_no_koy', parsed.adresNo); }
      if (parsed.adresText) {
        this.setYgField('yg_adres_text', parsed.adresText); this.setYgField('yg_adres_text_bel', parsed.adresText); this.setYgField('yg_adres_text_koy', parsed.adresText);
        this.setYgField('yg_aciklama', parsed.adresText);
      }
      if (!parsed.adresNo && parsed.adresText) {
        const chk = this.panel.querySelector('#yg_adres_yetersiz_check');
        if (chk) chk.checked = true;
        this.setYgField('yg_adres_yetersiz', '1');
      }
      if (parsed.isciCalisacak) {
        const calisiyor = parsed.isciCalisacak.toLocaleLowerCase('tr-TR').includes('evet');
        if (!calisiyor) { this.setYgField('yg_asgari', '0'); this.setYgField('yg_diger', '0'); }
      }
      if (parsed.kiraMi) {
        const kiralik = parsed.kiraMi.toLocaleLowerCase('tr-TR').includes('evet');
        this.setYgField('yg_mulkiyet', kiralik ? '2' : '1');
      }
      if (parsed.kiraDonemi) this.setYgField('yg_kira_donemi', parsed.kiraDonemi);
      if (parsed.kiraTutari) this.setYgField('yg_kira_tutari', String(parsed.kiraTutari));
      if (parsed.para) this.setYgField('yg_para', parsed.para);
      if ((Array.isArray(parsed.mulkSahipleri) && parsed.mulkSahipleri.length) || (Array.isArray(parsed.mulkSahibiIds) && parsed.mulkSahibiIds.length)) {
        const srcList = (Array.isArray(parsed.mulkSahipleri) && parsed.mulkSahipleri.length)
          ? parsed.mulkSahipleri
          : parsed.mulkSahibiIds.map(id => ({ vkn: id.length === 10 ? id : '', tckn: id.length === 11 ? id : '', unvan: '', hisse: 100 }));
        this.ygMulkSahipleri = srcList.map(m => ({
          vkn: String(m.vkn || '').replace(/\D+/g, '').slice(0, 10),
          tckn: String(m.tckn || '').replace(/\D+/g, '').slice(0, 11),
          unvan: m.unvan || '',
          hisse: Number(m.hisse || 100)
        }));
        this.ygMulkCurrent = this.ygMulkSahipleri[0] || null;
        const firstId = (this.ygMulkCurrent && (this.ygMulkCurrent.tckn || this.ygMulkCurrent.vkn)) || parsed.mulkSahibiIds?.[0] || '';
        this.setYgField('yg_mulk_vkntckn', firstId);
        try { this.renderYgMulkList(); } catch (_) {}
      }
      if (parsed.faaliyetKod) {
        const sel = this.panel.querySelector('#yg_faaliyet_select');
        if (sel) {
          const opt = Array.from(sel.options || []).find(o => String(o.value || '').includes(parsed.faaliyetKod) || String(o.textContent || '').includes(parsed.faaliyetKod));
          if (opt) sel.value = opt.value;
        }
      }
    }

    async enrichAdiOrtaklikMulkSahipleriFromEys(parsed = {}, sessionData) {
      const ids = Array.isArray(parsed.mulkSahibiIds) ? parsed.mulkSahibiIds : [];
      if (!ids.length) return parsed;
      const out = [];
      for (const id0 of ids) {
        const id = String(id0 || '').replace(/\D+/g, '').slice(0, 11);
        if (id.length !== 10 && id.length !== 11) continue;
        try {
          let raw = null;
          if (id.length === 10) raw = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SICIL_BY_VKN, { vkn: id, sessionData });
          else raw = await post(CFG.EYS_URL, CFG.COMMANDS.YG_UNVAN_BY_TCKN, { tckn: id, sessionData });
          const n = normalizeSicilData(raw, { vkn: id.length === 10 ? id : '', tckn: id.length === 11 ? id : '' });
          out.push({
            vkn: String(n.vergiNo || (id.length === 10 ? id : '') || '').replace(/\D+/g, '').slice(0, 10),
            tckn: String(n.mukellefNo || (id.length === 11 ? id : '') || '').replace(/\D+/g, '').slice(0, 11),
            unvan: n.kimlikUnvan || '',
            hisse: 100
          });
          this.log('ygiris', `Adi ortaklık mülk sahibi sicil okundu: ${out[out.length - 1].vkn || out[out.length - 1].tckn} ${out[out.length - 1].unvan || ''}`);
        } catch (e) {
          this.log('ygiris', `Adi ortaklık mülk sahibi sicil okunamadı (${id}): ${e?.message || String(e)}`, true);
          out.push({ vkn: id.length === 10 ? id : '', tckn: id.length === 11 ? id : '', unvan: '', hisse: 100 });
        }
      }
      parsed.mulkSahipleri = out.length ? out : parsed.mulkSahipleri || [];
      return parsed;
    }

    buildAdiOrtaklikHarAciklama(parsed = {}) {
      const lines = [];
      const first = [parsed.unvan || '', parsed.faaliyetKod || '', parsed.faaliyetText || ''].filter(Boolean).join('   ');
      if (first) lines.push(first);
      if (parsed.isciCalisacak) lines.push(`İşçi Çalıştıracak Mı : ${parsed.isciCalisacak}`);
      if (parsed.muhtasarDonem) lines.push(`Muhtasar Beyanname Dönemi : ${parsed.muhtasarDonem}`);
      if (parsed.kiraMi) lines.push(`İş Yeri Kira Mı : ${parsed.kiraMi}`);
      if (parsed.kiraDonemiTxt) lines.push(`Kira Dönemi : ${parsed.kiraDonemiTxt}`);
      if (parsed.kiraTutarCesidi) lines.push(`Kira Tutar Çeşidi : ${parsed.kiraTutarCesidi}`);
      if (parsed.kiraTutari) lines.push(`Kira Tutarı : ${parsed.kiraTutari}`);
      if (parsed.paraCinsi) lines.push(`Para Cinsi : ${parsed.paraCinsi}`);
      if (Array.isArray(parsed.mulkSahipleri) && parsed.mulkSahipleri.length) {
        lines.push(`Mülk Sahibi : ${parsed.mulkSahipleri.map(m => [m.vkn || m.tckn, m.unvan].filter(Boolean).join(' ')).join(', ')}`);
      } else if (Array.isArray(parsed.mulkSahibiIds) && parsed.mulkSahibiIds.length) {
        lines.push(`Mülk Sahibi : ${parsed.mulkSahibiIds.join(', ')}`);
      }
      return lines.join('\n').trim();
    }

    enrichAdiOrtaklikYoklamaPayload(yoklama, parsed = {}) {
      const y = yoklama || {};
      // Gerçek HAR'da mukGrupData.faaliyetKonusu çoğu kez EYS sicil/faaliyet servisinden gelen NACE ile kalıyor;
      // PDF'teki faaliyet kodu/açıklaması yoklama açıklamasına yazılıyor.
      y.mukGrupData = y.mukGrupData || {};
      if (!y.mukGrupData.mukGrup) y.mukGrupData.mukGrup = '1';
      if (!y.mukGrupData.isletmeTuru) y.mukGrupData.isletmeTuru = '1';
      if (!y.mukGrupData.isyeriTuru) y.mukGrupData.isyeriTuru = '0';
      if (!y.mukGrupData.faaliyetKonusu && parsed.faaliyetText) y.mukGrupData.faaliyetKonusu = parsed.faaliyetText;
      if (parsed.adresNo || parsed.adresText) {
        y.yoklamaAdresi = y.yoklamaAdresi || {};
        if (parsed.adresNo) {
          y.yoklamaAdresi.ano = String(parsed.adresNo);
          if (!y.yoklamaAdresi.ickapi) y.yoklamaAdresi.ickapi = String(parsed.adresNo);
        }
        if (parsed.adresText) {
          if (!y.yoklamaAdresi.atext) y.yoklamaAdresi.atext = parsed.adresText;
          if (!y.yoklamaAdresi.aciklama) y.yoklamaAdresi.aciklama = parsed.adresText;
        }
      }
      const ib = y.detay && (y.detay.iseBaslama || y.detay.tuzelIseBaslama || y.detay.subeAcilis || y.detay.genel);
      if (ib && typeof ib === 'object') {
        if (parsed.isciCalisacak) ib.isciCalistiracakMi = parsed.isciCalisacak;
        if (parsed.muhtasarDonem) ib.muhtasarBeyannameDonemi = parsed.muhtasarDonem;
        if (parsed.kiraMi) ib.isYeriKiraMi = parsed.kiraMi;
        if (parsed.kiraTutarCesidi) ib.kiraTutarCesidi = parsed.kiraTutarCesidi;
        if (parsed.kiraDonemiTxt) ib.kiraDonemiText = parsed.kiraDonemiTxt;
        if (parsed.paraCinsi) ib.paraCinsiText = parsed.paraCinsi;
        const mulkList = (Array.isArray(parsed.mulkSahipleri) && parsed.mulkSahipleri.length)
          ? parsed.mulkSahipleri
          : ((parsed.mulkSahibiIds || []).map(id => ({ vkn: id.length === 10 ? id : '', tckn: id.length === 11 ? id : '', unvan: '', hisse: 100 })));
        if (mulkList.length) {
          ib.kiralik = ib.kiralik || {};
          ib.kiralik.mulkSahibi = mulkList.map(m => ({
            vkn: String(m.vkn || '').replace(/\D+/g, '').slice(0, 10),
            tckn: String(m.tckn || '').replace(/\D+/g, '').slice(0, 11),
            unvan: m.unvan || '',
            hisse: Number(m.hisse || 100)
          }));
        }
        if (parsed.kiraMi && parsed.kiraMi.toLocaleLowerCase('tr-TR').includes('evet')) {
          ib.mulkiyet = '2';
          ib.kiralik = ib.kiralik || {};
        }
        if (ib.kiralik) {
          if (parsed.kiraSekli) ib.kiralik.odemeSekli = parsed.kiraSekli;
          else if (!ib.kiralik.odemeSekli) ib.kiralik.odemeSekli = '2';
          if (parsed.kiraTutari) ib.kiralik.kiraMiktari = Number(parsed.kiraTutari || 0);
          if (parsed.kiraDonemi) ib.kiralik.odemeDonemi = parsed.kiraDonemi;
          if (parsed.para) ib.kiralik.paraBirimi = parsed.para;
        }
      }
      const harAciklama = this.buildAdiOrtaklikHarAciklama(parsed);
      if (harAciklama) y.yoklamaAciklama = harAciklama;
      if (parsed.adresNo) {
        y.yoklamaAdresi = y.yoklamaAdresi || {};
        y.yoklamaAdresi.ano = String(parsed.adresNo);
        y.yoklamaAdresi.ickapi = y.yoklamaAdresi.ickapi || String(parsed.adresNo);
        y.yoklamaAdresi.yetersiz = 0;
        if (!y.yoklamaAdresi.aciklama) y.yoklamaAdresi.aciklama = '';
      }
      y.adiOrtaklikKaynak = {
        aktifOrtakId: parsed.aktifOrtakId || '',
        aktifOrtakSira: parsed.aktifOrtakSira || '',
        aktifOrtakToplam: parsed.aktifOrtakToplam || '',
        ortaklikUnvan: parsed.unvan || '',
        iseBaslamaTarihi: parsed.iseTarih || '',
        faaliyetAdresi: parsed.adresText || '',
        adresNo: parsed.adresNo || '',
        ortaklar: parsed.ortaklar || [],
        isciCalisacak: parsed.isciCalisacak || '',
        kiraMi: parsed.kiraMi || '',
        kiraDonemi: parsed.kiraDonemiTxt || '',
        kiraTutarCesidi: parsed.kiraTutarCesidi || '',
        kiraTutari: parsed.kiraTutari || 0,
        paraCinsi: parsed.paraCinsi || '',
        mulkSahibiIds: parsed.mulkSahibiIds || []
      };
      return y;
    }

    async saveYgPartnerYoklamaFromAdiOrtaklik(job, identity, parsed, sessionData) {
      const id = String(identity || '').replace(/\D+/g, '').slice(0, 11);
      if (id.length !== 10 && id.length !== 11) throw new Error('Ortak kimlik no geçersiz: ' + identity);
      this.ygLookup = null;
      this.ygSelectedKnownAddress = null;
      this.setYgField('yg_vkntckn', id);
      this.setYgField('yg_tckn', id.length === 11 ? id : '');
      const yt = this.panel.querySelector('#yg_yturu');
      if (yt) { yt.value = '10'; yt.dispatchEvent(new Event('change', { bubbles: true })); }
      this.setYgField('yg_istakip_oid', this.ygItFindIsTakipNo(job) || this.ygFindAkisOid(job) || '');
      this.setYgField('yg_yoklama_aciklama', parsed?.specialKind === 'tekIseBaslama' ? `İşe başlama bildirimi sistem harici yeniden yoklaması. İşTakip: ${this.ygItFindIsTakipNo(job) || '-'}` : `Adi ortaklık işe başlama bildirimi ortak yoklaması. İşTakip: ${this.ygItFindIsTakipNo(job) || '-'}`);
      try { await this.lookupYoklamaGiris(); } catch (e) { this.log('ygiris', `Ortak sicil/adres sorgusu uyarı (${id}): ${e?.message || String(e)}`, true); }
      try { await this.enrichAdiOrtaklikMulkSahipleriFromEys(parsed, this.ygLookup?.sessionData || sessionData); } catch (_) {}
      this.applyAdiOrtaklikParsedFieldsToForm(parsed);
      if (parsed.adresNo) {
        this.setYgField('yg_adres_no', parsed.adresNo); this.setYgField('yg_adres_no_bel', parsed.adresNo); this.setYgField('yg_adres_no_koy', parsed.adresNo);
        try { await this.lookupYgAdresNo(); } catch (e) { this.log('ygiris', `Ortaklık adres no sorgusu uyarı (${parsed.adresNo}): ${e?.message || String(e)}`, true); }
      } else if (parsed.adresText) {
        this.setYgField('yg_adres_text', parsed.adresText); this.setYgField('yg_adres_text_bel', parsed.adresText); this.setYgField('yg_adres_text_koy', parsed.adresText);
        this.setYgField('yg_aciklama', parsed.adresText);
        const chk = this.panel.querySelector('#yg_adres_yetersiz_check');
        if (chk) chk.checked = true;
        this.setYgField('yg_adres_yetersiz', '1');
      }
      const built = this.buildYoklamaGirisPayload(this.getYoklamaGirisConfig());
      this.enrichAdiOrtaklikYoklamaPayload(built.yoklama, parsed);
      const kimlikNo = built.yoklama.kimlik.vkn || built.yoklama.kimlik.tckn;
      try { await post(CFG.EYS_URL, CFG.COMMANDS.YG_TERK_BILGI, { vkntckn: kimlikNo, kodu: '', val: '', sessionData: built.sessionData }); } catch (_) {}
      const saveYoklama = this.compactYgSavePayloadForMemurHar(built.yoklama);
      const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SAVE, { yoklama: JSON.stringify(saveYoklama), sessionData: built.sessionData });
      const rawData = parsePossiblyJsonData(resp) || {};
      const data = rawData?.data && typeof rawData.data === 'object' ? rawData.data : rawData;
      const ykodu = data.ykodu || data.yKodu || data.yKODU || data.ykoduYeni || '';
      const durum = data.durum || data.DURUM || data.ydurum || '10';
      if (!ykodu) throw new Error('Kaydet cevabında yKodu alınamadı. Cevap: ' + previewResponse(resp));
      const labelTip = id.length === 10 ? 'VKN' : 'TCKN';
      const ortakLabel = parsed?.specialKind === 'tekIseBaslama'
        ? `${labelTip} ${id}`
        : `${parsed?.aktifOrtakSira || ''}. ${labelTip} ${id}`.trim();
      return { ykodu, kod: ykodu, durum, kisi: id, ortakKimlik: id, aktifOrtakId: id, ortakLabel, ortakSira: parsed?.aktifOrtakSira || 0, ortakToplam: parsed?.aktifOrtakToplam || 0, optime: new Date().toISOString(), aciklama: parsed?.specialKind === 'tekIseBaslama' ? 'İşe başlama mükellefi' : 'Adi ortaklık ortağı' };
    }

    async postYgItWorkflowActionNoConfirm(job, action) {
      const payload = this.buildYgItSavePayload(job, action);
      if (!payload.isTakipNo) throw new Error('isTakipNo bulunamadı');
      if (!payload.akisOid) throw new Error('akisOid bulunamadı');
      if (!payload.orgoid) throw new Error('orgoid bulunamadı');
      const d = this.getYgItDiscovery();
      const resp = await this.postYgIsTakip('akisIslemleri_akisYeniAdimKaydet', payload, d.token);
      job.__sent = true;
      job.__lastActionSent = this.ygItActionLabel(action);
      job.__sendResp = resp;
      return resp;
    }


    parseYgIseBaslamaTekPdfText(text, job) {
      const t = String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
      const normalizeLetters = (s) => String(s || '')
        .replace(/[İIı]/g, 'i').replace(/[Şş]/g, 's').replace(/[Ğğ]/g, 'g')
        .replace(/[Üü]/g, 'u').replace(/[Öö]/g, 'o').replace(/[Çç]/g, 'c');
      const low = normalizeLetters(t).toLowerCase();
      const labeled = (labelRe, stopRe, src = t) => {
        const normSrc = normalizeLetters(src);
        const sl = normSrc.toLowerCase();
        const m = sl.match(labelRe);
        if (!m || m.index == null) return '';
        const start = m.index + m[0].length;
        const rest = src.slice(start).replace(/^\s*[:：\-]?\s*/, '');
        const restLow = normalizeLetters(rest).toLowerCase();
        const sm = restLow.match(stopRe || /$/);
        const cut = sm && sm.index != null ? sm.index : rest.length;
        return rest.slice(0, cut).replace(/\s+/g, ' ').trim();
      };
      const toYmd = (val) => {
        const m = String(val || '').match(/(\d{2})[.\/\-](\d{2})[.\/\-](\d{4})/);
        if (m) return `${m[3]}${m[2]}${m[1]}`;
        const m2 = String(val || '').match(/\b(20\d{2})(\d{2})(\d{2})\b/);
        return m2 ? `${m2[1]}${m2[2]}${m2[3]}` : '';
      };
      const money = (val) => {
        const s = String(val || '').replace(/[^0-9,\.]/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.');
        const n = parseFloat(s);
        return Number.isFinite(n) ? n : 0;
      };
      const idLine = labeled(/t\.?\s*c\.?\s*\/?\s*vergi\s+kimlik\s+numarasi/i, /adres\s*:|cep\s+telefonu|ise\s+baslama\s+bildirimine|faaliyet\s+adresi/i);
      let nums = Array.from(new Set((idLine.match(/\b\d{10,11}\b/g) || []).map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n)).filter(Boolean)));
      if (!nums.length) {
        const start = low.indexOf('basvuru sahibine iliskin');
        const end = start >= 0 ? low.indexOf('ise baslama bildirimine', start) : -1;
        const sec = start >= 0 && end > start ? t.slice(start, end) : t.slice(0, Math.min(t.length, 1600));
        nums = Array.from(new Set((sec.match(/\b\d{10,11}\b/g) || []).map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n)).filter(Boolean)));
      }
      nums = nums.filter(id => !this.ygAdiOrtaklikCurrentUserIds().has(id));
      const vkn = nums.find(x => x.length === 10) || '';
      const tckn = nums.find(x => x.length === 11) || '';
      const selectedId = vkn || tckn || nums[0] || '';
      const iseTarih = toYmd(labeled(/ise\s+baslama\s+tarihi/i, /faaliyet\s+adresi|adres\s+numarasi|vergi\s+dairesi|faaliyet\s+bilgileri/i)) || this.ygAdiOrtaklikFindDateFromObjects(job);
      const unvan = labeled(/adi\s+soyadi\s*\/\s*unvani/i, /t\.?\s*c\.?\s*\/?\s*vergi\s+kimlik|adres\s*:/i) || getJobField(job, ['is_unvan','is_unvan_unvan','unvan','mukellefUnvan']) || '';
      const adresText = labeled(/faaliyet\s+adresi/i, /adres\s+numarasi|vergi\s+dairesi|faaliyet\s+bilgileri/i);
      const adresNo = (labeled(/adres\s+numarasi/i, /vergi\s+dairesi|faaliyet\s+bilgileri|isci\s+bilgileri/i).match(/\d{5,}/) || [])[0] || '';
      const isciText = labeled(/isci\s+calistiracak\s+mi/i, /muhtasar|is\s*yeri|isyeri|bu\s+belge/i);
      const kiraText = labeled(/is\s*yeri\s+kira\s+mi/i, /is\s*yeri\s+detayi|kira\s+donemi|kira\s+tutari|mulk\s+sahibi|e\s*-?tebligat|bildirim\s+tercihleri|bu\s+belge/i);
      const kiraMi = /evet/i.test(normalizeLetters(kiraText)) ? 'Evet' : (/hayir|hayır/i.test(kiraText) ? 'Hayır' : '');
      const kiraDonemiTxt = labeled(/kira\s+donemi/i, /kira\s+tutari|kira\s+tutar|para\s+cinsi|mulk\s+sahibi|e\s*-?tebligat/i);
      const kiraTutari = money(labeled(/kira\s+tutari/i, /para\s+cinsi|mulk\s+sahibi|e\s*-?tebligat|bildirim/i));
      const paraCinsi = labeled(/para\s+cinsi/i, /mulk\s+sahibi|e\s*-?tebligat|bildirim/i);
      const mulkSec = labeled(/mulk\s+sahib/i, /e\s*-?tebligat|bildirim|bu\s+belge/i);
      const mulkSahibiIds = Array.from(new Set((mulkSec.match(/\b\d{10,11}\b/g) || []).map(n => this.ygAdiOrtaklikNormalizeKimlikCandidate(n)).filter(Boolean)));
      return {
        specialKind: 'tekIseBaslama',
        ids: selectedId ? [selectedId] : [],
        ortaklar: selectedId ? [{ id: selectedId, vkn: selectedId.length === 10 ? selectedId : vkn, tckn: selectedId.length === 11 ? selectedId : tckn, tip: selectedId.length === 10 ? 'VKN' : 'TCKN' }] : [],
        unvan, iseTarih, adresText, adresNo,
        isciCalisacak: /evet/i.test(normalizeLetters(isciText)) ? 'Evet' : (/hayir|hayır/i.test(isciText) ? 'Hayır' : ''),
        kiraMi, kiraDonemiTxt, kiraDonemi: /yil|yıl/i.test(kiraDonemiTxt) ? '2' : '1',
        kiraTutarCesidi: /net/i.test(low) ? 'NET' : '', kiraSekli: /net/i.test(low) ? '2' : '',
        kiraTutari, paraCinsi, para: /tl|try|turk/i.test(normalizeLetters(paraCinsi).toLowerCase()) ? '1' : '',
        mulkSahibiIds,
        hamMetin: t
      };
    }

    async handleYgIseBaslamaTekWorkflow(job, action, opts = {}) {
      const key = this.ygSpecialJobKey(job);
      this.log('ygiris', `İşe başlama sistem harici yeniden yoklama akışı başlıyor. İşTakip=${this.ygItFindIsTakipNo(job) || key || '-'}`);
      const text = await this.fetchYgPreviewTextForJob(job);
      let parsed = this.parseYgIseBaslamaTekPdfText(text, job);
      if (!parsed.ids.length) {
        this.log('ygiris', 'Önizleme metni alındı fakat mükellef VKN/TCKN ayıklanamadı; manuel/kopyala-yapıştır yedeği açılıyor.', true);
        const manualText = await this.askAdiOrtaklikManualKimliksFromPreview(job, '', ['Önizleme metni alındı ama mükellef VKN/TCKN ayıklanamadı']);
        if (manualText) parsed = this.parseYgIseBaslamaTekPdfText(manualText, job);
      }
      if (!parsed.ids.length) throw new Error('İşe başlama PDF içinde mükellef TCKN/VKN okunamadı.');
      const id = parsed.ids[0];
      if (opts.ask !== false) {
        const ok = confirm(`İşe başlama için sistem harici yeniden yoklama çıkarılacak.\n\nMükellef: ${id}\nTarih: ${parsed.iseTarih || '-'}\nAdres No: ${parsed.adresNo || '-'}\n\nDevam edilsin mi?`);
        if (!ok) { this.log('ygiris', 'İşe başlama sistem harici akışı iptal edildi.'); return null; }
      }
      const sessionData = this.ygLookup?.sessionData || await this.bootRole(this.getYoklamaGirisConfig().role || '10', 'ygiris');
      const item = await this.saveYgPartnerYoklamaFromAdiOrtaklik(job, id, Object.assign({}, parsed, { aktifOrtakId: id, aktifOrtakSira: 1, aktifOrtakToplam: 1 }), sessionData);
      const st = this.storeYgAdiOrtaklikStatus(job, [item]);
      this.renderYgItJobs();
      this.log('ygiris', `İşe başlama sistem harici yoklama kaydedildi: ${id} / ${item.ykodu}`);
      return st;
    }

    async handleYgIseBaslamaTekWorkflowFromMain(job, action) {
      return this.handleYgIseBaslamaTekWorkflow(job, action, { ask: true });
    }

    async handleYgAdiOrtaklikWorkflow(job, action, opts = {}) {
      const key = this.ygSpecialJobKey(job);
      const existing = this.readYgAdiOrtaklikStoredStatus(job);
      if (existing && existing.items?.length && !opts.forceDuplicate) {
        job.__ykStatus = existing;
        job.__eligible = false;
        job.__excludeReason = 'Mevcut adi ortaklık yoklaması var; mükerrer engellendi';
        this.renderYgItJobs();
        const kodlar = (existing.items || []).map(x => this.ygItYkGetKod(x)).filter(Boolean).join(', ') || existing.kod || '-';
        this.log('ygiris', `Adi ortaklık mükerrer engellendi. İşTakip=${this.ygItFindIsTakipNo(job) || key || '-'} mevcut kodlar: ${kodlar}`);
        return existing;
      }
      this.log('ygiris', `Adi ortaklık işe başlama özel akışı başlıyor. İşTakip=${this.ygItFindIsTakipNo(job) || key || '-'}`);
      const text = await this.fetchYgPreviewTextForJob(job);
      let parsed = this.parseAdiOrtaklikPdfText(text, job);
      if (!parsed.ids.length) {
        this.log('ygiris', 'Önizleme metni alındı fakat ortaklar tablosu ayıklanamadı; manuel/kopyala-yapıştır yedeği açılıyor.', true);
        const manualText = await this.askAdiOrtaklikManualKimliksFromPreview(job, '', ['Önizleme metni alındı ama ortaklar tablosu ayıklanamadı']);
        if (manualText) parsed = this.parseAdiOrtaklikPdfText(manualText, job);
      }
      if (!parsed.ids.length) throw new Error('Önizleme PDF içinde ortak kimlik numaraları okunamadı. Önizlemeden ortaklar tablosunun metni alınamadı.');
      const listText = parsed.ids.map((x, i) => `${i + 1}. ${x}`).join('\n');
      if (opts.ask !== false) {
        const ok = confirm(`Adi ortaklık işe başlama için ${parsed.ids.length} ortak bulundu.\n\nHAR örneği tek ortağın yoklama kaydıdır; bot aynı temel PDF/HAR bilgisini kullanıp her ortak için ayrı ayrı İşe Başlama yoklaması kaydedecek. Çıkan kodlar listede ortak VKN/TCKN etiketiyle gösterilecek.\n\n${listText}\n\nDevam edilsin mi?`);
        if (!ok) { this.log('ygiris', 'Adi ortaklık özel akışı iptal edildi.'); return existing || null; }
      }
      const sessionData = this.ygLookup?.sessionData || await this.bootRole(this.getYoklamaGirisConfig().role || '10', 'ygiris');
      this.log('ygiris', `Adi ortaklık HAR şablonu tek ortak kaydıdır; ${parsed.ids.length} ortak için ayrı ayrı saveYoklama gönderilecek.`);
      const results = [];
      for (let i = 0; i < parsed.ids.length; i++) {
        const id = parsed.ids[i];
        const parsedForPartner = Object.assign({}, parsed, { aktifOrtakId: id, aktifOrtakSira: i + 1, aktifOrtakToplam: parsed.ids.length });
        this.log('ygiris', `Adi ortaklık ortak yoklaması kaydediliyor ${i + 1}/${parsed.ids.length}: ${id}`);
        const item = await this.saveYgPartnerYoklamaFromAdiOrtaklik(job, id, parsedForPartner, sessionData);
        results.push(item);
        this.log('ygiris', `Adi ortaklık ortak yoklaması kaydedildi: ${id} / ${item.ykodu}`);
      }
      const st = this.storeYgAdiOrtaklikStatus(job, results);
      try {
        if (action) {
          await this.postYgItWorkflowActionNoConfirm(job, action);
          this.log('ygiris', 'Adi ortaklık yoklamaları oluşturulduktan sonra İş Takip akışı da gönderildi.');
        }
      } catch (e) {
        this.log('ygiris', `Yoklamalar oluşturuldu fakat İş Takip akışı gönderilemedi: ${e?.message || String(e)}`, true);
      }
      this.renderYgItJobs();
      return st;
    }

    async handleYgAdiOrtaklikWorkflowFromMain(job, action) {
      return this.handleYgAdiOrtaklikWorkflow(job, action, { ask: true });
    }

    getYgItKaynakText(job) {
      const ek = job?.kaynakEkBilgiler || {};
      return [
        job?.is_kaynakbilgi,
        job?.isKaynakBilgi,
        job?.is_kaynakbilgisi,
        ek?.is_kaynakbilgi,
        ek?.isKaynakBilgi,
        ek?.is_kaynakBilgi,
        ek?.is_kaynakBilgisi,
        ek?.isKaynakBilgisi,
        ek?.is_kaynak_bilgi,
        ek?.is_kaynak_bilgisi
      ].filter(Boolean).map(v => String(v)).join(' | ');
    }

    getYgItExcludeReason(job) {
      const joined = this.getYgItKaynakText(job).toLowerCase();
      if (!joined) return '';
      if (joined.includes('muhtasar dönem değişikliği bildirimi')) return 'is_kaynakbilgi içinde Muhtasar Dönem Değişikliği Bildirimi geçtiği için hariç';
      if (joined.includes('mersis no')) return 'is_kaynakbilgi içinde Mersis No geçtiği için hariç';
      return '';
    }

    getYgItBelgeBilgiText(job) {
      const ek = job?.kaynakEkBilgiler || {};
      const vals = [
        job?.belgeBilgi,
        job?.is_belgeBilgi,
        job?.belge_bilgi,
        job?.is_kaynakbilgi,
        job?.is_kaynakbilgisi,
        ek?.belgeBilgi,
        ek?.is_belgeBilgi,
        ek?.belge_bilgi,
        ek?.is_kaynakbilgi,
        ek?.isKaynakBilgi
      ].filter(v => String(v ?? '').trim());
      const out = [];
      const seen = new Set();
      vals.forEach(v => {
        const t = String(v).replace(/\s+/g, ' ').trim();
        const k = t.toLowerCase();
        if (t && !seen.has(k)) { seen.add(k); out.push(t); }
      });
      return out.join(' | ') || '-';
    }

    getYgItIsTuruText(job) {
      const detailId = Number(getJobField(job, ['is_detayId','txtGizliDetayId']) || 0);
      const dynamicText = this.ygItDetailMap?.[detailId];
      if (dynamicText) return dynamicText;
      return getJobField(job, ['txtIsTuru','isTuru','is_turu','is_kaynakbilgi','is_kaynakbilgisi']) || '-';
    }

    ygFindAkisOid(job) {
      return String(getJobField(job, ['akis_oid','akisOid','oid','is_akisOid']) || '').trim();
    }

    ygFindOrgoid(job) {
      const d = this.getYgItDiscovery();
      return String(
        getJobField(job, ['orgoid','orgOid','is_sicil_orgoid','sicilOrgOid']) ||
        d.orgoid ||
        getSessionSeed().org ||
        ''
      ).trim();
    }

    async evaluateYgItJobStatuses(rows) {
      const list = Array.isArray(rows) ? rows : [];
      if (!list.length) return;
      const d = this.getYgItDiscovery();
      this.log('ygiris', `İş Takip durum/uygunluk kontrolü başlıyor. kayıt=${list.length}`);
      for (let i = 0; i < list.length; i++) {
        const job = list[i];
        const reason = this.getYgItExcludeReason(job);
        if (reason) {
          job.__eligible = false;
          job.__excludeReason = reason;
          if (i === 0 || (i + 1) % 10 === 0 || i === list.length - 1) this.renderYgItJobs();
          continue;
        }
        const akisOid = this.ygFindAkisOid(job);
        const orgoid = this.ygFindOrgoid(job);
        if (!akisOid || !orgoid) {
          job.__eligible = false;
          job.__error = !akisOid ? 'akisOid bulunamadı' : 'orgoid bulunamadı';
          if (i === 0 || (i + 1) % 10 === 0 || i === list.length - 1) this.renderYgItJobs();
          continue;
        }
        try {
          const resp = await this.postYgIsTakip('akisIslemleri_isTakipSonrakiAdimlariBul', { orgoid, akisOid }, d.token);
          const steps = resp?.data?.hedefAdimlar || resp?.hedefAdimlar || [];
          job.__steps = Array.isArray(steps) ? steps : [];
          const step = job.__steps.find(x => String(x?.aciklama || x?.durumAciklama || '').toLowerCase().includes('yoklama süreci başlat')) || null;
          job.__step = step;
          job.__eligible = !!step;
          job.__error = '';
        } catch (err) {
          job.__eligible = false;
          job.__error = err?.message || String(err);
        }
        if (i === 0 || (i + 1) % 10 === 0 || i === list.length - 1) {
          this.log('ygiris', `İş Takip durum kontrolü: ${i + 1}/${list.length}`);
          this.renderYgItJobs();
        }
      }
      const uygun = list.filter(x => x.__eligible).length;
      const haric = list.filter(x => x.__excludeReason).length;
      this.renderYgItJobs();
      this.log('ygiris', `İş Takip durum kontrolü tamamlandı. uygun=${uygun}, hariç=${haric}, toplam=${list.length}`);
    }

    getYgItRowStatus(job) {
      if (job.__sent) return { text: 'Gönderildi', cls: 'yg-it-status-ok' };
      if (job.__eligible) {
        const st = job.__step || {};
        return { text: `Yoklama Süreci Başlat (${st.durumNo ?? '-'}/${st.tip ?? '-'})`, cls: 'yg-it-status-ok' };
      }
      if (job.__excludeReason) return { text: `Hariç: ${job.__excludeReason}`, cls: 'yg-it-status-exc' };
      if (job.__error) return { text: job.__error, cls: 'yg-it-status-bad' };
      return { text: 'Kontrol bekliyor', cls: 'yg-it-status-bad' };
    }

    renderYgItJobs() {
      const box = this.panel.querySelector('#yg_it_jobs_list');
      if (!box) return;
      const sourceRows = Array.isArray(this.ygItJobs) ? this.ygItJobs : [];
      const rows = this.filterYgItJobsByVkn(sourceRows);
      this.updateYgItVknInfo(sourceRows.length, rows.length);
      if (!sourceRows.length) {
        box.innerHTML = '<div class="tiny">İş Takip listesi boş.</div>';
        return;
      }
      if (!rows.length) {
        box.innerHTML = '<div class="tiny">Kayıt geldi fakat VKN aralık filtresi nedeniyle görünür kayıt yok. VKN Başlangıç/Bitiş alanlarını temizle.</div>';
        return;
      }
      const tableRows = rows.map((j, visibleIndex) => {
        const originalIndex = sourceRows.indexOf(j);
        const vkn = this.getYgItVkn(j) || getJobField(j, ['is_vergiNo','vergiNo','vkn']);
        const tckn = getJobField(j, ['is_tcKimlikNo','tcKimlikNo','tckn']);
        const unvan = getJobField(j, ['is_unvan','is_unvan_unvan','unvan']);
        const no = getJobField(j, ['is_isTakipNo','akis_isTakipNo','isTakipNo','akis_oid']);
        const pOid = findJobPreviewOid(j);
        const status = this.getYgItRowStatus(j);
        const previewLabel = this.getYgItKaynakText(j).toLowerCase().includes('mersis no') ? 'Mersis' : (pOid ? 'Önizle Aç' : 'Veri Yok');
        const previewBtn = pOid && previewLabel !== 'Mersis'
          ? `<button class="inline-btn" data-yg-job-preview="${originalIndex}">Önizle Aç</button>`
          : `<span class="tiny">${htmlEscape(previewLabel)}</span>`;
        return `<tr>
          <td class="yg-col-no">${visibleIndex + 1}</td>
          <td class="yg-col-act"><div class="yg-act-wrap"><button class="yg-row-action-btn" data-yg-job-actions="${originalIndex}" title="Ana Modül akış seçenekleri">⋮</button><button class="inline-btn good" data-yg-job-pick="${originalIndex}">Seç / Doldur</button></div></td>
          <td class="yg-col-is"><strong>${htmlEscape(no || '-')}</strong><br><span class="tiny">${htmlEscape([vkn, tckn].filter(Boolean).join(' / ') || '-')}</span><br><span class="tiny">${htmlEscape(unvan || '-')}</span></td>
          <td class="yg-col-tur">${htmlEscape(this.getYgItIsTuruText(j))}</td>
          <td class="yg-col-preview">${previewBtn}</td>
          <td class="yg-col-ykdurum">${this.renderYgItYoklamaDurumCell(j)}</td>
          <td class="yg-col-ykkod">${this.renderYgItYoklamaKodCell(j)}</td>
        </tr>`;
      }).join('');
      box.innerHTML = `<table class="yg-it-table">
        <thead><tr>
          <th class="yg-col-no">#</th>
          <th class="yg-col-act">İşlem</th>
          <th class="yg-col-is">İşTakip</th>
          <th class="yg-col-tur">İşin Türü</th>
          <th class="yg-col-preview">Önizle</th>
          <th class="yg-col-ykdurum">Yoklama Durum</th>
          <th class="yg-col-ykkod">Yoklama Kodu</th>
        </tr></thead><tbody>${tableRows}</tbody></table>`;
      box.querySelectorAll('[data-yg-job-actions]').forEach(btn => btn.onclick = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const idx = Number(btn.getAttribute('data-yg-job-actions'));
        this.toggleYgItActionMenu(this.ygItJobs[idx], btn);
      });
      box.querySelectorAll('[data-yg-job-pick]').forEach(btn => btn.onclick = () => {
        const idx = Number(btn.getAttribute('data-yg-job-pick'));
        this.applyYgJobToForm(this.ygItJobs[idx]);
      });
      box.querySelectorAll('[data-yg-job-preview]').forEach(btn => btn.onclick = async () => {
        const idx = Number(btn.getAttribute('data-yg-job-preview'));
        const job = this.ygItJobs[idx];
        const pOid = findJobPreviewOid(job);
        if (!pOid) return;
        try {
          // Ana Modül'deki çalışan önizleme akışını kullan: aynı token çözme ve aynı modal.
          const mainBot = window.__istakipBotInstanceV427;
          if (mainBot && typeof mainBot.openPreview === 'function') {
            this.log('ygiris', `İş Takip önizleme Ana Modül akışıyla açılıyor: ${pOid}`);
            await mainBot.openPreview(job);
            return;
          }
        } catch (err) {
          this.log('ygiris', `Ana Modül önizleme akışı kullanılamadı, EYS akışına dönülüyor: ${err?.message || String(err)}`, true);
        }
        this.setYgField('yg_istakip_oid', pOid);
        await this.openYgIsTakipPreview();
      });
      box.querySelectorAll('[data-yg-ykodu]').forEach(a => a.onclick = async (ev) => {
        ev.preventDefault();
        const kod = a.getAttribute('data-yg-ykodu');
        if (kod) await this.openYgOldYoklama(kod);
      });
    }

    async applyYgJobToForm(job) {
      if (!job) return;
      const vkn = String(getJobField(job, ['is_vergiNo','vergiNo','vkn']) || '').trim();
      const tckn = String(getJobField(job, ['is_tcKimlikNo','tcKimlikNo','tckn']) || '').trim();
      const unvan = String(getJobField(job, ['is_unvan','is_unvan_unvan','unvan']) || '').trim();
      const no = String(getJobField(job, ['is_isTakipNo','akis_isTakipNo','isTakipNo','akis_oid']) || '').trim();
      const pOid = findJobPreviewOid(job);
      this.setYgField('yg_vkntckn', vkn || tckn);
      this.setYgField('yg_unvan', unvan);
      this.setYgField('yg_tckn', tckn);
      this.setYgField('yg_istakip_oid', pOid || no);
      this.setYgField('yg_selected_job_info', `${no || '-'} / ${vkn || tckn || '-'} / ${unvan || '-'}`);
      // İş takip unvanına göre mükellef grubu ilk tahmin; sicil sorgusu çalışınca kesinleşir.
      const jobMukGrup = this.inferMukellefGrubuFromUnvan(unvan);
      if (jobMukGrup) {
        const muk = this.panel.querySelector('#yg_muk_grup');
        if (muk) muk.value = jobMukGrup;
      }
      const ymd = ymdFromAny(getJobField(job, ['is_gelisTarihi','gelisTarihi','is_tarih','tarih','talepTarihi','basvuruTarihi','is_kaynakbilgisi']));
      if (ymd) this.setYgField('yg_ise_tarih', ymd);
      await this.lookupYoklamaGiris();
      this.log('ygiris', `İş Takip kaydı forma aktarıldı: ${no || vkn || tckn}`);
    }

    resolveYgKeysToken() {
      const clean = v => String(v || '').trim();
      const usable = v => {
        const t = clean(v);
        if (!t || t.includes('...')) return '';
        // Gerçek token genelde uzun olur; Ana Modül ekranında görünen kırpılmış değerleri kullanma.
        if (t.length < 25) return '';
        return t;
      };
      try {
        if (typeof window.__istakipBotResolveToken === 'function') {
          const fromBridge = ['gp', 'g', 'evdo', 'e', 'istakip']
            .map(m => usable(window.__istakipBotResolveToken(m)))
            .find(Boolean);
          if (fromBridge) return fromBridge;
        }
      } catch (_) {}
      try {
        const val = sel => document.querySelector(sel)?.value || document.querySelector(sel)?.textContent || '';
        const fromDom = ['#it_tok_gp', '#it_tok_g', '#it_base_tok', '#it_token']
          .map(sel => usable(val(sel)))
          .find(Boolean);
        if (fromDom) return fromDom;
      } catch (_) {}
      return usable(getToken()) || clean(getToken());
    }

    async fetchYgKeysPreviewInfo(keysEvrakOid) {
      // Ana Modül'deki çalışan önizleme mantığına yakın tutuldu.
      // Bazı evraklarda /flexpaper/pdf fileID değerinin sonuna .pdf eklenmezse 401 dönebiliyor.
      const token = this.resolveYgKeysToken();
      if (!token) throw new Error('KEYS/GP token bulunamadı.');
      const p = new URLSearchParams();
      p.append('cmd', 'evrakOrtakServis_evrakOnizle');
      p.append('callid', makeEysCallId());
      p.append('token', token);
      p.append('jp', JSON.stringify({ evrakOid: String(keysEvrakOid || '').trim(), konteynerOid: null, evrakVersiyonOid: null, yetkisiz: true, barkod: true }));
      const res = await fetch(`${location.origin}/keyss/external_dispatch`, { method: 'POST', body: p, credentials: 'include' });
      if (!res.ok) throw new Error(`Önizleme ağ hatası: ${res.status}`);
      const txt = await res.text();
      let json = null;
      try { json = JSON.parse(txt); } catch (_) { throw new Error('Önizleme cevabı JSON değil.'); }
      if (String(json?.error || '') === '1') throw new Error(previewResponse(json));
      const data = json?.data || json || {};
      const url = extractFirstUrlDeep(data);
      if (url) return { token, url: normalizeEysUrl(url), response: json };
      const uuid = deepPickValue(data, ['uuid','fileID','fileId']);
      const dosyaId = deepPickValue(data, ['dosyaId','dosyaID','fn','fileName']);
      if (!uuid) throw new Error('Önizleme için fileID bulunamadı.');
      const cleanedFileId = String(uuid || '').trim();
      const fileIdForUrl = cleanedFileId.toLowerCase().endsWith('.pdf') ? cleanedFileId : `${cleanedFileId}.pdf`;
      return { url: `${location.origin}/keyss/flexpaper/pdf/?token=${encodeURIComponent(token)}&fileID=${fileIdForUrl}#navpanes=0`, token, response: json, fileID: cleanedFileId, uuid: cleanedFileId, dosyaId };
    }






    updateYgYoklamaBilgileriUi() {
      const cfg = this.getYoklamaGirisConfig();
      const yturu = this.panel.querySelector('#yg_yturu');
      const label = this.panel.querySelector('#yg_yturu_label');
      const special = this.panel.querySelector('#yg_tur_special_fields');
      const notice = this.panel.querySelector('#yg_diger_yoklama_notice');
      const text = yturu?.selectedOptions?.[0]?.textContent || '';
      if (label) label.value = text;
      if (special) special.innerHTML = ygTurSpecialTemplate(cfg.yturu, text);
      if (notice) notice.style.display = 'none';
      const d = this.panel.querySelector('#yg_ise_tarih');
      if (d && !d.value) d.value = eysTodayYYYYMMDD();
      this.bindYgDynamicTemplateEvents();
      this.updateYgCalisanTotal();
    }

    syncYgIsyeriRadioToSelect() {
      const checked = this.panel.querySelector('input[name="yg_isyeri_radio"]:checked');
      const sel = this.panel.querySelector('#yg_isyeri_turu');
      if (checked && sel) sel.value = checked.value;
    }


    setYgFaaliyetSelect(options = [], selectedValue = '') {
      const sel = this.panel.querySelector('#yg_faaliyet_select');
      if (!sel) return;
      sel.innerHTML = '<option value="">---</option>';
      const list = Array.isArray(options) ? options : [];
      for (const o of list) {
        const opt = document.createElement('option');
        opt.value = String(o.value || o.sira || '').trim();
        opt.textContent = String(o.text || o.label || o.value || '').trim();
        sel.appendChild(opt);
      }
      const want = String(selectedValue || '').trim();
      if (want && Array.from(sel.options).some(x => x.value === want)) sel.value = want;
      else if (list.length === 1) sel.selectedIndex = 1;
      const chosen = sel.selectedOptions?.[0];
      if (chosen && chosen.value) {
        this.ygLookup = this.ygLookup || {};
        this.ygLookup.faaliyet = Object.assign({}, this.ygLookup.faaliyet || {}, { value: chosen.value, text: chosen.textContent, options: list });
      }
    }

    parseYgFaaliyetResponse(resp) {
      const d = parsePossiblyJsonData(resp);
      const root = d?.data || d || {};
      const options = Array.isArray(root.options) ? root.options : (Array.isArray(root) ? root : []);
      const value = String(root.sira || options[0]?.value || '').trim();
      const found = options.find(o => String(o.value) === value) || options[0] || {};
      return { value, text: found.text || root.text || value || '', options };
    }

    async loadYgVdsOfVkn() {
      const cfg = this.getYoklamaGirisConfig();
      const vkn = cfg.vkn || this.ygLookup?.sicil?.vergiNo || '';
      if (!vkn) return [];
      try {
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
        const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_VD_OF_VKN, { vkn, sessionData });
        const data = parsePossiblyJsonData(resp);
        const list = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
        this.ygVdOptions = list;

        const sel = this.panel.querySelector('#yg_faaliyet_vd_select');
        if (sel) {
          const keep = sel.value;
          sel.innerHTML = '<option value="">---</option>';
          for (const o of list) {
            const label = getVdOptionText(o);
            const code = getVdOptionCode(o, label);
            const opt = document.createElement('option');
            opt.value = code || label;
            opt.textContent = label || code;
            opt.dataset.vdkodu = code || '';
            try { opt.dataset.raw = JSON.stringify(o || {}); } catch (_) {}
            sel.appendChild(opt);
          }
          if (keep && Array.from(sel.options).some(o => o.value === keep)) sel.value = keep;
          else if (list.length === 1) sel.value = getVdOptionCode(list[0], getVdOptionText(list[0]));
        }
        this.setYgKnownVdOptions(list);
        const bilinenVd = this.panel.querySelector('#yg_bilinen_vd');
        if (bilinenVd && bilinenVd.value) await this.loadYgKnownAddressesForSelectedVd({ source: 'vd-list' });
        this.log('ygiris', `VD listesi yüklendi. Kayıt=${list.length}`);
        return list;
      } catch (err) {
        this.log('ygiris', `VD listesi alınamadı: ${err?.message || String(err)}`, true);
        return [];
      }
    }

    async loadYgFaaliyetForSelectedType() {
      const cfg = this.getYoklamaGirisConfig();
      const vkn = cfg.vkn || this.ygLookup?.sicil?.vergiNo || '';
      if (!vkn) return;
      const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
      try {
        let resp;
        if (cfg.faaliyetTuru === 'VD') {
          const vd = cfg.faaliyetVd || sessionData.birim;
          if (!vd) return this.log('ygiris', 'VD’ye bağlı faaliyet için VD seçiniz.', true);
          try {
            resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SUBE_FAALIYETLER || CFG.COMMANDS.YG_VD_FAALIYETLER, { vkn, vdKodu: vd, birimfaal: '0', sessionData });
          } catch (_) {
            resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_MERKEZ_FAALIYET, { vkn, vdkodu: vd, vdKodu: vd, sessionData });
          }
        } else {
          resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_MERKEZ_FAALIYET, { vkn, sessionData });
        }
        const faaliyet = this.parseYgFaaliyetResponse(resp);
        this.setYgFaaliyetSelect(faaliyet.options, faaliyet.value);
        this.ygLookup = this.ygLookup || {};
        this.ygLookup.faaliyet = Object.assign({}, faaliyet, { tur: cfg.faaliyetTuru, vdkodu: cfg.faaliyetVd });
        this.log('ygiris', `Faaliyet konusu yüklendi. Tür=${cfg.faaliyetTuru}, kayıt=${faaliyet.options.length}`);
      } catch (err) {
        this.log('ygiris', `Faaliyet konusu alınamadı: ${err?.message || String(err)}`, true);
      }
    }


    renderYgKnownAddressesList(list = [], note = '') {
      const box = this.panel?.querySelector('#yg_bilinen_adres_list');
      if (!box) return;
      if (!list.length) {
        box.innerHTML = `<div class="tiny">Bilinen adres bulunamadı.${note ? '<br>' + htmlEscape(note) : ''}</div>`;
        return;
      }
      box.innerHTML = list.map((a, i) => {
        const raw = a.raw || a;
        const adr = a.adresString || pickValue(raw, ['ADRESSTRING','adresString','adres','text','ADRES']) || '';
        const no = a.adresNo || pickValue(raw, ['ADRESNO','adresNo','ano']) || '';
        const vd = a.vdkodu || pickValue(raw, ['vdkodu','vdKodu','VDKODU']) || '';
        const vdText = a.vdText || '';
        return `<div class="list-row" data-yg-known-addr="${i}"><div><strong>${i + 1}. ${htmlEscape(no || 'Adres no yok')}</strong><div class="tiny">${htmlEscape(adr || '-')}</div>${vd ? `<div class="tiny">VD: ${htmlEscape(vdText || vd)}</div>` : ''}</div><button class="inline-btn good" data-yg-known-pick="${i}">Yoklama Adresi Yap</button></div>`;
      }).join('');
      box.querySelectorAll('[data-yg-known-pick]').forEach(btn => btn.onclick = (ev) => { ev.stopPropagation(); void this.selectYgKnownAddress(Number(btn.getAttribute('data-yg-known-pick'))); });
      box.querySelectorAll('[data-yg-known-addr]').forEach(row => row.onclick = () => { void this.selectYgKnownAddress(Number(row.getAttribute('data-yg-known-addr'))); });
    }

    async loadYgMemurHarVdFaaliyetVeAdresAkisi(vkn, sessionData) {
      if (!vkn || !sessionData) return;
      const vdOptions = Array.isArray(this.ygVdOptions) ? this.ygVdOptions : [];
      const vdItems = vdOptions.map(o => {
        const text = getVdOptionText(o);
        const code = getVdOptionCode(o, text);
        return { raw: o, text, code };
      }).filter(x => x.code);
      if (!vdItems.length) return;

      const faaliyetMap = {};
      let selectedFaaliyet = null;
      const selectedVd = String(this.panel?.querySelector('#yg_faaliyet_vd_select')?.value || '').trim();
      for (const item of vdItems) {
        try {
          // Gerçek memur HAR: srvcRemoteCall_getSubeFaaliyetKonulari {vkn, vdKodu, birimfaal:"0", sessionData}
          const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SUBE_FAALIYETLER, { vkn, vdKodu: item.code, birimfaal: '0', sessionData });
          const f = this.parseYgFaaliyetResponse(resp);
          faaliyetMap[item.code] = Object.assign({}, f, { vdkodu: item.code, vdText: item.text, rawResponse: resp });
          if ((f.options || []).length) {
            if (!selectedFaaliyet || item.code === selectedVd) selectedFaaliyet = faaliyetMap[item.code];
          }
          this.log('ygiris', `Memur HAR şube faaliyet: VD=${item.code}, adet=${(f.options || []).length}`);
        } catch (err) {
          this.log('ygiris', `Memur HAR şube faaliyet alınamadı: VD=${item.code}, ${err?.message || String(err)}`, true);
        }
      }
      this.ygMemurVdFaaliyetMap = faaliyetMap;
      if (selectedFaaliyet && (selectedFaaliyet.options || []).length) {
        const tur = this.panel?.querySelector('#yg_faaliyet_vd');
        if (tur) tur.checked = true;
        const vdSel = this.panel?.querySelector('#yg_faaliyet_vd_select');
        if (vdSel && selectedFaaliyet.vdkodu && Array.from(vdSel.options).some(o => o.value === selectedFaaliyet.vdkodu)) vdSel.value = selectedFaaliyet.vdkodu;
        this.setYgFaaliyetSelect(selectedFaaliyet.options, selectedFaaliyet.value);
        this.ygLookup = Object.assign({}, this.ygLookup || {}, { faaliyet: Object.assign({}, selectedFaaliyet, { tur: 'VD' }) });
      } else {
        // HAR'da şube faaliyetlerden sonra merkez faaliyet tekrar deneniyor.
        try {
          const mResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_MERKEZ_FAALIYET, { vkn, sessionData });
          const mf = this.parseYgFaaliyetResponse(mResp);
          if ((mf.options || []).length) {
            this.setYgFaaliyetSelect(mf.options, mf.value);
            this.ygLookup = Object.assign({}, this.ygLookup || {}, { faaliyet: Object.assign({}, mf, { tur: 'MERKEZ' }) });
          }
          this.log('ygiris', `Memur HAR merkez faaliyet tekrar kontrolü: adet=${(mf.options || []).length}`);
        } catch (err) {
          this.log('ygiris', `Memur HAR merkez faaliyet tekrar kontrolü alınamadı: ${err?.message || String(err)}`, true);
        }
      }

      const allAdres = [];
      for (const item of vdItems) {
        try {
          // Gerçek memur HAR: srvcRemoteCall_getVDAdresleri {vkn, vdkodu, sessionData}; tüm VD'ler tek tek denenir.
          const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_VD_ADRESLER, { vkn, vdkodu: item.code, sessionData });
          const rows = normalizeVdAdresRows(resp).map(r => Object.assign({}, r, { vdkodu: item.code, vdText: item.text }));
          allAdres.push(...rows);
          this.log('ygiris', `Memur HAR bilinen adres: VD=${item.code}, adet=${rows.length}`);
        } catch (err) {
          this.log('ygiris', `Memur HAR bilinen adres alınamadı: VD=${item.code}, ${err?.message || String(err)}`, true);
        }
      }
      const seen = new Set();
      this.ygKnownAddresses = allAdres.filter(r => {
        const key = `${r.adresNo || ''}|${r.adresString || ''}`;
        if ((!r.adresNo && !r.adresString) || seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      this.renderYgKnownAddressesList(this.ygKnownAddresses, 'Memur HAR tüm VD adres taraması');
      if (this.ygKnownAddresses.length === 1 && !this.getYoklamaGirisConfig().adresNo) {
        try { await this.selectYgKnownAddress(0, true); } catch (_) {}
      }
    }

    updateYgFaaliyetTuruUi() {
      const cfg = this.getYoklamaGirisConfig();
      const vdSel = this.panel.querySelector('#yg_faaliyet_vd_select');
      if (vdSel) vdSel.disabled = cfg.faaliyetTuru !== 'VD';
      if (cfg.faaliyetTuru === 'VD') this.loadYgVdsOfVkn().then(() => this.loadYgFaaliyetForSelectedType());
      else this.loadYgFaaliyetForSelectedType();
    }


    inferMukellefGrubuFromUnvan(unvan = '') {
      const u = String(unvan || '').toUpperCase();
      if (['LİMİTED', 'LIMITED', 'ANONİM', 'ANONIM', 'A.Ş', 'AŞ', 'LTD', 'ŞTİ', 'STI', 'KOOPERATİF', 'KOOPERATIF', 'KOLLEKTİF', 'KOLLEKTIF', 'KOMANDİT', 'KOMANDIT'].some(k => u.includes(k))) return '2';
      return '';
    }

    inferMukellefGrubuFromSicil(sicil = {}) {
      const turNo = Number(sicil.sirketTuru || 0);
      const turAd = String(sicil.sirketTuruAd || '').toUpperCase();

      // EYS ekranında gerçek kişi = Gelir Vergisi; şirket türleri = Kurumlar Vergisi.
      if (turNo === 1 || turAd.includes('GERÇEK') || turAd.includes('GERCEK')) return '1';
      if (turNo >= 2) return '2';

      const kurumKelimeleri = ['LİMİTED', 'LIMITED', 'ANONİM', 'ANONIM', 'KOOPERATİF', 'KOOPERATIF', 'KOLLEKTİF', 'KOLLEKTIF', 'KOMANDİT', 'KOMANDIT', 'ŞİRKET', 'SIRKET'];
      if (kurumKelimeleri.some(k => turAd.includes(k))) return '2';

      return '1';
    }

    applySicilToYoklamaGirisFields(sicil = {}) {
      if (!sicil) return;

      const vkn = String(sicil.vergiNo || '').trim();
      const tckn = String(sicil.mukellefNo || '').trim();
      const unvan = String(sicil.kimlikUnvan || '').trim();
      const sirketTuru = String(sicil.sirketTuru || '').trim();

      if (unvan) this.setYgField('yg_unvan', unvan);
      if (tckn) this.setYgField('yg_tckn', tckn);
      if (vkn && !this.panel.querySelector('#yg_vkntckn')?.value) this.setYgField('yg_vkntckn', vkn);

      if (sirketTuru) {
        const isletme = this.panel.querySelector('#yg_isletme_turu');
        if (isletme) {
          if (!Array.from(isletme.options).some(o => o.value === sirketTuru)) {
            const opt = document.createElement('option');
            opt.value = sirketTuru;
            opt.textContent = sicil.sirketTuruAd || `Şirket Türü ${sirketTuru}`;
            isletme.appendChild(opt);
          }
          isletme.value = sirketTuru;
        }
      }

      const mukGrup = this.inferMukellefGrubuFromSicil(sicil);
      const muk = this.panel.querySelector('#yg_muk_grup');
      if (muk && mukGrup) {
        muk.value = mukGrup;
        this.log('ygiris', `Mükellef grubu otomatik seçildi: ${muk.selectedOptions?.[0]?.textContent || muk.value}`);
      }
    }


    getYoklamaGirisConfig() {
      const q = id => this.panel.querySelector('#' + id);
      const vkntckn = this.onlyDigits(q('yg_vkntckn')?.value || '').slice(0, 11);
      const adresMode = this.getYgAddressMode ? this.getYgAddressMode() : 'ililce';
      const adresIds = this.getYgAddressIds ? this.getYgAddressIds(adresMode) : { il:'yg_il', ilce:'yg_ilce', mahalle:'yg_mahalle', csbm:'yg_csbm', diskapi:'yg_diskapi', ickapi:'yg_ickapi', adresNo:'yg_adres_no', adresText:'yg_adres_text', aciklama:'yg_aciklama', yetersiz:'yg_adres_yetersiz_check' };
      const addr = id => q(id);
      return {
        role: q('yg_role')?.value || '10',
        servis: q('yg_servis')?.value || '60',
        yturu: q('yg_yturu')?.value || '10',
        yturuText: q('yg_yturu')?.selectedOptions?.[0]?.textContent || '',
        vkntckn,
        ihbarDayali: !!q('yg_ihbar_dayali')?.checked,
        ihbarKaynak: q('yg_ihbar_kaynak')?.value || 'BIMER',
        ihbarKaynakText: q('yg_ihbar_kaynak')?.selectedOptions?.[0]?.textContent || '',
        ihbarTarihSayi: (q('yg_ihbar_tarih_sayi')?.value || '').trim(),
        vkn: vkntckn.length === 10 ? vkntckn : '',
        tckn: (q('yg_tckn')?.value || '').replace(/\D+/g, '').slice(0, 11),
        unvan: (q('yg_unvan')?.value || '').trim(),
        sms: q('yg_sms')?.value || '1',
        tel: this.onlyDigits(q('yg_tel')?.value || '').slice(0, 10),
        eposta: (q('yg_eposta')?.value || '').trim(),
        isletmeTuru: q('yg_isletme_turu')?.value || '1',
        mukGrup: q('yg_muk_grup')?.value || '1',
        faaliyetTuru: q('yg_faaliyet_vd')?.checked ? 'VD' : 'MERKEZ',
        faaliyetVd: q('yg_faaliyet_vd_select')?.value || '',
        faaliyetVdText: q('yg_faaliyet_vd_select')?.selectedOptions?.[0]?.textContent || '',
        faaliyetValue: q('yg_faaliyet_select')?.value || '',
        faaliyetText: q('yg_faaliyet_select')?.selectedOptions?.[0]?.textContent || '',
        isyeriRadio: this.panel.querySelector('input[name="yg_isyeri_radio"]:checked')?.value || '',
        isyeriTuru: this.panel.querySelector('input[name="yg_isyeri_radio"]:checked')?.value || q('yg_isyeri_turu')?.value || '0',
        iseTarih: this.onlyDigits(q('yg_ise_tarih')?.value || '').slice(0, 8),
        asgari: Number(this.onlyDigits(q('yg_asgari')?.value || '0') || '0'),
        diger: Number(this.onlyDigits(q('yg_diger')?.value || '0') || '0'),
        mulkiyet: q('yg_mulkiyet')?.value || '2',
        kiraSekli: q('yg_kira_sekli')?.value || '2',
        kiraDonemi: q('yg_kira_donemi')?.value || '2',
        kiraTutari: moneyToNumber(q('yg_kira_tutari')?.value || '0'),
        para: q('yg_para')?.value || '1',
        mulkVkntckn: this.onlyDigits(q('yg_mulk_vkntckn')?.value || '').slice(0, 11),
        adresMode,
        bilinenVd: q('yg_bilinen_vd')?.value || '',
        bilinenAdresNo: q('yg_bilinen_adres_secili')?.value || '',
        adresNo: this.onlyDigits(addr(adresIds.adresNo)?.value || '').slice(0, 20),
        adresYetersiz: (addr(adresIds.yetersiz)?.checked ? '1' : (q('yg_adres_yetersiz')?.value || '0')),
        aciklama: (addr(adresIds.aciklama)?.value || q('yg_aciklama')?.value || '').trim(),
        yoklamaAciklama: (q('yg_yoklama_aciklama')?.value || '').trim(),
        disGorev: q('yg_dis_gorev')?.value || '0',
        disGorevVd: q('yg_dis_gorev_vd')?.value || '',
        yetkiTespit: q('yg_yetki_tespit')?.value || '',
        il: addr(adresIds.il)?.value || '',
        ilText: addr(adresIds.il)?.selectedOptions?.[0]?.textContent || '',
        ilce: addr(adresIds.ilce)?.value || '',
        ilceText: addr(adresIds.ilce)?.selectedOptions?.[0]?.textContent || '',
        mahalle: addr(adresIds.mahalle)?.value || '',
        mahalleText: addr(adresIds.mahalle)?.selectedOptions?.[0]?.textContent || '',
        csbm: addr(adresIds.csbm)?.value || '',
        csbmText: addr(adresIds.csbm)?.selectedOptions?.[0]?.textContent || '',
        diskapi: addr(adresIds.diskapi)?.value || '',
        diskapiText: addr(adresIds.diskapi)?.selectedOptions?.[0]?.textContent || '',
        ickapi: addr(adresIds.ickapi)?.value || '',
        ickapiText: addr(adresIds.ickapi)?.selectedOptions?.[0]?.textContent || '',
        adresText: addr(adresIds.adresText)?.value || q('yg_adres_text')?.value || '',
        istakipOid: (q('yg_istakip_oid')?.value || '').trim(),
        temelKaynak: (q('yg_temel_kaynak')?.value || 'VERGİ DAİRESİ').trim(),
        temelKodu: (q('yg_temel_kodu')?.value || '').trim(),
        temelDurumu: (q('yg_temel_durumu')?.value || '').trim()
      };
    }


    collectYgSpecialFields() {
      const box = this.panel.querySelector('#yg_tur_special_fields');
      const out = {};
      if (!box) return out;
      box.querySelectorAll('input,select,textarea').forEach(el => {
        if (!el.id) return;
        if (el.type === 'checkbox') out[el.id] = !!el.checked;
        else out[el.id] = el.value;
      });
      return out;
    }

    setYgField(id, value) {
      const el = this.panel.querySelector('#' + id);
      if (el && value !== undefined && value !== null) el.value = String(value);
    }

    renderYgSummary() {
      const box = this.panel.querySelector('#yg_summary');
      if (!box) return;
      const sicil = this.ygLookup?.sicil || {};
      const faaliyet = this.ygLookup?.faaliyet || {};
      const adres = this.ygLookup?.adres || this.getYgAdresFromFields?.() || {};
      const ykodu = this.ygLastYkodu || '';
      box.innerHTML = `
        <div class="list-row yg-summary-row">
          <div>
            <div><strong>Ön Bilgi</strong></div>
            <div class="tiny">VKN: ${sicil.vergiNo || '-'} | TCKN: ${sicil.mukellefNo || sicil.tckn || '-'} | Unvan: ${sicil.kimlikUnvan || '-'}</div>
            <div class="tiny">Faaliyet: ${faaliyet.text || '-'}</div><div class="tiny">Yoklama Türü: ${this.getYoklamaGirisConfig().yturuText || this.getYoklamaGirisConfig().yturu || '-'}</div>
            <div class="tiny">İhbar: ${this.getYoklamaGirisConfig().ihbarDayali ? (this.getYoklamaGirisConfig().ihbarKaynakText + ' / ' + this.getYoklamaGirisConfig().ihbarTarihSayi) : 'Yok'}</div>
            <div class="tiny">Adres: ${adres.adresAciklama || adres.atext || '-'}</div>
            <div class="tiny">Son yKodu: ${ykodu || '-'}</div>
          </div>
        </div>`;
    }

    async lookupYoklamaGiris() {
      const cfg = this.getYoklamaGirisConfig();
      if (!cfg.vkntckn) return this.log('ygiris', 'VKN/TCKN giriniz.', true);
      if (cfg.vkntckn.length !== 10 && cfg.vkntckn.length !== 11) return this.log('ygiris', 'VKN 10 hane, TCKN 11 hane olmalı.', true);
      try {
        const sessionData = await this.bootRole(cfg.role, 'ygiris');
        this.fillYgTemelBilgileri(sessionData);
        await this.preloadYgMemurGirisFlow(sessionData);
        this.log('ygiris', `Sorgu başlıyor. rol=${cfg.role} servis=${cfg.servis} vkntckn=${cfg.vkntckn}`);
        let sicil = {};
        if (cfg.vkntckn.length === 10) {
          const sicilResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SICIL_BY_VKN, { vkn: cfg.vkntckn, sessionData });
          sicil = normalizeSicilData(sicilResp, { vkn: cfg.vkntckn });
        } else {
          const tResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_UNVAN_BY_TCKN, { tckn: cfg.vkntckn, sessionData });
          sicil = normalizeSicilData(tResp, { tckn: cfg.vkntckn });
          if (sicil.adresNo && !cfg.adresNo) this.setYgField('yg_adres_no', sicil.adresNo);
          if (sicil.adresStr && !this.panel.querySelector('#yg_adres_text')?.value) this.setYgField('yg_adres_text', sicil.adresStr);
        }

        const vkn = String(sicil.vergiNo || cfg.vkn || '').trim();
        if (!vkn) this.log('ygiris', 'Sicil sorgusunda VKN bulunamadı; elle VKN gerekebilir.', true);

        try {
          const terk = await post(CFG.EYS_URL, CFG.COMMANDS.YG_TERK_BILGI, { vkntckn: vkn || cfg.vkntckn, kodu: '', val: '', sessionData });
          this.log('ygiris', `Terk bilgisi: ${previewResponse(terk)}`);
        } catch (err) {
          this.log('ygiris', 'Terk bilgisi alınamadı: ' + (err?.message || String(err)), true);
        }

        let faaliyet = {};
        if (vkn) {
          const fResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_MERKEZ_FAALIYET, { vkn, sessionData });
          faaliyet = this.parseYgFaaliyetResponse(fResp);
          this.setYgFaaliyetSelect(faaliyet.options, faaliyet.value);
          this.ygLookup = Object.assign({}, this.ygLookup || {}, { sicil, faaliyet, sessionData });
          await this.loadYgVdsOfVkn();
          // Gerçek memur HAR: VD listesi sonrası şube faaliyetleri ve bilinen adresleri tüm VD'ler için tarar.
          try { await this.loadYgMemurHarVdFaaliyetVeAdresAkisi(vkn, sessionData); } catch (e) { this.log('ygiris', `Memur HAR VD faaliyet/adres akışı tamamlanamadı: ${e?.message || e}`, true); }
          // Gerçek memur ekranı VD listesi sonrası eski yoklamaları da aynı akışta çağırıyor.
          try { await this.fetchYgOldYoklamalar({ source: 'lookup' }); } catch (_) {}
        }

        let adres = {};
        if (cfg.adresNo) {
          const aResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_ADRES_AS_STRING, { adresNo: cfg.adresNo, sessionData });
          adres = parsePossiblyJsonData(aResp) || {};
          try {
            const tResp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_ADRES_TEXT, { adresNo: cfg.adresNo, sessionData });
            const atext = parsePossiblyJsonData(tResp);
            if (typeof atext === 'string') adres.atext = atext;
          } catch (_) {}
          try {
            await post(CFG.EYS_URL, CFG.COMMANDS.YG_COORDS, { adresno: cfg.adresNo, sessionData });
          } catch (_) {}
        }

        const preservedLookup = this.ygLookup || {};
        this.ygLookup = {
          sicil,
          faaliyet: preservedLookup.faaliyet || faaliyet,
          adres: Object.assign({}, preservedLookup.adres || {}, adres || {}),
          sessionData
        };
        if ((this.ygKnownAddresses || []).length === 1 && !cfg.adresNo && !this.ygLookup.adres?.adresNo) {
          try { await this.selectYgKnownAddress(0, true); } catch (_) {}
        }
        this.applySicilToYoklamaGirisFields(sicil);
        if (!this.panel.querySelector('#yg_aciklama')?.value && cfg.tel) this.setYgField('yg_aciklama', cfg.tel);
        if (cfg.adresNo || sicil.adresNo) await this.lookupYgAdresNo();
        this.log('ygiris', `Sorgu tamamlandı. VKN=${vkn || '-'} Unvan=${sicil.kimlikUnvan || '-'}`);
        this.renderYgSummary();
      } catch (err) {
        this.log('ygiris', err?.message || String(err), true);
      }
    }


    async openYgIsTakipPreview() {
      const cfg = this.getYoklamaGirisConfig();
      const oid = cfg.istakipOid;
      if (!oid) return this.log('ygiris', 'İş Takip OID / No giriniz veya İş Takip listesinden kayıt seçiniz.', true);
      try {
        this.log('ygiris', `İş Takip önizle açılıyor: ${oid}`);
        const info = await this.fetchYgKeysPreviewInfo(oid);
        openYgPreviewUrl(info.url, 'İş Takip Önizleme');
        this.log('ygiris', 'İş Takip önizleme aynı ekranda açıldı.');
      } catch (err) {
        this.log('ygiris', `İş Takip önizleme hata: ${err?.message || String(err)}`, true);
      }
    }

    async fetchYgOldYoklamalar(opts = {}) {
      const cfg = this.getYoklamaGirisConfig();
      const no = cfg.vkntckn || cfg.vkn || cfg.tckn;
      if (!no) return this.log('ygiris', 'Önce VKN/TCKN giriniz.', true);
      try {
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
        const vkn = cfg.vkn || this.ygLookup?.sicil?.vergiNo || '';
        const tckn = cfg.tckn || this.ygLookup?.sicil?.mukellefNo || (no.length === 11 ? no : '');
        const firstVd = cfg.bilinenVd || getVdOptionCode((this.ygVdOptions || [])[0], getVdOptionText((this.ygVdOptions || [])[0])) || sessionData.birim || '';
        const payloads = [
          { vdkodu: firstVd, vkn, tckn, sessionData },
          { vkn, tckn, vkntckn: no, sessionData },
          { vkntckn: no, sessionData },
          { data: { vkn, tckn, vkntckn: no, vdkodu: firstVd }, sessionData }
        ];
        let records = [];
        let lastResp = null;
        for (const payload of payloads) {
          try {
            const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_ESKI_LISTE, payload);
            lastResp = resp;
            const data = parsePossiblyJsonData(resp);
            if (Array.isArray(data)) records = data;
            else if (Array.isArray(data?.data)) records = data.data;
            else if (Array.isArray(data?.data?.data)) records = data.data.data;
            else if (Array.isArray(data?.data?.list)) records = data.data.list;
            else if (Array.isArray(data?.data?.yoklamalar)) records = data.data.yoklamalar;
            else if (Array.isArray(data?.yoklamalar)) records = data.yoklamalar;
            if (records.length) break;
          } catch (_) {}
        }
        this.renderYgOldYoklamalar(records, lastResp);
        this.log('ygiris', `Önceki yoklama sorgusu tamamlandı. Kayıt=${records.length}`);
      } catch (err) {
        this.log('ygiris', err?.message || String(err), true);
      }
    }

    renderYgOldYoklamalar(records, rawResp = null) {
      const box = this.panel.querySelector('#yg_old_list');
      if (!box) return;
      if (!records || !records.length) {
        box.innerHTML = `<div class="list-row"><div><strong>Önceki yoklama bulunamadı</strong><div class="tiny">${rawResp ? previewResponse(rawResp) : ''}</div></div></div>`;
        return;
      }
      box.innerHTML = records.map((r, idx) => {
        const x = formatYoklamaRecordLine(r);
        const esc = (v) => String(v || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        const rawHint = !x.y ? `<div class="tiny">Kod alanı cevapta yok. Ham: ${esc(previewResponse(r)).slice(0, 220)}</div>` : '';
        const openBtn = x.y
          ? `<button class="inline-btn" data-yg-open-yoklama="${esc(x.y)}">Yoklamayı Aç</button>`
          : `<button class="inline-btn" disabled title="Cevapta yoklama kodu yok">Kod Yok</button>`;
        return `
          <div class="list-row">
            <div>
              <div><strong>${idx + 1}. ${esc(x.y || 'Yoklama kodu yok')}</strong></div>
              <div class="tiny">Durum: ${esc(x.durum || '-')} | Tarih: ${esc(x.tarih || '-')} | Kişi: ${esc(x.ad || '-')}</div>
              ${rawHint}
            </div>
            ${openBtn}
          </div>`;
      }).join('');
      box.querySelectorAll('[data-yg-open-yoklama]').forEach(btn => {
        btn.addEventListener('click', () => this.openYgOldYoklama(btn.getAttribute('data-yg-open-yoklama')));
      });
    }

    async openYgOldYoklama(ykodu) {
      if (!ykodu) return this.log('ygiris', 'Yoklama kodu yok.', true);
      try {
        const cfg = this.getYoklamaGirisConfig();
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
        const payloads = [
          { yKodu: ykodu, sessionData },
          { ykodu, sessionData },
          { kodu: ykodu, sessionData }
        ];
        let lastErr = '';
        for (const payload of payloads) {
          try {
            const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_YOKLAMA_PDF, payload);
            const url = normalizeEysUrl(extractFirstUrlDeep(resp));
            if (url) {
              openYgPreviewUrl(url, 'Önceki Yoklama');
              this.log('ygiris', `Önceki yoklama açıldı: ${ykodu}`);
              return;
            }
            lastErr = 'Yoklama linki bulunamadı: ' + previewResponse(resp);
          } catch (err) {
            lastErr = err?.message || String(err);
          }
        }
        // Bazı EYS ortamlarında direkt URL üretilebilir.
        const direct = `${location.protocol}//eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?yKodu=${encodeURIComponent(ykodu)}`;
        openYgPreviewUrl(direct, 'Önceki Yoklama');
        this.log('ygiris', `Direkt getSonuc ile açıldı: ${ykodu}`);
      } catch (err) {
        this.log('ygiris', err?.message || String(err), true);
      }
    }



    setYgKnownVdOptions(list = []) {
      this.ygVdOptions = Array.isArray(list) ? list : [];
      const ids = ['yg_bilinen_vd', 'yg_dis_gorev_vd', 'yg_kiraci_vd', 'yg_yonetici_vd'];
      for (const id of ids) {
        const sel = this.panel.querySelector('#' + id);
        if (!sel) continue;
        const keep = sel.value;
        sel.innerHTML = '<option value="">---</option>';
        for (const o of this.ygVdOptions) {
          const t = getVdOptionText(o);
          const v = getVdOptionCode(o, t);
          if (!v && !t) continue;
          const opt = document.createElement('option');
          opt.value = v || t;
          opt.textContent = t || v;
          opt.dataset.vdkodu = v || '';
          try { opt.dataset.raw = JSON.stringify(o || {}); } catch (_) {}
          sel.appendChild(opt);
        }
        if (keep && Array.from(sel.options).some(o => o.value === keep)) sel.value = keep;
        else if (this.ygVdOptions.length === 1) {
          const o = this.ygVdOptions[0];
          sel.value = getVdOptionCode(o, getVdOptionText(o));
        }
      }
    }

    getYgAddressMode() {
      const btn = this.panel.querySelector('.addr-tab.active');
      return btn?.dataset?.addrMode || 'ililce';
    }

    getYgAddressIds(mode = 'ililce') {
      if (mode === 'belediye') return {
        il: 'yg_bel_il', ilce: 'yg_bel_ilce', bucak: 'yg_bel_bucak', belde: 'yg_bel_belde', mahalle: 'yg_bel_mahalle', csbm: 'yg_bel_csbm', diskapi: 'yg_bel_diskapi', ickapi: 'yg_bel_ickapi', adresNo: 'yg_adres_no_bel', adresText: 'yg_adres_text_bel', aciklama: 'yg_aciklama_bel', yetersiz: 'yg_adres_yetersiz_bel'
      };
      if (mode === 'koy') return {
        il: 'yg_koy_il', ilce: 'yg_koy_ilce', bucak: 'yg_koy_bucak', koy: 'yg_koy_koy', mevki: 'yg_koy_mevki', csbm: 'yg_koy_csbm', diskapi: 'yg_koy_diskapi', ickapi: 'yg_koy_ickapi', adresNo: 'yg_adres_no_koy', adresText: 'yg_adres_text_koy', aciklama: 'yg_aciklama_koy', yetersiz: 'yg_adres_yetersiz_koy'
      };
      return { il:'yg_il', ilce:'yg_ilce', mahalle:'yg_mahalle', csbm:'yg_csbm', diskapi:'yg_diskapi', ickapi:'yg_ickapi', adresNo:'yg_adres_no', adresText:'yg_adres_text', aciklama:'yg_aciklama', yetersiz:'yg_adres_yetersiz_check' };
    }

    bindYgAddressModeEvents() {
      this.panel.querySelectorAll('.addr-tab').forEach(btn => {
        btn.addEventListener('click', async () => {
          const mode = btn.dataset.addrMode || 'ililce';
          this.panel.querySelectorAll('.addr-tab').forEach(b => b.classList.toggle('active', b === btn));
          this.panel.querySelectorAll('.addr-mode').forEach(p => p.classList.toggle('active', p.dataset.addrPanel === mode));
          this.setYgField('yg_adres_mode_label', mode === 'belediye' ? 'Belediye Adresi' : (mode === 'koy' ? 'Köy Adresi' : 'İl-İlçe Merkezi'));
          await this.loadYgModeIlList(mode);
          this.renderYgSummary();
        });
      });
      const bindChain = (ids) => {
        const il = this.panel.querySelector('#' + ids.il);
        const ilce = this.panel.querySelector('#' + ids.ilce);
        const mahalle = ids.mahalle ? this.panel.querySelector('#' + ids.mahalle) : null;
        const bucak = ids.bucak ? this.panel.querySelector('#' + ids.bucak) : null;
        const belde = ids.belde ? this.panel.querySelector('#' + ids.belde) : null;
        const koy = ids.koy ? this.panel.querySelector('#' + ids.koy) : null;
        const mevki = ids.mevki ? this.panel.querySelector('#' + ids.mevki) : null;
        const csbm = this.panel.querySelector('#' + ids.csbm);
        const diskapi = this.panel.querySelector('#' + ids.diskapi);
        const ickapi = this.panel.querySelector('#' + ids.ickapi);
        const no = this.panel.querySelector('#' + ids.adresNo);
        if (il) il.addEventListener('change', () => this.loadYgCombo(ids.ilce, 2, il.value, ['kod'], ['ad']));
        if (ilce) ilce.addEventListener('change', () => {
          if (bucak) this.loadYgCombo(ids.bucak, 10, ilce.value, ['value','kod'], ['text','ad']);
          else if (mahalle) this.loadYgCombo(ids.mahalle, 3, ilce.value, ['value'], ['text']);
        });
        if (bucak) bucak.addEventListener('change', () => {
          if (belde) this.loadYgCombo(ids.belde, 8, bucak.value, ['value','kod'], ['text','ad']);
          if (koy) this.loadYgCombo(ids.koy, 8, bucak.value, ['value','kod'], ['text','ad']);
        });
        if (belde) belde.addEventListener('change', () => this.loadYgCombo(ids.mahalle, 3, belde.value, ['value'], ['text']));
        if (koy) koy.addEventListener('change', () => this.loadYgCombo(ids.mevki || ids.csbm, ids.mevki ? 9 : 4, koy.value, ['value','kod'], ['text','ad']));
        if (mevki) mevki.addEventListener('change', () => this.loadYgCombo(ids.csbm, 4, mevki.value, ['value'], ['text']));
        if (mahalle) mahalle.addEventListener('change', () => this.loadYgCombo(ids.csbm, 4, mahalle.value, ['value'], ['text']));
        if (csbm) csbm.addEventListener('change', () => this.loadYgCombo(ids.diskapi, 5, csbm.value, ['value'], ['disKapiNo','text']));
        if (diskapi) diskapi.addEventListener('change', () => this.loadYgCombo(ids.ickapi, 6, diskapi.value, ['adresNo'], ['icKapiNo','text']));
        if (ickapi) ickapi.addEventListener('change', () => { if (ickapi.value) { this.setYgField(ids.adresNo, ickapi.value); this.lookupYgAdresNo(); } });
        if (no) no.addEventListener('blur', () => { if (this.onlyDigits(no.value).length >= 7) this.lookupYgAdresNo(); });
      };
      bindChain(this.getYgAddressIds('ililce'));
      bindChain(this.getYgAddressIds('belediye'));
      bindChain(this.getYgAddressIds('koy'));
    }

    async loadYgModeIlList(mode = 'ililce') {
      const ids = this.getYgAddressIds(mode);
      const el = this.panel.querySelector('#' + ids.il);
      if (el && el.options.length <= 1) await this.loadYgCombo(ids.il, 1, '', ['kod'], ['ad']);
    }

    async loadYgKnownAddressesForSelectedVd(opts = {}) {
      const cfg = this.getYoklamaGirisConfig();
      const vkn = String(cfg.vkn || this.ygLookup?.sicil?.vergiNo || cfg.vkntckn || '').replace(/\D+/g, '').slice(0, 11);
      const selEl = this.panel.querySelector('#yg_bilinen_vd');
      const optEl = selEl?.selectedOptions?.[0];
      let optRaw = null;
      try { optRaw = optEl?.dataset?.raw ? JSON.parse(optEl.dataset.raw) : null; } catch (_) {}
      const vdRaw = cfg.bilinenVd || selEl?.value || '';
      const optText = optEl?.textContent || vdRaw || '';
      const box = this.panel.querySelector('#yg_bilinen_adres_list');

      if (box) box.innerHTML = '<div class="tiny">Bilinen adres sorgulanıyor...</div>';
      if (!vkn) {
        if (box) box.innerHTML = '<div class="tiny">Önce VKN/TCKN sorgusu yapılmalı.</div>';
        return this.log('ygiris', 'Bilinen adres için önce VKN/TCKN sorgusu gerekir.', true);
      }

      let lastResp = null;
      let lastPayloadName = '';
      let callerNote = 'Kaynaklar ekranı sadece gibintranet/js/cs/side-user-lib-g.js gösterdiği için ilk yöntem: mevcut sayfanın yerel CSCaller.call akışı; module/url zorlanmaz.';
      let list = [];
      let vdCodes = [];
      let tried = [];
      let directTried = [];

      try {
        const cap = window.__istakipEysCaptured || {};
        const capturedReq = cap.lastByCmd?.[CFG.COMMANDS.YG_VD_ADRESLER] || cap.lastVdAdresleri || null;
        const capturedPayload = (capturedReq?.payload && typeof capturedReq.payload === 'object') ? capturedReq.payload : {};
        const capturedSession = capturedPayload.sessionData;
        const exactSession = buildSessionData('10');
        const cachedSession = this.ygLookup?.sessionData;
        const builtRoleSession = buildSessionData(cfg.role || '10');
        const sessions = [capturedSession, exactSession, cachedSession, builtRoleSession]
          .filter(Boolean)
          .filter((s, i, arr) => arr.findIndex(x => JSON.stringify(x) === JSON.stringify(s)) === i);

        vdCodes = buildKnownAddressVdCodes({ capturedPayload, optEl, optRaw, optText, vdRaw });
        if (!vdCodes.length) {
          if (box) box.innerHTML = '<div class="tiny">Vergi dairesi kodu bulunamadı.</div>';
          return this.log('ygiris', 'Bilinen adres için vergi dairesi kodu bulunamadı.', true);
        }

        // 1) Gerçek memur HAR akışı: /edenetis/dispatch + srvcRemoteCall_getVDAdresleri
        // Payload sadece vkn + vdkodu + sessionData. Önce bunu deneriz; çalışırsa eski CSCaller yedeklerine gitmeyiz.
        for (const sessionData of sessions) {
          for (const vd of vdCodes) {
            lastPayloadName = `REAL_MEMUR_FETCH:${vd}`;
            tried.push(vd);
            this.log('ygiris', `Bilinen adres gerçek memur akışı deneniyor: ${lastPayloadName}`);
            try {
              const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_VD_ADRESLER, { vkn, vdkodu: vd, sessionData });
              lastResp = resp;
              list = normalizeVdAdresRows(resp);
              callerNote = `Gerçek memur HAR akışı OK. VD=${vd}`;
              if (list.length) {
                if (selEl && vd && selEl.value !== vd && Array.from(selEl.options).some(o => o.value === vd)) selEl.value = vd;
                break;
              }
            } catch (err) {
              lastResp = { __error: err?.message || String(err) };
              this.log('ygiris', `Gerçek memur bilinen adres akışı hata: ${err?.message || String(err)}`, true);
            }
          }
          if (list.length) break;
        }

        // 2) Yedek: kaynaklar ekranında görünen yerel gibintranet/side-user-lib-g akışı.
        // Gerçek ekranda dispatch, keys.ggm.bim/gibintranet tarafında çalışıyor; module=e/url zorlamak yetki hatası verebiliyor.
        if (!list.length) {
          const csCandidates = [];
          const moduleOrder = ['__local__', 'g', 'e'];
        moduleOrder.forEach((mod, mi) => {
          sessions.forEach((sessionData, si) => {
            vdCodes.forEach((vd, vi) => {
              csCandidates.push({
                name: `CSCALLER:${mod}/session-${si + 1}/vd-${vi + 1}:${vd}`,
                payload: { vkn, vdkodu: vd, sessionData },
                vd,
                moduleName: mod
              });
            });
          });
        });

        for (const c of csCandidates) {
          lastPayloadName = c.name;
          tried.push(c.vd);
          this.log('ygiris', `Bilinen adres CSCaller deneniyor: ${lastPayloadName}`);
          try {
            const result = await callEysCSCaller(CFG.COMMANDS.YG_VD_ADRESLER, c.payload, 11000, c.moduleName || '__local__');
            lastResp = result.response || result.data || result;
            list = normalizeVdAdresRows(lastResp);
            callerNote = `CSCaller cevap verdi. module=${c.moduleName || '__local__'}, local=${result.useLocalDispatch ? 'evet' : 'hayır'}, dispatch=${result.dispatchUrl || 'yerel/default'}, vd=${c.vd}`;
            if (list.length) {
              if (selEl && c.vd && selEl.value !== c.vd && Array.from(selEl.options).some(o => o.value === c.vd)) selEl.value = c.vd;
              break;
            }
            const pv = previewResponse(lastResp);
            if (/yetkiniz yok|yetki/i.test(pv)) {
              this.log('ygiris', `CSCaller yetki mesajı döndürdü; sonraki VD/session deneniyor: ${c.vd}`, true);
            }
          } catch (err) {
            lastResp = { __error: err?.message || String(err) };
            callerNote = `CSCaller hata: ${err?.message || String(err)}`;
            this.log('ygiris', `Bilinen adres CSCaller hata, yedekler denenebilir: ${err?.message || String(err)}`, true);
          }
        }

        }

        // 3) Yedek: eğer EYS ekranında daha önce aynı servis çalıştıysa, yakalanan token/payload ile direkt dispatch.
        if (!list.length) {
          const tokenCandidates = getEysTokenCandidatesForCmd(CFG.COMMANDS.YG_VD_ADRESLER);
          if (!tokenCandidates.length) tokenCandidates.push({ token: '', why: 'no-token' });
          const directCandidates = [];
          const directUrls = getDirectDispatchUrls();
          directUrls.forEach((url, ui) => {
            sessions.forEach((sessionData, si) => {
              vdCodes.forEach((vd, vi) => {
                tokenCandidates.forEach((tk, ti) => {
                  directCandidates.push({
                    name: `FETCH:${ui === 0 ? 'local-gibintranet' : 'eyoklama'}/session-${si + 1}/vd-${vi + 1}:${vd}/token-${ti + 1}:${tk.why || 'token'}`,
                    payload: { vkn, vdkodu: vd, sessionData },
                    vd,
                    url,
                    token: tk.token || '',
                    tokenWhy: tk.why || ''
                  });
                });
              });
            });
          });

          for (const c of directCandidates) {
            lastPayloadName = c.name;
            directTried.push(`${c.vd}/${c.tokenWhy || '-'}:${maskTokenForLog(c.token)}`);
            this.log('ygiris', `Bilinen adres direkt dispatch yedek deneniyor: ${lastPayloadName}`);
            try {
              const resp = await post(c.url || CFG.EYS_URL, CFG.COMMANDS.YG_VD_ADRESLER, c.payload, c.token || '');
              lastResp = resp;
              list = normalizeVdAdresRows(resp);
              if (list.length) {
                if (selEl && c.vd && selEl.value !== c.vd && Array.from(selEl.options).some(o => o.value === c.vd)) selEl.value = c.vd;
                callerNote = `Direkt dispatch yedek OK. URL=${c.url || '-'}, VD=${c.vd}, tokenKaynak=${c.tokenWhy || '-'}`;
                break;
              }
              const pv = previewResponse(resp);
              if (/yetkiniz yok|yetki/i.test(pv)) this.log('ygiris', `Direkt dispatch yetki mesajı döndürdü: ${c.vd}/${c.tokenWhy}`, true);
            } catch (err) {
              lastResp = { __error: err?.message || String(err) };
              this.log('ygiris', `Direkt dispatch yedek hata: ${err?.message || String(err)}`, true);
            }
          }
        }

        this.ygKnownAddresses = list;

        if (box) {
          box.innerHTML = list.length ? list.map((a, i) => {
            const adr = a.adresString || pickValue(a.raw, ['ADRESSTRING','adresString','adres','text','ADRES']) || '';
            const no = a.adresNo || pickValue(a.raw, ['ADRESNO','adresNo','ano']) || '';
            return `<div class="list-row" data-yg-known-addr="${i}"><div><strong>${i + 1}. ${htmlEscape(no || 'Adres no yok')}</strong><div class="tiny">${htmlEscape(adr || '-')}</div></div><button class="inline-btn good" data-yg-known-pick="${i}">Yoklama Adresi Yap</button></div>`;
          }).join('') : `<div class="tiny">Bilinen adres bulunamadı.<br>Son payload: ${htmlEscape(lastPayloadName)}<br>Akış: yerel CSCaller.call → gerekirse /gibintranet_server/dispatch → sonra /edenetis/dispatch yedeği<br>Not: ${htmlEscape(callerNote)}<br>Seçili görünen VD: ${htmlEscape(optText)}<br>Denenen VD kodları: ${htmlEscape(vdCodes.join(', '))}<br>CSCaller denenenler: ${htmlEscape(tried.join(', '))}<br>Direkt yedek denenenler: ${htmlEscape(directTried.slice(0, 18).join(' | '))}<br>Payload tipi: vkn + vdkodu + sessionData<br>Cevap: ${htmlEscape(previewResponse(lastResp)).slice(0, 700)}</div>`;
          box.querySelectorAll('[data-yg-known-pick]').forEach(btn => btn.onclick = (ev) => { ev.stopPropagation(); void this.selectYgKnownAddress(Number(btn.getAttribute('data-yg-known-pick'))); });
          box.querySelectorAll('[data-yg-known-addr]').forEach(row => row.onclick = () => { void this.selectYgKnownAddress(Number(row.getAttribute('data-yg-known-addr'))); });
        }

        if (list.length) this.log('ygiris', `Bilinen adresler alındı. Akış=${lastPayloadName}, kayıt=${list.length}`);
        else this.log('ygiris', `Bilinen adres alınamadı. Son cevap: ${previewResponse(lastResp)}`, true);
      } catch (err) {
        if (box) box.innerHTML = `<div class="tiny">Bilinen adres sorgusu hata: ${htmlEscape(err?.message || String(err))}</div>`;
        this.log('ygiris', `Bilinen adres sorgusu hata: ${err?.message || String(err)}`, true);
      }
    }

    async selectYgKnownAddress(idx, autoLookup = true) {
      const a = (this.ygKnownAddresses || [])[idx];
      if (!a) return;
      const no = String(a.adresNo || pickValue(a.raw || a, ['ADRESNO','adresNo','ano']) || '').trim();
      const txt = String(a.adresString || pickValue(a.raw || a, ['ADRESSTRING','adresString','adres','text','ADRES']) || '').trim();
      this.ygSelectedKnownAddress = { adresNo: no, atext: txt, ADRESNO: no, ADRESSTRING: txt, raw: a.raw || a };
      this.setYgField('yg_bilinen_adres_secili', no);
      this.setYgField('yg_adres_no', no);
      this.setYgField('yg_adres_text', txt);
      this.setYgField('yg_adres_source', 'Bilinen adres seçildi');
      const box = this.panel.querySelector('#yg_bilinen_adres_list');
      if (box) box.querySelectorAll('.list-row').forEach((r, i) => r.classList.toggle('selected', i === idx));
      this.ygLookup = this.ygLookup || {};
      this.ygLookup.adres = Object.assign({}, this.ygLookup.adres || {}, this.ygSelectedKnownAddress);
      this.renderYgSummary();
      this.log('ygiris', `Yoklama adresi seçildi: ${no}`);
      if (autoLookup && no) {
        try { await this.lookupYgAdresNo(); } catch (_) {}
      }
    }

    bindYgDynamicTemplateEvents() {
      const box = this.panel.querySelector('#yg_tur_special_fields');
      if (!box) return;
      box.querySelectorAll('#yg_asgari,#yg_diger').forEach(el => el.addEventListener('input', () => this.updateYgCalisanTotal()));
      const date = box.querySelector('#yg_ise_tarih');
      if (date && !date.value) date.value = eysTodayYYYYMMDD();
      const mulkNo = box.querySelector('#yg_mulk_vkntckn');
      if (mulkNo) {
        mulkNo.addEventListener('input', () => { mulkNo.value = this.onlyDigits(mulkNo.value).slice(0, 11); });
      }
      const lookup = box.querySelector('#yg_mulk_lookup_btn');
      if (lookup) lookup.onclick = () => this.lookupYgMulkSahibi();
      const add = box.querySelector('#yg_mulk_add_btn');
      if (add) add.onclick = () => this.addYgMulkSahibi();
      const clear = box.querySelector('#yg_mulk_clear_btn');
      if (clear) clear.onclick = () => { this.ygMulkSahipleri = []; this.renderYgMulkList(); };
    }

    updateYgCalisanTotal() {
      const asgari = Number(this.onlyDigits(this.panel.querySelector('#yg_asgari')?.value || '0') || '0');
      const diger = Number(this.onlyDigits(this.panel.querySelector('#yg_diger')?.value || '0') || '0');
      this.setYgField('yg_toplam_calisan', String(asgari + diger));
    }

    getYgCurrentYkodu() {
      return String(this.ygLastYkodu || this.panel.querySelector('#yg_son_kayit_kodu')?.value || this.panel.querySelector('#yg_temel_kodu')?.value || '').trim();
    }

    normalizeYoklamaTuruCode(t) {
      const map = {
        '10': '10', NAKIL_ISE_BASLAMA: '11', ADRES_DEGISIKLIGI: '12', SUBE_ACILIS: '13', EK_ISE_BASLAMA: '14', EK_ISI_BIRAKMA: '15', TUZEL_ACILIS: '16', ISI_BIRAKMA: '20', NAKIL_ISI_BIRAKMA: '21', SUBE_KAPANIS: '23', FAAL_MUK_KONTROL: '30', NAKIL_VASITALARI: '31', DIGER_UCRETLI_CALISAN: '32', DIGER_UCRETLI_CALISAN_TERK: '33', NAKIL_VASITALARI_TERK: '34', KAYIT_DISI_FAALIYET: '40', GMSI_MULK_SAHIBI: '50', GMSI_KIRACI: '51', RESEN_TERK_ISYERI: '60', RESEN_TERK_SIRKET: '61', KDV_IADE_IMALATCI: '70', KDV_IADE_IMALATCI_OLMAYAN: '71', KDV_IADE_IHRAC_KAYDI: '72', KDV_INCELEME: '80', VUK_160A: '83', ANLASMALI_MATBAA: '90', SERBEST: '130'
      };
      return map[String(t || '10')] || String(t || '10');
    }

    makeYgBildirimData(cfg) {
      return {
        kendisi: (this.panel.querySelector('#yg_bildirim_kendisi')?.value || '1') === '1',
        smmm: (this.panel.querySelector('#yg_smmm')?.value || '0') === '1',
        aciklama: this.panel.querySelector('#yg_bildirim_aciklama')?.value || ''
      };
    }

    makeYgMulkiyetData(cfg) {
      const mulkList = (this.ygMulkSahipleri || []).length
        ? this.ygMulkSahipleri
        : (cfg.mulkVkntckn ? [{ vkn: cfg.mulkVkntckn.length === 10 ? cfg.mulkVkntckn : '', tckn: cfg.mulkVkntckn.length === 11 ? cfg.mulkVkntckn : '', unvan: '', hisse: 100 }] : []);
      const out = { mulkiyet: cfg.mulkiyet };
      if (cfg.mulkiyet === '2' || cfg.mulkiyet === '3' || cfg.mulkiyet === '4') {
        out.kiralik = { odemeSekli: cfg.kiraSekli, odemeDonemi: cfg.kiraDonemi, kiraMiktari: Number(cfg.kiraTutari || 0), paraBirimi: cfg.para, mulkSahibi: mulkList };
      }
      out.emlak = { emlakvergidegeri: moneyToNumber(this.panel.querySelector('#yg_emlak_degeri')?.value || '0'), emlakSahibi: { vkn: '', tckn: '', unvan: '', sirketturu: '' } };
      return out;
    }

    buildYgDetailByType(cfg) {
      const type = String(cfg.yturu || '10');
      const code = this.normalizeYoklamaTuruCode(type);
      const special = this.collectYgSpecialFields();
      const bildirim = this.makeYgBildirimData(cfg);
      const mulk = this.makeYgMulkiyetData(cfg);
      const calisan = { asgariUcretli: Number(cfg.asgari || 0), digerUcretli: Number(cfg.diger || 0), toplam: Number(cfg.asgari || 0) + Number(cfg.diger || 0) };
      const dateVal = cfg.iseTarih || eysTodayYYYYMMDD();
      const tarihKey = {
        '10':'iseBaslamaTarihi','11':'nakilIseBaslamaTarihi','12':'adresDegisiklikTarihi','13':'subeIseBaslamaTarihi','14':'ekIseBaslamaTarihi','15':'ekIsiBirakmaTarihi','16':'iseBaslamaTarihi','20':'isiBirakmaTarihi','21':'nakilIsiBirakmaTarihi','23':'subeKapanisTarihi'
      }[code] || 'tarih';
      const tarihObj = { [tarihKey]: dateVal };
      const detay = {};
      if (['10','11','12'].includes(code)) detay.iseBaslama = Object.assign({}, tarihObj, calisan, mulk, { bildirimdeBulunan: bildirim });
      else if (code === '13') detay.subeAcilis = Object.assign({}, tarihObj, calisan, mulk, { mukellefiyetTuru: special.yg_mukellefiyet_turu || '1', bildirimdeBulunan: bildirim });
      else if (code === '14') detay.ekIseBaslama = Object.assign({}, tarihObj, { bildirimdeBulunan: bildirim });
      else if (code === '15') detay.ekIsiBirakma = Object.assign({}, tarihObj, { bildirimdeBulunan: bildirim });
      else if (code === '16') detay.tuzelIseBaslama = Object.assign({}, tarihObj);
      else if (['20','21'].includes(code)) detay.isiBirakma = Object.assign({}, tarihObj, { bildirimdeBulunan: bildirim });
      else if (code === '23') detay.subeKapanis = Object.assign({}, tarihObj, { bildirimdeBulunan: bildirim });
      else if (['31','34'].includes(code)) detay.aracBilgi = { plakaNo: special.yg_arac_plaka || '', sasiNo: special.yg_arac_sasi || '', tescil: special.yg_arac_tescil_tarihi || '', cins: special.yg_arac_cins || '', marka: special.yg_arac_marka || '', model: special.yg_arac_model || '', mernisAdresi: special.yg_arac_mernis_adres || '', yoklamaAdresiYap: special.yg_arac_yoklama_adresi_yap || '1' };
      else if (code === '50') detay.mulkSahibi = { gayrimenkul: special.yg_gmsi_mulk_gayrimenkul || '' };
      else if (code === '51') detay.kiraci = { vkn: (special.yg_kiraci_vkntckn || '').length === 10 ? special.yg_kiraci_vkntckn : '', tckn: (special.yg_kiraci_vkntckn || '').length === 11 ? special.yg_kiraci_vkntckn : '', adSoyad: special.yg_kiraci_adsoyad || '', odemeSekli: special.yg_kiraci_kira_sekli || '1', odemeDonemi: special.yg_kiraci_kira_donemi || '1', kiraMiktari: moneyToNumber(special.yg_kiraci_kira_tutari || '0'), paraBirimi: special.yg_kiraci_para || '1', vdkodu: special.yg_kiraci_vd || '', adresNo: special.yg_kiraci_adres || '' };
      else if (code === '61' || code === '62') detay.yonetici = { vkn: (special.yg_yonetici_vkntckn || '').length === 10 ? special.yg_yonetici_vkntckn : '', tckn: (special.yg_yonetici_vkntckn || '').length === 11 ? special.yg_yonetici_vkntckn : '', vdkodu: special.yg_yonetici_vd || '', adresNo: special.yg_yonetici_adres || '', mernisAdresiniGetir: special.yg_yonetici_mernis_getir || '1', mernisAdresi: special.yg_yonetici_mernis_adres || '' };
      else if (code === '80' || code === '83') detay.ozelesas = { mulkiyet: cfg.mulkiyet };
      else if (code === '130') detay.moduller = {
        mulkiyetBilgisi: !!special.yg_serbest_0, faaliyetTespiti: !!special.yg_serbest_1, calisanTespiti: !!special.yg_serbest_2, okcTespiti: !!special.yg_serbest_3, posTespiti: !!special.yg_serbest_4, demirbasTespiti: !!special.yg_serbest_5, vergiLevhasiKontrolu: !!special.yg_serbest_6, sonDuzenlenenBelgeler: !!special.yg_serbest_7, zRaporlariKontrolu: !!special.yg_serbest_8, belgeIhlalleriKontrolu: !!special.yg_serbest_9, naceKoduDegisikligi: !!special.yg_serbest_10
      };
      else detay.genel = Object.assign({}, tarihObj, { aciklama: cfg.yoklamaAciklama || cfg.aciklama || '' });
      return { detay, yturuCode: code, special };
    }

    clearYoklamaGirisForm() {
      if (!confirm('Yoklama Giriş formu temizlensin mi?')) return;
      this.panel.querySelectorAll('[data-page="ygiris"] input:not([readonly]), [data-page="ygiris"] select, [data-page="ygiris"] textarea').forEach(el => {
        if (el.id === 'yg_role') el.value = '10';
        else if (el.id === 'yg_servis') el.value = '60';
        else if (el.id === 'yg_yturu') el.value = '10';
        else if (el.type === 'checkbox') el.checked = false;
        else if (el.tagName === 'SELECT') el.selectedIndex = 0;
        else el.value = '';
      });
      this.ygLookup = null; this.ygLastYkodu = ''; this.ygMulkSahipleri = []; this.ygMulkCurrent = null; this.ygKnownAddresses = []; this.ygSelectedKnownAddress = null;
      this.updateYgYoklamaBilgileriUi();
      this.fillYgTemelBilgileri();
      this.setYgKayitSonucuBilgileri('', '');
      this.setYgField('yg_son_islem', 'Yeni kayıt için temizlendi');
      const old = this.panel.querySelector('#yg_old_list'); if (old) old.innerHTML = '';
      const sum = this.panel.querySelector('#yg_summary'); if (sum) sum.innerHTML = '';
      this.log('ygiris', 'Yoklama Giriş formu temizlendi.');
    }

    async deleteYoklamaGirisNative() {
      const ykodu = this.getYgCurrentYkodu();
      if (!ykodu) return this.log('ygiris', 'Silinecek yoklama kodu yok.', true);
      if (!confirm(`${ykodu} kodlu yoklama kalıcı olarak silinecek. Devam edilsin mi?`)) return;
      try {
        const cfg = this.getYoklamaGirisConfig();
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
        const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_DELETE, { ykodu, yKodu: ykodu, sessionData });
        this.setYgField('yg_son_islem', 'Kaydı sil response alındı');
        this.log('ygiris', `Kaydı sil response: ${previewResponse(resp)}`);
      } catch (err) { this.log('ygiris', err?.message || String(err), true); }
    }

    async submitYoklamaGirisKoor() {
      const ykodu = this.getYgCurrentYkodu();
      if (!ykodu) return this.log('ygiris', 'Koordinatöre göndermek için yKodu yok.', true);
      if (!confirm(`${ykodu} kodlu yoklama koordinatöre gönderilecek. Devam edilsin mi?`)) return;
      try {
        const cfg = this.getYoklamaGirisConfig();
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '20', 'ygiris');
        const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SUBMIT_KOOR, { yKodu: ykodu, koorKodu: sessionData.user, sessionData });
        this.setYgField('yg_son_islem', 'Koordinatöre gönderildi/response alındı');
        this.log('ygiris', `Koordinatör gönder response: ${previewResponse(resp)}`);
      } catch (err) { this.log('ygiris', err?.message || String(err), true); }
    }

    async submitYoklamaGirisDirectEkip() {
      const cfg = this.getYoklamaGirisConfig();
      if (!confirm('Yoklama ekibe direkt gönderilecek. Devam edilsin mi?')) return;
      try {
        if (!this.ygLookup) await this.lookupYoklamaGiris();
        const built = this.buildYoklamaGirisPayload(cfg);
        const checkCmd = this.normalizeYoklamaTuruCode(cfg.yturu) === '16' ? CFG.COMMANDS.YG_CHECK_DIRECT_EKIP : CFG.COMMANDS.YG_CHECK_YOKLAMA_DIRECT_EKIP;
        let checkResp = null;
        try { checkResp = await post(CFG.EYS_URL, checkCmd, { yoklama: JSON.stringify(built.yoklama), sessionData: built.sessionData }); } catch (e) { this.log('ygiris', `Ekip kontrolü atlandı/başarısız: ${e.message || e}`, true); }
        let defaultEkip = '';
        const checkData = parsePossiblyJsonData(checkResp);
        if (typeof checkData === 'string') defaultEkip = checkData.split(',')[0] || '';
        else if (Array.isArray(checkData)) defaultEkip = pickValue(checkData[0] || {}, ['ekipkodu','ekipKodu','value','kod']) || '';
        else defaultEkip = pickValue(checkData || {}, ['ekipkodu','ekipKodu','value','kod','data']) || '';
        const ekipkodu = prompt('Ekibe direkt gönder için ekip kodu/seçim no girin. Kontrol cevabı monitöre yazıldı.', defaultEkip || '');
        this.log('ygiris', `Ekip kontrol response: ${previewResponse(checkResp)}`);
        if (!ekipkodu) return this.log('ygiris', 'Ekip kodu girilmedi; işlem iptal edildi.', true);
        const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SUBMIT_DIRECT_EKIP, { yoklama: JSON.stringify(built.yoklama), ekipkodu, sessionData: built.sessionData });
        const rawData = parsePossiblyJsonData(resp) || {};
        const data = rawData?.data && typeof rawData.data === 'object' ? rawData.data : rawData;
        const ykodu = data.ykodu || data.yKodu || data.yKODU || this.getYgCurrentYkodu();
        const durum = data.durum || data.DURUM || data.ydurum || '40';
        this.ygLastYkodu = ykodu || this.ygLastYkodu;
        this.setYgKayitSonucuBilgileri(this.ygLastYkodu, durum);
        this.setYgField('yg_son_islem', 'Ekibe direkt gönder response alındı');
        this.log('ygiris', `Ekibe direkt gönder response: ${previewResponse(resp)}`);
      } catch (err) { this.log('ygiris', err?.message || String(err), true); }
    }

    buildYoklamaGirisPayload(cfg) {
      if (!this.ygLookup) throw new Error('Önce VKN/TCKN sorgusu çalıştırın.');
      const sicil = this.ygLookup.sicil || {};
      const faaliyet = this.ygLookup.faaliyet || {};
      const known = this.ygSelectedKnownAddress || {};
      const fieldAdres = this.getYgAdresFromFields();
      const adres = Object.assign({}, this.ygLookup.adres || {}, fieldAdres);
      if (cfg.bilinenAdresNo || known.adresNo || known.ADRESNO) {
        adres.adresNo = cfg.bilinenAdresNo || known.adresNo || known.ADRESNO;
        adres.atext = known.atext || known.ADRESSTRING || adres.atext || adres.adresAciklama || cfg.adresText;
        adres.adresAciklama = adres.atext;
      }
      const sessionData = this.ygLookup.sessionData || buildSessionData(cfg.role);
      const vkn = String(sicil.vergiNo || cfg.vkn || '').trim();
      const tckn = String(sicil.mukellefNo || cfg.tckn || (cfg.vkntckn.length === 11 ? cfg.vkntckn : '') || '').trim();
      if (!vkn && !tckn) throw new Error('Kaydetmek için VKN veya TCKN bulunamadı.');
      if (!cfg.iseTarih || cfg.iseTarih.length !== 8) throw new Error('Tarih alanı YYYYMMDD formatında olmalı.');
      if (cfg.sms === '1' && cfg.tel && cfg.tel.length !== 10) throw new Error('SMS gönderilsin seçiliyse telefon 10 hane olmalı ya da SMS gönderilmesin seçilmeli.');
      if (cfg.ihbarDayali && !cfg.ihbarTarihSayi) throw new Error('İhbara dayalı yoklama seçildiyse İhbarın Tarih/Sayı Bilgisi girilmelidir.');
      if (!String(adres.adresNo || cfg.adresNo || '').trim() && cfg.adresYetersiz !== '1') throw new Error('Adres no yoksa “Adres Yetersizdir” seçilip açıklama girilmelidir.');
      if (cfg.adresYetersiz === '1' && !cfg.aciklama) throw new Error('Adres yetersiz seçildiyse adres açıklaması girilmelidir.');

      const detailBuilt = this.buildYgDetailByType(cfg);
      const ytext = (cfg.aciklama || cfg.yoklamaAciklama || '') + ' - [' + [cfg.ilText, cfg.ilceText, cfg.mahalleText, cfg.csbmText, cfg.diskapiText, cfg.ickapiText].filter(x => x && x !== '---').join('/') + ']';
      const effectiveMukGrup = cfg.mukGrup || this.inferMukellefGrubuFromSicil(sicil) || '1';
      const yoklama = {
        kimlik: { vkn, tckn, unvan: cfg.unvan || sicil.kimlikUnvan || '', sirketturu: Number(sicil.sirketTuru || cfg.isletmeTuru || 1) },
        yturu: detailBuilt.yturuCode,
        yturuText: cfg.yturuText,
        mukiletisim: { tel: cfg.tel, eposta: cfg.eposta, issms: cfg.sms === '1', smsdurum: cfg.sms === '1' ? '1' : '0', smstarih: null },
        ihbaraDayali: cfg.ihbarDayali ? 1 : 0,
        ihbarKaynak: cfg.ihbarDayali ? cfg.ihbarKaynak : '',
        ihbarKaynakText: cfg.ihbarDayali ? cfg.ihbarKaynakText : '',
        ihbarTarihSayiBilgisi: cfg.ihbarDayali ? cfg.ihbarTarihSayi : '',
        detay: detailBuilt.detay,
        detayRaw: detailBuilt.special,
        mukGrupData: {
          mukGrup: effectiveMukGrup, isletmeTuru: cfg.isletmeTuru,
          faaliyetKonusu: cfg.faaliyetText || faaliyet.text || '', faaliyetKodu: cfg.faaliyetValue || faaliyet.value || '',
          faaliyetTuru: cfg.faaliyetTuru, faaliyetVdKodu: cfg.faaliyetTuru === 'VD' ? cfg.faaliyetVd : '', faaliyetVdText: cfg.faaliyetTuru === 'VD' ? cfg.faaliyetVdText : '', isyeriTuru: cfg.isyeriTuru
        },
        yoklamaAdresi: {
          il: String(adres.ilKod || cfg.il || ''), ilce: String(adres.ilceKod || cfg.ilce || ''), mahalle: String(adres.mahKod || cfg.mahalle || ''), csbm: String(adres.csbmKod || cfg.csbm || ''),
          diskapi: String(adres.binaKod || cfg.diskapi || ''), diskapitext: String(adres.disKapiNo || cfg.diskapiText || ''), ickapi: String(adres.adresNo || cfg.ickapi || ''),
          ano: String(adres.adresNo || cfg.adresNo || ''), atext: String(adres.atext || adres.adresAciklama || cfg.adresText || ''), aciklama: cfg.aciklama || '', yetersiz: cfg.adresYetersiz === '1' ? 1 : 0, ytext
        },
        yoklamaAciklama: cfg.yoklamaAciklama || cfg.aciklama || cfg.tel || '',
        disGorev: { disGorev: cfg.disGorev, vdkodu: cfg.disGorevVd, yetkiTespit: cfg.yetkiTespit },
        durum: '', kaynakKodu: 0, birimKodu: sessionData.birim, kullaniciKodu: sessionData.user, servis: cfg.servis, eosrol: sessionData.rol, eosusergiris: sessionData.giris
      };
      return { yoklama, sessionData, yturuCode: detailBuilt.yturuCode };
    }


    compactYgSavePayloadForMemurHar(yoklama) {
      // Gerçek memur HAR'da save payload sade geliyor; boş/yardımcı alanları göndermeyelim.
      const y = JSON.parse(JSON.stringify(yoklama || {}));
      if (!y.ihbaraDayali) {
        delete y.ihbaraDayali; delete y.ihbarKaynak; delete y.ihbarKaynakText; delete y.ihbarTarihSayiBilgisi;
      }
      if (!y.yturuText) delete y.yturuText;
      if (!y.detayRaw || (typeof y.detayRaw === 'object' && !Object.keys(y.detayRaw).length)) delete y.detayRaw;
      if (y.mukGrupData) {
        if (!y.mukGrupData.faaliyetKodu) delete y.mukGrupData.faaliyetKodu;
        if (!y.mukGrupData.faaliyetTuru) delete y.mukGrupData.faaliyetTuru;
        if (!y.mukGrupData.faaliyetVdKodu) delete y.mukGrupData.faaliyetVdKodu;
        if (!y.mukGrupData.faaliyetVdText) delete y.mukGrupData.faaliyetVdText;
      }
      const ib = y.detay && (y.detay.iseBaslama || y.detay.tuzelIseBaslama || y.detay.subeAcilis || y.detay.genel);
      if (ib && typeof ib === 'object' && Object.prototype.hasOwnProperty.call(ib, 'toplam')) delete ib.toplam;
      if (y.disGorev && !y.disGorev.disGorev && !y.disGorev.vdkodu && !y.disGorev.yetkiTespit) delete y.disGorev;
      return y;
    }

    async saveYoklamaGiris() {
      const cfg = this.getYoklamaGirisConfig();
      if (!confirm('Yoklama kaydı sisteme kaydedilecek. Devam edilsin mi?')) return;
      try {
        if (!this.ygLookup) await this.lookupYoklamaGiris();
        const built = this.buildYoklamaGirisPayload(cfg);
        const kimlikNo = built.yoklama.kimlik.vkn || built.yoklama.kimlik.tckn;

        const terk = await post(CFG.EYS_URL, CFG.COMMANDS.YG_TERK_BILGI, { vkntckn: kimlikNo, kodu: '', val: '', sessionData: built.sessionData });
        const terkData = parsePossiblyJsonData(terk);
        if (terkData === '-1') throw new Error('VKN/TCKN format hatası.');
        if (terkData === '-2') throw new Error('Sistem hatası.');
        if (terkData === '8') throw new Error('V.İ.R. kapsamında terk mükellef için yoklama oluşturulamaz.');
        if (terkData === '21') throw new Error('VUK 160/A kapsamında terk mükellef için yoklama oluşturulamaz.');

        if (built.yturuCode === '16' && built.yoklama.kimlik.vkn) {
          try {
            const sermaye = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SERMAYE, { vkn: built.yoklama.kimlik.vkn, sessionData: built.sessionData });
            this.log('ygiris', `Sermaye kontrolü: ${previewResponse(sermaye)}`);
          } catch (e) { this.log('ygiris', `Sermaye kontrolü alınamadı: ${e.message || e}`, true); }
        }

        this.log('ygiris', `srvcYoklama_saveYoklama gönderiliyor. yturu=${built.yturuCode}`);
        const saveYoklama = this.compactYgSavePayloadForMemurHar(built.yoklama);
        const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SAVE, { yoklama: JSON.stringify(saveYoklama), sessionData: built.sessionData });
        const rawData = parsePossiblyJsonData(resp) || {};
        const data = rawData?.data && typeof rawData.data === 'object' ? rawData.data : rawData;
        const ykodu = data.ykodu || data.yKodu || data.yKODU || data.ykoduYeni || '';
        const durum = data.durum || data.DURUM || data.ydurum || '';
        this.ygLastYkodu = ykodu || this.ygLastYkodu;
        this.setYgKayitSonucuBilgileri(this.ygLastYkodu, durum);
        this.setYgField('yg_son_islem', 'Kaydet response alındı');
        this.log('ygiris', `Yoklama kaydet response: ${previewResponse(resp)}`);
        this.renderYgSummary();
      } catch (err) {
        this.log('ygiris', err?.message || String(err), true);
      }
    }

    async submitYoklamaGirisMudur() {
      const ykodu = this.getYgCurrentYkodu();
      if (!ykodu) return this.log('ygiris', 'Önce yoklamayı kaydedin; yKodu yok.', true);
      if (!confirm(`${ykodu} kodlu yoklama müdür onayına gönderilecek. Devam edilsin mi?`)) return;
      const cfg = this.getYoklamaGirisConfig();
      try {
        const sessionData = this.ygLookup?.sessionData || await this.bootRole(cfg.role || '10', 'ygiris');
        this.log('ygiris', `Müdür onayına gönderiliyor: ${ykodu}`);
        const resp = await post(CFG.EYS_URL, CFG.COMMANDS.YG_SUBMIT_MUDUR, { yKodu: ykodu, sessionData });
        this.setYgField('yg_son_islem', 'Müdür onayına gönder response alındı');
        this.log('ygiris', `Müdür onayı response: ${previewResponse(resp)}`);
      } catch (err) {
        this.log('ygiris', err?.message || String(err), true);
      }
    }


    applyEysDefaultSelections() {
      const forceVal = (id, val) => {
        const el = this.panel.querySelector('#' + id);
        if (el) el.value = val;
      };
      forceVal('filtered_role', '10');
      forceVal('filtered_servis', '91');
      forceVal('filtered_source', '2');
      forceVal('filtered_ydurum', '60');
      forceVal('filtered_sonucislem', '0');
      forceVal('filtered_icdis', '0');
      forceVal('filtered_belge_koor_no', defaultBelgeKoorNo(buildSessionData('10')));
      forceVal('daily_role', '10');
      forceVal('daily_servis', '91');
      forceVal('daily_source', '2');
      forceVal('daily_ydurum', '60');
      forceVal('daily_sonucislem', '0');

      const fvs = this.panel.querySelector('#filtered_vkn_start'); if (fvs && !fvs.value) fvs.value = '0000000000';
      const fve = this.panel.querySelector('#filtered_vkn_end'); if (fve && !fve.value) fve.value = '9999999999';
      const dvs = this.panel.querySelector('#daily_vkn_start'); if (dvs && !dvs.value) dvs.value = '0000000000';
      const dve = this.panel.querySelector('#daily_vkn_end'); if (dve && !dve.value) dve.value = '9999999999';
      const delay = this.panel.querySelector('#daily_delay'); if (delay && !delay.value) delay.value = '1800';
    }

    async ensureSideUrl() {
      if (this.sideUrl) return this.sideUrl;
      const candidates = buildSideCandidates();
      this.log('main', 'side-dispatch adresi aranıyor...');
      for (const url of candidates) {
        const probe = await tryPost(url, CFG.COMMANDS.SIDE_GET_MODULE_INFO, { moduleName: 'e', excludeList: [], lang: 'tr' });
        if (!probe || !probe.__error) {
          this.sideUrl = url;
          this.log('main', 'Kullanılacak side-dispatch: ' + url);
          return url;
        }
      }
      throw new Error('Çalışan side-dispatch adresi bulunamadı.');
    }

    async bootRole(role, tab = 'main') {
      const sessionData = buildSessionData(role);
      const isMudur = String(role) === '20';
      const user = sessionData.user;
      const sideUrl = await this.ensureSideUrl();
      const bfNames = isMudur ? ['e.P_DESKTOP_MUDUR'] : ['e.PG_INDEX'];
      const loadedList = isMudur ? ['g.PG_INDEX', 'e.PG_INDEX'] : ['g.PG_INDEX', 'g.PG_MHK_ANA_SAYFA'];

      this.log(tab, `${isMudur ? 'Müdür' : 'Memur'} bot BF yükleniyor: ${bfNames.join(', ')}`);

      await post(sideUrl, CFG.COMMANDS.SIDE_GET_MODULE_INFO, {
        moduleName: 'e',
        excludeList: [
          'jquery','jquery-ui','jquery-ui-timepicker','ui.datepicker-tr','jquery.maskedinput',
          'jquery.ratings','jquery-jmenu','jquery-currency-autonumeric','underscore','tinymce','nouislider','tus'
        ],
        lang: 'tr'
      });

      await post(sideUrl, CFG.COMMANDS.SIDE_GET_EAGER_BF_DEFS, {
        userid: user,
        bfnames: bfNames,
        loadedList,
        resourceBundleLang: 'tr'
      });

      try { await post(sideUrl, CFG.COMMANDS.SIDE_GET_SERVICE_DEF_LIST, {}); } catch (_) {}
      await post(CFG.EYS_URL, CFG.COMMANDS.CREATE_SESSION, { orgs: [{ birimKodu: sessionData.birim }], sessionData });
      try { await post(CFG.EYS_URL, CFG.COMMANDS.CHECK_USER, { tckn: sessionData.user, sessionData }); } catch (_) {}
      try { await post(CFG.EYS_URL, CFG.COMMANDS.GET_VD_ADI, { vdkodu: sessionData.birim, sessionData }); } catch (_) {}
      try {
        const koorResp = await post(CFG.EYS_URL, CFG.COMMANDS.GET_KOOR_OF_VD, { vdkodu: sessionData.birim, sessionData });
        const koorVal = koorResp && (koorResp.data || koorResp.value || koorResp.koor || koorResp);
        if (koorVal && typeof koorVal !== 'object') this.lastBelgeKoorNo = String(koorVal).trim();
      } catch (_) {}
      return sessionData;
    }


    uniqueYkodlari(list) {
      const out = [];
      const seen = new Set();
      for (const y of list || []) {
        const v = String(y || '').trim();
        if (!v || seen.has(v)) continue;
        seen.add(v);
        out.push(v);
      }
      return out;
    }

    async getIadeler(sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.IADE_LIST, {
        data: {
          koor: '',
          vd: sessionData.birim,
          vdkodu: sessionData.birim,
          icdis: '0'
        },
        sessionData
      });
    }

    async sendYoklamalarTekTek(ykodlari, sessionData, sendMethod, label, tab = 'main') {
      const list = this.uniqueYkodlari(ykodlari);
      const results = [];
      let ok = 0;
      let fail = 0;

      if (!list.length) {
        this.log(tab, `${label}: gönderilecek kayıt yok.`);
        return { ok, fail, total: 0, results };
      }

      this.log(tab, `${label}: ${list.length} kayıt tek tek gönderilecek.`);

      for (let i = 0; i < list.length; i += 1) {
        const ykodu = list[i];
        try {
          this.log(tab, `${label}: ${i + 1}/${list.length} gönderiliyor → ${ykodu}`);
          const resp = await sendMethod.call(this, [ykodu], sessionData);
          results.push({ ykodu, ok: true, resp });
          ok += 1;
          this.log(tab, `${label}: ${i + 1}/${list.length} tamam → ${previewResponse(resp)}`);
        } catch (err) {
          fail += 1;
          results.push({ ykodu, ok: false, error: err?.message || String(err) });
          this.log(tab, `${label}: ${i + 1}/${list.length} hata → ${ykodu} | ${err?.message || String(err)}`, true);
        }
        await sleep(CFG.SEQUENTIAL_SEND_WAIT_MS || 450);
      }

      this.log(tab, `${label}: tek tek gönderim bitti. Başarılı=${ok}, Hatalı=${fail}, Toplam=${list.length}`);
      return { ok, fail, total: list.length, results };
    }


    async getMemurList(sessionData, config = null) {
      const { bastar, bittar } = config || this.getMainConfig();
      return post(CFG.EYS_URL, CFG.COMMANDS.MEMUR_LIST, { bastar, bittar, vdkodu: sessionData.birim, sessionData });
    }

    async sendToMudur(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MEMUR_SEND, { ykodlari, sessionData });
    }

    async getMudurList(sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MUDUR_LIST, { birim: sessionData.birim, sessionData });
    }

    async sendToKoor(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MUDUR_SEND, { ykodlari, sessionData });
    }

    async resolveBelgeKoorNo(sessionData, preferred = '', tab = 'filtered') {
      const given = String(preferred || '').trim();
      if (given) return given;
      if (this.lastBelgeKoorNo) return this.lastBelgeKoorNo;
      try {
        const koorResp = await post(CFG.EYS_URL, CFG.COMMANDS.GET_KOOR_OF_VD, { vdkodu: sessionData.birim, sessionData });
        const koorVal = koorResp && (koorResp.data || koorResp.value || koorResp.koor || koorResp);
        if (koorVal && typeof koorVal !== 'object') {
          this.lastBelgeKoorNo = String(koorVal).trim();
          return this.lastBelgeKoorNo;
        }
      } catch (err) {
        this.log(tab, 'Belge koordinatörlük servisi alınamadı; varsayılan kullanılacak: ' + (err?.message || String(err)), true);
      }
      return defaultBelgeKoorNo(sessionData);
    }

    async getYoklamalarFiltered(sessionData, servis, range, tab = 'filtered', opts = {}) {
      const ydurum = String(opts.ydurum ?? '');
      const sonucislem = String(opts.sonucislem ?? '1');
      const sorgukaynak = String(opts.sorgukaynak ?? opts.source ?? '0');
      const { basvkn, sonvkn } = normalizeServerVknRange(opts.vknStart || '', opts.vknEnd || '');
      const icdis = String(opts.icdis ?? '0');
      const yoklamaKodu = String(opts.yoklamaKodu || '').trim();
      const benzersizKod = String(opts.benzersizKod || '').trim();
      const unvan = String(opts.unvan || '').trim();
      const disil = String(opts.disil || '').replace(/\D+/g, '').slice(0, 3);
      const disvd = String(opts.disvd || '').replace(/\D+/g, '').slice(0, 6);

      // EYS'in kendi rSorguKriter.getData akışı: benzersiz kod varsa sadece hashcode+belgekoorno,
      // yoklama kodu varsa sadece ykodu gönderilir; tarih/servis/durum filtreleri eklenmez.
      if (benzersizKod) {
        const belgekoorno = await this.resolveBelgeKoorNo(sessionData, opts.belgeKoorNo, tab);
        const queryData = { koor: '', vd: sessionData.birim, hashcode: benzersizKod, belgekoorno };
        this.log(tab, `Benzersiz kodla sorgu: hashcode=${benzersizKod} belgekoorno=${belgekoorno || '-'}`);
        this.log(tab, `Giden sorgu data=${JSON.stringify(queryData)}`);
        return post(CFG.EYS_URL, CFG.COMMANDS.GET_YOKLAMALAR, {
          data: queryData,
          sessionData
        });
      }

      if (yoklamaKodu) {
        const queryData = { koor: '', vd: sessionData.birim, ykodu: yoklamaKodu };
        this.log(tab, `Yoklama koduyla sorgu: ykodu=${yoklamaKodu}`);
        this.log(tab, `Giden sorgu data=${JSON.stringify(queryData)}`);
        return post(CFG.EYS_URL, CFG.COMMANDS.GET_YOKLAMALAR, {
          data: queryData,
          sessionData
        });
      }

      const queryData = {
        koor: '', vd: sessionData.birim, vdkodu: sessionData.birim, sorgukaynak, icdis,
        disil, disvd, basvkn, sonvkn, bastckn: '', sontckn: '', yabanci: 0,
        vkn: '', tckn: '', yturu: [], ydurum, sonucislem, servis: String(servis || ''),
        bastar: range.bastar, bittar: range.bittar, unvan, ym: ydurum === '60' ? '' : '', usekullanici: false,
        eosusergiris: sessionData.giris, eosuser: sessionData.user, ihbaraDayali: false
      };
      this.log(tab, `Yoklamalar sorgulanıyor. kaynak=${sorgukaynak} görev=${icdis} servis=${servis || '-'} bastar=${range.bastar} bittar=${range.bittar} ydurum=${ydurum || '-'} sonucislem=${sonucislem} vkn=${basvkn || '-'}..${sonvkn || '-'} disil=${disil || '-'} disvd=${disvd || '-'} unvan=${unvan || '-'}`);
      this.log(tab, `Giden sorgu data=${JSON.stringify(queryData)}`);
      return post(CFG.EYS_URL, CFG.COMMANDS.GET_YOKLAMALAR, {
        data: queryData,
        sessionData
      });
    }


    buildYoklamaQueryOptions(cfg = {}) {
      return {
        sorgukaynak: cfg.source,
        ydurum: cfg.ydurum,
        sonucislem: cfg.sonucislem,
        vknStart: cfg.vknStart,
        vknEnd: cfg.vknEnd,
        icdis: cfg.icdis,
        disil: cfg.disil,
        disvd: cfg.disvd,
        yoklamaKodu: cfg.yoklamaKodu,
        benzersizKod: cfg.benzersizKod,
        belgeKoorNo: cfg.belgeKoorNo,
        unvan: cfg.unvan
      };
    }

    async getYoklamalarByConfig(sessionData, cfg, range, tab = 'filtered') {
      const opts = this.buildYoklamaQueryOptions(cfg);
      if (cfg.useFallback) {
        this.log(tab, 'Yedek sorgu modu açık: önce seçili seçenek birebir denenecek; boş dönerse HAR yedeği devreye girecek.');
        return this.getYoklamalarWithHarFallback(sessionData, cfg, range, tab);
      }
      this.log(tab, 'Birebir EYS sorgu modu: yedek/Hepsi sorgusuna düşülmeyecek.');
      return this.getYoklamalarFiltered(sessionData, cfg.servis, range, tab, opts);
    }

    async getYoklamalarWithHarFallback(sessionData, cfg, range, tab = 'filtered') {
      const exactSearch = String(cfg?.yoklamaKodu || cfg?.benzersizKod || '').trim();
      const tried = new Set();
      const makeKey = (servis, opts) => JSON.stringify({
        servis: String(servis || ''),
        source: String(opts.sorgukaynak ?? opts.source ?? ''),
        icdis: String(opts.icdis ?? ''),
        ydurum: String(opts.ydurum ?? ''),
        sonucislem: String(opts.sonucislem ?? ''),
        disil: String(opts.disil || ''),
        disvd: String(opts.disvd || '')
      });
      const attempt = async (label, servis, opts) => {
        const key = makeKey(servis, opts);
        if (tried.has(key)) return null;
        tried.add(key);
        if (label) this.log(tab, label);
        const resp = await this.getYoklamalarFiltered(sessionData, servis, range, tab, opts);
        const rows = extractYoklamaRows(resp);
        return { resp, rows, servis, opts };
      };

      const baseOpts = this.buildYoklamaQueryOptions(cfg);
      let result = await attempt('', cfg.servis, baseOpts);
      if (exactSearch || (result && result.rows.length)) return result.resp;

      // HAR'da görülen çalışan günlük kombinasyon:
      // sorgukaynak=2, icdis=0, servis=91, ydurum=60, sonucislem=0, disil/disvd boş.
      // Kullanıcı EYS ekranında hedef/kaynak veya giden dış gibi dar seçenek seçtiğinde sonuç 0 dönebiliyor.
      const fallbacks = [];
      if (String(baseOpts.icdis || '') !== '0' || baseOpts.disil || baseOpts.disvd) {
        fallbacks.push({
          label: 'HAR yedek: görev yeri Hepsi, kaynak/hedef il-VD boş deneniyor.',
          servis: cfg.servis,
          opts: { ...baseOpts, icdis: '0', disil: '', disvd: '' }
        });
      }
      if (String(baseOpts.sonucislem ?? '') !== '0') {
        fallbacks.push({
          label: 'HAR yedek: işlem durumu Hepsi deneniyor.',
          servis: cfg.servis,
          opts: { ...baseOpts, sonucislem: '0', icdis: '0', disil: '', disvd: '' }
        });
      }
      if (String(baseOpts.sorgukaynak ?? '') !== '2') {
        fallbacks.push({
          label: 'HAR yedek: Arşiv dahil tüm veriler deneniyor.',
          servis: cfg.servis,
          opts: { ...baseOpts, sorgukaynak: '2', sonucislem: '0', icdis: '0', disil: '', disvd: '' }
        });
      }
      if (String(cfg.servis || '') !== '91') {
        fallbacks.push({
          label: 'HAR yedek: servis 91 deneniyor.',
          servis: '91',
          opts: { ...baseOpts, sorgukaynak: '2', ydurum: baseOpts.ydurum || '60', sonucislem: '0', icdis: '0', disil: '', disvd: '' }
        });
      }
      if (String(cfg.servis || '')) {
        fallbacks.push({
          label: 'HAR yedek: servis boş / hepsi deneniyor.',
          servis: '',
          opts: { ...baseOpts, sorgukaynak: '2', sonucislem: '0', icdis: '0', disil: '', disvd: '' }
        });
      }

      for (const fb of fallbacks) {
        result = await attempt(fb.label, fb.servis, fb.opts);
        if (result && result.rows.length) {
          this.log(tab, `Yedek sorgu veri döndürdü: ${result.rows.length} kayıt.`);
          return result.resp;
        }
      }
      return result ? result.resp : await this.getYoklamalarFiltered(sessionData, cfg.servis, range, tab, baseOpts);
    }

    async archiveYoklamalar(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.ARCHIVE_YOKLAMA, { ykodlari, sessionData });
    }

    async markIslemYapildi(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.ISLEM_YAPILDI, { ykodlari, durum: '80', islem: 'işlem', sessionData });
    }

    async runFilteredWorkflow() {
      if (this.filteredInFlight) return this.log('filtered', 'Filtreli işlem zaten çalışıyor.');
      const cfg = this.getFilteredConfig();
      if (!cfg.bastar || !cfg.bittar) return this.log('filtered', 'Tarih alanları boş bırakılamaz.', true);

      this.filteredInFlight = true;
      try {
        const roleName = cfg.role === '10' ? 'Memur' : 'Müdür';
        this.log('filtered', `Filtreli işlem başlatıldı. rol=${roleName} kaynak=${cfg.source} servis=${cfg.servis || '-'} ydurum=${cfg.ydurum || '-'} sonucislem=${cfg.sonucislem} aksiyon=${cfg.action}`);
        const sessionData = await this.bootRole(cfg.role, 'filtered');
        const listResp = await this.getYoklamalarFiltered(sessionData, cfg.servis, { bastar: cfg.bastar, bittar: cfg.bittar }, 'filtered', { sorgukaynak: cfg.source, ydurum: cfg.ydurum, sonucislem: cfg.sonucislem, vknStart: cfg.vknStart, vknEnd: cfg.vknEnd, icdis: cfg.icdis, disil: cfg.disil, disvd: cfg.disvd, yoklamaKodu: cfg.yoklamaKodu, benzersizKod: cfg.benzersizKod, belgeKoorNo: cfg.belgeKoorNo, unvan: cfg.unvan });
        const rows = extractYoklamaRows(listResp);
        const filteredRows = this.filterRowsByVkn(clientFilterRows(rows, cfg), cfg);
        const ykodlari = filteredRows.map(x => x.ykodu);
        this.log('filtered', `Sorgu response önizleme: ${previewResponse(listResp)}`);
        this.log('filtered', `Servisten gelen kayıt: ${rows.length}, istemci filtresinden geçen: ${filteredRows.length}`);
        if (rows.length && !filteredRows.length) {
          this.log('filtered', 'Uyarı: servis kayıt döndürdü ama tarih/servis istemci filtresinden hiç kayıt geçmedi.', true);
        }
        if (!ykodlari.length) return this.log('filtered', 'Uygun yoklama bulunamadı.');
        this.log('filtered', `Toplam ${ykodlari.length} yoklama işlenecek. İlk kayıt: ${ykodlari[0]}`);
        const actionResp = cfg.action === 'archive'
          ? await this.archiveYoklamalar(ykodlari, sessionData)
          : await this.markIslemYapildi(ykodlari, sessionData);
        this.log('filtered', `${cfg.action === 'archive' ? 'Arşive kaldırma' : 'İşlem yapıldı'} tamamlandı. (${ykodlari.length} kayıt)`);
        this.log('filtered', `Aksiyon response: ${previewResponse(actionResp)}`);
      } catch (err) {
        this.log('filtered', err?.message || String(err), true);
      } finally {
        this.filteredInFlight = false;
      }
    }

    buildPdfUrl(ykodu, opts = {}) {
      const base = window.location.origin.includes('eyoklama.gelirler.gov.tr')
        ? window.location.origin
        : 'http://eyoklama.gelirler.gov.tr:32516';
      const u = new URL(`${base}/edenetis/getSonuc`);
      u.searchParams.set('yKodu', String(ykodu || ''));
      if (opts.autoPrint) u.searchParams.set('eys_autoprint', '1');
      if (opts.delay) u.searchParams.set('eys_delay', String(opts.delay));
      if (opts.closeAfter) u.searchParams.set('eys_close', '1');
      return u.toString();
    }

    renderDailyList() {
      const box = this.panel.querySelector('#daily_list');
      box.innerHTML = '';
      const visibleRows = this.getVisibleDailyRows();
      this.dailyVisibleRows = visibleRows;
      if (!visibleRows.length) {
        box.innerHTML = '<div class="list-row"><span class="tiny">Henüz kayıt yok veya VKN filtresine uyan kayıt yok.</span></div>';
        return;
      }
      visibleRows.forEach((row, index) => {
        const div = document.createElement('div');
        div.className = 'list-row';
        div.innerHTML = `
          <div>
            <div><strong>${row.ykodu}</strong></div>
            <div class="tiny">servis=${row.servis || '-'} durum=${row.durum || '-'} archived=${row.archived || '-'} ${row.unvan || ''}</div>
          </div>
          <div>
            <button class="inline-btn" data-open="${index}">PDF Aç</button>
            <button class="inline-btn good" data-print="${index}">Yazdır 1-2</button>
          </div>`;
        box.appendChild(div);
      });
      box.querySelectorAll('[data-open]').forEach(btn => btn.addEventListener('click', () => this.openDailyPdf(Number(btn.dataset.open))));
      box.querySelectorAll('[data-print]').forEach(btn => btn.addEventListener('click', () => this.printDailyPdf(Number(btn.dataset.print))));
    }

    async runDailyQuery() {
      if (this.dailyInFlight) return this.log('daily', 'Günlük sorgu zaten çalışıyor.');
      const cfg = this.getDailyConfig();
      if (!cfg.date) return this.log('daily', 'Günlük tarih boş bırakılamaz.', true);

      this.dailyInFlight = true;
      try {
        this.log('daily', `Günlük sorgu başlatıldı. rol=${cfg.role === '10' ? 'Memur' : 'Müdür'} kaynak=${cfg.source} servis=${cfg.servis || '-'} tarih=${cfg.date} ydurum=${cfg.ydurum || '-'} sonucislem=${cfg.sonucislem}`);
        const sessionData = await this.bootRole(cfg.role, 'daily');
        const listResp = await this.getYoklamalarByConfig(
          sessionData,
          cfg,
          { bastar: cfg.date, bittar: cfg.date },
          'daily'
        );
        this.dailyRows = extractYoklamaRows(listResp);
        this.log('daily', `Sorgu response önizleme: ${previewResponse(listResp)}`);
        this.log('daily', `Günlük sorgu filtreleri: kaynak=${cfg.source}, yoklama durumu=${cfg.ydurum || 'hepsi'}, işlem durumu=${cfg.sonucislem}`);
        this.log('daily', `Toplam ${this.dailyRows.length} kayıt bulundu. VKN filtresine uyan: ${this.getVisibleDailyRows().length}`);
        if (cfg.printer) this.log('daily', `Seçili yazıcı notu: ${cfg.printer}`);
        this.renderDailyList();
      } catch (err) {
        this.log('daily', err?.message || String(err), true);
      } finally {
        this.dailyInFlight = false;
      }
    }

    openDailyPdf(index) {
      const row = (this.dailyVisibleRows || this.dailyRows || [])[index];
      if (!row) return;
      const url = this.buildPdfUrl(row.ykodu);
      this.log('daily', `PDF açılıyor: ${row.ykodu}`);
      eysOpenPdfPopup(url);
    }

    async printDailyPdf(index) {
      const row = (this.dailyVisibleRows || this.dailyRows || [])[index];
      if (!row) return;
      const cfg = this.getDailyConfig();
      const url = this.buildPdfUrl(row.ykodu, { autoPrint: true, delay: cfg.delay });
      this.log('daily', `PDF yazdırma denemesi: ${row.ykodu} (Chrome PDF viewer otomatik print)`);
      const win = eysOpenPdfPopup(url);
      if (!win) return this.log('daily', 'Popup engellendi. PDF penceresi açılamadı.', true);
      try {
        await sleep(300);
        win.focus();
        this.log('daily', 'PDF sekmesi açıldı. Otomatik print parametresi gönderildi; olmazsa Ctrl+P kullan.');
      } catch (err) {
        this.log('daily', 'PDF sekmesi açıldı ama focus/print izleme başarısız: ' + (err?.message || String(err)), true);
      }
    }

    openAllDailyPdfs() {
      const rows = this.getVisibleDailyRows();
      if (!rows.length) return this.log('daily', 'Önce günlük sorgu yap veya VKN filtresine uyan kayıt yok.', true);
      this.log('daily', `Toplam ${rows.length} PDF açılıyor...`);
      rows.forEach(row => {
        const url = this.buildPdfUrl(row.ykodu);
        eysOpenPdfPopup(url);
      });
    }

    async queuePrintDailyPdfs() {
      if (this.dailyQueueInFlight) return this.log('daily', 'Kuyruk yazdırma zaten çalışıyor.');
      const rows = this.getVisibleDailyRows();
      if (!rows.length) return this.log('daily', 'Önce günlük sorgu yap veya VKN filtresine uyan kayıt yok.', true);
      this.dailyQueueInFlight = true;
      const cfg = this.getDailyConfig();
      try {
        this.log('daily', `Kuyruk yazdırma başladı. kayıt=${rows.length} gecikme=${cfg.delay}ms. Sayfa aralığı 1-2 için print penceresinde kontrol gerekir.`);
        if (cfg.printer) this.log('daily', `Hedef yazıcı notu: ${cfg.printer}`);
        for (let i = 0; i < rows.length; i += 1) {
          const row = rows[i];
          this.log('daily', `${i + 1}/${rows.length} işleniyor: ${row.ykodu}`);
          const autoUrl = this.buildPdfUrl(row.ykodu, { autoPrint: true, delay: cfg.delay });
          const win = window.open(autoUrl, '_blank');
          if (!win) {
            this.log('daily', `Popup engellendi: ${row.ykodu}`, true);
          } else {
            try { win.focus(); } catch (_) {}
          }
          await sleep(Math.max(1200, cfg.delay + 700));
        }
        this.log('daily', 'Kuyruk açma tamamlandı. Her PDF sekmesi otomatik print denedi; gerekirse Ctrl+P ile devam et.');
      } catch (err) {
        this.log('daily', err?.message || String(err), true);
      } finally {
        this.dailyQueueInFlight = false;
      }
    }

    scheduleNext(reason) {
      if (!this.running) return;
      clearTimeout(this.timer);
      this.log('main', `${reason} 5 dakika sonra yeni tur başlayacak...`);
      this.timer = setTimeout(() => this.runCycle(), CFG.RESCAN_MS);
    }

    async runMudurStage() {
      this.log('main', 'Müdür oturumu açılıyor...');
      const mudurSession = await this.bootRole('20', 'main');

      let iadeSet = new Set();
      try {
        this.log('main', 'Koordinatörden geri dönen/iade yoklamalar sorgulanıyor...');
        const iadeResp = await this.getIadeler(mudurSession);
        const iadeYkodlari = this.uniqueYkodlari(extractYkodlariStrict(iadeResp));
        iadeSet = new Set(iadeYkodlari);
        this.log('main', `İade sorgusu tamamlandı. Tekrar gönderilmeyecek kayıt: ${iadeYkodlari.length}`);
        if (iadeYkodlari.length) this.log('main', `İade ilk kayıt: ${iadeYkodlari[0]}`);
      } catch (err) {
        this.log('main', 'İade sorgusu alınamadı; akış devam edecek: ' + (err?.message || String(err)), true);
      }

      this.log('main', 'Müdür onay bekleyen listesi sorgulanıyor...');
      const mudurResp = await this.getMudurList(mudurSession);
      const mudurYkodlariRaw = this.uniqueYkodlari(extractYkodlariStrict(mudurResp));
      const mudurYkodlari = mudurYkodlariRaw.filter(yk => !iadeSet.has(yk));

      this.log('main', `Müdür response önizleme: ${previewResponse(mudurResp)}`);
      this.log('main', `Müdür listesi: ${mudurYkodlariRaw.length}, iade nedeniyle atlanan: ${mudurYkodlariRaw.length - mudurYkodlari.length}, gönderilecek: ${mudurYkodlari.length}`);

      if (mudurYkodlari.length > 0) {
        const sendSummary = await this.sendYoklamalarTekTek(
          mudurYkodlari,
          mudurSession,
          this.sendToKoor,
          'Müdür → Koordinatör',
          'main'
        );
        this.log('main', `Müdür → Koordinatör aşaması bitti. Başarılı=${sendSummary.ok}, Hatalı=${sendSummary.fail}`);
        return sendSummary.ok > 0;
      }

      this.log('main', 'Müdür listesinde gönderilecek kayıt yok.');
      return false;
    }

    async runCycle() {
      if (!this.running || this.inFlight) return;
      this.inFlight = true;
      this.cycleNo += 1;
      try {
        const dateCfg = this.getMainConfig();
        this.log('main', `Tur #${this.cycleNo} başladı. bastar=${dateCfg.bastar} bittar=${dateCfg.bittar}`);
        this.log('main', 'Memur oturumu açılıyor...');
        const memurSession = await this.bootRole('10', 'main');
        this.log('main', 'Memur listesi sorgulanıyor...');
        const memurResp = await this.getMemurList(memurSession, dateCfg);
        const memurYkodlari = extractYkodlariStrict(memurResp);
        this.log('main', `Memur response önizleme: ${previewResponse(memurResp)}`);
        if (memurYkodlari.length > 0) {
          this.log('main', `Memur listesinde ${memurYkodlari.length} kayıt bulundu. İlk kayıt: ${memurYkodlari[0]}`);
          const sendSummary = await this.sendYoklamalarTekTek(
            memurYkodlari,
            memurSession,
            this.sendToMudur,
            'Memur → Müdür',
            'main'
          );
          this.log('main', `Memur → Müdür aşaması bitti. Başarılı=${sendSummary.ok}, Hatalı=${sendSummary.fail}`);
          await sleep(CFG.AFTER_MEMUR_SEND_WAIT_MS);
          const mudurProcessed = await this.runMudurStage();
          this.scheduleNext(mudurProcessed ? 'Müdür aşaması da çalıştı.' : 'Müdür aşaması boş geçti.');
          return;
        }
        this.log('main', 'Memur listesi boş. Doğrudan müdür aşamasına geçiliyor...');
        const mudurProcessed = await this.runMudurStage();
        this.scheduleNext(mudurProcessed ? 'Müdür aşaması çalıştı.' : 'Bekleyen kayıt yok.');
      } catch (err) {
        this.log('main', err?.message || String(err), true);
        this.scheduleNext('Hata sonrası yeniden deneme için');
      } finally {
        this.inFlight = false;
      }
    }

    start() {
      if (this.running) return;
      this.running = true;
      this.setButtons(true);
      this.log('main', 'Bot başlatıldı. Bu akış yalnız Akış sekmesinin tarihlerini kullanır.');
      this.runCycle();
    }

    stop() {
      this.running = false;
      this.inFlight = false;
      clearTimeout(this.timer);
      this.timer = null;
      this.setButtons(false);
      this.log('main', 'Bot durduruldu.');
    }
  }

  function findRoleSelect() {
    const candidates = Array.from(document.querySelectorAll('select.csc-combobox, select'));
    for (const sel of candidates) {
      if (!visible(sel)) continue;
      const joined = Array.from(sel.options || []).map(o => textOf(o).toLowerCase()).join(' | ');
      if (joined.includes('yoklama') || joined.includes('memur') || joined.includes('müdür')) return sel;
    }
    return null;
  }

  function findOpenButton() {
    const candidates = Array.from(document.querySelectorAll('input.csc-button,input[type="button"],input[type="submit"],button'));
    for (const el of candidates) {
      if (!visible(el)) continue;
      const txt = textOf(el).toLowerCase();
      if (txt.includes('eys modülünü aç') || txt.includes('eys modulunu ac') || txt.includes('eys mod')) return el;
    }
    return null;
  }

  function findEysLauncher() {
    const exact = document.querySelector('#gen__1023.csc-button.gibintra-uyg-btns.gibintra-eds-btn');
    if (exact && visible(exact)) return exact;
    const all = Array.from(document.querySelectorAll('input.csc-button,button,input[type="button"],input[type="submit"],a,div,span')).filter(visible);
    const scored = all.map(el => {
      const txt = `${textOf(el)} ${el.id || ''} ${el.className || ''}`.toLowerCase();
      let score = 0;
      if (txt.includes('eys')) score += 10;
      if (txt.includes('elektronik yoklama')) score += 8;
      if (txt.includes('yoklama')) score += 6;
      if (txt.includes('gibintra-eds-btn')) score += 5;
      if (txt.includes('uyg-btn')) score += 3;
      return { el, score };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);
    return scored[0]?.el || null;
  }

  async function waitForPopupReady(log) {
    const started = Date.now();
    while (Date.now() - started < 15000) {
      const sel = findRoleSelect();
      const btn = findOpenButton();
      if (sel && btn) {
        log('Popup hazır. Rol seçimi ve aç butonu bulundu.');
        return true;
      }
      await sleep(300);
    }
    return false;
  }

  function selectRole(role, log) {
    const sel = findRoleSelect();
    if (!sel) return false;
    const targetNeedle = String(role) === '20' ? 'müdür' : 'memur';
    const opt = Array.from(sel.options).find(o => textOf(o).toLowerCase().includes(targetNeedle));
    if (!opt) return false;
    sel.value = opt.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    log(`Rol seçildi: ${opt.text}`);
    return true;
  }

  async function openFlow(role, log) {
    const launcher = findEysLauncher();
    if (!launcher) return log('EYS launcher bulunamadı.', true);
    log('EYS launcher tetikleniyor...');
    launcher.click();
    const ready = await waitForPopupReady(log);
    if (!ready) return log('Popup hazır olmadı.', true);
    const selected = selectRole(role, log);
    if (!selected) return log('Rol seçilemedi.', true);
    const btn = findOpenButton();
    if (!btn) return log('"EYS MODÜLÜNÜ AÇ" butonu bulunamadı.', true);
    log('Aç butonuna basılıyor...');
    btn.click();
    log('Açma akışı gönderildi.');
  }

  async function resumeIfNeeded(log) {
    const data = await eysStorageGet(CFG.STORAGE_KEY);
    if (!data || !data.role || Date.now() - Number(data.t || 0) > 120000) return;
    await eysStorageRemove(CFG.STORAGE_KEY);
    log(`Refresh sonrası otomatik devam ediyor. role=${data.role}`);
    openFlow(data.role, log);
  }

  injectStyle();
  const panel = createPanel();
  eysTryEmbedIntoMainPanel();
  const bot = new EysFullBot(panel);
  try { window.__istakipEysFullBotInstance = bot; } catch (_) {}
  try {
    const pg = window.__istakipEysPageSession || {};
    bot.log('main', 'EYS sayfa kütüphane bilgisi: libEDenetis/CSSession oturum köprüsü aktif. birim=' + (pg.birim || '-') + ' user=' + (pg.user || '-'));
  } catch (_) {}
  bot.log('main', 'Hazır.');
  bot.log('filtered', 'Hazır. Bu monitör yalnız Filtreli İşlem sekmesine aittir.');
  bot.log('daily', 'Hazır. Bu monitör yalnız Günlük PDF sekmesine aittir.');
  resumeIfNeeded(msg => bot.log('main', msg));
})();

try { setInterval(eysTryEmbedIntoMainPanel, 800); } catch (_) {}
