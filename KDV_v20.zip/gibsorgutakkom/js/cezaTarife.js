/* ===================================================================================
   VUK usulsüzlük / özel usulsüzlük ceza tarifeleri (fiil tarihi yılına göre)
   Kaynaklar: VUK GT 577 (2025), VUK GT 588 (2026, RG 31.12.2025 5. mük.), 7524 sayılı Kanun (02.08.2024'ten itibaren)
              PwC "VUK Ceza Tutarları" (2026 ve 2025 tabloları), Alomaliye (7524 sonrası 2024 tutarları)
   Mükellef grubu (EVDO cezalar[].mukellefGrubu):
     1 Sermaye şirketleri · 2 Sermaye şirketi dışı 1. sınıf tüccar ve serbest meslek erbabı · 3 2. sınıf tüccarlar
     4 Yukarıdakiler dışında kalıp beyanname usulüyle GV'ye tabi olanlar · 5 Kazancı basit usulde tespit edilenler · 6 GV'den muaf esnaf
   Tarihî tutarlar GİB'in "Vergi Usul Kanununda Yer Alan Cezalar ile İlgili Maktu Hadler" tablosundandır.
   =================================================================================== */
var CEZA_TARIFE = {
  /* VUK 352 — (1) sayılı cetvel: [1. derece, 2. derece] mükellef grubu 1..6 */
  m352: {
    '2021' : { 1:[240,130], 2:[140,70], 3:[70,32], 4:[32,19], 5:[19,9], 6:[9,5] },
    '2022' : { 1:[320,170], 2:[170,95], 3:[95,43], 4:[43,25], 5:[25,12], 6:[12,6.8] },
    '2023' : { 1:[700,370], 2:[420,210], 3:[210,95], 4:[95,55], 5:[55,26], 6:[26,15] },
    '2024a': { 1:[1100,580], 2:[660,330], 3:[330,150], 4:[150,87], 5:[87,40], 6:[40,23] },
    '2024b': { 1:[20000,10000], 2:[10000,5000], 3:[5000,3500], 4:[3500,2250], 5:[2250,1500], 6:[1500,1000] },   /* 02.08.2024–31.12.2024 (7524) */
    '2025' : { 1:[28000,14000], 2:[14000,7000], 3:[7000,5000], 4:[5000,3200], 5:[3200,2100], 6:[2100,1400] },   /* VUK GT 577 */
    '2026' : { 1:[35000,17000], 2:[17000,8700], 3:[8700,6000], 4:[6000,4000], 5:[4000,2600], 6:[2600,1700] }    /* VUK GT 588 */
  },
  /* VUK mük. 355 — bilgi vermeme / 107-A, mük.242, 256, 257, mük.257 ve GVK 98/A: [1. sınıf tüccar+SM erbabı, 2. sınıf tüccar+çiftçi+basit usul, diğerleri] */
  m355: {
    '2021' : [2500,1300,650],
    '2022' : [3400,1700,880],
    '2023' : [7500,3700,1900],
    '2024a': [11800,5800,3000],
    '2024b': [20000,10000,5000],
    '2025' : [28000,14000,7000],
    '2026' : [35000,17000,8700]
  },
  /* VUK mük. 355 — 107/A (e-tebligat) zorunluluğuna uymama */
  m355_107A: {
    '2021' : [1500,760,390],
    '2022' : [2000,1000,530],
    '2023' : [4400,2200,1180],
    '2024a': [6900,3400,1800],
    '2024b': [6900,3400,1800],
    '2025' : [9900,4800,2500],
    '2026' : [12000,6000,3000]
  },
  /* VUK 353/1 ve 353/2 — (2) sayılı cetvel: tespit sırasına göre asgari tutar [1., 2., 3., 4., 5., sonraki]; ceza = belge tutarının %10'u, bu asgariden az olamaz */
  m353: {
    '2024b': [10000,20000,30000,40000,50000,100000],
    '2025' : [14000,28000,43000,57000,70000,140000],
    '2026' : [17000,35000,53000,70000,87000,170000]
  }
};
/* mük.355 kademesi: mükellef grubu -> [0]=1.sınıf/SM, [1]=2.sınıf/basit usul, [2]=diğer */
function muk355Kademe(grubu){ grubu=String(grubu||''); if(grubu==='1'||grubu==='2')return 0; if(grubu==='3'||grubu==='5')return 1; if(grubu==='4'||grubu==='6')return 2; return -1; }
var MG_ADI={
  '1':'sermaye şirketleri',
  '2':'sermaye şirketi dışındaki 1. sınıf tüccar / serbest meslek erbabı',
  '3':'2. sınıf tüccarlar',
  '4':'beyanname usulündeki diğer gelir vergisi mükellefleri',
  '5':'kazancı basit usulde tespit edilenler',
  '6':'gelir vergisinden muaf esnaf'
};
var M355_KADEME_ADI=['1. sınıf tüccar / serbest meslek','2. sınıf tüccar / çiftçi / basit usul','diğerleri'];
function tarifeYili(fiilYmd){
  var s=String(fiilYmd||'').replace(/\D/g,'').slice(0,8); if(s.length!==8)return '';
  var ilk=+s.slice(0,4), ymd, y;
  if(ilk>=2000&&ilk<=2100){ymd=s;y=ilk;}else{y=+s.slice(4,8);ymd=s.slice(4,8)+s.slice(2,4)+s.slice(0,2);}
  if(y>=2026)return '2026'; if(y===2025)return '2025'; if(y===2024)return +ymd>=20240802?'2024b':'2024a'; if(y>=2021&&y<=2023)return String(y); return '';
}
function _tlfmt(v){ return Number(v||0).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
function _yakin(a,b){ return Math.abs(Number(a)-Number(b))<0.01; }

/* Neden metninden madde tespiti: 352/1, 352/2, 353/1, 353/2, mük.355 (107/A ayrı) */
function cezaMaddesi(nedenMetni,nedenKodu){
  var nd=String(nedenMetni||'').replace(/[İI]/g,'i').toLowerCase(), k=String(nedenKodu||'');
  if(/107\/a/.test(nd))return 'm355_107A';
  if(/m[üu]k(errer)?\.?\s*355/.test(nd)||k==='77'||k==='78'||k==='79')return 'm355';
  if(/353\/1/.test(nd)||k==='70')return 'm353';
  if(/353\/2/.test(nd)||k==='71')return 'm353';
  if(/352\/1/.test(nd)||k==='11')return 'm352_1';
  if(/352\/2/.test(nd)||k==='12')return 'm352_2';
  return '';
}
/* Kontrol: dönen {ok:true|false|null, mesaj}. ok=null -> tarife/madde tanımsız, kontrol yapılamadı.
   girdi: {madde, yil, grubu, matrah, tutar, kat, resen, tekerrur} */
function tarifeKontrol(g){
  var yil=g.yil, madde=g.madde; if(!yil||!madde)return {ok:null,mesaj:'tarife/madde tanımsız'};
  if(madde==='m352_1'||madde==='m352_2'){
    var t=CEZA_TARIFE.m352[yil]; var satir=t&&t[String(g.grubu)]; if(!satir)return {ok:null,mesaj:'352 tarifesi: '+yil+' / grup '+g.grubu+' tanımsız'};
    var bek=satir[madde==='m352_1'?0:1], mat=Number(g.matrah||0), kat=Number(g.kat||1), bekKat=g.resen?2:1;
    var m=[]; var ok=true;
    if(!_yakin(mat,bek)){ ok=false; m.push('usulsüzlük matrahı '+_tlfmt(mat)+' ≠ '+yil.replace('b',' (7524 sonrası)')+' tarifesi grup '+g.grubu+' '+(madde==='m352_1'?'1.':'2.')+' derece '+_tlfmt(bek)); } else m.push('matrah tarifeye uygun ('+_tlfmt(bek)+')');
    var bekTutar=bek*bekKat+Number(g.tekerrur||0);
    if(Number(g.tutar)>0&&!_yakin(Number(g.tutar),bekTutar)&&!_yakin(Number(g.tutar),mat*kat)){ ok=false; m.push('tutar '+_tlfmt(g.tutar)+' ≠ matrah × kat ('+_tlfmt(bekTutar)+')'); }
    return {ok:ok,mesaj:m.join('; ')};
  }
  if(madde==='m355'||madde==='m355_107A'){
    var tt=CEZA_TARIFE[madde][yil], grupKd=muk355Kademe(g.grubu), nk=String(g.nedenKodu||''), kodKd=({'77':0,'78':1,'79':2})[nk];
    var kd=(kodKd!=null)?kodKd:grupKd; if(!tt||kd<0)return {ok:null,mesaj:'mük.355 tarifesi: '+yil+' / grup '+g.grubu+' tanımsız'};
    var asg=tt[kd], tutar=Number(g.tutar||g.matrah||0);
    var grupUyumsuz=madde==='m355'&&kodKd!=null&&grupKd>=0&&kodKd!==grupKd;
    if(_yakin(tutar,asg))return {ok:!grupUyumsuz,mesaj:'mük.355 tutarı tarifeye uygun ('+_tlfmt(asg)+', neden kodu '+(nk||'-')+' / '+M355_KADEME_ADI[kd]+')'+(grupUyumsuz?'; ANCAK neden kodu '+nk+' ('+M355_KADEME_ADI[kodKd]+') ile MG '+g.grubu+' ('+(MG_ADI[String(g.grubu)]||'tanımsız')+') çelişiyor':'')};
    if(tutar>asg){ var kat3=_yakin(tutar,asg*3); return {ok:true,mesaj:'mük.355 tutarı '+_tlfmt(tutar)+' asgarinin ('+_tlfmt(asg)+') üzerinde — '+(kat3?'3 kat (gerçek faydalanıcı / POS) olabilir':'%10 hesaplı (IBAN/tevsik) olabilir, işlem tutarını kontrol edin')}; }
    return {ok:false,mesaj:'mük.355 tutarı '+_tlfmt(tutar)+' asgari tarifenin ('+_tlfmt(asg)+', kademe '+(kd+1)+') ALTINDA'};
  }
  if(madde==='m353'){
    var tiers=CEZA_TARIFE.m353[yil]; if(!tiers)return {ok:null,mesaj:'353 tarifesi '+yil+' tanımsız'};
    var tu=Number(g.tutar||g.matrah||0);
    for(var i=0;i<tiers.length;i++){ if(_yakin(tu,tiers[i]))return {ok:true,mesaj:'353 asgari tutar: '+(i+1)+'. tespit ('+_tlfmt(tiers[i])+')'}; }
    if(tu<tiers[0])return {ok:false,mesaj:'353 tutarı '+_tlfmt(tu)+' 1. tespit asgarisinin ('+_tlfmt(tiers[0])+') ALTINDA'};
    return {ok:true,mesaj:'353 tutarı '+_tlfmt(tu)+' asgarinin üzerinde — belge tutarının %10\'u olmalı (belge tutarı ≈ '+_tlfmt(tu*10)+')'};
  }
  return {ok:null,mesaj:'madde tanımsız'};
}
if(typeof window!=='undefined'){ window.CEZA_TARIFE=CEZA_TARIFE; window.tarifeKontrol=tarifeKontrol; window.cezaMaddesi=cezaMaddesi; window.tarifeYili=tarifeYili; }
