v4.31.8 — v4.31.2 Tabanlı Stabil Fix

Bu sürüm v4.31.2 düzgün çalışan panel görüntüsü baz alınarak hazırlandı.

Bilerek dokunulmayanlar:
- Panel/sekme taşıma mantığı
- Ana Modül / EYS Modülü görünümü
- EYS panel yerleşimi
- Liste ve siyah alan düzeni

Sadece düzeltilenler:
1. Bugün butonu hatası:
   fmtDateYYYYMMDD is not defined
   yerine güvenli eysTodayYYYYMMDD() kullanıldı.

2. CFG hatası:
   content.js içinde dış scope CFG.PANEL_ID kullanımı güvenli hale getirildi.

Not:
v4.31.5, v4.31.6 ve v4.31.7 üzerinde yapılan panel taşıma değişiklikleri bu sürüme alınmadı.
