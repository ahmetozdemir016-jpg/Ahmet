v4.31.24 Yoklama Türü Alan Şablonları

Eklenenler:
- Yoklama Giriş sekmesinde Yoklama Türü seçimine göre özel alan şablonları eklendi.
- Adres, dış görev ve yoklama açıklama alanları ortak bölüm olarak her türde görünür.
- İşe Başlama / Nakil İşe Başlama / Adres Değişikliği / Şube Açılışı / Ek İşe Başlama / Ek İşi Bırakma / İşi Bırakma / Nakil İşi Bırakma / Şube Kapanışı alanları ayrıldı.
- Nakil Vasıtaları ve Nakil Vasıtaları Terk için araç bilgileri alanları eklendi.
- GMSİ Mülk Sahibi ve GMSİ Kiracı alanları eklendi.
- Re’sen Terk şirket yetkilisi nezdinde için yönetici alanları eklendi.
- KDV İadeleri Vergi İncelemesine Tabi Olacak Mükellef Tespit Yoklaması ve VUK 160A için Özel Esas / İşyeri Mülkiyeti alanı eklendi.
- Serbest Yoklama için checkbox alanları eklendi.
- KDV İade (İmalatçıların İhraç Kaydı) ve Nakil Vasıtaları Terk seçenekleri listeye eklendi.

Not:
- Doğrudan SİSTEME KAYDET payloadı şimdilik yalnız İşe Başlama için kesindir.
- Diğer yoklama türlerinde alanlar EYS ekranını görsel/iş akışı olarak taklit eder; kayıt için o türe ait örnek payload yakalanınca ayrı bağlanmalıdır.
