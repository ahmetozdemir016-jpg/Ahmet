v4.31.27 EYS Kütüphane / Session Bridge

README(7).md incelendi.

EYS modülü açıldığında görülen ana yapılar:
- grid.locale-tr.min.js
- jquery.jqGrid-4.5.4
- side-bc.js içindeki CSC bileşenleri
- side-user-lib-e.js içindeki libEDenetis yardımcıları

Bu sürümde eklenen:
- Sayfa context içinde libEDenetis.getSessionData() okunur.
- CSSession.get(...) ile aşağıdaki anahtarlar okunur:
  - EOSROL
  - EOSUSER
  - EOSUSERGIRIS
  - EOSBIRIMKODU
  - EOSDEFILKODU
  - EOSADI
  - EOSUSERGIRISX
- İçerik scriptine güvenli postMessage köprüsü ile aktarılır.
- buildSessionData artık bu gerçek EYS değerlerini kullanır.
- Varsayılan 016253 / 35353114746 değerleri yalnızca gerçek session alınamazsa fallback olarak kalır.

README’den doğrulanan libEDenetis bilgileri:
- getSessionData() sessionData alanlarını topluyor.
- serviceCall(page, serviceName, parameters, ...) parametrelere sessionData ekliyor.
- showPdfSonuc / showPdfMektup PDF açma mantığında kullanılıyor.
- getTodayDateStr ve tarih yardımcıları EYS YYYYMMDD formatıyla uyumlu.
