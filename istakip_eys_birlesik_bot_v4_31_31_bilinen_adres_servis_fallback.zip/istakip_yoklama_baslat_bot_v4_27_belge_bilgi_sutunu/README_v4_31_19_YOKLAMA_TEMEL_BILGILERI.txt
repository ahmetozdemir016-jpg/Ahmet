v4.31.19 Yoklama Temel Bilgileri

Eklenenler:
- Yoklama Giriş sekmesinin başına “Yoklama Temel Bilgileri” bölümü eklendi.
- Bu bölümde gerçek EYS formundaki üst alanlar gösterilir:
  - Kullanıcı
  - İl
  - Kaynak
  - Birim Kodu
  - Kodu
  - Durumu
  - Rol
  - Servis
  - Yoklama Türü

Çalışma mantığı:
- Kullanıcı, il ve birim kodu oturum/sessionData bilgisinden otomatik dolar.
- Kaynak varsayılan “VERGİ DAİRESİ” gelir.
- Servis seçimi yine saveYoklama payloadındaki `servis` alanına gider.
- Yoklama kaydedilince dönen yKodu “Kodu” alanına, dönen durum “Durumu” alanına yazılır.

Not:
- Ana modül işlem sütunu düzeltmesi korunmuştur.
- İş Takip/EYS token ayrımı düzeltmesi korunmuştur.
