v4.31.25 Adres Belirleme + Bilinen Adresler

Eklenen/Düzenlenen:
- Yoklama Giriş > Yoklama Adresi bölümü EYS ekranındaki sıraya göre düzenlendi.
- Mükellefin Bilinen Adresleri alanı eklendi.
- Vergi Dairesi seçilince srvcRemoteCall_getVdAdresleri sorgusu ile ADRESSTRING/ADRESNO alınır.
- Bilinen adres tablosunda “Yoklama Adresi Yap” seçimi eklendi.
- Adres Belirleme için 3 sekme eklendi:
  1) İl-İlçe Merkezi: İl, İlçe, Mahalle + sağda CSBM, Dışkapı, İçkapı, Mernis Adres Text
  2) Belediye Adresi: İl, İlçe, Bucak, Belde + sağda Mahalle, CSBM, Dışkapı, İçkapı, Mernis Adres Text
  3) Köy Adresi: İl, İlçe, Bucak, Köy + sağda Mevki/Mezra, CSBM, Dışkapı, İçkapı, Mernis Adres Text
- Aktif adres moduna göre adresNo/adresText/aciklama payload alanları okunur.
- Önceki yoklama türü şablonları ve VD’ye bağlı faaliyet düzeltmeleri korunmuştur.

Not:
- Adres combo type numaraları EYS’ten gelen mevcut srvcRemoteCall_getAdresDataForCombo yapısına göre korunmuştur; belediye/köy alt kırılımlarında gerekirse yeni XHR örneğine göre type numarası ayrıca kesinleştirilebilir.
