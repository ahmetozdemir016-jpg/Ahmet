v4.31.23 Yoklama Bilgileri

Eklenen/Düzenlenen:
- Yoklama Giriş sekmesinde gerçek EYS formuna uygun “Yoklama Bilgileri” bölümü oluşturuldu.
- İşyeri Türü artık radio şeklinde:
  - Merkez
  - Şube
  - Depo
  - Mesken
  - Diğer
- Yoklama Türü bu bölümde seçiliyor.
- İşe Başlama seçiliyse çalışan sayısı, mülkiyet, kira, mülk sahibi alanları açık kalır.
- Diğer yoklama türleri seçilirse İşe Başlama alanları gizlenir ve uyarı gösterilir.
- Kayıt payloadı için isyeriTuru radio seçimine bağlandı.

Not:
- Doğrudan SİSTEME KAYDET şu anda yalnız İşe Başlama için aktiftir.
- Diğer yoklama türleri ekranda seçilebilir; kayıt için ilgili örnek payload ayrıca gerekir.
- VD’ye bağlı faaliyet, mükellef grubu otomatik, ihbar bilgileri ve token düzeltmeleri korunmuştur.
