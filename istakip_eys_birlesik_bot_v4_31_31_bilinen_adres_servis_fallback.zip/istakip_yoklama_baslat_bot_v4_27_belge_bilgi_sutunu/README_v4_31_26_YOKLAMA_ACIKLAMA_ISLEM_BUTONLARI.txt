v4.31.26 Yoklama Açıklama ve Alt İşlem Butonları

Eklenen/Düzenlenen:
- Yoklama Açıklama bölümü ayrı ortak bölüm olarak eklendi.
- Açıklama kutusu id=yg_yoklama_aciklama olarak payload içine ayrıca alındı.
- Dış Görev Bilgisi ayrı bölüm olarak korunur.
- Alt işlem butonları gerçek EYS sırasına göre eklendi:
  - Temizle (Yeni Kayıt)
  - Sisteme Kaydet
  - Müdür Onayına Gönder
  - Kaydı Sil
- Temizle butonu panel alanlarını temizler, varsa EYS ekranındaki Temizle/Yeni Kayıt düğmesini tetikler.
- Kaydı Sil butonu onay ister; varsa EYS ekranındaki Kaydı Sil düğmesini tetikler. Silme payloadı kesinleşmediği için düğme bulunamazsa API isteği göndermez.
- Kayıt sonrası son yKodu ve durum alanları alt bölümde de görünür.

Not:
- Sisteme Kaydet payloadı hâlâ kesin olarak İşe Başlama akışı üzerinden bağlıdır; diğer türlerde alan şablonları hazırlık/inceleme amaçlıdır.
