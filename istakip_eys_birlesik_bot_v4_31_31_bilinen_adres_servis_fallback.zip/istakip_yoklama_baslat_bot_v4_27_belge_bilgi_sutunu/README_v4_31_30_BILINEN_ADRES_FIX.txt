v4.31.30 Bilinen Adres Fix

Düzeltmeler:
- Vergi dairesi seçiminde değer bazen “016253-ÇEKİRGE(MERKEZ,FAAL)” gibi tam metin kalıyordu.
  EYS servisi ise vdkodu için sadece 6 haneli kod bekliyor. Artık otomatik “016253” çıkarılıyor.
- srvcRemoteCall_getVdAdresleri isteği artık EYS ekranındaki gibi sade gönderiliyor:
  { vkn, vdkodu, sessionData }
- ADRESSTRING / ADRESNO cevap ayrıştırması güçlendirildi.
  data, data.data, liste, rows, result ve iç içe JSON cevapları taranıyor.
- Vergi dairesi değişince otomatik bilinen adres sorgusu da tetikleniyor.
- Boş sonuçta panelde ham cevaptan kısa önizleme gösteriliyor; böylece hata/boş cevap daha kolay görülür.
