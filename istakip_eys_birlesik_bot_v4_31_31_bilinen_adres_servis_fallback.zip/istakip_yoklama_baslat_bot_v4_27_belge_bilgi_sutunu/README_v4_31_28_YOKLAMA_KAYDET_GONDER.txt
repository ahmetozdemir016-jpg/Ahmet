v4.31.28 Yoklama Kaydet/Gönder Komutları

Eklenenler:
- Tüm yoklama türleri için genel detay payload mapping eklendi.
- srvcYoklama_saveYoklama tüm türlerde yturu kodu ile gönderim yapacak şekilde genişletildi.
- Müdür onayına gönder: srvcYoklama_submitYoklamaToMudur
- Koordinatöre gönder: srvcYoklama_submitYoklamaDirectToKoor
- Kaydı sil: srvcYoklama_delYoklama
- Ekibe direkt gönder: srvcYoklama_checkYoklamaDirectToEkip / srvcYoklama_checkDirectToEkip + srvcYoklama_submitToDirectEkip
- Terk kontrolü: srvcRemoteCall_getMukellefTerkBilgisiX
- Tüzel açılış sermaye kontrolü: srvcRemoteCall_getSermayeMiktari
- Bilinen adres listesi ve adres belirleme için eksik runtime metodları eklendi.
- İl/ilçe merkezi, belediye adresi ve köy adresi combo zinciri bağlandı.

Not:
Bazı yoklama türlerinin EYS tarafındaki birebir alan isimleri farklı dönerse monitörde save response kontrol edilmeli. Bu sürüm, README’deki rYoklama.getData mantığına uygun genel anahtarlarla payload üretir.
