v4.31.21 Mükellef Grubu Otomatik

README 3 ve ekrandaki akışa göre düzeltildi.

Sorun:
- VKN yazıldığında sistem ekranında faaliyet konusu, işletme/şirket türü ve birçok alan otomatik doluyor.
- Bot panelinde Mükellef Grubu manuel kalıyordu.

Düzeltme:
- srvcRemoteCall_getSicilByVKN / TCKN cevabındaki şirket türü bilgisi okunur:
  - sirketTuru
  - sirketTuruAd
- Şirket türü gerçek mükellef ise Mükellef Grubu otomatik Gelir Vergisi Mükellefi seçilir.
- Limited, anonim, kooperatif, kollektif, komandit vb. şirket türlerinde Mükellef Grubu otomatik Kurumlar Vergisi Mükellefi seçilir.
- README 3 örneğindeki sirketTuru=6 / Limited Şirket için otomatik Kurumlar Vergisi Mükellefi seçilir.
- İş Takip listesinden satır seçilirse, unvana göre ön tahmin yapılır; sicil sorgusu tamamlanınca kesin bilgiyle güncellenir.

Not:
- Önceki ihbar bilgileri, yoklama temel bilgileri, işlem sütunu ve token düzeltmeleri korunmuştur.
