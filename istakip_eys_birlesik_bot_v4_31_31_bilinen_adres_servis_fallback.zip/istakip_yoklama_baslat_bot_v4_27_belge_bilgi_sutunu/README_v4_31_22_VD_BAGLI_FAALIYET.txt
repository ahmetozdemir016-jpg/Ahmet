v4.31.22 VD’ye Bağlı Faaliyet

Eklenenler:
- Yoklama Giriş > Mükellef Bilgileri bölümüne faaliyet türü seçimi eklendi:
  - Merkeze Bağlı Faaliyet
  - VD’ye Bağlı Faaliyet
- Varsayılan Merkeze Bağlı Faaliyet olarak gelir.
- VD’ye Bağlı Faaliyet seçilirse “Faaliyet Konusu İçin VD Seçiniz” alanı aktif olur.
- VKN sorgusundan sonra srvcRemoteCall_getVDsOfVKN ile VD listesi çekilir.
- VD seçilince faaliyet konusu yeniden yüklenir.
- Faaliyet konusu artık select olarak gösterilir; seçilen değer payload’a eklenir.

Payload’a eklenen/güçlendirilen alanlar:
- faaliyetKonusu
- faaliyetKodu
- faaliyetTuru
- faaliyetVdKodu
- faaliyetVdText

Not:
- Merkeze bağlı faaliyet eski otomatik çalışma mantığını korur.
- Mükellef Grubu otomatik, ihbar bilgileri, temel bilgiler, işlem sütunu ve token düzeltmeleri korunmuştur.
