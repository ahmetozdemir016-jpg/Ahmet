v4.31.18 İşlem Sütunu Aç/Kapat

Değişiklik:
- Ana modül İşleri Tara listesindeki İşTakip hücresine mouse ile gelince açılan akış seçenekleri kaldırıldı.
- İşTakip sütunundan önce yeni “İşlem” sütunu eklendi.
- İşlem sütunundaki ⋮ butonuna tıklayınca seçenekler açılır.
- Aynı ⋮ butonuna tekrar tıklayınca seçenekler kapanır.
- Menü seçeneklerinin içeriği aynen korundu:
  - Memura ata / Yoklamaya sevk vb. gerçek akış seçenekleri
  - Önizle / bilgi fallback seçenekleri

Not:
- EYS modülü ve token düzeltmesine dokunulmadı.
- Sadece ana modül tablo etkileşimi değiştirildi.
