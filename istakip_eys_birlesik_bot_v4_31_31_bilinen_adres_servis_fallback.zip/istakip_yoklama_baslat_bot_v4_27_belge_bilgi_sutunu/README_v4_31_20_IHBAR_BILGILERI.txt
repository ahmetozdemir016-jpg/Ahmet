v4.31.20 İhbar Bilgileri

Eklenenler:
- Yoklama Giriş > Mükellef Bilgileri bölümüne İhbara Dayalı Yoklama alanı eklendi.
- Kutucuk işaretlenince İhbar Kaynağı ve İhbarın Tarih/Sayı Bilgisi aktif olur.
- İhbar Kaynağı seçenekleri:
  - VİMER
  - BİMER
  - CİMER
  - DİĞER
- İhbarın Tarih/Sayı Bilgisi açıklama alanı payload'a dahil edilir.

Payload'a eklenen alanlar:
- ihbaraDayali
- ihbarKaynak
- ihbarKaynakText
- ihbarTarihSayiBilgisi

Not:
- Yoklama Temel Bilgileri bölümü korunmuştur.
- Ana modül İşlem sütunu düzeltmesi korunmuştur.
- İş Takip/EYS token ayrımı düzeltmesi korunmuştur.
