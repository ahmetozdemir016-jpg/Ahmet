v4.31.31 Bilinen Adres / Önceki Yoklama Düzeltmesi

Düzeltmeler:
- Bilinen adres sorgusunda EYS'in döndürdüğü “Servis Hatası” için fresh session/BF yükleme zorunlu yapıldı.
- srvcRemoteCall_getVdAdresleri için birkaç güvenli payload varyasyonu deneniyor:
  1) vkn + vdkodu + sessionData
  2) vkn + vdKodu + sessionData
  3) vkn + vdkodu + token + sessionData
- Boş/servis hatalı cevapta panel artık son denenen payload tipini ve kısa cevabı gösteriyor.
- Önceki yoklama listesinde ykodu alanı farklı adla gelirse daha geniş anahtarlarla ve metin içi regex ile yakalanıyor.
- Yoklama kodu gerçekten yoksa “Yoklamayı Aç” butonu yerine pasif “Kod Yok” gösteriliyor.
- Bilinen adres VD change eventindeki çift tetikleme azaltıldı.
