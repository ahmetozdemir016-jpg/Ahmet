EVDB Emanet Excel Chrome Eklentisi v1.0
- Emanet Türü seçimi koordinat/tıklama ve son çare değer yazma ile güçlendirildi.
- Bot sadece eklenti ikonuna basınca açılır.
