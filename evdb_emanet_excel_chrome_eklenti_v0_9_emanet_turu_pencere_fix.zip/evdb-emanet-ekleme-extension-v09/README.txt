EVDB Emanet Excel Aktarım Botu v0.9

Düzeltmeler:
- Pencere artık otomatik açılmaz; Chrome eklenti ikonuna tıklayınca aç/kapat yapılır.
- Emanet Türü açılır listesinden 39 Diğer Çeşitli Emanetler seçimi güçlendirildi.
- Belge No, Tutar ve Tarih alanları v0.8 mantığıyla metin kutusu olarak doldurulur.

Kurulum: chrome://extensions > Geliştirici modu > Paketlenmemiş öğe yükle.
