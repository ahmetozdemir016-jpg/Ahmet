/* Minimal XLSX reader for simple .xlsx worksheets. No external library. */
(function () {
  const enc = new TextEncoder();
  const dec = new TextDecoder('utf-8');

  function u16(a, o) { return a[o] | (a[o + 1] << 8); }
  function u32(a, o) { return (a[o] | (a[o + 1] << 8) | (a[o + 2] << 16) | (a[o + 3] << 24)) >>> 0; }

  async function inflateRaw(bytes) {
    if (typeof DecompressionStream === 'undefined') throw new Error('Chrome DecompressionStream desteklenmiyor.');
    try {
      const ds = new DecompressionStream('deflate-raw');
      const stream = new Blob([bytes]).stream().pipeThrough(ds);
      return new Uint8Array(await new Response(stream).arrayBuffer());
    } catch (e) {
      const ds = new DecompressionStream('deflate');
      const stream = new Blob([bytes]).stream().pipeThrough(ds);
      return new Uint8Array(await new Response(stream).arrayBuffer());
    }
  }

  async function unzip(arrayBuffer) {
    const a = new Uint8Array(arrayBuffer);
    let eocd = -1;
    for (let i = a.length - 22; i >= Math.max(0, a.length - 66000); i--) {
      if (u32(a, i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('XLSX/ZIP son kayıt bulunamadı.');
    const entries = u16(a, eocd + 10);
    const cdOffset = u32(a, eocd + 16);
    const files = {};
    let p = cdOffset;
    for (let i = 0; i < entries; i++) {
      if (u32(a, p) !== 0x02014b50) throw new Error('ZIP central directory okunamadı.');
      const method = u16(a, p + 10);
      const compSize = u32(a, p + 20);
      const uncompSize = u32(a, p + 24);
      const nameLen = u16(a, p + 28);
      const extraLen = u16(a, p + 30);
      const commentLen = u16(a, p + 32);
      const localOffset = u32(a, p + 42);
      const name = dec.decode(a.slice(p + 46, p + 46 + nameLen));
      let lp = localOffset;
      if (u32(a, lp) !== 0x04034b50) throw new Error('ZIP local header okunamadı: ' + name);
      const lfName = u16(a, lp + 26);
      const lfExtra = u16(a, lp + 28);
      const dataStart = lp + 30 + lfName + lfExtra;
      const comp = a.slice(dataStart, dataStart + compSize);
      let data;
      if (method === 0) data = comp;
      else if (method === 8) data = await inflateRaw(comp);
      else throw new Error('Desteklenmeyen ZIP sıkıştırma metodu: ' + method);
      files[name] = { bytes: data, text: () => dec.decode(data), size: uncompSize };
      p += 46 + nameLen + extraLen + commentLen;
    }
    return files;
  }

  function xml(text) { return new DOMParser().parseFromString(text, 'application/xml'); }
  function textContent(el) { return el ? (el.textContent || '') : ''; }
  function relsById(files, path) {
    const out = {};
    if (!files[path]) return out;
    const doc = xml(files[path].text());
    [...doc.getElementsByTagName('Relationship')].forEach(r => {
      out[r.getAttribute('Id')] = r.getAttribute('Target');
    });
    return out;
  }
  function normPath(base, target) {
    if (target.startsWith('/')) return target.slice(1);
    const parts = (base.split('/').slice(0, -1).join('/') + '/' + target).split('/');
    const stack = [];
    for (const p of parts) {
      if (!p || p === '.') continue;
      if (p === '..') stack.pop(); else stack.push(p);
    }
    return stack.join('/');
  }
  function colIndex(ref) {
    const m = String(ref || '').match(/[A-Z]+/i);
    if (!m) return 0;
    let n = 0;
    for (const ch of m[0].toUpperCase()) n = n * 26 + ch.charCodeAt(0) - 64;
    return n - 1;
  }
  function readSharedStrings(files) {
    const ss = [];
    if (!files['xl/sharedStrings.xml']) return ss;
    const doc = xml(files['xl/sharedStrings.xml'].text());
    [...doc.getElementsByTagName('si')].forEach(si => {
      const ts = [...si.getElementsByTagName('t')].map(t => t.textContent || '').join('');
      ss.push(ts);
    });
    return ss;
  }
  function cellValue(c, sharedStrings) {
    const t = c.getAttribute('t');
    if (t === 'inlineStr') return textContent(c.getElementsByTagName('t')[0]);
    const v = textContent(c.getElementsByTagName('v')[0]);
    if (t === 's') return sharedStrings[Number(v)] ?? '';
    if (t === 'b') return v === '1' ? 'TRUE' : 'FALSE';
    return v;
  }
  function rowsFromSheetXml(sheetText, sharedStrings) {
    const doc = xml(sheetText);
    const rows = [];
    [...doc.getElementsByTagName('row')].forEach(row => {
      const arr = [];
      [...row.getElementsByTagName('c')].forEach(c => {
        arr[colIndex(c.getAttribute('r'))] = cellValue(c, sharedStrings);
      });
      rows.push(arr.map(v => v == null ? '' : v));
    });
    if (!rows.length) return [];
    const headers = rows[0].map(h => String(h || '').trim());
    return rows.slice(1).map((r, idx) => {
      const o = { __rownum: idx + 2 };
      headers.forEach((h, i) => { if (h) o[h] = r[i] == null ? '' : String(r[i]).trim(); });
      return o;
    });
  }
  async function readXlsx(file, wantedSheetName) {
    const files = await unzip(await file.arrayBuffer());
    const wbPath = 'xl/workbook.xml';
    if (!files[wbPath]) throw new Error('xl/workbook.xml bulunamadı.');
    const wb = xml(files[wbPath].text());
    const wbRels = relsById(files, 'xl/_rels/workbook.xml.rels');
    const sheets = [...wb.getElementsByTagName('sheet')].map(s => ({
      name: s.getAttribute('name'),
      rid: s.getAttribute('r:id') || s.getAttribute('id')
    }));
    const sheet = sheets.find(s => s.name === wantedSheetName) || sheets[0];
    if (!sheet) throw new Error('Excel sayfası bulunamadı.');
    const target = wbRels[sheet.rid];
    if (!target) throw new Error('Sayfa ilişki kaydı bulunamadı: ' + sheet.name);
    const sheetPath = normPath(wbPath, target);
    if (!files[sheetPath]) throw new Error('Sayfa XML bulunamadı: ' + sheetPath);
    return { sheetName: sheet.name, rows: rowsFromSheetXml(files[sheetPath].text(), readSharedStrings(files)), sheets: sheets.map(s => s.name) };
  }
  window.XLSXLite = { readXlsx };
})();
