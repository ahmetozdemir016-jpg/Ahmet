chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'EVDB_EMANET_TOGGLE_PANEL' });
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['xlsx-lite.js', 'content.js'] });
      await chrome.tabs.sendMessage(tab.id, { type: 'EVDB_EMANET_TOGGLE_PANEL' });
    } catch (_) {}
  }
});
