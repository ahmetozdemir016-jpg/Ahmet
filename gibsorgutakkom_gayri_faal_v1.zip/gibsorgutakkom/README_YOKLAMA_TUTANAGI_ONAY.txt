YOKLAMA TUTANAĞI DÜZENLENMİŞ – İŞLEM BEKLEYEN YOKLAMALAR (diger/yoklama-tutanagi-onay.html)

Ana ekrandaki "Yoklama Tutanağı – İşlem Bekleyen Yoklamalar (toplu)" düğmesi açar. Denetim Tutanağı ekranının
aynısıdır; farklar: Belge İhlal sütunu yok, tarih aralığı var, Türü/Servis kodları adla gösterilir.

Servisler (HAR 23.09.2026 + İş Takip/EYS Bot):
- Liste: srvcDashboard_getMudurIslemlerYIslemBekleyen {birim, bastar, bittar (yyyymmdd), sessionData}
  Tek cevapta tüm liste (örnekte 677 satır). Satır kimliği ykodu.
- İşlem Yapıldı: srvcYoklama_islemYapildiYoklamaSonuc {ykodlari:[ykodu], durum:'80', islem:'işlem', sessionData}
- Arşive Kaldır: srvcArchive_archiveYoklama {ykodlari:[ykodu], sessionData}
  Her ikisi de KEYS akışındaki gibi satır satır (tek ykodu) gönderilir.
- Sonuç: GET edenetis/getSonuc?yKodu=<ykodu>
- Ek:    GET edenetis/getSonuc?yKoduEk=<ykodu>  (denetimdeki dKoduEk'e benzetilerek; doğrulanmadı)
- İade servisi bu ekran için henüz bilinmiyor (HAR'da yok) — eklenmedi.

Sütunlar: VKN, TCKN, Ünvan, Türü, Başlama/Bırakma, İlk İşlem, Son İşlem, İhbar, Başvuru Yapan, Servis, Memur Kodu,
Y.Kodu, Ekip Kodu, YM Adı, Açıklama, Adres, Adres No, Tespit Edilen Hususlar (yoklama fişi PDF'inden, PDF Okuyucu uzantısı gerekir).
Filtreler: Açıklama (liste/içerir), Türü, Servis, VKN aralığı, arama. Genişlik/hizalama/çıktı ayarları Denetim ekranından
bağımsız saklanır (takkom_yoklama_*).

v1.1: Başlama/Bırakma, İlk İşlem, Son İşlem, İhbar, Başvuru Yapan, Memur Kodu, Ekip Kodu, YM Adı, Adres No sütunları
varsayılan olarak gizli; 'Sütunlar ▾' menüsünden işaretlenenler listeye gelir (seçim saklanır). Excel ve çıktı yalnızca
görünen sütunları içerir.

v1.2: Tespit Edilen Hususlar sütunu: fişte 'TESPİT EDİLEN DİĞER HUSUSLAR' varsa o metin, 'GÖREV SONLANDIRMA BİLGİLERİ' varsa
Ana Neden / İkinci Neden / Açıklama; ikisi de varsa ikisi birlikte (önce hususlar, altında görev sonlandırma) yazılır.
Önbellek sürümü yükseltildi: daha önce okunan fişler 'Tespit Edilen Hususları Getir' ile otomatik yeniden okunur.

v1.3: Tek düğme 'Seçilenleri İşlem Yapıldı + Arşive Kaldır': her yoklama için satır satır önce srvcYoklama_islemYapildiYoklamaSonuc,
başarılıysa hemen srvcArchive_archiveYoklama gönderilir. İşlem yapılıp arşivlenemeyen satırlar kırmızı ve ayrı sayılır.
VKN aralığı kutuları (bu ekran ve Denetim Tutanağı ekranı) en fazla 10 rakam kabul eder; harf/fazla hane silinir.

v1.4: Tarih aralığı her açılışta KEYS ile aynı şekilde bugün ve 180 gün öncesi (HAR: bastar 20260327, bittar 20260923);
değiştirilebilir ama saklanmaz. Liste gelince KEYS özet servisi (srvcDashboard_getMudurIslemler → yislembekleyen) çağrılır ve
'KEYS özeti: X | Listelenen: Y' satırı gösterilir (eşleşiyorsa yeşil, farklıysa sarı).

v1.5: Eski sürümün sakladığı başlangıç tarihi açılışta silinir (artık hiç saklanmaz). Tarihin yanında 'Son 6 ay (KEYS varsayılanı)'
düğmesi; tarih varsayılandan farklıysa kutular sarı ve '⚠ KEYS varsayılanından farklı tarih' uyarısı görünür.
