EVDB Emanet Excel Chrome Eklentisi v2.8

Bu sürüm v2.7 akışını korur.

Yeni eklenen davranış:
- TC No / Vergi No yazıldıktan sonra Ad/Soyad/Unvan bilgisi gelmezse bot birkaç kez boş alan tıklamasıyla sorguyu tetikler.
- Buna rağmen bilgi gelmezse Emanet Bilgilerini Temizle butonuna basar.
- Aynı Excel satırını bir kez daha dener.
- İkinci denemede de bilgi gelmezse kaydı durdurmaz; Ad/Soyad gelmeyen / sorgu sonuçsuz olarak sayar, Fiş No bilgisini panelde ve logda yazar, sonraki kayda geçer.

Korunan özellikler:
- Her başarılı Emanet Ekle + Evet sonrasında üstteki Emanet Bilgilerini Temizle yapılır.
- Ekran temizlenince sıradaki kayda geçer.
- Boş TC/VKN, hatalı kimlik, mükellef bulunamadı, emanette mevcut, çıkış/aktarım kayıtlarını Fiş No ile raporlayıp atlar.
- Başarılı kayıtları hatırlar ve aynı Excel tekrar seçildiğinde kaldığı yerden devam eder.

Kurulum:
1. Chrome > chrome://extensions açın.
2. Eski eklentiyi kaldırın.
3. Geliştirici modunu açın.
4. Paketlenmemiş öğe yükle seçin.
5. evdb-emanet-ekleme-extension-v28 klasörünü seçin.
