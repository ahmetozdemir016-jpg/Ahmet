ONAY YAPILACAK İŞLER (diger/onay-isleri.html)

Ana ekrandaki "Onay Yapılacak İşler" düğmesi açar. Üstteki "İş" listesinden onaylanacak iş seçilir; yeni işler ISLER tablosuna eklenir.

1) e-Defter Analizi – Ceza İşlemleri (müdür onayı)
   GİBİNTRANET › e-Defter Analizi-Yönetici Ekranı › İş Detayı: Onayda Bekleyen İşler
   Liste: gibintranet_server/dispatch edefterService_edefterKullaniciUstundekiMukListesiGetir
     {vdkodu, basVknTckn, bitVknTckn, basDonem, bitDonem, cezaNedeni:'-1', isDurumu:'-1', mudurMu:'1', isDetayi:'0', islemDurumu:'-1'}
     Tüm liste tek cevapta gelir (KEYS ekranda 10'arlı sayfalara böler).
   Onay: edefterService_edefterMudurOnay {oid, durum} → {durum:'4', sonuc:'basarili', onayTarihi}. Satır satır, bekleme süresiyle.
   Durum: 2 = ihbarname düzenlendi, 3 = ihbarname düzenlenmedi (açıklamalı), 4 = onaylandı.
   Süzgeçler: durum, kullanıcı, dayanak kodu, dosya türü, onay (onaylanmamış / bu oturumda onaylanan / hatalı), arama.
   Kullanıcı bazlı özet (tıklayınca süzer), sütun başlığına tıklayarak sıralama, Excel.

v1.2 (13.10.2026) – Yeni iş: "Sistemden silinmesi gereken eski nesil ÖKC (ÖKC Silme İşlemleri)"
1) Mükellef listesi üç yoldan: (a) Merkezi Denetim (GİBİNTRANET › YBS › VD Ön Kontrol): işlem grubu/adı ile
   vdOnKontrolSorgulama → rapor seçilince dosyaIndirS3 ile Excel indirilir ve okunur (gibintranet tokeni Bearer /
   X-Auth-Token olarak gönderilir; tarayıcı CORS engellerse uyarı verir); (b) .xlsx dosyası yükleme (VERGİ KİMLİK
   NUMARASI, T.C. KİMLİK NUMARASI, AD SOYAD/UNVAN, VERGİ DAİRESİ KODU sütunları); (varsayılan işlem grubu 12 – ÖKC İşlemleri, işlem adı 12.01 – Aktif Eski Nesil ÖKC'si Olan Mükelleflerden Kayıt Silme İşlemleri Yapılmayanların Listesi); (c) VKN yapıştırma (unvan/VD
   sicilService_mukellefTcknVknBagliVDGetir ile tamamlanır). Aynı VKN bir kez listelenir.
2) "Eskiden Sorgula": her VKN için odmKaydediciCihazService_odmKaydediciCihazEskidenSorgulama {vkn, vdkodu};
   bulunan cihazlar (marka, model, levha, sicil, fatura, teslim) satır satır listelenir ve seçili gelir.
3) "Seçili Cihazları Sil": onay sorusundan sonra her cihaz için odmKaydediciCihazService_odmKaydediciCihazSil
   {input:{eoid, oid:''}} ("Cihaz başarıyla silindi." beklenir); ardından ilgili mükellef tekrar sorgulanarak
   doğrulanır. Silinenler listede yeşil kalır; Durdur, bekleme süresi, süzgeç ve Excel çıktısı vardır.
   Sayfa ?is=okc ile doğrudan bu işle açılır.
v1.2.1 – "Merkezi Denetimden Çek (en yeni rapor)": tek tıkla raporlar sorgulanır, en yeni tarihli rapor indirilip
  listeye yüklenir. İstekler TAKKOM PDF Okuyucu uzantısı v1.3 üzerinden gider (CORS engeli yok); uzantı yoksa doğrudan
  fetch denenir, o da engellenirse Excel yükleme yolu önerilir. Uzantı güncellemesi gerekir: eklentiler/takkom_pdf_okuyucu_v1
  (chrome://extensions › Yenile).
