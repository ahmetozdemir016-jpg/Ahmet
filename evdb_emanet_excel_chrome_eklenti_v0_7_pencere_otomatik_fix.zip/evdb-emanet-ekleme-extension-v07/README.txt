EVDB Emanet Excel Aktarım Botu v0.7

Düzeltmeler:
- Bot penceresinin EVDB sayfasında otomatik görünmesi güçlendirildi.
- keysggm / GIB Portal / Emanet MIF ekranlarında sayfa yüklenmesi gecikirse tekrar deneme eklendi.
- iframe/alt frame ihtimaline karşı all_frames aktif edildi.

Kurulum:
1) Eski eklentiyi kaldırın.
2) chrome://extensions > Geliştirici modu.
3) Paketlenmemiş öğe yükle > evdb-emanet-ekleme-extension-v07 klasörünü seçin.
4) EVDB sayfasını Ctrl+R ile yenileyin.
5) Pencere görünmezse sağ üstteki eklenti ikonuna tıklayın.
