EVDB Emanet Excel Botu v1.6

Düzeltme: İlk emanet eklendikten sonra ikinci TC/VKN sorgusunun çalışması için satır geçiş bekleme, Emanet Bilgilerini Temizle ve kullanıcı gibi yazma eklendi.

Kurulum: chrome://extensions > Geliştirici modu > Paketlenmemiş öğe yükle > bu klasörü seç.
