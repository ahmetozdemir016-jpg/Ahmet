v4.31.10 — v4.31.2 Stabil Taban + EYS Varsayılan Açılış

Bu sürüm v4.31.2 düzgün çalışan panel tabanı üzerinden hazırlandı.

Alınmayan değişiklikler:
- v4.31.5 / v4.31.6 / v4.31.7 / v4.31.9 panel taşıma/tamir kodları bu sürüme alınmadı.
- Ana panel düzenine yeni onarım CSS'i eklenmedi.

Yapılan küçük düzeltmeler:
1. Bugün butonu:
   fmtDateYYYYMMDD is not defined hatası giderildi.
   eysTodayYYYYMMDD() kullanılır.

2. CFG:
   CFG is not defined hatası için panel id erişimleri güvenli hale getirildi.

3. Açılış:
   Panel açılınca EYS Modülü sekmesi varsayılan olarak açılır.
   Ana Modül sekmesine üstten geçilebilir.
