Bu temiz sürümde eski VKN filtre denemeleri kaldırıldı.
VKN Başlangıç / VKN Bitiş yalnızca işler tablosunun üstünde yer alır.
İşleri Tara sonrası oluşan listede, İşTakip hücresindeki 10 haneli VKN'ye göre süzme yapılır.
Eski üst form satırları gizlenir; token ekranları görünür kalır.
