// v4.27.10: son preview linkinde de ilk giriş tokeni kullanılacak şekilde hazırlandı.
(() => {
  'use strict';
  if (window.__istakipYoklamaBotLoadedV419) return;
  window.__istakipYoklamaBotLoadedV419 = true;

  const CFG = {
    PANEL_ID: 'istakip-yoklama-bot-panel-v419',
    STYLE_ID: 'istakip-yoklama-bot-style-v419',
    STORAGE_KEY: 'istakip_yoklama_bot_v419_settings',
    DISCOVERY_KEY: 'istakip_yoklama_bot_v419_discovery',
    DISPATCH_URL: `${location.origin}/istakip_server/dispatch`,
    KEYS_DISPATCH_URL: `${location.origin}/keyss/external_dispatch`,
    FLEXPAPER_URL: `${location.origin}/keyss/flexpaper/pdf/`,
    DEFAULT_LIMIT: 50,
    COMMANDS: {
      LIST: 'isTakipSorgulamalarServices_isleriSorgula',
      NEXT_STEPS: 'akisIslemleri_isTakipSonrakiAdimlariBul',
      SAVE_STEP: 'akisIslemleri_akisYeniAdimKaydet',
      ACTIVE_COUNTS: 'isTakipSorgulamalarServices_aktifIsSayilariniBul',
      USER_SESSION: 'userSessionService_getUserSessionInfo'
    }
  };


  const PAGE_HOOK_EVENT = '__ISTAKIP_BOT_V4_DISCOVERY__';

  function wirePageMessages() {
    if (window.__istakipV419MsgWired) return;
    window.__istakipV419MsgWired = true;
    window.addEventListener('message', ev => {
      try {
        if (ev.source !== window) return;
        const d = ev.data;
        if (!d || d.type !== PAGE_HOOK_EVENT) return;
                if (d.cmd) state.discovery.lastCmd = d.cmd;
        const src = (d.source || 'page-hook') + (d.cmd ? `:${d.cmd}` : '');
        const rawModule = d.moduleName || d.payload?.moduleName || d.payload?.modulAdi || d.payload?.module || '';
        const moduleName = normalizeModuleName(rawModule);
        if (moduleName) setPendingModule(moduleName, src);

        if (/assos-login-response/i.test(src)) {
          if (d.token) logBaseDiscovery('token', d.token, src);
          if (d.userId) logBaseDiscovery('userId', d.userId, src);
          if (d.orgoid) logBaseDiscovery('orgoid', d.orgoid, src);
          if (state.discovery.pendingModule && d.token) {
            rememberModuleToken(state.discovery.pendingModule, d.token, src + ':pending-bound');
          }
        }

        if (d.token) logDiscovery('token', d.token, src);
        if (d.userId) logDiscovery('userId', d.userId, src);
        if (d.orgoid) logDiscovery('orgoid', d.orgoid, src);
        if (d.payload && typeof d.payload === 'object') learnFromObject(d.payload, d.source || 'page-hook:payload');
        persistDiscovery();
        renderDiscovery();
      } catch (_) {}
    });
  }

  function injectPageHook() {
    if (window.__istakipV419HookInjected) return;
    window.__istakipV419HookInjected = true;
    const root = document.documentElement || document.head || document.body;
    if (!root) return;
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('page_hook.js');
    script.dataset.evt = PAGE_HOOK_EVENT;
    script.onload = () => script.remove();
    root.appendChild(script);
  }

  const state = {
    jobs: [],
    eligibleJobs: [],
    running: false,
    stopRequested: false,
    discovery: {
      token: '',
      userId: '',
      orgoid: '',
      baseToken: '',
      baseUserId: '',
      baseOrgoid: '',
      baseUserLocked: false,
      baseOrgoidLocked: false,
      baseSource: { token: '', userId: '', orgoid: '' },
      pendingModule: '',
      tokensByModule: { gp: '', g: '', istakip: '', evdo: '', e: '' },
      tokenSourceByModule: { gp: '', g: '', istakip: '', evdo: '', e: '' },
      source: { token: '', userId: '', orgoid: '' },
      lastCmd: '',
      lastModuleName: '',
      lastUsedToken: '',
      lastUsedTokenSource: '',
      history: []
    },
    detailMap: {}
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = (sel, root = document) => root.querySelector(sel);

  function textOf(el) {
    return ((el?.innerText || el?.textContent || el?.value || '') + '').replace(/\s+/g, ' ').trim();
  }

  function safeCall(obj, fn) {
    try { return obj && typeof obj[fn] === 'function' ? obj[fn]() : undefined; }
    catch (_) { return undefined; }
  }

  function isGenericUserValue(v) {
    const s = String(v || '').trim().toLowerCase();
    return !s || s === 'g.i.b.' || s === 'gib' || s === 'g.i.b' || s === 'gelir idaresi başkanlığı';
  }

  function isMeaningfulUserValue(v) {
    return !!String(v || '').trim() && !isGenericUserValue(v);
  }

  function logBaseDiscovery(kind, value, source) {
    if (!value) return;
    const next = String(value).trim();
    if (!next) return;
    const keyMap = { token: 'baseToken', userId: 'baseUserId', orgoid: 'baseOrgoid' };
    const srcKey = kind;
    const valueKey = keyMap[kind];
    if (!valueKey) return;

    if (kind === 'userId') {
      const current = String(state.discovery.baseUserId || '').trim();
      const locked = !!state.discovery.baseUserLocked;
      if (locked && current && current !== next) return;
      if (!current && isMeaningfulUserValue(next)) {
        state.discovery.baseUserId = next;
        state.discovery.baseSource[srcKey] = source;
        state.discovery.baseUserLocked = true;
        state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.userId <= ${next} (${source}) [locked]`);
        if (state.discovery.history.length > 60) state.discovery.history.shift();
        return;
      }
      if (current && isMeaningfulUserValue(current) && isGenericUserValue(next)) return;
    }

    if (kind === 'orgoid') {
      const current = String(state.discovery.baseOrgoid || '').trim();
      const locked = !!state.discovery.baseOrgoidLocked;
      if (locked && current && current !== next) return;
      if (!current && next) {
        state.discovery.baseOrgoid = next;
        state.discovery.baseSource[srcKey] = source;
        state.discovery.baseOrgoidLocked = true;
        state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.orgoid <= ${next} (${source}) [locked]`);
        if (state.discovery.history.length > 60) state.discovery.history.shift();
        return;
      }
    }

    if (state.discovery[valueKey] && state.discovery[valueKey] === next && state.discovery.baseSource[srcKey] == source) return;
    state.discovery[valueKey] = next;
    state.discovery.baseSource[srcKey] = source;
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.${kind} <= ${next} (${source})`);
    if (state.discovery.history.length > 60) state.discovery.history.shift();
  }

  function setPendingModule(moduleName, source='') {
    const m = normalizeModuleName(moduleName);
    if (!m) return;
    state.discovery.pendingModule = m;
    state.discovery.lastModuleName = m;
    if (source) {
      state.discovery.history.push(`[${new Date().toLocaleTimeString()}] pendingModule <= ${m} (${source})`);
      if (state.discovery.history.length > 60) state.discovery.history.shift();
    }
    persistDiscovery();
    renderDiscovery();
  }

  function normalizeModuleName(v) {
    const s = String(v || '').trim().toLowerCase();
    if (!s) return '';
    if (['gp', 'g', 'istakip', 'evdo', 'e'].includes(s)) return s;
    if (s.includes('istakip')) return 'istakip';
    if (s.includes('evdo') || s.includes('evdb')) return 'evdo';
    if (s === 'eys' || s.includes('edenetis') || s === 'e') return 'e';
    if (s.includes('gibintranet') || s == 'g') return 'g';
    if (s.includes('gp')) return 'gp';
    return s;
  }

  function moduleTokenPriority(moduleName, source) {
    const m = normalizeModuleName(moduleName);
    const s = String(source || '').toLowerCase();
    if (s.includes('pending-bound')) return 300;
    if (m === 'istakip') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:istakip')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'evdo') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:evdo')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'e') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:e')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'g' || m === 'gp') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 170;
      if (s.includes('side.get_service_def_list')) return 160;
      if (s.includes('assos-login-response')) return 150;
      if (s.includes('cssession.gettoken')) return 120;
    }
    return 50;
  }

  function rememberModuleToken(moduleName, token, source) {
    const m = normalizeModuleName(moduleName);
    const t = String(token || '').trim();
    if (!m || !t) return;
    const cur = state.discovery.tokensByModule[m] || '';
    const curSrc = state.discovery.tokenSourceByModule[m] || '';
    if (!cur || moduleTokenPriority(m, source) >= moduleTokenPriority(m, curSrc)) {
      state.discovery.tokensByModule[m] = t;
      state.discovery.tokenSourceByModule[m] = source;
      state.discovery.lastModuleName = m;
      state.discovery.history.push(`[${new Date().toLocaleTimeString()}] tokenByModule.${m} <= ${t} (${source})`);
      if (state.discovery.history.length > 40) state.discovery.history.shift();
      if (m === 'istakip') {
        state.discovery.token = t;
        state.discovery.source.token = `tokenByModule.${m} <= ${source}`;
      }
      persistDiscovery();
      renderDiscovery();
    }
  }

  function resolveTokenForModule(moduleName) {
    const m = normalizeModuleName(moduleName);
    if (m && state.discovery.tokensByModule[m]) return state.discovery.tokensByModule[m];
    const cssToken = safeGetCssToken(m);
    if (cssToken) return cssToken;
    if (!m) return state.discovery.token || getTokenFromUrl() || '';
    return '';
  }

  function sourcePriority(kind, source) {
    const s = String(source || '').toLowerCase();
    if (kind === 'token') {
      if (s.includes('module-bound')) return 260;
      if (s.includes('assos-login-response')) return 250;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 190;
      if (s.includes('assos-login') && s.includes('form-token')) return 130;
      if (s.includes('main.jsp')) return 100;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 90;
      if (s.includes('cssession.gettoken')) return 50;
      if (s.includes('url:token')) return 10;
    }
    if (kind === 'orgoid') {
      if (s.includes('akisislemleri_istakipsonrakiadimlaribul')) return 200;
      if (s.includes('akisislemleri_akisyeniadimkaydet')) return 190;
      if (s.includes('usersessionservice_getusersessioninfo')) return 170;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 150;
      if (s.includes('page-xhr') || s.includes('page-fetch')) return 70;
      if (s.includes('cssession.getorgoid')) return 50;
    }
    if (kind === 'userId') {
      if (s.includes('assos-login-response')) return 140;
      if (s.includes('usersessionservice_getusersessioninfo')) return 130;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 110;
      if (s.includes('page-xhr') || s.includes('page-fetch')) return 80;
      if (s.includes('cssession.getuserid')) return 60;
    }
    return 20;
  }

  function shouldOverwrite(kind, nextValue, nextSource) {
    const current = String(state.discovery[kind] || '').trim();
    const currentSource = state.discovery.source[kind] || '';
    if (!current) return true;
    if (current === String(nextValue).trim()) return sourcePriority(kind, nextSource) >= sourcePriority(kind, currentSource);
    return sourcePriority(kind, nextSource) >= sourcePriority(kind, currentSource);
  }

  function logDiscovery(kind, value, source) {
    if (!value) return;
    const next = String(value).trim();
    if (!next) return;
    if (!shouldOverwrite(kind, next, source)) return;
    const current = state.discovery[kind];
    if (current === next && state.discovery.source[kind] === source) return;
    state.discovery[kind] = next;
    state.discovery.source[kind] = source;
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] ${kind} <= ${next} (${source})`);
    if (state.discovery.history.length > 30) state.discovery.history.shift();
    persistDiscovery();
    renderDiscovery();
  }

  function persistDiscovery() {
    try {
      chrome.storage.local.set({ [CFG.DISCOVERY_KEY]: state.discovery });
    } catch (_) {}
  }

  function restoreDiscovery(cb) {
    try {
      chrome.storage.local.get([CFG.DISCOVERY_KEY], out => {
        const d = out?.[CFG.DISCOVERY_KEY];
        if (d && typeof d === 'object') {
          state.discovery = {
            token: d.token || '',
            userId: d.userId || '',
            orgoid: d.orgoid || '',
            baseToken: d.baseToken || '',
            baseUserId: d.baseUserId || '',
            baseOrgoid: d.baseOrgoid || '',
            baseUserLocked: !!d.baseUserLocked,
            baseOrgoidLocked: !!d.baseOrgoidLocked,
            baseSource: d.baseSource || { token: '', userId: '', orgoid: '' },
            pendingModule: d.pendingModule || '',
            tokensByModule: d.tokensByModule || { gp: '', g: '', istakip: '', evdo: '', e: '' },
            tokenSourceByModule: d.tokenSourceByModule || { gp: '', g: '', istakip: '', evdo: '', e: '' },
            source: d.source || { token: '', userId: '', orgoid: '' },
            lastCmd: d.lastCmd || '',
            lastModuleName: d.lastModuleName || '',
            lastUsedToken: d.lastUsedToken || '',
            lastUsedTokenSource: d.lastUsedTokenSource || '',
            history: Array.isArray(d.history) ? d.history.slice(-50) : []
          };
        }
        cb?.();
      });
    } catch (_) { cb?.(); }
  }


  function safeGetCssToken(moduleName) {
    try {
      const css = window.CSSession || {};
      if (typeof css.getToken === 'function') {
        return moduleName ? css.getToken(moduleName) : css.getToken();
      }
      return css.token || '';
    } catch (_) { return ''; }
  }

  function deepScan(obj, out = {}, depth = 0, seen = new WeakSet()) {
    try {
      if (!obj || typeof obj !== 'object' || depth > 6) return out;
      if (seen.has(obj)) return out;
      seen.add(obj);
      const pick = (key, val) => {
        if (val === undefined || val === null || val === '') return;
        const k = String(key || '').toLowerCase();
        const v = typeof val === 'string' ? val.trim() : val;
        if (!v) return;
        if (!out.token && k === 'token') out.token = v;
        if (!out.orgoid && k === 'orgoid') out.orgoid = v;
        if (!out.userId && /^(userid|kullanicikodu|atamayapankullaniciuserid|islemyapanuserid)$/i.test(String(key))) out.userId = v;
        if (!out.moduleName && /^(moduladi|modulename|module|modul)$/i.test(String(key))) out.moduleName = v;
      };
      if (Array.isArray(obj)) {
        obj.forEach(v => deepScan(v, out, depth + 1, seen));
        return out;
      }
      for (const [k, v] of Object.entries(obj)) {
        pick(k, v);
        if (typeof v === 'string') {
          const j = parseMaybeJson(v);
          if (j) deepScan(j, out, depth + 1, seen);
        } else if (v && typeof v === 'object') {
          deepScan(v, out, depth + 1, seen);
        }
      }
    } catch (_) {}
    return out;
  }

  function getTokenFromUrl() {
    return new URLSearchParams(location.search).get('token') || '';
  }

  function learnFromObject(obj, source) {
    if (!obj || typeof obj !== 'object') return;
    const found = deepScan(obj, {});
    const maybeUser = found.userId;
    const maybeOrg = found.orgoid;
    const maybeToken = found.token;
    const moduleName = normalizeModuleName(found.moduleName || obj.moduleName || obj.modulAdi || obj.module || '');
    if (moduleName) state.discovery.lastModuleName = moduleName;
    if (maybeUser) logDiscovery('userId', maybeUser, source);
    if (maybeOrg) logDiscovery('orgoid', maybeOrg, source);
    if (maybeToken) {
      logDiscovery('token', maybeToken, source);
      if (moduleName) rememberModuleToken(moduleName, maybeToken, source);
      else if (/assos-login-response/i.test(source) && /istakip/i.test(location.href)) {
        rememberModuleToken('istakip', maybeToken, source + ':location-bound');
      }
    }
  }

  function learnFromStorageBag(source, bag) {
    if (!bag) return;
    try {
      for (let i = 0; i < bag.length; i++) {
        const k = bag.key(i);
        const v = bag.getItem(k);
        if (!v) continue;
        if (!state.discovery.token && /token/i.test(k) && String(v).length > 10) logDiscovery('token', v, `${source}:${k}`);
        if (!state.discovery.orgoid && /org.?oid/i.test(k) && String(v).trim()) logDiscovery('orgoid', v, `${source}:${k}`);
        if (!state.discovery.userId && /(user.?id|userid|kullanici)/i.test(k) && String(v).trim()) logDiscovery('userId', v, `${source}:${k}`);
        if ((v.startsWith('{') || v.startsWith('[')) && v.length < 50000) {
          try { learnFromObject(JSON.parse(v), `${source}:${k}`); } catch (_) {}
        }
      }
    } catch (_) {}
  }

  function discoverFromPage() {
    const css = window.CSSession || {};
    logBaseDiscovery('token', getTokenFromUrl(), 'url:token');
    logDiscovery('token', getTokenFromUrl(), 'url:token');
    logBaseDiscovery('token', safeGetCssToken('gp') || safeGetCssToken(), 'CSSession.getToken:base');
    logDiscovery('token', safeGetCssToken('istakip') || safeGetCssToken('gp') || safeGetCssToken(), 'CSSession.getToken');
    ['gp','g','istakip','evdo','e'].forEach(m => {
      const mt = safeGetCssToken(m);
      if (mt) rememberModuleToken(m, mt, `CSSession.getToken:${m}`);
    });
    const cssUser = safeCall(css, 'getUserId') || css.userId || css.userid || css.USERID || css.kullaniciKodu;
    const cssOrg = safeCall(css, 'getOrgOid') || css.orgOid || css.orgoid || window.orgOid || window.ORGOID;
    logBaseDiscovery('userId', cssUser, 'CSSession.getUserId:base');
    logBaseDiscovery('orgoid', cssOrg, 'CSSession.getOrgOid:base');
    logDiscovery('userId', cssUser, 'CSSession.getUserId');
    logDiscovery('orgoid', cssOrg, 'CSSession.getOrgOid');
    learnFromObject(window.userSession || window.session || window.__session || {}, 'window.session');
    learnFromStorageBag('localStorage', window.localStorage);
    learnFromStorageBag('sessionStorage', window.sessionStorage);
  }

  function parseMaybeJson(str) {
    if (!str || typeof str !== 'string') return null;
    const s = str.trim();
    if (!s || (s[0] !== '{' && s[0] !== '[')) return null;
    try { return JSON.parse(s); } catch { return null; }
  }

  function inspectPayload(cmd, payload, source) {
    if (cmd) state.discovery.lastCmd = cmd;
    if (!payload || typeof payload !== 'object') return;
    learnFromObject(payload, source + (cmd ? `:${cmd}` : ''));
    if (payload.jp && typeof payload.jp === 'string') {
      const parsed = parseMaybeJson(payload.jp);
      if (parsed) learnFromObject(parsed, `${source}:jp` + (cmd ? `:${cmd}` : ''));
    }
    if (payload.sorgulamaKriterleri) learnFromObject(payload.sorgulamaKriterleri, `${source}:sorgulamaKriterleri`);
  }

  function inspectBody(body, source) {
    if (!body) return;
    try {
      if (typeof body === 'string') {
        const usp = new URLSearchParams(body);
        if ([...usp.keys()].length) {
          const cmd = usp.get('cmd') || '';
          const token = usp.get('token') || '';
          const jpText = usp.get('jp') || '';
          if (token) logDiscovery('token', token, `${source}:form-token` + (cmd ? `:${cmd}` : ''));
          if (jpText) {
            const jp = parseMaybeJson(jpText);
            if (jp) inspectPayload(cmd, jp, `${source}:form-jp`);
          }
        } else {
          const parsed = parseMaybeJson(body);
          if (parsed) inspectPayload('', parsed, `${source}:json-body`);
        }
      } else if (body instanceof URLSearchParams) {
        inspectBody(body.toString(), source);
      } else if (typeof FormData !== 'undefined' && body instanceof FormData) {
        const data = {};
        for (const [k, v] of body.entries()) data[k] = v;
        inspectPayload(data.cmd || '', data, `${source}:formdata`);
      }
    } catch (_) {}
  }

  function patchNetwork() {
    if (window.__istakipDiscoveryPatched) return;
    window.__istakipDiscoveryPatched = true;

    const origFetch = window.fetch;
    if (origFetch) {
      window.fetch = async function(...args) {
        try {
          const [input, init] = args;
          const url = typeof input === 'string' ? input : input?.url || '';
          const body = init?.body || (typeof input !== 'string' ? input?.body : undefined);
          if (/dispatch|assos-login|index\.jsp/i.test(url)) inspectBody(body, `fetch:${url}`);
        } catch (_) {}
        const res = await origFetch.apply(this, args);
        try {
          const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
          if (/dispatch/i.test(url)) {
            const clone = res.clone();
            clone.text().then(txt => {
              const parsed = parseMaybeJson(txt);
              if (parsed) learnFromObject(parsed?.data || parsed, `fetch-response:${url}`);
            }).catch(() => {});
          }
        } catch (_) {}
        return res;
      };
    }

    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__it_url = url;
      this.__it_method = method;
      return origOpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(body) {
      try {
        if (/dispatch|assos-login|index\.jsp/i.test(this.__it_url || '')) inspectBody(body, `xhr:${this.__it_url}`);
        this.addEventListener('load', () => {
          try {
            if (/dispatch/i.test(this.__it_url || '')) {
              const parsed = parseMaybeJson(this.responseText);
              if (parsed) learnFromObject(parsed?.data || parsed, `xhr-response:${this.__it_url}`);
            }
          } catch (_) {}
        });
      } catch (_) {}
      return origSend.call(this, body);
    };
  }

  function getDiscovered(moduleName = 'istakip') {
    discoverFromPage();
    const m = normalizeModuleName(moduleName || 'istakip') || 'istakip';
    return {
      token: resolveTokenForModule(m),
      userId: state.discovery.baseUserId || state.discovery.userId || '',
      orgoid: state.discovery.baseOrgoid || state.discovery.orgoid || '',
      tokensByModule: Object.assign({}, state.discovery.tokensByModule),
      moduleName: m
    };
  }

  function makeCallId() {
    return `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
  }

  async function post(cmd, jp) {
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', makeCallId());
    const discovered = getDiscovered('istakip');
    const token = discovered.token;
    if (!token) {
      throw new Error(`İş Takip tokenı bulunamadı. pendingModule=${state.discovery.pendingModule || '-'} baseToken=${state.discovery.baseToken ? 'var' : 'yok'} istakipToken=${state.discovery.tokensByModule?.istakip ? 'var' : 'yok'}`);
    }
    p.append('token', token);
    state.discovery.lastUsedToken = token;
    state.discovery.lastUsedTokenSource = state.discovery.tokenSourceByModule?.istakip || 'resolveTokenForModule(istakip)';
    const jpText = JSON.stringify(jp || {});
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] outbound:${cmd} jp=${jpText}`);
    if (state.discovery.history.length > 80) state.discovery.history.shift();
    persistDiscovery();
    renderDiscovery();
    p.append('jp', jpText);

    const res = await fetch(CFG.DISPATCH_URL, {
      method: 'POST',
      body: p,
      credentials: 'include'
    });
    if (!res.ok) throw new Error(`Ağ hatası ${res.status} (${cmd})`);
    const txt = await res.text();
    try { return JSON.parse(txt); } catch { return txt; }
  }
  function injectStyle() {
    if (document.getElementById(CFG.STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = CFG.STYLE_ID;
    s.textContent = `
      #${CFG.PANEL_ID}{position:fixed;top:118px;right:16px;left:auto;width:min(920px, calc(100vw - 32px));max-width:calc(100vw - 32px);max-height:calc(100vh - 140px);min-width:540px;min-height:44px;overflow:hidden;resize:both;z-index:2147483647;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.38);font:12px/1.35 'Segoe UI',Arial,sans-serif}
      #${CFG.PANEL_ID} *{box-sizing:border-box}
      #${CFG.PANEL_ID} .hdr{display:flex;justify-content:space-between;align-items:center;padding:4px 8px;background:#0d1b31;border-bottom:1px solid #22324f;border-radius:14px 14px 0 0;cursor:move;user-select:none;touch-action:none;height:44px;box-sizing:border-box}
      #${CFG.PANEL_ID} .body{padding:10px;max-height:calc(94vh - 56px);overflow:auto}
      #${CFG.PANEL_ID} .row{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .row3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .row4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} label{display:block;font-size:11px;color:#9fb4d2;margin-bottom:2px}
      #${CFG.PANEL_ID} input,#${CFG.PANEL_ID} select{width:100%;padding:5px 7px;border-radius:7px;border:1px solid #314867;background:#081523;color:#eaf2ff}
      #${CFG.PANEL_ID} input[readonly]{background:#0d1524;color:#b9cae8}
      #${CFG.PANEL_ID} button{padding:9px 10px;border-radius:7px;border:0;cursor:pointer;font-weight:600}
      #${CFG.PANEL_ID} .btn-green{background:#39d98a;color:#032611}
      #${CFG.PANEL_ID} .btn-blue{background:#3478f6;color:#fff}
      #${CFG.PANEL_ID} .btn-violet{background:#8b5cf6;color:#fff}
      #${CFG.PANEL_ID} .btn-red{background:#dc4c4c;color:#fff}
      #${CFG.PANEL_ID} .btn-amber{background:#f59e0b;color:#111}
      #${CFG.PANEL_ID} .mini{width:28px;height:28px;padding:0;background:#132643;color:#fff;border:1px solid #38527a}
      #${CFG.PANEL_ID} .sub{font-size:11px;color:#95a8c4;margin:6px 0 10px}
      #${CFG.PANEL_ID} .log{height:82px;min-height:82px;max-height:82px;overflow:auto;background:#02060d;color:#9cff9c;font-family:ui-monospace,monospace;border:1px solid #1f2d42;padding:6px;border-radius:10px;resize:vertical}
      #${CFG.PANEL_ID} .disc{background:#091525;border:1px solid #233752;border-radius:10px;padding:8px;margin-bottom:8px}
      #${CFG.PANEL_ID} .kv{display:grid;grid-template-columns:110px 1fr;gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .muted{color:#8ca0bf}
      #${CFG.PANEL_ID} table{width:100%;border-collapse:collapse;margin-top:8px;font-size:11px}
      #${CFG.PANEL_ID} th,#${CFG.PANEL_ID} td{border-bottom:1px solid #1f2d42;padding:6px 4px;vertical-align:top;text-align:left}
      #${CFG.PANEL_ID} .eligible{color:#88ffb2;font-weight:700}
      #${CFG.PANEL_ID} .bad{color:#ff8f8f}
      #${CFG.PANEL_ID} .tblwrap{max-height:420px;overflow:auto;border:1px solid #1f2d42;border-radius:10px}
      #${CFG.PANEL_ID} .tiny{font-size:10px;color:#99a7c0}
      #${CFG.PANEL_ID} #it_tbl_filter_bar{position:sticky;top:0;z-index:7;background:#08111f;padding-bottom:6px}
      #${CFG.PANEL_ID} .tblwrap thead th{position:sticky;top:0;z-index:5;background:#0d1b31}
      #${CFG.PANEL_ID} .hide-above-buttons{display:none !important}
      #${CFG.PANEL_ID} .vkn-range-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0 8px 0}
      #${CFG.PANEL_ID} .vkn-range-row input{height:28px;min-height:28px;padding:4px 8px}
#${CFG.PANEL_ID} .disc{display:block !important}
      #${CFG.PANEL_ID} .tokcard{display:block !important}
      #${CFG.PANEL_ID} .tiny{font-size:10px;color:#99a7c0}
      #${CFG.PANEL_ID} #it_tbl_filter_bar{position:sticky;top:0;z-index:7;background:#08111f;padding-bottom:6px}
      #${CFG.PANEL_ID} .tblwrap thead th{position:sticky;top:0;z-index:5;background:#0d1b31}
      #${CFG.PANEL_ID} .hide-above-buttons{display:none !important}
      #${CFG.PANEL_ID} .vkn-range-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0 8px 0}
      #${CFG.PANEL_ID} .vkn-range-row input{height:28px;min-height:28px;padding:4px 8px}

      #${CFG.PANEL_ID} .tblwrap thead th{position:sticky;top:0;z-index:5;background:#0d1b31}
      #${CFG.PANEL_ID} .disc{padding:4px;margin-bottom:6px;max-height:120px;overflow:auto}
      #${CFG.PANEL_ID} .tokcard{margin:4px 0 !important;padding:4px !important;max-height:90px;overflow:auto}
      #${CFG.PANEL_ID} .sub{margin:4px 0 6px 0;font-size:11px}

      #it_preview_modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.58);z-index:2147483647;padding:20px}
      #it_preview_modal.open{display:flex}
      #it_preview_box{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:min(1280px,96vw);height:min(900px,92vh);min-width:520px;min-height:320px;background:#fff;border-radius:12px;overflow:hidden;resize:both;box-shadow:0 20px 50px rgba(0,0,0,.45);display:flex;flex-direction:column;border:1px solid #cfd8e3}
      #it_preview_head{height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;background:#0d1b31;color:#fff;border-bottom:1px solid #22324f;flex:0 0 auto;cursor:move;user-select:none}
      #it_preview_title{font:600 14px/1.2 'Segoe UI',Arial,sans-serif;padding-right:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #it_preview_actions{display:flex;gap:8px;align-items:center}
      #it_preview_actions .it-btn-mini{padding:7px 10px;border-radius:7px;border:1px solid #38527a;background:#132643;color:#fff;cursor:pointer;font:600 12px/1 'Segoe UI',Arial,sans-serif}
      #it_preview_frame{width:100%;height:100%;border:0;display:block;background:#eef3f8;flex:1 1 auto}
      #it_preview_msg{padding:16px;font:13px/1.5 'Segoe UI',Arial,sans-serif;color:#17212f;background:#fff;border-top:1px solid #e5ebf3;flex:0 0 auto}
    `;
    document.head.appendChild(s);
  }

  function createPanel() {
    const existing = document.getElementById(CFG.PANEL_ID);
    if (existing) return existing;
    const el = document.createElement('div');
    el.id = CFG.PANEL_ID;
    el.innerHTML = `
      <div class="hdr">
        <strong class="drag-title">İş Takip Yoklama Başlat Botu v4.27</strong>
        <div>
          <button class="mini" id="it_toggle" title="Gövdeyi aç/kapat">−</button>
          <button class="mini" id="it_panel_reset" title="Boyut ve konumu sıfırla">□</button>
          <button class="mini" id="it_close" style="color:#ff8f8f" title="Kapat">×</button>
        </div>
      </div>
      <div class="body" id="it_wrap">
        <div class="disc">
          <div class="vkn-range-row">
          <div><label>VKN Başlangıç</label><input id="it_vkn_start" placeholder="örn 0000000000"></div>
          <div><label>VKN Bitiş</label><input id="it_vkn_end" placeholder="örn 3000000000"></div>
        </div>
        <div class="row3" style="margin-bottom:6px">
            <div><label>Keşfedilen Kullanıcı</label><input id="it_user" readonly></div>
            <div><label>Keşfedilen OrgOid</label><input id="it_orgoid" readonly></div>
            <div><label>Keşfedilen Token</label><input id="it_token" readonly></div>
          </div>
          <div class="row3" style="margin-bottom:0">
            <div class="tiny" id="it_user_src"></div>
            <div class="tiny" id="it_org_src"></div>
            <div class="tiny" id="it_tok_src"></div>
          </div>
          <div class="tokcard" style="margin:8px 0">
            <div class="tokname">İlk Giriş Oturumu</div>
            <div class="tokval" id="it_base_tok">-</div>
            <div class="toksrc" id="it_base_tok_src">Token kaynağı: -</div>
            <div class="tokval" id="it_base_user">-</div>
            <div class="toksrc" id="it_base_user_src">Kullanıcı kaynağı: -</div>
            <div class="tokval" id="it_base_org">-</div>
            <div class="toksrc" id="it_base_org_src">OrgID kaynağı: -</div>
          </div>
          <div class="sub" id="it_used_tok">Kullanılan İş Takip tokenı: -</div>
          <div class="sub" id="it_used_tok_src">Kullanılan token kaynağı: -</div>
          <div class="row" style="margin-top:6px;margin-bottom:0">
            <button class="btn-violet" id="it_discover">XHR KEŞFİNİ YENİLE</button>
            <div class="tiny" id="it_last_cmd"></div>
          </div>
          <div class="tokgrid">
            <div class="tokcard"><div class="tokname">İş Takip (istakip)</div><div class="tokval" id="it_tok_istakip">-</div><div class="toksrc" id="it_toksrc_istakip">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">EVDB (evdo)</div><div class="tokval" id="it_tok_evdo">-</div><div class="toksrc" id="it_toksrc_evdo">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">EYS (e)</div><div class="tokval" id="it_tok_e">-</div><div class="toksrc" id="it_toksrc_e">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">GİB İntranet (g)</div><div class="tokval" id="it_tok_g">-</div><div class="toksrc" id="it_toksrc_g">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">Portal (gp)</div><div class="tokval" id="it_tok_gp">-</div><div class="toksrc" id="it_toksrc_gp">Kaynak: -</div></div>
          </div>
          <div class="tiny" style="margin-top:6px">Eklenti açılır açılmaz sayfa bağlamında XHR/fetch dinlenir. İlk tıkladığın işte giden sorgulardan orgoid, userId, akisOid ve cmd yakalanır.</div>
        </div>
        <div class="row4 hide-above-buttons">
          <div><label>Vergi No / TCKN / Ünvan</label><input id="it_filter" placeholder="Boş = hepsi"></div>
          <div><label>İş Takip No</label><input id="it_istakip" placeholder="İsteğe bağlı"></div>
          <div><label>İş Tipi</label><input id="it_istipi" value="5"></div>
          <div><label>Sonuç limiti</label><input id="it_limit" value="50"></div>
        </div>
        <div class="row4">
          <div><label>Uygun değil işleri sil</label><select id="it_atama_sil"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div>
          <div><label>hedefDurumNo</label><input id="it_hedef_durum" value="4"></div>
          <div><label>akisDurumTip</label><input id="it_durum_tip" value="21"></div>
          <div><label>islemSahibi</label><input id="it_islem_sahibi" value="3"></div>
        </div>
        <div class="row3">
          <div><label>isiUzerimeAl</label><select id="it_uzerime_al"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div>
          <div><label>Manuel OrgOid (boş kalırsa keşfedilen)</label><input id="it_orgoid_override" placeholder="İsteğe bağlı"></div>
          <div><label>Manuel UserId (boş kalırsa keşfedilen)</label><input id="it_user_override" placeholder="İsteğe bağlı"></div>
        </div>
        <div class="row3">
          <button class="btn-green" id="it_scan">İŞLERİ TARA</button>
          <button class="btn-blue" id="it_send">UYGUNLARI GÖNDER</button>
          <button class="btn-amber" id="it_refresh">LİSTEYİ YENİLE</button>
        </div>
        <button class="btn-red" id="it_stop" style="display:none;width:100%;margin-bottom:8px">DURDUR</button>
        <div class="sub">Akış: auto-discovery ile token / userId / orgoid bul → işleri çek → sonraki adımları kontrol et → uygun olanları <b>akisIslemleri_akisYeniAdimKaydet</b> ile gönder.</div>
        <div class="log" id="it_log"></div>
        <div class="tblwrap">
          <table>
            <thead><tr><th>#</th><th>İşTakip</th><th>İşin Türü</th><th>Ünvan</th><th>Durum</th><th>Önizle</th></tr></thead>
            <tbody id="it_rows"></tbody>
          </table>
        </div>
      </div>`;
    (document.body || document.documentElement).appendChild(el);
    return el;
  }

  function renderDiscovery() {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    const shortTok = v => v ? `${String(v).slice(0, 22)}...` : '-';
    const setVal = (sel, val) => { const el = $(sel, panel); if (el) el.value = val; };
    const setTxt = (sel, val) => { const el = $(sel, panel); if (el) el.textContent = val; };

    const shownUser = state.discovery.baseUserId || state.discovery.userId || '';
    const shownOrg = state.discovery.baseOrgoid || state.discovery.orgoid || '';
    const ist = state.discovery.tokensByModule?.istakip || state.discovery.token || '';

    setVal('#it_user', shownUser);
    setVal('#it_orgoid', shownOrg);
    setVal('#it_token', ist ? `${ist.slice(0, 18)}...` : '');

    setTxt('#it_user_src', state.discovery.baseSource?.userId ? `Kaynak: ${state.discovery.baseSource.userId} (ilk giriş)` : (state.discovery.source.userId ? `Kaynak: ${state.discovery.source.userId}` : 'Kaynak: -'));
    setTxt('#it_org_src', state.discovery.baseSource?.orgoid ? `Kaynak: ${state.discovery.baseSource.orgoid} (ilk giriş)` : (state.discovery.source.orgoid ? `Kaynak: ${state.discovery.source.orgoid}` : 'Kaynak: -'));
    setTxt('#it_tok_src', state.discovery.tokenSourceByModule?.istakip ? `İş Takip token kaynağı: ${state.discovery.tokenSourceByModule.istakip}` : (state.discovery.source.token ? `Genel token kaynağı: ${state.discovery.source.token}` : 'Kaynak: -'));

    setTxt('#it_base_tok', state.discovery.baseToken ? `${String(state.discovery.baseToken).slice(0,22)}...` : '-');
    setTxt('#it_base_tok_src', state.discovery.baseSource?.token ? `Token kaynağı: ${state.discovery.baseSource.token}` : 'Token kaynağı: -');
    setTxt('#it_base_user', state.discovery.baseUserId || '-');
    setTxt('#it_base_user_src', state.discovery.baseSource?.userId ? `Kullanıcı kaynağı: ${state.discovery.baseSource.userId}` : 'Kullanıcı kaynağı: -');
    setTxt('#it_base_org', state.discovery.baseOrgoid || '-');
    setTxt('#it_base_org_src', state.discovery.baseSource?.orgoid ? `OrgID kaynağı: ${state.discovery.baseSource.orgoid}` : 'OrgID kaynağı: -');

    setTxt('#it_used_tok', state.discovery.lastUsedToken ? `Kullanılan İş Takip tokenı: ${String(state.discovery.lastUsedToken).slice(0,22)}...` : 'Kullanılan İş Takip tokenı: -');
    setTxt('#it_used_tok_src', state.discovery.lastUsedTokenSource ? `Kullanılan token kaynağı: ${state.discovery.lastUsedTokenSource}` : 'Kullanılan token kaynağı: -');

    const modText = ['gp','g','istakip','evdo','e'].map(m => `${m}:${state.discovery.tokensByModule?.[m] ? 'var' : '-'}`).join(' | ');
    setTxt('#it_last_cmd', `${state.discovery.lastCmd ? `Son cmd: ${state.discovery.lastCmd}` : 'Son cmd: -'} | Son modül: ${state.discovery.lastModuleName || '-'} | ${modText}`);

    const fill = (m, id1, id2) => {
      const val = state.discovery.tokensByModule?.[m] || '';
      const src = state.discovery.tokenSourceByModule?.[m] || '';
      setTxt(id1, shortTok(val));
      setTxt(id2, src ? `Kaynak: ${src}` : 'Kaynak: -');
    };
    fill('istakip', '#it_tok_istakip', '#it_toksrc_istakip');
    fill('evdo', '#it_tok_evdo', '#it_toksrc_evdo');
    fill('e', '#it_tok_e', '#it_toksrc_e');
    fill('g', '#it_tok_g', '#it_toksrc_g');
    fill('gp', '#it_tok_gp', '#it_toksrc_gp');
  }

  function logger(panel) {
    const box = $('#it_log', panel);
    return (msg, err = false) => {
      const line = `[${new Date().toLocaleTimeString()}] ${err ? 'HATA: ' : ''}${msg}`;
      console.log('[ISTAKIP-BOT-V4]', line);
      box.innerHTML += `<div style="overflow-wrap:anywhere;word-break:break-word">${err ? '<span class="bad">HATA:</span> ' : ''}${msg}</div>`;
      box.scrollTop = box.scrollHeight;
    };
  }


function readUrlToken() {
  try { return new URL(location.href).searchParams.get('token') || ''; }
  catch (_) { return ''; }
}

function resolveKeysToken() {
  const preferred = ['gp', 'g'];
  for (const m of preferred) {
    const t = resolveTokenForModule(m);
    if (t) return t;
  }
  if (state.discovery.baseToken && state.discovery.baseToken !== state.discovery.token) {
    return state.discovery.baseToken;
  }
  const mods = ['gp', 'g', 'evdo', 'e', 'istakip'];
  for (const m of mods) {
    const t = resolveTokenForModule(m);
    if (t) return t;
  }
  return state.discovery.baseToken || '';
}

function collectMessageText(resp) {
  try {
    const msgs = Array.isArray(resp?.messages) ? resp.messages : [];
    return msgs.map(m => String(m?.text || '').trim()).filter(Boolean).join(' | ');
  } catch (_) {
    return '';
  }
}

function findDeepValue(obj, keys, depth = 0, seen = new WeakSet()) {
  try {
    if (!obj || typeof obj !== 'object' || depth > 6) return '';
    if (seen.has(obj)) return '';
    seen.add(obj);
    for (const k of keys) {
      if (obj[k] != null && obj[k] !== '') return obj[k];
    }
    for (const v of Object.values(obj)) {
      if (v && typeof v === 'object') {
        const found = findDeepValue(v, keys, depth + 1, seen);
        if (found != null && found !== '') return found;
      }
    }
  } catch (_) {}
  return '';
}

async function fetchKeysPreviewInfo(keysEvrakOid) {
  const token = resolveKeysToken();
  if (!token) throw new Error('KEYS token bulunamadı');
  const p = new URLSearchParams();
  p.append('cmd', 'evrakOrtakServis_evrakOnizle');
  p.append('callid', makeCallId());
  p.append('token', token);
  p.append('jp', JSON.stringify({
    evrakOid: String(keysEvrakOid || '').trim(),
    konteynerOid: null,
    evrakVersiyonOid: null,
    yetkisiz: true,
    barkod: true
  }));

  const res = await fetch(CFG.KEYS_DISPATCH_URL, {
    method: 'POST',
    body: p,
    credentials: 'include'
  });
  if (!res.ok) throw new Error(`Önizleme sorgusu ağ hatası: ${res.status}`);
  const txt = await res.text();
  let json = null;
  try { json = JSON.parse(txt); } catch (_) {
    throw new Error('Önizleme cevabı JSON değil');
  }
  if (String(json?.error || '') === '1') {
    throw new Error(collectMessageText(json) || 'Evrak önizleme hatası');
  }

  const data = json?.data || json || {};
  const directUrl = findDeepValue(data, ['previewUrl', 'pdfUrl', 'url', 'link']);
  if (directUrl) {
    return { token, url: directUrl, response: json };
  }

  const uuid = findDeepValue(data, ['uuid', 'fileID', 'fileId']);
  const dosyaId = findDeepValue(data, ['dosyaId', 'dosyaID', 'fn', 'fileName']);
  if (!uuid) throw new Error('Önizleme linki için fileID bulunamadı');

  const cleanedFileId = String(uuid || '').trim();
  const fileIdForUrl = cleanedFileId.endsWith('.pdf') ? cleanedFileId : `${cleanedFileId}.pdf`;
  const url = `${CFG.FLEXPAPER_URL}?token=${encodeURIComponent(token)}&fileID=${fileIdForUrl}#navpanes=0`;
  return { token, url, response: json, fileID: cleanedFileId, dosyaId };
}

function ensurePreviewModal() {
  let modal = document.getElementById('it_preview_modal');
  if (modal) return modal;
  modal = document.createElement('div');
  modal.id = 'it_preview_modal';
  modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.58);z-index:2147483647;padding:20px;';
  modal.innerHTML = `
    <div id="it_preview_box">
      <div id="it_preview_head">
        <div id="it_preview_title">Evrak Önizleme</div>
        <div id="it_preview_actions">
          <button type="button" class="it-btn-mini" id="it_preview_min">_</button>
          <button type="button" class="it-btn-mini" id="it_preview_reset">□</button>
          <button type="button" class="it-btn-mini" id="it_preview_reload">Yenile</button>
          <button type="button" class="it-btn-mini" id="it_preview_close">Kapat</button>
        </div>
      </div>
      <iframe id="it_preview_frame" referrerpolicy="no-referrer"></iframe>
      <div id="it_preview_msg" style="display:none"></div>
    </div>`;
  (document.body || document.documentElement).appendChild(modal);
  modal.addEventListener('click', ev => {
    if (ev.target === modal) { modal.classList.remove('open'); modal.style.display = 'none'; }
  });
  modal.querySelector('#it_preview_close').onclick = () => { modal.classList.remove('open'); modal.style.display = 'none'; };
  modal.querySelector('#it_preview_min').onclick = () => {
    const frame = modal.querySelector('#it_preview_frame');
    const msg = modal.querySelector('#it_preview_msg');
    const box = modal.querySelector('#it_preview_box');
    const hidden = frame.style.display === 'none' && msg.style.display === 'none';
    if (hidden) {
      frame.style.display = '';
      box.style.height = box.dataset.prevHeight || 'min(900px,92vh)';
      box.style.width = box.dataset.prevWidth || 'min(1280px,96vw)';
    } else {
      box.dataset.prevHeight = box.style.height || '';
      box.dataset.prevWidth = box.style.width || '';
      frame.style.display = 'none';
      msg.style.display = 'none';
      box.style.height = '48px';
      box.style.width = '520px';
    }
  };
  modal.querySelector('#it_preview_reset').onclick = () => {
    resetPreviewBoxSize();
  };
  modal.querySelector('#it_preview_reload').onclick = () => {
    const frame = modal.querySelector('#it_preview_frame');
    const src = frame.getAttribute('src');
    if (src) frame.setAttribute('src', src);
  };
  requestAnimationFrame(() => {
    const box = modal.querySelector('#it_preview_box');
    const head = modal.querySelector('#it_preview_head');
    enableDrag(box, head, { clearTransform: true });
  });
  return modal;
}

function showPreviewModal(url, titleText) {
  const modal = ensurePreviewModal();
  const frame = modal.querySelector('#it_preview_frame');
  const msg = modal.querySelector('#it_preview_msg');
  const title = modal.querySelector('#it_preview_title');
  title.textContent = titleText || 'Evrak Önizleme';
  msg.style.display = 'none';
  msg.textContent = '';
  frame.style.display = '';
  frame.src = url;
  modal.classList.add('open');
  modal.style.display = 'flex';
  const box = modal.querySelector('#it_preview_box');
  if (box && box.style.height === '48px') { resetPreviewBoxSize(); }

  let loaded = false;
  const timer = setTimeout(() => {
    if (loaded) return;
    msg.style.display = '';
    msg.innerHTML = 'Önizleme iframe içinde açılamadıysa sunucu buna izin vermiyor olabilir.<br><br>Bağlantıyı kopyalayıp adres çubuğunda açmayı deneyebilirsin.';
  }, 4000);

  frame.onload = () => {
    loaded = true;
    clearTimeout(timer);
  };
}


function enableDrag(el, handle, opts = {}) {
  if (!el || !handle) return;
  if (handle.__dragBound) return;
  handle.__dragBound = true;

  let dragging = false;
  let startX = 0, startY = 0, startLeft = 0, startTop = 0;

  const onMove = (ev) => {
    if (!dragging) return;
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;
    const rect = el.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - Math.min(rect.width, window.innerWidth));
    const maxTop = Math.max(0, window.innerHeight - 44);
    el.style.left = `${Math.max(0, Math.min(maxLeft, startLeft + dx))}px`;
    el.style.top = `${Math.max(0, Math.min(maxTop, startTop + dy))}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    if (opts.clearTransform) el.style.transform = 'none';
  };

  const onUp = () => {
    dragging = false;
    document.body.style.userSelect = '';
    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('mouseup', onUp, true);
  };

  handle.addEventListener('mousedown', (ev) => {
    if (ev.button !== 0) return;
    if (ev.target && ev.target.closest('button,a,input,select,textarea,iframe')) return;
    const rect = el.getBoundingClientRect();
    dragging = true;
    startX = ev.clientX;
    startY = ev.clientY;
    startLeft = rect.left;
    startTop = rect.top;
    el.style.left = `${rect.left}px`;
    el.style.top = `${rect.top}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    if (opts.clearTransform) el.style.transform = 'none';
    document.body.style.userSelect = 'none';
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mouseup', onUp, true);
    ev.preventDefault();
    ev.stopPropagation();
  }, true);
}

function onlyDigits(v){ return String(v || '').replace(/\D+/g, ''); }

function clamp10(el){
  if (!el) return;
  el.value = onlyDigits(el.value).slice(0, 10);
}

function hideLegacyTopFormRows(panel){
  try{
    const rows = Array.from(panel.querySelectorAll('.row4, .row3'));
    rows.forEach(row => {
      const txt = String(row.textContent || '');
      if (
        /Vergi No\s*\/\s*TCKN\s*\/\s*Ünvan/.test(txt) ||
        /Uygun değil işleri sil/.test(txt) ||
        /isiUzerimeAl/.test(txt) ||
        /Manual OrgOid/.test(txt) ||
        /Manual UserId/.test(txt) ||
        /hedefDurumNo/.test(txt) ||
        /akisDurumTip/.test(txt) ||
        /islemSahibi/.test(txt)
      ) {
        row.style.display = 'none';
      }
    });
  }catch(e){}
}

function getRenderedTable(panel){
  return panel?.querySelector('.tblwrap table') || null;
}

function getRenderedRows(panel){
  const table = getRenderedTable(panel);
  if (!table || !table.tBodies || !table.tBodies[0]) return [];
  return Array.from(table.tBodies[0].rows || []);
}

function getIsTakipCellFromRow(tr){
  const cells = Array.from(tr?.cells || []);
  return cells[1] || cells[0] || null;
}

function getRowVknFromIsTakipCell(tr){
  try{
    const cell = getIsTakipCellFromRow(tr);
    if (!cell) return '';
    const raw = String(cell.innerText || cell.textContent || '');
    const nums = raw.match(/\d{10,11}/g) || [];
    // İşTakip hücresindeki 10 haneli sayı VKN kabul edilir; 11 hane TCKN sayılır.
    const vkn = nums.find(x => String(x).length === 10);
    return vkn || '';
  }catch(e){
    return '';
  }
}

function getFilterValues(panel){
  return {
    start: onlyDigits(panel?.querySelector('#it_tbl_vkn_start')?.value || '').slice(0, 10),
    end: onlyDigits(panel?.querySelector('#it_tbl_vkn_end')?.value || '').slice(0, 10),
  };
}

function isVknInRange(vkn, start, end){
  if (!start && !end) return true;
  if (!vkn || vkn.length !== 10) return false;
  if (start && start.length !== 10) start = '';
  if (end && end.length !== 10) end = '';
  if (!start && !end) return true;
  if (start && !end) return vkn >= start;
  if (!start && end) return vkn <= end;
  return vkn >= start && vkn <= end;
}

function applyRenderedTableVknFilter(panel){
  try{
    const rows = getRenderedRows(panel);
    const { start, end } = getFilterValues(panel);
    let visible = 0;
    rows.forEach(tr => {
      const vkn = getRowVknFromIsTakipCell(tr);
      const ok = isVknInRange(vkn, start, end);
      tr.style.display = ok ? '' : 'none';
      if (ok) visible++;
    });

    const log = panel?.querySelector('#it_log');
    if (log) {
      const tag = `[VKN filtre] başlangıç=${start || '-'} bitiş=${end || '-'} görünür=${visible}/${rows.length}`;
      const lines = String(log.textContent || '').split('\n').filter(Boolean).filter(x => !x.startsWith('[VKN filtre]'));
      log.textContent = [tag].concat(lines).join('\n');
    }
  }catch(e){}
}

function ensureTableFilterBar(panel){
  try{
    const wrap = panel?.querySelector('.tblwrap');
    if (!wrap) return null;

    let bar = panel.querySelector('#it_tbl_filter_bar');
    if (bar) return bar;

    bar = document.createElement('div');
    bar.id = 'it_tbl_filter_bar';
    bar.style.cssText = 'display:flex; gap:8px; align-items:end; margin:0 0 8px 0; flex-wrap:wrap;';
    bar.innerHTML = `
      <div style="display:flex; flex-direction:column; gap:4px;">
        <label style="font-size:11px;">VKN Başlangıç</label>
        <input id="it_tbl_vkn_start" placeholder="0000000000" maxlength="10" style="height:28px;padding:4px 8px;">
      </div>
      <div style="display:flex; flex-direction:column; gap:4px;">
        <label style="font-size:11px;">VKN Bitiş</label>
        <input id="it_tbl_vkn_end" placeholder="3000000000" maxlength="10" style="height:28px;padding:4px 8px;">
      </div>
      <div style="display:flex; align-items:end; gap:6px;">
        <button type="button" id="it_tbl_vkn_apply">Uygula</button>
        <button type="button" id="it_tbl_vkn_clear">Temizle</button>
      </div>
    `;
    wrap.parentNode.insertBefore(bar, wrap);

    const start = bar.querySelector('#it_tbl_vkn_start');
    const end = bar.querySelector('#it_tbl_vkn_end');
    const applyBtn = bar.querySelector('#it_tbl_vkn_apply');
    const clearBtn = bar.querySelector('#it_tbl_vkn_clear');

    const run = () => {
      clamp10(start);
      clamp10(end);
      applyRenderedTableVknFilter(panel);
    };

    ['input','change','keyup'].forEach(ev => {
      start.addEventListener(ev, run);
      end.addEventListener(ev, run);
    });

    applyBtn.addEventListener('click', run);
    clearBtn.addEventListener('click', () => {
      start.value = '';
      end.value = '';
      applyRenderedTableVknFilter(panel);
    });

    return bar;
  }catch(e){
    return null;
  }
}

function wireCleanTableFilterFlow(panel){
  try{
    if (!panel) return;
    hideLegacyTopFormRows(panel);
    ensureTableFilterBar(panel);
    applyRenderedTableVknFilter(panel);

    const scan = panel.querySelector('#it_scan');
    const refresh = panel.querySelector('#it_refresh');

    if (scan && !scan.__cleanTblFilterBound) {
      scan.addEventListener('click', () => {
        setTimeout(() => {
          hideLegacyTopFormRows(panel);
          ensureTableFilterBar(panel);
          applyRenderedTableVknFilter(panel);
        }, 1200);
      });
      scan.__cleanTblFilterBound = true;
    }

    if (refresh && !refresh.__cleanTblFilterBound) {
      refresh.addEventListener('click', () => {
        setTimeout(() => {
          hideLegacyTopFormRows(panel);
          ensureTableFilterBar(panel);
          applyRenderedTableVknFilter(panel);
        }, 500);
      });
      refresh.__cleanTblFilterBound = true;
    }

    if (!panel.__cleanTblFilterObserverBound) {
      const wrap = panel.querySelector('.tblwrap');
      if (wrap) {
        const mo = new MutationObserver(() => {
          hideLegacyTopFormRows(panel);
          ensureTableFilterBar(panel);
          applyRenderedTableVknFilter(panel);
        });
        mo.observe(wrap, { childList:true, subtree:true, characterData:true });
        panel.__cleanTblFilterObserverBound = true;
      }
    }
  }catch(e){}
}

setInterval(() => {
  try{
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    wireCleanTableFilterFlow(panel);
  }catch(e){}
}, 400);
