EVDB Emanet Excel Bot v2.1

Referans çalışan sürüm: v1.8.

Düzeltmeler / ekler:
- v1.8/v1.9 çalışan akış korunmuştur.
- Kimlik no yazıldıktan sonra Ad/Soyad gelmezse bot birkaç kez güvenli boş alana tıklayarak sorguyu yeniden tetikler.
- Başarılı eklenen kayıtlar hafızaya alınır. Aynı Excel tekrar okunup Başlat dendiğinde başarılı satırlar atlanır, kaldığı yerden devam eder.
- Panelde "Hafızadaki başarılı" sayısı görünür.
- Gerekirse "Hafızayı Sıfırla" butonu ile aynı Excel için ilerleme hafızası temizlenir.
- 2. ve sonraki satırlarda üstteki "Emanet Bilgilerini Temizle" kullanılır; alttaki genel "Temizle" kullanılmaz.
- Vergi Kimlik No alanına ekstra tıklama yoktur.

Kurulum:
1) Chrome uzantılarından eski sürümü kaldırın.
2) Paketlenmemiş öğe yükle ile evdb-emanet-ekleme-extension-v21 klasörünü seçin.
3) EVDB ekranını yenileyin.
4) Eklenti ikonuna basarak paneli açın.

Kullanım notu:
Bir hata olduğunda Durdur / sayfayı yenile / Excel'i tekrar Dosyayı Oku / Başlat yaparsanız, "Başarılı kayıtları hatırla" seçili olduğu sürece daha önce eklenen kayıtlar atlanır.


v2.1 ekleri:
- Vergi No ve T.C. No ikisi de boş olan satırlar artık hata sayılmaz; otomatik atlanır ve sonraki satırdan devam edilir.
- Atlanan boş kimlik kayıtlarının sayısı panelde görünür.
- Atlanan kayıtların Fiş No listesi panelde ve işlem sonunda log ekranında yazılır.
