chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ evdbBotState: { running: false, paused: false } });
});
