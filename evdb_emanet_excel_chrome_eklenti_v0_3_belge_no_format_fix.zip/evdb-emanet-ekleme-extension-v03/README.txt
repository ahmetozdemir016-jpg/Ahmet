EVDB Emanet Excel Botu v0.3

Excel sayfası: Emanet_Rapor
Okunan sütunlar:
A Tarih, B Fiş No, C Belge No, D İşlem Tutarı, F İşlem Yönü, G T.C. No, H Vergi No.

Belge No otomatik EVDB formatına çevrilir:
20260604000000015161 -> 20260604/00-000/0015161
Belge No boşsa Tarih + Fiş No'dan üretilir.

Varsayılan: İşlem Yönü=Giriş olanları işler, Kaydet'e basmadan yalnızca alta ekler.
