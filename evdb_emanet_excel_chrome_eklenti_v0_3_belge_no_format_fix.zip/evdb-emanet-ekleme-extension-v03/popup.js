const $ = id => document.getElementById(id);
let preparedRows = [];
let selectedFile = null;

function log(msg) {
  const el = $('log');
  el.textContent += `[${new Date().toLocaleTimeString('tr-TR')}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
}
function status(msg) { $('status').textContent = msg; log(msg); }
function setFile(file) {
  selectedFile = file || null;
  preparedRows = [];
  $('total').textContent = '0';
  $('usable').textContent = '0';
  $('start').disabled = true;
  $('preview').disabled = !selectedFile;
  if (selectedFile) {
    $('fileName').textContent = `${selectedFile.name} (${Math.round(selectedFile.size/1024)} KB)`;
    status('Dosya seçildi. Şimdi “Dosyayı Oku” butonuna basın.');
  } else {
    $('fileName').textContent = 'Dosya seçilmedi.';
    status('Dosya seçilmedi.');
  }
}

$('choose').addEventListener('click', () => $('file').click());
$('file').addEventListener('change', e => setFile(e.target.files && e.target.files[0]));

const dz = $('dropZone');
['dragenter','dragover'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.classList.add('drag'); }));
['dragleave','drop'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.classList.remove('drag'); }));
dz.addEventListener('drop', e => {
  const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (!file) return status('Bırakılan dosya alınamadı.');
  if (!file.name.toLowerCase().endsWith('.xlsx')) return status('Sadece .xlsx dosyası seçin.');
  setFile(file);
});

function normalizeDate(v) {
  v = String(v || '').trim();
  if (!v) return '';
  let m = v.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
  if (m) return `${m[1].padStart(2,'0')}.${m[2].padStart(2,'0')}.${m[3]}`;
  if (/^\d+(\.\d+)?$/.test(v)) {
    const n = Number(v);
    if (n > 20000 && n < 80000) {
      const d = new Date(Math.round((n - 25569) * 86400 * 1000));
      return `${String(d.getUTCDate()).padStart(2,'0')}.${String(d.getUTCMonth()+1).padStart(2,'0')}.${d.getUTCFullYear()}`;
    }
  }
  return v;
}
function normalizeAmount(v) {
  v = String(v || '').trim();
  if (!v) return '';
  if (v.includes(',') && v.includes('.')) return v.replace(/\./g, '');
  return v.replace(/\s/g, '').replace('.', ',');
}

function formatEvdbBelgeNo(raw, tarih, fisNo) {
  let v = String(raw || '').trim();
  // Excel örneği: 20260604000000015161 -> EVDB: 20260604/00-000/0015161
  const digits = v.replace(/\D/g, '');
  if (digits.length >= 15 && /^20\d{6}/.test(digits)) {
    return `${digits.slice(0,8)}/00-000/${digits.slice(-7)}`;
  }
  // Belge No yoksa, Tarih + Fiş No'dan üret: 04.06.2026 + F15161 -> 20260604/00-000/0015161
  const t = String(tarih || '').trim();
  const f = String(fisNo || '').replace(/\D/g, '');
  const m = t.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (!v && m && f) return `${m[3]}${m[2]}${m[1]}/00-000/${f.padStart(7,'0')}`;
  return v;
}

function pick(r, names) {
  for (const n of names) {
    if (r[n] !== undefined && r[n] !== null && String(r[n]).trim() !== '') return r[n];
  }
  return '';
}
function mapRows(rows) {
  const onlyGiris = $('onlyGiris').checked;
  return rows.map(r => {
    const tarih = normalizeDate(pick(r, ['Tarih', 'İşlem Tarihi', 'Duzenleme Tarihi', 'Düzenleme Tarihi']));
    const fisNo = String(pick(r, ['Fiş No', 'Fis No', 'Fiş Numarası']) || '').trim();
    const belgeRaw = String(pick(r, ['Belge No', 'Belge Numarası', 'Belge No.']) || '').trim();
    return {
      excelRow: r.__rownum,
      tarih,
      fisNo,
      belgeNo: formatEvdbBelgeNo(belgeRaw, tarih, fisNo),
      belgeNoExcel: belgeRaw,
      tutar: normalizeAmount(pick(r, ['İşlem Tutarı', 'Islem Tutari', 'Tutar', 'Tutarı'])),
      islemYonu: String(pick(r, ['İşlem Yönü', 'Islem Yonu', 'Yön']) || '').trim(),
      tcNo: String(pick(r, ['T.C. No', 'TC No', 'T.C.Kimlik No', 'T.C. Kimlik No']) || '').replace(/\D/g, ''),
      vergiNo: String(pick(r, ['Vergi No', 'Vergi Kimlik No', 'VKN']) || '').replace(/\D/g, ''),
      gonderen: String(pick(r, ['Gönderen/Ödeyen', 'Gönderen', 'Ödeyen']) || '').trim(),
      ham: r
    };
  }).filter(r => !onlyGiris || r.islemYonu.toLocaleLowerCase('tr-TR') === 'giriş')
    .filter(r => r.tarih || r.belgeNo || r.tutar || r.tcNo || r.vergiNo);
}

$('preview').addEventListener('click', async () => {
  const file = selectedFile || ($('file').files && $('file').files[0]);
  if (!file) return status('Önce Excel dosyası seçin.');
  try {
    status('Excel okunuyor...');
    const wb = await XLSXLite.readXlsx(file, 'Emanet_Rapor');
    preparedRows = mapRows(wb.rows);
    $('total').textContent = wb.rows.length;
    $('usable').textContent = preparedRows.length;
    $('start').disabled = preparedRows.length === 0;
    status(`Okundu. Sayfa: ${wb.sheetName}. İşlenecek kayıt: ${preparedRows.length}. Belge No EVDB formatına çevrildi.`);
    log('İlk kayıt örnekleri: ' + JSON.stringify(preparedRows.slice(0, 3), null, 2));
  } catch (e) {
    status('Excel okuma hatası: ' + (e && e.message ? e.message : e));
  }
});

async function sendToTab(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error('Aktif sekme bulunamadı.');
  return await chrome.tabs.sendMessage(tab.id, message);
}

$('start').addEventListener('click', async () => {
  if (!preparedRows.length) return status('Önce dosyayı okuyun.');
  try {
    await chrome.storage.local.set({ evdbEmanetRows: preparedRows });
    await sendToTab({
      type: 'EVDB_EMANET_START',
      rows: preparedRows,
      options: {
        noAutoSave: $('noAutoSave').checked,
        stopOnError: $('stopOnError').checked,
        delay: Number($('delay').value || 750),
        belgeTuru: 'Diğer',
        emanetTuru: '39 Diğer Çeşitli Emanetler'
      }
    });
    $('start').disabled = true; $('pause').disabled = false; $('stop').disabled = false; $('resume').disabled = true;
    status('Aktarım başlatıldı. EVDB ekranındaki bot panelinden ilerlemeyi izleyin.');
  } catch (e) { status('Başlatma hatası: ' + (e && e.message ? e.message : e)); }
});
$('pause').addEventListener('click', async () => { await sendToTab({ type: 'EVDB_EMANET_PAUSE' }); $('pause').disabled=true; $('resume').disabled=false; status('Duraklatıldı.'); });
$('resume').addEventListener('click', async () => { await sendToTab({ type: 'EVDB_EMANET_RESUME' }); $('pause').disabled=false; $('resume').disabled=true; status('Devam ediyor.'); });
$('stop').addEventListener('click', async () => { await sendToTab({ type: 'EVDB_EMANET_STOP' }); $('start').disabled=false; $('pause').disabled=true; $('resume').disabled=true; $('stop').disabled=true; status('Durduruldu.'); });
