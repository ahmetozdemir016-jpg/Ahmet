(() => {
  if (window.__evdbEmanetBotLoaded) return;
  window.__evdbEmanetBotLoaded = true;

  const state = { running: false, paused: false, stopped: false, current: 0, results: [], options: {} };

  function norm(s) {
    return String(s || '').toLocaleLowerCase('tr-TR')
      .replace(/\s+/g, ' ').replace(/[：:]/g, '').trim();
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
  }
  function log(msg) {
    ensurePanel();
    const line = `[${new Date().toLocaleTimeString('tr-TR')}] ${msg}`;
    console.log('[EVDB Emanet Bot]', msg);
    const box = document.getElementById('evdb-emanet-bot-log');
    if (box) { box.textContent += line + '\n'; box.scrollTop = box.scrollHeight; }
    const title = document.getElementById('evdb-emanet-bot-title');
    if (title) title.textContent = `EVDB Emanet Botu - ${state.current}/${state.total || 0}`;
  }
  function ensurePanel() {
    if (document.getElementById('evdb-emanet-bot-panel')) return;
    const panel = document.createElement('div');
    panel.id = 'evdb-emanet-bot-panel';
    panel.style.cssText = 'position:fixed;right:12px;bottom:12px;width:390px;max-height:340px;z-index:2147483647;background:#111;color:#eee;border:2px solid #ffd966;border-radius:8px;font:12px Arial;padding:8px;box-shadow:0 4px 22px #0008;';
    panel.innerHTML = `
      <div id="evdb-emanet-bot-title" style="font-weight:bold;margin-bottom:6px">EVDB Emanet Botu</div>
      <div style="display:flex;gap:6px;margin-bottom:6px">
        <button id="evdb-bot-pause">Duraklat</button>
        <button id="evdb-bot-resume">Devam</button>
        <button id="evdb-bot-stop">Durdur</button>
      </div>
      <pre id="evdb-emanet-bot-log" style="height:235px;overflow:auto;white-space:pre-wrap;background:#000;color:#d8ffd8;padding:6px;margin:0;border-radius:4px"></pre>`;
    document.documentElement.appendChild(panel);
    document.getElementById('evdb-bot-pause').onclick = () => { state.paused = true; log('Duraklatıldı.'); };
    document.getElementById('evdb-bot-resume').onclick = () => { state.paused = false; log('Devam ediyor.'); };
    document.getElementById('evdb-bot-stop').onclick = () => { state.stopped = true; state.running = false; log('Durduruluyor...'); };
  }

  function injectConfirmOverride() {
    if (document.getElementById('evdb-emanet-confirm-override')) return;
    const s = document.createElement('script');
    s.id = 'evdb-emanet-confirm-override';
    s.textContent = `(() => {
      if (window.__evdbEmanetConfirmPatched) return;
      window.__evdbEmanetConfirmPatched = true;
      const oldConfirm = window.confirm;
      window.confirm = function(msg) {
        try {
          if (String(msg || '').toLocaleLowerCase('tr-TR').includes('zaman aşımı')) return true;
        } catch(e) {}
        return oldConfirm.apply(this, arguments);
      };
    })();`;
    (document.head || document.documentElement).appendChild(s);
  }

  function allCandidates() {
    return [...document.querySelectorAll('input, textarea, select, [contenteditable="true"], [role="combobox"]')].filter(visible);
  }
  function inputLike(el) {
    if (!el) return false;
    return ['INPUT','TEXTAREA','SELECT'].includes(el.tagName) || el.isContentEditable || el.getAttribute('role') === 'combobox';
  }
  function findLabelNode(label) {
    const nlabel = norm(label);
    let best = null;
    for (const el of [...document.querySelectorAll('label, td, th, div, span, font, b')].filter(visible)) {
      const t = norm(el.innerText || el.textContent || '');
      if (!t) continue;
      if (t === nlabel || t.includes(nlabel)) {
        if (!best || (t.length < norm(best.innerText || best.textContent || '').length)) best = el;
      }
    }
    return best;
  }
  function findControlAfterLabel(label) {
    // Direct selectors by name/id/title/aria-label first
    const nlabel = norm(label);
    const controls = allCandidates();
    for (const c of controls) {
      const attrs = [c.name, c.id, c.title, c.placeholder, c.getAttribute('aria-label'), c.getAttribute('fieldLabel')].map(norm).join(' ');
      if (attrs.includes(nlabel)) return c;
    }
    const labelNode = findLabelNode(label);
    if (!labelNode) return null;
    const near = labelNode.closest('tr, .x-form-item, .form-group, table, div') || labelNode.parentElement;
    if (near) {
      const inside = [...near.querySelectorAll('input, textarea, select, [contenteditable="true"], [role="combobox"]')].filter(visible);
      if (inside.length) return inside[0];
    }
    // Next siblings / document order after label
    const lr = labelNode.getBoundingClientRect();
    let best = null, bestScore = Infinity;
    for (const c of controls) {
      const r = c.getBoundingClientRect();
      const rightSameLine = r.left >= lr.left - 5 && Math.abs(r.top - lr.top) < 60;
      const below = r.top >= lr.top && r.top - lr.top < 130;
      if (rightSameLine || below) {
        const score = Math.abs(r.top - lr.top) * 4 + Math.max(0, r.left - lr.left);
        if (score < bestScore) { best = c; bestScore = score; }
      }
    }
    return best;
  }
  function setNativeValue(el, value) {
    if (!el) throw new Error('Alan bulunamadı.');
    el.scrollIntoView({ block: 'center', inline: 'center' });
    el.focus();
    if (el.tagName === 'SELECT') {
      const nval = norm(value);
      let opt = [...el.options].find(o => norm(o.textContent).includes(nval) || norm(o.value).includes(nval));
      if (!opt) throw new Error('Açılır listede seçenek yok: ' + value);
      el.value = opt.value;
    } else if (el.isContentEditable) {
      el.textContent = value;
    } else {
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, value); else el.value = value;
    }
    ['input','change','keyup','blur'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Tab' }));
  }
  async function typeValue(label, value) {
    const el = findControlAfterLabel(label);
    if (!el) throw new Error(`Alan bulunamadı: ${label}`);
    setNativeValue(el, String(value || ''));
    await sleep(150);
    return el;
  }
  async function selectByText(label, text) {
    const el = findControlAfterLabel(label);
    if (!el) throw new Error(`Liste alanı bulunamadı: ${label}`);
    el.scrollIntoView({ block: 'center', inline: 'center' });
    if (el.tagName === 'SELECT') {
      setNativeValue(el, text);
      await sleep(200); return;
    }
    // ExtJS/combo style: click, type, arrow/enter.
    el.focus(); el.click();
    await sleep(120);
    setNativeValue(el, text);
    await sleep(350);
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'ArrowDown', code: 'ArrowDown' }));
    await sleep(80);
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter' }));
    await sleep(250);
    clickVisibleText(text, false); // dropdown item fallback
    await sleep(200);
  }
  function clickVisibleText(text, required = true) {
    const target = norm(text);
    const nodes = [...document.querySelectorAll('button, input[type="button"], input[type="submit"], a, span, div, td')].filter(visible);
    let best = null;
    for (const el of nodes) {
      const val = el.tagName === 'INPUT' ? el.value : (el.innerText || el.textContent || '');
      const t = norm(val);
      if (t === target || t.includes(target)) { best = el; break; }
    }
    if (!best) {
      if (required) throw new Error('Buton/metin bulunamadı: ' + text);
      return false;
    }
    best.scrollIntoView({ block: 'center', inline: 'center' });
    best.click();
    return true;
  }
  async function clickButton(text) {
    clickVisibleText(text, true);
    await sleep(500);
  }
  async function clickYesIfExists() {
    for (let i=0; i<20; i++) {
      const ok = clickVisibleText('Evet', false) || clickVisibleText('Tamam', false);
      if (ok) { log('Onay penceresi: Evet/Tamam tıklandı.'); return true; }
      await sleep(150);
    }
    return false;
  }
  async function waitForIdentityFilled(timeoutMs = 8000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const ad = findControlAfterLabel('Ad');
      const soyad = findControlAfterLabel('Soyad');
      const unvan = findControlAfterLabel('Unvan') || findControlAfterLabel('Adı Soyadı') || findControlAfterLabel('Mükellef');
      const vals = [ad, soyad, unvan].filter(Boolean).map(x => String(x.value || x.textContent || '').trim()).filter(Boolean);
      if (vals.length >= 1) return true;
      await sleep(350);
    }
    return false;
  }
  function validateRow(row) {
    const missing = [];
    if (!row.vergiNo && !row.tcNo) missing.push('Vergi No/T.C. No');
    if (!row.belgeNo) missing.push('Belge No');
    if (!row.tutar) missing.push('Tutar');
    if (!row.tarih) missing.push('Tarih');
    return missing;
  }

  async function processRow(row, index) {
    log(`Satır ${row.excelRow} başlıyor: ${row.vergiNo || row.tcNo} / ${row.tutar} / ${row.belgeNo}`);
    const missing = validateRow(row);
    if (missing.length) throw new Error('Eksik alan: ' + missing.join(', '));

    await selectByText('Belge Türü', state.options.belgeTuru || 'Diğer');

    if (row.vergiNo) {
      await typeValue('Vergi Kimlik No', row.vergiNo);
      // T.C. alanı önceki satırdan kalmasın diye mümkünse temizle
      const tc = findControlAfterLabel('T.C. Kimlik No') || findControlAfterLabel('TC Kimlik No');
      if (tc) setNativeValue(tc, '');
    } else {
      await typeValue('T.C. Kimlik No', row.tcNo);
      const vn = findControlAfterLabel('Vergi Kimlik No');
      if (vn) setNativeValue(vn, '');
    }

    log('Ad/Soyad/Unvan dolması bekleniyor...');
    if (!(await waitForIdentityFilled())) throw new Error('Ad/Soyad/Unvan otomatik dolmadı.');

    await typeValue('Belge No', row.belgeNo);
    await typeValue('Tutar', row.tutar);
    await typeValue('Düzenleme Tarihi', row.tarih);
    await typeValue('Zaman Aşımı Başlangıç Tarihi', row.tarih);
    await selectByText('Emanet Türü', state.options.emanetTuru || '39 Diğer Çeşitli Emanetler');

    await clickButton('Emanet Ekle');
    await clickYesIfExists();
    await sleep(state.options.delay || 750);
    log(`Satır ${row.excelRow} eklendi kabul edildi.`);
    return { row: row.excelRow, status: 'Eklendi' };
  }

  async function runRows(rows, options) {
    if (state.running) { log('Zaten çalışıyor.'); return; }
    injectConfirmOverride();
    ensurePanel();
    state.running = true; state.paused = false; state.stopped = false; state.current = 0; state.total = rows.length; state.options = options || {}; state.results = [];
    log(`Aktarım başladı. Kayıt sayısı: ${rows.length}. Kaydet otomatik: ${!state.options.noAutoSave}`);
    for (let i = 0; i < rows.length; i++) {
      while (state.paused && !state.stopped) await sleep(300);
      if (state.stopped) break;
      state.current = i + 1;
      try {
        const res = await processRow(rows[i], i);
        state.results.push(res);
      } catch (e) {
        log(`HATA - Excel satır ${rows[i]?.excelRow}: ${e.message}`);
        state.results.push({ row: rows[i]?.excelRow, status: 'Hata', message: e.message });
        if (state.options.stopOnError) break;
      }
    }
    state.running = false;
    if (!state.stopped && !state.options.noAutoSave) {
      try { await clickButton('Kaydet'); log('Kaydet butonuna basıldı.'); } catch (e) { log('Kaydet basılamadı: ' + e.message); }
    }
    log('İşlem bitti. Sonuçlar: ' + JSON.stringify(state.results));
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      if (message.type === 'EVDB_EMANET_START') {
        runRows(message.rows || [], message.options || {});
        sendResponse({ ok: true });
      } else if (message.type === 'EVDB_EMANET_PAUSE') {
        state.paused = true; log('Popup komutu: duraklat.'); sendResponse({ ok: true });
      } else if (message.type === 'EVDB_EMANET_RESUME') {
        state.paused = false; log('Popup komutu: devam.'); sendResponse({ ok: true });
      } else if (message.type === 'EVDB_EMANET_STOP') {
        state.stopped = true; state.running = false; log('Popup komutu: durdur.'); sendResponse({ ok: true });
      }
    } catch (e) { sendResponse({ ok: false, error: e.message }); }
    return true;
  });
})();
