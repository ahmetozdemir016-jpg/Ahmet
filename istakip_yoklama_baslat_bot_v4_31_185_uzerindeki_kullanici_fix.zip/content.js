// v4.31.185: Birim+kullanıcı işleri birleştirilirken aynı iş önce GİB/birim satırından geldiğinde kullanıcı satırındaki __ownerName/__ownerUserId kaybolmasın diye duplicate merge eklendi; Üzerindeki Kullanıcı sütunu OID/nodeId benzeri değerleri kullanıcı adı gibi göstermeyip gerçek kullanıcı adını yedek alanlardan okur. v4.31.184: Kullanıcı üzerinde/bölüm kişileri üzerinde gelen MERSİS işlerinde İşlem Bilgisi boş kalmasın diye VDKODU metin yerine 6 haneli koda normalize edilir ve ham cevap yedek alanları okunur. v4.31.183: İşleri Tara birleşik listede kullanıcı üzerindeki MERSİS işlerinde İşin Türü boş/Belge Bilgi gibi görünme hatası düzeltildi; detayId ve EVDB MERSİS işlem türü yedek eşleştirmesi eklendi. v4.31.182: İşi Başkasına Ata sadece kullanıcı üzerinde olan işler için aktif; GİB/birim işlerindeki başkasına ata akışı gizlendi. v4.31.181: Memur üzerindeki işte "İşi Başkasına Ata" gerçek HAR akışı eklendi; amir organizasyon ağacı + isAtamaIslemleri_isiBaskasinaAtaAmirTarafindan payloadı kullanılır. v4.31.180: Memura Ata/Talep Sevk payloadında seçilen her kullanıcıya ait userId + kullanıcı nodeId ayrı gönderilir; sabit nodeId atanma hatası düzeltildi. v4.31.178: Memura Ata/Talep Sevk seçim ekranı HAR akışına göre Ekle/Çıkar/Açıklama/İşi Ata şeklinde düzenlendi. v4.31.177: Memur listesi menüde görünmeme düzeltildi; seçim listesi satır menüsünde açılır. v4.31.176: Memura Ata / Talep Sevk kullanıcı seçimi HAR akışı eklendi. v4.31.175: Ünvan değişikliğinde eski 999 ve yeni 103 MERSİS sorguları birlikte kullanılır. v4.31.144: MERSİS Merkez Açılış yoklaması EYS Yoklama Giriş payload akışıyla kaydedilir.
(() => {
  'use strict';
  // v4.31.69 Memur Yoklama Giriş HAR akışı: tüm VD şube faaliyetleri, bilinen adresler ve sade save payload düzeltildi.
  try {
    const __itHref = String(location.href || '').toLowerCase();
    const __itPath = String(location.pathname || '').toLowerCase();
    if (__itHref.includes('/flexpaper/pdf') || __itPath.includes('/flexpaper/pdf') || __itHref.includes('/edenetis/getsonuc') || __itPath.includes('/edenetis/getsonuc')) return;
  } catch (_) {}

  if (window.__istakipYoklamaBotLoadedV419) return;
  window.__istakipYoklamaBotLoadedV419 = true;

  const CFG = {
    PANEL_ID: 'istakip-yoklama-bot-panel-v419',
    STYLE_ID: 'istakip-yoklama-bot-style-v419',
    STORAGE_KEY: 'istakip_yoklama_bot_v419_settings',
    DISCOVERY_KEY: 'istakip_yoklama_bot_v419_discovery',
    UI_KEY: 'istakip_yoklama_bot_v419_ui',
    RESTORE_ID: 'istakip-yoklama-bot-restore-v419',
    DISPATCH_URL: `${location.origin}/istakip_server/dispatch`,
    KEYS_DISPATCH_URL: `${location.origin}/keyss/external_dispatch`,
    FLEXPAPER_URL: `${location.origin}/keyss/flexpaper/pdf/`,
    DEFAULT_LIMIT: 50,
    COMMANDS: {
      LIST: 'isTakipSorgulamalarServices_isleriSorgula',
      NEXT_STEPS: 'akisIslemleri_isTakipSonrakiAdimlariBul',
      SAVE_STEP: 'akisIslemleri_akisYeniAdimKaydet',
      ACTIVE_COUNTS: 'isTakipSorgulamalarServices_aktifIsSayilariniBul',
      USER_JOBS_SUMMARY: 'isTakipSorgulamalarServices_kullanicilaraAitIslerinOzetiniSorgula',
      USER_JOBS_IN_NODE: 'isTakipSorgulamalarServices_kullanicininBirimdekiIsleriniSorgula',
      USER_SESSION: 'userSessionService_getUserSessionInfo'
    }
  };


  const PAGE_HOOK_EVENT = '__ISTAKIP_BOT_V4_DISCOVERY__';

  function itIsEvdbRaporContextActive() {
    try {
      const title = String(document.title || '').toLowerCase();
      const body = String((document.body && (document.body.innerText || document.body.textContent)) || '').slice(0, 12000).toLowerCase();
      const txt = title + ' ' + body;
      // Normal EVDB ekranı açıldığında /evdorapor_server/assos-login görülebiliyor; bu tek başına EVDB Rapor tokeni sayılmayacak.
      // Sadece ekranda EVDB Rapor/MERSİS rapor bağlamı görünüyorsa rapor tokeni olarak kaydedilir.
      return /evdb\s*rapor/i.test(txt) || /mers[iı]s\s*i[şs]lem\s*listesi/i.test(txt) || /ticaret\s*sicili\s*m[üu]d[üu]rl[üu][ğg][üu]\s*tescil/i.test(txt);
    } catch (_) { return false; }
  }

  function wirePageMessages() {
    if (window.__istakipV419MsgWired) return;
    window.__istakipV419MsgWired = true;
    window.addEventListener('message', ev => {
      try {
        if (ev.source !== window) return;
        const d = ev.data;
        if (!d || d.type !== PAGE_HOOK_EVENT) return;
                if (d.cmd) state.discovery.lastCmd = d.cmd;
        const src = (d.source || 'page-hook') + (d.cmd ? `:${d.cmd}` : '');
        const rawModule = d.moduleName || d.payload?.moduleName || d.payload?.modulAdi || d.payload?.module || '';
        const moduleName = normalizeModuleName(rawModule);
        if (moduleName) setPendingModule(moduleName, src);

        if (/assos-login-response/i.test(src)) {
          if (d.token) logBaseDiscovery('token', d.token, src);
          if (d.userId) logBaseDiscovery('userId', d.userId, src);
          if (d.orgoid) logBaseDiscovery('orgoid', d.orgoid, src);
          if (/evdorapor_server\/assos-login|evdorapor_server.*assos-login/i.test(src) && d.token) {
            try {
              if (itIsEvdbRaporContextActive()) {
                state.discovery.evdbRaporToken = String(d.token || '').trim();
                state.discovery.evdbRaporTokenSource = src;
                state.discovery.evdbRaporTokenTime = Date.now();
                itWriteEvdoRaporTokenCache({ token: d.token, gpToken: '', time: Date.now(), source: src });
              } else {
                state.discovery.history.push(`[${new Date().toLocaleTimeString()}] EVDB açılışı /assos-login görüldü; EVDB Rapor tokeni olarak işaretlenmedi (${src})`);
                if (state.discovery.history.length > 60) state.discovery.history.shift();
              }
            } catch (_) {}
          }
          if (state.discovery.pendingModule && d.token) {
            rememberModuleToken(state.discovery.pendingModule, d.token, src + ':pending-bound');
          }
        }

        if (d.token) logDiscovery('token', d.token, src);
        if (d.userId) logDiscovery('userId', d.userId, src);
        if (d.orgoid) logDiscovery('orgoid', d.orgoid, src);
        if (d.payload && typeof d.payload === 'object') {
          if (Array.isArray(d.payload.tokens)) rememberPageTokenList(d.payload.tokens, src);
          learnFromObject(d.payload, d.source || 'page-hook:payload');
        }
        persistDiscovery();
        renderDiscovery();
        maybeStopHooksAfterDiscovery(src);
      } catch (_) {}
    });
  }

  function injectPageHook() {
    // v4.31.49: Sayfa CSP'si script etiketi enjeksiyonunu engelleyebiliyor.
    // page_hook.js artık manifestte world:"MAIN" content script olarak çalışıyor.
    try { window.postMessage({ type: '__ISTAKIP_EYS_SESSION_REQUEST__' }, '*'); } catch (_) {}
  }

  const REQUIRED_HOOK_TOKEN_MODULES = ['gp', 'g', 'istakip', 'evdo', 'e'];

  function discoveryHasEnoughTokens() {
    try {
      const d = state.discovery || {};
      const mods = d.tokensByModule || {};
      const userId = d.userId || d.baseUserId || '';
      const orgoid = d.orgoid || d.baseOrgoid || '';
      const hasAllModuleTokens = REQUIRED_HOOK_TOKEN_MODULES.every(m => !!String(mods[m] || '').trim());
      const hasEvdbRaporToken = !!(String(d.evdbRaporToken || '').trim() || itReadEvdoRaporTokenCache()?.token);
      return !!(userId && orgoid && hasAllModuleTokens && hasEvdbRaporToken);
    } catch (_) { return false; }
  }

  function moduleNameFromPageTokenSource(source) {
    const s = String(source || '');
    let m = '';
    const m1 = s.match(/CSSession\.getToken\((?:module:)?([^\)]+)\)/i);
    if (m1) m = m1[1];
    if (!m) {
      const m2 = s.match(/getToken[:\s]+(gp|g|istakip|evdo|e)\b/i);
      if (m2) m = m2[1];
    }
    return normalizeModuleName(String(m || '').replace(/^module:/i, '').trim());
  }

  function rememberPageTokenList(tokens, sourcePrefix = 'page-token-list') {
    try {
      if (!Array.isArray(tokens)) return;
      for (const item of tokens) {
        const token = String(item && item.token || '').trim();
        if (!token) continue;
        const src = `${sourcePrefix}:${item.source || 'token'}`;
        const moduleName = moduleNameFromPageTokenSource(item.source || '');
        if (moduleName) {
          rememberModuleToken(moduleName, token, src);
          if (moduleName === 'gp' || moduleName === 'g') logBaseDiscovery('token', token, src);
        } else {
          logDiscovery('token', token, src);
        }
      }
    } catch (_) {}
  }

  function stopPageNetworkHook(reason = 'tokens-captured') {
    try {
      if (state.discovery) state.discovery.hookStopped = true;
      window.__istakipDiscoveryStopped = true;
      window.postMessage({ type: '__ISTAKIP_EYS_STOP_HOOK__', reason }, '*');
    } catch (_) {}
  }

  function maybeStopHooksAfterDiscovery(reason = 'discovery-update') {
    try {
      if (!state.discovery || state.discovery.hookStopped) return;
      if (discoveryHasEnoughTokens()) stopPageNetworkHook(reason);
    } catch (_) {}
  }


  const state = {
    jobs: [],
    eligibleJobs: [],
    running: false,
    stopRequested: false,
    discovery: {
      token: '',
      userId: '',
      orgoid: '',
      baseToken: '',
      baseUserId: '',
      baseOrgoid: '',
      baseUserLocked: false,
      baseOrgoidLocked: false,
      baseSource: { token: '', userId: '', orgoid: '' },
      pendingModule: '',
      tokensByModule: { gp: '', g: '', istakip: '', evdo: '', e: '' },
      tokenSourceByModule: { gp: '', g: '', istakip: '', evdo: '', e: '' },
      evdbRaporToken: '',
      evdbRaporTokenSource: '',
      evdbRaporTokenTime: 0,
      source: { token: '', userId: '', orgoid: '' },
      lastCmd: '',
      lastModuleName: '',
      lastUsedToken: '',
      lastUsedTokenSource: '',
      hookStopped: false,
      history: []
    },
    detailMap: {},
    ykStatusCache: new Map()
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = (sel, root = document) => root.querySelector(sel);

  function itHtmlEscape(v) {
    return String(v ?? '').replace(/[&<>"']/g, ch => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[ch]));
  }

  // v4.31.179: Memura Ata seçim ekranında kullanılan eski helper adı.
  // Bazı bloklar doğrudan escapeHtml(...) çağırıyor; global helper yoksa ReferenceError oluşuyordu.
  function escapeHtml(v) {
    return itHtmlEscape(v);
  }

  function textOf(el) {
    return ((el?.innerText || el?.textContent || el?.value || '') + '').replace(/\s+/g, ' ').trim();
  }

  function safeCall(obj, fn) {
    try { return obj && typeof obj[fn] === 'function' ? obj[fn]() : undefined; }
    catch (_) { return undefined; }
  }

  function isGenericUserValue(v) {
    const s = String(v || '').trim().toLowerCase();
    return !s || s === 'g.i.b.' || s === 'gib' || s === 'g.i.b' || s === 'gelir idaresi başkanlığı';
  }

  function isMeaningfulUserValue(v) {
    return !!String(v || '').trim() && !isGenericUserValue(v);
  }

  function logBaseDiscovery(kind, value, source) {
    if (!value) return;
    const next = String(value).trim();
    if (!next) return;
    const keyMap = { token: 'baseToken', userId: 'baseUserId', orgoid: 'baseOrgoid' };
    const srcKey = kind;
    const valueKey = keyMap[kind];
    if (!valueKey) return;

    if (kind === 'userId') {
      const current = String(state.discovery.baseUserId || '').trim();
      const locked = !!state.discovery.baseUserLocked;
      if (locked && current && current !== next) return;
      if (!current && isMeaningfulUserValue(next)) {
        state.discovery.baseUserId = next;
        state.discovery.baseSource[srcKey] = source;
        state.discovery.baseUserLocked = true;
        state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.userId <= ${next} (${source}) [locked]`);
        if (state.discovery.history.length > 60) state.discovery.history.shift();
        return;
      }
      if (current && isMeaningfulUserValue(current) && isGenericUserValue(next)) return;
    }

    if (kind === 'orgoid') {
      const current = String(state.discovery.baseOrgoid || '').trim();
      const locked = !!state.discovery.baseOrgoidLocked;
      if (locked && current && current !== next) return;
      if (!current && next) {
        state.discovery.baseOrgoid = next;
        state.discovery.baseSource[srcKey] = source;
        state.discovery.baseOrgoidLocked = true;
        state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.orgoid <= ${next} (${source}) [locked]`);
        if (state.discovery.history.length > 60) state.discovery.history.shift();
        return;
      }
    }

    if (state.discovery[valueKey] && state.discovery[valueKey] === next && state.discovery.baseSource[srcKey] == source) return;
    state.discovery[valueKey] = next;
    state.discovery.baseSource[srcKey] = source;
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.${kind} <= ${next} (${source})`);
    if (state.discovery.history.length > 60) state.discovery.history.shift();
  }

  function setPendingModule(moduleName, source='') {
    const m = normalizeModuleName(moduleName);
    if (!m) return;
    state.discovery.pendingModule = m;
    state.discovery.lastModuleName = m;
    if (source) {
      state.discovery.history.push(`[${new Date().toLocaleTimeString()}] pendingModule <= ${m} (${source})`);
      if (state.discovery.history.length > 60) state.discovery.history.shift();
    }
    persistDiscovery();
    renderDiscovery();
  }

  function normalizeModuleName(v) {
    const s = String(v || '').trim().toLowerCase();
    if (!s) return '';
    if (['gp', 'g', 'istakip', 'evdo', 'e'].includes(s)) return s;
    if (s.includes('istakip')) return 'istakip';
    if (s.includes('evdo') || s.includes('evdb')) return 'evdo';
    if (s === 'eys' || s.includes('edenetis') || s === 'e') return 'e';
    if (s.includes('gibintranet') || s == 'g') return 'g';
    if (s.includes('gp')) return 'gp';
    return s;
  }

  function moduleTokenPriority(moduleName, source) {
    const m = normalizeModuleName(moduleName);
    const s = String(source || '').toLowerCase();
    if (s.includes('pending-bound')) return 300;
    if (m === 'istakip') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:istakip')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'evdo') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:evdo')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'e') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:e')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'g' || m === 'gp') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 170;
      if (s.includes('side.get_service_def_list')) return 160;
      if (s.includes('assos-login-response')) return 150;
      if (s.includes('cssession.gettoken')) return 120;
    }
    return 50;
  }

  function rememberModuleToken(moduleName, token, source) {
    const m = normalizeModuleName(moduleName);
    const t = String(token || '').trim();
    if (!m || !t) return;
    const cur = state.discovery.tokensByModule[m] || '';
    const curSrc = state.discovery.tokenSourceByModule[m] || '';
    if (!cur || moduleTokenPriority(m, source) >= moduleTokenPriority(m, curSrc)) {
      state.discovery.tokensByModule[m] = t;
      state.discovery.tokenSourceByModule[m] = source;
      state.discovery.lastModuleName = m;
      state.discovery.history.push(`[${new Date().toLocaleTimeString()}] tokenByModule.${m} <= ${t} (${source})`);
      if (state.discovery.history.length > 40) state.discovery.history.shift();
      if (m === 'istakip') {
        state.discovery.token = t;
        state.discovery.source.token = `tokenByModule.${m} <= ${source}`;
      }
      persistDiscovery();
      renderDiscovery();
      try { maybeStopHooksAfterDiscovery(`tokenByModule.${m}`); } catch (_) {}
    }
  }

  function resolveTokenForModule(moduleName) {
    const m = normalizeModuleName(moduleName);
    if (m && state.discovery.tokensByModule[m]) return state.discovery.tokensByModule[m];
    const cssToken = safeGetCssToken(m);
    if (cssToken) return cssToken;
    if (!m) return state.discovery.token || getTokenFromUrl() || '';
    return '';
  }

  function sourcePriority(kind, source) {
    const s = String(source || '').toLowerCase();
    if (kind === 'token') {
      if (s.includes('module-bound')) return 260;
      if (s.includes('assos-login-response')) return 250;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 190;
      if (s.includes('assos-login') && s.includes('form-token')) return 130;
      if (s.includes('main.jsp')) return 100;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 90;
      if (s.includes('cssession.gettoken')) return 50;
      if (s.includes('url:token')) return 10;
    }
    if (kind === 'orgoid') {
      if (s.includes('akisislemleri_istakipsonrakiadimlaribul')) return 200;
      if (s.includes('akisislemleri_akisyeniadimkaydet')) return 190;
      if (s.includes('usersessionservice_getusersessioninfo')) return 170;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 150;
      if (s.includes('page-xhr') || s.includes('page-fetch')) return 70;
      if (s.includes('cssession.getorgoid')) return 50;
    }
    if (kind === 'userId') {
      if (s.includes('assos-login-response')) return 140;
      if (s.includes('usersessionservice_getusersessioninfo')) return 130;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 110;
      if (s.includes('page-xhr') || s.includes('page-fetch')) return 80;
      if (s.includes('cssession.getuserid')) return 60;
    }
    return 20;
  }

  function shouldOverwrite(kind, nextValue, nextSource) {
    const current = String(state.discovery[kind] || '').trim();
    const currentSource = state.discovery.source[kind] || '';
    if (!current) return true;
    if (current === String(nextValue).trim()) return sourcePriority(kind, nextSource) >= sourcePriority(kind, currentSource);
    return sourcePriority(kind, nextSource) >= sourcePriority(kind, currentSource);
  }

  function logDiscovery(kind, value, source) {
    if (!value) return;
    const next = String(value).trim();
    if (!next) return;
    if (!shouldOverwrite(kind, next, source)) return;
    const current = state.discovery[kind];
    if (current === next && state.discovery.source[kind] === source) return;
    state.discovery[kind] = next;
    state.discovery.source[kind] = source;
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] ${kind} <= ${next} (${source})`);
    if (state.discovery.history.length > 30) state.discovery.history.shift();
    persistDiscovery();
    renderDiscovery();
  }

  function persistDiscovery() {
    try {
      itChromeStorageSetSafe({ [CFG.DISCOVERY_KEY]: state.discovery });
    } catch (_) {}
  }

  function restoreDiscovery(cb) {
    try {
      itChromeStorageGetSafe([CFG.DISCOVERY_KEY], out => {
        const d = out?.[CFG.DISCOVERY_KEY];
        if (d && typeof d === 'object') {
          state.discovery = {
            token: d.token || '',
            userId: d.userId || '',
            orgoid: d.orgoid || '',
            baseToken: d.baseToken || '',
            baseUserId: d.baseUserId || '',
            baseOrgoid: d.baseOrgoid || '',
            baseUserLocked: !!d.baseUserLocked,
            baseOrgoidLocked: !!d.baseOrgoidLocked,
            baseSource: d.baseSource || { token: '', userId: '', orgoid: '' },
            pendingModule: d.pendingModule || '',
            tokensByModule: d.tokensByModule || { gp: '', g: '', istakip: '', evdo: '', e: '' },
            tokenSourceByModule: d.tokenSourceByModule || { gp: '', g: '', istakip: '', evdo: '', e: '' },
            source: d.source || { token: '', userId: '', orgoid: '' },
            lastCmd: d.lastCmd || '',
            lastModuleName: d.lastModuleName || '',
            lastUsedToken: d.lastUsedToken || '',
            lastUsedTokenSource: d.lastUsedTokenSource || '',
            evdbRaporToken: d.evdbRaporToken || '',
            evdbRaporTokenSource: d.evdbRaporTokenSource || '',
            evdbRaporTokenTime: Number(d.evdbRaporTokenTime) || 0,
            hookStopped: false,
            history: Array.isArray(d.history) ? d.history.slice(-50) : []
          };
        }
        cb?.();
      });
    } catch (_) { cb?.(); }
  }


  function safeGetCssToken(moduleName) {
    try {
      const css = window.CSSession || {};
      if (typeof css.getToken === 'function') {
        return moduleName ? css.getToken(moduleName) : css.getToken();
      }
      return css.token || '';
    } catch (_) { return ''; }
  }

  function deepScan(obj, out = {}, depth = 0, seen = new WeakSet()) {
    try {
      if (!obj || typeof obj !== 'object' || depth > 6) return out;
      if (seen.has(obj)) return out;
      seen.add(obj);
      const pick = (key, val) => {
        if (val === undefined || val === null || val === '') return;
        const k = String(key || '').toLowerCase();
        const v = typeof val === 'string' ? val.trim() : val;
        if (!v) return;
        if (!out.token && k === 'token') out.token = v;
        if (!out.orgoid && k === 'orgoid') out.orgoid = v;
        if (!out.userId && /^(userid|kullanicikodu|atamayapankullaniciuserid|islemyapanuserid)$/i.test(String(key))) out.userId = v;
        if (!out.moduleName && /^(moduladi|modulename|module|modul)$/i.test(String(key))) out.moduleName = v;
      };
      if (Array.isArray(obj)) {
        obj.forEach(v => deepScan(v, out, depth + 1, seen));
        return out;
      }
      for (const [k, v] of Object.entries(obj)) {
        pick(k, v);
        if (typeof v === 'string') {
          const j = parseMaybeJson(v);
          if (j) deepScan(j, out, depth + 1, seen);
        } else if (v && typeof v === 'object') {
          deepScan(v, out, depth + 1, seen);
        }
      }
    } catch (_) {}
    return out;
  }

  function getTokenFromUrl() {
    return new URLSearchParams(location.search).get('token') || '';
  }

  function learnFromObject(obj, source) {
    if (!obj || typeof obj !== 'object') return;
    const found = deepScan(obj, {});
    const maybeUser = found.userId;
    const maybeOrg = found.orgoid;
    const maybeToken = found.token;
    const moduleName = normalizeModuleName(found.moduleName || obj.moduleName || obj.modulAdi || obj.module || '');
    if (moduleName) state.discovery.lastModuleName = moduleName;
    if (maybeUser) logDiscovery('userId', maybeUser, source);
    if (maybeOrg) logDiscovery('orgoid', maybeOrg, source);
    if (maybeToken) {
      logDiscovery('token', maybeToken, source);
      if (moduleName) rememberModuleToken(moduleName, maybeToken, source);
      else if (/assos-login-response/i.test(source) && /istakip/i.test(location.href)) {
        rememberModuleToken('istakip', maybeToken, source + ':location-bound');
      }
    }
  }

  function learnFromStorageBag(source, bag) {
    if (!bag) return;
    try {
      for (let i = 0; i < bag.length; i++) {
        const k = bag.key(i);
        const v = bag.getItem(k);
        if (!v) continue;
        if (!state.discovery.token && /token/i.test(k) && String(v).length > 10) logDiscovery('token', v, `${source}:${k}`);
        if (!state.discovery.orgoid && /org.?oid/i.test(k) && String(v).trim()) logDiscovery('orgoid', v, `${source}:${k}`);
        if (!state.discovery.userId && /(user.?id|userid|kullanici)/i.test(k) && String(v).trim()) logDiscovery('userId', v, `${source}:${k}`);
        if ((v.startsWith('{') || v.startsWith('[')) && v.length < 50000) {
          try { learnFromObject(JSON.parse(v), `${source}:${k}`); } catch (_) {}
        }
      }
    } catch (_) {}
  }

  function discoverFromPage() {
    const css = window.CSSession || {};
    logBaseDiscovery('token', getTokenFromUrl(), 'url:token');
    logDiscovery('token', getTokenFromUrl(), 'url:token');
    logBaseDiscovery('token', safeGetCssToken('gp') || safeGetCssToken(), 'CSSession.getToken:base');
    logDiscovery('token', safeGetCssToken('istakip') || safeGetCssToken('gp') || safeGetCssToken(), 'CSSession.getToken');
    ['gp','g','istakip','evdo','e'].forEach(m => {
      const mt = safeGetCssToken(m);
      if (mt) rememberModuleToken(m, mt, `CSSession.getToken:${m}`);
    });
    const cssUser = safeCall(css, 'getUserId') || css.userId || css.userid || css.USERID || css.kullaniciKodu;
    const cssOrg = safeCall(css, 'getOrgOid') || css.orgOid || css.orgoid || window.orgOid || window.ORGOID;
    logBaseDiscovery('userId', cssUser, 'CSSession.getUserId:base');
    logBaseDiscovery('orgoid', cssOrg, 'CSSession.getOrgOid:base');
    logDiscovery('userId', cssUser, 'CSSession.getUserId');
    logDiscovery('orgoid', cssOrg, 'CSSession.getOrgOid');
    learnFromObject(window.userSession || window.session || window.__session || {}, 'window.session');
    learnFromStorageBag('localStorage', window.localStorage);
    learnFromStorageBag('sessionStorage', window.sessionStorage);
    maybeStopHooksAfterDiscovery('discoverFromPage');
  }

  function parseMaybeJson(str) {
    if (!str || typeof str !== 'string') return null;
    const s = str.trim();
    if (!s || (s[0] !== '{' && s[0] !== '[')) return null;
    try { return JSON.parse(s); } catch { return null; }
  }

  function inspectPayload(cmd, payload, source) {
    if (cmd) state.discovery.lastCmd = cmd;
    if (!payload || typeof payload !== 'object') return;
    learnFromObject(payload, source + (cmd ? `:${cmd}` : ''));
    if (payload.jp && typeof payload.jp === 'string') {
      const parsed = parseMaybeJson(payload.jp);
      if (parsed) learnFromObject(parsed, `${source}:jp` + (cmd ? `:${cmd}` : ''));
    }
    if (payload.sorgulamaKriterleri) learnFromObject(payload.sorgulamaKriterleri, `${source}:sorgulamaKriterleri`);
  }

  function inspectBody(body, source) {
    if (!body) return;
    try {
      if (typeof body === 'string') {
        const usp = new URLSearchParams(body);
        if ([...usp.keys()].length) {
          const cmd = usp.get('cmd') || '';
          const token = usp.get('token') || '';
          const jpText = usp.get('jp') || '';
          if (token) logDiscovery('token', token, `${source}:form-token` + (cmd ? `:${cmd}` : ''));
          if (jpText) {
            const jp = parseMaybeJson(jpText);
            if (jp) inspectPayload(cmd, jp, `${source}:form-jp`);
          }
        } else {
          const parsed = parseMaybeJson(body);
          if (parsed) inspectPayload('', parsed, `${source}:json-body`);
        }
      } else if (body instanceof URLSearchParams) {
        inspectBody(body.toString(), source);
      } else if (typeof FormData !== 'undefined' && body instanceof FormData) {
        const data = {};
        for (const [k, v] of body.entries()) data[k] = v;
        inspectPayload(data.cmd || '', data, `${source}:formdata`);
      }
    } catch (_) {}
  }

  function patchNetwork() {
    if (window.__istakipDiscoveryPatched) return;
    window.__istakipDiscoveryPatched = true;

    const origFetch = window.fetch;
    if (origFetch) {
      window.fetch = async function(...args) {
        try {
          const [input, init] = args;
          const url = typeof input === 'string' ? input : input?.url || '';
          const body = init?.body || (typeof input !== 'string' ? input?.body : undefined);
          if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch|assos-login|index\.jsp/i.test(url)) inspectBody(body, `fetch:${url}`);
        } catch (_) {}
        const res = await origFetch.apply(this, args);
        try {
          const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
          if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch|assos-login/i.test(url)) {
            const clone = res.clone();
            clone.text().then(txt => {
              const parsed = parseMaybeJson(txt);
              if (parsed) learnFromObject(parsed?.data || parsed, `fetch-response:${url}`);
            }).catch(() => {});
          }
        } catch (_) {}
        return res;
      };
    }

    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__it_url = url;
      this.__it_method = method;
      return origOpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(body) {
      try {
        if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch|assos-login|index\.jsp/i.test(this.__it_url || '')) inspectBody(body, `xhr:${this.__it_url}`);
        this.addEventListener('load', () => {
          try {
            if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch|assos-login/i.test(this.__it_url || '')) {
              const parsed = parseMaybeJson(this.responseText);
              if (parsed) learnFromObject(parsed?.data || parsed, `xhr-response:${this.__it_url}`);
            }
          } catch (_) {}
        });
      } catch (_) {}
      return origSend.call(this, body);
    };
  }

  function getDiscovered(moduleName = 'istakip') {
    discoverFromPage();
    const m = normalizeModuleName(moduleName || 'istakip') || 'istakip';
    return {
      token: resolveTokenForModule(m),
      userId: state.discovery.baseUserId || state.discovery.userId || '',
      orgoid: state.discovery.baseOrgoid || state.discovery.orgoid || '',
      tokensByModule: Object.assign({}, state.discovery.tokensByModule),
      moduleName: m
    };
  }

  function makeCallId() {
    return `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
  }

  async function post(cmd, jp) {
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', makeCallId());
    const discovered = getDiscovered('istakip');
    const token = discovered.token;
    if (!token) {
      throw new Error(`İş Takip tokenı bulunamadı. pendingModule=${state.discovery.pendingModule || '-'} baseToken=${state.discovery.baseToken ? 'var' : 'yok'} istakipToken=${state.discovery.tokensByModule?.istakip ? 'var' : 'yok'}`);
    }
    p.append('token', token);
    state.discovery.lastUsedToken = token;
    state.discovery.lastUsedTokenSource = state.discovery.tokenSourceByModule?.istakip || 'resolveTokenForModule(istakip)';
    const jpText = JSON.stringify(jp || {});
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] outbound:${cmd} jp=${jpText}`);
    if (state.discovery.history.length > 80) state.discovery.history.shift();
    persistDiscovery();
    renderDiscovery();
    p.append('jp', jpText);

    const res = await fetch(CFG.DISPATCH_URL, {
      method: 'POST',
      body: p,
      credentials: 'include',
      cache: 'no-store'
    });
    if (!res.ok) throw new Error(`Ağ hatası ${res.status} (${cmd})`);
    const txt = await res.text();
    try { return JSON.parse(txt); } catch { return txt; }
  }

  function exposeIstakipDiscoveryBridge() {
    try {
      window.__istakipBotGetDiscovered = (moduleName = 'istakip') => {
        try { return getDiscovered(moduleName || 'istakip'); } catch (_) { return {}; }
      };
      window.__istakipBotResolveToken = (moduleName = 'istakip') => {
        try { return resolveTokenForModule(moduleName || 'istakip') || ''; } catch (_) { return ''; }
      };
      window.__istakipBotDiscoverFromPage = () => {
        try {
          discoverFromPage();
          persistDiscovery();
          renderDiscovery();
          return getDiscovered('istakip');
        } catch (_) { return {}; }
      };
      window.__istakipBotPostIstakip = async (cmd, jp) => {
        return await post(cmd, jp);
      };
    } catch (_) {}
  }
  exposeIstakipDiscoveryBridge();

  function injectStyle() {
    if (document.getElementById(CFG.STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = CFG.STYLE_ID;
    s.textContent = `
      #${CFG.PANEL_ID}{position:fixed;top:118px;right:16px;left:auto;width:min(980px, calc(100vw - 32px));height:min(660px, calc(100vh - 140px));max-width:calc(100vw - 32px);max-height:calc(100vh - 140px);min-width:540px;min-height:320px;overflow:hidden;resize:none;z-index:2147483647;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.38);font:12px/1.35 'Segoe UI',Arial,sans-serif;display:flex;flex-direction:column}
      #${CFG.PANEL_ID} *{box-sizing:border-box}
      #${CFG.PANEL_ID}.collapsed{width:300px!important;height:38px!important;min-height:38px!important;max-height:38px!important;overflow:hidden!important}
      #${CFG.PANEL_ID}.collapsed .body{display:none!important}
      #${CFG.PANEL_ID} .hdr{display:flex;justify-content:space-between;align-items:center;padding:4px 8px;background:#0d1b31;border-bottom:1px solid #22324f;border-radius:14px 14px 0 0;cursor:move;user-select:none;touch-action:none;height:44px;flex:0 0 44px;box-sizing:border-box}
      #${CFG.PANEL_ID} .body{padding:10px;flex:1 1 auto;min-height:0;max-height:none;overflow:auto;background:#08111f;display:flex;flex-direction:column}
      #${CFG.PANEL_ID} #it_main_tab_page{display:flex;flex-direction:column;min-height:0;flex:1 1 auto;width:100%}
      #${CFG.PANEL_ID} #it_eys_tab_page{min-height:0;flex:1 1 auto;width:100%}
      #${CFG.PANEL_ID} .row{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .row3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .row4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} label{display:block;font-size:11px;color:#9fb4d2;margin-bottom:2px}
      #${CFG.PANEL_ID} input,#${CFG.PANEL_ID} select{width:100%;padding:5px 7px;border-radius:7px;border:1px solid #314867;background:#081523;color:#eaf2ff}
      #${CFG.PANEL_ID} input[readonly]{background:#0d1524;color:#b9cae8}
      #${CFG.PANEL_ID} button{padding:9px 10px;border-radius:7px;border:0;cursor:pointer;font-weight:600}
      #${CFG.PANEL_ID} .btn-green{background:#39d98a;color:#032611}
      #${CFG.PANEL_ID} .btn-blue{background:#3478f6;color:#fff}
      #${CFG.PANEL_ID} .btn-violet{background:#8b5cf6;color:#fff}
      #${CFG.PANEL_ID} .btn-red{background:#dc4c4c;color:#fff}
      #${CFG.PANEL_ID} .btn-amber{background:#f59e0b;color:#111}
      #${CFG.PANEL_ID} .mini{width:28px;height:28px;padding:0;background:#132643;color:#fff;border:1px solid #38527a}
      #${CFG.PANEL_ID} .sub{font-size:11px;color:#95a8c4;margin:6px 0 10px}
      #${CFG.PANEL_ID} .it-token-status{font-size:11px;line-height:1.35;background:#061426;border:1px solid #284569;border-radius:8px;padding:6px 8px;margin:0 0 8px 0;color:#dcecff;display:block!important;flex:0 0 auto}
      #${CFG.PANEL_ID} .it-token-status .ok{color:#72f5a4;font-weight:700}
      #${CFG.PANEL_ID} .it-token-status .no{color:#ff8f8f;font-weight:700}
      #${CFG.PANEL_ID} .it-token-status .src{color:#92a7c7;font-size:10px}
      #${CFG.PANEL_ID} .log{height:82px;min-height:82px;max-height:82px;overflow:auto;background:#02060d;color:#9cff9c;font-family:ui-monospace,monospace;border:1px solid #1f2d42;padding:6px;border-radius:10px;resize:vertical}
      #${CFG.PANEL_ID} .disc{background:#091525;border:1px solid #233752;border-radius:10px;padding:8px;margin-bottom:8px}
      #${CFG.PANEL_ID} .kv{display:grid;grid-template-columns:110px 1fr;gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .muted{color:#8ca0bf}
      #${CFG.PANEL_ID} table{width:max-content;min-width:100%;border-collapse:collapse;margin-top:8px;font-size:11px;table-layout:fixed}
      #${CFG.PANEL_ID} th,#${CFG.PANEL_ID} td{border-bottom:1px solid #1f2d42;padding:6px 4px;vertical-align:top;text-align:left;overflow-wrap:anywhere}
      #${CFG.PANEL_ID} .it-resizable-table th{position:relative;user-select:none}
      #${CFG.PANEL_ID} .it-resizable-table th.it-sortable{cursor:pointer}
      #${CFG.PANEL_ID} .it-resizable-table th.it-sortable:hover{background:#132846}
      #${CFG.PANEL_ID} .it-sort-ind{font-size:10px;color:#93c5fd;margin-left:4px}
      #${CFG.PANEL_ID} .it-col-resizer{position:absolute;right:-3px;top:0;width:7px;height:100%;cursor:col-resize;z-index:8;background:transparent}
      #${CFG.PANEL_ID} .it-col-resizer:hover,#${CFG.PANEL_ID} .it-col-resizer.active{background:rgba(96,165,250,.35)}
      body.it-col-resizing{cursor:col-resize!important;user-select:none!important}
      #${CFG.PANEL_ID} .eligible{color:#88ffb2;font-weight:700}
      #${CFG.PANEL_ID} .bad{color:#ff8f8f}
      #${CFG.PANEL_ID} .tblwrap{max-height:420px;overflow:auto;border:1px solid #1f2d42;border-radius:10px}
      #${CFG.PANEL_ID} .tiny{font-size:10px;color:#99a7c0}

      #${CFG.PANEL_ID} .yk-line{display:block;line-height:1.25;margin:1px 0;white-space:normal}
      #${CFG.PANEL_ID} .it-mersis-islem-bilgisi{white-space:normal!important;overflow-wrap:anywhere!important;word-break:break-word!important;line-height:1.25}
      #${CFG.PANEL_ID} .yk-kod .preview-link{font-family:monospace;font-size:11px}
      #${CFG.PANEL_ID} .yk-muted{color:#8b98b7}

      #${CFG.PANEL_ID} .it-module-tabs{display:flex;gap:6px;margin:0 0 8px 0;padding:6px;border:1px solid #273048;border-radius:8px;background:#071225}
      #${CFG.PANEL_ID} .it-module-tab{flex:1;padding:8px 10px;border:1px solid #33415f;border-radius:7px;background:#0b1729;color:#cbd7eb;font-weight:700;cursor:pointer}
      #${CFG.PANEL_ID} .it-module-tab.active{background:#2563eb;color:#fff;border-color:#60a5fa}

      #${CFG.PANEL_ID} .it-main-advanced{display:none !important}
      #${CFG.PANEL_ID} .it-resize-left{position:absolute;left:-5px;top:44px;bottom:12px;width:10px;cursor:ew-resize;z-index:25}
      #${CFG.PANEL_ID} .it-resize-bottom{position:absolute;left:12px;right:12px;bottom:-5px;height:10px;cursor:ns-resize;z-index:25}
      #${CFG.PANEL_ID} .it-resize-bottom-left{position:absolute;left:-7px;bottom:-7px;width:18px;height:18px;cursor:nesw-resize;z-index:30;border-left:2px solid rgba(96,165,250,.65);border-bottom:2px solid rgba(96,165,250,.65);border-bottom-left-radius:10px;background:rgba(37,99,235,.10)}
      #${CFG.PANEL_ID} .it-resize-left:hover,#${CFG.PANEL_ID} .it-resize-bottom:hover,#${CFG.PANEL_ID} .it-resize-bottom-left:hover{background:rgba(96,165,250,.18)}
      #${CFG.PANEL_ID} .hdr,#${CFG.PANEL_ID} label,#${CFG.PANEL_ID} button{user-select:none}
      #eys-tabbed-bot-panel.it-embedded-eys{position:relative!important;top:auto!important;right:auto!important;left:auto!important;bottom:auto!important;width:100%!important;max-width:none!important;z-index:auto!important;box-shadow:none!important;margin:0!important;border-radius:8px!important}
      #eys-tabbed-bot-panel.it-embedded-eys>.h{display:none!important}


      #${CFG.PANEL_ID} .hide-above-buttons{display:none !important}
      #${CFG.PANEL_ID} .vkn-range-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0 8px 0}
      #${CFG.PANEL_ID} .vkn-range-row input{height:28px;min-height:28px;padding:4px 8px}
#${CFG.PANEL_ID} .disc{display:block !important}
      #${CFG.PANEL_ID} .tokcard{display:block !important}
      #${CFG.PANEL_ID} .tiny{font-size:10px;color:#99a7c0}
      #${CFG.PANEL_ID} .hide-above-buttons{display:none !important}
      #${CFG.PANEL_ID} .vkn-range-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0 8px 0}
      #${CFG.PANEL_ID} .vkn-range-row input{height:28px;min-height:28px;padding:4px 8px}
      #${CFG.PANEL_ID} .disc{max-height:none !important;overflow:visible !important;background:#091525}
      #${CFG.PANEL_ID} .disc > .row3,
      #${CFG.PANEL_ID} .disc > .row,
      #${CFG.PANEL_ID} .disc > .tokcard,
      #${CFG.PANEL_ID} .disc > .tokgrid,
      #${CFG.PANEL_ID} .disc > .sub,
      #${CFG.PANEL_ID} .disc > .tiny{display:none !important}
      #${CFG.PANEL_ID} .disc .vkn-range-row{display:grid !important}
      #${CFG.PANEL_ID} .it-module-tabs{flex:0 0 auto}

      #${CFG.PANEL_ID} .tblwrap thead th{position:sticky;top:0;z-index:5;background:#0d1b31}
      #${CFG.PANEL_ID} .disc{padding:4px;margin-bottom:6px;max-height:120px;overflow:auto}
      #${CFG.PANEL_ID} .tokcard{margin:4px 0 !important;padding:4px !important;max-height:90px;overflow:auto}
      #${CFG.PANEL_ID} .sub{margin:4px 0 6px 0;font-size:11px}
      #${CFG.PANEL_ID} .disc{max-height:none !important;overflow:visible !important;background:#091525 !important}
      #${CFG.PANEL_ID} .disc > .row3,
      #${CFG.PANEL_ID} .disc > .row,
      #${CFG.PANEL_ID} .disc > .tokcard,
      #${CFG.PANEL_ID} .disc > .tokgrid,
      #${CFG.PANEL_ID} .disc > .sub,
      #${CFG.PANEL_ID} .disc > .tiny{display:none !important}


      #${CFG.PANEL_ID} .it-main-actions{position:static!important;top:auto!important;height:auto!important;min-height:0!important;max-height:none!important;overflow:visible!important;background:transparent!important;padding:0!important;margin:6px 0 8px 0!important;display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:6px!important}
      #${CFG.PANEL_ID} .it-main-actions button,#${CFG.PANEL_ID} #it_scan,#${CFG.PANEL_ID} #it_send,#${CFG.PANEL_ID} #it_refresh{height:38px!important;min-height:38px!important;max-height:38px!important;padding:0 10px!important;line-height:1.15!important;display:flex!important;align-items:center!important;justify-content:center!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}
      #${CFG.PANEL_ID} #it_log{display:block!important;height:82px!important;min-height:82px!important;max-height:82px!important;overflow:auto!important;resize:vertical!important}
      #${CFG.PANEL_ID} .tblwrap{display:block!important;max-height:360px!important;overflow:auto!important;min-height:120px!important}
      /* v4.31.72: Ana Modül üst VKN Başlangıç/Bitiş alanı kaldırıldı; keşif alanları DOM'da kalsa da görünmez. */
      #${CFG.PANEL_ID} .disc{display:none!important;max-height:0!important;overflow:hidden!important;padding:0!important;margin:0!important;background:transparent!important}

      /* v4.31.56: Ana modül sonradan yeniden düzenlenince alt alan siyah boşlukta kalmasın. */
      #${CFG.PANEL_ID} #it_main_tab_page{display:flex!important;flex-direction:column!important;min-height:0!important;flex:1 1 auto!important;overflow:hidden!important}
      #${CFG.PANEL_ID} #it_main_tab_page > .disc{display:none!important;flex:0 0 0!important;height:0!important;min-height:0!important;padding:0!important;margin:0!important}
      #${CFG.PANEL_ID} #it_main_tab_page > .it-main-actions{flex:0 0 38px!important}
      #${CFG.PANEL_ID} #it_main_tab_page > #it_stop{flex:0 0 auto!important}
      #${CFG.PANEL_ID} #it_main_tab_page > .sub{display:block!important;flex:0 0 auto!important;margin:4px 0 6px!important;font-size:11px!important;line-height:1.25!important}
      #${CFG.PANEL_ID} #it_main_tab_page > #it_log{display:block!important;flex:0 0 82px!important;height:82px!important;min-height:82px!important;max-height:82px!important}
      #${CFG.PANEL_ID} #it_main_tab_page > .tblwrap{display:block!important;flex:1 1 auto!important;min-height:160px!important;max-height:none!important;overflow:auto!important;background:#07101d!important}

      #it_preview_modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.58);z-index:2147483647;padding:20px}
      #it_preview_modal.open{display:flex}
      #it_preview_box{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:min(1280px,96vw);height:min(900px,92vh);min-width:520px;min-height:320px;background:#fff;border-radius:12px;overflow:hidden;resize:both;box-shadow:0 20px 50px rgba(0,0,0,.45);display:flex;flex-direction:column;border:1px solid #cfd8e3}
      #it_preview_head{height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;background:#0d1b31;color:#fff;border-bottom:1px solid #22324f;flex:0 0 auto;cursor:move;user-select:none}
      #it_preview_title{font:600 14px/1.2 'Segoe UI',Arial,sans-serif;padding-right:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #it_preview_actions{display:flex;gap:8px;align-items:center}
      #it_preview_actions .it-btn-mini{padding:7px 10px;border-radius:7px;border:1px solid #38527a;background:#132643;color:#fff;cursor:pointer;font:600 12px/1 'Segoe UI',Arial,sans-serif}
      #it_preview_frame{width:100%;height:100%;border:0;display:block;background:#eef3f8;flex:1 1 auto}
      #it_preview_msg{padding:16px;font:13px/1.5 'Segoe UI',Arial,sans-serif;color:#17212f;background:#fff;border-top:1px solid #e5ebf3;flex:0 0 auto}
    `;
    document.head.appendChild(s);
    try {
      const fix = document.createElement('style');
      fix.id = 'istakip-yoklama-bot-layout57';
      fix.textContent = `
        #${CFG.PANEL_ID} .body{overflow:auto!important;display:block!important;background:#08111f!important;}
        #${CFG.PANEL_ID} #it_main_tab_page{display:block;overflow:visible!important;min-height:auto!important;}
        #${CFG.PANEL_ID} #it_main_tab_page > .disc{display:none!important;height:0!important;min-height:0!important;padding:0!important;margin:0!important;overflow:hidden!important;}
        #${CFG.PANEL_ID} #it_main_tab_page[style*="display: none"]{display:none!important;}
        #${CFG.PANEL_ID} .it-main-actions{height:auto!important;max-height:none!important;overflow:visible!important;display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:6px!important;margin:6px 0 8px!important;}
        #${CFG.PANEL_ID} .it-main-actions button{height:38px!important;min-height:38px!important;max-height:38px!important;}
        #${CFG.PANEL_ID} #it_log{height:82px!important;min-height:82px!important;display:block!important;overflow:auto!important;}
        #${CFG.PANEL_ID} .tblwrap{display:block!important;min-height:180px!important;max-height:360px!important;overflow:auto!important;background:#07101d!important;border:1px solid #1f2d46!important;border-radius:8px!important;}
      `;
      document.head.appendChild(fix);
    } catch (_) {}
  }

  function createPanel() {
    const existing = document.getElementById(CFG.PANEL_ID);
    if (existing) return existing;
    const el = document.createElement('div');
    el.id = CFG.PANEL_ID;
    el.innerHTML = `
      <div class="it-resize-left" title="Sola doğru genişlet/daralt"></div>
      <div class="it-resize-bottom" title="Aşağı doğru büyüt/küçült"></div>
      <div class="it-resize-bottom-left" title="Sol alt köşeden büyüt/küçült"></div>
      <div class="hdr">
        <strong class="drag-title">İş Takip + EYS Botu v4.31.185</strong>
        <div>
          <button class="mini" id="it_toggle" title="Gövdeyi aç/kapat">−</button>
          <button class="mini" id="it_panel_reset" title="Boyut ve konumu sıfırla">□</button>
          <button class="mini" id="it_close" style="color:#ff8f8f" title="Kapat">×</button>
        </div>
      </div>
      <div class="body" id="it_wrap">
        <div class="it-token-status" id="it_token_status">Token durumu hazırlanıyor...</div>
        <div class="disc">
          <div class="vkn-range-row" style="display:none!important">
          <div><label>VKN Başlangıç</label><input id="it_vkn_start" placeholder="örn 0000000000"></div>
          <div><label>VKN Bitiş</label><input id="it_vkn_end" placeholder="örn 3000000000"></div>
        </div>
        <div class="row3" style="margin-bottom:6px">
            <div><label>Keşfedilen Kullanıcı</label><input id="it_user" readonly></div>
            <div><label>Keşfedilen OrgOid</label><input id="it_orgoid" readonly></div>
            <div><label>Keşfedilen Token</label><input id="it_token" readonly></div>
          </div>
          <div class="row3" style="margin-bottom:0">
            <div class="tiny" id="it_user_src"></div>
            <div class="tiny" id="it_org_src"></div>
            <div class="tiny" id="it_tok_src"></div>
          </div>
          <div class="tokcard" style="margin:8px 0">
            <div class="tokname">İlk Giriş Oturumu</div>
            <div class="tokval" id="it_base_tok">-</div>
            <div class="toksrc" id="it_base_tok_src">Token kaynağı: -</div>
            <div class="tokval" id="it_base_user">-</div>
            <div class="toksrc" id="it_base_user_src">Kullanıcı kaynağı: -</div>
            <div class="tokval" id="it_base_org">-</div>
            <div class="toksrc" id="it_base_org_src">OrgID kaynağı: -</div>
          </div>
          <div class="sub" id="it_used_tok">Kullanılan İş Takip tokenı: -</div>
          <div class="sub" id="it_used_tok_src">Kullanılan token kaynağı: -</div>
          <div class="row" style="margin-top:6px;margin-bottom:0">
            <button class="btn-violet" id="it_discover">XHR KEŞFİNİ YENİLE</button>
            <div class="tiny" id="it_last_cmd"></div>
          </div>
          <div class="tokgrid">
            <div class="tokcard"><div class="tokname">İş Takip (istakip)</div><div class="tokval" id="it_tok_istakip">-</div><div class="toksrc" id="it_toksrc_istakip">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">EVDB (evdo)</div><div class="tokval" id="it_tok_evdo">-</div><div class="toksrc" id="it_toksrc_evdo">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">EYS (e)</div><div class="tokval" id="it_tok_e">-</div><div class="toksrc" id="it_toksrc_e">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">GİB İntranet (g)</div><div class="tokval" id="it_tok_g">-</div><div class="toksrc" id="it_toksrc_g">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">Portal (gp)</div><div class="tokval" id="it_tok_gp">-</div><div class="toksrc" id="it_toksrc_gp">Kaynak: -</div></div>
          </div>
          <div class="tiny" style="margin-top:6px">Eklenti açılır açılmaz sayfa bağlamında XHR/fetch dinlenir. İlk tıkladığın işte giden sorgulardan orgoid, userId, akisOid ve cmd yakalanır.</div>
        </div>
        <div class="row4 hide-above-buttons">
          <div><label>Vergi No / TCKN / Ünvan</label><input id="it_filter" placeholder="Boş = hepsi"></div>
          <div><label>İş Takip No</label><input id="it_istakip" placeholder="İsteğe bağlı"></div>
          <div><label>İş Tipi</label><input id="it_istipi" value="5"></div>
          <div><label>Sonuç limiti</label><input id="it_limit" value="50"></div>
        </div>
        <div class="row4 it-main-advanced">
          <div><label>Uygun değil işleri sil</label><select id="it_atama_sil"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div>
          <div><label>hedefDurumNo</label><input id="it_hedef_durum" value="4"></div>
          <div><label>akisDurumTip</label><input id="it_durum_tip" value="21"></div>
          <div><label>islemSahibi</label><input id="it_islem_sahibi" value="3"></div>
        </div>
        <div class="row3 it-main-advanced">
          <div><label>isiUzerimeAl</label><select id="it_uzerime_al"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div>
          <div><label>Manuel OrgOid (boş kalırsa keşfedilen)</label><input id="it_orgoid_override" placeholder="İsteğe bağlı"></div>
          <div><label>Manuel UserId (boş kalırsa keşfedilen)</label><input id="it_user_override" placeholder="İsteğe bağlı"></div>
        </div>
        <div class="row3 it-main-actions">
          <button class="btn-green" id="it_scan">İŞLERİ TARA</button>
          <button class="btn-blue" id="it_send">UYGUNLARI GÖNDER</button>
          <button class="btn-amber" id="it_refresh">LİSTEYİ YENİLE</button>
        </div>
        <button class="btn-red" id="it_stop" style="display:none;width:100%;margin-bottom:8px">DURDUR</button>
        <div class="sub">Akış: auto-discovery ile token / userId / orgoid bul → işleri çek → sonraki adımları kontrol et → uygun olanları <b>akisIslemleri_akisYeniAdimKaydet</b> ile gönder.</div>
        <div class="log" id="it_log"></div>
        <div class="tblwrap">
          <table id="it_jobs_table" class="it-resizable-table">
            <colgroup id="it_jobs_colgroup"></colgroup>
            <thead id="it_jobs_thead"></thead>
            <tbody id="it_rows"></tbody>
          </table>
        </div>
      </div>`;
    (document.body || document.documentElement).appendChild(el);
    return el;
  }

  function renderDiscovery() {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    const shortTok = v => v ? `${String(v).slice(0, 22)}...` : '-';
    const setVal = (sel, val) => { const el = $(sel, panel); if (el) el.value = val; };
    const setTxt = (sel, val) => { const el = $(sel, panel); if (el) el.textContent = val; };

    const shownUser = state.discovery.baseUserId || state.discovery.userId || '';
    const shownOrg = state.discovery.baseOrgoid || state.discovery.orgoid || '';
    const ist = state.discovery.tokensByModule?.istakip || state.discovery.token || '';

    setVal('#it_user', shownUser);
    setVal('#it_orgoid', shownOrg);
    setVal('#it_token', ist ? `${ist.slice(0, 18)}...` : '');

    setTxt('#it_user_src', state.discovery.baseSource?.userId ? `Kaynak: ${state.discovery.baseSource.userId} (ilk giriş)` : (state.discovery.source.userId ? `Kaynak: ${state.discovery.source.userId}` : 'Kaynak: -'));
    setTxt('#it_org_src', state.discovery.baseSource?.orgoid ? `Kaynak: ${state.discovery.baseSource.orgoid} (ilk giriş)` : (state.discovery.source.orgoid ? `Kaynak: ${state.discovery.source.orgoid}` : 'Kaynak: -'));
    setTxt('#it_tok_src', state.discovery.tokenSourceByModule?.istakip ? `İş Takip token kaynağı: ${state.discovery.tokenSourceByModule.istakip}` : (state.discovery.source.token ? `Genel token kaynağı: ${state.discovery.source.token}` : 'Kaynak: -'));

    setTxt('#it_base_tok', state.discovery.baseToken ? `${String(state.discovery.baseToken).slice(0,22)}...` : '-');
    setTxt('#it_base_tok_src', state.discovery.baseSource?.token ? `Token kaynağı: ${state.discovery.baseSource.token}` : 'Token kaynağı: -');
    setTxt('#it_base_user', state.discovery.baseUserId || '-');
    setTxt('#it_base_user_src', state.discovery.baseSource?.userId ? `Kullanıcı kaynağı: ${state.discovery.baseSource.userId}` : 'Kullanıcı kaynağı: -');
    setTxt('#it_base_org', state.discovery.baseOrgoid || '-');
    setTxt('#it_base_org_src', state.discovery.baseSource?.orgoid ? `OrgID kaynağı: ${state.discovery.baseSource.orgoid}` : 'OrgID kaynağı: -');

    setTxt('#it_used_tok', state.discovery.lastUsedToken ? `Kullanılan İş Takip tokenı: ${String(state.discovery.lastUsedToken).slice(0,22)}...` : 'Kullanılan İş Takip tokenı: -');
    setTxt('#it_used_tok_src', state.discovery.lastUsedTokenSource ? `Kullanılan token kaynağı: ${state.discovery.lastUsedTokenSource}` : 'Kullanılan token kaynağı: -');

    const modText = ['gp','g','istakip','evdo','e'].map(m => `${m}:${state.discovery.tokensByModule?.[m] ? 'var' : '-'}`).join(' | ');
    setTxt('#it_last_cmd', `${state.discovery.lastCmd ? `Son cmd: ${state.discovery.lastCmd}` : 'Son cmd: -'} | Son modül: ${state.discovery.lastModuleName || '-'} | ${modText}`);

    const fill = (m, id1, id2) => {
      const val = state.discovery.tokensByModule?.[m] || '';
      const src = state.discovery.tokenSourceByModule?.[m] || '';
      setTxt(id1, shortTok(val));
      setTxt(id2, src ? `Kaynak: ${src}` : 'Kaynak: -');
    };
    fill('istakip', '#it_tok_istakip', '#it_toksrc_istakip');
    fill('evdo', '#it_tok_evdo', '#it_toksrc_evdo');
    fill('e', '#it_tok_e', '#it_toksrc_e');
    fill('g', '#it_tok_g', '#it_toksrc_g');
    fill('gp', '#it_tok_gp', '#it_toksrc_gp');

    try {
      const raporCache = itReadEvdoRaporTokenCache && itReadEvdoRaporTokenCache();
      const raporTok = state.discovery.evdbRaporToken || raporCache?.token || '';
      const raporSrc = state.discovery.evdbRaporTokenSource || raporCache?.source || '';
      const stat = (name, val, src) => `${name}: <span class="${val ? 'ok' : 'no'}">${val ? 'yakalandı' : 'yok'}</span>${src ? ` <span class="src">(${itHtmlEscape(String(src).slice(0,80))})</span>` : ''}`;
      const html = [
        stat('İş Takip', state.discovery.tokensByModule?.istakip || state.discovery.token, state.discovery.tokenSourceByModule?.istakip || state.discovery.source?.token),
        stat('EVDB Rapor', raporTok, raporSrc),
        stat('EVDB', state.discovery.tokensByModule?.evdo, state.discovery.tokenSourceByModule?.evdo),
        stat('EYS', state.discovery.tokensByModule?.e, state.discovery.tokenSourceByModule?.e),
        stat('GP/Portal', state.discovery.tokensByModule?.gp, state.discovery.tokenSourceByModule?.gp),
        stat('GİB', state.discovery.tokensByModule?.g, state.discovery.tokenSourceByModule?.g)
      ].join(' &nbsp; | &nbsp; ');
      const el = $('#it_token_status', panel); if (el) el.innerHTML = html;
    } catch (_) {}
  }

  function logger(panel) {
    const box = $('#it_log', panel);
    return (msg, err = false) => {
      const line = `[${new Date().toLocaleTimeString()}] ${err ? 'HATA: ' : ''}${msg}`;
      console.log('[ISTAKIP-BOT-V4]', line);
      box.innerHTML += `<div style="overflow-wrap:anywhere;word-break:break-word">${err ? '<span class="bad">HATA:</span> ' : ''}${msg}</div>`;
      box.scrollTop = box.scrollHeight;
    };
  }


function readUrlToken() {
  try { return new URL(location.href).searchParams.get('token') || ''; }
  catch (_) { return ''; }
}

function resolveKeysToken() {
  const preferred = ['gp', 'g'];
  for (const m of preferred) {
    const t = resolveTokenForModule(m);
    if (t) return t;
  }
  if (state.discovery.baseToken && state.discovery.baseToken !== state.discovery.token) {
    return state.discovery.baseToken;
  }
  const mods = ['gp', 'g', 'evdo', 'e', 'istakip'];
  for (const m of mods) {
    const t = resolveTokenForModule(m);
    if (t) return t;
  }
  return state.discovery.baseToken || '';
}

function collectMessageText(resp) {
  try {
    const msgs = Array.isArray(resp?.messages) ? resp.messages : [];
    return msgs.map(m => String(m?.text || '').trim()).filter(Boolean).join(' | ');
  } catch (_) {
    return '';
  }
}

function findDeepValue(obj, keys, depth = 0, seen = new WeakSet()) {
  try {
    if (!obj || typeof obj !== 'object' || depth > 6) return '';
    if (seen.has(obj)) return '';
    seen.add(obj);
    for (const k of keys) {
      if (obj[k] != null && obj[k] !== '') return obj[k];
    }
    for (const v of Object.values(obj)) {
      if (v && typeof v === 'object') {
        const found = findDeepValue(v, keys, depth + 1, seen);
        if (found != null && found !== '') return found;
      }
    }
  } catch (_) {}
  return '';
}

async function fetchKeysPreviewInfo(keysEvrakOid) {
  const token = resolveKeysToken();
  if (!token) throw new Error('KEYS token bulunamadı');
  const p = new URLSearchParams();
  p.append('cmd', 'evrakOrtakServis_evrakOnizle');
  p.append('callid', makeCallId());
  p.append('token', token);
  p.append('jp', JSON.stringify({
    evrakOid: String(keysEvrakOid || '').trim(),
    konteynerOid: null,
    evrakVersiyonOid: null,
    yetkisiz: true,
    barkod: true
  }));

  const res = await fetch(CFG.KEYS_DISPATCH_URL, {
    method: 'POST',
    body: p,
    credentials: 'include'
  });
  if (!res.ok) throw new Error(`Önizleme sorgusu ağ hatası: ${res.status}`);
  const txt = await res.text();
  let json = null;
  try { json = JSON.parse(txt); } catch (_) {
    throw new Error('Önizleme cevabı JSON değil');
  }
  if (String(json?.error || '') === '1') {
    throw new Error(collectMessageText(json) || 'Evrak önizleme hatası');
  }

  const data = json?.data || json || {};
  const directUrl = findDeepValue(data, ['previewUrl', 'pdfUrl', 'url', 'link']);
  if (directUrl) {
    return { token, url: directUrl, response: json };
  }

  const uuid = findDeepValue(data, ['uuid', 'fileID', 'fileId']);
  const dosyaId = findDeepValue(data, ['dosyaId', 'dosyaID', 'fn', 'fileName']);
  if (!uuid) throw new Error('Önizleme linki için fileID bulunamadı');

  const cleanedFileId = String(uuid || '').trim();
  const fileIdForUrl = cleanedFileId.endsWith('.pdf') ? cleanedFileId : `${cleanedFileId}.pdf`;
  const url = `${CFG.FLEXPAPER_URL}?token=${encodeURIComponent(token)}&fileID=${fileIdForUrl}#navpanes=0`;
  return { token, url, response: json, fileID: cleanedFileId, dosyaId };
}

try { window.__istakipFetchKeysPreviewInfo = fetchKeysPreviewInfo; } catch (_) {}

function formatCompactDateTR(v, sep = '/') {
  const s = String(v || '').replace(/\D+/g, '');
  if (s.length !== 8) return String(v || '');
  return `${s.slice(6,8)}${sep}${s.slice(4,6)}${sep}${s.slice(0,4)}`;
}


function itParseCompactDateTimeMs(v) {
  const s = String(v || '').replace(/\D+/g, '');
  if (s.length < 8) return 0;
  const y = Number(s.slice(0, 4));
  const mo = Number(s.slice(4, 6));
  const d = Number(s.slice(6, 8));
  const h = s.length >= 10 ? Number(s.slice(8, 10)) : 0;
  const mi = s.length >= 12 ? Number(s.slice(10, 12)) : 0;
  const se = s.length >= 14 ? Number(s.slice(12, 14)) : 0;
  if (!y || !mo || !d) return 0;
  const t = new Date(y, mo - 1, d, h || 0, mi || 0, se || 0).getTime();
  return Number.isFinite(t) ? t : 0;
}

function itFormatCompactDateTimeTR(v) {
  const s = String(v || '').replace(/\D+/g, '');
  if (s.length < 8) return String(v || '') || '-';
  const date = `${s.slice(6,8)}/${s.slice(4,6)}/${s.slice(0,4)}`;
  if (s.length >= 12) return `${date}<br><span class="muted">${s.slice(8,10)}:${s.slice(10,12)}</span>`;
  return date;
}

function itJobAcilisRaw(job) {
  return job?.akis_atanma_Zamani || job?.is_optime || job?.akis_optime || job?.is_isAcilisZamani || job?.isAcilisZamani || '';
}

function itJobBeklenenBitisRaw(job) {
  return job?.is_beklenenIsBitisZamani || job?.beklenenIsBitisZamani || job?.isBeklenenBitisZamani || job?.is_beklenen_is_bitis_zamani || '';
}

function itJobKaldigiSureText(job) {
  const start = itParseCompactDateTimeMs(itJobAcilisRaw(job));
  if (!start) return '-';
  const end = itParseCompactDateTimeMs(job?.akis_bitis_Zamani || job?.is_isBitisZamani || job?.isBitisZamani || '') || Date.now();
  let mins = Math.max(0, Math.floor((end - start) / 60000));
  const days = Math.floor(mins / 1440); mins -= days * 1440;
  const hours = Math.floor(mins / 60); mins -= hours * 60;
  const parts = [];
  if (days) parts.push(`${days} Gün`);
  if (hours) parts.push(`${hours} Saat`);
  parts.push(`${mins} Dakika`);
  return parts.join('<br>');
}

function itJobKaldigiSureSort(job) {
  const start = itParseCompactDateTimeMs(itJobAcilisRaw(job));
  if (!start) return 0;
  const end = itParseCompactDateTimeMs(job?.akis_bitis_Zamani || job?.is_isBitisZamani || job?.isBitisZamani || '') || Date.now();
  return Math.max(0, end - start);
}

function itResolveGibIntranetToken() {
  // Sicil ekranındaki sorgular GİB/gibintranet tokeni ile çalışır; EYS için ayrı token aranmaz.
  // Önce URL'deki aktif gibintranet/gp tokenini kullan, yoksa yakalanan GIB/GP tokenlerine dön.
  const urlToken = readUrlToken();
  if (urlToken && /gibintranet|gp\//i.test(location.href)) return urlToken;
  return resolveKeysToken();
}

function itGetSicilKaydiPayload(job) {
  const vkn = String(job?.is_vergiNo || job?.is_sicil_vergiNo || job?.vergiNo || '').replace(/\D+/g, '').slice(0, 10);
  const tckn = String(job?.is_tcKimlikNo || job?.tckn || job?.tcKimlikNo || '').replace(/\D+/g, '').slice(0, 11);
  const vdKodu = String(job?.vdKodu || job?.vdkodu || job?.is_vdkodu || '').replace(/\D+/g, '').slice(0, 6);
  const ilKodu = String(job?.ilKodu || job?.ilkodu || '').replace(/\D+/g, '').slice(0, 3);
  const unvan = String(job?.is_unvan || job?.is_unvan_unvan || '').trim();
  return { vkn, tckn, vdKodu, ilKodu, unvan };
}

async function itFetchSicilKaydiInfo(job) {
  const q = itGetSicilKaydiPayload(job);
  if (!q.vkn && !q.tckn) throw new Error('Sicil kaydı sorgusu için VKN/TCKN bulunamadı');
  const token = itResolveGibIntranetToken();
  if (!token) throw new Error('GİB/Portal token bulunamadı');

  const p = new URLSearchParams();
  p.append('cmd', 'sicilService_sicilBilgileriSorgulaIlKodu');
  p.append('callid', makeCallId());
  p.append('token', token);
  p.append('jp', JSON.stringify({ vkn: q.vkn, tckn: q.tckn, vdKodu: q.vdKodu || '', ilKodu: q.ilKodu || '' }));

  const res = await fetch(`${location.origin}/gibintranet_server/dispatch`, {
    method: 'POST',
    body: p,
    credentials: 'include',
    cache: 'no-store'
  });
  if (!res.ok) throw new Error(`Sicil kaydı sorgusu ağ hatası: ${res.status}`);
  const txt = await res.text();
  let json = null;
  try { json = JSON.parse(txt); } catch (_) {
    throw new Error('Sicil kaydı cevabı JSON değil');
  }
  if (String(json?.error || '') === '1') {
    throw new Error(collectMessageText(json) || 'Sicil kaydı sorgusu hatası');
  }
  return { query: q, response: json, data: json?.data || {} };
}

async function itFetchSicilVdDetay(payload) {
  const q = {
    vkn: String(payload?.vkn || '').replace(/\D+/g, '').slice(0, 10),
    vdkodu: String(payload?.vdkodu || payload?.vdKodu || '').replace(/\D+/g, '').slice(0, 6),
    birimOid: String(payload?.birimOid || payload?.birimoid || '').trim(),
    subeno: String(payload?.subeno || '').trim(),
    subeadi: String(payload?.subeadi || '').trim(),
    isyerituru: String(payload?.isyerituru || '').trim(),
    isyerinitelik: String(payload?.isyerinitelik || '').trim(),
    mukblgoid: String(payload?.mukblgoid || '').trim()
  };
  if (!q.vkn || !q.vdkodu || !q.birimOid || !q.mukblgoid) {
    throw new Error('Vergi dairesi detay sorgusu için vkn/vdkodu/birimOid/mukblgoid eksik');
  }
  const token = itResolveGibIntranetToken();
  if (!token) throw new Error('GİB/Portal token bulunamadı');

  const p = new URLSearchParams();
  p.append('cmd', 'sicilService_mukSicilDetayBilgileriGetir');
  p.append('callid', makeCallId());
  p.append('token', token);
  p.append('jp', JSON.stringify({
    vkn: q.vkn,
    vdkodu: q.vdkodu,
    birimOid: q.birimOid,
    subeno: q.subeno || '',
    subeadi: q.subeadi || '',
    isyerituru: q.isyerituru || '',
    isyerinitelik: q.isyerinitelik || '',
    mukblgoid: q.mukblgoid
  }));

  const res = await fetch(`${location.origin}/gibintranet_server/dispatch`, {
    method: 'POST',
    body: p,
    credentials: 'include',
    cache: 'no-store'
  });
  if (!res.ok) throw new Error(`Vergi dairesi detay sorgusu ağ hatası: ${res.status}`);
  const txt = await res.text();
  let json = null;
  try { json = JSON.parse(txt); } catch (_) {
    throw new Error('Vergi dairesi detay cevabı JSON değil');
  }
  if (String(json?.error || '') === '1') {
    throw new Error(collectMessageText(json) || 'Vergi dairesi detay sorgusu hatası');
  }
  const raw = json?.data || {};
  // HAR cevabında birçok dolu alan data.mukellefBilgi içinde geliyor.
  // Ekran doldururken hem üst data hem mukellefBilgi birlikte kullanılsın.
  const merged = { ...(raw?.mukellefBilgi || {}), ...raw };
  if (raw?.mukellefBilgi) {
    merged.mukellefBilgi = raw.mukellefBilgi;
    if (!Array.isArray(merged.mukellefiyet) && Array.isArray(raw.mukellefBilgi.mukellefiyet)) merged.mukellefiyet = raw.mukellefBilgi.mukellefiyet;
    if (!Array.isArray(merged.adresbilgi) && Array.isArray(raw.mukellefBilgi.adresbilgi)) merged.adresbilgi = raw.mukellefBilgi.adresbilgi;
    if (!Array.isArray(merged.faaliyet) && Array.isArray(raw.mukellefBilgi.faaliyet)) merged.faaliyet = raw.mukellefBilgi.faaliyet;
  }
  return { query: q, response: json, data: merged, rawData: raw };
}

try { window.__istakipFetchSicilVdDetay = itFetchSicilVdDetay; } catch (_) {}

async function itFetchSicilVergiDetay(payload) {
  const q = {
    mukblgoid: String(payload?.mukblgoid || '').trim(),
    vkn: String(payload?.vkn || '').replace(/\D+/g, '').slice(0, 10),
    vKodu: String(payload?.vKodu || payload?.vergikodu || '').replace(/\D+/g, '').slice(0, 4),
    vdkodu: String(payload?.vdkodu || '').replace(/\D+/g, '').slice(0, 6)
  };
  if (!q.vkn || !q.vKodu || !q.vdkodu) throw new Error('Vergi kodu detayı için gerekli alanlar eksik');
  const token = itResolveGibIntranetToken();
  if (!token) throw new Error('GİB/Portal token bulunamadı');

  const p = new URLSearchParams();
  p.append('cmd', 'sicilService_mukellefinVergiKoduBilgileriGetir');
  p.append('callid', makeCallId());
  p.append('token', token);
  p.append('jp', JSON.stringify({ mukblgoid: q.mukblgoid || '', vkn: q.vkn, vKodu: q.vKodu, vdkodu: q.vdkodu }));

  const res = await fetch(`${location.origin}/gibintranet_server/dispatch`, {
    method: 'POST',
    body: p,
    credentials: 'include',
    cache: 'no-store'
  });
  if (!res.ok) throw new Error(`Vergi kodu detayı ağ hatası: ${res.status}`);
  const txt = await res.text();
  let json = null;
  try { json = JSON.parse(txt); } catch (_) {
    throw new Error('Vergi kodu detay cevabı JSON değil');
  }
  if (String(json?.error || '') === '1') {
    throw new Error(collectMessageText(json) || 'Vergi kodu detay sorgusu hatası');
  }
  return { query: q, response: json, data: json?.data || {} };
}

try { window.__istakipFetchSicilVergiDetay = itFetchSicilVergiDetay; } catch (_) {}

function itMapPotansiyelText(v) {
  const s = String(v ?? '').trim();
  if (s === '1') return 'Potansiyel';
  if (s === '0') return 'Potansiyel Değil';
  return s || '-';
}

function itMapMukellefTuruText(v) {
  const s = String(v ?? '').trim();
  const m = { '1': 'Tam', '2': 'Dar' };
  return s ? `${s} - ${m[s] || ''}`.replace(/\s+-\s*$/, '') : '-';
}

function itMapSirketTuruText(no, ad) {
  const s = String(no ?? '').trim();
  const a = String(ad || '').trim();
  if (s && a) return `${s} - ${a}`;
  return s || a || '-';
}

function itMapBirimDurumText(row) {
  const bit = String(row?.isibirakmatarihi || row?.birimbittar || '').replace(/\D+/g, '');
  const faal = String(row?.birimfaal || row?.mukblgdurum || '').trim();
  if (bit) return 'TERK';
  if (faal === '1') return 'FAAL';
  if (faal === '2') return 'TERK';
  return faal || '-';
}

function itMapTerkNedeniText(code) {
  const s = String(code ?? '').trim();
  const m = { '6': 'Terk' };
  if (!s) return '-';
  return m[s] ? `${s} - ${m[s]}` : s;
}

function itMapHukukiDurumText(code, text) {
  const s = String(code ?? '').trim();
  const t = String(text ?? '').trim();
  if (t && s && !t.startsWith(s)) return `${s} - ${t}`;
  if (t) return t;
  const m = {
    '15': 'Konkordato Geçici Mühlet',
    '16': 'Konkordato Geçici Mühlet Sonu',
    '19': 'Konkordato Geçici Mühlet Uzatma',
    '20': 'Konkordato Geçici Mühlet Uzatma Sonu',
    '23': 'Konkordato Kesin Mühlet',
    '24': 'Konkordato Kesin Mühlet Sonu',
    '27': 'Konkordato Kesin Mühlet Uzatma',
    '28': 'Konkordato Kesin Mühlet Uzatma Sonu',
    '31': 'Konkordatonun Tasdiki',
    '32': 'Konkordatonun Reddi'
  };
  if (!s) return '-';
  return m[s] ? `${s} - ${m[s]}` : s;
}

function itBuildSicilKaydiHtml(info, job) {
  const d = info?.data || {};
  const q = info?.query || {};
  const vdRows = Array.isArray(d?.vdler?.baglivd) ? d.vdler.baglivd : [];
  const selected = vdRows.find(r => String(r?.vdkodu || '') === String(job?.is_vdkodu || job?.vdkodu || '').trim()) || vdRows[0] || {};
  const selectedVd = [selected?.vdkodu, selected?.vdadi].filter(Boolean).join(' - ');
  const headParts = [];
  if (d?.vkn || q.vkn) headParts.push(`VKN: ${d?.vkn || q.vkn}`);
  if (d?.tckn || d?.mukellefno || q.tckn) headParts.push(`TCKN: ${d?.tckn || d?.mukellefno || q.tckn}`);
  if (d?.kimlikunvan || q.unvan) headParts.push(`ÜNVAN: ${d?.kimlikunvan || q.unvan}`);
  if (selectedVd) headParts.push(`VERGİ DAİRESİ: ${selectedVd}`);
  const headBar = headParts.join('   ');
  const safeJson = itHtmlEscape(JSON.stringify({ data: d, query: q, vdRows }, null, 0));

  const rowsHtml = vdRows.map((row, i) => `
    <tr class="vd-row" title="Detay açmak için tıklayın">
      <td>${itHtmlEscape([row?.vdkodu, row?.vdadi].filter(Boolean).join(' - '))}</td>
      <td>${itHtmlEscape(row?.subeno || '')}</td>
      <td>${itHtmlEscape(row?.subeadi || '')}</td>
      <td>${itHtmlEscape(row?.isyerituru || '')}</td>
      <td>${itHtmlEscape(row?.isyerinitelik || '')}</td>
      <td>${itHtmlEscape(formatCompactDateTR(row?.isebaslamatarihi || row?.birimbastar || '', '.'))}</td>
      <td>${itHtmlEscape(formatCompactDateTR(row?.isibirakmatarihi || row?.birimbittar || '', '.'))}</td>
      <td>${itHtmlEscape(itMapBirimDurumText(row))}</td>
      <td>${itHtmlEscape(itMapTerkNedeniText(row?.mukblgislemturubittur || ''))}</td>
    </tr>`).join('');

  return `<!doctype html><html><head><meta charset="utf-8"><title>Sicil Kaydı</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f6f6f8;color:#111;margin:0;font-size:12px}
.page{padding:14px}.topbar{display:none}
.grid{display:grid;grid-template-columns:260px 1fr 260px 1fr;gap:10px 12px;align-items:center}
.lbl{font-weight:bold;color:#333}input,select{width:100%;padding:6px 8px;border:1px solid #bfc6cf;border-radius:3px;background:#fff}
.name{grid-column:1 / span 2;color:#666;margin-top:-4px}.btnrow{margin-top:10px}.btn{padding:6px 16px;border:1px solid #999;border-radius:3px;background:#ececec;font-size:12px;cursor:pointer}
.bar{background:#2f3640;color:#fff;padding:7px 10px;font-weight:bold}.tabs{display:flex;gap:6px;padding:8px 10px 0 10px;background:#fff}.tab{padding:7px 10px;border:1px solid #c66;background:#b73a45;color:#fff;border-bottom:none;border-radius:4px 4px 0 0;font-weight:bold}.tab.passive{background:#f2f2f2;color:#333;border-color:#ccc}
.card{background:#fff;border:1px solid #d7d7d7;margin:0 10px 10px 10px;padding:14px;box-shadow:0 1px 2px rgba(0,0,0,.03)}.info{display:grid;grid-template-columns:180px 1fr 180px 1fr;row-gap:8px;column-gap:12px;max-width:980px}.info .k{font-weight:bold;color:#444}
.tablewrap{margin-top:14px;overflow:auto;border:1px solid #ddd}table{border-collapse:collapse;width:100%;font-size:11px}th,td{border:1px solid #ddd;padding:6px;vertical-align:top;text-align:left}th{background:#f0f4f8}.actions{margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}.tiny{font-size:11px;color:#666}.vd-row,.tax-row{cursor:pointer}.vd-row:hover,.tax-row:hover{background:#fff7d6}.detail-title{font-weight:bold;margin:12px 0 6px;color:#333}.boxgrid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}.addrbox{border:1px solid #999;padding:8px;min-height:120px}.addrbox h4{margin:0 0 6px;font-size:12px}.kv{display:grid;grid-template-columns:120px 1fr;gap:4px 8px}.muted{color:#666}.linklike{color:#0b5bd3;text-decoration:underline;cursor:pointer}.msg{padding:10px;border:1px solid #ddd;background:#fafafa}.loading{padding:12px;border:1px solid #ddd;background:#fbfbfb}
@media print{.btnrow,.actions,.tabs{display:none}.page{padding:0}.card{box-shadow:none;border:none}.topbar{border:none}}
</style></head><body>
<div class="topbar">
  <div class="grid">
    <div><input readonly value="${itHtmlEscape(d?.vkn || q.vkn || '')}"></div>
    <div></div>
    <div class="lbl">T.C. KİMLİK NO:</div>
    <div><input readonly value="${itHtmlEscape(d?.tckn || d?.mukellefno || q.tckn || '')}"></div>
    <div class="name">${itHtmlEscape(d?.kimlikunvan || q.unvan || '-')}</div>
    <div></div>
    <div class="lbl">VERGİ DAİRESİ:</div>
    <div><select id="vdSelect">${vdRows.map((row, i) => `<option${row === selected ? ' selected' : ''}>${itHtmlEscape([row?.vdkodu, row?.vdadi].filter(Boolean).join(' - ') || '-')}</option>`).join('')}</select></div>
  </div>
  <div class="btnrow"><button class="btn">Liste</button> <button class="btn">Yazdır</button></div>
</div>
<div class="bar">${itHtmlEscape(headBar || 'Sicil Kaydı')}</div>
<div class="tabs"><div class="tab passive">Sorgu</div><div class="tab">VERGİ KİMLİK NO: ${itHtmlEscape(d?.vkn || q.vkn || '')}</div></div>
<div class="card" id="sicilContent">
  <div class="info">
    <div class="k">VERGİ NO:</div><div>${itHtmlEscape(d?.vergino || d?.vkn || q.vkn || '-')}</div>
    <div class="k">T.C. KİMLİK NO:</div><div>${itHtmlEscape(d?.tckn || d?.mukellefno || q.tckn || '-')}</div>
    <div class="k">AD SOYAD / ÜNVAN:</div><div>${itHtmlEscape(d?.kimlikunvan || q.unvan || '-')}</div>
    <div class="k">DOĞUM TARİHİ:</div><div>${itHtmlEscape(d?.dogumtarihiformatli || formatCompactDateTR(d?.dogumtarihi || '', '.'))}</div>
    <div class="k">DOĞUM YERİ:</div><div>${itHtmlEscape([d?.dogumyeri, d?.dogumyeritext].filter(Boolean).join(' - ') || '-')}</div>
    <div class="k">MÜKELLEF TÜRÜ:</div><div>${itHtmlEscape(itMapMukellefTuruText(d?.tamdarmukelleffiyet))}</div>
    <div class="k">ŞİRKET TÜRÜ:</div><div>${itHtmlEscape(itMapSirketTuruText(d?.sirketturu, d?.sirketturuad))}</div>
    <div class="k">POTANSİYEL:</div><div>${itHtmlEscape(itMapPotansiyelText(d?.kimlikpotansiyel))}</div>
  </div>
  <div class="actions"><span class="tiny">Detay ekranını açmak için aşağıdaki vergi dairesi satırına tıklayın.</span></div>
  <div class="tablewrap">
    <table>
      <thead><tr><th>VERGİ DAİRESİ</th><th>ŞUBE NO</th><th>ŞUBE ADI</th><th>İŞ YERİ TÜRÜ</th><th>İŞ YERİ NİTELİĞİ</th><th>İŞE BAŞLAMA TARİHİ</th><th>İŞİ BIRAKMA TARİHİ</th><th>DURUM</th><th>TERK NEDENİ</th></tr></thead>
      <tbody>${rowsHtml || '<tr><td colspan="9">Kayıt bulunamadı.</td></tr>'}</tbody>
    </table>
  </div>
</div>
<script type="application/json" id="sicilJson">${safeJson}</script>
<!-- runtime handlers are attached from content.js to satisfy CSP -->

</body></html>`;
}

function itAttachSicilPopupHandlers(popup, info, job) {
  const doc = popup && popup.document;
  if (!doc) return;
  const d = info?.data || {};
  const q = info?.query || {};
  const vdRows = Array.isArray(d?.vdler?.baglivd) ? d.vdler.baglivd : [];
  const vdDetailCache = {};
  let activeView = 'list';
  let lastVdRenderAt = 0;
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>\"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
  const date = (v, sep='.') => {
    const raw = String(v || '').trim();
    const x = raw.replace(/\D+/g, '');
    if (x.length !== 8) return raw || '-';
    const y1 = Number(x.slice(0,4));
    const y2 = Number(x.slice(4,8));
    // Servisler bazen YYYYMMDD, bazen DDMMYYYY / DD.MM.YYYY döndürüyor.
    // Yılı nerede görürsek ona göre biçimlendiriyoruz.
    if (y1 >= 1900 && y1 <= 2100) return x.slice(6,8) + sep + x.slice(4,6) + sep + x.slice(0,4);
    if (y2 >= 1900 && y2 <= 2100) return x.slice(0,2) + sep + x.slice(2,4) + sep + x.slice(4,8);
    return raw || '-';
  };
  const rowVd = (row) => [row?.vdkodu, row?.vdadi].filter(Boolean).join(' - ') || '-';
  const muk = (v) => ({ '1': '1 - Tam', '2': '2 - Dar' }[String(v)] || String(v || '-'));
  const pot = (v) => String(v) === '1' ? 'Potansiyel' : (String(v) === '0' ? 'Potansiyel Değil' : (v || '-'));
  const durum = (row) => {
    const bit = String(row?.isibirakmatarihi || row?.birimbittar || '').replace(/\D+/g, '');
    const faal = String(row?.birimfaal || row?.mukblgdurum || '').trim();
    if (bit) return 'TERK';
    if (faal === '1') return 'FAAL';
    if (faal === '2') return 'TERK';
    return faal || '-';
  };
  const codeText = (code, text, map = {}) => {
    const c = String(code ?? '').trim();
    const t = String(text ?? '').trim();
    if (t && c && !t.startsWith(c)) return `${c} - ${t}`;
    if (t) return t;
    if (!c || c === '0') return '-';
    return map[c] ? `${c} - ${map[c]}` : c;
  };
  const terkMap = {
    '1': 'Terk',
    '2': 'Terk',
    '3': 'Terk',
    '4': 'Terk',
    '5': 'Terk',
    '6': 'Terk'
  };
  const faalTerkMap = { '1': 'Faal', '2': 'Terk', '3': 'Terk' };
  const gelirUnsuruMap = {
    '1': 'Ticari Kazanç',
    '2': 'Zirai Kazanç',
    '3': 'Serbest Meslek Kazancı',
    '4': 'Gayrimenkul Sermaye İradı',
    '5': 'Menkul Sermaye İradı',
    '6': 'Diğer Kazanç ve İratlar',
    '7': 'Ücret'
  };
  const terk = (v, text) => codeText(v, text, terkMap);
  const terkNedeniFromVergi = (m) => {
    // Vergi satırında 'durum' faal/terk durumudur; terk nedeni değildir.
    // Gerçek ekranda aktif kayıtlarda terk nedeni boş gelir. Bu yüzden sadece
    // bitiş/terk işlem türü alanları doluysa yazıyoruz.
    const raw = m?.bitislemturu ?? m?.terkNedeni ?? m?.terknedeni ?? m?.bitisIslemTuru ?? '';
    const txt = m?.bitislemturutext || m?.terkNedeniText || m?.terkNedeniAciklama || m?.terknedenitext || '';
    const s = String(raw ?? '').trim();
    if (!s || s === '0') return '-';
    return terk(s, txt);
  };
  const faalTerk = (v, text) => codeText(v, text, faalTerkMap);
  const faalTerkPlain = (v, text) => {
    const s = String(v ?? '').trim();
    const t = String(text ?? '').trim();
    if (t) return t.replace(/^\d+\s*-\s*/, '');
    return faalTerkMap[s] || (s ? s : '-');
  };
  const gelirUnsuruText = (g) => {
    const code = g?.gelirunsuru || g?.gelirUnsuru || g?.gelirunsurukodu || g?.gelirUnsuruKodu || g?.gelirUnsuruKod || g?.kod || g?.gelirKodu || g?.tipi || g?.gelirunsurutipi || g?.gelirUnsuruTipi;
    const text = g?.gelirunsurutext || g?.gelirUnsuruText || g?.gelirunsuruadi || g?.gelirUnsuruAdi || g?.adi || g?.ad || g?.gelirAdi || g?.tipitext || g?.tipiText;
    return codeText(code, text, gelirUnsuruMap);
  };
  const donemText = (v) => {
    const x = String(v ?? '').replace(/\D+/g, '');
    if (x.length === 12) return `${x.slice(4,6)}/${x.slice(0,4)}-${x.slice(10,12)}/${x.slice(6,10)}`;
    if (x.length === 6) return `${x.slice(4,6)}/${x.slice(0,4)}`;
    return String(v ?? '').trim() || '-';
  };
  const getNameParts = () => {
    const name = String(d?.kimlikunvan || q.unvan || '').trim();
    const arr = name.split(/\s+/).filter(Boolean);
    const gercek = String(d?.sirketturu || '') === '1';
    return {
      ad: d?.ad || d?.adi || (gercek && arr.length ? arr[0] : name),
      soyad: d?.soyad || d?.soyadi || (gercek && arr.length > 1 ? arr.slice(1).join(' ') : '')
    };
  };
  const getMukListForRow = (row) => {
    const all = Array.isArray(d?.mukellefiyet) ? d.mukellefiyet : [];
    let arr = all.filter(m => String(m?.mukblgoid || '') === String(row?.mukblgoid || ''));
    if (!arr.length) arr = all.filter(m => String(m?.vdkodu || '') === String(row?.vdkodu || ''));
    if (!arr.length && all.length === 1) arr = all.slice();
    return arr;
  };
  const content = () => doc.getElementById('sicilContent');
  const hideTop = () => {
    const top = doc.querySelector('.topbar');
    if (top) top.remove();
    // Siyah şeridin üstünde hiçbir alan kalmasın.
    doc.body.style.margin = '0';
  };
  const bindInitialRows = () => {
    hideTop();
    doc.querySelectorAll('.vd-row').forEach((tr, idx) => {
      tr.removeAttribute('onclick');
      tr.style.cursor = 'pointer';
      tr.addEventListener('click', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        activeView = 'list';
        renderVdDetail(idx);
      });
    });
  };
  const renderList = () => {
    hideTop();
    activeView = 'list';
    const rowsHtml = vdRows.map((row, i) => `
      <tr class="vd-row" data-vd-index="${i}">
        <td>${esc(rowVd(row))}</td>
        <td>${esc(row?.subeno || '')}</td>
        <td>${esc(row?.subeadi || '')}</td>
        <td>${esc(row?.isyerituru || '')}</td>
        <td>${esc(row?.isyerinitelik || '')}</td>
        <td>${esc(date(row?.isebaslamatarihi || row?.birimbastar || ''))}</td>
        <td>${esc(date(row?.isibirakmatarihi || row?.birimbittar || ''))}</td>
        <td>${esc(durum(row))}</td>
        <td>${esc(terk(row?.mukblgislemturubittur || '', row?.mukblgislemturubitturtext || row?.terkNedeniText || ''))}</td>
      </tr>`).join('');
    const c = content();
    if (!c) return;
    c.innerHTML = `
      <div class="info">
        <div class="k">VERGİ NO:</div><div>${esc(d?.vergino || d?.vkn || q.vkn || '-')}</div>
        <div class="k">T.C. KİMLİK NO:</div><div>${esc(d?.tckn || d?.mukellefno || q.tckn || '-')}</div>
        <div class="k">AD SOYAD / ÜNVAN:</div><div>${esc(d?.kimlikunvan || q.unvan || '-')}</div>
        <div class="k">DOĞUM TARİHİ:</div><div>${esc(d?.dogumtarihiformatli || date(d?.dogumtarihi || ''))}</div>
        <div class="k">DOĞUM YERİ:</div><div>${esc([d?.dogumyeri, d?.dogumyeritext].filter(Boolean).join(' - ') || '-')}</div>
        <div class="k">MÜKELLEF TÜRÜ:</div><div>${esc(muk(d?.tamdarmukelleffiyet))}</div>
        <div class="k">ŞİRKET TÜRÜ:</div><div>${esc([d?.sirketturu, d?.sirketturuad].filter(Boolean).join(' - ') || '-')}</div>
        <div class="k">POTANSİYEL:</div><div>${esc(pot(d?.kimlikpotansiyel))}</div>
      </div>
      <div class="actions"><button class="btn" data-print="1">Yazdır</button><span class="tiny">Vergi dairesi satırına tıklayınca detay açılır.</span></div>
      <div class="tablewrap"><table><thead><tr><th>VERGİ DAİRESİ</th><th>ŞUBE NO</th><th>ŞUBE ADI</th><th>İŞ YERİ TÜRÜ</th><th>İŞ YERİ NİTELİĞİ</th><th>İŞE BAŞLAMA TARİHİ</th><th>İŞİ BIRAKMA TARİHİ</th><th>DURUM</th><th>TERK NEDENİ</th></tr></thead><tbody>${rowsHtml || '<tr><td colspan="9">Kayıt bulunamadı.</td></tr>'}</tbody></table></div>`;
    c.querySelector('[data-print="1"]')?.addEventListener('click', () => popup.print());
    c.querySelectorAll('.vd-row').forEach((tr, i) => tr.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      renderVdDetail(i);
    }));
  };
  const renderVdDetail = async (idx) => {
    const row = vdRows[idx] || vdRows[0] || {};
    const { ad, soyad } = getNameParts();
    const c = content();
    if (!c) return;
    const mukList = getMukListForRow(row);
    activeView = 'vd';
    lastVdRenderAt = Date.now();
    c.innerHTML = '<div class="loading">Vergi dairesi detayı açılıyor...</div>';

    let detail = {};
    let detailErr = '';
    try {
      // 2. aşama HAR akışı: vergi dairesi satırına tıklanınca
      // sicilService_mukSicilDetayBilgileriGetir çağrılır.
      // Payload alanları ilk listedeki seçilen vergi dairesi satırından alınır.
      const resp = await itFetchSicilVdDetay({
        vkn: d?.vergino || d?.vkn || q.vkn || row?.vergino || '',
        vdkodu: row?.vdkodu || '',
        birimOid: row?.birimOid || row?.birimoid || '',
        subeno: row?.subeno || '',
        subeadi: row?.subeadi || '',
        isyerituru: row?.isyerituru || '',
        isyerinitelik: row?.isyerinitelik || '',
        mukblgoid: row?.mukblgoid || ''
      });
      detail = resp?.data || {};
    } catch (e) {
      detailErr = e?.message || String(e);
      detail = {};
    }

    const pick = (...vals) => {
      for (const v of vals) {
        if (v !== undefined && v !== null && String(v).trim() !== '') return v;
      }
      return '';
    };
    const pickKey = (...keys) => {
      for (const k of keys) {
        const v = detail?.[k];
        if (v !== undefined && v !== null && String(v).trim() !== '') return v;
        const vr = row?.[k];
        if (vr !== undefined && vr !== null && String(vr).trim() !== '') return vr;
        const vd0 = d?.[k];
        if (vd0 !== undefined && vd0 !== null && String(vd0).trim() !== '') return vd0;
      }
      return '';
    };
    const deepFind = (obj, keys) => {
      const wanted = new Set(keys.map(k => String(k).toLowerCase()));
      const seen = new Set();
      const walk = (x) => {
        if (!x || typeof x !== 'object' || seen.has(x)) return '';
        seen.add(x);
        if (Array.isArray(x)) {
          for (const it of x) {
            const r = walk(it);
            if (r !== '') return r;
          }
          return '';
        }
        for (const [k, v] of Object.entries(x)) {
          if (wanted.has(String(k).toLowerCase()) && v !== undefined && v !== null && String(v).trim() !== '') return v;
        }
        for (const v of Object.values(x)) {
          const r = walk(v);
          if (r !== '') return r;
        }
        return '';
      };
      return walk(obj);
    };
    const pickDeep = (...keys) => pickKey(...keys) || deepFind(detail, keys) || deepFind(d, keys) || '';
    const pickArr = (...keys) => {
      for (const k of keys) {
        const v = detail?.[k] ?? row?.[k] ?? d?.[k];
        if (Array.isArray(v) && v.length) return v;
        if (v && typeof v === 'object') {
          for (const ck of ['liste', 'list', 'data', 'rows', 'items', 'mukellefiyet', 'vergimuafiyet', 'gelirunsurlari', 'faaliyet']) {
            if (Array.isArray(v?.[ck]) && v[ck].length) return v[ck];
          }
        }
        const found = deepFind(detail, [k]) || deepFind(d, [k]);
        if (Array.isArray(found) && found.length) return found;
        if (found && typeof found === 'object') {
          for (const ck of ['liste', 'list', 'data', 'rows', 'items', 'mukellefiyet', 'vergimuafiyet', 'gelirunsurlari', 'faaliyet']) {
            if (Array.isArray(found?.[ck]) && found[ck].length) return found[ck];
          }
        }
      }
      return [];
    };
    const listFromContainer = (...vals) => {
      for (const v of vals) {
        if (Array.isArray(v) && v.length) return v;
        if (v && typeof v === 'object') {
          for (const ck of ['faaliyet', 'faaliyetler', 'faaliyetListesi', 'faaliyetBilgileri', 'vergimuafiyet', 'gelirunsurlari', 'liste', 'list', 'data', 'rows', 'items']) {
            if (Array.isArray(v?.[ck]) && v[ck].length) return v[ck];
          }
        }
      }
      return [];
    };
    const collectNamedArrays = (obj, mustInclude, mustNotInclude = []) => {
      const out = [];
      const seen = new Set();
      const walk = (v, key = '', depth = 0) => {
        if (!v || depth > 8) return;
        if (Array.isArray(v)) {
          const k = String(key || '').toLowerCase();
          const ok = mustInclude.some(s => k.includes(String(s).toLowerCase())) &&
            !mustNotInclude.some(s => k.includes(String(s).toLowerCase()));
          if (ok && v.length && !seen.has(v)) {
            seen.add(v);
            out.push(...v);
          }
          v.forEach(x => walk(x, key, depth + 1));
          return;
        }
        if (typeof v === 'object') {
          for (const [k, val] of Object.entries(v)) walk(val, k, depth + 1);
        }
      };
      walk(obj);
      return out;
    };
    // Birden fazla kelimeyi aynı anahtar adında arar. Örn: terk + faaliyet.
    // Bu sayede FAALİYET BİLGİLERİ, TERK FAALİYET BİLGİLERİ ve NACE bölümleri birbirine karışmaz.
    const collectNamedArraysAll = (obj, mustAll, mustNotInclude = []) => {
      const out = [];
      const seen = new Set();
      const walk = (v, key = '', depth = 0) => {
        if (!v || depth > 8) return;
        if (Array.isArray(v)) {
          const k = String(key || '').toLowerCase();
          const ok = mustAll.every(s => k.includes(String(s).toLowerCase())) &&
            !mustNotInclude.some(s => k.includes(String(s).toLowerCase()));
          if (ok && v.length && !seen.has(v)) {
            seen.add(v);
            out.push(...v);
          }
          v.forEach(x => walk(x, key, depth + 1));
          return;
        }
        if (typeof v === 'object') {
          for (const [k, val] of Object.entries(v)) walk(val, k, depth + 1);
        }
      };
      walk(obj);
      return out;
    };
    const fmtDate = (v) => v ? date(v) : '-';
    const textOrDash = (v) => {
      const s = String(v ?? '').trim();
      return s ? s : '-';
    };
    const hukukiList = listFromContainer(
      detail?.hukukiDurum,
      detail?.hukukiDurumList,
      detail?.hukukiDurumBilgileri,
      detail?.mukellefBilgi?.hukukiDurum,
      pickArr('hukukiDurum', 'hukukiDurumList', 'hukukiDurumBilgileri', 'hukukiDurumlari', 'hukukidurum')
    );
    const hukukiBasText = itMapHukukiDurumText(
      pick(detail?.hukukidurumbastur, detail?.mukellefBilgi?.hukukidurumbastur, row?.hukukidurumbastur, pickDeep('hukukidurumbastur')),
      pickDeep('hukukidurumbasturtext', 'hukukiDurumBaslamaTuruText', 'baslayanHukukiDurum', 'baslayanHukukiDurumText')
    );
    const hukukiBitText = itMapHukukiDurumText(
      pick(detail?.hukukidurumsontur, detail?.mukellefBilgi?.hukukidurumsontur, row?.hukukidurumsontur, pickDeep('hukukidurumsontur')),
      pickDeep('hukukidurumsonturtext', 'hukukiDurumSonuclanmaTuruText', 'bitenHukukiDurum', 'bitenHukukiDurumText')
    );
    const hukukiBasTarih = fmtDate(pick(detail?.hukukidurumbastar, detail?.mukellefBilgi?.hukukidurumbastar, row?.hukukidurumbastar, pickDeep('hukukidurumbastar', 'hukukiDurumBaslamaTarihi', 'hukukidurumbaslamatarihi')));
    const hukukiBitTarih = fmtDate(pick(detail?.hukukidurumsontar, detail?.mukellefBilgi?.hukukidurumsontar, row?.hukukidurumsontar, pickDeep('hukukidurumsontar', 'hukukiDurumBitisTarihi', 'hukukidurumbitistarihi', 'hukukiDurumAitTarihi')));
    const vdNameForCode = (code) => {
      const c = String(code || '').trim();
      if (!c) return '-';
      const rr = vdRows.find(x => String(x?.vdkodu || '').trim() === c);
      return rr ? [rr.vdkodu, rr.vdadi].filter(Boolean).join(' - ') : c;
    };
    const hukukiBasRows = hukukiList.length ? hukukiList.map(h => `
      <tr>
        <td>${esc(itMapHukukiDurumText(h.hukukidurumbastur || h.basTur || h.tur, h.hukukidurumbasturtext || h.basTurText || h.turText))}</td>
        <td>${esc(fmtDate(h.hukukidurumbastar || h.basTarih || h.tarih))}</td>
        <td>${esc(vdNameForCode(h.hukukidurumvdkodugiris || h.vdkodugiris || h.vdkodu))}</td>
      </tr>`).join('') : '<tr><td colspan="3">Kayıt yok</td></tr>';
    const hukukiSonRows = hukukiList.length ? hukukiList.map(h => `
      <tr>
        <td>${esc(itMapHukukiDurumText(h.hukukidurumsontur || h.sonTur || h.sonucTur, h.hukukidurumsonturtext || h.sonTurText || h.sonucTurText))}</td>
        <td>${esc(fmtDate(h.hukukidurumsontar || h.sonTarih || h.sonucTarih))}</td>
        <td>${esc(vdNameForCode(h.hukukidurumvdkoducikis || h.vdkoducikis || h.sonVdkodu || h.vdkodu))}</td>
      </tr>`).join('') : '<tr><td colspan="3">Kayıt yok</td></tr>';

    const mappedIsyeriTuru = pickKey('isyeriturutext') || (pick(row?.isyerituru, detail?.isyerituru) ? `${pick(row?.isyerituru, detail?.isyerituru)} - Merkez` : '1 - Merkez');
    const mappedIsyeriNitelik = pickKey('isyeriniteliktext') || (pick(row?.isyerinitelik, detail?.isyerinitelik) ? `${pick(row?.isyerinitelik, detail?.isyerinitelik)} - Merkez` : '1 - Merkez');

    const detailMuk = (Array.isArray(detail?.mukellefiyet) && detail.mukellefiyet.length) ? detail.mukellefiyet
      : (Array.isArray(detail?.vergiler) && detail.vergiler.length) ? detail.vergiler
      : (Array.isArray(detail?.vergiBilgileri) && detail.vergiBilgileri.length) ? detail.vergiBilgileri
      : (Array.isArray(detail?.vergiBilgileriList) && detail.vergiBilgileriList.length) ? detail.vergiBilgileriList
      : mukList;
    const vergiRows = detailMuk.length ? detailMuk.map((m, mi) => `
      <tr class="tax-row" data-muk-index="${mi}" data-vkodu="${esc(m.vergikodu || String(m.vergikodutext || '').replace(/\D+/g, '').slice(0, 4))}" data-vdkodu="${esc(m.vdkodu || row?.vdkodu || '')}" data-mukblgoid="${esc(m.mukblgoid || row?.mukblgoid || '')}" data-vergino="${esc(m.vergino || detail?.vergino || d?.vergino || d?.vkn || q.vkn || row?.vergino || '')}" title="Vergi detayı açmak için tıklayın">
        <td>${esc(m.vergikodutext || m.vergikodu || '-')}</td>
        <td>${esc(m.basdonemkodutext || m.donemturu || '-')}</td>
        <td>${esc(fmtDate(m.bastar || m.baslamaTarihi || m.isebaslamatarihi))}</td>
        <td>${esc(m.basdonem || m.baytextbyil || m.baslamaDonemi || '-')}</td>
        <td>${esc(fmtDate(m.bittar || m.birakmaTarihi || m.isibirakmatarihi))}</td>
        <td>${esc(m.bitdonem || m.bitaytextbityil || m.birakmaDonemi || '-')}</td>
        <td>${esc(terkNedeniFromVergi(m))}</td>
        <td>${esc(String(m.muafbilgisi) === '1' || String(m.istisnaMuafiyet || '').trim() ? (m.istisnaMuafiyet || 'Var') : '-')}</td>
      </tr>`).join('') : `<tr><td>0001 - GELİR VERGİSİ</td><td>-</td><td>${esc(fmtDate(row?.isebaslamatarihi || row?.birimbastar))}</td><td>-</td><td>${esc(fmtDate(row?.isibirakmatarihi || row?.birimbittar))}</td><td>-</td><td>${esc(terk(row?.mukblgislemturubittur, row?.mukblgislemturubitturtext || row?.terkNedeniText || ''))}</td><td>-</td></tr>`;

    const gencList = listFromContainer(
      detail?.gencGirisimci,
      detail?.gencgirisimci,
      detail?.gencGirisimciBilgileri,
      detail?.mukellefBilgi?.gencGirisimci,
      detail?.mukellefBilgi?.gencgirisimci,
      detail?.mukellefBilgi?.gencGirisimciBilgileri,
      pickArr('gencGirisimciBilgileri', 'gencgirisimciBilgileri', 'gencGirisimciler', 'gencgirisimciler', 'gencgirisimciList', 'vergimuafiyet')
    );
    const gencKeyNorm = (k) => String(k || '')
      .toLocaleLowerCase('tr-TR')
      .replace(/[ıİ]/g, 'i').replace(/[ğĞ]/g, 'g').replace(/[üÜ]/g, 'u')
      .replace(/[şŞ]/g, 's').replace(/[öÖ]/g, 'o').replace(/[çÇ]/g, 'c')
      .replace(/[^a-z0-9]+/g, '');
    const gencPick = (g, ...keys) => {
      if (!g || typeof g !== 'object') return '';
      for (const k of keys) {
        const v = g?.[k];
        if (v !== undefined && v !== null && String(v).trim() !== '') return v;
      }
      const wanted = new Set(keys.map(gencKeyNorm));
      for (const [k, v] of Object.entries(g)) {
        if (wanted.has(gencKeyNorm(k)) && v !== undefined && v !== null && String(v).trim() !== '') return v;
      }
      return '';
    };
    const gencFind = (g, must = [], mustNot = []) => {
      if (!g || typeof g !== 'object') return '';
      const ms = must.map(gencKeyNorm).filter(Boolean);
      const ns = mustNot.map(gencKeyNorm).filter(Boolean);
      for (const [k, v] of Object.entries(g)) {
        const nk = gencKeyNorm(k);
        if (ms.every(x => nk.includes(x)) && !ns.some(x => nk.includes(x)) && v !== undefined && v !== null && String(v).trim() !== '') return v;
      }
      return '';
    };
    const gencStartDate = (g) => gencPick(g,
      'muafiyetBaslamaTarihi', 'muafiyetbaslamatarihi', 'muafiyetbastar', 'muafiyetBasTar', 'muafiyetbaslama',
      'muafBaslamaTarihi', 'muafbaslamatarihi', 'muafbastar', 'muafBasTar',
      'istisnaBaslamaTarihi', 'istisnabastar', 'istisnaBasTar', 'baslangicTarihi',
      'baslamatarihi', 'baslamaTarihi', 'bastar', 'basTarih'
    ) || gencFind(g, ['muafiyet','baslama','tarih'], ['donem']) || gencFind(g, ['muaf','bas','tar'], ['donem']) || gencFind(g, ['istisna','bas','tar'], ['donem']);
    const gencEndDate = (g) => gencPick(g,
      'muafiyetBitisTarihi', 'muafiyetbitistarihi', 'muafiyetbittar', 'muafiyetBitTar', 'muafiyetbitis',
      'muafBitisTarihi', 'muafbitistarihi', 'muafbittar', 'muafBitTar',
      'istisnaBitisTarihi', 'istisnabittar', 'istisnaBitTar', 'bitistarihi', 'bitisTarihi', 'bittar', 'bitTarih'
    ) || gencFind(g, ['muafiyet','bitis','tarih'], ['donem']) || gencFind(g, ['muaf','bit','tar'], ['donem']) || gencFind(g, ['istisna','bit','tar'], ['donem']);
    const gencStartPeriod = (g) => gencPick(g, 'muafiyetBaslamaDonemi', 'muafiyetbaslamadonemi', 'muafiyetBasDonem', 'muafiyetbasdonem', 'muafBasDonem', 'basdonem', 'basDonem', 'baslamaDonemi') || gencFind(g, ['muafiyet','baslama','donem']) || gencFind(g, ['muaf','bas','donem']);
    const gencEndPeriod = (g) => gencPick(g, 'muafiyetBitisDonemi', 'muafiyetbitisdonemi', 'muafiyetBitDonem', 'muafiyetbitdonem', 'muafBitDonem', 'bitdonem', 'bitDonem', 'bitisDonemi') || gencFind(g, ['muafiyet','bitis','donem']) || gencFind(g, ['muaf','bit','donem']);
    const gencTurText = (g) => {
      const text = gencPick(g,
        'istisnaMuafiyetTuruText', 'istisnamuafiyetturutext', 'istisna_muafiyet_turu_text',
        'istisnaturuText', 'istisnaTuruText', 'istisnaMuafiyetAdi', 'istisnaadi',
        'muafiyetTuruText', 'muafiyetturutext'
      );
      const code = gencPick(g,
        'istisnaMuafiyetTuru', 'istisnamuafiyetturu', 'istisna_muafiyet_turu',
        'istisnaturu', 'istisnaTuru', 'istisnaturuKodu', 'istisnaMuafiyetTuruKodu',
        'muafiyetTuru', 'muafiyetturu', 'muafiyetTur', 'muafiyettur', 'muafTur', 'muaftur',
        'istisnaMuafiyetKod', 'istisnaMuafiyetKodu', 'muafiyetKodu', 'muafKod'
      ) || gencFind(g, ['istisna','tur']) || gencFind(g, ['muaf','tur']);
      if (text && code && !String(text).startsWith(String(code))) return `${code} - ${text}`;
      if (text) return text;
      if (String(code) === '1') return '1 - Genç Girişimci';
      // Genç girişimci listesi servis tarafından ayrı geldiyse tür alanı bazen boş kalıyor.
      // Bu bölümde kayıt varsa sistem ekranındaki karşılığı 1 - Genç Girişimci olarak yazılır.
      if (gencVergiText(g) !== '-' || gencStartDate(g) || gencEndDate(g) || gencStartPeriod(g) || gencEndPeriod(g)) return '1 - Genç Girişimci';
      return code ? String(code) : '-';
    };
    const gencVergiText = (g) => {
      const text = gencPick(g, 'vergituru', 'vergiTuru', 'vergiturutext', 'vergiTuruText', 'vergikodutext', 'vergiKoduText', 'vergiadi', 'vergiAdi', 'vergiTurAdi', 'vergituradi') || gencFind(g, ['vergi','tur']);
      const code = gencPick(g, 'vergikodu', 'vergiKodu', 'vkodu', 'vKodu', 'vergiKod', 'vergikod') || gencFind(g, ['vergi','kod']);
      if (text && code && !String(text).startsWith(String(code))) return `${code} - ${text}`;
      if (text) return text;
      if (String(code) === '0001' || String(code) === '1') return '0001 - YIL.GEL.V.';
      return code ? String(code) : '-';
    };
    const gencRows = gencList.length ? gencList.map(g => `
      <tr>
        <td>${esc(gencTurText(g))}</td>
        <td>${esc(gencVergiText(g))}</td>
        <td>${esc(fmtDate(gencStartDate(g)))}</td>
        <td>${esc(fmtDate(gencEndDate(g)))}</td>
        <td>${esc(donemText(gencStartPeriod(g)))}</td>
        <td>${esc(donemText(gencEndPeriod(g)))}</td>
      </tr>`).join('') : '<tr><td colspan="6">Kayıt yok</td></tr>';

    const gelirList = listFromContainer(detail?.gelirUnsur, detail?.gelirunsur, detail?.mukellefBilgi?.gelirUnsur, pickArr('gelirUnsuruBilgileri', 'gelirunsuruBilgileri', 'gelirUnsuru', 'gelirunsuru', 'gelirUnsuruList', 'gelirunsurlari'));
    const gelirRows = gelirList.length ? gelirList.map(g => `
      <tr>
        <td>${esc(gelirUnsuruText(g))}</td>
        <td>${esc(faalTerkPlain(g.faalterk || g.durum || g.faalTerk || '', g.faalterktext || g.faalTerkText || g.durumText || ''))}</td>
        <td>${esc(fmtDate(g.baslamatarihi || g.baslamaTarihi || g.bastar || g.basTarih || ''))}</td>
        <td>${esc(fmtDate(g.bitistarihi || g.bitisTarihi || g.bittar || g.bitTarih || ''))}</td>
      </tr>`).join('') : '<tr><td colspan="4">Kayıt yok</td></tr>';

    // Sistem ekranında üç ayrı bölüm var:
    // 1) FAALİYET BİLGİLERİ
    // 2) TERK FAALİYET BİLGİLERİ
    // 3) FAALİYET BİLGİLERİ GÖRÜNTÜLEME (NACE 2.1 REVİZYONU NEDENİYLE)
    // Önceki sürümlerde faaliyet + terk faaliyet aynı tabloda birleşebiliyordu.
    let faaliyetList = listFromContainer(
      detail?.faaliyetListesi,
      detail?.mukellefBilgi?.faaliyetListesi,
      detail?.faaliyetBilgileri,
      detail?.mukellefBilgi?.faaliyetBilgileri,
      detail?.faaliyetler,
      detail?.mukellefBilgi?.faaliyetler,
      detail?.faaliyet,
      detail?.mukellefBilgi?.faaliyet,
      pickArr('faaliyetListesi', 'faaliyetBilgileri', 'faaliyetler', 'faaliyet')
    );
    if (!faaliyetList.length) faaliyetList = collectNamedArrays(detail, ['faaliyet'], ['nace', 'genc', 'terk']);

    let terkFaaliyetList = listFromContainer(
      detail?.terkFaaliyetBilgileri,
      detail?.mukellefBilgi?.terkFaaliyetBilgileri,
      detail?.terkFaaliyetListesi,
      detail?.mukellefBilgi?.terkFaaliyetListesi,
      detail?.terkFaaliyetleri,
      detail?.mukellefBilgi?.terkFaaliyetleri,
      pickArr('terkFaaliyetBilgileri', 'terkFaaliyetListesi', 'terkFaaliyetleri')
    );
    if (!terkFaaliyetList.length) terkFaaliyetList = collectNamedArraysAll(detail, ['terk', 'faaliyet'], ['nace', 'genc']);

    const faaliyetText = (f) => [f.faaliyetkod || f.faaliyetKodu || f.faaliyet_kodu || f.nacekodu || f.naceKodu || f.kod || f.kodu, f.faaliyetad || f.faaliyetAdi || f.faaliyet_adi || f.faaliyetadi || f.naceadi || f.naceAdi || f.ad || f.adi || f.faaliyet].filter(Boolean).join(' - ') || '-';
    const faaliyetRowsFrom = (arr, allowFallback = false) => arr.length ? arr.map(f => `
      <tr>
        <td>${esc(f.isyerituru || f.isYeriTuru || f.isyeriTuru || (String(f.merkezsube || '') === '1' ? 'MERKEZ' : '') || 'MERKEZ')}</td>
        <td>${esc(f.sirano || f.siraNo || f.sira || f.faaliyetNo || f.sira_no || '-')}</td>
        <td>${esc(fmtDate(f.baslamatarihi || f.baslamaTarihi || f.bastar || f.basTarih || (allowFallback ? (row?.isebaslamatarihi || row?.birimbastar) : '') || ''))}</td>
        <td>${esc(fmtDate(f.bitistarihi || f.bitisTarihi || f.bittar || f.bitTarih || (allowFallback ? (row?.isibirakmatarihi || row?.birimbittar) : '') || ''))}</td>
        <td>${esc(faaliyetText(f))}</td>
      </tr>`).join('') : (allowFallback ? `<tr><td>MERKEZ</td><td>1</td><td>${esc(fmtDate(row?.isebaslamatarihi || row?.birimbastar))}</td><td>${esc(fmtDate(row?.isibirakmatarihi || row?.birimbittar))}</td><td>${esc([pickDeep('faaliyetkod', 'faaliyetKodu', 'faaliyetkodu'), pickDeep('faaliyetad', 'faaliyetAdi', 'faaliyetadi')].filter(Boolean).join(' - ') || '-')}</td></tr>` : '<tr><td colspan="5">Kayıt yok</td></tr>');
    const faaliyetRows = faaliyetRowsFrom(faaliyetList, true);
    const terkFaaliyetRows = faaliyetRowsFrom(terkFaaliyetList, false);

    let naceList = listFromContainer(detail?.faaliyetListesiNace, detail?.mukellefBilgi?.faaliyetListesiNace, detail?.naceFaaliyetleri, detail?.faaliyetNace, pickArr('faaliyetListesiNace', 'faaliyetNace', 'naceFaaliyetleri'));
    if (!naceList.length) naceList = collectNamedArrays(detail, ['nace'], []);
    const naceRows = naceList.length ? naceList.map((f, ni) => `
      <tr>
        <td>${esc(f.sira || f.sirano || f.siraNo || f.sira_no || (ni + 1))}</td>
        <td>${esc(fmtDate(f.baslamatarihi || f.baslamaTarihi || f.bastar || f.basTarih || ''))}</td>
        <td>${esc(fmtDate(f.bitistarihi || f.bitisTarihi || f.bittar || f.bitTarih || ''))}</td>
        <td>${esc(faaliyetText(f))}</td>
      </tr>`).join('') : '<tr><td colspan="4">Kayıt yok</td></tr>';

    vdDetailCache[idx] = { detail, detailMuk, row, mukList: detailMuk };

    const adresList = Array.isArray(detail?.adresbilgi) ? detail.adresbilgi : (Array.isArray(detail?.mukellefBilgi?.adresbilgi) ? detail.mukellefBilgi.adresbilgi : []);
    const yerlesimAdres = adresList.find(a => String(a?.adrestip || '') === '1') || adresList[0] || {};
    const isyeriAdres = adresList.find(a => String(a?.adrestip || '') === '2') || adresList[1] || adresList[0] || {};
    const buildAddressBoxFromObj = (title, a) => {
      const lines = [
        ['ADRES NO:', a?.adresno],
        ['MAHALLE / SEMT:', a?.mahallesemt],
        ['CADDE / SOKAK:', a?.caddesokak],
        ['DIŞ KAPI NO:', a?.diskapino],
        ['İÇ KAPI NO:', a?.ickapino],
        ['İL:', a?.iladi],
        ['İLÇE:', a?.ilceadi],
        ['BELDE / BUCAK:', a?.beldebucak],
        ['KÖY:', a?.koy]
      ].map(([label, val]) => `<div>${esc(label)}</div><div>${esc(textOrDash(val))}</div>`).join('');
      return `<div class="addrbox"><h4>${esc(title)}</h4><div class="kv">${lines}</div></div>`;
    };

    const yerlesimBox = buildAddressBoxFromObj('YERLEŞİM YERİ ADRESİ', yerlesimAdres);
    const isyeriBox = buildAddressBoxFromObj('İŞYERİ ADRESİ', isyeriAdres);

    const msgHtml = detailErr ? `<div class="msg" style="margin-bottom:10px">Vergi dairesi detayı açıldı. Ek alanların bir kısmı servis cevabında gelmediği için boş bırakıldı. Detay servis notu: ${esc(detailErr)}</div>` : '';

    c.innerHTML = `
      <div class="actions"><button class="btn" data-back-list="1">← Vergi dairesi listesine dön</button><button class="btn" data-print="1">Yazdır</button><span class="tiny">2. aşama: Vergi dairesi detayı açıldı. Vergi bilgileri satırına tıklarsanız vergi detayı açılır.</span></div>
      ${msgHtml}
      <div class="info" style="max-width:1100px">
        <div class="k">VERGİ NO:</div><div>${esc(pick(detail?.vergino, d?.vergino, d?.vkn, row?.vergino, q.vkn, '-'))}</div>
        <div class="k">VERGİ DAİRESİ:</div><div>${esc(textOrDash(pick(detail?.vdadi, rowVd(row))))}</div>
        <div class="k">T.C. KİMLİK NO:</div><div>${esc(pick(d?.tckn, d?.mukellefno, q.tckn, detail?.mukellefno, '-'))}</div>
        <div class="k">MÜKELLEF TÜRÜ:</div><div>${esc(muk(pick(detail?.tamdarmukelleffiyet, d?.tamdarmukelleffiyet)))}</div>
        <div class="k">ADI:</div><div>${esc(ad || pickDeep('adi', 'ad')) || '-'}</div>
        <div class="k">İŞ YERİ TÜRÜ:</div><div>${esc(textOrDash(mappedIsyeriTuru))}</div>
        <div class="k">SOYADI:</div><div>${esc(soyad || pickDeep('soyadi', 'soyad') || d?.kimlikunvan || q.unvan || '-')}</div>
        <div class="k">İŞ YERİ NİTELİĞİ:</div><div>${esc(textOrDash(mappedIsyeriNitelik))}</div>
        <div class="k">BABA ADI:</div><div>${esc(textOrDash(pickDeep('babaadi', 'babaAdi', 'babaad')))}</div>
        <div class="k">ŞUBE NO:</div><div>${esc(textOrDash(pick(detail?.subeno, row?.subeno)))}</div>
        <div class="k">ANA ADI:</div><div>${esc(textOrDash(pickDeep('anaadi', 'anaAdi', 'anaad')))}</div>
        <div class="k">ŞUBE ADI:</div><div>${esc(textOrDash(pick(detail?.subeadi, row?.subeadi, 'Merkez')))}</div>
        <div class="k">DOĞUM TARİHİ:</div><div>${esc(textOrDash(pick(detail?.dogumtarihiformatli, d?.dogumtarihiformatli, fmtDate(detail?.dogumtarihi), fmtDate(d?.dogumtarihi))))}</div>
        <div class="k">UYRUĞU:</div><div>${esc(textOrDash(pickDeep('uyruktext', 'uyrugu', 'uyruk') || '1 - T.C.'))}</div>
        <div class="k">DOĞUM YERİ:</div><div>${esc(textOrDash(pick(detail?.dogumyeritext, [d?.dogumyeri, d?.dogumyeritext].filter(Boolean).join(' - '))))}</div>
        <div class="k">ÜLKE:</div><div>${esc(textOrDash(pickDeep('ulke', 'ulketext') || 'TÜRKİYE'))}</div>
        <div class="k">CİNSİYET:</div><div>${esc(textOrDash(pickDeep('cinsiyet', 'cinsiyettext')))}</div>
        <div class="k">TABELA ÜNVANI:</div><div>${esc(textOrDash(pickDeep('tabelaunvani', 'tabelaUnvani')))}</div>
        <div class="k">İŞE BAŞLAMA TARİHİ:</div><div>${esc(fmtDate(pick(detail?.isebaslamatarihi, row?.isebaslamatarihi, row?.birimbastar)))}</div>
        <div class="k">DURUM:</div><div>${esc(textOrDash(durum(row)))}</div>
        <div class="k">İŞİ BIRAKMA TARİHİ:</div><div>${esc(fmtDate(pick(detail?.isibirakmatarihi, row?.isibirakmatarihi, row?.birimbittar)))}</div>
        <div class="k">TERK NEDENİ:</div><div>${esc(textOrDash(terk(pick(detail?.mukblgislemturubittur, row?.mukblgislemturubittur), pickDeep('mukblgislemturubitturtext', 'terkNedeniText', 'terknedeniadi', 'terkNedeniAdi'))))}</div>
        <div class="k">TEL NO:</div><div>${esc(textOrDash(pickDeep('telno', 'telefon', 'telNo')))}</div>
        <div class="k"></div><div></div>
      </div>

      <div class="boxgrid" style="grid-template-columns:1fr 1fr;margin-top:14px">
        <div>
          <div class="detail-title">BAŞLAYAN HUKUKİ DURUM:</div>
          <div class="msg">${esc(textOrDash(hukukiBasText))}</div>
        </div>
        <div>
          <div class="detail-title">HUKUKİ DURUM BAŞLAMA TARİHİ:</div>
          <div class="msg">${esc(textOrDash(hukukiBasTarih))}</div>
        </div>
        <div>
          <div class="detail-title">BİTEN HUKUKİ DURUM:</div>
          <div class="msg">${esc(textOrDash(hukukiBitText))}</div>
        </div>
        <div>
          <div class="detail-title">HUKUKİ DURUM BİTİŞ TARİHİ:</div>
          <div class="msg">${esc(textOrDash(hukukiBitTarih))}</div>
        </div>
      </div>

      <div class="detail-title">HUKUKİ DURUM BAŞLAMA BİLGİSİ</div>
      <div class="tablewrap"><table><thead><tr><th>TÜRÜ</th><th>TARİHİ</th><th>BİLGİ GİRİŞİ YAPAN VD.</th></tr></thead><tbody>${hukukiBasRows}</tbody></table></div>
      <div class="detail-title">HUKUKİ DURUM SONUÇLANMA BİLGİSİ</div>
      <div class="tablewrap"><table><thead><tr><th>TÜRÜ</th><th>TARİHİ</th><th>BİLGİ GİRİŞİ YAPAN VD.</th></tr></thead><tbody>${hukukiSonRows}</tbody></table></div>

      <div class="detail-title">GENÇ GİRİŞİMCİLERDE KAZANÇ İSTİSNASI BİLGİLERİ</div>
      <div class="tablewrap"><table><thead><tr><th>İSTİSNA / MUAFİYET TÜRÜ</th><th>VERGİ TÜRÜ</th><th>MUAFİYET BAŞLAMA TARİHİ</th><th>MUAFİYET BİTİŞ TARİHİ</th><th>MUAFİYET BAŞLAMA DÖNEMİ</th><th>MUAFİYET BİTİŞ DÖNEMİ</th></tr></thead><tbody>${gencRows}</tbody></table></div>

      <div class="detail-title">VERGİ BİLGİLERİ</div>
      <div class="tablewrap"><table><thead><tr><th>VERGİ KODU</th><th>DÖNEM</th><th>BAŞLAMA TARİHİ</th><th>BAŞLAMA DÖNEMİ</th><th>BIRAKMA TARİHİ</th><th>BIRAKMA DÖNEMİ</th><th>TERK NEDENİ</th><th>İSTİSNA / MUAFİYET</th></tr></thead><tbody>${vergiRows}</tbody></table></div>

      <div class="detail-title">GELİR UNSURU BİLGİLERİ</div>
      <div class="tablewrap"><table><thead><tr><th>GELİR UNSURU</th><th>FAAL / TERK</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th></tr></thead><tbody>${gelirRows}</tbody></table></div>

      <div class="boxgrid">${yerlesimBox}${isyeriBox}</div>

      <div class="detail-title">FAALİYET BİLGİLERİ</div>
      <div class="tablewrap"><table><thead><tr><th>İŞ YERİ TÜRÜ</th><th>SIRA NO</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAALİYET KODU - ADI</th></tr></thead><tbody>${faaliyetRows}</tbody></table></div>

      <div class="detail-title">TERK FAALİYET BİLGİLERİ</div>
      <div class="tablewrap"><table><thead><tr><th>İŞ YERİ TÜRÜ</th><th>SIRA NO</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAALİYET KODU - ADI</th></tr></thead><tbody>${terkFaaliyetRows}</tbody></table></div>

      <div class="detail-title">FAALİYET BİLGİLERİ GÖRÜNTÜLEME (NACE 2.1 REVİZYONU NEDENİYLE)</div>
      <div class="tablewrap"><table><thead><tr><th>SIRA NO</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAALİYET KODU - ADI</th></tr></thead><tbody>${naceRows}</tbody></table></div>
      <div class="tiny" style="margin-top:8px">Not: Resimdeki ikinci aşamaya benzer detay görünümü verildi. Servis cevabında gelmeyen alanlar boş bırakılır.</div>`;

    c.querySelector('[data-back-list="1"]')?.addEventListener('click', renderList);
    c.querySelector('[data-print="1"]')?.addEventListener('click', () => popup.print());
    c.querySelectorAll('.tax-row').forEach((tr, mi) => tr.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      if (activeView !== 'vd') return;
      renderVergiDetay(idx, mi, tr.dataset || {});
    }));
  };

  const renderVergiDetay = async (vdIdx, mukIdx, ds = {}) => {
    const row = vdRows[vdIdx] || vdRows[0] || {};
    const cached = vdDetailCache[vdIdx] || {};
    const mukList = Array.isArray(cached.mukList) && cached.mukList.length ? cached.mukList : getMukListForRow(row);
    const chosen = mukList[mukIdx] || mukList[0] || {};
    const c = content();
    if (!c) return;
    activeView = 'vergi';
    c.innerHTML = '<div class="loading">Vergi kodu detayı sorgulanıyor...</div>';
    try {
      const resp = await itFetchSicilVergiDetay({
        mukblgoid: ds.mukblgoid || chosen?.mukblgoid || row?.mukblgoid || d?.mukblgoid || '',
        vkn: ds.vergino || chosen?.vergino || d?.vergino || d?.vkn || q.vkn || row?.vergino || '',
        vKodu: ds.vkodu || chosen?.vergikodu || chosen?.vKodu || String(chosen?.vergikodutext || '').replace(/\D+/g, '').slice(0, 4),
        vdkodu: ds.vdkodu || chosen?.vdkodu || row?.vdkodu || ''
      });
      const det = resp?.data || {};
      const list = Array.isArray(det?.mukellefiyet) ? det.mukellefiyet : [];
      const first = list[0] || chosen || {};
      const satirlar = list.length ? list.map(m => `<tr><td>${esc(m.basdonemkodutext || '-')}</td><td>${esc(date(m.bastar))}</td><td>${esc(m.basdonem || m.baytextbyil || '-')}</td><td>${esc(date(m.bittar))}</td><td>${esc(m.bitdonem || m.bitaytextbityil || '-')}</td><td>${esc(terkNedeniFromVergi(m))}</td></tr>`).join('') : '<tr><td colspan="6">Kayıt bulunamadı.</td></tr>';
      c.innerHTML = `
        <div class="actions"><button class="btn" data-back-vd="1">← Vergi dairesi detayına dön</button><button class="btn" data-back-list="1">Liste</button><button class="btn" data-print="1">Yazdır</button></div>
        <div class="info">
          <div class="k">VERGİ NO:</div><div>${esc(det?.vergino || det?.vkn || d?.vergino || q.vkn || '-')}</div>
          <div class="k">VERGİ DAİRESİ:</div><div>${esc(det?.vdadi || rowVd(row))}</div>
          <div class="k">ÜNVAN:</div><div>${esc(det?.kimlikunvan || d?.kimlikunvan || q.unvan || '-')}</div>
          <div class="k">VERGİ KODU:</div><div>${esc(first?.vergikodutext || first?.vergikodu || '-')}</div>
          <div class="k">MUHTASAR:</div><div>${/muhtasar|stopaj/i.test(String(first?.vergikodutext || '')) ? 'Evet' : '-'}</div>
          <div class="k">ŞUBE NO:</div><div>${esc(first?.subeno || row?.subeno || '-')}</div>
          <div class="k">ŞUBE ADI:</div><div>${esc(first?.subeadi || row?.subeadi || '-')}</div>
          <div class="k">İŞ YERİ TÜRÜ:</div><div>${esc(first?.isyerituru ? first.isyerituru + ' - Merkez' : (row?.isyerituru ? row.isyerituru + ' - Merkez' : '-'))}</div>
          <div class="k">İŞ YERİ NİTELİĞİ:</div><div>${esc(first?.isyerinitelik ? first.isyerinitelik + ' - Merkez' : (row?.isyerinitelik ? row.isyerinitelik + ' - Merkez' : '-'))}</div>
        </div>
        <div class="tablewrap"><table><thead><tr><th>DÖNEM KODU</th><th>BAŞLAMA TARİHİ</th><th>BAŞLAMA DÖNEMİ</th><th>BIRAKMA TARİHİ</th><th>BIRAKMA DÖNEMİ</th><th>TERK NEDENİ</th></tr></thead><tbody>${satirlar}</tbody></table></div>`;
      c.querySelector('[data-back-vd="1"]')?.addEventListener('click', () => renderVdDetail(vdIdx));
      c.querySelector('[data-back-list="1"]')?.addEventListener('click', renderList);
      c.querySelector('[data-print="1"]')?.addEventListener('click', () => popup.print());
    } catch (e) {
      c.innerHTML = `<div class="actions"><button class="btn" data-back-vd="1">← Geri Dön</button></div><div class="msg">Vergi kodu detayı açılamadı: ${esc(e?.message || String(e))}</div>`;
      c.querySelector('[data-back-vd="1"]')?.addEventListener('click', () => renderVdDetail(vdIdx));
    }
  };
  // İlk ekranı tamamen temiz HTML ile yeniden kuruyoruz.
  // Böylece eski inline onclick akışı kalmıyor ve 1. tıktan sonra yanlışlıkla 3. aşamaya atlamıyor.
  renderList();
}

function itOpenHtmlPopup(titleText, initialHtml = '') {
  const sw = window.screen && window.screen.availWidth ? window.screen.availWidth : 1366;
  const sh = window.screen && window.screen.availHeight ? window.screen.availHeight : 768;
  const w = Math.min(1180, Math.max(860, Math.floor(sw * 0.74)));
  const h = Math.min(860, Math.max(620, Math.floor(sh * 0.82)));
  const left = 24;
  const top = 36;
  const name = `${String(titleText || 'Pencere').replace(/[^a-z0-9_]+/gi, '_')}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const win = window.open('', name, `popup=yes,noopener=no,noreferrer=no,resizable=yes,scrollbars=yes,toolbar=no,menubar=no,location=no,status=no,width=${w},height=${h},left=${left},top=${top}`);
  if (!win) return null;
  try {
    win.document.open();
    win.document.write(initialHtml || '<!doctype html><html><head><meta charset="utf-8"><title>Yükleniyor...</title></head><body style="font-family:Arial,sans-serif;padding:18px">Yükleniyor...</body></html>');
    win.document.close();
    win.focus();
  } catch (_) {}
  return win;
}

function itBuildLoadingHtml(title, text) {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${itHtmlEscape(title || 'Yükleniyor')}</title></head><body style="font-family:Arial,Helvetica,sans-serif;background:#fff;color:#222;padding:24px"><h2 style="margin:0 0 10px">${itHtmlEscape(title || 'Yükleniyor')}</h2><div>${itHtmlEscape(text || 'Yükleniyor...')}</div></body></html>`;
}

function itBuildErrorHtml(title, text) {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${itHtmlEscape(title || 'Hata')}</title></head><body style="font-family:Arial,Helvetica,sans-serif;background:#fff;color:#222;padding:24px"><h2 style="margin:0 0 10px;color:#b00020">${itHtmlEscape(title || 'Hata')}</h2><div>${itHtmlEscape(text || 'İşlem sırasında hata oluştu.')}</div></body></html>`;
}

function openItPreviewPopupWindow(url, titleText = 'Evrak Önizleme') {
  if (!url) return null;
  try {
    const sw = window.screen && window.screen.availWidth ? window.screen.availWidth : 1366;
    const sh = window.screen && window.screen.availHeight ? window.screen.availHeight : 768;
    const sl = window.screen && Number.isFinite(window.screen.availLeft) ? window.screen.availLeft : 0;
    const st = window.screen && Number.isFinite(window.screen.availTop) ? window.screen.availTop : 0;
    const idx = (window.__istakipPreviewPopupCount = (window.__istakipPreviewPopupCount || 0) + 1);
    const w = Math.min(980, Math.max(720, Math.floor(sw * 0.58)));
    const h = Math.min(820, Math.max(560, Math.floor(sh * 0.78)));
    const left = Math.max(0, Math.floor(sl + 20 + ((idx - 1) % 4) * 34));
    const top = Math.max(0, Math.floor(st + 40 + ((idx - 1) % 4) * 28));
    const features = [
      'popup=yes',
      'noopener=no',
      'noreferrer=no',
      'resizable=yes',
      'scrollbars=yes',
      'toolbar=no',
      'menubar=no',
      'location=yes',
      'status=no',
      `width=${w}`,
      `height=${h}`,
      `left=${left}`,
      `top=${top}`
    ].join(',');
    const name = `${String(titleText || 'Evrak_Onizleme').replace(/[^a-z0-9_]+/gi, '_')}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const win = window.open(url, name, features);
    if (win) {
      try { win.focus(); } catch (_) {}
      return win;
    }
  } catch (_) {}
  return null;
}

function ensurePreviewModal() {
  // v4.31.67: Her önizleme için ayrı pencere oluştur. Eski tekil #it_preview_modal
  // kullanımı ikinci önizlemede mevcut pencerenin içeriğini değiştiriyordu.
  const uid = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  let modal = document.createElement('div');
  modal.id = `it_preview_modal_${uid}`;
  modal.className = 'it-preview-modal-instance';
  modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.58);z-index:2147483647;padding:20px;';
  modal.innerHTML = `
    <div id="it_preview_box">
      <div id="it_preview_head">
        <div id="it_preview_title">Evrak Önizleme</div>
        <div id="it_preview_actions">
          <button type="button" class="it-btn-mini" id="it_preview_min">_</button>
          <button type="button" class="it-btn-mini" id="it_preview_reset">□</button>
          <button type="button" class="it-btn-mini" id="it_preview_reload">Yenile</button>
          <button type="button" class="it-btn-mini" id="it_preview_close">Kapat</button>
        </div>
      </div>
      <iframe id="it_preview_frame" referrerpolicy="no-referrer"></iframe>
      <div id="it_preview_msg" style="display:none"></div>
    </div>`;
  (document.body || document.documentElement).appendChild(modal);
  modal.addEventListener('click', ev => {
    if (ev.target === modal) { modal.classList.remove('open'); modal.style.display = 'none'; }
  });
  modal.querySelector('#it_preview_close').onclick = () => { modal.classList.remove('open'); modal.style.display = 'none'; };
  modal.querySelector('#it_preview_min').onclick = () => {
    const frame = modal.querySelector('#it_preview_frame');
    const msg = modal.querySelector('#it_preview_msg');
    const box = modal.querySelector('#it_preview_box');
    const hidden = frame.style.display === 'none' && msg.style.display === 'none';
    if (hidden) {
      frame.style.display = '';
      box.style.height = box.dataset.prevHeight || 'min(900px,92vh)';
      box.style.width = box.dataset.prevWidth || 'min(1280px,96vw)';
    } else {
      box.dataset.prevHeight = box.style.height || '';
      box.dataset.prevWidth = box.style.width || '';
      frame.style.display = 'none';
      msg.style.display = 'none';
      box.style.height = '48px';
      box.style.width = '520px';
    }
  };
  modal.querySelector('#it_preview_reset').onclick = () => {
    const box = modal.querySelector('#it_preview_box');
    if (!box) return;
    box.style.width = 'min(1280px,96vw)';
    box.style.height = 'min(900px,92vh)';
    box.style.left = '50%';
    box.style.top = '50%';
    box.style.right = 'auto';
    box.style.bottom = 'auto';
    box.style.transform = 'translate(-50%,-50%)';
  };
  modal.querySelector('#it_preview_reload').onclick = () => {
    const frame = modal.querySelector('#it_preview_frame');
    const src = frame.getAttribute('src');
    if (src) frame.setAttribute('src', src);
  };
  requestAnimationFrame(() => {
    const box = modal.querySelector('#it_preview_box');
    const head = modal.querySelector('#it_preview_head');
    enableDrag(box, head, { clearTransform: true });
  });
  return modal;
}

function showPreviewModal(url, titleText) {
  // v4.31.67: Önizleme tıklamaları birbirini ezmesin diye önce benzersiz popup aç.
  // Popup engellenirse alttaki çoklu modal yedeği çalışır.
  const pop = openItPreviewPopupWindow(url, titleText || 'Evrak Önizleme');
  if (pop) return;
  const modal = ensurePreviewModal();
  const frame = modal.querySelector('#it_preview_frame');
  const msg = modal.querySelector('#it_preview_msg');
  const title = modal.querySelector('#it_preview_title');
  title.textContent = titleText || 'Evrak Önizleme';
  msg.style.display = 'none';
  msg.textContent = '';
  frame.style.display = '';
  frame.src = url;
  modal.classList.add('open');
  modal.style.display = 'flex';
  const box = modal.querySelector('#it_preview_box');
  if (box && box.style.height === '48px') {
    box.style.width = 'min(1280px,96vw)';
    box.style.height = 'min(900px,92vh)';
    box.style.left = '50%';
    box.style.top = '50%';
    box.style.right = 'auto';
    box.style.bottom = 'auto';
    box.style.transform = 'translate(-50%,-50%)';
  }

  let loaded = false;
  const timer = setTimeout(() => {
    if (loaded) return;
    msg.style.display = '';
    msg.innerHTML = 'Önizleme iframe içinde açılamadıysa sunucu buna izin vermiyor olabilir.<br><br>Bağlantıyı kopyalayıp adres çubuğunda açmayı deneyebilirsin.';
  }, 4000);

  frame.onload = () => {
    loaded = true;
    clearTimeout(timer);
  };
}


function enableDrag(el, handle, opts = {}) {
  if (!el || !handle) return;
  if (handle.__dragBound) return;
  handle.__dragBound = true;

  let dragging = false;
  let startX = 0, startY = 0, startLeft = 0, startTop = 0;

  const onMove = (ev) => {
    if (!dragging) return;
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;
    const rect = el.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - Math.min(rect.width, window.innerWidth));
    const maxTop = Math.max(0, window.innerHeight - 44);
    el.style.left = `${Math.max(0, Math.min(maxLeft, startLeft + dx))}px`;
    el.style.top = `${Math.max(0, Math.min(maxTop, startTop + dy))}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    if (opts.clearTransform) el.style.transform = 'none';
  };

  const onUp = () => {
    dragging = false;
    document.body.style.userSelect = '';
    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('mouseup', onUp, true);
  };

  handle.addEventListener('mousedown', (ev) => {
    if (ev.button !== 0) return;
    if (ev.target && ev.target.closest('button,a,input,select,textarea,iframe')) return;
    const rect = el.getBoundingClientRect();
    dragging = true;
    startX = ev.clientX;
    startY = ev.clientY;
    startLeft = rect.left;
    startTop = rect.top;
    el.style.left = `${rect.left}px`;
    el.style.top = `${rect.top}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    if (opts.clearTransform) el.style.transform = 'none';
    document.body.style.userSelect = 'none';
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mouseup', onUp, true);
    ev.preventDefault();
    ev.stopPropagation();
  }, true);
}


function enablePanelResizeHandles(panel) {
  if (!panel || panel.__itResizeHandlesBound) return;
  panel.__itResizeHandlesBound = true;

  const minW = 540;
  const minH = 220;
  const margin = 8;

  const bind = (sel, mode) => {
    const h = panel.querySelector(sel);
    if (!h) return;
    h.addEventListener('mousedown', (ev) => {
      if (ev.button !== 0) return;
      const r = panel.getBoundingClientRect();
      const startX = ev.clientX;
      const startY = ev.clientY;
      const startLeft = r.left;
      const startTop = r.top;
      const startRight = r.right;
      const startW = r.width;
      const startH = r.height;
      panel.style.left = `${r.left}px`;
      panel.style.top = `${r.top}px`;
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
      panel.style.width = `${r.width}px`;
      panel.style.height = `${r.height}px`;
      panel.style.transform = 'none';
      document.body.style.userSelect = 'none';

      const onMove = (e) => {
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        if (mode.includes('left')) {
          const maxW = Math.max(minW, Math.min(window.innerWidth - margin, startRight - margin));
          let newW = Math.max(minW, Math.min(maxW, startW - dx));
          let newLeft = startRight - newW;
          if (newLeft < margin) {
            newLeft = margin;
            newW = startRight - margin;
          }
          panel.style.left = `${Math.max(margin, newLeft)}px`;
          panel.style.width = `${Math.max(minW, newW)}px`;
        }

        if (mode.includes('bottom')) {
          const maxH = Math.max(minH, window.innerHeight - startTop - margin);
          const newH = Math.max(minH, Math.min(maxH, startH + dy));
          panel.style.height = `${newH}px`;
          panel.style.maxHeight = `${Math.max(minH, window.innerHeight - startTop - margin)}px`;
        }

        e.preventDefault();
        e.stopPropagation();
      };

      const onUp = () => {
        document.body.style.userSelect = '';
        document.removeEventListener('mousemove', onMove, true);
        document.removeEventListener('mouseup', onUp, true);
        fitPanelToViewport(panel);
      };

      document.addEventListener('mousemove', onMove, true);
      document.addEventListener('mouseup', onUp, true);
      ev.preventDefault();
      ev.stopPropagation();
    }, true);
  };

  bind('.it-resize-left', 'left');
  bind('.it-resize-bottom', 'bottom');
  bind('.it-resize-bottom-left', 'left-bottom');
}

function bindMainPanelMoveAndResize(panel) {
  try {
    if (!panel) return;
    const header = panel.querySelector('.hdr');
    enableDrag(panel, header, { clearTransform: true });
    enablePanelResizeHandles(panel);
    panel.style.resize = 'none';
    fitPanelToViewport(panel);
    try { stabilizeMainPanelLayout(panel); } catch (_) {}
  } catch (_) {}
}



function onlyDigits(v){ return String(v || '').replace(/\D+/g, ''); }

function limit10InputValue(inp){
  if (!inp) return;
  inp.value = onlyDigits(inp.value).slice(0, 10);
}

function getRowsFromTable(panel){
  try{
    const table = panel.querySelector('.tblwrap table');
    if (!table || !table.tBodies || !table.tBodies[0]) return [];
    return Array.from(table.tBodies[0].rows || []);
  }catch(e){
    return [];
  }
}

function getVknFromRow(tr){
  try{
    const isTakipCell = tr.querySelector('.it-is-takip-cell') || (tr.cells ? tr.cells[2] : null) || (tr.cells ? tr.cells[1] : null);
    if (!isTakipCell) return '';
    const raw = String(isTakipCell.innerText || isTakipCell.textContent || '');
    const nums = raw.match(/\d{10,11}/g) || [];
    const vkn = nums.find(x => String(x).length === 10);
    return vkn || '';
  }catch(e){
    return '';
  }
}

function getHeaderFilter(panel){
  const startInp = panel.querySelector('#it_header_vkn_start');
  const endInp = panel.querySelector('#it_header_vkn_end');
  return {
    start: onlyDigits(startInp?.value || '').slice(0,10),
    end: onlyDigits(endInp?.value || '').slice(0,10)
  };
}

function inVknRange(vkn, start, end){
  if (!start && !end) return true;
  if (!vkn || String(vkn).length !== 10) return false;
  if (start && start.length !== 10) start = '';
  if (end && end.length !== 10) end = '';
  if (!start && !end) return true;
  if (start && !end) return vkn >= start;
  if (!start && end) return vkn <= end;
  return vkn >= start && vkn <= end;
}

function applyHeaderVknFilter(panel){
  try{
    const { start, end } = getHeaderFilter(panel);
    const rows = getRowsFromTable(panel);
    let visible = 0;
    rows.forEach(tr => {
      const vkn = getVknFromRow(tr);
      const ok = inVknRange(vkn, start, end);
      tr.style.display = ok ? '' : 'none';
      if (ok) visible++;
    });
    const log = panel.querySelector('#it_log');
    if (log) {
      const tag = `[VKN filtre] başlangıç=${start || '-'} bitiş=${end || '-'} görünür=${visible}/${rows.length}`;
      const lines = String(log.textContent || '').split('\n').filter(Boolean).filter(x => !x.startsWith('[VKN filtre]'));
      log.textContent = [tag].concat(lines).join('\n');
    }
  }catch(e){}
}

function ensureHeaderVknFilter(panel){
  try{
    const wrap = panel.querySelector('.tblwrap');
    const table = wrap?.querySelector('table');
    const theadRow = table?.querySelector('thead tr');
    if (!wrap || !table || !theadRow) return;

    if (!panel.querySelector('#it_header_vkn_filter_box')) {
      const box = document.createElement('div');
      box.id = 'it_header_vkn_filter_box';
      box.style.cssText = 'display:none; position:absolute; z-index:20; background:#0d1b31; border:1px solid #32486f; border-radius:8px; padding:8px; box-shadow:0 10px 24px rgba(0,0,0,.35); width:260px;';
      box.innerHTML = `
        <div style="font-size:12px; margin-bottom:6px;">VKN Aralığı</div>
        <div style="display:grid; gap:6px;">
          <input id="it_header_vkn_start" placeholder="VKN Başlangıç" maxlength="10" style="height:28px; padding:4px 8px;" />
          <input id="it_header_vkn_end" placeholder="VKN Bitiş" maxlength="10" style="height:28px; padding:4px 8px;" />
          <div style="display:flex; gap:6px;">
            <button type="button" id="it_header_vkn_apply" style="flex:1;">Uygula</button>
            <button type="button" id="it_header_vkn_clear" style="flex:1;">Temizle</button>
          </div>
        </div>
      `;
      wrap.style.position = 'relative';
      wrap.appendChild(box);

      const startInp = box.querySelector('#it_header_vkn_start');
      const endInp = box.querySelector('#it_header_vkn_end');
      const applyBtn = box.querySelector('#it_header_vkn_apply');
      const clearBtn = box.querySelector('#it_header_vkn_clear');

      [startInp, endInp].forEach(inp => {
        inp.addEventListener('input', () => {
          limit10InputValue(inp);
          applyHeaderVknFilter(panel);
        });
      });
      applyBtn.addEventListener('click', () => applyHeaderVknFilter(panel));
      clearBtn.addEventListener('click', () => {
        startInp.value = '';
        endInp.value = '';
        applyHeaderVknFilter(panel);
      });

      document.addEventListener('click', (ev) => {
        const headBtn = panel.querySelector('#it_istakip_head_filter_btn');
        if (!box.contains(ev.target) && ev.target !== headBtn) box.style.display = 'none';
      }, true);
    }

    const ths = Array.from(table.querySelectorAll('thead th'));
    const isTakipTh = ths.find(th => /İşTakip/i.test((th.textContent || '').replace(/\s+/g,'')));
    if (isTakipTh && !panel.querySelector('#it_istakip_head_filter_btn')) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.id = 'it_istakip_head_filter_btn';
      btn.textContent = '↕';
      btn.title = 'VKN aralık filtresi';
      btn.style.cssText = 'margin-left:6px; width:20px; height:20px; padding:0; line-height:18px; font-size:11px;';
      isTakipTh.appendChild(btn);

      btn.addEventListener('click', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const box = panel.querySelector('#it_header_vkn_filter_box');
        const rect = btn.getBoundingClientRect();
        const wrapRect = wrap.getBoundingClientRect();
        box.style.left = '0px';
      });
    }

    const btn = panel.querySelector('#it_istakip_head_filter_btn');
    const box = panel.querySelector('#it_header_vkn_filter_box');
    if (btn && box) {
      btn.onclick = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const b = btn.getBoundingClientRect();
        const w = wrap.getBoundingClientRect();
        const left = Math.max(0, b.left - w.left);
        const top = Math.max(24, b.bottom - w.top + 4);
        box.style.left = left + 'px';
        box.style.top = top + 'px';
        box.style.display = box.style.display === 'block' ? 'none' : 'block';
      };
    }
  }catch(e){}
}

function hideUpperFilterRows(panel){
  try{
    const rows = Array.from(panel.querySelectorAll('.row4, .row3'));
    rows.forEach(row => {
      const txt = String(row.textContent || '');
      if (
        /Vergi No\s*\/\s*TCKN\s*\/\s*Ünvan/.test(txt) ||
        /Uygun değil işleri sil/.test(txt) ||
        /isiUzerimeAl/.test(txt)
      ) {
        row.style.display = 'none';
      }
    });
  }catch(e){}
}

function isValidTckn(v){
  const s = String(v || '').trim();
  return /^\d{11}$/.test(s);
}
function normalizeDiscoveredUser(v){
  const s = String(v || '').trim();
  return isValidTckn(s) ? s : '';
}

function fitPanelToViewport(panel){
  try{
    if (!panel) return;
    const margin = 16;
    const body = panel.querySelector('.body');
    if (body) {
      body.style.flex = '1 1 auto';
      body.style.minHeight = '0';
      body.style.maxHeight = 'none';
      body.style.overflowY = 'auto';
      body.style.overflowX = 'hidden';
      body.style.background = '#08111f';
    }
    if (panel.classList.contains('collapsed')) return;
    panel.style.display = 'flex';
    panel.style.flexDirection = 'column';
    panel.style.overflow = 'hidden';
    panel.style.minWidth = '540px';
    panel.style.minHeight = '320px';
    panel.style.maxWidth = `${Math.max(540, window.innerWidth - margin * 2)}px`;
    const rect0 = panel.getBoundingClientRect();
    const top = Math.max(margin, rect0.top || parseInt(panel.style.top || '118', 10) || 118);
    const maxH = Math.max(320, window.innerHeight - top - margin);
    const maxW = Math.max(540, window.innerWidth - margin * 2);
    panel.style.maxHeight = `${maxH}px`;

    const rect = panel.getBoundingClientRect();
    if (!panel.style.height || /^auto$/i.test(panel.style.height)) {
      panel.style.height = `${Math.min(660, maxH)}px`;
    } else if (rect.height < 300 || rect.height > maxH) {
      panel.style.height = `${Math.max(320, Math.min(rect.height || 660, maxH))}px`;
    }
    if (rect.width < 540) panel.style.width = '540px';
    if (rect.width > maxW) panel.style.width = `${maxW}px`;

    const rect2 = panel.getBoundingClientRect();
    if (rect2.left < margin) {
      panel.style.left = `${margin}px`;
      panel.style.right = 'auto';
    }
    if (rect2.right > window.innerWidth - margin && panel.style.left && panel.style.left !== 'auto') {
      panel.style.left = `${Math.max(margin, window.innerWidth - margin - rect2.width)}px`;
      panel.style.right = 'auto';
    }
    if (rect2.top < margin) panel.style.top = `${margin}px`;
    if (rect2.bottom > window.innerHeight - margin) {
      panel.style.top = `${Math.max(margin, window.innerHeight - margin - rect2.height)}px`;
    }
  }catch(e){}
}

function resetPreviewBoxSize() {
  const box = document.getElementById('it_preview_box');
  if (!box) return;
  box.style.width = 'min(1280px,96vw)';
  box.style.height = 'min(900px,92vh)';
  box.style.left = '50%';
  box.style.top = '50%';
  box.style.right = 'auto';
  box.style.bottom = 'auto';
  box.style.transform = 'translate(-50%,-50%)';
}





function ykDigits(v) {
  return String(v || '').replace(/\D+/g, '');
}

function ykFormatDateYYYYMMDD(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}${m}${day}`;
}

function ykDateRangeSixMonths() {
  const end = new Date();
  const start = new Date(end);
  start.setMonth(start.getMonth() - 6);
  return {
    start: ykFormatDateYYYYMMDD(start),
    end: ykFormatDateYYYYMMDD(end)
  };
}

function ykGetSessionSeed() {
  try {
    const c = window.CSSession || {};
    const vd =
      (typeof c.getVdKodu === 'function' ? c.getVdKodu() : '') ||
      c.vdKodu || c.vdkodu || c.birim || state.discovery?.baseOrgoid || state.discovery?.orgoid || '';
    const user =
      (typeof c.getUserId === 'function' ? c.getUserId() : '') ||
      c.userId || window.userId || state.discovery?.baseUserId || state.discovery?.userId || '';
    const adi =
      (typeof c.getUserName === 'function' ? c.getUserName() : '') ||
      c.adi || window.userName || '';
    const birim = String(vd || '').trim();
    return {
      user: String(user || '').trim(),
      giris: String(user || '').trim(),
      birim,
      il: birim.slice(0, 3),
      adi: String(adi || '').trim(),
      userx: String(user || '').trim()
    };
  } catch (_) {
    const birim = String(state.discovery?.baseOrgoid || state.discovery?.orgoid || '').trim();
    const user = String(state.discovery?.baseUserId || state.discovery?.userId || '').trim();
    return { user, giris: user, birim, il: birim.slice(0, 3), adi: '', userx: user };
  }
}

function ykBuildSessionData(role = '20') {
  const seed = ykGetSessionSeed();
  return {
    rol: String(role),
    user: seed.user,
    giris: seed.giris,
    birim: seed.birim,
    il: seed.il,
    adi: seed.adi,
    userx: seed.userx
  };
}

function ykResolveToken() {
  try {
    return state.discovery?.tokensByModule?.e
      || state.discovery?.tokensByModule?.g
      || state.discovery?.tokensByModule?.gp
      || state.discovery?.tokensByModule?.evdo
      || state.discovery?.tokensByModule?.istakip
      || state.discovery?.baseToken
      || state.discovery?.token
      || new URLSearchParams(location.search).get('token')
      || '';
  } catch (_) {
    return '';
  }
}

async function ykPostEys(cmd, jp) {
  const p = new URLSearchParams();
  p.append('cmd', cmd);
  p.append('callid', String(Date.now()));
  const token = ykResolveToken();
  if (token) p.append('token', token);
  p.append('jp', JSON.stringify(jp || {}));

  const res = await fetch('http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch', {
    method: 'POST',
    body: p,
    credentials: 'include'
  });

  const txt = await res.text();
  if (!res.ok) throw new Error(`E-Yoklama ağ hatası: ${res.status} ${cmd}`);
  try { return JSON.parse(txt); }
  catch (_) { throw new Error('E-Yoklama cevabı JSON değil: ' + txt.slice(0, 160)); }
}

function ykDurumText(d) {
  if (d === null || d === undefined || d === '') return '-';
  const raw = String(d).trim();
  const n = Number(raw);
  switch (n) {
    case 10: return 'Yoklama Giriş';
    case 20: return 'Müdür Onay';
    case 30: return 'Koordinatör Onay';
    case 40: return 'Ekibe Atandı';
    case 50: return 'Yoklama Memuru';
    case 60: return 'Görev Başladı';
    case 70: return 'Devam Ediyor';
    case 80: return 'Sonuç Alındı';
    case 81: return 'Sonuçlandı';
    default:
      // Günlük akıştan bazı yerlerde zaten metin olarak "Müdür Onay" vb. gelebiliyor.
      if (raw && !/^[-–]$/.test(raw) && isNaN(n)) return raw;
      return n ? `Durum ${n}` : '-';
  }
}

function ykPickFirst(obj, keys) {
  if (!obj || typeof obj !== 'object') return '';
  for (const k of keys) {
    if (obj[k] !== undefined && obj[k] !== null && String(obj[k]).trim() !== '') return obj[k];
  }
  return '';
}

function ykGetDurumRaw(item) {
  const direct = ykPickFirst(item, [
    'durum','DURUM','ydurum','YDURUM','yDurum','YDurum',
    'durumText','DURUMTEXT','durumAciklama','durumAçıklama','durumAdi','durumAdı',
    'yoklamaDurum','yoklamaDurumu','yoklama_durum','yoklamaDurumText',
    'sonDurum','son_durum','sonucDurum','sonucText','sonuc','asama','aşama','asamaAdi','aşamaAdı',
    'adimAdi','adımAdı','akisDurum','akışDurum','akisDurumAdi','akışDurumAdı','islemDurumu','işlemDurumu'
  ]);
  if (direct !== '') return direct;

  const textBlob = [
    item?.aciklama, item?.açıklama, item?.islemAciklama, item?.işlemAçıklama,
    item?.mesaj, item?.message, item?.data, item?.sonucMesaj
  ].filter(Boolean).join(' ');
  const t = String(textBlob || '').toLocaleLowerCase('tr-TR');
  if (t.includes('koordinat')) return 'Koordinatör Onay';
  if (t.includes('müdür') || t.includes('mudur')) return 'Müdür Onay';
  if (t.includes('ekibe') || t.includes('ekip')) return 'Ekibe Atandı';
  if (t.includes('sonuçlandı') || t.includes('sonuclandi')) return 'Sonuçlandı';
  if (t.includes('sonuç alındı') || t.includes('sonuc alindi')) return 'Sonuç Alındı';
  if (t.includes('görev başladı') || t.includes('gorev basladi')) return 'Görev Başladı';
  if (t.includes('yoklama giriş') || t.includes('yoklama giris')) return 'Yoklama Giriş';
  return '';
}

function ykBuildSonucUrl(ykodu) {
  const y = String(ykodu || '').trim();
  return y ? `http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?yKodu=${encodeURIComponent(y)}` : '';
}

function ykLooksLikeKod(value) {
  return typeof value === 'string' && /^\d{8}Y\d{6}[A-Z0-9]+$/i.test(value);
}

function ykCollectObjects(root, out = [], seen = new Set()) {
  // v4.31.144: Bazı E-Yoklama cevaplarında data alanı JSON string olarak dönebiliyor.
  // String JSON parse edilmezse getYoklamalar cevabındaki 4 yoklama yerine ekranda tek/eksik kod görünebiliyordu.
  if (typeof root === 'string') {
    const txt = root.trim();
    if ((txt.startsWith('{') && txt.endsWith('}')) || (txt.startsWith('[') && txt.endsWith(']'))) {
      try { return ykCollectObjects(JSON.parse(txt), out, seen); } catch (_) {}
    }
    return out;
  }
  if (Array.isArray(root)) {
    for (const item of root) ykCollectObjects(item, out, seen);
    return out;
  }
  if (root && typeof root === 'object') {
    if (seen.has(root)) return out;
    seen.add(root);
    out.push(root);
    for (const value of Object.values(root)) ykCollectObjects(value, out, seen);
  }
  return out;
}

function ykParseMaybeJson(value) {
  if (typeof value !== 'string') return value;
  const txt = value.trim();
  if (!txt) return value;
  if ((txt.startsWith('{') && txt.endsWith('}')) || (txt.startsWith('[') && txt.endsWith(']'))) {
    try { return JSON.parse(txt); } catch (_) {}
  }
  return value;
}

function ykExtractItems(resp) {
  // HAR'daki srvcYoklama_getYoklamalar cevabı doğrudan { data:[...] } şeklinde.
  // Önce bu ana liste alınır. Böylece root/metadata objesi veya ara wrapper'lar satır gibi sayılmaz,
  // aynı VKN için aynı gün dönen 4 yoklama kodu da eksiksiz korunur.
  const directCandidates = [];
  const parsedResp = ykParseMaybeJson(resp);
  if (Array.isArray(parsedResp)) directCandidates.push(parsedResp);
  if (parsedResp && typeof parsedResp === 'object') {
    const d = ykParseMaybeJson(parsedResp.data);
    if (Array.isArray(d)) directCandidates.push(d);
    if (d && typeof d === 'object') {
      if (Array.isArray(d.data)) directCandidates.push(d.data);
      if (Array.isArray(d.rows)) directCandidates.push(d.rows);
      if (Array.isArray(d.list)) directCandidates.push(d.list);
    }
    if (Array.isArray(parsedResp.rows)) directCandidates.push(parsedResp.rows);
    if (Array.isArray(parsedResp.list)) directCandidates.push(parsedResp.list);
  }

  const rows = [];
  const seen = new Set();
  const addRow = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    const kod = ykGetKod(obj);
    const hasUseful =
      kod || obj.vkn || obj.tckn || obj.unvan || obj.adsoyadunvan ||
      ykGetDurumRaw(obj) || obj.ilkislem || obj.sonislem || obj.adrestxt || obj.adresno || obj.yturu;
    if (!hasUseful) return;
    const key = kod || [
      obj.vkn || '', obj.tckn || '', obj.ilkislem || '', obj.sonislem || '',
      obj.durum || '', obj.servis || '', obj.adresno || '', String(obj.aciklama || '').slice(0, 80)
    ].join('|') || JSON.stringify(obj).slice(0, 120);
    if (seen.has(key)) return;
    seen.add(key);
    rows.push(obj);
  };

  if (directCandidates.length) {
    directCandidates.flat().forEach(addRow);
    return rows;
  }

  for (const obj of ykCollectObjects(parsedResp)) addRow(obj);
  return rows;
}

function ykGetKod(item) {
  const direct = item?.ykodu || item?.yKod || item?.ykod || item?.yKodu ||
    item?.yoklamaKodu || item?.yoklamakodu || item?.kod || item?.ykodu1 || '';
  return String(direct || '').trim();
}

function ykGetOptime(item) {
  const raw = String(
    item?.optime ||
    item?.sonislem ||
    item?.ilkislem ||
    item?.islemZamani ||
    item?.tarih ||
    item?.giris ||
    ykGetKod(item).slice(0, 8) ||
    ''
  ).replace(/\D+/g, '');
  return Number(raw || 0);
}

function ykGetMeaningfulDurum(item) {
  if (!item) return '';
  const raw = ykGetDurumRaw(item);
  let text = ykDurumText(raw);
  if (text && text !== '-' && !/^Durum\s*0$/i.test(text)) return text;
  const rol = String(item?.rol || item?.ROL || item?.role || item?.asamaRol || '').trim();
  if (rol && !/^[-–]$/.test(rol)) return rol;
  // Orijinal günlük akışta bazen işlem adı/açıklama alanında son aşama metni gelir.
  const blob = [
    item?.akış, item?.akis, item?.akisAdi, item?.akışAdı,
    item?.islem, item?.işlem, item?.islemAdi, item?.işlemAdı,
    item?.aciklama, item?.açıklama, item?.mesaj, item?.message
  ].filter(Boolean).join(' ');
  text = ykDurumText(ykGetDurumRaw({ aciklama: blob }));
  if (text && text !== '-' && !/^Durum\s*0$/i.test(text)) return text;
  return '';
}

function ykGetLastStatus(items) {
  if (!items || !items.length) return { durum: '-', kod: '', item: null };
  let best = null;
  let bestTime = -1;
  items.forEach((it, idx) => {
    const has = ykGetMeaningfulDurum(it) || ykGetKod(it);
    if (!has) return;
    const t = ykGetOptime(it);
    // Tarih yoksa/aynıysa dizide daha sonra gelen kayıt son işlem kabul edilir.
    if (!best || t > bestTime || (t === bestTime && idx >= (best.__idx ?? -1))) {
      best = it;
      best.__idx = idx;
      bestTime = t;
    }
  });
  const last = best || items[items.length - 1];
  const durum = ykGetMeaningfulDurum(last) || '-';
  return {
    durum,
    kod: ykGetKod(last),
    item: last
  };
}

async function ykFetchYoklamalarForJob(job) {
  const vkn = String(job?.is_vergiNo || job?.vergiNo || job?.vkn || '').trim();
  const tckn = String(job?.is_tcKimlikNo || job?.tcKimlikNo || job?.tckn || '').trim();
  if (!vkn && !tckn) throw new Error('VKN/TCKN bulunamadı.');

  const range = ykDateRangeSixMonths();
  const jobStartDate = ykGetJobStartDate(job);
  if (jobStartDate) range.start = jobStartDate;
  // Bitiş tarihi her zaman bugün kalsın; böylece işin atanma tarihinden bugüne kadar aynı VKN için çıkan
  // tüm yoklamalar (aynı gün 4 kod gibi) görülebilir.
  range.end = ykDateRangeSixMonths().end;
  const sessionData = ykBuildSessionData('20');

  // EYS Tam Bot Full eklentisindeki doğru yapı:
  // cmd: srvcYoklama_getYoklamalar
  // jp: { data:{...}, sessionData }
  return ykPostEys('srvcYoklama_getYoklamalar', {
    data: {
      koor: '',
      vd: sessionData.birim,
      vdkodu: sessionData.birim,
      sorgukaynak: '0',
      icdis: '0',
      disil: '',
      disvd: '',
      // HAR örneğinde bu alanlar boş; sadece vkn/tckn alanı dolu gidiyor.
      // basvkn/sonvkn de doldurulunca servis bazı durumlarda sonuçları daraltıp eksik döndürebiliyor.
      basvkn: '',
      sonvkn: '',
      bastckn: '',
      sontckn: '',
      yabanci: 0,
      vkn,
      tckn,
      yturu: [],
      ydurum: '',
      sonucislem: '1',
      servis: '',
      bastar: range.start,
      bittar: range.end,
      unvan: '',
      ym: '',
      usekullanici: false,
      eosusergiris: sessionData.giris,
      eosuser: sessionData.user,
      ihbaraDayali: false
    },
    sessionData
  });
}

async function ykFetchGunlukAkis(ykodu) {
  if (!ykodu) return [];
  const sessionData = ykBuildSessionData('20');
  try {
    const json = await ykPostEys('srvcYoklama_getYoklamaGunluk', {
      ykodu,
      yKodu: ykodu,
      sessionData
    });
    return ykExtractItems(json);
  } catch (_) {
    return [];
  }
}

async function ykFetchYoklamaByCode(ykodu) {
  if (!ykodu) return [];
  const sessionData = ykBuildSessionData('20');
  try {
    const json = await ykPostEys('srvcYoklama_getYoklamalar', {
      data: { koor: '', vd: sessionData.birim, ykodu },
      sessionData
    });
    return ykExtractItems(json);
  } catch (_) {
    return [];
  }
}

function ykEnsureModal() {
  let modal = document.getElementById('it_yoklama_modal');
  if (modal) return modal;
  modal = document.createElement('div');
  modal.id = 'it_yoklama_modal';
  modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.50);z-index:2147483647;padding:18px;';
  modal.innerHTML = `
    <div id="it_yoklama_box" style="position:fixed;right:28px;top:120px;width:min(980px,94vw);height:min(760px,88vh);min-width:520px;min-height:320px;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.42);display:flex;flex-direction:column;resize:both;overflow:hidden;">
      <div id="it_yoklama_head" style="height:42px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;background:#0d1b31;border-bottom:1px solid #22324f;cursor:move;user-select:none;">
        <div style="font-weight:700;">Yoklama</div>
        <div><button type="button" id="it_yoklama_close" class="mini" style="color:#ff8f8f">×</button></div>
      </div>
      <div id="it_yoklama_body" style="padding:10px;overflow:auto;flex:0 0 auto;max-height:210px;font:12px/1.45 'Segoe UI',Arial,sans-serif;"></div>
      <iframe id="it_yoklama_frame" style="display:none;border:0;width:100%;flex:1;background:#eef3f8;"></iframe>
    </div>`;
  (document.body || document.documentElement).appendChild(modal);
  modal.querySelector('#it_yoklama_close').onclick = () => {
    modal.style.display = 'none';
    modal.querySelector('#it_yoklama_frame').src = 'about:blank';
  };
  return modal;
}

function ykRenderModalItems(job, items, selectedKod) {
  const modal = ykEnsureModal();
  const body = modal.querySelector('#it_yoklama_body');
  const frame = modal.querySelector('#it_yoklama_frame');
  const list = items || [];

  if (!list.length) {
    body.innerHTML = `<div style="color:#ff8f8f">Yoklama kaydı bulunamadı.</div>`;
    frame.style.display = 'none';
    return;
  }

  body.innerHTML = list.map((it, idx) => {
    const kod = ykGetKod(it);
    const url = ykBuildSonucUrl(kod);
    const durum = ykDurumText(it?.durum);
    return `<div style="border-top:1px solid #22324f;padding:7px 0;">
      <b>${idx + 1}. ${it.unvan || it.adsoyadunvan || it.adSoyadUnvan || 'Yoklama Kaydı'}</b>
      <div style="font-size:11px;color:#cbd7eb">Durum: ${durum} | Kod: ${kod || '-'} | Zaman: ${it.optime || it.sonislem || it.ilkislem || '-'}</div>
      ${url ? `<button type="button" class="it_yoklama_pdf_btn" data-url="${url}" style="margin-top:5px;">PDF Aç</button>` : `<span style="color:#ff8f8f">yKodu yok</span>`}
    </div>`;
  }).join('');

  body.querySelectorAll('.it_yoklama_pdf_btn').forEach(btn => {
    btn.onclick = () => { frame.src = btn.dataset.url; frame.style.display = 'block'; };
  });

  const targetUrl = selectedKod ? ykBuildSonucUrl(selectedKod) : (body.querySelector('.it_yoklama_pdf_btn')?.dataset?.url || '');
  if (targetUrl) {
    frame.src = targetUrl;
    frame.style.display = 'block';
  } else {
    frame.style.display = 'none';
  }
}

async function ykOpenYoklamaForJob(job, cachedItems, cachedKod, logFn) {
  const modal = ykEnsureModal();
  modal.style.display = 'flex';
  const body = modal.querySelector('#it_yoklama_body');
  const frame = modal.querySelector('#it_yoklama_frame');
  frame.style.display = 'none';
  frame.src = 'about:blank';
  body.innerHTML = '<div style="color:#9cff9c">Yoklama yükleniyor...</div>';
  try {
    let items = cachedItems;
    if (!items || !items.length) {
      const resp = await ykFetchYoklamalarForJob(job);
      items = ykExtractItems(resp);
    }
    ykRenderModalItems(job, items, cachedKod);
    if (typeof logFn === 'function') logFn('Yoklama görüntülendi.');
  } catch (e) {
    body.innerHTML = `<div style="color:#ff8f8f">Yoklama alınamadı: ${e.message || String(e)}</div>`;
    if (typeof logFn === 'function') logFn('Yoklama alınamadı: ' + (e.message || String(e)), true);
  }
}



function ykOpenPdfPopup(url) {
  if (!url) return null;
  const safeOpenFallback = () => {
    try { return window.open(url, '_blank'); } catch (_) { return null; }
  };
  try {
    const sw = window.screen && window.screen.availWidth ? window.screen.availWidth : 1366;
    const sh = window.screen && window.screen.availHeight ? window.screen.availHeight : 768;
    const sl = window.screen && Number.isFinite(window.screen.availLeft) ? window.screen.availLeft : 0;
    const st = window.screen && Number.isFinite(window.screen.availTop) ? window.screen.availTop : 0;
    const w = Math.min(980, Math.max(720, Math.floor(sw * 0.62)));
    const h = Math.min(900, Math.max(620, Math.floor(sh * 0.88)));
    const left = Math.max(0, Math.floor(sl + sw - w - 20));
    const top = Math.max(0, Math.floor(st + 40));
    const features = [
      'popup=yes',
      'noopener=no',
      'noreferrer=no',
      'resizable=yes',
      'scrollbars=yes',
      'toolbar=no',
      'menubar=no',
      'location=yes',
      'status=no',
      `width=${w}`,
      `height=${h}`,
      `left=${left}`,
      `top=${top}`
    ].join(',');
    const winName = `YK_PDF_POPUP_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const win = window.open(url, winName, features);
    if (win) {
      try { win.focus(); } catch (_) {}
      return win;
    }
    return safeOpenFallback();
  } catch (_) {
    return safeOpenFallback();
  }
}



function ykNormalizeYmdDate(value) {
  const s = String(value || '').trim();
  if (!s) return '';

  let m = s.match(/(20\d{2})\D?([01]\d)\D?([0-3]\d)/);
  if (m) return `${m[1]}${m[2]}${m[3]}`;

  m = s.match(/([0-3]?\d)\D+([01]?\d)\D+(20\d{2})/);
  if (m) return `${m[3]}${String(m[2]).padStart(2, '0')}${String(m[1]).padStart(2, '0')}`;

  m = s.match(/tarih\s*[:=]\s*([0-3]?\d)[./-]([01]?\d)[./-](20\d{2})/i);
  if (m) return `${m[3]}${String(m[2]).padStart(2, '0')}${String(m[1]).padStart(2, '0')}`;

  return '';
}

function ykDeepFindDateByKey(obj) {
  const wanted = ['gelis', 'geliş', 'kaynak', 'talep', 'basvuru', 'başvuru', 'evrak', 'tarih', 'olusturma', 'oluşturma'];
  const seen = new Set();
  const stack = [obj];

  while (stack.length) {
    const cur = stack.pop();
    if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
    seen.add(cur);

    if (Array.isArray(cur)) {
      cur.forEach(x => stack.push(x));
      continue;
    }

    for (const [k, v] of Object.entries(cur)) {
      const lk = String(k).toLowerCase();
      if (wanted.some(w => lk.includes(w))) {
        const ymd = ykNormalizeYmdDate(v);
        if (ymd) return ymd;
      }
      if (v && typeof v === 'object') stack.push(v);
    }
  }
  return '';
}

function ykGetJobStartDate(job) {
  const candidates = [
    // v4.31.144: Yoklama durum/kod sorgusunda başlangıç tarihi İş Takip'teki atanma tarihi olmalı.
    // HAR örneğinde bu alan akis_atanma_Zamani=20260521171055 şeklinde geliyor.
    job?.akis_atanma_Zamani,
    job?.akis_atanma_zamani,
    job?.akisAtanmaZamani,
    job?.akis_atanmaZamani,
    job?.atanmaZamani,
    job?.atanma_zamani,
    job?.akis_optime,
    job?.is_optime,
    job?.optime,
    job?.is_gelisTarihi,
    job?.gelisTarihi,
    job?.is_tarih,
    job?.tarih,
    job?.is_kaynakTarihi,
    job?.kaynakTarihi,
    job?.talepTarihi,
    job?.basvuruTarihi,
    job?.evrakTarihi,
    job?.olusturmaTarihi,
    job?.createDate,
    job?.createdDate,
    job?.is_kaynakbilgisi,
    job?.is_kaynakBilgisi,
    job?.belgeBilgi,
    job?.evrakBilgisi
  ];

  for (const c of candidates) {
    const ymd = ykNormalizeYmdDate(c);
    if (ymd) return ymd;
  }

  const deep = ykDeepFindDateByKey(job);
  if (deep) return deep;

  try { return ykDateRangeSixMonths().start; } catch (_) { return ''; }
}

function itEnsureActionMenu() {
  let menu = document.getElementById('it_is_takip_action_menu');
  if (menu) return menu;
  menu = document.createElement('div');
  menu.id = 'it_is_takip_action_menu';
  menu.style.cssText = 'position:fixed;display:none;z-index:2147483647;min-width:220px;max-width:340px;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:8px;box-shadow:0 12px 30px rgba(0,0,0,.45);padding:6px;font:12px/1.35 Segoe UI,Arial,sans-serif';
  document.documentElement.appendChild(menu);
  menu.addEventListener('mouseenter', () => menu.__inside = true);
  menu.addEventListener('mouseleave', () => {
    menu.__inside = false;
    setTimeout(() => { if (!menu.__inside) menu.style.display = 'none'; }, 180);
  });
  return menu;
}

function itGetActionList(job) {
  const raw = [job?.sonrakiAdimlar, job?.sonraki_adimlar, job?.akisSonrakiAdimlar, job?.nextSteps, job?.actions, job?.adimlar, job?.islemListesi].find(Array.isArray) || [];
  const mapped = raw.map(x => ({
    text: x?.text || x?.label || x?.ad || x?.adi || x?.aciklama || x?.islemAdi || x?.name || '',
    value: x?.value || x?.kod || x?.id || x?.akisNo || x?.adimNo || x?.tip || ''
  })).filter(x => x.text || x.value);
  const fallback = [
    { text: 'Yoklamaya Sevk Et', value: 'yoklama' },
    { text: 'Önizle Aç', value: 'preview' },
    { text: 'Satır Bilgisini Göster', value: 'info' }
  ];
  const seen = new Set();
  return mapped.concat(fallback).filter(x => {
    const k = `${x.text}|${x.value}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

function itShowActionMenuForJob(job, anchor, bot) {
  const menu = itEnsureActionMenu();
  const actions = itGetActionList(job);
  menu.innerHTML = actions.map((a, i) => `<div class="it-menu-item" data-idx="${i}" style="padding:7px 9px;border-radius:6px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06);">${String(a.text || a.value || '-')}</div>`).join('');
  menu.querySelectorAll('.it-menu-item').forEach(el => {
    el.onmouseenter = () => el.style.background = '#12315a';
    el.onmouseleave = () => el.style.background = '';
    el.onclick = () => {
      const a = actions[Number(el.dataset.idx)];
      menu.style.display = 'none';
      const txt = String(a?.text || '').toLowerCase();
      if (txt.includes('önizle') || a?.value === 'preview') {
        try { bot.openPreview(job); } catch (_) {}
        return;
      }
      if (a?.value === 'info') {
        alert(JSON.stringify(job, null, 2).slice(0, 4000));
        return;
      }
      try { bot.log(`İşTakip seçenek seçildi: ${a?.text || a?.value || '-'} / isTakip=${job?.is_isTakipNo || job?.akis_isTakipNo || '-'}`); } catch (_) {}
    };
  });
  const r = anchor.getBoundingClientRect();
  const w = 260;
  let left = r.left, top = r.bottom + 4;
  if (left + w > innerWidth) left = Math.max(4, innerWidth - w - 8);
  if (top + 240 > innerHeight) top = Math.max(4, r.top - 220);
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  menu.style.display = 'block';
}



function itSpecialKeyForJob(job) {
  return String(itFindIsTakipNo(job) || itFindAkisOid(job) || job?.keysEvrakOid || job?.kaynakEkBilgiler?.keysEvrakOid || '').trim();
}

function itReadAdiOrtaklikStoredStatus(job) {
  try {
    const key = itSpecialKeyForJob(job);
    if (!key) return null;
    const raw = localStorage.getItem('istakip_adi_ortaklik_yoklama_' + key);
    if (!raw) return null;
    const st = JSON.parse(raw);
    if (st && Array.isArray(st.items) && st.items.length) return st;
  } catch (_) {}
  return null;
}

function itIsAdiOrtaklikIseBaslamaJob(job, bot) {
  let isTuru = '';
  try { if (bot && typeof bot.getIsTuruText === 'function') isTuru = bot.getIsTuruText(job); } catch (_) {}
  const ek = job?.kaynakEkBilgiler || {};
  const blob = [
    isTuru,
    job?.txtIsTuru, job?.isTuru, job?.is_kaynakbilgi, job?.is_kaynakbilgisi,
    ek?.txtIsTuru, ek?.is_kaynakbilgi, ek?.isKaynakBilgi, ek?.is_kaynakbilgisi,
    job?.is_unvan, job?.is_unvan_unvan, job?.unvan
  ].filter(Boolean).join(' ').toLocaleLowerCase('tr-TR');
  return (blob.includes('adi ortak') || blob.includes('adi ortaklık')) && (blob.includes('işe başlama') || blob.includes('ise baslama'));
}

function itIsIseBaslamaJob(job, bot) {
  let isTuru = '';
  try { if (bot && typeof bot.getIsTuruText === 'function') isTuru = bot.getIsTuruText(job); } catch (_) {}
  const ek = job?.kaynakEkBilgiler || {};
  const blob = [
    isTuru,
    job?.txtIsTuru, job?.isTuru, job?.is_kaynakbilgi, job?.is_kaynakbilgisi,
    ek?.txtIsTuru, ek?.is_kaynakbilgi, ek?.isKaynakBilgi, ek?.is_kaynakbilgisi,
    job?.belgeBilgi, job?.is_unvan, job?.is_unvan_unvan, job?.unvan
  ].filter(Boolean).join(' ').toLocaleLowerCase('tr-TR');
  return (blob.includes('işe başlama') || blob.includes('ise baslama'));
}

function itIsMersisMerkezAcilisJob(job, bot) {
  let isTuru = '';
  try { if (bot && typeof bot.getIsTuruText === 'function') isTuru = bot.getIsTuruText(job); } catch (_) {}
  const ek = job?.kaynakEkBilgiler || {};
  const blob = [
    isTuru,
    job?.txtIsTuru, job?.isTuru, job?.is_kaynakbilgi, job?.is_kaynakbilgisi,
    ek?.txtIsTuru, ek?.is_kaynakbilgi, ek?.isKaynakBilgi, ek?.is_kaynakbilgisi,
    job?.belgeBilgi, job?.txtBelgeBilgi, job?.is_unvan, job?.is_unvan_unvan, job?.unvan
  ].filter(Boolean).join(' ').toLocaleLowerCase('tr-TR');
  const isMersis = blob.includes('mersis');
  const isMerkez = blob.includes('merkez');
  const isAcilis = blob.includes('açılış') || blob.includes('acilis') || blob.includes('açilis') || blob.includes('acılış');
  const isIseBaslama = blob.includes('işe başlama') || blob.includes('ise baslama');
  return isMersis && isMerkez && isAcilis;
}

function itIsMersisMerkezAdresDegisikligiJob(job, bot) {
  let isTuru = '';
  try { if (bot && typeof bot.getIsTuruText === 'function') isTuru = bot.getIsTuruText(job); } catch (_) {}
  const ek = job?.kaynakEkBilgiler || {};
  const blob = [
    isTuru,
    job?.txtIsTuru, job?.isTuru, job?.is_kaynakbilgi, job?.is_kaynakbilgisi,
    ek?.txtIsTuru, ek?.is_kaynakbilgi, ek?.isKaynakBilgi, ek?.is_kaynakbilgisi,
    job?.belgeBilgi, job?.is_unvan, job?.is_unvan_unvan, job?.unvan
  ].filter(Boolean).join(' ').toLocaleLowerCase('tr-TR');
  return (blob.includes('mersis') && blob.includes('merkez') && blob.includes('adres') && (blob.includes('değişik') || blob.includes('degisik')));
}

function itIsYoklamaSureciAction(action) {
  const t = itActionLabel(action).toLocaleLowerCase('tr-TR');
  return t.includes('yoklama süreci başlat') || t.includes('yoklama sureci baslat');
}

function itFindAkisOid(job) {
  const candidates = [
    job?.akisOid,
    job?.akis_oid,
    job?.akis_akisOid,
    job?.akis_islemOid,
    job?.is_akisOid,
    job?.isAkisOid,
    job?.akisoid,
    job?.oid,
    job?.kaynakEkBilgiler?.akisOid,
    job?.kaynakEkBilgiler?.akis_oid,
    job?.kaynakEkBilgiler?.akis_islemOid
  ].map(x => String(x || '').trim()).filter(Boolean);

  return candidates[0] || '';
}


function itFindIsTakipNo(job) {
  return String(
    job?.is_isTakipNo ||
    job?.akis_isTakipNo ||
    job?.isTakipNo ||
    job?.istakipNo ||
    job?.kaynakEkBilgiler?.isTakipNo ||
    ''
  ).trim();
}

function itNormalizeBeklenenIsBitisZamani(job) {
  const candidates = [
    job?.is_beklenenIsBitisZamani,
    job?.beklenenIsBitisZamani,
    job?.beklenenIsBitis,
    job?.kaynakEkBilgiler?.is_beklenenIsBitisZamani,
    job?.kaynakEkBilgiler?.beklenenIsBitisZamani
  ];
  for (const c of candidates) {
    const digits = String(c || '').replace(/\D/g, '');
    if (digits.length >= 12) return digits.slice(0, 12); // EYS HAR: 202603111700
    if (digits.length === 8) return digits + '1700';
  }
  return '';
}

function itIsFinishChefAction(action) {
  const t = (itActionLabel(action) + ' ' + String(action?.durumAciklama || action?.asJSONObject?.durumAciklama || '')).toLocaleLowerCase('tr-TR');
  return t.includes('işi bitir') || t.includes('isi bitir') || t.includes('şef') || t.includes('sef');
}

async function itSendSingleWorkflowAction(job, action, bot) {
  const label = itActionLabel(action);
  const tag = itFindIsTakipNo(job) || itFindAkisOid(job) || '-';
  try {
    if (!bot || typeof bot.getSettings !== 'function') throw new Error('Bot ayarları okunamadı');
    const s = bot.getSettings();
    renderDiscovery();
    if (typeof bot.assertDiscovery === 'function' && !bot.assertDiscovery(s)) return;

    const payload = bot.buildSavePayload(job, action, s);
    if (!payload.isTakipNo) throw new Error('isTakipNo bulunamadı');
    if (!payload.akisOid) throw new Error('akisOid bulunamadı');
    if (!payload.orgoid) throw new Error('orgoid bulunamadı');

    const detail = [
      `İşTakip: ${payload.isTakipNo}`,
      `Adım: ${label}`,
      `hedefDurumNo=${payload.hedefDurumNo}`,
      `akisDurumTip=${payload.akisDurumTip}`,
      payload.beklenenIsBitisZamani ? `beklenen=${payload.beklenenIsBitisZamani}` : 'beklenen=boş'
    ].join('\n');

    if (!confirm(`${detail}\n\nBu akış adımı kaydedilsin mi?`)) {
      try { bot.log(`Akış iptal edildi: ${label} | isTakip=${tag}`); } catch (_) {}
      return;
    }

    try { bot.log(`Akış gönderiliyor: ${label} | isTakip=${tag} | hedefDurumNo=${payload.hedefDurumNo}, tip=${payload.akisDurumTip}`); } catch (_) {}
    const resp = await post(CFG.COMMANDS.SAVE_STEP || 'akisIslemleri_akisYeniAdimKaydet', payload);
    job.__lastActionSent = label;
    job.__sent = true;
    job.__sendResp = resp;
    try { bot.log(`Akış kaydedildi: ${label} | isTakip=${tag}`); } catch (_) {}
    if (typeof bot.refreshAfterSave === 'function') await bot.refreshAfterSave();
    else if (typeof bot.renderRows === 'function') bot.renderRows(state.jobs || []);
  } catch (e) {
    const msg = e?.message || String(e);
    try { bot?.log?.(`Akış gönderim hatası: ${label} | isTakip=${tag} | ${msg}`, true); } catch (_) {}
    alert(`Akış gönderilemedi:\n${msg}`);
  }
}

function itFindOrgoid(job) {
  return String(
    job?.akis_orgoid ||
    job?.is_orgoid ||
    job?.orgoid ||
    job?.orgOid ||
    job?.kaynakEkBilgiler?.is_sicil_orgoid ||
    job?.kaynakEkBilgiler?.orgoid ||
    state.discovery?.baseOrgoid ||
    state.discovery?.orgoid ||
    ''
  ).trim();
}

async function itFetchRealActions(job) {
  const orgoid = itFindOrgoid(job);
  const akisOid = itFindAkisOid(job);

  if (!orgoid) throw new Error('orgoid bulunamadı');
  if (!akisOid) throw new Error('akisOid bulunamadı');

  const resp = await post(CFG.COMMANDS.NEXT_STEPS || 'akisIslemleri_isTakipSonrakiAdimlariBul', {
    orgoid,
    akisOid
  });

  const list = resp?.data?.hedefAdimlar || resp?.hedefAdimlar || [];
  return Array.isArray(list) ? list : [];
}

function itActionLabel(a) {
  return String(
    a?.aciklama ||
    a?.durumAciklama ||
    a?.asJSONObject?.aciklama ||
    a?.text ||
    a?.label ||
    a?.name ||
    '-'
  ).trim();
}

function itActionSub(a) {
  const bits = [];
  if (a?.durumNo !== undefined) bits.push('durumNo=' + a.durumNo);
  if (a?.tip !== undefined) bits.push('tip=' + a.tip);
  if (a?.akisNo !== undefined) bits.push('akisNo=' + a.akisNo);
  return bits.join(' / ');
}


function itIsBaskasinaAtaAction(action) {
  const txt = (itActionLabel(action) + ' ' + String(action?.durumAciklama || action?.asJSONObject?.durumAciklama || '')).toLocaleLowerCase('tr-TR');
  return txt.includes('başkasına ata') || txt.includes('baskasina ata') || txt.includes('iş başkasına ata') || txt.includes('işi başkasına ata') || txt.includes('isi baskasina ata');
}


function itIsUserOwnedJob(job) {
  // İşleri Tara birleşik listesinde kullanıcı üzerindeki işler fetchBirimVeKullaniciIsleri sırasında __ownerUserId ile işaretlenir.
  // Gerçek sistemde "İşi Başkasına Ata" bu satırlarda vardır; GİB/birim bekleyen işlerinde bu akış yoktur.
  const ownerUserId = String(job?.__ownerUserId || '').trim();
  if (ownerUserId) return true;
  const ownerName = String(job?.__ownerName || '').trim();
  if (ownerName && ownerName !== '-' && !ownerName.toLocaleLowerCase('tr-TR').includes('birimdeki')) return true;
  return false;
}

function itSyntheticBaskasinaAtaAction() {
  return {
    __syntheticBaskasinaAta: true,
    aciklama: 'İşi Başkasına Ata',
    durumAciklama: 'İşi Başkasına Ata'
  };
}

function itIsMemuraAtaTalepSevkAction(action) {
  const txt = (itActionLabel(action) + ' ' + String(action?.durumAciklama || action?.asJSONObject?.durumAciklama || '')).toLocaleLowerCase('tr-TR');
  if (itIsBaskasinaAtaAction(action)) return true;
  if (txt.includes('memura ata') || txt.includes('memura atama')) return true;
  if ((txt.includes('talep') || txt.includes('istek')) && (txt.includes('sevk') || txt.includes('ata'))) return true;
  if (Array.isArray(action?.atamaYapilabilecekBirimBilgileri) && action.atamaYapilabilecekBirimBilgileri.length) return true;
  return false;
}

function itExtractOrgTreeId(resp) {
  const d = resp?.data || resp;
  return String(d?.id || d?.nodeId || d?.value || '').trim();
}

function itExtractAssignableUsers(resp, fallbackNodeId = '') {
  function findFirstArray(o, keys) {
    const seen = new Set();
    function walk(x) {
      if (!x || typeof x !== 'object' || seen.has(x)) return null;
      seen.add(x);
      for (const k of keys) if (Array.isArray(x[k])) return x[k];
      for (const v of Object.values(x)) {
        const r = walk(v);
        if (r) return r;
      }
      return null;
    }
    return walk(o);
  }
  const raw = resp?.data?.kullaniciListesi || resp?.kullaniciListesi || resp?.data?.list || resp?.list || findFirstArray(resp, ['kullaniciListesi','kullanicilar','users','children']) || [];
  const list = Array.isArray(raw) ? raw : [];
  return list.map(x => {
    // Gerçek Memura Ata ekranında kullanıcı satırında iki ayrı bilgi var:
    // 1) userId  : işi kime atayacağımız memur kimliği
    // 2) nodeId  : o memurun organizasyon ağacındaki satır/node kimliği
    // Önceki sürüm nodeId yoksa bölüm nodeId'sini fallback alıyordu. Bu durumda hangi memur seçilirse seçilsin
    // aynı bölüm/sabit node ile gönderim yapılabiliyordu. Bu yüzden id/value gibi satıra özel alanlar da nodeId adayıdır.
    const userId = String(x?.userId ?? x?.userid ?? x?.kullaniciUserId ?? x?.kullaniciId ?? x?.value ?? '').trim();
    const nodeId = String(
      x?.nodeId ?? x?.node_id ?? x?.node ?? x?.id ?? x?.key ?? x?.value2 ?? x?.value ?? fallbackNodeId ?? ''
    ).trim();
    const text = String(x?.text || x?.label || x?.adSoyad || x?.adiSoyadi || x?.adSoyadi || x?.name || x?.kullaniciAdiSoyadi || userId || '').trim();
    // HAR'da bölüm satırı value=16537 / nodeId=16537 geliyor; memurlar 10-11 haneli userId ve "Ad Soyad / Birim" şeklinde geliyor.
    const isUser = /^\d{10,11}$/.test(userId) || (text.includes('/') && userId && String(userId) !== String(nodeId));
    return { text, value: userId, userId, nodeId, isUser, raw: x };
  }).filter(x => x.isUser && x.userId);
}

async function itFetchAssignableUsersForAction(job, action, bot) {
  const s = bot?.getSettings ? bot.getSettings() : {};
  const orgoid = itFindOrgoid(job) || String(s?.orgoid || '');
  const akisOid = itFindAkisOid(job);
  const durumNo = Number(action?.durumNo ?? action?.asJSONObject?.durumNo ?? 0);
  const isBaskasina = itIsBaskasinaAtaAction(action);
  if (!orgoid) throw new Error('orgoid bulunamadı');
  if (!akisOid) throw new Error('akisOid bulunamadı');
  // İşi Başkasına Ata HAR akışında durumNo boş gider; Memura Ata/Talep Sevk'te ise hedef durumNo zorunludur.
  if (!isBaskasina && !durumNo) throw new Error('hedef durumNo bulunamadı');

  const treeCmd = isBaskasina
    ? 'akisSorgulamaIslemleri_amirIcinOrganizasyonAgaciOlustur'
    : 'akisSorgulamaIslemleri_akisDurumuIcinOrganizasyonAgaciOlustur';
  // HAR: Memurun üzerindeki işi başka kullanıcıya atamada durumNo boş gönderiliyor.
  const treePayload = isBaskasina ? { orgoid, akisOid, durumNo: '' } : { orgoid, akisOid, durumNo };
  const treeResp = await post(treeCmd, treePayload);
  const nodeId = itExtractOrgTreeId(treeResp);
  if (!nodeId) throw new Error('Organizasyon ağacında nodeId bulunamadı');
  const usersResp = await post(CFG.COMMANDS.NODE_USERS || 'isTakipSorgulamalarServices_birimdekiKullanicilariGetir', { id: String(nodeId) });
  const users = itExtractAssignableUsers(usersResp, nodeId);
  if (!users.length) throw new Error('Atanabilecek memur listesi boş döndü');
  return { nodeId, users, treeResp, usersResp, isBaskasina };
}

function itShowAssignUserPicker(job, action, anchor, bot, assignInfo) {
  // v4.31.178: Gerçek sistemdeki Evdo İştakip Organizasyon ekranına benzer seçim ekranı.
  // HAR akışı: sonrakiAdimlariBul -> akisDurumuIcinOrganizasyonAgaciOlustur -> birimdekiKullanicilariGetir
  // -> kullanıcı Ekle -> akisYeniAdimKaydet. Tek tıkla direkt göndermek yerine kullanıcı listesi, Ekle/Çıkar,
  // açıklama ve İşi Ata butonu gösterilir.
  const old = document.getElementById('it_assign_user_dialog');
  if (old) old.remove();
  const menu = itEnsureActionMenu();
  menu.style.display = 'none';

  const label = itActionLabel(action);
  const users = assignInfo?.users || [];
  const dialog = document.createElement('div');
  dialog.id = 'it_assign_user_dialog';
  dialog.style.cssText = 'position:fixed;z-index:2147483647;left:50%;top:50%;transform:translate(-50%,-50%);width:min(760px,94vw);max-height:88vh;overflow:auto;background:#f5f5f5;color:#222;border:1px solid #777;box-shadow:0 12px 38px rgba(0,0,0,.45);font:12px Arial,Segoe UI,sans-serif;padding:12px 14px;';

  const rootLabel = escapeHtml(String(assignInfo?.treeResp?.data?.label || assignInfo?.nodeLabel || 'Sicil Memurluğu'));
  dialog.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <div style="font-weight:bold;font-size:14px;">Evdo İştakip Organizasyon</div>
      <button type="button" id="it_assign_close" style="padding:2px 7px;">X</button>
    </div>
    <div style="display:grid;grid-template-columns:220px 1fr;gap:14px;align-items:start;">
      <div>
        <div style="margin-bottom:4px;">Ara</div>
        <input id="it_assign_search" style="width:180px;margin-bottom:4px;" />
        <div style="border-left:1px solid #aaa;margin-left:8px;padding-left:8px;min-height:260px;">
          <div style="background:#e9ed9f;display:inline-block;padding:2px 4px;">${rootLabel}</div>
        </div>
      </div>
      <div>
        <div style="font-weight:bold;margin-bottom:2px;">Kullanıcı Listesi</div>
        <select id="it_assign_all" size="10" style="width:100%;height:150px;background:#ffffcc;border:1px solid #888;" multiple>
          ${users.map((u, i) => `<option value="${i}">${escapeHtml(u.text || u.value)}</option>`).join('')}
        </select>
        <div style="text-align:center;margin:6px 0;">
          <button type="button" id="it_assign_add" style="min-width:54px;">Ekle</button>
          <button type="button" id="it_assign_remove" style="min-width:54px;margin-left:8px;">Çıkar</button>
        </div>
        <div style="font-weight:bold;margin-bottom:2px;">Atama Yapılacak Kullanıcılar</div>
        <select id="it_assign_selected" size="6" style="width:100%;height:94px;background:#ffffcc;border:1px solid #888;" multiple></select>
        <div style="font-weight:bold;margin:8px 0 2px;">Açıklama</div>
        <textarea id="it_assign_note" style="width:100%;height:70px;background:#ffffcc;border:1px solid #888;"></textarea>
        <div style="text-align:center;margin-top:10px;">
          <button type="button" id="it_assign_send" style="min-width:78px;">İşi Ata</button>
        </div>
        <div id="it_assign_status" style="margin-top:8px;color:#555;font-size:11px;"></div>
      </div>
    </div>
  `;
  document.documentElement.appendChild(dialog);

  const allSel = dialog.querySelector('#it_assign_all');
  const pickedSel = dialog.querySelector('#it_assign_selected');
  const search = dialog.querySelector('#it_assign_search');
  const status = dialog.querySelector('#it_assign_status');
  const picked = [];

  function redrawAll(filter = '') {
    const f = String(filter || '').toLocaleLowerCase('tr-TR');
    allSel.innerHTML = users.map((u, i) => ({ u, i }))
      .filter(x => !f || String(x.u.text || x.u.value).toLocaleLowerCase('tr-TR').includes(f))
      .map(x => `<option value="${x.i}">${escapeHtml(x.u.text || x.u.value)}</option>`).join('');
  }
  function redrawPicked() {
    pickedSel.innerHTML = picked.map((u, i) => `<option value="${i}">${escapeHtml(u.text || u.value)}</option>`).join('');
  }
  function addSelected() {
    const idxs = Array.from(allSel.selectedOptions).map(o => Number(o.value));
    for (const idx of idxs) {
      const u = users[idx];
      if (u && !picked.some(p => String(p.value) === String(u.value))) picked.push(u);
    }
    redrawPicked();
  }
  function removeSelected() {
    const idxs = Array.from(pickedSel.selectedOptions).map(o => Number(o.value)).sort((a,b)=>b-a);
    for (const idx of idxs) picked.splice(idx, 1);
    redrawPicked();
  }

  dialog.querySelector('#it_assign_close').onclick = () => dialog.remove();
  dialog.querySelector('#it_assign_add').onclick = addSelected;
  dialog.querySelector('#it_assign_remove').onclick = removeSelected;
  allSel.ondblclick = addSelected;
  pickedSel.ondblclick = removeSelected;
  search.oninput = () => redrawAll(search.value);

  dialog.querySelector('#it_assign_send').onclick = async () => {
    try {
      if (!picked.length) throw new Error('Atama yapılacak kullanıcı seçilmedi. Önce kullanıcıyı seçip Ekle deyin.');
      const s = bot.getSettings();
      const payload = bot.buildSavePayload(job, action, s);
      const assignees = picked.map(u => ({
        nodeId: String(u.nodeId || assignInfo.nodeId || ''),
        userId: String(u.userId || u.value || '')
      }));
      payload.atamaYapilacaklar = assignees;
      // Gerçek HAR akışında seçilen kullanıcıya ait node/user bilgisi ayrı ayrı taşınıyor.
      // Boş bırakıldığında veya bölüm nodeId'si kullanıldığında sistem seçilen memur yerine sabit/default kişiye atayabiliyor.
      payload.atanacakNodeId = assignees.length === 1 ? assignees[0].nodeId : '';
      payload.akisDurumKullanicilari = assignees.map(x => x.userId);
      payload.akisDurumNodeIdler = assignees.map(x => x.nodeId);
      payload.islemSahibi = 3;
      payload.akisDurum = 1;
      payload.isiUzerimeAl = 1;
      payload.aciklama = String(dialog.querySelector('#it_assign_note')?.value || '');
      payload.beklenenIsBitisZamani = '';
      if (!payload.isTakipNo) throw new Error('isTakipNo bulunamadı');
      if (!payload.akisOid) throw new Error('akisOid bulunamadı');
      if (!payload.orgoid) throw new Error('orgoid bulunamadı');
      if (payload.atamaYapilacaklar.some(x => !x.nodeId || !x.userId)) throw new Error('Seçilen kullanıcı için nodeId/userId eksik');
      const names = picked.map(u => String(u.text || u.value).split('/')[0].trim()).join(', ');
      if (!confirm(`${label}\n\nİşTakip: ${payload.isTakipNo}\nAtanacak: ${names}\n\nKaydedilsin mi?`)) return;
      status.textContent = 'Gönderiliyor...';
      bot.log(`${label} gönderiliyor: isTakip=${payload.isTakipNo} → ${names} | atama=${payload.atamaYapilacaklar.map(x => x.userId + '/' + x.nodeId).join(',')}`);
      const saveCmd = itIsBaskasinaAtaAction(action)
        ? 'isAtamaIslemleri_isiBaskasinaAtaAmirTarafindan'
        : (CFG.COMMANDS.SAVE_STEP || 'akisIslemleri_akisYeniAdimKaydet');
      let savePayload = payload;
      if (itIsBaskasinaAtaAction(action)) {
        let username = '';
        try { username = String(ykGetSessionSeed?.().adi || ''); } catch (_) {}
        if (!username) username = String(window.userName || window.kullaniciAdi || '');
        // Gerçek HAR: isAtamaIslemleri_isiBaskasinaAtaAmirTarafindan
        // jp={atamaYapanKullaniciUserId, orgoid, akisOid, atamaYapilacaklar, userId:'',
        //     islemYapanUserId, username, aciklama}
        savePayload = {
          atamaYapanKullaniciUserId: String(s.userId || ''),
          orgoid: String(payload.orgoid || ''),
          akisOid: String(payload.akisOid || ''),
          atamaYapilacaklar: assignees,
          userId: '',
          islemYapanUserId: String(s.userId || ''),
          username,
          aciklama: String(dialog.querySelector('#it_assign_note')?.value || '')
        };
      }
      await post(saveCmd, savePayload);
      bot.log(`${label} kaydedildi: cmd=${saveCmd} isTakip=${payload.isTakipNo} → ${names} | atama=${assignees.map(x => x.userId + '/' + x.nodeId).join(',')}`);
      status.textContent = 'Kaydedildi.';
      setTimeout(() => dialog.remove(), 500);
      if (typeof bot.refreshAfterSave === 'function') await bot.refreshAfterSave();
    } catch (e) {
      const msg = e?.message || String(e);
      status.textContent = msg;
      status.style.color = '#b00020';
      try { bot.log(`${label} gönderim hatası: ${msg}`, true); } catch (_) {}
      alert(`${label} gönderilemedi:\n${msg}`);
    }
  };
}

async function itOpenAssignUserFlow(job, action, anchor, bot) {
  const menu = itShowLoadingActionMenu(anchor, 'Memur listesi alınıyor...');
  try {
    const info = await itFetchAssignableUsersForAction(job, action, bot);
    try { bot.log(`Memur listesi alındı: hedefDurumNo=${action?.durumNo ?? '-'}, nodeId=${info.nodeId}, kullanıcı=${info.users.length}`); } catch (_) {}
    itShowAssignUserPicker(job, action, anchor, bot, info);
  } catch (e) {
    menu.innerHTML = `<div style="padding:8px 10px;color:#ff8f8f">Memur listesi alınamadı</div><div style="padding:0 10px 8px;font-size:10px;color:#aeb9d4">${escapeHtml(e?.message || String(e))}</div>`;
    try { bot.log('Memur listesi alınamadı: ' + (e?.message || String(e)), true); } catch (_) {}
  }
}

function itShowLoadingActionMenu(anchor, text = 'Akış seçenekleri yükleniyor...') {
  const menu = itEnsureActionMenu();
  menu.innerHTML = `<div style="padding:8px 10px;color:#9cff9c">${text}</div>`;
  const r = anchor.getBoundingClientRect();
  const w = 300;
  let left = r.left;
  let top = r.bottom + 4;
  if (left + w > innerWidth) left = Math.max(4, innerWidth - w - 8);
  if (top + 260 > innerHeight) top = Math.max(4, r.top - 240);
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  menu.style.display = 'block';
  return menu;
}

function itRenderRealActionMenu(job, anchor, bot, actions) {
  const menu = itEnsureActionMenu();
  const extraActions = [];
  if (itIsAdiOrtaklikIseBaslamaJob(job, bot)) {
    extraActions.push({ __systemExternal: 'adiOrtaklik', aciklama: 'Sistem harici Adi Ortaklık Yoklama Çıkar' });
  } else if (itIsMersisMerkezAdresDegisikligiJob(job, bot)) {
    extraActions.push({ __systemExternal: 'adresDegisikligi', aciklama: 'Adres Değişikliği Yoklaması Çıkart' });
  } else if (itIsMersisMerkezAcilisJob(job, bot)) {
    extraActions.push({ __systemExternal: 'mersisMerkezAcilis', aciklama: 'MERSİS Merkez Açılış Yoklaması Çıkart' });
  } else if (itIsIseBaslamaJob(job, bot)) {
    extraActions.push({ __systemExternal: 'iseBaslamaTek', aciklama: 'Sistem harici Yeniden Yoklama Çıkart' });
  }
  const userOwned = itIsUserOwnedJob(job);
  actions = (Array.isArray(actions) ? actions : []).concat(extraActions);
  // Gerçek ekranda "İşi Başkasına Ata" sadece memurun/kullanıcının üzerindeki işlerde bulunur.
  // GİB/birim bekleyen işlerde bu seçenek gösterilmez; oralarda varsa Memura Ata/Talep Sevk kullanılır.
  if (userOwned) {
    if (!actions.some(a => itIsBaskasinaAtaAction(a))) actions.unshift(itSyntheticBaskasinaAtaAction());
  } else {
    actions = actions.filter(a => !itIsBaskasinaAtaAction(a));
  }

  if (!actions || !actions.length) {
    menu.innerHTML = `<div style="padding:8px 10px;color:#ffb86b">Akış seçeneği bulunamadı.</div>`;
    return;
  }

  menu.innerHTML = actions.map((a, i) => {
    const label = itActionLabel(a);
    const sub = itActionSub(a);
    return `
      <div class="it-menu-item" data-idx="${i}" style="padding:7px 9px;border-radius:6px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06);">
        <div style="font-weight:700">${label}</div>
        ${sub ? `<div style="font-size:10px;color:#aeb9d4;margin-top:2px">${sub}</div>` : ''}
      </div>`;
  }).join('');

  menu.querySelectorAll('.it-menu-item').forEach(el => {
    el.onmouseenter = () => el.style.background = '#12315a';
    el.onmouseleave = () => el.style.background = '';
    el.onclick = async () => {
      const a = actions[Number(el.dataset.idx)];
      try {
        bot.log(`Akış seçildi: ${itActionLabel(a)} | durumNo=${a?.durumNo ?? '-'} tip=${a?.tip ?? '-'} akisNo=${a?.akisNo ?? '-'} | isTakip=${itFindIsTakipNo(job) || '-'}`);
      } catch (_) {}
      // v4.31.177: Memura Ata/Talep Sevk'te menüyü önce kapatırsak seçilen satır display:none altında kaldığı için
      // getBoundingClientRect sıfırlanıyor ve memur listesi görünmeyebiliyordu. Listeyi mevcut satır menüsü içinde aç.
      if (itIsMemuraAtaTalepSevkAction(a)) {
        await itOpenAssignUserFlow(job, a, anchor || el, bot);
        return;
      }
      menu.style.display = 'none';
      if (a && a.__systemExternal) {
        const bridge = window.__istakipEysFullBotInstance;
        if (!bridge) { alert('Sistem harici yoklama için EYS Modülü/Yoklama Giriş köprüsü hazır değil. EYS Modülü sekmesini bir kez açıp tekrar deneyin.'); return; }
        try {
          if (a.__systemExternal === 'adiOrtaklik') await bridge.handleYgAdiOrtaklikWorkflowFromMain(job, null);
          else if (a.__systemExternal === 'mersisMerkezAcilis' && typeof bridge.handleYgMersisMerkezAcilisWorkflowFromMain === 'function') await bridge.handleYgMersisMerkezAcilisWorkflowFromMain(job, null);
          else if (a.__systemExternal === 'mersisMerkezAcilis' && typeof bridge.handleYgMersisMerkezAcilisWorkflow === 'function') await bridge.handleYgMersisMerkezAcilisWorkflow(job, null, { ask: true });
          else if (a.__systemExternal === 'iseBaslamaTek' && typeof bridge.handleYgIseBaslamaTekWorkflowFromMain === 'function') await bridge.handleYgIseBaslamaTekWorkflowFromMain(job, null);
          else if (a.__systemExternal === 'adresDegisikligi' && typeof bridge.handleYgAdresDegisikligiWorkflowFromMain === 'function') await bridge.handleYgAdresDegisikligiWorkflowFromMain(job, null);
          else throw new Error('Sistem harici akış fonksiyonu bulunamadı.');
          if (typeof bot.refreshAfterSave === 'function') await bot.refreshAfterSave();
        } catch (err) { alert('Sistem harici yoklama çıkarılamadı\n' + (err?.message || String(err))); }
        return;
      }
      await itSendSingleWorkflowAction(job, a, bot);
    };
  });
}

async function itShowRealActionMenuForJob(job, anchor, bot) {
  const menu = itShowLoadingActionMenu(anchor);
  try {
    const cacheKey = '__realActions';
    if (!job[cacheKey]) {
      job[cacheKey] = await itFetchRealActions(job);
    }
    itRenderRealActionMenu(job, anchor, bot, job[cacheKey]);
  } catch (e) {
    if (itIsUserOwnedJob(job)) {
      try { bot.log('Akış seçenekleri alınamadı; kullanıcı üzerindeki iş için İşi Başkasına Ata seçeneği yerel açılıyor: ' + (e.message || String(e)), true); } catch (_) {}
      itRenderRealActionMenu(job, anchor, bot, [itSyntheticBaskasinaAtaAction()]);
      return;
    }
    menu.innerHTML = `
      <div style="padding:8px 10px;color:#ff8f8f">Akış seçenekleri alınamadı</div>
      <div style="padding:0 10px 8px;font-size:10px;color:#aeb9d4">${String(e.message || e)}</div>`;
    try { bot.log('Akış seçenekleri alınamadı: ' + (e.message || String(e)), true); } catch (_) {}
  }
}


async function itToggleRealActionMenuForJob(job, anchor, bot) {
  const menu = itEnsureActionMenu();
  if (menu.style.display === 'block' && menu.__activeAnchor === anchor) {
    menu.style.display = 'none';
    menu.__activeAnchor = null;
    return;
  }
  menu.__activeAnchor = anchor;
  await itShowRealActionMenuForJob(job, anchor, bot);
  menu.__activeAnchor = anchor;
}



function itLocalFallbackGet(key) {
  try {
    const k = Array.isArray(key) ? key[0] : key;
    const raw = localStorage.getItem('it_storage_' + k);
    return raw ? { [k]: JSON.parse(raw) } : {};
  } catch (_) { return {}; }
}

function itLocalFallbackSet(obj) {
  try {
    Object.entries(obj || {}).forEach(([k, v]) => {
      localStorage.setItem('it_storage_' + k, JSON.stringify(v));
    });
  } catch (_) {}
}

function itChromeStorageGetSafe(key, cb) {
  try {
    if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) {
      cb(itLocalFallbackGet(key));
      return;
    }
    chrome.storage.local.get(key, out => {
      try {
        if (chrome.runtime && chrome.runtime.lastError) {
          cb(itLocalFallbackGet(key));
          return;
        }
      } catch (_) {
        cb(itLocalFallbackGet(key));
        return;
      }
      cb(out || itLocalFallbackGet(key));
    });
  } catch (_) {
    cb(itLocalFallbackGet(key));
  }
}

function itChromeStorageSetSafe(obj, cb) {
  try {
    itLocalFallbackSet(obj);
    if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) {
      if (cb) cb();
      return;
    }
    chrome.storage.local.set(obj, () => {
      try {
        if (chrome.runtime && chrome.runtime.lastError) {}
      } catch (_) {}
      if (cb) cb();
    });
  } catch (_) {
    if (cb) cb();
  }
}


function setupUnifiedModuleTabs() {
  try {
    const mainPanel = document.getElementById(CFG.PANEL_ID);
    const mainWrap = mainPanel?.querySelector('#it_wrap');
    if (!mainPanel || !mainWrap) return;

    if (!document.getElementById('it_module_tabs')) {
      const tabs = document.createElement('div');
      tabs.id = 'it_module_tabs';
      tabs.className = 'it-module-tabs';
      tabs.innerHTML = `
        <button type="button" id="it_tab_main" class="it-module-tab active">Ana Modül</button>
        <button type="button" id="it_tab_eys" class="it-module-tab">EYS Modülü</button>
      `;

      const mainPage = document.createElement('div');
      mainPage.id = 'it_main_tab_page';

      const eysPage = document.createElement('div');
      eysPage.id = 'it_eys_tab_page';
      eysPage.style.display = 'none';

      const children = Array.from(mainWrap.childNodes);
      mainWrap.appendChild(tabs);
      mainWrap.appendChild(mainPage);
      mainWrap.appendChild(eysPage);

      children.forEach(ch => {
        if (ch !== tabs && ch !== mainPage && ch !== eysPage) mainPage.appendChild(ch);
      });

      const activate = (tab) => {
        const mainBtn = document.getElementById('it_tab_main');
        const eysBtn = document.getElementById('it_tab_eys');
        const mainPg = document.getElementById('it_main_tab_page');
        const eysPg = document.getElementById('it_eys_tab_page');
        const eysPanel = document.getElementById('eys-tabbed-bot-panel');

        if (tab === 'eys') {
          if (eysPanel && eysPg && eysPanel.parentElement !== eysPg) {
            eysPg.appendChild(eysPanel);
            eysPanel.classList.add('it-embedded-eys');
            eysPanel.style.display = '';
          }
          if (mainPg) mainPg.style.display = 'none';
          if (eysPg) eysPg.style.display = 'block';
          if (mainBtn) mainBtn.classList.remove('active');
          if (eysBtn) eysBtn.classList.add('active');
        } else {
          if (mainPg) mainPg.style.display = 'block';
          if (eysPg) eysPg.style.display = 'none';
          if (mainBtn) mainBtn.classList.add('active');
          if (eysBtn) eysBtn.classList.remove('active');
        }
      };

      tabs.querySelector('#it_tab_main').onclick = () => activate('main');
      tabs.querySelector('#it_tab_eys').onclick = () => activate('eys');

      window.__itActivateModuleTab = activate;
    }

    const eysPanel = document.getElementById('eys-tabbed-bot-panel');
    const eysPg = document.getElementById('it_eys_tab_page');
    if (eysPanel && eysPg && eysPanel.parentElement !== eysPg) {
      eysPg.appendChild(eysPanel);
      eysPanel.classList.add('it-embedded-eys');
      if (!document.getElementById('it_tab_eys')?.classList.contains('active')) {
        eysPg.style.display = 'none';
      }
    }

    const launcher = document.getElementById('istakip-eys-launcher');
    if (launcher) launcher.style.display = 'none';
  } catch (_) {}
}

function switchModulePanel(target) {
  try {
    setupUnifiedModuleTabs();
    if (typeof window.__itActivateModuleTab === 'function') {
      window.__itActivateModuleTab(target === 'eys' ? 'eys' : 'main');
      return true;
    }
  } catch (_) {}
  return false;
}

try { window.__istakipSwitchModule = switchModulePanel; } catch (_) {}

  function itGetJobField(obj, names) {
    try {
      const seen = new Set();
      const stack = [obj || {}];
      while (stack.length) {
        const cur = stack.shift();
        if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
        seen.add(cur);
        for (const n of names || []) {
          if (cur[n] !== undefined && cur[n] !== null && String(cur[n]).trim() !== '') return cur[n];
        }
        for (const k of Object.keys(cur)) {
          const v = cur[k];
          if (v && typeof v === 'object') stack.push(v);
        }
      }
    } catch (_) {}
    return '';
  }

  function itCleanDigits(v) { return String(v || '').replace(/\D+/g, ''); }

  function itExtractVdKodu6(v) {
    const s = String(v || '').trim();
    if (!s) return '';
    // VDKODU 6 hanelidir. Alan bazen "016253 - ÇEKİRGE" gibi, bazen de sadece metin gelir.
    const direct = s.replace(/\D+/g, '');
    if (/^\d{6}$/.test(direct)) return direct;
    const m = s.match(/(?:^|\D)(\d{6})(?:\D|$)/);
    if (m) return m[1];
    return '';
  }

  function itFindMersisVdKodu(job, defaultVd) {
    // İş Takip kullanıcı üzerindeki işlerde vergiDairesi alanı çoğu zaman "Çekirge Vergi Dairesi..." metni geliyor.
    // Bu metin VDKODU diye gönderilirse EVDB Rapor MERSİS işlem listesi boş döner ve İşlem Bilgisi dolmaz.
    const k = job?.kaynakEkBilgiler || {};
    const candidates = [
      job?.vdKodu, job?.vdkodu, job?.VDKODU, job?.vd_kodu, job?.is_vdKodu, job?.is_vdkodu,
      job?.vergiDairesiKodu, job?.vergi_dairesi_kodu, job?.vdkod, job?.vdKod,
      k?.vdKodu, k?.vdkodu, k?.VDKODU, k?.vd_kodu, k?.is_vdKodu, k?.is_vdkodu,
      k?.vergiDairesiKodu, k?.vergi_dairesi_kodu, k?.vdkod, k?.vdKod,
      defaultVd
    ];
    for (const c of candidates) {
      const code = itExtractVdKodu6(c);
      if (code) return code;
    }
    return itExtractVdKodu6(defaultVd) || '016253';
  }

  function itLooksLikeMersisIslemBilgisiText(v) {
    const t = String(v || '').replace(/\s+/g, ' ').trim();
    if (!t || t === '-') return false;
    const l = t.toLocaleLowerCase('tr-TR');
    return /^(başarılı|basarili|hatalı|hatali|bilgi|uyarı|uyari)\b/.test(l)
      || l.includes('bildirimi vergi dairesi')
      || l.includes('kontrol edilerek sicil kayıtlarına')
      || l.includes('sicil kayıtlarına bilgi girişi')
      || l.includes('lütfen kontrol ediniz')
      || l.includes('doğrulanamadı') || l.includes('dogrulanamadi');
  }

  function itMersisRawIslemBilgisiFromJob(job) {
    const val = itGetJobField(job, [
      'islemBilgisi','ISLEMBILGISI','islem_bilgisi','islemBilgi','ISLEM_BILGISI',
      'is_islemBilgisi','is_islem_bilgisi','akis_islemBilgisi','akis_islem_bilgisi',
      'sonucBilgisi','is_sonucBilgisi','akis_sonucBilgisi','sonucAciklama','is_sonucAciklama',
      'hata','HATA','is_hata','akis_hata','hataBilgisi','hataAciklama',
      'islemSonuc','islemSonucu','is_islemSonuc','is_islemSonucu'
    ]);
    const txt = String(val || '').replace(/\s+/g, ' ').trim();
    return itLooksLikeMersisIslemBilgisiText(txt) ? txt : '';
  }

  function itFindMersisNo(job, bot) {
    const direct = itGetJobField(job, ['mersisNo','mersis','MersisNo','MERSISNO']);
    if (itCleanDigits(direct).length >= 14) return itCleanDigits(direct);
    let blob = '';
    try { blob += ' ' + (bot && bot.getBelgeBilgiText ? bot.getBelgeBilgiText(job) : ''); } catch (_) {}
    try { blob += ' ' + (bot && bot.getKaynakText ? bot.getKaynakText(job) : ''); } catch (_) {}
    try { blob += ' ' + JSON.stringify(job || {}); } catch (_) {}
    const labelled = blob.match(/mersis\s*no\s*[:：]?\s*(\d{14,20})/i);
    if (labelled) return labelled[1];
    const nums = blob.match(/\b\d{14,20}\b/g) || [];
    return nums[0] || '';
  }

  function itFindVkn(job, bot) {
    const direct = itGetJobField(job, ['is_vergiNo','vergiNo','vergino','vkn','mukellefVkn','mukVkn','VERGINO']);
    if (itCleanDigits(direct).length === 10) return itCleanDigits(direct);
    let blob = '';
    try { blob += ' ' + (bot && bot.getBelgeBilgiText ? bot.getBelgeBilgiText(job) : ''); } catch (_) {}
    try { blob += ' ' + JSON.stringify(job || {}); } catch (_) {}
    const labelled = blob.match(/vergi\s*no\s*[:：]?\s*(\d{10})/i);
    if (labelled) return labelled[1];
    const nums = blob.match(/\b\d{10}\b/g) || [];
    return nums[0] || '';
  }

  function itYmdFromAnything(v) {
    const s = String(v || '').trim();
    let m = s.match(/(\d{2})[\.\/\-](\d{2})[\.\/\-](\d{4})/);
    if (m) return m[3] + m[2] + m[1];
    m = s.match(/(20\d{2})[\.\/\-]?(\d{2})[\.\/\-]?(\d{2})/);
    if (m) return m[1] + m[2] + m[3];
    return '';
  }

  function itDeepFindFirstByKey(obj, keyPred) {
    try {
      const seen = new Set();
      const stack = [obj];
      while (stack.length) {
        const cur = stack.shift();
        if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
        seen.add(cur);
        for (const [k, v] of Object.entries(cur)) {
          if (keyPred(String(k || ''))) return v;
          if (v && typeof v === 'object') stack.push(v);
        }
      }
    } catch (_) {}
    return '';
  }

  function itFindJobGelisYmd(job, bot) {
    // MERSİS rapor sorgusunda kullanılacak tarih, İş Takip iş listesinden gelen
    // akis_atanma_Zamani alanının ilk 8 hanesidir. Bunu en öne alıyoruz;
    // belge/tescil/rapor tarihleri önce okunursa yanlış güne sorgu atabiliyordu.
    const atanmaVal = itGetJobField(job, [
      'akis_atanma_Zamani','akis_atanmaZamani','akisAtanmaZamani','akis_atanma_zamani',
      'akisAtamaZamani','akis_atama_Zamani','akis_atamaZamani','akis_atama_zamani',
      'atamaZamani','atama_zamani','atanmaZamani','atanma_zamani'
    ]) || itDeepFindFirstByKey(job, k => {
      const lk = k.toLocaleLowerCase('tr-TR').replace(/[ıİ]/g, 'i');
      return (lk.includes('atanma') || lk.includes('atama')) && (lk.includes('zaman') || lk.includes('zamani'));
    });
    const atanmaYmd = itYmdFromAnything(atanmaVal);
    if (atanmaYmd) return atanmaYmd;

    const directCandidates = [
      itGetJobField(job, ['is_gelisTarihi','is_gelişTarihi','gelisTarihi','gelişTarihi','isGelmeTarihi','gelmeTarihi','is_kaynakTarihi','kaynakTarihi','is_tarih','tarih','is_olusturmaTarihi','olusturmaTarihi','olusturulmaTarihi','createDate','createdDate','talepTarihi','basvuruTarihi','başvuruTarihi','evrakTarihi','gonderilmeTarihi','gönderilmeTarihi','is_gonderilmeTarihi','is_gönderilmeTarihi']),
      itGetJobField(job && job.kaynakEkBilgiler, ['akis_atanma_Zamani','akisAtanmaZamani','is_gelisTarihi','gelisTarihi','is_tarih','tarih','is_kaynakTarihi','kaynakTarihi','talepTarihi','basvuruTarihi','evrakTarihi','olusturmaTarihi','createDate','createdDate']),
      bot && bot.getKaynakText ? bot.getKaynakText(job) : '',
      bot && bot.getBelgeBilgiText ? bot.getBelgeBilgiText(job) : ''
    ];
    for (const c of directCandidates) {
      const ymd = itYmdFromAnything(c);
      if (ymd) return ymd;
    }

    // İş Takip cevabında tarih alanı farklı isimde gelebiliyor.
    // Atanma zamanı yoksa geliş/kaynak/talep/başvuru/evrak/tarih geçen alanları derin tarar.
    try {
      const wanted = ['gelis','geliş','gelme','kaynak','talep','basvuru','başvuru','evrak','tarih','olusturma','oluşturma','created','create'];
      const seen = new Set();
      const stack = [job];
      while (stack.length) {
        const cur = stack.shift();
        if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
        seen.add(cur);
        for (const [k, v] of Object.entries(cur)) {
          const lk = String(k || '').toLocaleLowerCase('tr-TR');
          if (wanted.some(w => lk.includes(w))) {
            const ymd = itYmdFromAnything(v);
            if (ymd) return ymd;
          }
          if (v && typeof v === 'object') stack.push(v);
        }
      }
    } catch (_) {}

    // Son çare: ham JSON içinde görünen ilk tarih. Bugüne otomatik düşmez;
    // böylece yanlış güne sorgu atıp yanlış mükellefe gitmez.
    try {
      const ymd = itYmdFromAnything(JSON.stringify(job || {}));
      if (ymd) return ymd;
    } catch (_) {}
    return '';
  }


  function itFormatYmdFromDate(dt) {
    const yy = dt.getFullYear();
    const mm = String(dt.getMonth() + 1).padStart(2, '0');
    const dd = String(dt.getDate()).padStart(2, '0');
    return `${yy}${mm}${dd}`;
  }

  function itPrevCalendarYmd(ymd) {
    const s = String(ymd || '').trim();
    if (!/^20\d{6}$/.test(s)) return s;
    const dt = new Date(Number(s.slice(0,4)), Number(s.slice(4,6)) - 1, Number(s.slice(6,8)));
    dt.setDate(dt.getDate() - 1);
    return itFormatYmdFromDate(dt);
  }

  function itPrevBusinessYmdForWeekend(ymd) {
    const s = String(ymd || '').trim();
    if (!/^20\d{6}$/.test(s)) return s;
    const dt = new Date(Number(s.slice(0,4)), Number(s.slice(4,6)) - 1, Number(s.slice(6,8)));
    const day = dt.getDay(); // 0=Pazar, 6=Cumartesi
    if (day === 6) dt.setDate(dt.getDate() - 1);      // Cumartesi -> Cuma
    else if (day === 0) dt.setDate(dt.getDate() - 2); // Pazar -> Cuma
    return itFormatYmdFromDate(dt);
  }

  function itFindMersisRaporQueryYmd(job, bot) {
    // EVDB Rapor MERSİS işlem listesi hafta sonu gelen İş Takip kayıtlarını
    // normal sistemdeki gibi önceki iş günüyle buluyor: Cumartesi/Pazar -> önceki Cuma.
    return itPrevBusinessYmdForWeekend(itFindJobGelisYmd(job, bot));
  }

  function itMersisRaporDateFallbacks(primaryYmd) {
    // Arefe / yarım gün resmi tatil gibi durumlarda İş Takip ataması aynı gün görünür,
    // fakat EVDB Rapor MERSİS İşlem Listesi kaydı bir önceki iş gününde bulunur.
    // Bu nedenle ilk tarih boş/eşleşmesiz dönerse bir önceki gün ikinci deneme yapılır.
    const out = [];
    const add = (v, reason) => {
      const s = String(v || '').trim();
      if (/^20\d{6}$/.test(s) && !out.some(x => x.date === s)) out.push({ date: s, reason });
    };
    add(primaryYmd, 'asil');
    add(itPrevCalendarYmd(primaryYmd), 'onceki-gun');
    return out;
  }

  function itMersisKind(job, bot) {
    let txt = '';
    try { txt += ' ' + (bot && bot.getIsTuruText ? bot.getIsTuruText(job) : ''); } catch (_) {}
    try { txt += ' ' + (bot && bot.getBelgeBilgiText ? bot.getBelgeBilgiText(job) : ''); } catch (_) {}
    try { txt += ' ' + (bot && bot.getKaynakText ? bot.getKaynakText(job) : ''); } catch (_) {}
    try { txt += ' ' + JSON.stringify(job || {}); } catch (_) {}
    const t = txt.toLocaleLowerCase('tr-TR');
    const has = (...words) => words.some(w => t.includes(w));
    const degis = has('değiş', 'degis', 'değisik', 'değişik');
    const acilis = has('açılış', 'acilis', 'acılış');

    // Merkez açılış ayrı liste türüyle geliyor. Diğer MERSİS türlerinde normal sistem 999 ile listeleyip
    // dönen kaydın gerçek ISLEMTURU / ISLEMTURUKOD değerini detay isteğine koyuyor.
    if (has('merkez') && acilis) return { listTur: '101', title: 'Merkez Açılış', kod: '101' };
    // Ünvan değişikliği EVDB Rapor MERSİS işlem listesinde ayrı işlem türü koduyla (103) sorgulanıyor.
    // 999 ile sorgulanırsa İşlem Bilgisi boş kalıyor ve önizleme için detay kaydı bulunamıyor.
    if (has('unvan', 'ünvan') && degis) return { listTur: '103', title: 'Ünvan Değişikliği', kod: '103' };
    if (has('şube', 'sube') && acilis) return { listTur: '999', title: 'Şube Açılış', kod: '999' };
    if (has('adres') && has('nakil') && has('işe başlama', 'ise baslama')) return { listTur: '999', title: 'Adres Değişikliği Nedeniyle Nakil İşe Başlama', kod: '999' };
    if (has('adres') && degis) return { listTur: '999', title: 'Adres Bilgi Değişikliği', kod: '999' };
    if (has('sorumlu') || has('temsilci') || has('yönetici', 'yonetici')) return { listTur: '999', title: 'Sorumlu Bilgileri Değişikliği', kod: '999' };
    if (has('hisse') || has('pay') || has('ortaklık', 'ortaklik') || has('tüzel ortak', 'tuzel ortak')) return { listTur: '999', title: 'Tüzel Ortaklık Bilgileri Değişikliği', kod: '999' };
    if (has('birleşme', 'birlesme') || has('bölünme', 'bolunme')) return { listTur: '999', title: 'Birleşme Halinde Terk - Birleşme Bilgi Giriş', kod: '999' };
    if (has('tasfiye kapanış', 'tasfiye kapanis', 'terkin')) return { listTur: '999', title: 'Tasfiye Kapanış (Tasfiye Sonu Terkin) İş Bırakma', kod: '999' };
    if (has('tasfiye')) return { listTur: '999', title: 'Tasfiyeye Giriş', kod: '999' };
    return { listTur: '999', title: 'MERSİS İşlemi', kod: '999' };
  }


  function itMersisListTursForKind(kind) {
    const out = [];
    const add = (v) => {
      const s = String(v || '').trim();
      if (s && !out.includes(s)) out.push(s);
    };
    add(kind && kind.listTur);
    // Ünvan değişikliğinde sistemde hem yeni özel kod (103) hem eski genel liste (999)
    // farklı alanları doldurabiliyor. İki listeyi birlikte okuyup kaydı/önizlemeyi tamamlıyoruz.
    const title = String((kind && kind.title) || '').toLocaleLowerCase('tr-TR');
    const kod = String((kind && (kind.kod || kind.listTur)) || '').trim();
    if (kod === '103' || title.includes('unvan') || title.includes('ünvan')) add('999');
    if (!out.length) out.push('999');
    return out;
  }

  function itMersisMergeDataObjects(primary, secondary) {
    if (!secondary || typeof secondary !== 'object') return primary || {};
    if (!primary || typeof primary !== 'object') return secondary || {};
    const out = Array.isArray(primary) ? primary.slice() : { ...primary };
    for (const [k, v] of Object.entries(secondary)) {
      const cur = out[k];
      if (Array.isArray(cur) && Array.isArray(v)) {
        out[k] = cur.length ? cur : v;
      } else if ((cur === undefined || cur === null || String(cur).trim?.() === '') && v !== undefined && v !== null && String(v).trim?.() !== '') {
        out[k] = v;
      } else if (cur && typeof cur === 'object' && !Array.isArray(cur) && v && typeof v === 'object' && !Array.isArray(v)) {
        out[k] = itMersisMergeDataObjects(cur, v);
      } else if (Array.isArray(v) && (!Array.isArray(cur) || !cur.length)) {
        out[k] = v;
      }
    }
    return out;
  }

  function itMersisMergeDetailResponses(primary, secondary) {
    if (!secondary) return primary;
    if (!primary) return secondary;
    const pData = primary?.data || primary;
    const sData = secondary?.data || secondary;
    const mergedData = itMersisMergeDataObjects(pData, sData);
    return { ...secondary, ...primary, data: mergedData, __mergedFrom: [primary, secondary] };
  }

  function itEvdoReportBaseUrl() {
    try { return (location.protocol || 'http:') + '//keys.ggm.bim'; } catch (_) { return 'http://keys.ggm.bim'; }
  }

  function itTokenUsable(v) {
    const t = String(v || '').trim();
    if (!t || t.includes('...') || t.length < 25) return '';
    return t;
  }

  function itGetGpPortalTokenCandidate() {
    const candidates = [];
    try { candidates.push(new URLSearchParams(location.search).get('token')); } catch (_) {}
    try { candidates.push(resolveTokenForModule('gp')); } catch (_) {}
    try { candidates.push(resolveTokenForModule('portal')); } catch (_) {}
    try { candidates.push(resolveTokenForModule('evdo')); } catch (_) {}
    try { candidates.push(resolveTokenForModule('e')); } catch (_) {}
    try {
      const d = getDiscovered('evdo');
      candidates.push(d?.tokensByModule?.gp, d?.tokensByModule?.portal, d?.tokensByModule?.evdo, d?.tokensByModule?.e, d?.token);
    } catch (_) {}
    return candidates.map(itTokenUsable).find(Boolean) || '';
  }

  const IT_EVDO_RAPOR_TOKEN_CACHE_KEY = 'istakip.evdoRaporToken.v431122';
  const IT_EVDO_RAPOR_TOKEN_TTL = 8 * 60 * 60 * 1000;

  function itReadEvdoRaporTokenCache() {
    const now = Date.now();
    const candidates = [];
    try { candidates.push(globalThis.__istakipEvdoRaporToken); } catch (_) {}
    try { candidates.push(window.__istakipEvdoRaporToken); } catch (_) {}
    try { candidates.push(JSON.parse(sessionStorage.getItem(IT_EVDO_RAPOR_TOKEN_CACHE_KEY) || 'null')); } catch (_) {}
    try { candidates.push(JSON.parse(localStorage.getItem(IT_EVDO_RAPOR_TOKEN_CACHE_KEY) || 'null')); } catch (_) {}
    for (const c of candidates) {
      const token = itTokenUsable(c && c.token);
      const time = Number(c && c.time) || 0;
      if (token && now - time < IT_EVDO_RAPOR_TOKEN_TTL) return { ...c, token, time };
    }
    return null;
  }

  function itWriteEvdoRaporTokenCache(entry) {
    const clean = { token: itTokenUsable(entry && entry.token), gpToken: itTokenUsable(entry && entry.gpToken), time: Number(entry && entry.time) || Date.now(), source: entry?.source || 'captured-evdo-rapor-token' };
    if (!clean.token) return;
    try { globalThis.__istakipEvdoRaporToken = clean; } catch (_) {}
    try { window.__istakipEvdoRaporToken = clean; } catch (_) {}
    try { sessionStorage.setItem(IT_EVDO_RAPOR_TOKEN_CACHE_KEY, JSON.stringify(clean)); } catch (_) {}
    try { localStorage.setItem(IT_EVDO_RAPOR_TOKEN_CACHE_KEY, JSON.stringify(clean)); } catch (_) {}
  }

  function itCapturedEvdoRaporToken() {
    // EVDB modül tokeni ile EVDB Rapor tokeni aynı kabul edilmeyecek.
    // Rapor tokeni yalnızca açıkça /evdorapor_server/assos-login cevabından, rapor bağlamında yakalanmışsa kullanılır.
    try {
      const d = getDiscovered('evdo') || {};
      const token = itTokenUsable(d.evdbRaporToken || state.discovery.evdbRaporToken);
      const source = String(d.evdbRaporTokenSource || state.discovery.evdbRaporTokenSource || '');
      if (token && /evdorapor_server\/assos-login|bot-once:\/evdorapor_server\/assos-login|assos-login-response/i.test(source)) {
        return { token, source: source || 'captured-evdb-rapor-assos-login' };
      }
    } catch (_) {}
    return null;
  }

  let itEvdoRaporLoginPromise = null;

  async function itLoginEvdoRaporOnce() {
    if (itEvdoRaporLoginPromise) return itEvdoRaporLoginPromise;
    itEvdoRaporLoginPromise = (async () => {
      const gpToken = itGetGpPortalTokenCandidate();
      if (!gpToken) throw new Error('GP token bulunamadı; EVDB Rapor tokeni alınamadı.');
      const p = new URLSearchParams();
      p.append('assoscmd', 'shlogin');
      p.append('rtype', 'json');
      p.append('token', gpToken);
      const url = itEvdoReportBaseUrl() + '/evdorapor_server/assos-login';
      const res = await fetch(url, { method: 'POST', body: p, credentials: 'include', cache: 'no-store' });
      if (!res.ok) throw new Error(`EVDB Rapor assos-login ağ hatası: ${res.status}`);
      const txt = await res.text();
      let json = null;
      try { json = JSON.parse(txt); } catch (_) {}
      const token = itTokenUsable(json && (json.token || json.data?.token || json.result?.token));
      if (!token) throw new Error('EVDB Rapor assos-login döndü ama token okunamadı.');
      itWriteEvdoRaporTokenCache({ token, gpToken, time: Date.now(), source: 'bot-once:/evdorapor_server/assos-login' });
      return token;
    })();
    try {
      return await itEvdoRaporLoginPromise;
    } catch (e) {
      itEvdoRaporLoginPromise = null;
      throw e;
    }
  }

  async function itGetEvdoRaporToken(forceRefresh = false) {
    if (!forceRefresh) {
      const cached = itReadEvdoRaporTokenCache();
      if (cached && cached.token) return cached.token;
    }

    const captured = itCapturedEvdoRaporToken();
    if (captured && captured.token) {
      itWriteEvdoRaporTokenCache({ token: captured.token, gpToken: '', time: Date.now(), source: captured.source || 'captured-evdo-rapor-token' });
      return captured.token;
    }

    // Normal sistemin açtığı EVDB Rapor tokeni yakalanmadıysa, bot doğru endpoint'e yalnızca bir kere assos-login atar ve tokeni cache'ler.
    return await itLoginEvdoRaporOnce();
  }

  async function itEvdoRaporPost(cmd, jp, token) {
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', makeCallId());
    // HAR akışında dispatch isteklerinde module=evdorapor zorunlu geliyor.
    p.append('module', 'evdorapor');
    p.append('token', token);
    p.append('jp', JSON.stringify(jp || {}));
    const res = await fetch(itEvdoReportBaseUrl() + '/evdorapor_server/dispatch', { method: 'POST', body: p, credentials: 'include', cache: 'no-store' });
    if (!res.ok) throw new Error(`EVDB rapor ağ hatası: ${res.status} (${cmd})`);
    const txt = await res.text();
    try { return JSON.parse(txt); } catch (_) { return txt; }
  }

  async function itFetchMersisDetailForPreview(job, bot) {
    const token = await itGetEvdoRaporToken();
    const sess = await itEvdoRaporPost('userSessionService_getUserSessionInfo', { rfDataInfo: [] }, token).catch(() => ({}));
    const defaultVd = String(sess?.data?.VDKODU || sess?.VDKODU || '016253').trim();
    const vdkodu = itFindMersisVdKodu(job, defaultVd);
    const isTakipNo = String(itFindIsTakipNo(job) || itGetJobField(job, ['isTakipNo','istakipNo','is_takip_no','isTakip']) || '').trim();
    const mersisFromJob = itFindMersisNo(job, bot);
    const vknFromJob = itFindVkn(job, bot);
    const kind = itMersisKind(job, bot);
    const rawJobDate = itFindJobGelisYmd(job, bot);
    const date = itFindMersisRaporQueryYmd(job, bot);
    if (!date) throw new Error('MERSİS liste sorgusu için işin geldiği tarih bulunamadı; bugüne sorgu atılmadı. İş Takip satırındaki tarih alanını kontrol et.');
    if (rawJobDate && rawJobDate !== date) { try { console.info('[ISTAKIP-BOT-V4] MERSİS rapor sorgu tarihi hafta sonu nedeniyle önceki iş gününe alındı:', rawJobDate, '->', date); } catch (_) {} }
    const listTurs = itMersisListTursForKind(kind);
    const listPayloads = [];
    const listResps = [];
    let arr = [];
    for (const tur of listTurs) {
      const lp = { SERVISADI: 'RP_EVDO_YSICIL_MERSIS_ISLEM_LISTESI', ISLEMTURU: tur, ISLEMDURUM: '99', ISLEMTARIH: date, BASTARIHI: date, BITISTARIHI: date, VDKODU: vdkodu, VDKODSUZ: 0 };
      listPayloads.push(lp);
      const lr = await itEvdoRaporPost('sicilListeRaporServis_calistir', lp, token).catch(e => ({ __error: e?.message || String(e), data: { veriler: [] } }));
      listResps.push(lr);
      const rows0 = lr?.data?.veriler || lr?.veriler || lr?.data || [];
      const rowsArr = Array.isArray(rows0) ? rows0 : [];
      for (const r of rowsArr) arr.push({ ...r, __listTur: tur, __listPayload: lp });
    }
    const listPayload = listPayloads[0] || { SERVISADI: 'RP_EVDO_YSICIL_MERSIS_ISLEM_LISTESI', ISLEMTURU: kind.listTur || '999', ISLEMDURUM: '99', ISLEMTARIH: date, BASTARIHI: date, BITISTARIHI: date, VDKODU: vdkodu, VDKODSUZ: 0 };
    const listResp = listResps[0] || { data: { veriler: arr } };
    const norm = v => String(v || '').trim();
    const digs = v => itCleanDigits(v);
    const pick = (obj, names) => itGetJobField(obj, names);
    const recIsTakip = r => norm(pick(r, ['isTakipNo','istakipNo','ISTAKIPNO','is_takip_no','isTakip','is_isTakipNo','akis_isTakipNo','isNo','is_no']));
    const recMersis = r => digs(pick(r, ['mersisNo','MERSISNO','mersisno','mersis_no','mersis','MersisNo','MERKEZMERSISNO','merkezMersisNo']));
    const recVkn = r => digs(pick(r, ['vergiNo','VERGINO','vergino','vergi_no','vkn','VKN','vergiKimlikNo','VERGIKIMLIKNO','vergiKimlikNumarasi']));
    const recOid = r => norm(pick(r, ['islemOid','ISLEMOID','islemOID','islem_oid','oid','OID']));
    const recTur = r => norm(pick(r, ['islemTuru','ISLEMTURU','ISLEM_TURU','islem_turu','islemAdi','islemadi','islemAdı','islemTurAdi','islemTuruAdi','ISLEMTURADI','ISLEM_TUR_ADI','ISLEM_ADI','islemAciklama','islemTipi']));
    const recTurKod = r => norm(pick(r, ['islemTuruKod','islemTuruKodu','ISLEMTURUKOD','ISLEMTURUKODU','ISLEM_TURU_KOD','ISLEM_TURU_KODU','islem_turu_kod','islem_turu_kodu','islemTurKodu','ISLEMTURKODU','islemKod','islemKodu','ISLEMKOD','ISLEMKODU','kod','KOD','turKod','TURKOD']));
    const scoreRec = (r) => {
      let score = 0;
      if (isTakipNo && recIsTakip(r) === isTakipNo) score += 100;
      if (mersisFromJob && recMersis(r) === mersisFromJob) score += 80;
      if (vknFromJob && recVkn(r) === vknFromJob) score += 30;
      try {
        const blob = JSON.stringify(r || {});
        if (isTakipNo && blob.includes(isTakipNo)) score += 20;
        if (mersisFromJob && blob.includes(mersisFromJob)) score += 20;
        if (vknFromJob && blob.includes(vknFromJob)) score += 5;
      } catch (_) {}
      return score;
    };
    let ranked = arr.map(r => ({ r, score: scoreRec(r) })).sort((a,b) => b.score - a.score);
    let rec = ranked.length && ranked[0].score > 0 ? ranked[0].r : null;
    let usedFallbackDate = '';
    const directOid = String(itGetJobField(job, ['islemOid','is_islemOid','akisOid','oid']) || '').trim();

    // Arefe / yarım gün resmi tatil durumlarında ilk gün listesi boş veya eşleşmesiz dönebiliyor.
    // O zaman aynı sorguyu bir önceki gün için atıp tıklanan satırı oradan buluyoruz.
    if (!rec) {
      const fallbackDate = itPrevCalendarYmd(date);
      if (fallbackDate && fallbackDate !== date) {
        const fallbackRows = [];
        for (const tur of listTurs) {
          const fp = { SERVISADI: 'RP_EVDO_YSICIL_MERSIS_ISLEM_LISTESI', ISLEMTURU: tur, ISLEMDURUM: '99', ISLEMTARIH: fallbackDate, BASTARIHI: fallbackDate, BITISTARIHI: fallbackDate, VDKODU: vdkodu, VDKODSUZ: 0 };
          const fr = await itEvdoRaporPost('sicilListeRaporServis_calistir', fp, token).catch(e => ({ __error: e?.message || String(e), data: { veriler: [] } }));
          const rows0 = fr?.data?.veriler || fr?.veriler || fr?.data || [];
          const rowsArr = Array.isArray(rows0) ? rows0 : [];
          for (const r of rowsArr) fallbackRows.push({ ...r, __listTur: tur, __listPayload: fp, __fallbackDate: fallbackDate, __fallbackFromDate: date });
        }
        const fRanked = fallbackRows.map(r => ({ r, score: scoreRec(r) })).sort((a,b) => b.score - a.score);
        if (fRanked.length && fRanked[0].score > 0) {
          arr = arr.concat(fallbackRows);
          ranked = arr.map(r => ({ r, score: scoreRec(r) })).sort((a,b) => b.score - a.score);
          rec = fRanked[0].r;
          usedFallbackDate = fallbackDate;
          try { console.info('[ISTAKIP-BOT-V4] MERSİS önizlemede ilk tarih eşleşmedi, önceki gün denendi:', date, '->', fallbackDate); } catch (_) {}
        }
      }
    }

    // Çok kayıt dönerse eşleşme bulmadan ilk satıra düşmek hatalı MERSİS önizlemesine sebep oluyordu.
    if (!rec && arr.length === 1) rec = arr[0];
    if (!rec && mersisFromJob && directOid && isTakipNo) rec = { mersisNo: mersisFromJob, islemOid: directOid, isTakipNo, islemTuru: kind.title, islemTuruKod: kind.kod };
    if (!rec) throw new Error(`EVDB MERSİS işlem listesinde tıklanan satırla eşleşen kayıt bulunamadı. ISTAKIP=${isTakipNo || '-'}, MERSIS=${mersisFromJob || '-'}, VKN=${vknFromJob || '-'}, liste=${arr.length}`);
    const mersisNo = String(recMersis(rec) || mersisFromJob || '').trim();
    const islemOid = String(recOid(rec) || directOid || '').trim();
    const finalIsTakip = String(recIsTakip(rec) || isTakipNo || '').trim();
    const islemTuru = String(recTur(rec) || kind.title || '').trim();
    const islemTuruKod = String(recTurKod(rec) || kind.kod || '').trim();
    if (!mersisNo || !islemOid || !finalIsTakip) throw new Error('MERSİS detay için MERSISNO / ISLEMOID / ISTAKIPNO eksik kaldı.');
    const detailPayload = { SERVISADI: 'RP_EVDO_YSICIL_MERSIS_ISLEM_DETAY_BILGILERI', MERSISNO: mersisNo, ISLEMOID: islemOid, ISTAKIPNO: finalIsTakip, ISLEMTURU: islemTuru, ISLEMTURUKOD: islemTuruKod };
    let detailResp = await itEvdoRaporPost('sicilListeRaporServis_calistir', detailPayload, token);

    // Ünvan değişikliği gibi türlerde eski (999) ve yeni (103) detay cevapları farklı bölümleri dolduruyor.
    // Aynı satır için diğer listeden eşleşen kayıt varsa onun detayını da alıp boş kalan alanları tamamlıyoruz.
    const altDetails = [];
    try {
      const primaryTur = String(rec.__listTur || kind.listTur || '').trim();
      const altCandidates = arr
        .filter(r => r && String(r.__listTur || '').trim() && String(r.__listTur || '').trim() !== primaryTur)
        .map(r => ({ r, score: scoreRec(r) }))
        .filter(x => x.score > 0)
        .sort((a,b) => b.score - a.score);
      for (const cand of altCandidates.slice(0, 2)) {
        const ar = cand.r;
        const aMersisNo = String(recMersis(ar) || mersisNo || '').trim();
        const aOid = String(recOid(ar) || islemOid || '').trim();
        const aIsTakip = String(recIsTakip(ar) || finalIsTakip || '').trim();
        const aTur = String(recTur(ar) || kind.title || '').trim();
        const aTurKod = String(recTurKod(ar) || ar.__listTur || kind.kod || '').trim();
        if (!aMersisNo || !aOid || !aIsTakip) continue;
        const altPayload = { SERVISADI: 'RP_EVDO_YSICIL_MERSIS_ISLEM_DETAY_BILGILERI', MERSISNO: aMersisNo, ISLEMOID: aOid, ISTAKIPNO: aIsTakip, ISLEMTURU: aTur, ISLEMTURUKOD: aTurKod };
        const altResp = await itEvdoRaporPost('sicilListeRaporServis_calistir', altPayload, token).catch(() => null);
        if (altResp) {
          altDetails.push({ rec: ar, detailPayload: altPayload, detailResp: altResp });
          detailResp = itMersisMergeDetailResponses(detailResp, altResp);
        }
      }
    } catch (_) {}
    return { rec, listPayload, listResp, listPayloads, listResps, detailPayload, detailResp, altDetails, tokenUsed: token, usedFallbackDate };
  }


  function itMersisListIslemBilgisiFromRec(rec) {
    const val = itGetJobField(rec, [
      'islemBilgisi','ISLEMBILGISI','islem_bilgisi','islemBilgi','ISLEM_BILGISI',
      // EVDB Rapor MERSİS İşlem Listesi ekranındaki "İşlem Bilgisi" sütunu JSON cevapta çoğu zaman "hata" alanı olarak geliyor.
      'hata','HATA','hataBilgisi','HATABILGISI','hataAciklama','HATAACIKLAMA',
      'sonucBilgisi','SONUCBILGISI','sonucAciklama','SONUCACIKLAMA',
      'aciklama','ACIKLAMA','bilgi','BILGI','uyari','UYARI','islemSonuc','ISLEMSONUC','islemSonucu','ISLEMSONUCU'
    ]);
    return String(val || '').replace(/\s+/g, ' ').trim();
  }

  function itIsMersisListJob(job, bot) {
    let txt = '';
    try { txt += ' ' + (bot && bot.getIsTuruText ? bot.getIsTuruText(job) : ''); } catch (_) {}
    try { txt += ' ' + (bot && bot.getBelgeBilgiText ? bot.getBelgeBilgiText(job) : ''); } catch (_) {}
    try { txt += ' ' + (bot && bot.getKaynakText ? bot.getKaynakText(job) : ''); } catch (_) {}
    try { txt += ' ' + JSON.stringify(job || {}); } catch (_) {}
    return txt.toLocaleLowerCase('tr-TR').includes('mersis');
  }

  function itMersisRecScoreForJob(rec, job, bot) {
    const norm = v => String(v || '').trim();
    const digs = v => itCleanDigits(v);
    const isTakipNo = String(itFindIsTakipNo(job) || '').trim();
    const mersisFromJob = itFindMersisNo(job, bot);
    const vknFromJob = itFindVkn(job, bot);
    const recIsTakip = r => norm(itGetJobField(r, ['isTakipNo','istakipNo','ISTAKIPNO','is_takip_no','isTakip','is_isTakipNo','akis_isTakipNo','isNo','is_no']));
    const recMersis = r => digs(itGetJobField(r, ['mersisNo','MERSISNO','mersisno','mersis_no','mersis','MersisNo','MERKEZMERSISNO','merkezMersisNo']));
    const recVkn = r => digs(itGetJobField(r, ['vergiNo','VERGINO','vergino','vergi_no','vkn','VKN','vergiKimlikNo','VERGIKIMLIKNO','vergiKimlikNumarasi']));
    let score = 0;
    if (isTakipNo && recIsTakip(rec) === isTakipNo) score += 100;
    if (mersisFromJob && recMersis(rec) === mersisFromJob) score += 80;
    if (vknFromJob && recVkn(rec) === vknFromJob) score += 30;
    try {
      const blob = JSON.stringify(rec || {});
      if (isTakipNo && blob.includes(isTakipNo)) score += 20;
      if (mersisFromJob && blob.includes(mersisFromJob)) score += 20;
      if (vknFromJob && blob.includes(vknFromJob)) score += 5;
    } catch (_) {}
    return score;
  }

  async function itEnrichMersisIslemBilgileriForJobs(jobs, bot) {
    const list = (Array.isArray(jobs) ? jobs : []).filter(j => itIsMersisListJob(j, bot));
    if (!list.length) return { total: 0, matched: 0, skipped: 0 };

    const token = await itGetEvdoRaporToken();
    const sess = await itEvdoRaporPost('userSessionService_getUserSessionInfo', { rfDataInfo: [] }, token).catch(() => ({}));
    let defaultVd = itExtractVdKodu6(sess?.data?.VDKODU || sess?.VDKODU || '016253') || '016253';
    const groups = new Map();
    let skipped = 0;
    for (const job of list) {
      const rawJobDate = itFindJobGelisYmd(job, bot);
      const date = itFindMersisRaporQueryYmd(job, bot);
      if (!date) { skipped++; continue; }
      if (rawJobDate && rawJobDate !== date) { try { job.__mersisRaporSorguTarihi = date; job.__mersisRaporAsilIsTarihi = rawJobDate; } catch (_) {} }
      const kind = itMersisKind(job, bot);
      const vdkodu = itFindMersisVdKodu(job, defaultVd);
      const key = [date, kind.listTur || '999', vdkodu].join('|');
      if (!groups.has(key)) groups.set(key, { date, kind, vdkodu, jobs: [] });
      groups.get(key).jobs.push(job);
    }

    let matched = 0;
    const mersisListCache = new Map();
    const fetchMersisRows = async (date, kind, vdkodu) => {
      const key = [date, (kind && (kind.listTur || kind.kod || kind.title)) || '999', vdkodu].join('|');
      if (mersisListCache.has(key)) return mersisListCache.get(key);
      const out = [];
      for (const tur of itMersisListTursForKind(kind || {})) {
        const listPayload = { SERVISADI: 'RP_EVDO_YSICIL_MERSIS_ISLEM_LISTESI', ISLEMTURU: tur || '999', ISLEMDURUM: '99', ISLEMTARIH: date, BASTARIHI: date, BITISTARIHI: date, VDKODU: vdkodu, VDKODSUZ: 0 };
        const listResp = await itEvdoRaporPost('sicilListeRaporServis_calistir', listPayload, token).catch(() => null);
        const rows = listResp?.data?.veriler || listResp?.veriler || listResp?.data || [];
        const rowsArr = Array.isArray(rows) ? rows : [];
        for (const r of rowsArr) out.push({ ...r, __listTur: tur, __listPayload: listPayload });
      }
      mersisListCache.set(key, out);
      return out;
    };

    for (const g of groups.values()) {
      const arr = await fetchMersisRows(g.date, g.kind || {}, g.vdkodu);
      for (const job of g.jobs) {
        let ranked = arr.map(r => ({ r, score: itMersisRecScoreForJob(r, job, bot) })).sort((a,b) => b.score - a.score);
        let best = ranked.length && ranked[0].score > 0 ? ranked[0].r : (arr.length === 1 ? arr[0] : null);

        // İlk tarih boş/eşleşmesiz dönerse bir önceki günle tekrar dene.
        // Arefe/öğleden sonra resmi tatil gibi kayıtlarda İş Takip tarihi 26 görünürken EVDB Rapor listesi 25'te bulunabiliyor.
        if (!best) {
          const fallbackDate = itPrevCalendarYmd(g.date);
          if (fallbackDate && fallbackDate !== g.date) {
            const fbRows = await fetchMersisRows(fallbackDate, g.kind || {}, g.vdkodu);
            const fbRanked = fbRows.map(r => ({ r, score: itMersisRecScoreForJob(r, job, bot) })).sort((a,b) => b.score - a.score);
            if (fbRanked.length && fbRanked[0].score > 0) {
              best = fbRanked[0].r;
              try {
                job.__mersisRaporSorguTarihi = fallbackDate;
                job.__mersisRaporAsilIsTarihi = job.__mersisRaporAsilIsTarihi || g.date;
                job.__mersisRaporFallback = `${g.date}->${fallbackDate}`;
              } catch (_) {}
              try { console.info('[ISTAKIP-BOT-V4] MERSİS işlem bilgisi ilk tarihte bulunamadı, önceki gün denendi:', g.date, '->', fallbackDate); } catch (_) {}
            }
          }
        }

        if (best) {
          const bilgi = itMersisListIslemBilgisiFromRec(best);
          const islemTuru = itGetJobField(best, ['islemTuru','ISLEMTURU','islem_turu','ISLEM_TURU','islemTuruAdi','islemAdi']);
          if (islemTuru) job.__mersisIslemTuru = itNormalizeMersisIslemTuruLabel(islemTuru);
          if (bilgi) {
            job.__mersisIslemBilgisi = bilgi;
            job.__mersisListRec = best;
            matched++;
          } else {
            const rawBilgi = itMersisRawIslemBilgisiFromJob(job);
            job.__mersisIslemBilgisi = rawBilgi || '-';
            if (rawBilgi) matched++;
          }
        } else {
          const rawBilgi = itMersisRawIslemBilgisiFromJob(job);
          if (rawBilgi) {
            job.__mersisIslemBilgisi = rawBilgi;
            matched++;
          }
        }
      }
    }
    return { total: list.length, matched, skipped };
  }

  function itFirst(v) { return Array.isArray(v) ? (v[0] || {}) : (v || {}); }
  function itMersisNormKey(k) {
    return String(k || '')
      .toLocaleLowerCase('tr-TR')
      .replace(/[ıİ]/g, 'i')
      .replace(/[şŞ]/g, 's')
      .replace(/[ğĞ]/g, 'g')
      .replace(/[üÜ]/g, 'u')
      .replace(/[öÖ]/g, 'o')
      .replace(/[çÇ]/g, 'c')
      .replace(/[^a-z0-9]+/g, '');
  }

  function itVal(row, names) {
    if (!row || typeof row !== 'object') return '';
    for (const n of names) {
      const v = row[n];
      if (v !== undefined && v !== null && String(v).trim() !== '') return v;
    }
    const keyMap = {};
    for (const k of Object.keys(row)) keyMap[itMersisNormKey(k)] = k;
    for (const n of names) {
      const realKey = keyMap[itMersisNormKey(n)];
      if (!realKey) continue;
      const v = row[realKey];
      if (v !== undefined && v !== null && String(v).trim() !== '') return v;
    }
    return '';
  }

  function itMersisCleanVal(v) {
    if (v === undefined || v === null) return '';
    const s = String(v).replace(/\s+/g, ' ').trim();
    if (!s || /^undefined$/i.test(s) || /^null$/i.test(s)) return '';
    return s;
  }

  function itMersisList(v) {
    if (Array.isArray(v)) return v.filter(x => x && typeof x === 'object');
    if (v && typeof v === 'object') return [v];
    return [];
  }

  function itRowsOf(arr, columns) {
    const list = itMersisList(arr);
    const activeCols = columns.filter(c => list.some(item => itMersisCleanVal(itVal(item, c[1]))));
    if (!list.length || !activeCols.length) return '';
    const rows = list
      .filter(item => activeCols.some(c => itMersisCleanVal(itVal(item, c[1]))))
      .map(item => `<tr>${activeCols.map(c => `<td>${itHtmlEscape(itMersisCleanVal(itVal(item, c[1])))}</td>`).join('')}</tr>`)
      .join('');
    if (!rows) return '';
    return `<thead><tr>${activeCols.map(c => `<th>${itHtmlEscape(c[0])}</th>`).join('')}</tr></thead><tbody>${rows}</tbody>`;
  }

  function itMersisPickList(data, names) {
    if (!data || typeof data !== 'object') return [];
    const wanted = names.map(itMersisNormKey);
    const directKeys = Object.keys(data || {});
    for (const n of names) {
      const list = itMersisList(data && data[n]);
      if (list.length) return list;
    }
    for (const k of directKeys) {
      const nk = itMersisNormKey(k);
      if (!wanted.includes(nk)) continue;
      const list = itMersisList(data[k]);
      if (list.length) return list;
    }
    const found = [];
    const seen = new Set();
    const walk = (obj, depth) => {
      if (!obj || depth > 5 || found.length) return;
      if (Array.isArray(obj)) {
        for (const x of obj) walk(x, depth + 1);
        return;
      }
      if (typeof obj !== 'object') return;
      if (seen.has(obj)) return;
      seen.add(obj);
      for (const [k, v] of Object.entries(obj)) {
        const nk = itMersisNormKey(k);
        if (wanted.includes(nk)) {
          const list = itMersisList(v);
          if (list.length) { found.push(...list); return; }
        }
      }
      for (const v of Object.values(obj)) walk(v, depth + 1);
    };
    walk(data, 0);
    return found;
  }

  function itMersisCollectLists(data, keyHints, fieldHints) {
    const out = [];
    const seenObj = new Set();
    const seenRow = new Set();
    const keyNeedles = keyHints.map(itMersisNormKey).filter(Boolean);
    const fieldNeedles = fieldHints.map(itMersisNormKey).filter(Boolean);
    const rowMatches = (row) => {
      if (!row || typeof row !== 'object') return false;
      const keys = Object.keys(row).map(itMersisNormKey);
      return fieldNeedles.some(h => keys.some(k => k.includes(h) || h.includes(k)));
    };
    const addRows = (rows) => {
      for (const r of itMersisList(rows)) {
        if (!rowMatches(r)) continue;
        const sig = JSON.stringify(r);
        if (seenRow.has(sig)) continue;
        seenRow.add(sig);
        out.push(r);
      }
    };
    const walk = (obj, depth, parentKey) => {
      if (!obj || depth > 6) return;
      if (typeof obj === 'object') {
        if (seenObj.has(obj)) return;
        seenObj.add(obj);
      }
      if (Array.isArray(obj)) {
        const pk = itMersisNormKey(parentKey || '');
        if (keyNeedles.some(h => pk.includes(h) || h.includes(pk))) addRows(obj);
        else for (const r of obj) if (rowMatches(r)) addRows([r]);
        for (const x of obj) walk(x, depth + 1, parentKey);
        return;
      }
      if (typeof obj !== 'object') return;
      for (const [k, v] of Object.entries(obj)) {
        const nk = itMersisNormKey(k);
        if (keyNeedles.some(h => nk.includes(h) || h.includes(nk))) addRows(v);
        walk(v, depth + 1, k);
      }
    };
    walk(data, 0, '');
    return out;
  }

  function itMersisFirstRow(data, names) {
    const list = itMersisPickList(data, names);
    return list[0] || {};
  }

  function itMersisSection(title, rows, columns) {
    const table = itRowsOf(rows, columns);
    if (!table) return '';
    return `<div class="sec"><div class="sec-title">${itHtmlEscape(title)}</div><table>${table}</table></div>`;
  }

  function itMersisMeta(pairs) {
    const cells = [];
    for (const [label, value] of pairs) {
      const v = itMersisCleanVal(value);
      if (!v) continue;
      cells.push(`<div class="lbl">${itHtmlEscape(label)}</div><div>${itHtmlEscape(v)}</div>`);
    }
    return `<div class="meta">${cells.join('')}</div>`;
  }

  function itBuildMersisSystemLikeHtml(info, job, bot) {
    const data = info?.detailResp?.data || info?.detailResp || {};
    const rec = info?.rec || {};

    const acilisList = itMersisPickList(data, ['acilisBilgileri']);
    const unvanDegList = itMersisPickList(data, ['unvanDegisikligiBilgileri', 'unvanDegisiklikBilgileri', 'unvanBilgileri', 'unvanDegisikligiBilgisi', 'unvanDegisiklikBilgisi']);
    const adresList = itMersisPickList(data, ['adresBilgileri', 'adresDegisikligiBilgileri', 'adresBilgisi']);
    const faaliyetList = itMersisPickList(data, ['faaliyetBilgileri', 'faaliyetBilgisi']);
    const ortakList = itMersisPickList(data, ['ortakBilgileri', 'ortakBilgisi']);
    const sermayeList = itMersisPickList(data, ['sermayeBilgileri', 'sermayeBilgisi']);
    let temsilList = itMersisPickList(data, ['temsilciBilgileri', 'temsilciBilgisi', 'sorumluBilgileri', 'sorumluBilgisi', 'sorumluDegisikligiBilgileri', 'sorumluBilgileriDegisikligi', 'yoneticiBilgileri', 'yöneticiBilgileri']);
    const iletisimList = itMersisPickList(data, ['iletisimBilgileri', 'iletisimBilgisi']);
    const birlesmeList = itMersisPickList(data, ['birlesmeVeBolunmeBilgileri', 'birlesmeBolunmeBilgileri', 'birlesmeBilgileri', 'bolunmeBilgileri', 'birlesmeVeBolunmeBilgisi', 'birlesmeBolunmeBilgisi', 'birlesmeBolunmeDegisiklikBilgileri']);
    let hisseList = itMersisPickList(data, ['hisseDevriBilgileri', 'hisseDevriDegisenBilgileri', 'hisseDevriDegisenOrtakBilgileri', 'hisseDevriBilgisi', 'ortaklikBilgileriDegisikligi', 'ortaklikDegisikligiBilgileri', 'ortaklikVePayDegisikligiBilgileri', 'ortaklikPayDegisikligiBilgileri', 'payDegisikligiBilgileri', 'payBilgileri', 'hissePayBilgileri', 'degisenOrtakBilgileri', 'tuzelOrtaklikBilgileri', 'tuzelOrtaklikBilgileriDegisikligi']);
    const tasfiyeList = itMersisPickList(data, ['iflasVeTasfiyeBilgileri', 'iflasTasfiyeBilgileri', 'tasfiyeBilgileri', 'iflasVeTasfiyeBilgisi', 'tasfiyeGirisBilgileri', 'tasfiyeKapanisBilgileri', 'tasfiyeSonuTerkinBilgileri']);
    if (!temsilList.length) temsilList = itMersisCollectLists(data, ['temsilci','sorumlu','yonetici','yönetici'], ['temsilciUnvan','temsilciTcKimlikNo','temsilciTCKimlikNo','temsilciVergiNo','yetkiSekli','temsilYetkiSekli','gorevi','görevi']);
    if (!hisseList.length) hisseList = itMersisCollectLists(data, ['hisse','pay','ortaklik','ortaklık','devri','devreden','devralan'], ['devredenOrtakUnvan','devredenUnvan','devralanOrtakUnvan','devralanUnvan','devredenOrtakTCKimlikNo','devralanOrtakTCKimlikNo','toplamSermaye','namaYaziliHisseAdedi','hamilineYaziliHisseAdedi']);

    const headerRow = acilisList[0] || unvanDegList[0] || adresList[0] || birlesmeList[0] || hisseList[0] || tasfiyeList[0] || temsilList[0] || faaliyetList[0] || iletisimList[0] || {};
    const mersisNo = info?.detailPayload?.MERSISNO || itVal(headerRow, ['mersisNo', 'MERSISNO']) || itFindMersisNo(job, bot);
    const vkn = itVal(headerRow, ['vergiNo', 'vergiKimlikNo', 'vkn']) || rec.vergiNo || itFindVkn(job, bot);
    const unvan = itVal(headerRow, ['unvan', 'firmaUnvani', 'firmaUnvan', 'ortakUnvan']) || rec.unvan || itGetJobField(job, ['is_unvan','is_unvan_unvan','unvan']);
    const isTakipNo = info?.detailPayload?.ISTAKIPNO || itFindIsTakipNo(job);
    const islemTuru = info?.detailPayload?.ISLEMTURU || rec.islemTuru || '';
    const tescil = itVal(headerRow, ['tescilTarihi','basTar','baslangicTarihi']) || rec.tescilTarihi || '';
    const vd = itVal(headerRow, ['vergiDairesi']) || '';
    const isyeri = itVal(headerRow, ['isYeriTuru', 'isyeriTuru']) || '';

    const sections = [];
    sections.push(itMersisSection('Açılış Bilgileri', acilisList, [
      ['Vergi Kimlik No', ['vergiNo', 'vergiKimlikNo', 'vkn']],
      ['Unvanı', ['unvan', 'firmaUnvani', 'firmaUnvan']],
      ['Firma Nevi', ['firmaNevi']],
      ['Ticaret Sicili Müdürlüğü', ['tsm', 'ticaretSiciliMudurlugu']],
      ['Ticaret Sicil No', ['sicilNo', 'ticaretSicilNo']],
      ['İş Yeri Türü', ['isYeriTuru', 'isyeriTuru']],
      ['Merkez Mersis No', ['merkezMersisNo']],
      ['Tescil Tarihi', ['tescilTarihi', 'basTar']],
      ['Vergi Dairesi', ['vergiDairesi']]
    ]));

    sections.push(itMersisSection('Ünvan Değişikliği Bilgileri', unvanDegList, [
      ['Mersis No', ['mersisNo', 'MERSISNO']],
      ['Yeni Ünvan', ['yeniUnvan', 'yeniUnvani', 'unvan', 'firmaUnvani', 'firmaUnvan']],
      ['Talep Türü', ['talepTuru', 'talepTipi', 'talep']],
      ['Tescil Tarihi', ['tescilTarihi', 'basTar', 'baslangicTarihi']]
    ]));

    sections.push(itMersisSection('Birleşme ve Bölünme Bilgileri', birlesmeList, [
      ['Mersis No', ['mersisNo']],
      ['Vergi Kimlik No', ['vergiKimlikNo', 'vergiKimlikNumarasi', 'vergiNo', 'vkn']],
      ['Unvan', ['unvan', 'firmaUnvani', 'firmaUnvan']],
      ['Firma Nevi', ['firmaNevi', 'firmaTuru']],
      ['Talep Türü', ['talepTuru', 'talepTipi', 'talep']],
      ['Tescil Tarihi', ['tescilTarihi', 'basTar']]
    ]));

    sections.push(itMersisSection('Hisse Devri Değişen Bilgileri', hisseList, [
      ['Devreden Ortak Unvanı', ['devredenOrtakUnvani', 'devredenOrtakUnvan', 'devredenUnvan', 'devredenUnvani']],
      ['Devreden Ortak T.C.Kimlik No', ['devredenOrtakTCKimlikNo', 'devredenOrtakTcKimlikNo', 'devredenTcKimlikNo', 'devredenTCKimlikNo', 'devredenKimlikNo']],
      ['Devreden Vergi Kimlik No', ['devredenVergiKimlikNo', 'devredenOrtakVergiNo', 'devredenVergiNo']],
      ['Devreden Ortak Pasaport No', ['devredenOrtakPasaportNo', 'devredenPasaportNo']],
      ['Devralan Ortak Unvanı', ['devralanOrtakUnvani', 'devralanOrtakUnvan', 'devralanUnvan', 'devralanUnvani']],
      ['Devralan Ortak T.C.Kimlik No', ['devralanOrtakTCKimlikNo', 'devralanOrtakTcKimlikNo', 'devralanTcKimlikNo', 'devralanTCKimlikNo', 'devralanKimlikNo']],
      ['Devralan Vergi Kimlik No', ['devralanVergiKimlikNo', 'devralanOrtakVergiNo', 'devralanVergiNo']],
      ['Devralan Ortak Pasaport No', ['devralanOrtakPasaportNo', 'devralanPasaportNo']],
      ['Toplam Sermaye', ['toplamSermaye', 'sermaye', 'devredilenToplamSermaye']],
      ['Devredilen Nama Yazılı Hisse Adedi', ['devredilenNamaYaziliHisseAdedi', 'namaHisseAdedi']],
      ['Devredilen Hamiline Yazılı Hisse Adedi', ['devredilenHamilineYaziliHisseAdedi', 'hamiliHisseAdedi']],
      ['Devredilen İmtiyazlı Hisse Adedi', ['devredilenImtiyazliHisseAdedi', 'imtiyazliHisseAdedi']]
    ]));

    sections.push(itMersisSection('İflas ve Tasfiye Bilgileri', tasfiyeList, [
      ['Mersis No', ['mersisNo']],
      ['Unvan', ['unvan', 'firmaUnvani', 'firmaUnvan']],
      ['Firma Durumu', ['firmaDurumu', 'durum']],
      ['Tescil Tarihi', ['tescilTarihi', 'basTar']]
    ]));

    sections.push(itMersisSection('Sermaye Bilgileri', sermayeList, [
      ['Ortak Mersis No', ['ortakMersisNo']],
      ['Ortak T.C.Kimlik No', ['ortakKimlikNo','ortakTCKimlikNo','ortakTcKimlikNo']],
      ['Ortak Vergi No', ['ortakVergiNo']],
      ['Unvanı', ['ortakUnvan','unvan']],
      ['Nama Yazılı Hisse Adedi', ['namaHisseAdedi']],
      ['Hamiline Yazılı Hisse Adedi', ['hamiliHisseAdedi']],
      ['Ortağın Toplam Sermayesi', ['ortakSermaye']],
      ['Ortağın Toplam Sermayedeki Yüzdesi', ['ortakYuzde']],
      ['Şirketin Toplam Sermayesi', ['sirketSermaye']]
    ]));

    sections.push(itMersisSection('Ortak Bilgileri', ortakList, [
      ['Ortak Mersis No', ['ortakMersisNo']],
      ['Ortak T.C.Kimlik No', ['ortakKimlikNo','tcKimlikNo','ortakTcKimlikNo']],
      ['Ortak Vergi No', ['ortakVergiNo','vergiNo']],
      ['Unvanı', ['ortakUnvan','unvan']],
      ['Uyruk', ['ortakUyruk','uyruk']],
      ['Ortak Niteliği', ['ortaklikTipi','ortakNiteligi']],
      ['Başlangıç Tarihi', ['basTar','baslangicTarihi']],
      ['Bitiş Tarihi', ['bitTar','bitisTarihi']]
    ]));

    sections.push(itMersisSection('Temsilci Bilgileri', temsilList, [
      ['Temsilci Unvanı', ['temsilciUnvan','unvan','adiSoyadi','adSoyad']],
      ['Temsilci Mersis No', ['temsilciMersisNo','mersisNo']],
      ['Temsilci T.C.Kimlik No', ['temsilciTcKimlikNo','tcKimlikNo','tckn','kimlikNo']],
      ['Temsilci Vergi No', ['temsilciVergiNo','vergiNo','vkn']],
      ['Görevi', ['gorevi','gorev','görevi']],
      ['Temsil Yetki Şekli', ['yetkiSekli','temsilSekli','temsilYetkiSekli']],
      ['Başlangıç Tarihi', ['basTar','baslangicTarihi']],
      ['Bitiş Tarihi', ['bitTar','bitisTarihi']]
    ]));

    sections.push(itMersisSection('Adres Bilgileri', adresList, [
      ['Adres No', ['adresNo','adresno']],
      ['Adres', ['adres','adresText']]
    ]));

    sections.push(itMersisSection('Faaliyet Bilgileri', faaliyetList, [
      ['Sıra No', ['sira']],
      ['Faaliyet Kodu', ['faaliyetKodu']],
      ['Faaliyet Adı', ['faaliyetAdi']]
    ]));

    sections.push(itMersisSection('İletişim Bilgileri', iletisimList, [
      ['İletişim Türü', ['iletisimTuru']],
      ['İletişim Bilgisi', ['iletisimBilgisi']]
    ]));

    return `<!doctype html><html><head><meta charset="utf-8"><title>Ticaret Sicili Müdürlüğü Tescil Bilgileri (MERSİS)</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#fff;color:#111;margin:18px;font-size:12px}.page{max-width:980px;margin:0 auto}h1{text-align:center;font-size:18px;margin:8px 0 12px}.meta{display:grid;grid-template-columns:120px 1fr 130px 1fr;gap:0;border:1px solid #aaa}.meta div{border:1px solid #c8c8c8;padding:5px;overflow-wrap:anywhere}.lbl{font-weight:bold;background:#f2f2f2}.sec{margin-top:12px}.sec-title{background:#cfe3f3;border:1px solid #9dbbd0;font-weight:bold;padding:5px}table{border-collapse:collapse;width:100%;font-size:11px;table-layout:auto}th,td{border:1px solid #bbb;padding:5px;vertical-align:top;overflow-wrap:anywhere;word-break:normal}th{background:#e7f1fa;font-weight:bold}.actions{text-align:center;margin:18px}.actions button{font-size:12px;padding:5px 14px}@media print{.actions{display:none}body{margin:8mm}h1{font-size:16px}.sec{break-inside:avoid}table{font-size:10px}}
</style></head><body><div class="page">
<h1>TİCARET SİCİLİ MÜDÜRLÜĞÜ TESCİL BİLGİLERİ (MERSİS)</h1>
${itMersisMeta([['Mersis No:', mersisNo], ['Vergi Kimlik No:', vkn], ['Unvan:', unvan], ['İşlem Türü:', islemTuru], ['Tescil Tarihi:', tescil], ['İş Takip No:', isTakipNo], ['Vergi Dairesi:', vd], ['İşyeri Türü:', isyeri]])}
${sections.filter(Boolean).join('\n')}
<div class="actions"><button onclick="window.print()">Yazdır</button></div>
</div></body></html>`;
  }


  async function itOpenMersisPrintPreview(job, bot) {
    bot.log('MERSİS EVDB Rapor tokeniyle önizleme hazırlanıyor...');
    const info = await itFetchMersisDetailForPreview(job, bot);
    bot.log(`MERSİS detay alındı. MERSISNO=${info.detailPayload.MERSISNO} ISLEMOID=${info.detailPayload.ISLEMOID} ISTAKIPNO=${info.detailPayload.ISTAKIPNO}`);
    const html = itBuildMersisSystemLikeHtml(info, job, bot);
    const w = window.open('', `MERSIS_RAPOR_${Date.now()}`, 'width=1120,height=840,noopener=no');
    if (!w) throw new Error('Popup engellendi. Tarayıcı popup iznini açıp tekrar deneyin.');
    w.document.open(); w.document.write(html); w.document.close();
    try { w.focus(); } catch (_) {}
    bot.log('MERSİS önizleme sistemdeki Yazdır sayfası biçiminde açıldı. Açılan penceredeki Yazdır butonu Chrome yazdırma önizlemesini açar.');
  }



  function itTobbPost(cmd, jp) {
    const token = itResolveGibIntranetToken();
    if (!token) throw new Error('GİB/Portal token bulunamadı');
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', makeCallId());
    p.append('token', token);
    p.append('jp', JSON.stringify(jp || {}));
    return fetch(`${location.origin}/gibintranet_server/dispatch`, {
      method: 'POST',
      body: p,
      credentials: 'include',
      cache: 'no-store'
    }).then(async res => {
      if (!res.ok) throw new Error(`${cmd} ağ hatası: ${res.status}`);
      const txt = await res.text();
      try { return JSON.parse(txt); } catch (_) { throw new Error(`${cmd} cevabı JSON değil`); }
    });
  }

  function itCollectTobbIlanRows(json) {
    const rows = [];
    const seen = new Set();
    const looks = (o) => o && typeof o === 'object' && (
      o.sayi !== undefined || o.sayfa !== undefined || o.yayintarihi !== undefined || o.yayinTarihi !== undefined ||
      o.ilanturadi !== undefined || o.ilanTuru !== undefined || o.sicilno !== undefined || o.sicilNo !== undefined
    );
    const walk = (x) => {
      if (!x || typeof x !== 'object' || seen.has(x)) return;
      seen.add(x);
      if (Array.isArray(x)) { x.forEach(walk); return; }
      if (looks(x)) rows.push(x);
      Object.values(x).forEach(walk);
    };
    walk(json && (json.data || json));
    return rows.filter(r => String(r.sayi ?? r.sayfa ?? r.yayintarihi ?? r.yayinTarihi ?? '').trim() !== '');
  }

  function itFindTicaretSicilNo(job) {
    const direct = itGetJobField(job, ['sicilNo','sicilno','ticaretSicilNo','ticaret_sicil_no','TICARETSICILNO']);
    const d = itCleanDigits(direct);
    return d || '';
  }


  function itIsFirmaForTicaretSicilGazetesi(job, bot) {
    // Ticaret Sicil Gazetesi sorgusu sadece şirket/firma MERSİS kayıtları için gösterilir.
    // Şahıs işe başlama gibi kayıtlarda TCKN bulunur ve MERSİS no yoktur; bu kayıtlarda buton gizlenir.
    const mersisNo = itFindMersisNo(job, bot);
    if (!mersisNo || String(mersisNo).replace(/\D+/g, '').length < 14) return false;
    const tckn = itCleanDigits(itGetJobField(job, ['is_tcKimlikNo','tcKimlikNo','tckn','TCKN','tcNo','tc']));
    if (tckn.length === 11) return false;
    const tur = String((bot && bot.getIsTuruText ? bot.getIsTuruText(job) : '') || job?.is_turu || job?.is_isTuru || '').toLowerCase();
    const belge = String((bot && bot.getBelgeBilgiText ? bot.getBelgeBilgiText(job) : '') || '').toLowerCase();
    if (/işe\s*başlama\s*bildirimi|ise\s*baslama\s*bildirimi/.test(tur + ' ' + belge)) return false;
    return true;
  }

  async function itFetchTicaretSicilGazeteList(job, bot) {
    const mersisNo = itFindMersisNo(job, bot);
    const vkn = itFindVkn(job, bot);
    if (!mersisNo && !vkn) throw new Error('Ticaret Sicil Gazetesi sorgusu için MERSİS No/VKN bulunamadı');
    const jp = mersisNo
      ? { aramaYeri: 'MersisNo', vergiNo: '', mersisNo, baslamaTarihi: '', bitisTarihi: '' }
      : { aramaYeri: 'VergiNo', vergiNo: vkn, mersisNo: '', baslamaTarihi: '', bitisTarihi: '' };
    const json = await itTobbPost('tobbService_ilanListeleriniMersisNoVknGetir', jp);
    if (String(json?.error || '') === '1') throw new Error(collectMessageText(json) || 'Ticaret Sicil Gazetesi liste sorgusu hatası');
    const rows = itCollectTobbIlanRows(json);
    return { query: jp, response: json, rows, mersisNo, vkn };
  }

  function itTobbDate(v) {
    const s = String(v || '').trim();
    const n = s.replace(/\D+/g, '');
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    if (/^\d{2}[./-]\d{2}[./-]\d{4}$/.test(s)) {
      const p = s.split(/[./-]/); return `${p[2]}-${p[1]}-${p[0]}`;
    }
    if (n.length === 8) {
      const y1 = Number(n.slice(0,4));
      if (y1 >= 1900 && y1 <= 2100) return `${n.slice(0,4)}-${n.slice(4,6)}-${n.slice(6,8)}`;
      return `${n.slice(4,8)}-${n.slice(2,4)}-${n.slice(0,2)}`;
    }
    return s;
  }

  function itTobbDisplayDate(v) {
    const iso = itTobbDate(v);
    const m = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (m) return `${m[3]}/${m[2]}/${m[1]}`;
    return String(v || '-');
  }

  function itDecodePdfBase64ToBlobUrl(raw) {
    let b64 = String(raw || '').trim();
    b64 = b64.replace(/^data:application\/pdf;base64,/i, '');
    // v4.31.165: TOBB PDF cevabı bazı ilanlarda satır boşluğu / URL-safe karakter ile gelebiliyor.
    // Chrome PDF görüntüleyici bazı blob'ları açsa da bazılarını boş bırakıyordu; base64 burada normalize edilir.
    b64 = b64.replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4) b64 += '=';
    if (!b64) throw new Error('PDF Base64 sonucu boş geldi');
    const bin = atob(b64);
    if (!bin || bin.length < 10) throw new Error('PDF içeriği boş geldi');
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const sig = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3], bytes[4]);
    if (sig !== '%PDF-') {
      // Bazı cevaplarda JSON içindeki result dolu görünür ama PDF değildir; erken uyarı verelim.
      // Bu durumda kullanıcı yanlış/eksik sayfa-sayı kombinasyonunu hemen görür.
      console.warn('[ISTAKIP-BOT] TOBB PDF imzası beklenenden farklı:', sig);
    }
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    return { blob, url, bytes };
  }

  function itFindPdfResultDeep(json) {
    const seen = new Set();
    const keys = ['result','pdf','base64','file','data','content','icerik','pdfBase64'];
    const looksPdf = (v) => {
      const s = String(v || '').trim();
      return /^data:application\/pdf;base64,/i.test(s) || /^JVBER/i.test(s.replace(/\s+/g, ''));
    };
    const walk = (x) => {
      if (x == null) return '';
      if (typeof x === 'string') return looksPdf(x) ? x : '';
      if (typeof x !== 'object' || seen.has(x)) return '';
      seen.add(x);
      for (const k of keys) {
        if (x[k] != null) {
          const got = walk(x[k]);
          if (got) return got;
        }
      }
      if (Array.isArray(x)) {
        for (const it of x) { const got = walk(it); if (got) return got; }
      } else {
        for (const v of Object.values(x)) { const got = walk(v); if (got) return got; }
      }
      return '';
    };
    return walk(json);
  }

  function itTobbExpandSayfaList(sayfaRaw) {
    const s = String(sayfaRaw || '').trim();
    const nums = (s.match(/\d+/g) || []).map(n => Number(n)).filter(n => Number.isFinite(n));
    if (!nums.length) return [];
    if (/\d+\s*[-–—]\s*\d+/.test(s) && nums.length >= 2) {
      const a = nums[0], b = nums[1];
      const start = Math.min(a, b), end = Math.max(a, b);
      const out = [];
      for (let p = start; p <= end && out.length < 80; p++) out.push(String(p));
      return out;
    }
    return [String(nums[0])];
  }

  async function itFetchTicaretSicilGazetePdfSingle(yayinTarihi, sayi, sayfa) {
    const json = await itTobbPost('tobbService_imzasizPdfGetir', { yayinTarihi, sayi, sayfa });
    if (String(json?.error || '') === '1') throw new Error(collectMessageText(json) || 'Ticaret Sicil Gazetesi PDF sorgusu hatası');
    const result = itFindPdfResultDeep(json);
    const decoded = itDecodePdfBase64ToBlobUrl(result);
    return { url: decoded.url, blob: decoded.blob, bytes: decoded.bytes, response: json, payload: { yayinTarihi, sayi, sayfa } };
  }

  async function itFetchTicaretSicilGazetePdf(row, bot) {
    const yayinTarihi = itTobbDate(row?.yayinTarihi || row?.yayintarihi || row?.tarih || row?.date || '');
    const sayi = String(row?.sayi || row?.gazeteSayi || '').trim();
    const sayfaRaw = String(row?.sayfa || row?.sayfason || row?.sayfaNo || '').trim();
    const sayfalar = itTobbExpandSayfaList(sayfaRaw);
    if (!yayinTarihi || !sayi || !sayfalar.length) throw new Error('PDF için yayın tarihi/sayı/sayfa eksik');
    // Orijinal sistem, 81-85 / 178-183 gibi sayfa aralıklarında her sayfa için ayrı
    // tobbService_imzasizPdfGetir çağrısı atıyor. HAR'da görülen akışla aynı davranış:
    // sayfa aralığını tek payload olarak yollama; 81,82,83... diye tek tek al.
    const pages = [];
    for (const sf of sayfalar) {
      if (bot && bot.log && sayfalar.length > 1) bot.log(`TOBB PDF sayfası alınıyor: sayı=${sayi} sayfa=${sf}/${sayfalar[sayfalar.length - 1]}`);
      pages.push(await itFetchTicaretSicilGazetePdfSingle(yayinTarihi, sayi, sf));
    }
    const first = pages[0];
    return {
      url: first.url,
      blob: first.blob,
      bytes: first.bytes,
      response: first.response,
      pages,
      payload: { yayinTarihi, sayi, sayfa: sayfaRaw || first.payload.sayfa, sayfalar }
    };
  }

  function itBuildPdfViewerHtml(url, titleText, payload) {
    const title = titleText || 'Tobb Sicil Gazetesi PDF';
    const p = payload || {};
    return `<!doctype html><html><head><meta charset="utf-8"><title>${itHtmlEscape(title)}</title>
<style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#525659;font-family:Arial,Helvetica,sans-serif}.bar{height:30px;background:#333;color:#fff;font-size:12px;display:flex;align-items:center;gap:10px;padding:0 10px;box-sizing:border-box}.bar button{font-size:12px}.viewer{width:100%;height:calc(100% - 30px);border:0;background:#525659}embed,iframe{width:100%;height:100%;border:0;background:#525659}</style>
</head><body><div class="bar"><b>${itHtmlEscape(title)}</b><span>Sayı ${itHtmlEscape(p.sayi || '-')} Sayfa ${itHtmlEscape(p.sayfa || '-')}</span><button onclick="try{window.print()}catch(e){}">Yazdır</button><button onclick="try{location.href='${itHtmlEscape(url)}'}catch(e){}">PDF'yi direkt aç</button></div><div class="viewer"><embed src="${itHtmlEscape(url)}" type="application/pdf"></div></body></html>`;
  }


  function itBuildMultiPdfViewerHtml(pdf, titleText) {
    const title = titleText || 'Tobb Sicil Gazetesi PDF';
    const p = pdf?.payload || {};
    const pages = Array.isArray(pdf?.pages) && pdf.pages.length ? pdf.pages : [pdf];
    const pageLinks = pages.map((pg, i) => {
      const sf = pg?.payload?.sayfa || (p.sayfalar && p.sayfalar[i]) || (i + 1);
      return `<a href="#pg${i}" style="color:#fff;text-decoration:none;border:1px solid #777;padding:2px 6px;border-radius:3px">Sayfa ${itHtmlEscape(sf)}</a>`;
    }).join(' ');
    const embeds = pages.map((pg, i) => {
      const sf = pg?.payload?.sayfa || (p.sayfalar && p.sayfalar[i]) || (i + 1);
      return `<section id="pg${i}" class="pdfpage"><div class="pgbar">Sayfa ${itHtmlEscape(sf)}</div><embed src="${itHtmlEscape(pg.url)}" type="application/pdf"></section>`;
    }).join('');
    return `<!doctype html><html><head><meta charset="utf-8"><title>${itHtmlEscape(title)}</title>
<style>
html,body{margin:0;width:100%;height:100%;background:#525659;font-family:Arial,Helvetica,sans-serif;color:#fff}
.bar{position:sticky;top:0;z-index:5;min-height:34px;background:#333;color:#fff;font-size:12px;display:flex;align-items:center;gap:10px;padding:5px 10px;box-sizing:border-box;flex-wrap:wrap}
.bar button{font-size:12px}.pages{display:flex;gap:4px;flex-wrap:wrap}.pdfpage{height:calc(100vh - 42px);min-height:650px;margin:10px auto 20px;max-width:1100px;background:#444;border:1px solid #333}.pgbar{height:24px;line-height:24px;text-align:center;background:#3b3b3b;font-size:12px}embed,iframe{display:block;width:100%;height:calc(100% - 24px);border:0;background:#525659}
@media print{.bar,.pgbar{display:none}.pdfpage{height:100vh;margin:0;border:0;page-break-after:always}}
</style></head><body>
<div class="bar"><b>${itHtmlEscape(title)}</b><span>Sayı ${itHtmlEscape(p.sayi || '-')} Sayfa ${itHtmlEscape(p.sayfa || '-')}</span><button onclick="try{window.print()}catch(e){}">Yazdır</button><button onclick="try{location.href='${itHtmlEscape(pages[0]?.url || pdf.url)}'}catch(e){}">İlk PDF'yi direkt aç</button><span class="pages">${pageLinks}</span></div>
${embeds}</body></html>`;
  }

  function itOpenPdfBlobLikeSystem(pdf, titleText) {
    // v4.31.165: Orijinal sistem PDF'yi Chrome PDF viewer içinde blob URL ile gösteriyor.
    // v4.31.167: Sayfa aralıklı ilanlarda HAR'daki gibi sayfalar tek tek alınır ve tek popup içinde
    // çok sayfalı görünüm olarak gösterilir; örn. 81-85 => 81,82,83,84,85 sayfaları alt alta ayrı bölümler halinde açılır.
    const title = titleText || 'Tobb Sicil Gazetesi PDF';
    let w = null;
    try {
      const multi = Array.isArray(pdf?.pages) && pdf.pages.length > 1;
      w = openItHtmlPopup(title, multi ? itBuildMultiPdfViewerHtml(pdf, title) : itBuildPdfViewerHtml(pdf.url, title, pdf.payload));
    } catch (_) { w = null; }
    if (w) {
      try { w.focus(); } catch (_) {}
      return w;
    }
    try { return openItPreviewPopupWindow(pdf.url, title) || window.open(pdf.url, '_blank'); } catch (_) { return null; }
  }

  function itBuildTicaretSicilGazeteHtml(info) {
    const rows = info?.rows || [];
    const q = info?.query || {};
    const rowHtml = rows.map((r, i) => {
      const tsm = r.tsmadi || r.ticaretSicilMudurlugu || r.tsm || '';
      const sicilNo = r.sicilno || r.sicilNo || r.ticaretSicilNo || '';
      const vergiNo = r.vergino || r.vergiNo || '';
      const mersisNo = r.mersisno || r.mersisNo || r.MERSISNO || '';
      const unvan = r.unvan || r.unvani || '';
      const yayin = itTobbDisplayDate(r.yayinTarihi || r.yayintarihi || r.tarih || r.date || '');
      const sayi = r.sayi || '';
      const sayfa = r.sayfa || r.sayfason || '';
      const ilan = r.ilanturadi || r.ilanTuru || r.ilanturu || '';
      // v4.31.169: Sayfa alanı 1556-1557 gibi aralık ise tek PDF butonu yerine
      // 1556 ve 1557 için ayrı ayrı buton göster. Her buton kendi sayfasını açar.
      const sayfaButonlari = itTobbExpandSayfaList(sayfa);
      const pdfButtons = sayfaButonlari.length > 1
        ? sayfaButonlari.map(sf => `<button class="pdfbtn" data-pdf-index="${i}" data-pdf-page="${itHtmlEscape(sf)}" title="${itHtmlEscape(sf)}. sayfayı aç">${itHtmlEscape(sf)}</button>`).join(' ')
        : `<button class="pdfbtn" data-pdf-index="${i}" title="PDF aç">PDF</button>`;
      return `<tr>
        <td>${i + 1}</td><td>${itHtmlEscape(tsm)}</td><td>${itHtmlEscape(sicilNo)}</td><td>${itHtmlEscape(vergiNo)}</td>
        <td>${itHtmlEscape(mersisNo)}</td><td>${itHtmlEscape(unvan)}</td><td>${itHtmlEscape(yayin)}</td>
        <td>${itHtmlEscape(sayi)}</td><td>${itHtmlEscape(sayfa)}</td><td>${itHtmlEscape(ilan)}</td>
        <td class="pdfcell">${pdfButtons}</td></tr>`;
    }).join('');
    return `<!doctype html><html><head><meta charset="utf-8"><title>Ticaret Sicili Gazetesi İlan Görüntüleme</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f5f5f5;color:#222;margin:0;font-size:12px}.wrap{padding:14px}.title{text-align:center;color:#8b1f2d;font-weight:bold;font-size:16px;margin:18px 0 22px}.tabs{display:flex;gap:6px;margin-bottom:8px}.tab{padding:8px 12px;border:1px solid #c8c8c8;background:#fff;border-radius:3px}.tab.active{background:#b73a45;color:#fff;border-color:#b73a45}.query{margin:8px 0 14px;color:#333}.tablewrap{border:1px solid #cdd3db;background:white;overflow:auto}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #cdd3db;padding:7px 8px;vertical-align:top}th{background:#d9e6f2;text-align:center}.pdfbtn{padding:5px 9px;border:1px solid #777;background:#f7f7f7;cursor:pointer;border-radius:3px;margin:2px}.pdfcell{white-space:nowrap}.pdfbtn:hover{background:#e4eef9}.msg{padding:12px;background:#fff;border:1px solid #ddd}.muted{color:#666}.actions{margin:10px 0;display:flex;gap:8px}.btn{padding:6px 12px;border:1px solid #888;background:#eee;border-radius:3px;cursor:pointer}
</style></head><body><div class="wrap">
<div class="tabs"><div class="tab">Sorgu</div><div class="tab active">MERSİS Numarası ile Sorgulama</div></div>
<div class="title">TOBB-Türkiye Ticaret Sicili Gazetesi İlan Görüntüleme</div>
<div class="query"><b>Sorgu:</b> ${itHtmlEscape(q.aramaYeri || '-')} &nbsp; <b>Mersis No:</b> ${itHtmlEscape(q.mersisNo || '-')} &nbsp; <b>Vergi No:</b> ${itHtmlEscape(q.vergiNo || '-')}</div>
<div class="actions"><button class="btn" data-print="1">Yazdır</button></div>
<div class="tablewrap"><table><thead><tr><th></th><th>TİCARET SİCİLİ MÜDÜRLÜĞÜ</th><th>TİCARET SİCİL NO</th><th>VERGİ NO</th><th>MERSİS NO</th><th>UNVAN</th><th>YAYIN TARİHİ</th><th>SAYI</th><th>SAYFA</th><th>İLAN TÜRÜ</th><th>PDF</th></tr></thead><tbody>${rowHtml || '<tr><td colspan="11">Kayıt bulunamadı.</td></tr>'}</tbody></table></div>
</div></body></html>`;
  }

  function itAttachTicaretSicilGazeteHandlers(popup, info, bot) {
    const doc = popup && popup.document;
    if (!doc) return;
    doc.querySelector('[data-print="1"]')?.addEventListener('click', () => popup.print());
    doc.querySelectorAll('[data-pdf-index]').forEach(btn => {
      btn.addEventListener('click', async (ev) => {
        ev.preventDefault();
        const idx = Number(btn.getAttribute('data-pdf-index'));
        const row = (info?.rows || [])[idx] || {};
        const pageOverride = String(btn.getAttribute('data-pdf-page') || '').trim();
        const old = btn.textContent;
        btn.textContent = 'Açılıyor...';
        btn.disabled = true;
        try {
          const rowForPdf = pageOverride ? { ...row, sayfa: pageOverride, sayfason: pageOverride, sayfaNo: pageOverride } : row;
          if (bot && bot.log) bot.log(`Ticaret Sicil Gazetesi PDF alınıyor. yayın=${itTobbDisplayDate(row.yayinTarihi || row.yayintarihi || row.tarih || row.date || '')} sayı=${row.sayi || '-'} sayfa=${pageOverride || row.sayfa || '-'}`);
          const pdf = await itFetchTicaretSicilGazetePdf(rowForPdf, bot);
          const w = itOpenPdfBlobLikeSystem(pdf, `Tobb Sicil Gazetesi Sayı ${pdf.payload?.sayi || ''} Sayfa ${pdf.payload?.sayfa || ''}`);
          if (!w) window.open(pdf.url, '_blank');
        } catch (e) {
          alert(`PDF açılamadı: ${e?.message || String(e)}`);
          if (bot && bot.log) bot.log(`Ticaret Sicil Gazetesi PDF açılamadı: ${e?.message || String(e)}`, true);
        } finally {
          btn.textContent = old;
          btn.disabled = false;
        }
      });
    });
  }

  async function itOpenTicaretSicilGazetesi(job, bot) {
    const popup = itOpenHtmlPopup('Ticaret Sicil Gazetesi', itBuildLoadingHtml('Ticaret Sicil Gazetesi', 'Ticaret Sicil Gazetesi ilanları sorgulanıyor...'));
    if (!popup) throw new Error('Popup engellendi. Tarayıcı popup iznini açıp tekrar deneyin.');
    try {
      const info = await itFetchTicaretSicilGazeteList(job, bot);
      if (bot && bot.log) bot.log(`Ticaret Sicil Gazetesi listesi alındı. MERSIS=${info.mersisNo || '-'} VKN=${info.vkn || '-'} kayıt=${info.rows.length}`);
      const html = itBuildTicaretSicilGazeteHtml(info);
      popup.document.open(); popup.document.write(html); popup.document.close();
      itAttachTicaretSicilGazeteHandlers(popup, info, bot);
      try { popup.focus(); } catch (_) {}
    } catch (e) {
      try { popup.document.open(); popup.document.write(itBuildErrorHtml('Ticaret Sicil Gazetesi Açılamadı', e?.message || String(e))); popup.document.close(); } catch (_) {}
      if (bot && bot.log) bot.log(`Ticaret Sicil Gazetesi açılamadı: ${e?.message || String(e)}`, true);
    }
  }


  // v4.31.174: İşleri Tara > Önizle bölümünde şirketler için ortaklık/yöneticilik ek sorguları.
  function itGibIntranetPost(cmd, jp) {
    const token = itResolveGibIntranetToken();
    if (!token) throw new Error('GİB/Portal token bulunamadı');
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', makeCallId());
    p.append('token', token);
    p.append('jp', JSON.stringify(jp || {}));
    return fetch(`${location.origin}/gibintranet_server/dispatch`, {
      method: 'POST', body: p, credentials: 'include', cache: 'no-store'
    }).then(async res => {
      if (!res.ok) throw new Error(`${cmd} ağ hatası: ${res.status}`);
      const txt = await res.text();
      try { return JSON.parse(txt); } catch (_) { throw new Error(`${cmd} cevabı JSON değil`); }
    });
  }

  function itCompanyVknMersisFromJob(job) {
    const vkn = String(job?.is_vergiNo || job?.is_sicil_vergiNo || job?.vergiNo || '').replace(/\D+/g, '').slice(0, 10);
    const tckn = String(job?.is_tcKimlikNo || job?.tckn || job?.tcKimlikNo || '').replace(/\D+/g, '').slice(0, 11);
    const mersis = String(job?.is_sicil_mersisNo || job?.is_mersisNo || job?.mersisNo || job?.MERSISNO || '').replace(/\D+/g, '');
    const unvan = String(job?.is_unvan || job?.is_unvan_unvan || '').trim();
    return { vkn, tckn, mersis, unvan };
  }

  function itIsCompanyForOrtakYon(job, bot) {
    const q = itCompanyVknMersisFromJob(job);
    if (!q.vkn || q.tckn) return false;
    if (q.mersis) return true;
    try { return itIsFirmaForTicaretSicilGazetesi(job, bot); } catch (_) { return false; }
  }

  function itFmtAnyDate(v, sep='.') {
    const raw = String(v ?? '').trim();
    if (!raw) return '-';
    if (/^\d{2}[./-]\d{2}[./-]\d{4}$/.test(raw)) return raw.replace(/[/-]/g, sep);
    if (/^\d{4}[./-]\d{2}[./-]\d{2}$/.test(raw)) return `${raw.slice(8,10)}${sep}${raw.slice(5,7)}${sep}${raw.slice(0,4)}`;
    const x = raw.replace(/\D+/g, '');
    if (x.length >= 8) {
      const a = Number(x.slice(0,4));
      const b = Number(x.slice(4,8));
      if (a >= 1900 && a <= 2100) return `${x.slice(6,8)}${sep}${x.slice(4,6)}${sep}${x.slice(0,4)}`;
      if (b >= 1900 && b <= 2100) return `${x.slice(0,2)}${sep}${x.slice(2,4)}${sep}${x.slice(4,8)}`;
    }
    return raw || '-';
  }

  function itText(v) {
    const s = String(v ?? '').trim();
    return s || '-';
  }

  function itTable(rows, headers, mapFn, empty='Kayıt bulunamadı.') {
    const body = (Array.isArray(rows) ? rows : []).map((r, i) => `<tr><td>${i + 1}</td>${mapFn(r).map(v => `<td>${itHtmlEscape(itText(v))}</td>`).join('')}</tr>`).join('');
    return `<div class="tablewrap"><table><thead><tr><th></th>${headers.map(h => `<th>${itHtmlEscape(h)}</th>`).join('')}</tr></thead><tbody>${body || `<tr><td colspan="${headers.length + 1}">${itHtmlEscape(empty)}</td></tr>`}</tbody></table></div>`;
  }

  function itOrtakYonBaseHtml(title, inner) {
    return `<!doctype html><html><head><meta charset="utf-8"><title>${itHtmlEscape(title)}</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f6f6f8;color:#111;margin:0;font-size:12px}.wrap{padding:18px}.title{text-align:center;font-weight:bold;margin:16px 0 20px}.top{max-width:980px;margin:0 auto 18px;border:1px solid #bbb;background:#fff}.top td{padding:7px 10px}.top .k{font-weight:bold;background:#f7f7f7;width:150px}.sub{text-align:center;font-weight:bold;margin:22px 0 8px}.tablewrap{max-width:1160px;margin:8px auto 16px;overflow:auto}table{border-collapse:collapse;width:100%;font-size:11px;background:#fff}th,td{border:1px solid #999;padding:5px 6px;vertical-align:top;text-align:left}th{background:#e9eef5;text-align:center}.actions{max-width:1160px;margin:0 auto 10px;display:flex;gap:8px}.btn{padding:6px 14px;border:1px solid #888;background:#eee;border-radius:3px;cursor:pointer}.muted{color:#666}@media print{.actions{display:none}body{background:#fff}.wrap{padding:0}.top,.tablewrap{max-width:none}}
</style></head><body><div class="wrap"><div class="actions"><button class="btn" onclick="window.print()">Yazdır</button></div><div class="title">${itHtmlEscape(title)}</div>${inner}</div></body></html>`;
  }

  async function itFetchOrtakYonAktif(job) {
    const q = itCompanyVknMersisFromJob(job);
    if (!q.vkn) throw new Error('Ortak/yönetici sorgusu için VKN bulunamadı');
    const json = await itGibIntranetPost('sicilService_sirOrtYonMersisSorgulama', { vkn: q.vkn, tckn: '' });
    if (String(json?.error || '') === '1') throw new Error(collectMessageText(json) || 'Ortak/yönetici aktif kayıtlar sorgusu hatası');
    return { query: q, response: json, data: json?.data || {} };
  }

  function itBuildOrtakYonAktifHtml(info) {
    const data = info?.data || {};
    const gib = data.gib || {};
    const mersis = data.mersis || {};
    const titleInfo = mersis.mersisTitleInfo || {};
    const title = 'GİB ve MERSİS ORTAK/YÖNETİCİ GÖRÜNTÜLEME / AKTİF KAYITLAR';
    const top = `<table class="top"><tr><td class="k">VERGİ NO:</td><td>${itHtmlEscape(itText(gib.vergino || info?.query?.vkn))}</td><td class="k">ÜNVAN:</td><td>${itHtmlEscape(itText(gib.kimlikunvan || gib.unvan || titleInfo.unvan || info?.query?.unvan))}</td></tr><tr><td class="k">MERSİS NO:</td><td>${itHtmlEscape(itText(gib.mersisno || titleInfo.mersisNo || info?.query?.mersis))}</td><td class="k">KURULUŞ TARİHİ:</td><td>${itHtmlEscape(itFmtAnyDate(gib.tesciltarihi || gib.tsmtesciltarihi || gib.dogumtarihi))}</td></tr><tr><td class="k">KURULUŞ YERİ:</td><td>${itHtmlEscape([gib.dogumyeri, gib.dogumyeritext].filter(Boolean).join(' - ') || '-')}</td><td class="k">TERK TARİHİ:</td><td>${itHtmlEscape(itFmtAnyDate(gib.isibirakmatarihi))}</td></tr></table>`;
    const gibOrtak = itTable(gib.tuzelortak || [], ['VERGİ NO','T.C. KİMLİK NO','AD SOYAD/ÜNVAN','HİSSE','GİRİŞ TARİHİ','ÇIKIŞ TARİHİ'], r => [r.ortvergino, r.tckimlikno, r.adsoyad, r.orthisse, itFmtAnyDate(r.ortgiristar), itFmtAnyDate(r.ortcikistar)]);
    const gibYon = itTable(gib.tuzelyonetici || [], ['VERGİ NO','T.C. KİMLİK NO','AD SOYAD/ÜNVAN','YÖNETİCİ TÜR','YÖNETİCİ GİRİŞ TARİHİ','YÖNETİCİ ÇIKIŞ TARİHİ'], r => [r.yonvergino, r.tckimlikno, r.adsoyad, r.yontur, itFmtAnyDate(r.yongiristar), itFmtAnyDate(r.yoncikistar)]);
    const mersisTop = `<table class="top"><tr><td class="k">MERSİS NO:</td><td>${itHtmlEscape(itText(titleInfo.mersisNo || gib.mersisno || info?.query?.mersis))}</td><td class="k">AD SOYAD/ÜNVAN:</td><td>${itHtmlEscape(itText(titleInfo.unvan || gib.kimlikunvan || gib.unvan))}</td></tr></table>`;
    const mersisOrtak = itTable(mersis.ortak || [], ['VERGİ NO','T.C. KİMLİK NO','AD SOYAD/ÜNVAN','HİSSE','ORTAK SERMAYE MİKTARI'], r => [r.ortvergino, r.tckimlikno, r.adsoyad, r.orthisse, r.ortsermayemiktar]);
    const mersisYon = itTable(mersis.yonetici || [], ['VERGİ NO','T.C. KİMLİK NO','MERSİS NO','AD SOYAD/ÜNVAN','GÖREVİ','TEMSİL TÜRÜ','YETKİ SÜRESİ','YÖNETİCİ GİRİŞ TARİHİ','YÖNETİCİ ÇIKIŞ TARİHİ','DURUMU','ADINA HAREKET EDEN'], r => [r.yonvergino || r.yonvkn, r.yontckimlikno, r.mersis, r.yonadsoyad || r.yonad, r.yongorev, r.yontemsiltur, r.yonyetkisure, itFmtAnyDate(r.yongiristar), itFmtAnyDate(r.yoncikistar), r.yondurum, [r.yonadinhareketedenkisi, r.yonadinhareketedenkisitckimlikno].filter(Boolean).join(' / ')]);
    return itOrtakYonBaseHtml(title, `${top}<div class="sub">GİB SİCİL KAYITLARINA GÖRE</div><div class="sub">TÜZEL ORTAKLIK BİLGİLERİ</div>${gibOrtak}<div class="sub">TÜZEL YÖNETİCİ BİLGİLERİ</div>${gibYon}<div class="sub">MERSİS SİCİL KAYITLARINA GÖRE</div>${mersisTop}<div class="sub">TÜZEL ORTAKLIK BİLGİLERİ</div>${mersisOrtak}<div class="sub">TÜZEL YÖNETİCİ BİLGİLERİ</div>${mersisYon}`);
  }

  async function itFetchOrtakYonMersisDetay(job) {
    const aktif = await itFetchOrtakYonAktif(job);
    const gib = aktif.data?.gib || {};
    const mersis = aktif.data?.mersis || {};
    const mersisno = gib.mersisno || mersis?.mersisTitleInfo?.mersisNo || aktif.query.mersis;
    const sirketturu = String(gib.sirketturu || '').trim();
    if (!mersisno) throw new Error('MERSİS ortak/yönetici detay sorgusu için MERSİS No bulunamadı');
    const json = await itGibIntranetPost('sicilService_tuzelKisiOrtaklikDetayBilgisiSorgula', { mersisno, sirketturu });
    if (String(json?.error || '') === '1') throw new Error(collectMessageText(json) || 'MERSİS ortaklık/yöneticilik detay sorgusu hatası');
    return { query: { ...aktif.query, mersisno, sirketturu, unvan: gib.kimlikunvan || gib.unvan || aktif.query.unvan }, response: json, data: json?.data || {} };
  }

  function itBuildOrtakYonMersisDetayHtml(info) {
    const d = info?.data || {}; const q = info?.query || {};
    const title = 'TÜZEL KİŞİ YÖNETİCİ / ORTAKLIK BİLGİLERİ (MERSİS)';
    const top = `<table class="top"><tr><td class="k">RAPOR TARİHİ:</td><td>${itHtmlEscape(itText(d.raportarih))}</td><td class="k">RAPOR ZAMANI:</td><td>${itHtmlEscape(itText(d.raporzaman))}</td></tr><tr><td class="k">VERGİ KİMLİK NO:</td><td>${itHtmlEscape(itText(q.vkn))}</td><td class="k">ÜNVAN:</td><td>${itHtmlEscape(itText(q.unvan))}</td></tr><tr><td class="k">KURULUŞ TARİHİ:</td><td>${itHtmlEscape('-')}</td><td class="k">KURULUŞ YERİ:</td><td>${itHtmlEscape('-')}</td></tr></table>`;
    const temsilci = itTable(d.temsilci || [], ['VERGİ NO','T.C. KİMLİK NO','MERSİS NO','YÖNETİCİ ADI SOYADI/ÜNVANI','GÖREVİ','YETKİ SÜRESİ','GİRİŞ TARİHİ','ÇIKIŞ TARİHİ','DURUMU','ADINA HAREKET EDEN'], r => [r.tvergino || r.tvergiNo, r.ttckimlikno, r.tmersisno, r.tadisoyadi, r.tgorevi, r.tyetkisuresiyil, itFmtAnyDate(r.tbaslangictarihi), itFmtAnyDate(r.tbitistarihi), r.taktifpasif, [r.tadinahareketedenkisi, r.tadinahareketedenkisitckimlikno].filter(Boolean).join(' / ')]);
    const ortak = itTable(d.ortak || d.ortaklik || [], ['VERGİ KİMLİK NO','T.C. KİMLİK NO','MERSİS NO','ADI SOYADI / ÜNVAN','BAŞLANGIÇ TARİHİ','BİTİŞ TARİHİ','DURUM'], r => [r.oVergino || r.vergino || r.vergiNo, r.otckimlikno || r.tckimlikno, r.omersisno || r.mersisno, r.oadisoyadi || r.adsoyad || r.unvan, itFmtAnyDate(r.obaslangictarihi || r.baslangictarihi), itFmtAnyDate(r.obitistarihi || r.bitistarihi), r.odurum || r.durum]);
    const sermaye = itTable(d.sermaye || [], ['T.C. KİMLİK NO','VERGİ NO','ADI SOYADI/ÜNVAN','SERMAYE','SERMAYE ORANI(%)'], r => [r.stckimlikno, r.svergino, r.sadisoyadi, r.sortagintoplamsermayesi, r.sortagintoplamsermayedekiyuzdesi]);
    return itOrtakYonBaseHtml(title, `${top}<div class="sub">YÖNETİCİLİK</div>${temsilci}<div class="sub">ORTAKLIK</div>${ortak}<div class="sub">SERMAYE</div>${sermaye}`);
  }

  async function itFetchOrtakYonTarihce(job) {
    const q = itCompanyVknMersisFromJob(job);
    if (!q.vkn) throw new Error('Kuruluşundan itibaren ortak/yönetici sorgusu için VKN bulunamadı');
    const now = new Date();
    const bitTar = `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}`;
    const json = await itGibIntranetPost('sicilService_sirOrtYonTarihSorgulama', { vkn: q.vkn, tckn: '', basTar: '19800101', bitTar });
    if (String(json?.error || '') === '1') throw new Error(collectMessageText(json) || 'Sicil kayıtlarına göre ortaklık/yöneticilik sorgusu hatası');
    return { query: { ...q, basTar: '19800101', bitTar }, response: json, data: json?.data || {} };
  }

  function itBuildOrtakYonTarihceHtml(info) {
    const d = info?.data || {}; const q = info?.query || {};
    const title = 'SİCİL KAYITLARINA GÖRE ORTAKLIK / YÖNETİCİLİK BİLGİLERİ';
    const top = `<table class="top"><tr><td class="k">VERGİ NO:</td><td>${itHtmlEscape(itText(d.vergino || q.vkn))}</td><td class="k">ÜNVAN:</td><td>${itHtmlEscape(itText(d.kimlikunvan || q.unvan))}</td></tr><tr><td class="k">KURULUŞ TARİHİ:</td><td>${itHtmlEscape(itFmtAnyDate(d.tesciltarihi || d.dogumtarihi))}</td><td class="k">KURULUŞ YERİ:</td><td>${itHtmlEscape([d.dogumyeri, d.dogumyeritext].filter(Boolean).join(' - ') || '-')}</td></tr><tr><td class="k">SORGULAMA BAŞLANGIÇ TARİHİ:</td><td>${itHtmlEscape(itFmtAnyDate(q.basTar))}</td><td class="k">SORGULAMA BİTİŞ TARİHİ:</td><td>${itHtmlEscape(itFmtAnyDate(q.bitTar))}</td></tr></table>`;
    const ortak = itTable(d.tuzelortak || [], ['VERGİ NO','T.C. KİMLİK NO','AD SOYAD/ÜNVAN','HİSSE','GİRİŞ TARİHİ','ÇIKIŞ TARİHİ'], r => [r.ortvergino, r.tckimlikno, r.adsoyad, r.orthisse, itFmtAnyDate(r.ortgiristar), itFmtAnyDate(r.ortcikistar)]);
    const yon = itTable(d.tuzelyonetici || [], ['VERGİ NO','T.C. KİMLİK NO','AD SOYAD/ÜNVAN','YÖNETİCİ TÜR','YÖNETİCİ GİRİŞ TARİHİ','YÖNETİCİ ÇIKIŞ TARİHİ'], r => [r.yonvergino, r.tckimlikno, r.adsoyad, r.yontur, itFmtAnyDate(r.yongiristar), itFmtAnyDate(r.yoncikistar)]);
    return itOrtakYonBaseHtml(title, `${top}<div class="sub">TÜZEL ORTAKLIK BİLGİLERİ</div>${ortak}<div class="sub">TÜZEL YÖNETİCİ BİLGİLERİ</div>${yon}`);
  }

  async function itOpenOrtakYonPopup(kind, job, bot) {
    const titleMap = {
      aktif: 'GİB/MERSİS Ortak Yönetici Aktif Kayıtlar',
      mersisDetay: 'MERSİS Ortaklık Yöneticilik Sermaye',
      tarihce: 'Sicil Kayıtlarına Göre Ortaklık Yöneticilik'
    };
    const popup = itOpenHtmlPopup(titleMap[kind] || 'Ortaklık/Yöneticilik', itBuildLoadingHtml(titleMap[kind] || 'Ortaklık/Yöneticilik', 'Sorgu çalıştırılıyor...'));
    if (!popup) throw new Error('Popup engellendi. Tarayıcı popup iznini açıp tekrar deneyin.');
    try {
      let html = '';
      if (kind === 'aktif') html = itBuildOrtakYonAktifHtml(await itFetchOrtakYonAktif(job));
      else if (kind === 'mersisDetay') html = itBuildOrtakYonMersisDetayHtml(await itFetchOrtakYonMersisDetay(job));
      else if (kind === 'tarihce') html = itBuildOrtakYonTarihceHtml(await itFetchOrtakYonTarihce(job));
      else throw new Error('Bilinmeyen ortak/yönetici ekranı');
      popup.document.open(); popup.document.write(html); popup.document.close();
      try { popup.focus(); } catch (_) {}
    } catch (e) {
      try { popup.document.open(); popup.document.write(itBuildErrorHtml('Ortaklık/Yöneticilik Açılamadı', e?.message || String(e))); popup.document.close(); } catch (_) {}
      if (bot && bot.log) bot.log(`Ortaklık/Yöneticilik açılamadı: ${e?.message || String(e)}`, true);
    }
  }


  const IT_JOB_COLUMNS = [
    { key: 'no', label: '#', width: 34, min: 30 },
    { key: 'islem', label: 'İşlem', width: 62, min: 46 },
    { key: 'istakip', label: 'İşTakip', width: 150, min: 80, sort: 'istakip' },
    { key: 'belge', label: 'Belge Bilgi', width: 142, min: 80, sort: 'belge' },
    { key: 'tur', label: 'İşin Türü', width: 150, min: 80, sort: 'tur' },
    { key: 'unvan', label: 'Ünvan', width: 210, min: 120, sort: 'unvan' },
    { key: 'durum', label: 'Durum', width: 120, min: 70, sort: 'durum' },
    { key: 'owner', label: 'Üzerindeki Kullanıcı', width: 150, min: 90, sort: 'owner' },
    { key: 'islemBilgisi', label: 'İşlem Bilgisi', width: 142, min: 55, sort: 'islemBilgisi' },
    { key: 'isAcilis', label: 'İş Açılış Zamanı', width: 118, min: 90, sort: 'isAcilis' },
    { key: 'beklenenBitis', label: 'Beklenen İş Bitiş Zamanı', width: 125, min: 95, sort: 'beklenenBitis' },
    { key: 'uzerimdeSure', label: 'Üzerimde Kaldığı Süre', width: 115, min: 95, sort: 'uzerimdeSure' },
    { key: 'onizle', label: 'Önizle', width: 88, min: 70 },
    { key: 'ykDurum', label: 'Yoklama Durum', width: 150, min: 90, sort: 'ykDurum' },
    { key: 'ykKod', label: 'Yoklama Kodu', width: 190, min: 110, sort: 'ykKod' }
  ];
  const IT_COL_WIDTH_KEY = 'istakip_bot_job_col_widths_v4';

  function readJobColumnWidths() {
    try {
      const raw = localStorage.getItem(IT_COL_WIDTH_KEY);
      const parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (_) { return {}; }
  }

  function saveJobColumnWidth(key, width) {
    try {
      const data = readJobColumnWidths();
      data[key] = Math.max(30, Math.round(Number(width) || 0));
      localStorage.setItem(IT_COL_WIDTH_KEY, JSON.stringify(data));
    } catch (_) {}
  }

  function resetJobColumnWidths() {
    try { localStorage.removeItem(IT_COL_WIDTH_KEY); } catch (_) {}
  }

  const IT_DETAIL_TURU_FALLBACK_MAP = {
    // İş Takip bazı kullanıcı/bölüm listelerinde txtIsTuru boş geliyor; gerçek ekrandaki iş türü is_detayId ile anlaşılır.
    238: 'MERSIS_Merkez Açılış',
    277: 'İşe Başlama',
    402: 'MERSIS_Merkez Kapanış',
    403: 'MERSIS_Unvan Değişikliği',
    404: 'MERSIS_Merkez Adres Değişikliği',
    405: 'MERSIS_Merkez Adres Değişikliği Nedeniyle Nakil İşe Başlama',
    406: 'MERSIS_Ortaklık ve Pay Değişikliği',
    407: 'MERSIS_Temsilci Değişikliği (Sorumlu ve/veya yöneticilik değişikliği)',
    408: 'MERSIS_Şube Açılış',
    410: 'MERSIS_Birleşme/Bölünme Bilgileri',
    412: 'MERSIS_Tasfiye/Kapanış İşlemi',
    418: 'MERSIS_Merkez Adres Değişikliği',
    1371: 'Muhtasar Dönem Değişikliği Bildirimi'
  };

  function itLooksLikeBelgeInfoText(v) {
    const t = String(v || '').trim();
    if (!t || t === '-') return false;
    const low = t.toLocaleLowerCase('tr-TR');
    if (low.includes('vergi no') && low.includes('mersis no')) return true;
    if (/^\d{10,}\s*\/\s*\d{10,}/.test(t)) return true;
    if (/^\d{10,20}$/.test(t)) return true;
    return false;
  }

  function itNormalizeMersisIslemTuruLabel(v) {
    const raw = String(v || '').replace(/\s+/g, ' ').trim();
    if (!raw) return '';
    const low = raw.toLocaleLowerCase('tr-TR');
    if (low.includes('merkez') && (low.includes('açılış') || low.includes('acilis') || low.includes('acılış'))) return 'MERSIS_Merkez Açılış';
    if ((low.includes('ünvan') || low.includes('unvan')) && (low.includes('değiş') || low.includes('degis'))) return 'MERSIS_Unvan Değişikliği';
    if (low.includes('ortak') || low.includes('pay') || low.includes('hisse')) return 'MERSIS_Ortaklık ve Pay Değişikliği';
    if (low.includes('temsilci') || low.includes('sorumlu') || low.includes('yönetici') || low.includes('yonetici')) return 'MERSIS_Temsilci Değişikliği (Sorumlu ve/veya yöneticilik değişikliği)';
    if (low.includes('adres') && low.includes('nakil') && (low.includes('işe başlama') || low.includes('ise baslama'))) return 'MERSIS_Merkez Adres Değişikliği Nedeniyle Nakil İşe Başlama';
    if (low.includes('adres') && (low.includes('değiş') || low.includes('degis') || low.includes('bilgi'))) return 'MERSIS_Merkez Adres Değişikliği';
    if (low.includes('şube') || low.includes('sube')) return raw.startsWith('MERSIS_') ? raw : 'MERSIS_' + raw;
    if (low.includes('tasfiye') || low.includes('terk') || low.includes('kapanış') || low.includes('kapanis')) return raw.startsWith('MERSIS_') ? raw : 'MERSIS_' + raw;
    if (raw.startsWith('MERSIS_') || raw.startsWith('MERSİS_')) return raw;
    return raw;
  }

  function itGetDetailIdFromJob(job) {
    const k = job?.kaynakEkBilgiler || {};
    const vals = [job?.is_detayId, job?.txtGizliDetayId, job?.isDetayId, job?.detayId, k?.is_detayId, k?.txtGizliDetayId, k?.isDetayId, k?.detayId];
    for (const v of vals) {
      const n = Number(v);
      if (Number.isFinite(n) && n > 0) return n;
    }
    return 0;
  }

  function setupResizableJobTable(panel, logFn) {
    const table = $('#it_jobs_table', panel);
    const cg = $('#it_jobs_colgroup', panel);
    const thead = $('#it_jobs_thead', panel);
    if (!table || !cg || !thead) return;

    const saved = readJobColumnWidths();
    const getW = c => Math.max(c.min || 40, Number(saved[c.key] || c.width || 100));
    cg.innerHTML = IT_JOB_COLUMNS.map(c => `<col data-col-key="${itHtmlEscape(c.key)}" style="width:${getW(c)}px">`).join('');
    const botForSort = panel.__itBotInstance || null;
    const activeSort = botForSort?.__jobSort || null;
    thead.innerHTML = `<tr>${IT_JOB_COLUMNS.map((c, i) => `<th data-col-key="${itHtmlEscape(c.key)}" class="${c.sort ? 'it-sortable' : ''}" title="${c.sort ? 'Sıralamak için tıkla' : ''}">${itHtmlEscape(c.label)}${activeSort?.key === c.key ? `<span class="it-sort-ind">${activeSort.dir === 'desc' ? '▼' : '▲'}</span>` : ''}<span class="it-col-resizer" data-resize-col="1" title="Sütun genişliğini değiştir"></span></th>`).join('')}</tr>`;

    thead.querySelectorAll('th.it-sortable').forEach(th => {
      th.onclick = ev => {
        if (ev.target && ev.target.closest && ev.target.closest('.it-col-resizer')) return;
        const bot = panel.__itBotInstance || null;
        if (!bot) return;
        const key = th.getAttribute('data-col-key') || '';
        const prev = bot.__jobSort || {};
        bot.__jobSort = { key, dir: prev.key === key && prev.dir !== 'desc' ? 'desc' : 'asc' };
        setupResizableJobTable(panel, logFn);
        bot.renderRows(bot.__lastRowsRaw || [], true);
      };
    });

    let drag = null;
    const cols = () => Array.from(cg.querySelectorAll('col'));

    const onMove = ev => {
      if (!drag) return;
      ev.preventDefault();
      const dx = ev.clientX - drag.startX;
      const next = Math.max(drag.min, drag.startW + dx);
      drag.col.style.width = `${next}px`;
      drag.th.style.width = `${next}px`;
    };
    const onUp = ev => {
      if (!drag) return;
      const finalW = parseInt(drag.col.style.width || drag.startW, 10) || drag.startW;
      saveJobColumnWidth(drag.key, finalW);
      try { drag.handle.classList.remove('active'); } catch (_) {}
      drag = null;
      document.body.classList.remove('it-col-resizing');
      document.removeEventListener('mousemove', onMove, true);
      document.removeEventListener('mouseup', onUp, true);
      try { if (logFn) logFn('Sütun genişliği kaydedildi.'); } catch (_) {}
    };

    thead.querySelectorAll('.it-col-resizer').forEach(handle => {
      handle.onmousedown = ev => {
        ev.preventDefault();
        ev.stopPropagation();
        const th = handle.closest('th');
        const key = th?.getAttribute('data-col-key') || '';
        const idx = IT_JOB_COLUMNS.findIndex(c => c.key === key);
        const col = cols()[idx];
        if (!th || !col || idx < 0) return;
        const cfg = IT_JOB_COLUMNS[idx];
        const rect = th.getBoundingClientRect();
        drag = { key, th, col, handle, startX: ev.clientX, startW: rect.width, min: cfg.min || 40 };
        handle.classList.add('active');
        document.body.classList.add('it-col-resizing');
        document.addEventListener('mousemove', onMove, true);
        document.addEventListener('mouseup', onUp, true);
      };
      handle.ondblclick = ev => {
        ev.preventDefault();
        ev.stopPropagation();
        const th = handle.closest('th');
        const key = th?.getAttribute('data-col-key') || '';
        const idx = IT_JOB_COLUMNS.findIndex(c => c.key === key);
        const col = cols()[idx];
        const cfg = IT_JOB_COLUMNS[idx];
        if (!th || !col || !cfg) return;
        col.style.width = `${cfg.width}px`;
        th.style.width = `${cfg.width}px`;
        saveJobColumnWidth(key, cfg.width);
      };
    });
  }


  class Bot {
    constructor(panel) {
      this.panel = panel;
      this.panel.__itBotInstance = this;
      this.log = logger(panel);
      this.bind();
      setupResizableJobTable(this.panel, this.log);
      this.loadSettings();
      discoverFromPage();
      renderDiscovery();
      this.log('XHR dinleme açıldı. İlk tıklamalarda giden sorgulardan userId / orgoid / token yakalanacak.');
    }

    bind() {
      $('#it_close', this.panel).onclick = () => {
        try {
          // v4.31.57: 'İş Takip Botunu Aç' zorlayıcı geri-açma butonu kaldırıldı.
          // Kapatma sadece bu sayfa oturumu için geçerli olsun; sayfa yenilenince panel tekrar gelir.
          window.__istakipBotManualClosed = true;
          try { itChromeStorageSetSafe({ [CFG.UI_KEY]: { closed: false, minimized: false } }); } catch (_) {}
          try { const r = document.getElementById(CFG.RESTORE_ID); if (r) r.remove(); } catch (_) {}
          this.panel.remove();
        } catch (_) { try { this.panel.remove(); } catch (__) {} }
      };
      $('#it_panel_reset', this.panel).onclick = () => {
        this.panel.classList.remove('collapsed');
        $('#it_wrap', this.panel).style.display = '';
        this.panel.style.top = '118px';
        this.panel.style.right = '16px';
        this.panel.style.left = 'auto';
        this.panel.style.bottom = 'auto';
        this.panel.style.width = '980px';
        this.panel.style.height = 'min(660px, calc(100vh - 140px))';
        this.panel.style.minHeight = '320px';
        this.panel.style.display = 'flex';
        this.panel.style.flexDirection = 'column';
        this.panel.style.resize = 'none';
        this.panel.style.transform = 'none';
        resetJobColumnWidths();
        setupResizableJobTable(this.panel, this.log);
        fitPanelToViewport(this.panel);
      };
      $('#it_toggle', this.panel).onclick = () => {
        const wrap = $('#it_wrap', this.panel);
        const collapsed = this.panel.classList.contains('collapsed');
        if (collapsed) {
          this.panel.classList.remove('collapsed');
          wrap.style.display = '';
          this.panel.style.width = this.panel.dataset.prevWidth || 'min(980px, calc(100vw - 32px))';
          const prevH = parseInt(this.panel.dataset.prevHeight || '', 10);
          this.panel.style.height = (prevH && prevH >= 320) ? this.panel.dataset.prevHeight : 'min(660px, calc(100vh - 140px))';
          this.panel.style.minHeight = '320px';
          this.panel.style.display = 'flex';
          this.panel.style.flexDirection = 'column';
          this.panel.style.resize = 'none';
          this.panel.style.top = this.panel.dataset.prevTop || '118px';
          this.panel.style.right = this.panel.dataset.prevRight || '16px';
          this.panel.style.left = this.panel.dataset.prevLeft || 'auto';
          this.panel.style.bottom = this.panel.dataset.prevBottom || 'auto';
          fitPanelToViewport(this.panel);
        } else {
          this.panel.dataset.prevWidth = this.panel.style.width || `${this.panel.getBoundingClientRect().width}px`;
          this.panel.dataset.prevHeight = this.panel.style.height || `${this.panel.getBoundingClientRect().height}px`;
          this.panel.dataset.prevTop = this.panel.style.top || `${this.panel.getBoundingClientRect().top}px`;
          this.panel.dataset.prevRight = this.panel.style.right || '16px';
          this.panel.dataset.prevLeft = this.panel.style.left || 'auto';
          this.panel.dataset.prevBottom = this.panel.style.bottom || 'auto';
          this.panel.classList.add('collapsed');
          wrap.style.display = 'none';
          this.panel.style.width = '300px';
          this.panel.style.height = '38px';
          this.panel.style.minHeight = '38px';
          this.panel.style.resize = 'none';
          this.panel.style.top = '118px';
          this.panel.style.right = '16px';
          this.panel.style.left = 'auto';
          this.panel.style.bottom = 'auto';
        }
      };
      $('#it_discover', this.panel).onclick = () => {
        discoverFromPage();
        renderDiscovery();
        this.log(`Keşif yenilendi. userId=${state.discovery.userId || '-'} orgoid=${state.discovery.orgoid || '-'} istakipToken=${state.discovery.tokensByModule?.istakip ? 'var' : 'yok'}`);
      };
      $('#it_scan', this.panel).onclick = () => this.scan();
      $('#it_send', this.panel).onclick = () => this.sendEligible();
      $('#it_refresh', this.panel).onclick = () => this.refreshAfterSave();
      $('#it_stop', this.panel).onclick = () => { state.stopRequested = true; this.log('Durdurma istendi.'); };
      ['#it_limit','#it_filter','#it_istakip','#it_istipi','#it_atama_sil','#it_hedef_durum','#it_durum_tip','#it_islem_sahibi','#it_uzerime_al','#it_orgoid_override','#it_user_override']
        .forEach(sel => {
          const el = $(sel, this.panel);
          if (el) el.addEventListener('change', () => this.saveSettings());
        });

      ['#it_vkn_start', '#it_vkn_end'].forEach(sel => {
        const el = $(sel, this.panel);
        if (!el) return;
        ['input','change','keyup'].forEach(ev => el.addEventListener(ev, () => {
          el.value = this.digitsOnly(el.value).slice(0, 10);
          this.rerenderCurrentRows();
        }));
      });
    }

    loadSettings() {
      itChromeStorageGetSafe([CFG.STORAGE_KEY], out => {
        const s = out?.[CFG.STORAGE_KEY] || {};
        const keys = {
          limit:'#it_limit', filter:'#it_filter', istakip:'#it_istakip', isTipi:'#it_istipi',
          atamaSil:'#it_atama_sil', hedefDurum:'#it_hedef_durum', durumTip:'#it_durum_tip',
          islemSahibi:'#it_islem_sahibi', uzerimeAl:'#it_uzerime_al', orgoidOverride:'#it_orgoid_override', userOverride:'#it_user_override'
        };
        Object.entries(keys).forEach(([k, sel]) => {
          if (s[k] !== undefined && $(sel, this.panel)) $(sel, this.panel).value = s[k];
        });
      });
    }

    saveSettings() {
      const s = this.getSettings();
      itChromeStorageSetSafe({ [CFG.STORAGE_KEY]: {
        limit:String(s.limit), filter:s.filterRaw, istakip:s.istakipRaw, isTipi:String(s.isTipi),
        atamaSil:String(s.atamaSil), hedefDurum:String(s.hedefDurumNo), durumTip:String(s.akisDurumTip),
        islemSahibi:String(s.islemSahibi), uzerimeAl:String(s.isiUzerimeAl),
        orgoidOverride:s.orgoidOverride, userOverride:s.userOverride
      }});
    }

    getSettings() {
      discoverFromPage();
      const discovered = getDiscovered();
      return {
        discovered,
        userOverride: $('#it_user_override', this.panel).value.trim(),
        orgoidOverride: $('#it_orgoid_override', this.panel).value.trim(),
        userId: $('#it_user_override', this.panel).value.trim() || state.discovery.baseUserId || discovered.userId,
        orgoid: $('#it_orgoid_override', this.panel).value.trim() || state.discovery.baseOrgoid || discovered.orgoid,
        limit: 50,
        filterRaw: $('#it_filter', this.panel).value.trim(),
        istakipRaw: $('#it_istakip', this.panel).value.trim(),
        isTipi: Math.max(0, Number($('#it_istipi', this.panel).value || 5)),
        atamaSil: 1,
        hedefDurumNo: Number($('#it_hedef_durum', this.panel).value || 4),
        akisDurumTip: Number($('#it_durum_tip', this.panel).value || 21),
        islemSahibi: Number($('#it_islem_sahibi', this.panel).value || 3),
        isiUzerimeAl: Number($('#it_uzerime_al', this.panel).value || 1)
      };
    }

    assertDiscovery(s) {
      const missing = [];
      if (!s.userId) missing.push('userId');
      if (!s.orgoid) missing.push('orgoid');
      if (!s.discovered.token) missing.push('token');
      if (missing.length) {
        this.log(`Auto-discovery eksik: ${missing.join(', ')}. Önce ilgili ekranlarda birkaç işlem yap veya manuel alanları doldur.`, true);
        return false;
      }
      this.log(`Kullanılacak değerler → userId=${s.userId}, orgoid=${s.orgoid}, token=${s.discovered.token ? 'var' : 'yok'}`);
      return true;
    }

    buildListPayload(s, start = 0, pageLimit = null) {
      const raw = s.filterRaw;
      const isDigits = /^\d+$/.test(raw);
      return {
        userId: String(s.userId || ''),
        nodeId: "",
        isTipi: 5,
        atamaYapilamayacakIsleriSil: 1,
        sonucSayisi: String(pageLimit || s.limit || 50),
        sorgulamaKriterleri: {
          vergiNo: raw && isDigits && raw.length === 10 ? raw : "",
          tcKimlikNo: raw && isDigits && raw.length === 11 ? raw : "",
          belgeTarihi: "",
          sayi: "",
          basTar: "",
          bitTar: "",
          unvan: raw && !isDigits ? raw : "",
          isTuru: "",
          basBeklenenTamamlanmaTarihi: "",
          bitBeklenenTamamlanmaTarihi: "",
          etiket: "",
          istakipNo: s.istakipRaw || ""
        },
        respKeyParam: "isler",
        isTakipAkisNo: -1,
        isTakipDurumNo: -1,
        pv: { start: Number(start || 0), limit: String(pageLimit || s.limit || 50), sorters: [] }
      };
    }

    extractJobsFromListResponse(resp) {
      const key = resp?.respKeyParam || 'isler';
      return resp?.data?.isler || resp?.data?.[key] || [];
    }

    extractTotalCountFromListResponse(resp, fallbackCount = 0) {
      const vals = [
        resp?.data?.totalCount,
        resp?.data?.total,
        resp?.data?.toplam,
        resp?.data?.rowCount,
        resp?.data?.kayitSayisi,
        resp?.totalCount,
        resp?.total
      ];
      for (const v of vals) {
        const n = Number(v);
        if (Number.isFinite(n) && n >= 0) return n;
      }
      return Number(fallbackCount || 0);
    }

    async fetchAllJobsPaged(s, reason = 'İş listesi') {
      const pageLimit = Math.max(1, Number(s.limit || CFG.DEFAULT_LIMIT || 50) || 50);
      const all = [];
      let start = 0;
      let total = null;
      let pageNo = 1;

      while (true) {
        const resp = await post(CFG.COMMANDS.LIST, this.buildListPayload(s, start, pageLimit));
        const rows = this.extractJobsFromListResponse(resp);
        const respTotal = this.extractTotalCountFromListResponse(resp, all.length + rows.length);
        if (total === null) total = respTotal;

        all.push(...rows);
        this.log(`${reason}: sayfa ${pageNo} alındı. start=${start}, gelen=${rows.length}, toplam=${total}`);

        if (!rows.length) break;
        if (total && all.length >= total) break;
        if (rows.length < pageLimit) break;

        start += pageLimit;
        pageNo += 1;

        // Güvenlik sınırı: beklenmeyen sonsuz döngüyü önler.
        if (pageNo > 25) {
          this.log(`${reason}: 25 sayfa sınırına ulaşıldı, durduruldu. Alınan=${all.length}`, true);
          break;
        }
      }

      return { jobs: all, totalCount: total ?? all.length, pages: pageNo };
    }


    getNodeIdFromJobs(jobs) {
      const list = Array.isArray(jobs) ? jobs : [];
      for (const j of list) {
        const raw = j?.akis_nodeId ?? j?.nodeId ?? j?.akisNodeId ?? j?.kaynakEkBilgiler?.akis_nodeId ?? '';
        const val = String(raw || '').trim();
        if (val && val !== '0' && val !== '-1') return val;
      }
      try {
        const text = String((document.body && (document.body.innerText || document.body.textContent)) || '');
        const m = text.match(/nodeId["'\s:=]+(\d{3,})/i);
        if (m) return m[1];
      } catch (_) {}
      return '';
    }

    getUserRowsFromSummary(resp) {
      const d = resp?.data || {};
      const arr = d.birimdekiKullaniciIsListesiOzet || d.kullaniciIsListesiOzet || d.kullanicilar || d.rows || [];
      return Array.isArray(arr) ? arr : [];
    }

    normalizeOwnerName(row, userId) {
      const txt = String(row?.userAdSoyad || row?.adSoyad || row?.adiSoyadi || row?.label || '').trim();
      if (txt) return txt;
      return userId ? `Kullanıcı ${userId}` : 'Birimdeki işler';
    }

    ownerTextLooksLikeSystemId(v) {
      const t = String(v || '').replace(/\s+/g, ' ').trim();
      if (!t || t === '-' || /^(undefined|null)$/i.test(t)) return true;
      const plain = t.replace(/[()]/g, '').trim();
      if (/^\d{5,}$/.test(plain)) return true;
      // İş Takip akış/node id değerleri genellikle 0chu40qmac123d gibi harf+rakam karışık, boşluksuz değerlerdir.
      if (/^[0-9a-z]{10,}$/i.test(plain) && /\d/.test(plain) && /[a-z]/i.test(plain) && !/[çğıöşüÇĞİÖŞÜ\s]/.test(plain)) return true;
      if (/^[0-9a-f]{16,}$/i.test(plain)) return true;
      return false;
    }

    getOwnerDisplayText(job) {
      const k = job?.kaynakEkBilgiler || {};
      const candidates = [
        job?.__ownerName,
        job?.uzerindekiKullanici, job?.üzerindekiKullanici, job?.ownerName,
        job?.alanKullaniciAdiSoyadi, job?.alanKullaniciAdSoyad, job?.alanKullanici,
        job?.atananKullaniciAdiSoyadi, job?.atananKullaniciAdSoyad,
        job?.akisUserAdiSoyadi, job?.akis_userAdiSoyadi, job?.akis_kullaniciAdiSoyadi, job?.akisKullaniciAdiSoyadi,
        job?.isUserAdiSoyadi, job?.isUserAdSoyad, job?.is_userAdiSoyadi, job?.is_userAdSoyad,
        job?.is_alanKullaniciAdiSoyadi, job?.is_alanKullaniciAdSoyad, job?.is_alanKullanici,
        k?.__ownerName,
        k?.uzerindekiKullanici, k?.üzerindekiKullanici, k?.ownerName,
        k?.alanKullaniciAdiSoyadi, k?.alanKullaniciAdSoyad, k?.alanKullanici,
        k?.atananKullaniciAdiSoyadi, k?.atananKullaniciAdSoyad,
        k?.akisUserAdiSoyadi, k?.akis_userAdiSoyadi, k?.akis_kullaniciAdiSoyadi, k?.akisKullaniciAdiSoyadi,
        k?.isUserAdiSoyadi, k?.isUserAdSoyad, k?.is_userAdiSoyadi, k?.is_userAdSoyad,
        k?.is_alanKullaniciAdiSoyadi, k?.is_alanKullaniciAdSoyad, k?.is_alanKullanici
      ];
      for (const v of candidates) {
        const txt = String(v || '').replace(/\s+/g, ' ').trim();
        if (!txt || txt === '-') continue;
        if (this.ownerTextLooksLikeSystemId(txt)) continue;
        return txt;
      }
      return '-';
    }

    mergeCombinedJobFields(target, src) {
      if (!target || !src || target === src) return target;
      const empty = (v) => v === undefined || v === null || String(v).trim() === '' || String(v).trim() === '-';
      const ownerSrc = this.getOwnerDisplayText(src);
      const ownerTarget = this.getOwnerDisplayText(target);
      if (ownerSrc && ownerSrc !== '-' && (ownerTarget === '-' || this.ownerTextLooksLikeSystemId(ownerTarget))) {
        target.__ownerName = ownerSrc;
      }
      if (empty(target.__ownerUserId) && !empty(src.__ownerUserId)) target.__ownerUserId = src.__ownerUserId;

      // İlk sorgudan gelen GİB/birim satırı aynı işin kullanıcı üzerindeki satırından önce geldiyse
      // duplicate silinirken kullanıcı bilgisi kaybolmasın; boş alanları sonraki satırla tamamla.
      const important = [
        '__ownerName','__ownerUserId','__mersisIslemBilgisi','__mersisIslemTuru',
        'akisUserAdiSoyadi','akis_userAdiSoyadi','akis_kullaniciAdiSoyadi','akisKullaniciAdiSoyadi',
        'isUserAdiSoyadi','isUserAdSoyad','is_userAdiSoyadi','is_userAdSoyad',
        'alanKullaniciAdiSoyadi','alanKullaniciAdSoyad','alanKullanici','atananKullaniciAdiSoyadi',
        'is_detayId','txtGizliDetayId','txtIsTuru','isTuru','is_turu','is_isTuru',
        'islemBilgisi','ISLEMBILGISI','islem_bilgisi','is_islemBilgisi','akis_islemBilgisi'
      ];
      for (const key of important) {
        if (empty(target[key]) && !empty(src[key])) target[key] = src[key];
      }
      if (target.kaynakEkBilgiler && src.kaynakEkBilgiler && typeof target.kaynakEkBilgiler === 'object' && typeof src.kaynakEkBilgiler === 'object') {
        for (const [key, val] of Object.entries(src.kaynakEkBilgiler)) {
          if (empty(target.kaynakEkBilgiler[key]) && !empty(val)) target.kaynakEkBilgiler[key] = val;
        }
      } else if (empty(target.kaynakEkBilgiler) && src.kaynakEkBilgiler) {
        target.kaynakEkBilgiler = src.kaynakEkBilgiler;
      }
      return target;
    }

    dedupeJobsForCombinedScan(list) {
      const out = [];
      const seen = new Map();
      const keyOf = (j) => {
        const k = [
          j?.akis_oid, j?.akisOid, j?.is_isTakipNo, j?.akis_isTakipNo,
          j?.isTakipNo, j?.istakipNo, j?.kaynakEkBilgiler?.evrakOid,
          j?.kaynakEkBilgiler?.is_sicil_mersisNo, j?.is_vergiNo,
          j?.akis_atanma_Zamani
        ].map(v => String(v || '').trim()).filter(Boolean).join('|');
        return k || JSON.stringify(j || {}).slice(0, 300);
      };
      for (const j of Array.isArray(list) ? list : []) {
        const k = keyOf(j);
        if (seen.has(k)) {
          this.mergeCombinedJobFields(seen.get(k), j);
          continue;
        }
        seen.set(k, j);
        out.push(j);
      }
      return out;
    }

    async fetchBirimVeKullaniciIsleri(s, initialPageResult) {
      const initialJobs = Array.isArray(initialPageResult?.jobs) ? initialPageResult.jobs : [];
      const nodeId = this.getNodeIdFromJobs(initialJobs);
      if (!nodeId) {
        this.log('Birim/kullanıcı işleri için nodeId bulunamadı; mevcut listeyle devam ediliyor.', true);
        return initialPageResult;
      }

      let summary;
      try {
        summary = await post(CFG.COMMANDS.USER_JOBS_SUMMARY, { userId: String(s.userId || ''), nodeId: String(nodeId) });
      } catch (e) {
        this.log(`Birim kullanıcı özeti alınamadı: ${e?.message || String(e)}. Mevcut listeyle devam ediliyor.`, true);
        return initialPageResult;
      }

      const rows = this.getUserRowsFromSummary(summary);
      if (!rows.length) {
        this.log('Birim kullanıcı özeti boş döndü; mevcut listeyle devam ediliyor.');
        return initialPageResult;
      }

      const all = [];
      let fetchedUsers = 0;
      let fetchedJobs = 0;
      this.log(`Birim/kullanıcı iş özeti alındı. kullanıcı/birim satırı=${rows.length}, nodeId=${nodeId}`);

      for (const row of rows) {
        const userId = String(row?.userId ?? row?.userid ?? '').trim();
        const secili = Number(row?.seciliBirimdekiIsSayisi ?? row?.birimdekiIsSayisi ?? 0) || 0;
        const toplam = Number(row?.toplamIsSayisi ?? row?.toplam ?? 0) || 0;
        if (secili <= 0 && toplam <= 0) continue;
        const ownerName = this.normalizeOwnerName(row, userId);
        try {
          const resp = await post(CFG.COMMANDS.USER_JOBS_IN_NODE, { userId: userId, nodeId: String(nodeId) });
          const jobs = this.extractJobsFromListResponse(resp);
          fetchedUsers += 1;
          fetchedJobs += jobs.length;
          jobs.forEach(j => {
            j.__ownerUserId = userId;
            j.__ownerName = ownerName;
            if (!j.akisUserAdiSoyadi && ownerName && userId) j.akisUserAdiSoyadi = ownerName;
          });
          all.push(...jobs);
          this.log(`Birim/kullanıcı işleri: ${ownerName} userId=${userId || '-'} gelen=${jobs.length}`);
        } catch (e) {
          this.log(`Birim/kullanıcı işleri alınamadı: ${ownerName} userId=${userId || '-'} hata=${e?.message || String(e)}`, true);
        }
      }

      if (!all.length) {
        this.log('Birim/kullanıcı sorguları iş döndürmedi; mevcut listeyle devam ediliyor.', true);
        return initialPageResult;
      }

      const merged = this.dedupeJobsForCombinedScan([...initialJobs, ...all]);
      this.log(`Birim + üzerindeki kullanıcı işleri birleştirildi. kullanıcıSorgusu=${fetchedUsers}, gelen=${fetchedJobs}, tekil=${merged.length}`);
      return { jobs: merged, totalCount: merged.length, pages: initialPageResult?.pages || 1, nodeId, combined: true };
    }


    buildSavePayload(job, step, s) {
      const asObj = step?.asJSONObject || {};
      const hedefDurumNo = Number(step?.durumNo ?? asObj?.durumNo ?? s.hedefDurumNo);
      const akisDurumTip = Number(step?.tip ?? asObj?.tip ?? s.akisDurumTip);
      return {
        atanacakNodeId: '',
        atamaYapanKullaniciUserId: String(s.userId || ''),
        orgoid: itFindOrgoid(job) || String(s.orgoid || ''),
        isTakipNo: itFindIsTakipNo(job),
        akisOid: itFindAkisOid(job),
        atamaYapilacaklar: [],
        akisDurumKullanicilari: [],
        akisDurumNodeIdler: [],
        islemSahibi: Number(s.islemSahibi ?? 3),
        akisDurum: 1,
        userId: String(s.userId || ''),
        islemYapanUserId: String(s.userId || ''),
        isiUzerimeAl: Number(s.isiUzerimeAl ?? 1),
        aciklama: '',
        hedefDurumNo,
        akisDurumTip,
        geriGonderimSebepleri: [],
        // Son HAR'da İşi Bitir (Şef) için EYS bu alanı 12 haneli gönderiyor: YYYYMMDDHHMM.
        beklenenIsBitisZamani: itNormalizeBeklenenIsBitisZamani(job)
      };
    }

    shouldExcludeFromYoklama(job) {
      const texts = [
        job?.is_kaynakbilgi,
        job?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakbilgi,
        job?.kaynakEkBilgiler?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakBilgisi,
        job?.kaynakEkBilgiler?.isKaynakBilgisi,
        job?.kaynakEkBilgiler?.is_kaynak_bilgi,
        job?.kaynakEkBilgiler?.is_kaynak_bilgisi
      ]
        .filter(Boolean)
        .map(v => String(v).toLowerCase());

      const joined = texts.join(' | ');
      if (!joined) return '';

      if (joined.includes('muhtasar dönem değişikliği bildirimi')) {
        return 'is_kaynakbilgi içinde Muhtasar Dönem Değişikliği Bildirimi geçtiği için hariç';
      }
      if (joined.includes('mersis no')) {
        return 'is_kaynakbilgi içinde Mersis No geçtiği için hariç';
      }
      return '';
    }



    getKaynakText(job) {
      const vals = [
        job?.is_kaynakbilgi,
        job?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakbilgi,
        job?.kaynakEkBilgiler?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakBilgisi,
        job?.kaynakEkBilgiler?.isKaynakBilgisi
      ].filter(Boolean);
      return vals.map(v => String(v)).join(' | ');
    }

    isMersisKaydi(job) {
      return this.getKaynakText(job).toLowerCase().includes('mersis no');
    }

    rebuildDetailMapFromCounts(counts) {
      const grouped = counts?.data?.gruplanmisIsler || counts?.data?.groupedJobs || [];
      const map = {};
      for (const row of grouped) {
        const id = Number(row?.txtGizliDetayId ?? row?.is_detayId ?? 0);
        const text = String(row?.txtIsTuru || row?.isTuru || '').trim();
        if (id > 0 && text && text !== 'TOPLAM:') map[id] = text;
      }
      state.detailMap = map;
      return map;
    }

    getIsTuruText(job) {
      const detailId = itGetDetailIdFromJob(job);
      const dynamicText = state.detailMap?.[detailId];
      if (dynamicText && !itLooksLikeBelgeInfoText(dynamicText)) return dynamicText;

      const directVals = [
        job?.__mersisIslemTuru,
        job?.txtIsTuru, job?.isTuru, job?.is_turu, job?.is_isTuru,
        job?.kaynakEkBilgiler?.txtIsTuru, job?.kaynakEkBilgiler?.isTuru, job?.kaynakEkBilgiler?.is_turu, job?.kaynakEkBilgiler?.is_isTuru
      ];
      for (const v of directVals) {
        const txt = String(v ?? '').replace(/\s+/g, ' ').trim();
        if (txt && txt !== '-' && !itLooksLikeBelgeInfoText(txt)) return itNormalizeMersisIslemTuruLabel(txt);
      }

      const fallback = IT_DETAIL_TURU_FALLBACK_MAP[detailId];
      if (fallback) return fallback;

      const kaynak = job?.is_kaynakbilgi || job?.kaynakEkBilgiler?.is_kaynakbilgi || '';
      if (kaynak && !itLooksLikeBelgeInfoText(kaynak)) return kaynak;
      return '-';
    }

    getBelgeBilgiText(job) {
      const k = job?.kaynakEkBilgiler || {};
      const vals = [
        job?.belgeBilgi,
        job?.is_belgeBilgi,
        job?.belge_bilgi,
        job?.is_kaynakbilgi,
        k?.belgeBilgi,
        k?.is_belgeBilgi,
        k?.belge_bilgi,
        k?.is_kaynakbilgi,
        k?.isKaynakBilgi
      ].filter(v => String(v ?? '').trim());
      const uniq = [];
      const seen = new Set();
      vals.forEach(v => {
        const txt = String(v).replace(/\s+/g, ' ').trim();
        const key = txt.toLowerCase();
        if (txt && !seen.has(key)) { seen.add(key); uniq.push(txt); }
      });
      return uniq.join(' | ') || '-';
    }

    getMersisIslemBilgisiText(job) {
      const enriched = String(job?.__mersisIslemBilgisi || '').replace(/\s+/g, ' ').trim();
      if (enriched && enriched !== '-') return enriched;
      const raw = itMersisRawIslemBilgisiFromJob(job);
      if (raw) return raw;
      return String(
        job?.islemBilgisi || job?.ISLEMBILGISI || job?.islem_bilgisi ||
        job?.is_islemBilgisi || job?.is_islem_bilgisi || job?.akis_islemBilgisi ||
        job?.kaynakEkBilgiler?.islemBilgisi || job?.kaynakEkBilgiler?.ISLEMBILGISI ||
        job?.kaynakEkBilgiler?.is_islemBilgisi || job?.kaynakEkBilgiler?.is_islem_bilgisi ||
        '-'
      ).replace(/\s+/g, ' ').trim() || '-';
    }

    getYoklamaStatusCacheKey(job) {
      const parts = [
        job?.akis_oid,
        job?.is_isTakipNo || job?.akis_isTakipNo,
        job?.is_vergiNo || job?.is_tcKimlikNo,
        job?.keysEvrakOid || job?.kaynakEkBilgiler?.keysEvrakOid
      ].map(v => String(v || '').trim()).filter(Boolean);
      return parts.join('|') || JSON.stringify(job || {}).slice(0, 200);
    }

getPreviewPayload(job) {
  const k = job?.kaynakEkBilgiler || {};
  const kaynak = this.getKaynakText(job);
  const turText = this.getIsTuruText ? this.getIsTuruText(job) : '';
  const isMersis = String(kaynak + ' | ' + turText).toLocaleLowerCase('tr-TR').includes('mersis');

  // MERSİS satırlarında kaynak/belge alanındaki 16 haneli MERSİS No evrakOid gibi
  // yakalanabiliyor. Normal evrak önizlemesi gerekirse İş Takip OID önceliklidir;
  // asıl MERSİS önizleme ise openPreview içinde EVDB Rapor tokeniyle ayrı açılır.
  const isTakipOid = (
    job?.is_isTakipNo || job?.akis_isTakipNo || job?.isTakipNo || job?.istakipNo ||
    k?.is_isTakipNo || k?.akis_isTakipNo || k?.isTakipNo || k?.istakipNo || ''
  );
  let keysEvrakOid = k?.keysEvrakOid || job?.keysEvrakOid || k?.evrakOid || job?.evrakOid || k?.belgeOid || job?.belgeOid || '';
  if (isMersis && String(isTakipOid || '').trim()) keysEvrakOid = isTakipOid;

  return {
    belgeTuru: String(k?.belgeTuru ?? job?.belgeTuru ?? '').trim(),
    keysEvrakOid: String(keysEvrakOid || '').trim(),
    isGeldigiYer: k?.is_geldigiyer || job?.is_geldigiyer || '',
    kaynak
  };
}

async openPreview(job) {
  try {
    if (this.isMersisKaydi && this.isMersisKaydi(job)) {
      await itOpenMersisPrintPreview(job, this);
      return;
    }
    const p = this.getPreviewPayload(job);
    if (!p.keysEvrakOid) {
      this.log('Bu kayıtta keysEvrakOid bulunamadı, önizleme açılamadı.', true);
      return;
    }
    this.log(`Önizleme sorgulanıyor. keysEvrakOid=${p.keysEvrakOid}`);
    const info = await fetchKeysPreviewInfo(p.keysEvrakOid);
    this.log(`Önizleme cevabı alındı. keysEvrakOid=${p.keysEvrakOid} fileID=${info.fileID || ''} dosyaId=${info.dosyaId || ''}`);
    this.log(`Üretilen önizleme linki: ${info.url}`);
    showPreviewModal(info.url, p.kaynak || `Evrak ${p.keysEvrakOid}`);
    this.log(`Önizleme modal içinde açıldı. keysEvrakOid=${p.keysEvrakOid}`);
  } catch (e) {
    this.log(`Önizleme açılamadı: ${e.message || String(e)}`, true);
  }
}

    escapeHtml(v) {
      return itHtmlEscape(v);
    }

    digitsOnly(v) {
      return String(v || '').replace(/\D+/g, '');
    }

    getVknRangeFilter() {
      const sEl = $('#it_vkn_start', this.panel);
      const eEl = $('#it_vkn_end', this.panel);
      if (sEl) sEl.value = this.digitsOnly(sEl.value).slice(0, 10);
      if (eEl) eEl.value = this.digitsOnly(eEl.value).slice(0, 10);
      return {
        start: sEl ? sEl.value : '',
        end: eEl ? eEl.value : ''
      };
    }

    getJobVkn(job) {
      const direct = this.digitsOnly(job?.is_vergiNo || job?.vergiNo || job?.vkn || '');
      if (direct.length === 10) return direct;

      // yedek: iş takip hücresinde gösterilen değerlerden 10 haneli olanı bul
      const blob = [
        job?.is_vergiNo,
        job?.is_tcKimlikNo,
        job?.is_isTakipNo,
        job?.akis_isTakipNo
      ].map(x => String(x || '')).join(' ');
      const nums = blob.match(/\d{10,11}/g) || [];
      return nums.find(n => String(n).length === 10) || '';
    }

    getJobTckn(job) {
      const direct = this.digitsOnly(job?.is_tcKimlikNo || job?.tcKimlikNo || job?.tckn || '');
      if (direct.length === 11) return direct;
      const blob = [
        job?.is_vergiNo,
        job?.is_tcKimlikNo,
        job?.is_isTakipNo,
        job?.akis_isTakipNo
      ].map(x => String(x || '')).join(' ');
      const nums = blob.match(/\d{10,11}/g) || [];
      return nums.find(n => String(n).length === 11) || '';
    }

    isVknInRange(vkn, start, end) {
      if (!start && !end) return true;
      if (!vkn || vkn.length !== 10) return false;
      if (start && start.length !== 10) start = '';
      if (end && end.length !== 10) end = '';
      if (!start && !end) return true;
      if (start && !end) return vkn >= start;
      if (!start && end) return vkn <= end;
      return vkn >= start && vkn <= end;
    }

    filterJobsByVkn(list) {
      // v4.31.72: Ana Modül üst VKN Başlangıç/Bitiş alanı kaldırıldı; liste burada daraltılmaz.
      // Tablo başlığındaki küçük İşTakip/VKN filtresi ayrı çalışmaya devam eder.
      return list || [];
    }

    updateVknFilterInfo(total, shown) {
      // v4.31.72: Ana Modül üst VKN Başlangıç/Bitiş filtresi kaldırıldı; bilgi etiketi de gösterilmez.
      try { const info = $('#it_vkn_filter_info', this.panel); if (info) info.remove(); } catch (_) {}
    }

    rerenderCurrentRows() {
      if (Array.isArray(this.__lastRowsRaw)) this.renderRows(this.__lastRowsRaw, true);
    }


    getYoklamaStatusForJob(job) {
      const special = itReadAdiOrtaklikStoredStatus(job);
      if (special && Array.isArray(special.items) && special.items.length) return special;
      const st = job?.__ykStatus || {};
      return {
        durum: st.durum || '-',
        kod: st.kod || '',
        items: Array.isArray(st.items) ? st.items : [],
        error: st.error || ''
      };
    }

    hasExistingYoklamaForJob(job) {
      const st = this.getYoklamaStatusForJob(job);
      const items = Array.isArray(st.items) ? st.items : [];
      if (items.some(it => ykGetKod(it))) return true;
      if (st.kod) return true;
      return false;
    }

    async refreshYoklamaStatusNoCache(job) {
      try {
        const cacheKey = this.getYoklamaStatusCacheKey(job);
        try { state.ykStatusCache?.delete(cacheKey); } catch (_) {}
        try { delete job.__ykStatus; } catch (_) {}
        return await this.fetchAndCacheYoklamaStatus(job);
      } catch (e) {
        this.log(`Mükerrer yoklama kontrolü yapılamadı: ${job?.is_isTakipNo || job?.akis_isTakipNo || job?.akis_oid || '-'} | ${e?.message || String(e)}`, true);
        return null;
      }
    }

    getYoklamaOrtakLabel(it, idx = 0) {
      if (it?.ortakLabel) return String(it.ortakLabel);
      const raw = String(it?.kisi || it?.ortakKimlik || it?.ortakNo || it?.aktifOrtakId || it?.vkn || it?.tckn || it?.kimlikNo || it?.vkntckn || '').replace(/\D+/g, '');
      if (!raw) return '';
      const tip = raw.length === 10 ? 'VKN' : (raw.length === 11 ? 'TCKN' : 'Kimlik');
      return `${idx + 1}. ${tip} ${raw}`;
    }

    renderYoklamaDurumCell(job) {
      const st = this.getYoklamaStatusForJob(job);
      const items = st.items || [];

      if (items.length) {
        return items.map((it) => {
          const flowItems = Array.isArray(it?.__flow) ? it.__flow : [];
          const lastFlow = flowItems.length ? ykGetLastStatus(flowItems) : null;
          let durum = lastFlow?.durum || ykGetMeaningfulDurum(lastFlow?.item) || ykGetMeaningfulDurum(it) || '-';
          if (!durum || durum === '-' || /^Durum\s*0$/i.test(durum)) {
            // Tooltipte akış görünüyorsa ekrandaki hücre de son anlamlı aşamayı yazsın.
            const flowStatuses = flowItems.map(x => ykGetMeaningfulDurum(x)).filter(Boolean).filter(x => x !== '-');
            if (flowStatuses.length) durum = flowStatuses[flowStatuses.length - 1];
          }
          const optime = lastFlow?.item?.optime || lastFlow?.item?.sonislem || lastFlow?.item?.ilkislem || it?.optime || it?.sonislem || it?.ilkislem || '';
          const flowText = flowItems.length
            ? flowItems.map(x => ykGetMeaningfulDurum(x)).filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(' → ')
            : '';
          const titleBits = [];
          if (optime) titleBits.push('Tarih: ' + optime);
          if (flowText) titleBits.push('Akış: ' + flowText);
          const title = titleBits.length ? ` title="${this.escapeHtml(titleBits.join(' | '))}"` : '';
          return `<div class="yk-line"${title}>${this.escapeHtml(durum || '-')}</div>`;
        }).join('');
      }

      return `<span class="yk-line">${this.escapeHtml(ykDurumText(st.durum || '-'))}</span>`;
    }

    renderYoklamaKodCell(job) {
      const st = this.getYoklamaStatusForJob(job);
      const items = st.items || [];
      const showOrtakLabel = typeof itIsAdiOrtaklikIseBaslamaJob === 'function' && itIsAdiOrtaklikIseBaslamaJob(job, this);

      if (items.length) {
        return items.map((it, idx) => {
          const kod = ykGetKod(it);
          const ortak = showOrtakLabel ? this.getYoklamaOrtakLabel(it, idx) : '';
          if (!kod) return `<div class="yk-line yk-muted">${ortak ? `<b>${this.escapeHtml(ortak)}</b><br>` : ''}Kod yok</div>`;
          return `<div class="yk-line">${ortak ? `<b>${this.escapeHtml(ortak)}</b><br>` : ''}<a class="preview-link yk-kod-link" data-ykodu="${this.escapeHtml(kod)}">${this.escapeHtml(kod)}</a></div>`;
        }).join('');
      }

      if (st.kod) {
        return `<a class="preview-link yk-kod-link" data-ykodu="${this.escapeHtml(st.kod)}">${this.escapeHtml(st.kod)}</a>`;
      }

      return '<span class="yk-muted">-</span>';
    }

    async fetchAndCacheYoklamaStatus(job) {
      const cacheKey = this.getYoklamaStatusCacheKey(job);
      const cached = state.ykStatusCache?.get(cacheKey);
      if (cached) {
        job.__ykStatus = cached;
        return cached;
      }

      const storedSpecial = itReadAdiOrtaklikStoredStatus(job);
      if (storedSpecial && Array.isArray(storedSpecial.items) && storedSpecial.items.length) {
        const refreshed = [];
        for (const item of storedSpecial.items) {
          const kod = ykGetKod(item);
          let merged = item;
          if (kod) {
            let bestDurum = ykGetDurumRaw(item) || item?.durum;
            let bestOptime = item?.optime;
            let flow = [];
            let liveItem = null;
            try {
              flow = await ykFetchGunlukAkis(kod);
              if (flow && flow.length) {
                const lastFlow = ykGetLastStatus(flow);
                bestDurum = lastFlow?.durum || ykGetMeaningfulDurum(lastFlow?.item) || bestDurum;
                bestOptime = lastFlow?.item?.optime || lastFlow?.item?.sonislem || lastFlow?.item?.ilkislem || bestOptime;
              }
            } catch (_) {}
            try {
              const liveItems = await ykFetchYoklamaByCode(kod);
              if (liveItems && liveItems.length) {
                liveItem = liveItems[0];
                const lastLive = ykGetLastStatus(liveItems);
                bestDurum = ykGetMeaningfulDurum(liveItem) || lastLive?.durum || ykGetMeaningfulDurum(lastLive?.item) || bestDurum;
                bestOptime = liveItem?.optime || liveItem?.sonislem || liveItem?.ilkislem || lastLive?.item?.optime || bestOptime;
              }
            } catch (_) {}
            merged = Object.assign({}, liveItem || {}, item, {
              durum: bestDurum || item?.durum,
              optime: bestOptime || item?.optime,
              __flow: flow || item?.__flow,
              kisi: item?.kisi || item?.ortakKimlik || item?.ortakNo || item?.vkn || item?.tckn || '',
              ortakKimlik: item?.ortakKimlik || item?.kisi || item?.ortakNo || '',
              ortakLabel: item?.ortakLabel || ''
            });
          }
          refreshed.push(merged);
        }
        const last = ykGetLastStatus(refreshed);
        const st = { durum: last.durum || '-', kod: last.kod || '', items: refreshed, special: 'adi_ortaklik', fetchedAt: Date.now() };
        try { const key = itSpecialKeyForJob(job); if (key) localStorage.setItem('istakip_adi_ortaklik_yoklama_' + key, JSON.stringify(st)); } catch (_) {}
        state.ykStatusCache?.set(cacheKey, st);
        job.__ykStatus = st;
        return st;
      }

      const resp = await ykFetchYoklamalarForJob(job);
      let items = ykExtractItems(resp).filter(x => ykGetKod(x) || ykGetDurumRaw(x) || x?.durum || x?.optime || x?.sonislem || x?.ilkislem);
      // v4.31.144: Servis aynı VKN için birden fazla yoklama kodu döndürdüğünde hepsi korunur.
      // Sadece aynı ykodu birebir tekrar ederse tekilleştirilir.

      const seen = new Set();
      items = items.filter(it => {
        const k = ykGetKod(it) || JSON.stringify(it).slice(0, 120);
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });

      const enriched = [];
      for (const it of items) {
        const kod = ykGetKod(it);
        let merged = it;
        if (kod) {
          try {
            const flow = await ykFetchGunlukAkis(kod);
            if (flow && flow.length) {
              const lastFlow = ykGetLastStatus(flow);
              merged = Object.assign({}, it, {
                durum: lastFlow?.durum || ykGetMeaningfulDurum(lastFlow?.item) || ykGetMeaningfulDurum(it) || ykGetDurumRaw(it) || it?.durum,
                optime: lastFlow?.item?.optime || lastFlow?.item?.sonislem || lastFlow?.item?.ilkislem || it?.optime,
                __flow: flow
              });
            }
          } catch (_) {}
        }
        enriched.push(merged);
      }

      const last = ykGetLastStatus(enriched);
      const status = {
        durum: last.durum || '-',
        kod: last.kod || '',
        items: enriched,
        cacheKey,
        fetchedAt: Date.now()
      };
      state.ykStatusCache?.set(cacheKey, status);
      job.__ykStatus = status;
      return status;
    }

    async loadYoklamaStatusesForRenderedRows() {
      const raw = Array.isArray(this.__lastRowsRaw) ? this.__lastRowsRaw : [];
      if (!raw.length) return;

      const batchSeq = (this.__ykStatusBatchSeq || 0) + 1;
      this.__ykStatusBatchSeq = batchSeq;
      this.__ykRenderTimer = this.__ykRenderTimer || null;

      // v4.31.101: İşleri Tara/Liste Yenile sonrası yoklama durumları her seferinde canlı sorgulansın.
      // Eski ykStatusCache kullanılırsa durum hücresi '-' veya eski aşamada kalabiliyor.
      const jobsToFetch = raw.slice();
      for (const job of raw) {
        try { state.ykStatusCache?.delete(this.getYoklamaStatusCacheKey(job)); } catch (_) {}
        try { delete job.__ykStatus; } catch (_) {}
      }

      this.log(`Yoklama durum/kod sorgusu başlıyor. yeni=${jobsToFetch.length}, cache=0`);
      let index = 0;
      let done = 0;
      const concurrency = 3;
      const scheduleRender = () => {
        if (this.__ykStatusBatchSeq !== batchSeq) return;
        if (this.__ykRenderTimer) return;
        this.__ykRenderTimer = setTimeout(() => {
          this.__ykRenderTimer = null;
          if (this.__ykStatusBatchSeq === batchSeq) this.renderRows(raw, true);
        }, 350);
      };

      const worker = async () => {
        while (index < jobsToFetch.length && this.__ykStatusBatchSeq === batchSeq) {
          const job = jobsToFetch[index++];
          try {
            await this.fetchAndCacheYoklamaStatus(job);
          } catch (e) {
            const status = {
              durum: 'Alınamadı',
              kod: '',
              items: [],
              error: e.message || String(e),
              fetchedAt: Date.now()
            };
            job.__ykStatus = status;
            state.ykStatusCache?.set(this.getYoklamaStatusCacheKey(job), status);
          }
          done += 1;
          if (done === 1 || done % 10 === 0 || done === jobsToFetch.length) {
            this.log(`Yoklama durum/kod ilerleme: ${done}/${jobsToFetch.length}`);
          }
          scheduleRender();
        }
      };

      await Promise.all(Array.from({ length: Math.min(concurrency, jobsToFetch.length) }, worker));
      if (this.__ykStatusBatchSeq === batchSeq) {
        if (this.__ykRenderTimer) { clearTimeout(this.__ykRenderTimer); this.__ykRenderTimer = null; }
        this.renderRows(raw, true);
        this.log(`Yoklama durum/kod sorgusu tamamlandı. yeni=${jobsToFetch.length}, cache=0`);
      }
    }

    getJobSortValue(job, key) {
      switch (key) {
        case 'istakip': return String(job?.is_isTakipNo || job?.akis_isTakipNo || '').toLocaleLowerCase('tr');
        case 'belge': return String(this.getBelgeBilgiText(job) || '').toLocaleLowerCase('tr');
        case 'tur': return String(this.getIsTuruText(job) || '').toLocaleLowerCase('tr');
        case 'unvan': return String(job?.is_unvan || job?.is_unvan_unvan || '').toLocaleLowerCase('tr');
        case 'durum': return String(job?.__sent ? 'Gönderildi' : job?.__eligible ? 'Uygun' : (job?.__excludeReason || job?.__error || 'Uygun değil')).toLocaleLowerCase('tr');
        case 'owner': return String(this.getOwnerDisplayText(job) || '').toLocaleLowerCase('tr');
        case 'islemBilgisi': return String(this.getMersisIslemBilgisiText(job) || '').toLocaleLowerCase('tr');
        case 'isAcilis': return itParseCompactDateTimeMs(itJobAcilisRaw(job));
        case 'beklenenBitis': return itParseCompactDateTimeMs(itJobBeklenenBitisRaw(job));
        case 'uzerimdeSure': return itJobKaldigiSureSort(job);
        case 'ykDurum': return String(job?.__yoklamaDurumText || job?.__yoklamaDurum || '').toLocaleLowerCase('tr');
        case 'ykKod': return String(job?.__yoklamaKodText || job?.__yoklamaKod || '').toLocaleLowerCase('tr');
        default: return '';
      }
    }

    sortJobsForDisplay(list) {
      const arr = Array.isArray(list) ? list.slice() : [];
      const sort = this.__jobSort || null;
      if (!sort?.key) return arr;
      const dir = sort.dir === 'desc' ? -1 : 1;
      arr.sort((a, b) => {
        const av = this.getJobSortValue(a, sort.key);
        const bv = this.getJobSortValue(b, sort.key);
        if (typeof av === 'number' || typeof bv === 'number') return ((Number(av) || 0) - (Number(bv) || 0)) * dir;
        return String(av || '').localeCompare(String(bv || ''), 'tr', { numeric: true, sensitivity: 'base' }) * dir;
      });
      return arr;
    }

    renderRows(list, fromFilter = false) {
      if (!fromFilter) this.__lastRowsRaw = list || [];
      const body = $('#it_rows', this.panel);
      if (!body) return;
      body.innerHTML = '';

      const sourceList = Array.isArray(list) ? list : [];
      const filteredList = this.filterJobsByVkn(sourceList);
      this.updateVknFilterInfo(sourceList.length, filteredList.length);

      if (!sourceList.length) {
        body.innerHTML = '<tr><td colspan="15" class="muted">Liste boş. Önce İŞLERİ TARA ile işleri çek.</td></tr>';
        return;
      }

      if (!filteredList.length) {
        body.innerHTML = '<tr><td colspan="15" class="muted">Kayıt geldi fakat VKN aralık filtresi nedeniyle görünür kayıt yok. VKN Başlangıç/Bitiş alanlarını temizle.</td></tr>';
        return;
      }

      const sortedList = this.sortJobsForDisplay(filteredList);

      sortedList.forEach((job, idx) => {
        const step = job.__step;
        const status = job.__sent
          ? 'Gönderildi'
          : job.__eligible
            ? `Yoklama Süreci Başlat (${step?.durumNo}/${step?.tip})`
            : (job.__excludeReason ? `Hariç: ${job.__excludeReason}` : (job.__error || 'Uygun değil'));

        const p = this.getPreviewPayload(job);
        const hasPreviewData = !!p.keysEvrakOid;
        const showGazete = itIsFirmaForTicaretSicilGazetesi(job, this);
        const gazeteHtml = showGazete ? '<br><a class="preview-link" data-gazete="1">Ticaret Sicil Gazetesi Aç</a>' : '';
        const showOrtakYon = itIsCompanyForOrtakYon(job, this);
        const ortakYonHtml = showOrtakYon ? '<br><a class="preview-link" data-ortak-yon="aktif">GİB/MERSİS Ortak Yönetici Aktif</a><br><a class="preview-link" data-ortak-yon="mersisDetay">MERSİS Ortaklık-Yöneticilik-Sermaye</a><br><a class="preview-link" data-ortak-yon="tarihce">Sicil Kayıtlarına Göre Ortaklık</a>' : '';

        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${idx + 1}</td>
          <td class="it-action-cell"><button class="it-row-action-btn" data-it-actions="1" title="İş seçeneklerini aç/kapat">⋮</button></td>
          <td class="it-is-takip-cell">${this.escapeHtml(job.is_isTakipNo || job.akis_isTakipNo || '')}<br><span class="muted">${this.escapeHtml((job.is_vergiNo || '') + ' ' + (job.is_tcKimlikNo || ''))}</span></td>
          <td>${this.escapeHtml(this.getBelgeBilgiText(job))}</td>
          <td>${this.escapeHtml(this.getIsTuruText(job))}</td>
          <td>${this.escapeHtml(job.is_unvan || job.is_unvan_unvan || '')}</td>
          <td class="${job.__sent || job.__eligible ? 'eligible' : job.__error ? 'bad' : ''}">${this.escapeHtml(status)}</td>
          <td>${this.escapeHtml(this.getOwnerDisplayText(job))}</td>
          <td class="it-mersis-islem-bilgisi">${this.escapeHtml(this.getMersisIslemBilgisiText(job))}</td>
          <td>${itFormatCompactDateTimeTR(itJobAcilisRaw(job))}</td>
          <td>${itFormatCompactDateTimeTR(itJobBeklenenBitisRaw(job))}</td>
          <td>${itJobKaldigiSureText(job)}</td>
          <td>${
            hasPreviewData
              ? `<a class="preview-link" data-preview="1">Önizle Aç</a><br><a class="preview-link" data-sicil="1">Sicil Kaydı Aç</a>${gazeteHtml}${ortakYonHtml}`
              : `<a class="preview-link disabled">Veri Yok</a><br><a class="preview-link" data-sicil="1">Sicil Kaydı Aç</a>${gazeteHtml}${ortakYonHtml}`
          }</td>
          <td class="yk-durum">${this.renderYoklamaDurumCell(job)}</td>
          <td class="yk-kod">${this.renderYoklamaKodCell(job)}</td>`;

        const link = tr.querySelector('[data-preview="1"]');
        if (link) {
          link.onclick = (ev) => {
            ev.preventDefault();
            this.openPreview(job);
          };
        }
        const sicilLink = tr.querySelector('[data-sicil="1"]');
        if (sicilLink) {
          sicilLink.onclick = (ev) => {
            ev.preventDefault();
            this.openSicilKaydi(job);
          };
        }
        const gazeteLink = tr.querySelector('[data-gazete="1"]');
        if (gazeteLink) {
          gazeteLink.onclick = (ev) => {
            ev.preventDefault();
            this.openTicaretSicilGazetesi(job);
          };
        }
        tr.querySelectorAll('[data-ortak-yon]').forEach(oyLink => {
          oyLink.onclick = (ev) => {
            ev.preventDefault();
            this.openOrtakYoneticilik(oyLink.getAttribute('data-ortak-yon'), job);
          };
        });

        tr.querySelectorAll('[data-ykodu]').forEach(ykLink => {
          ykLink.onclick = (ev) => {
            ev.preventDefault();
            const kod = ykLink.getAttribute('data-ykodu');
            const url = ykBuildSonucUrl(kod);
            if (url) ykOpenPdfPopup(url);
          };
        });

        const actionBtn = tr.querySelector('[data-it-actions="1"]');
        if (actionBtn && !actionBtn.__itMenuBound) {
          actionBtn.style.cursor = 'pointer';
          actionBtn.onclick = (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            itToggleRealActionMenuForJob(job, actionBtn, this);
          };
          actionBtn.__itMenuBound = true;
        }

        body.appendChild(tr);
      });
    }

    async openSicilKaydi(job) {
      const popup = itOpenHtmlPopup('Sicil Kaydı', itBuildLoadingHtml('Sicil Kaydı', 'Sicil kayıt bilgileri sorgulanıyor...'));
      if (!popup) throw new Error('Popup engellendi. Tarayıcı popup iznini açıp tekrar deneyin.');
      try {
        const q = itGetSicilKaydiPayload(job);
        this.log(`Sicil kaydı sorgulanıyor. VKN=${q.vkn || '-'} TCKN=${q.tckn || '-'} cmd=sicilService_sicilBilgileriSorgulaIlKodu`);
        const info = await itFetchSicilKaydiInfo(job);
        const html = itBuildSicilKaydiHtml(info, job);
        popup.document.open(); popup.document.write(html); popup.document.close();
        try { itAttachSicilPopupHandlers(popup, info, job); } catch (eh) { this.log(`Sicil popup tıklama bağlama hatası: ${eh?.message || String(eh)}`, true); }
        try { popup.focus(); } catch (_) {}
        this.log(`Sicil kaydı açıldı. VKN=${info?.data?.vkn || q.vkn || '-'} kayıtSayısı=${Array.isArray(info?.data?.vdler?.baglivd) ? info.data.vdler.baglivd.length : 0}`);
      } catch (e) {
        try { popup.document.open(); popup.document.write(itBuildErrorHtml('Sicil Kaydı Açılamadı', e?.message || String(e))); popup.document.close(); } catch (_) {}
        this.log(`Sicil kaydı açılamadı: ${e?.message || String(e)}`, true);
      }
    }

    async openTicaretSicilGazetesi(job) {
      try {
        if (!itIsFirmaForTicaretSicilGazetesi(job, this)) {
          this.log('Ticaret Sicil Gazetesi sadece firma/MERSİS kayıtları için açılır. Şahıs kaydı atlandı.');
          return;
        }
        await itOpenTicaretSicilGazetesi(job, this);
      } catch (e) {
        this.log(`Ticaret Sicil Gazetesi açılamadı: ${e?.message || String(e)}`, true);
        alert(`Ticaret Sicil Gazetesi açılamadı: ${e?.message || String(e)}`);
      }
    }

    async openOrtakYoneticilik(kind, job) {
      try {
        if (!itIsCompanyForOrtakYon(job, this)) {
          this.log('Ortaklık/Yöneticilik ekranları sadece şirket/MERSİS kayıtları için açılır. Şahıs kaydı atlandı.');
          return;
        }
        await itOpenOrtakYonPopup(kind, job, this);
      } catch (e) {
        this.log(`Ortaklık/Yöneticilik açılamadı: ${e?.message || String(e)}`, true);
        alert(`Ortaklık/Yöneticilik açılamadı: ${e?.message || String(e)}`);
      }
    }

    async scan() {
      this.saveSettings();
      const s = this.getSettings();
      renderDiscovery();
      if (!this.assertDiscovery(s)) return;
      try { state.ykStatusCache?.clear(); } catch (_) {}
      try { state.jobs.forEach(j => { try { delete j.__ykStatus; } catch (_) {} }); } catch (_) {}
      this.log('İş türleri ve iş listesi çekiliyor... (cache kullanılmayacak)');
      try {
        const counts = await post(CFG.COMMANDS.ACTIVE_COUNTS, { userId: s.userId, nodeId: '' });
        const map = this.rebuildDetailMapFromCounts(counts);
        this.log(`İş türü eşleştirmeleri yüklendi. adet=${Object.keys(map).length}`);
      } catch (e) {
        state.detailMap = {};
        this.log(`İş türü eşleştirmeleri yüklenemedi: ${e.message || String(e)}`, true);
      }
      let pageResult;
      try {
        pageResult = await this.fetchAllJobsPaged(s, 'İşleri Tara');
        pageResult = await this.fetchBirimVeKullaniciIsleri(s, pageResult);
      } catch (e) {
        this.log(e.message || String(e), true);
        return;
      }
      state.jobs = pageResult.jobs || [];
      state.eligibleJobs = [];
      try {
        this.log('MERSİS işlem bilgileri EVDB Rapor listesinden çekiliyor...');
        const info = await itEnrichMersisIslemBilgileriForJobs(state.jobs, this);
        if (info.total) this.log(`MERSİS işlem bilgisi tamamlandı. eşleşen=${info.matched}/${info.total}${info.skipped ? ', tarih bulunamayan=' + info.skipped : ''}`);
      } catch (e) {
        this.log(`MERSİS işlem bilgisi alınamadı: ${e.message || String(e)}`, true);
      }
      this.renderRows(state.jobs);
      this.log(`Toplam ${state.jobs.length}/${pageResult.totalCount} iş geldi. Listeye döküldü; sonraki adımlar kontrol ediliyor...`);
      for (let i = 0; i < state.jobs.length; i++) {
        if (state.stopRequested) break;
        const job = state.jobs[i];
        try {
          const excludeReason = this.shouldExcludeFromYoklama(job);
          if (excludeReason) {
            job.__eligible = false;
            job.__excludeReason = excludeReason;
            const tag = job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid;
            this.log(`${i + 1}/${state.jobs.length} ${tag} → hariç (${excludeReason})`);
            continue;
          }

          const next = await post(CFG.COMMANDS.NEXT_STEPS, { orgoid: s.orgoid, akisOid: job.akis_oid });
          const steps = next?.data?.hedefAdimlar || [];
          job.__steps = steps;
          const step = steps.find(x => String(x?.aciklama || '').toLowerCase().includes('yoklama süreci başlat')) || null;
          job.__step = step;
          job.__eligible = !!step;
          if (job.__eligible) state.eligibleJobs.push(job);
          const tag = job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid;
          this.log(`${i + 1}/${state.jobs.length} ${tag} → ${job.__eligible ? `uygun (durumNo=${step?.durumNo}, tip=${step?.tip}, akisNo=${step?.akisNo})` : 'uygun değil'}`);
          if (i === 0 || job.__eligible || (i + 1) % 5 === 0 || i === state.jobs.length - 1) {
            this.renderRows(state.jobs, true);
          }
        } catch (e) {
          job.__eligible = false;
          job.__error = e.message || String(e);
          this.log(`${i + 1}/${state.jobs.length} ${job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid} kontrol hatası: ${job.__error}`, true);
          if (i === 0 || (i + 1) % 5 === 0 || i === state.jobs.length - 1) {
            this.renderRows(state.jobs, true);
          }
        }
      }
      this.renderRows(state.jobs);
        this.loadYoklamaStatusesForRenderedRows();
      this.log(`Tarama bitti. Uygun iş sayısı: ${state.eligibleJobs.length}`);
    }

    async sendEligible() {
      const s = this.getSettings();
      renderDiscovery();
      if (!this.assertDiscovery(s)) return;
      const list = state.eligibleJobs.length ? state.eligibleJobs : state.jobs.filter(x => x.__eligible);
      if (!list.length) {
        this.log('Gönderilecek uygun iş yok. Önce İŞLERİ TARA çalıştır.', true);
        return;
      }
      state.running = true;
      state.stopRequested = false;
      $('#it_stop', this.panel).style.display = '';
      if (!confirm(`Uygun ${list.length} iş Yoklama Süreci Başlat adımına gönderilecek. Devam edilsin mi?`)) {
        state.running = false;
        $('#it_stop', this.panel).style.display = 'none';
        this.log('Gönderim kullanıcı tarafından iptal edildi.');
        return;
      }
      this.log(`Uygun işleri doğrudan servisten gönderme başlıyor. Adet=${list.length}`);
      for (let i = 0; i < list.length; i++) {
        if (state.stopRequested) break;
        const job = list[i];
        const tag = job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid;
        try {
          // v4.31.72: Sistem "Yoklama Süreci Başlat" adımını göstermeye devam etse bile,
          // aynı iş için yoklama kodu varsa otomatik akış mükerrer yoklama oluşturmasın.
          await this.refreshYoklamaStatusNoCache(job);
          if (this.hasExistingYoklamaForJob(job)) {
            job.__eligible = false;
            job.__excludeReason = 'Mevcut yoklama kodu var; mükerrer engellendi';
            const st0 = this.getYoklamaStatusForJob(job);
            const kodlar = (st0.items || []).map(x => ykGetKod(x)).filter(Boolean).join(', ') || st0.kod || '-';
            this.log(`${i + 1}/${list.length} ${tag} atlandı: mevcut yoklama kodu var (${kodlar}). Mükerrer gönderilmedi.`);
            continue;
          }

          if (!job.__step) {
            this.log(`${tag} için adım bilgisi yok; atlandı.`, true);
            continue;
          }
          const payload = this.buildSavePayload(job, job.__step, s);
          await post(CFG.COMMANDS.SAVE_STEP, payload);
          job.__sent = true;
          this.log(`${i + 1}/${list.length} ${tag} gönderildi. hedefDurumNo=${payload.hedefDurumNo}, akisDurumTip=${payload.akisDurumTip}, orgoid=${payload.orgoid}`);
        } catch (e) {
          job.__sendErr = e.message || String(e);
          this.log(`${i + 1}/${list.length} ${tag} gönderim hatası: ${job.__sendErr}`, true);
        }
      }
      this.renderRows(state.jobs);
        this.loadYoklamaStatusesForRenderedRows();
      await this.refreshAfterSave();
      $('#it_stop', this.panel).style.display = 'none';
      state.running = false;
      this.log(state.stopRequested ? 'İşlem durduruldu.' : 'Gönderim tamamlandı.');
    }

    async refreshAfterSave() {
      const s = this.getSettings();
      renderDiscovery();
      if (!this.assertDiscovery(s)) return;
      try {
        const counts = await post(CFG.COMMANDS.ACTIVE_COUNTS, { userId: s.userId, nodeId: '' });
        const toplam = counts?.data?.toplamIs;
        const map = this.rebuildDetailMapFromCounts(counts);
        if (typeof toplam !== 'undefined') this.log(`Aktif iş sayıları yenilendi. toplamIs=${toplam}`);
        this.log(`İş türü eşleştirmeleri yenilendi. adet=${Object.keys(map).length}`);
      } catch (e) {
        this.log(`Aktif iş sayıları yenilenemedi: ${e.message || String(e)}`, true);
      }
      try {
        let pageResult = await this.fetchAllJobsPaged(s, 'Liste yenileme');
        pageResult = await this.fetchBirimVeKullaniciIsleri(s, pageResult);
        state.jobs = pageResult.jobs || [];
        try {
          this.log('MERSİS işlem bilgileri EVDB Rapor listesinden yenileniyor...');
          const info = await itEnrichMersisIslemBilgileriForJobs(state.jobs, this);
          if (info.total) this.log(`MERSİS işlem bilgisi yenilendi. eşleşen=${info.matched}/${info.total}${info.skipped ? ', tarih bulunamayan=' + info.skipped : ''}`);
        } catch (e) {
          this.log(`MERSİS işlem bilgisi yenilenemedi: ${e.message || String(e)}`, true);
        }
        // v4.31.72: Müdüre/koordinatöre gönderme veya EYS tarafında yapılan işlemden sonra
        // Yoklama Durum/Kod hücreleri eski cache'den gelmesin; Listeyi Yenile her seferinde canlı sorgulasın.
        try { state.ykStatusCache?.clear(); } catch (_) {}
        try { state.jobs.forEach(j => { try { delete j.__ykStatus; } catch (_) {} }); } catch (_) {}
        this.log(`Liste yenilendi. Güncel iş sayısı=${state.jobs.length}/${pageResult.totalCount}. Yoklama durumları canlı yenilenecek.`);
        this.renderRows(state.jobs);
        this.loadYoklamaStatusesForRenderedRows();
      } catch (e) {
        this.log(`Liste yenilenemedi: ${e.message || String(e)}`, true);
      }
    }
  }


  function ensureRestoreButton(show = true) {
    // v4.31.57: Geri-açma butonu panel düzenini bozduğu için tamamen kapatıldı.
    try { const old = document.getElementById(CFG.RESTORE_ID); if (old) old.remove(); } catch (_) {}
    return null;
  }

  function shouldLoad() {
    const href = String(location.href || '').toLowerCase();
    const host = String(location.hostname || '').toLowerCase();
    return host.includes('keys.ggm.bim') || href.includes('keys.ggm.bim') || href.includes('/gp/') || href.includes('takdire-sevk');
  }

  function ensurePanelLive(forceOpen = false) {
    try {
      injectStyle();
      if (!document.body && !document.documentElement) {
        setTimeout(() => ensurePanelLive(forceOpen), 300);
        return;
      }
      itChromeStorageGetSafe([CFG.UI_KEY], out => {
        const ui = out?.[CFG.UI_KEY] || {};
        // v4.31.57: Eski sürümlerden kalan kalıcı closed bayrağını dikkate alma.
        // Panel kapatılırsa sadece mevcut sayfada kapalı kalsın; geri-aç butonu üretme.
        if (ui && ui.closed) { try { itChromeStorageSetSafe({ [CFG.UI_KEY]: { closed: false, minimized: false } }); } catch (_) {} }
        const closed = !!window.__istakipBotManualClosed && !forceOpen;
        if (closed) return;
        if (!document.getElementById(CFG.PANEL_ID)) {
          const panel = createPanel();
          window.__istakipBotInstanceV427 = new Bot(panel);
          setupUnifiedModuleTabs();
          bindMainPanelMoveAndResize(panel);
        }
      });
    } catch (_) {
      if (document.body || document.documentElement) {
        if (!document.getElementById(CFG.PANEL_ID)) {
          const panel = createPanel();
          window.__istakipBotInstanceV427 = new Bot(panel);
          setupUnifiedModuleTabs();
          bindMainPanelMoveAndResize(panel);
        }
      } else {
        setTimeout(() => ensurePanelLive(forceOpen), 300);
      }
    }
  }

  if (!shouldLoad()) return;
  wirePageMessages();
  injectPageHook();
  patchNetwork();
  restoreDiscovery(() => {
    ensurePanelLive(false);
    document.addEventListener('DOMContentLoaded', () => setTimeout(() => ensurePanelLive(false), 150));
    window.addEventListener('pageshow', () => setTimeout(() => ensurePanelLive(false), 300));
    window.addEventListener('load', () => setTimeout(() => ensurePanelLive(false), 500));
    document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(() => ensurePanelLive(), 200); });
    setInterval(() => {
      if (!document.getElementById(CFG.PANEL_ID) && shouldLoad()) ensurePanelLive();
    }, 1500);
  });


// v4.31.46: Sonradan eklenen VKN filtre patch'lerinin kullandığı yardımcılar.
// Önceki pakette bu fonksiyonlar tanımlı olmadığı için arka planda hata oluşabiliyor
// ve liste renderı kararsızlaşabiliyordu. Boş filtrede hiçbir satırı gizlemez.
function getCurrentVknFilter(panel){
  try {
    return onlyDigits(panel?.querySelector('#it_filter')?.value || '').slice(0, 11);
  } catch (_) { return ''; }
}

function rowMatchesTypedVkn(tr, vkn){
  try {
    const needle = onlyDigits(vkn || '');
    if (!needle) return true;
    const raw = onlyDigits(tr?.innerText || tr?.textContent || '');
    return raw.includes(needle);
  } catch (_) { return true; }
}

function getVknRange(panel){
  try {
    const start = onlyDigits(panel?.querySelector('#it_vkn_start')?.value || '').slice(0,10);
    const end = onlyDigits(panel?.querySelector('#it_vkn_end')?.value || '').slice(0,10);
    return { start, end };
  } catch (_) { return { start:'', end:'' }; }
}

function parseTaxNoFromRow(tr){
  try { return getVknFromRow(tr); } catch (_) { return ''; }
}

function getVknFromIsTakipRow(tr){
  try { return getVknFromRow(tr); } catch (_) { return ''; }
}

function applyVknRangeFilter(panel){
  try {
    const range = getVknRange(panel);
    const rows = getRowsFromTable(panel);
    if (!range.start && !range.end) {
      rows.forEach(tr => { tr.style.display = ''; });
      return;
    }
    rows.forEach(tr => {
      const vkn = getVknFromRow(tr);
      tr.style.display = inVknRange(vkn, range.start, range.end) ? '' : 'none';
    });
  } catch (_) {}
}

function ensureVknRangeRow(panel){
  // Alanlar ana HTML içinde zaten var; burada sadece eksik paket hatasını önlüyoruz.
  return panel;
}

window.addEventListener('resize', () => {
  const panel = document.getElementById(CFG.PANEL_ID);
  if (panel) fitPanelToViewport(panel);
}, { passive: true });

function stabilizeMainPanelLayout(panel){
  // v4.31.57: Önceki sürümlerde her 300 ms'de yapılan zorlayıcı flex/height müdahalesi,
  // panel önce doğru açılıp sonra altının siyah boşluğa dönmesine sebep oluyordu.
  // Burada sadece istenen alanları gizli tutuyoruz; mevcut doğal yerleşime dokunmuyoruz.
  try{
    if (!panel) return;
    const r = document.getElementById(CFG.RESTORE_ID);
    if (r) r.remove();
    panel.querySelectorAll('.hide-above-buttons,.it-main-advanced').forEach(el => { el.style.display = 'none'; });
    const disc = panel.querySelector('.disc');
    if (disc) {
      disc.style.display = 'none';
      disc.style.height = '0px';
      disc.style.minHeight = '0px';
      disc.style.padding = '0px';
      disc.style.margin = '0px';
      disc.style.overflow = 'hidden';
    }
    const actionRow = panel.querySelector('.it-main-actions') || panel.querySelector('#it_scan')?.closest('.row3');
    if (actionRow) {
      actionRow.classList.add('it-main-actions');
      actionRow.style.height = '';
      actionRow.style.maxHeight = '';
      actionRow.style.overflow = '';
    }
  }catch(e){}
}

setInterval(() => {
  try{
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    stabilizeMainPanelLayout(panel);
    hideUpperFilterRows(panel);
    ensureHeaderVknFilter(panel);
    applyHeaderVknFilter(panel);
    const s = panel.querySelector('#it_vkn_start');
    const e = panel.querySelector('#it_vkn_end');
    if (s && !s.__vknBind55) {
      const run = () => { applyHeaderVknFilter(panel); };
      ['input','change','keyup'].forEach(ev => s.addEventListener(ev, run));
      if (e) ['input','change','keyup'].forEach(ev => e.addEventListener(ev, run));
      const scan = panel.querySelector('#it_scan');
      const refresh = panel.querySelector('#it_refresh');
      if (scan) scan.addEventListener('click', () => setTimeout(run, 1200));
      if (refresh) refresh.addEventListener('click', () => setTimeout(run, 500));
      s.__vknBind55 = true;
      if (e) e.__vknBind55 = true;
    }
    if (!panel.__headVknObserverBound55) {
      const wrap = panel.querySelector('.tblwrap');
      if (wrap) {
        const mo = new MutationObserver(() => { applyHeaderVknFilter(panel); });
        mo.observe(wrap, { childList:true, subtree:true, characterData:true });
        panel.__headVknObserverBound55 = true;
      }
    }
  }catch(e){}
}, 300);

try { setInterval(setupUnifiedModuleTabs, 700); } catch (_) {}
try { setInterval(() => bindMainPanelMoveAndResize(document.getElementById(CFG.PANEL_ID)), 700); } catch (_) {}

})();

// v4.31.174: MERSİS EVDB Rapor sorgusunda ilk tarih eşleşmezse önceki gün fallback sorgusu eklendi (arefe/yarım gün tatil).
