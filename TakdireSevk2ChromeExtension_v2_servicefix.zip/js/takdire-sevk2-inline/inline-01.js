/* === GÜVENLİ JSON PARSE (RECURSION-PROOF) + AJAX HATA GÜNLÜĞÜ === */
(function(){
  // recursion-proof parse helper
  window.safeJsonParse = function(payload, label){
    if (payload && typeof payload === "object") return payload;
    if (payload == null) {
      console.warn("[GİB] Boş cevap (null).", label || "");
      return null;
    }
    var txt = String(payload);
    if (!txt || txt.trim() === "") {
      console.warn("[GİB] Boş cevap (empty).", label || "");
      return null;
    }
    try {
      return window.JSON.parse(txt);
    } catch (e) {
      console.error("[GİB] JSON parse edilemedi.", label || "", e, "Cevap(ilk 500):", txt.slice(0,500));
      return null;
    }
  };

  window.safeJsonParseText = function(text, label){
    if (!text || typeof text !== "string" || text.trim() === "") {
      console.warn("[GİB] Boş cevap (text).", label || "");
      return null;
    }
    try { return window.JSON.parse(text); }
    catch(e){
      console.error("[GİB] JSON parse edilemedi (text).", label || "", e, "Cevap(ilk 500):", text.slice(0,500));
      return null;
    }
  };

  if (window.jQuery && jQuery.ajaxSetup) {
    jQuery.ajaxSetup({
      cache: false,
      error: function(xhr, status, err){
        var resp = (xhr && xhr.responseText) ? xhr.responseText : "";
        console.error("[GİB] AJAX hata:", (xhr?xhr.status:"?"), status, err || "", "Cevap(ilk 500):", resp.slice(0,500));
      }
    });
  }
})();
