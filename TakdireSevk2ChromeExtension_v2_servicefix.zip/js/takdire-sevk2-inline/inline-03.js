function __tk_sadece0015(){
    var donemler=[];
    try{
        $("#myTable6 tbody tr, #table6 tbody tr").each(function(){
            var d=$(this).find("td").eq(2).text().trim();
            if(d!==""){ donemler.push(d); }
        });
    }catch(e){}
    if(donemler.length===0) return false;
    return donemler.every(function(x){ return x === "0015"; });
}



$('#go').click(function() {

  
 
 tabloSil();
 


var myRegex= /[0-9]+/;
var tokenlink =$('#token').val();
var myRegexp= /token=([^&\s]+)/;
var token = myRegexp.exec(tokenlink);

// Not: Bu dosyada bazı yerlerde `var token = ...` kullanıldığı için
// `token()` fonksiyonu aynı scope'ta gölgelenebiliyor. Bu yardımcı,
// her zaman global `window.token()` fonksiyonundan token'ı alır.
function _tok(){
  try {
    if (window.token && typeof window.token === 'function') {
      return window.token();
    }
  } catch(e) {}
  return (token && token[1]) ? token[1] : null;
}
var callid=makeid(13) + '-';
var vkno=$('#input').val();
document.getElementById('vknFirst3').innerHTML=vkno.substring(0,3);
var bastar="19800101";
var vd_kodu=vdKodu();

var takdirDonem=new Array();
    
var bittar= new Date();

var bittar_yil=bittar.getFullYear();

var bittar=bittar_yil + "3112";
      
      
      var iliski_tur_dizi={'3':'3 - Genel Müdür; Şirket Müdürü','2':'2 - Yönetim Kurulu Üyesi'};
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};
      var potansiyelListe ={'1':'Potansiyel Değil', '9':'Potansiyel'};
      var isyeriNitelikListe ={'1':'Merkez', '2':'Şube', '3':'Depo', '4':'KDV İhtisas Şubesi'};
        
	
      ////////////////////////////////////////// Mükellefin sicil bilgilerini getiriyor

	   $('#tablo1').after(' <table class="w3-table" id="myTable10" border=1> <tr> <th>SMS</th><th>Gönüllü Uyum</th><th>İstisna Dilekçesi</th><th>E-Tebligat</th><th>9047</th> </tr>');
      
      $('#tablo1').after(' <table class="w3-table" id="myTable5" border=1> <caption>Araştırılan Firmanın</caption>   <tr>     <th>Vergi No</th>     <th>TC</th>    <th>Ünvan</th> <th>Özel Esas</th><th>FETÖ</th></tr>');

      
      $('#tablo2').after('<table id="myTable4" border=1><caption>Mükellefiyet Bilgileri</caption><tr><th>İŞ YERİ NİTELİK</th><th>DAİRE KODU</th><th>DAİRE ADI</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAAL TERK</th></tr>');
      
      
      var url5= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
      //var url5=url5.concat(callid + '15', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var url5=url5.concat(callid + '15', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var __tmp=daireler; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};

      var vkn=obj.data.vkn; 
      var tckn=obj.data.tckn; 
      var unvan=obj.data.kimlikunvan; 
      var sirketturu=obj.data.sirketturu;
      var oz_es =ozel_esas(vkn, _tok());
      var feto=fetoSorgu(vkn, _tok());
      var birimOid="";
      var subeno="";
      var isyerituru="1";
      var isyerinitelik="";
      var mukblgoid="";
	  var tahakkuk9047 = "?";
	  var tarhiyat9047 = "?";
	  try { tahakkuk9047 = tahakkukSorgula(_tok(),vkn,vd_kodu,"9047"); } catch(e) { console.log("9047 tahakkuk hatasi", e); }
	  try { tarhiyat9047 = tarhiyatSorgula(_tok(),vkn,vd_kodu,"9047"); } catch(e) { console.log("9047 tarhiyat hatasi", e); }
	
    
	  var tip = (!tckn || String(tckn).trim() === "") ? "2" : "1";
      var eTebligat = "Sorgulanamadi";
      try { eTebligat = eTebligatVarmi(vkn, tip, _tok()); } catch(e) { console.log("eTebligat hatasi", e); }

      $("#myTable5 tr:last").after( "<tr><td>" + vkn  + "</td><td>" + tckn  + "</td><td>" + unvan + "</td><td>" + oz_es + "</td><td>" + feto + "</td></tr>");
	
	  $("#myTable10 tr:last").after( "<tr><td>"  + smsVarmi(vkn, _tok()) + "</td><td>"  + gonulluUyum(vkn, _tok()) + "</td><td>" + istisnaDilekcesiVarmi(vkn, _tok()) +"</td><td>" +  eTebligat +"</td><td>" + tahakkuk9047 + "-" + tarhiyat9047 +  "</td></tr>");
	

	
      ///////////////////////////////////////////////Sicil bilgilerinde yer alan nevi değişikliği veya diğer bilgilerin yazdırılması sağlanıyor
	  
	  var sicil_mesaj_liste=obj.data.hatakontrol;
	  
	  if (sicil_mesaj_liste!=undefined){
	  
	  $.each(sicil_mesaj_liste,function(index,satir){
	  
	     $("#myTable5 tr:last").after( "<tr><td colspan='8'>" + satir.mesaj + "</td></tr>");
	  
	  });
	  
	  }
	
	///////////////////////////////////////////////////Temel Bilgi Değişikliği var mı?
	
	//
	try{  
	var url_temel= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=sicilService_temelBilgiDegisiklikSorgula&callid=';
	var url_temel=url_temel.concat(callid + '22', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%7D');
	var temel_bilgi = getRemote(url_temel);
	var obj_temel_bilgi =JSON.parse(temel_bilgi);  

	var temel_bilgi_degisikligi =  obj_temel_bilgi.data.degisiklikBilgileri.tuzelDegisiklik;
	
	  if (temel_bilgi_degisikligi!=undefined){
	    
		$.each(temel_bilgi_degisikligi,function(index,satir){
		
		 var kisaUnvan = satir.kisaunvan;
		 
		 if (kisaUnvan!=undefined){
		 
		    if (kisaUnvan.includes("YENİ KURULACAK")==false){
		
			$("#myTable5 tr:last").after( "<tr><td colspan='8'>" + kisaUnvan + "- İşlem tarihi " + tarih(satir.islemtarihi) + "</td></tr>");
		  
		      }
		      
		  }
		
		});
	  
	  }
}

	catch(err){
				$("#myTable5 tr:last").after( "<tr><td colspan='8'style='color:red;'>Temel Bilgi Değişikliği Sorgularken Hata ile Karşılaşıldı</td></tr>");

}	  
	  ////

	 	mukellefinadiOrtaklikSorgulu(vkn,_tok());


	  var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	  var b=0;    

	 var faaliyetDizi =new Array();
	 

	$.each(daireListesi, function(index, satir){
	
	
	  var daireadi=satir.vdadi; 
	  var vdkodu=satir.vdkodu;
	  var isyerinitelik = satir.isyerinitelik;
	  var birimOid= satir.birimoid;
	  var subeno = satir.subeno;
	  var subeadi=satir.subeadi;
	  var isyerinitelik=satir.isyerinitelik;
	  var isyerituru= satir.isyerituru;
	  var mukblgoid=satir.mukblgoid;
	  var isyerinitelik = isyeriNitelikListe[isyerinitelik];
	 
	  
	 
	 
	  
	  ////////////fAALİYET BİLGİLERİNİ GETİRECEZ


	$("#myTable5 tr:last").after( "<tr><td colspan='9' id='faaliyetBilgileri' ></td></tr>");
	
	
	
	  if (vdkodu==vd_kodu) {

		try{
	  
	      var urlFaaliyet= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=sicilService_mukSicilDetayBilgileriGetir&callid=';
	      var urlFaaliyet=urlFaaliyet.concat(callid + '56', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22birimOid%22%3A%22',birimOid,'%22%2C%22subeno%22%3A%22',subeno,'%22%2C%22subeadi%22%3A%22%22%2C%22isyerituru%22%3A%22',isyerituru,'%22%2C%22isyerinitelik%22%3A%22',isyerinitelik,'%22%2C%22mukblgoid%22%3A%22',mukblgoid,'%22%7D');
	      var faaliyet = getRemote(urlFaaliyet);
	      var objFaaliyet =JSON.parse(faaliyet);
	      
		  var faaliyetListesi=objFaaliyet.data.faaliyetListesi.faaliyet;
		  
		  $.each(faaliyetListesi, function(index, satir1){
		  
		  	  
		  	faaliyetDizi.push(satir1.faaliyetkod + "-" + satir1.faaliyetad + "<br>");
		  
		  
		  });

			document.getElementById('faaliyetBilgileri').innerHTML= removeDuplicates(faaliyetDizi);

		}

		catch(err){

			document.getElementById('faaliyetBilgileri').innerHTML= "Faaliyet Bilgileri sorgularken Hata ile karşılaşıldı" + err;

	

		}
		
	  }

	  //////////////////////////////
	  
	      var bastarih =tarih(satir.isebaslamatarihi);  	      
	      var bittarih =tarih(satir.isibirakmatarihi);
	      
	      var mukblgislemturubittur=satir.mukblgislemturubittur;
	      var faal = terkdurumu[mukblgislemturubittur];
	    
	      $("#myTable4 tr:last").after( "<tr><td>" + isyerinitelik + "</td><td>" + vdkodu  + "</td><td>" + daireadi  + "</td><td>" + bastarih  + "</td><td>" + bittarih  + "</td><td>" + faal  + "</td></tr>");
	

	});
	
$('#tablo3').after(
  '<table id="myTable6" style="table-layout:fixed; width:100%;">' +
    '<caption>Mükellefin Takdire Sevk Bilgileri</caption>' +

    // 1. başlık satırı
    '<tr>' +
      '<th style="width:2%;" rowspan="2">Seç</th>' +
      '<th style="width:5%;" rowspan="2">Vergi Kodu</th>' +
      '<th style="width:5%;" rowspan="2">Dönemi</th>' +
      '<th style="width:7%;" rowspan="2">TS Fiş No</th>' +
      '<th style="width:16%;" colspan="2">Mal ve Hizmet Satılan Mük. İlişkin</th>' +
      '<th style="width:8%;" rowspan="2">Banka Kredi Kartı<br>Sorgulama</th>' +
      '<th style="width:8%;" rowspan="2">Eski Tak. Kom. Kararı</th>' +
      '<th style="width:8%;" rowspan="2">İlgili Dönem<br>Matrah</th>' +
      '<th style="width:24%;" colspan="3">Takdir Komisyonu Kararı</th>' +
      '<th style="width:22%;" rowspan="2">Açıklama</th>' +
    '</tr>' +

    // 2. başlık satırı
    '<tr>' +
      '<th style="width:8%;">Satış</th>' +
      '<th style="width:8%;">Karşıt Alış</th>' +
      '<th style="width:8%;">Beyan Olunan</th>' +
      '<th style="width:8%;">Takdir Edilen</th>' +
      '<th style="width:8%;">Fark</th>' +
    '</tr>' +

    '<tbody></tbody>' +
  '</table>'
);    

// myTable11 (Önceki Takdir Komisyonu Kararları) tablosu bazı akışlarda doğrudan dolduruluyor.
// Bu yüzden tabloyu burada mutlaka oluşturuyoruz (aksi halde satır ekleme sırasında tablo bulunamayabilir).
$('#myTable6').after(
  '<table id="myTable11" style="table-layout:fixed; width:100%;">' +
    '<caption>Önceki Takdir Komisyonu Kararları</caption>' +
    '<tr>' +
      '<th style="width:8%;">Vergi Kodu</th>' +
      '<th style="width:14%;">Dönem</th>' +
      '<th style="width:14%;">TS Fiş No</th>' +
      '<th style="width:14%;">Karar No</th>' +
      '<th style="width:14%;">Karar Tarihi</th>' +
      '<th style="width:36%;">Matrah</th>' +
    '</tr>' +
    '<tbody></tbody>' +
  '</table>'
);

try{
      var url5= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=mhkTakdireSevkService_takdireSevkSorgulama&callid=';
      var url5=url5.concat(callid + '23', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22vergikodu%22%3A%22%22%2C%22basdonem%22%3A%22%22%2C%22bitdonem%22%3A%22%22%7D');
      var takdireSevk = getRemote(url5);
      var __tmp=takdireSevk; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};
      var a=1;
      
      var takdireSevkListesi = obj.data.tsler; /// vergi dairesi listeliyor

      // --- OTOMATİK POS / SATIŞ-KARŞIT ALIŞ SORGUSU İÇİN KURAL ---
      // Eğer takdire sevk sadece 0012 vergi kodundan oluşuyorsa veya sadece 0003 vergi kodundan oluşuyorsa
      // otomatik POS ve satış/karşıt alış motorunu çalıştırma.
      var __skipAutoPosSatisKarsit__ = false;
      try {
        var __vkSet__ = {};
        if (Array.isArray(takdireSevkListesi)) {
          $.each(takdireSevkListesi, function(_i, _s){
            var __vk = (_s && _s.vergikodu != null) ? String(_s.vergikodu).trim() : "";
            if (__vk) __vkSet__[__vk] = true;
          });
        }
        var __vks__ = Object.keys(__vkSet__);
        if (__vks__.length === 1 && (__vks__[0] === "0012" || __vks__[0] === "0003")) {
          __skipAutoPosSatisKarsit__ = true;
        }
      } catch(_e) {}


      // --- Takdir Komisyonu Kararı (geçmiş matrah) lookup: vergikodu|donem -> (en yeni kararın) matrah ---
      // Not: Aynı dönem için birden fazla karar olabiliyor; bu yüzden karartarihi en yeni olanı baz alıyoruz.
      var __takdirKararMatrahMap__ = {};
      try {
        if (Array.isArray(takdireSevkListesi)) {
          $.each(takdireSevkListesi, function(_i, _s){
            var _kararlar = (_s && Array.isArray(_s.kararlar)) ? _s.kararlar : [];
            if (_kararlar.length === 0) return;

            var _key = String(_s.vergikodu||'') + '|' + String(_s.donem||'');

            $.each(_kararlar, function(_j, _k){
              if (!_k) return;

              var _matrahRaw = (_k.matrah != null) ? String(_k.matrah).trim() : '';
              if (_matrahRaw === '') return;

              // karartarihi bazen YYYYMMDD, bazen farklı format gelebilir; _toYYYYMMDD ile normalize ediyoruz.
              var _dtStr = _toYYYYMMDD(_k.karartarihi);
              var _dtNum = _dtStr ? parseInt(_dtStr, 10) : 0;

              var prev = __takdirKararMatrahMap__[_key];
              var prevDtNum = (prev && prev.dtNum) ? prev.dtNum : 0;

              if (!prev || _dtNum >= prevDtNum) {
                __takdirKararMatrahMap__[_key] = { dtNum: _dtNum, matrah: tlCevir(_k.matrah) };
              }
            });
          });
        }
      } catch(_e) {
        // sessiz geç
      }

	$.each(takdireSevkListesi, function(index, satir){

	// --- NULL-SAFE: kararlar her zaman dizi olsun ---
	var kararlar = (satir && Array.isArray(satir.kararlar)) ? satir.kararlar : [];
	var ilkKarar = (kararlar.length > 0) ? kararlar[0] : null;
	var kararno  = (ilkKarar && ilkKarar.kararno != null) ? String(ilkKarar.kararno) : "";
	
	if (kararno=='') {
		// Satış/Karşıt Alış batch: sadece 0015 satırlarında dolacak
		var __bsRowAttr__ = "";
	
	  	takdirDonem.push(satir.donem.substr(0,4));
	   
	   if (satir.vergikodu =="0015") {

		// Satış / Karşıt Alış sorgusu artık toplu (batch) çalışıyor.
		// Burada sadece placeholder basıyoruz; sonuçlar tablo kurulduktan sonra dolduruluyor.
		var _y = satir.donem.substr(0,4);
		var _a = satir.donem.substr(4,2);

		var bs = "Yükleniyor";
		var karsitAlis = "Yükleniyor";

		var matrah = kdvMatrahgetir1(vkno, _y, _a, _tok());
		// POS/Banka ve Satış/Karşıt Alış tüm yıl motoru tarafından doldurulacak (mükerrer sorgu yok)
		var krediKarti = "Yükleniyor";

		// satıra yazacağımız data-* attribute'ları için
		var __bsRowAttr__ = " class='takkom-row bs-row bs-pending' data-vergikodu='" + satir.vergikodu + "' data-donem='" + satir.donem + "' data-yil='" + _y + "' data-ay='" + _a + "' ";

		}else if(satir.vergikodu =="0001"|| satir.vergikodu =="0010"){

	 		var matrah= beyanMatrahTakkomKuralli(vkno,tckn,satir.vergikodu,satir.donem.substr(0,6),satir.donem.substr(-6),orgIDGetir(vd_kodu),_tok());
			var bs ="Yükleniyor";
			var karsitAlis="Yükleniyor"; 
			var krediKarti="Yükleniyor";
			var __bsRowAttr__ = " class='takkom-row' data-vergikodu='" + satir.vergikodu + "' data-donem='" + satir.donem + "' data-yil='" + satir.donem.substr(0,4) + "' ";
		
		}else{
		
  		    var matrah= beyanMatrahTakkomKuralli(vkno,tckn,satir.vergikodu,satir.donem.substr(0,6),satir.donem.substr(-6),orgIDGetir(vd_kodu),_tok());
			var bs ="Yükleniyor";
			var karsitAlis="Yükleniyor"; 
			var krediKarti="Yükleniyor";
			var __bsRowAttr__ = " class='takkom-row' data-vergikodu='" + satir.vergikodu + "' data-donem='" + satir.donem + "' data-yil='" + satir.donem.substr(0,4) + "' ";

		}

		// --- Tak.Kom.Kararı sütunu için lookup (en yeni kararın matrahı) ---
		var __tkObj__ = __takdirKararMatrahMap__[String(satir.vergikodu||'') + '|' + String(satir.donem||'')];
		var __takdirKararMatrah__ = (__tkObj__ && __tkObj__.matrah) ? __tkObj__.matrah : "";
		
	     $("#myTable6 tr:last").after(
  "<tr" + __bsRowAttr__ + ">" +
    "<td style='text-align:center;'><input type='checkbox' class='row-select'></td>" +
    "<td>" + satir.vergikodu + "</td>" +

    "<td><label title=\"Beyanname Görüntülemek için Tıklayınız\" " +
      "onclick=\"beyanname_getir_guncel('" + vkn + "','" + vd_kodu + "','" + satir.vergikodu + "','" +
        satir.donem.substr(0,4) + "','" + satir.donem.substr(4,2) + "','" + satir.donem.substr(6,4) + "','" +
        satir.donem.substr(10,2) + "')\" type='submit'>" +
      satir.donem.substr(0,4) + "-" + satir.donem.substr(4,2) + "<br>" +
      satir.donem.substr(0,4) + "-" + satir.donem.substr(10,2) +
    "</label></td>" +

    "<td class='wrap'>" + satir.tsfno + "</td>" +
    "<td class='col-satis' style='text-align:center;'>" + bs + "</td>" +
    "<td class='col-karsit' style='text-align:center;'>" + karsitAlis + "</td>" +
    "<td class='col-banka' style='text-align:center;'>" + krediKarti + "</td>" +

    "<td style='text-align:center;'>" + __takdirKararMatrah__ + "</td>" +
    "<td style='text-align:center;'>" + matrah + "</td>" +

    // Beyan olunan
    "<td style='text-align:center;'>" +
      "<input type='text' class='hidden-input beyan-input' placeholder='0,00' inputmode='decimal'>" +
    "</td>" +

    // Takdir edilen
    "<td style='text-align:center;'>" +
      "<input type='text' class='hidden-input takdir-input' placeholder='0,00' inputmode='decimal'>" +
    "</td>" +

    // Fark (otomatik)
    "<td style='text-align:center;'>" +
      "<input type='text' class='hidden-input fark-output' placeholder='' readonly>" +
    "</td>" +

    // AÇIKLAMA (elle yazılacak)
   "<td class='aciklama-td' style='text-align:center;'>" +
   "<textarea class='aciklama-textarea' placeholder='Açıklama yazınız'></textarea>" +
   "</td>" +

  "</tr>"
);
	 
	 }else {

		// Güvenlik: karar var gibi görünse de dizi boşsa karar yok gibi davran
		if (!kararlar || kararlar.length === 0) {
		  return true; // $.each dışındaki akışa devam
		}
		$.each(kararlar, function(index, satir1){

		 $("#myTable11 tr:last").after( "<tr><td>" + satir.vergikodu  + '</td><td><label title="Beyanname Görüntülemek için Tıklayınız" onclick="beyanname_getir_guncel(\'' + vkn + '\',\'' + vd_kodu + '\',\'' +  satir.vergikodu + '\',\'' + satir.donem.substr(0,4) + '\',\'' + satir.donem.substr(4,2) + '\',\'' + satir.donem.substr(6,4)  +'\',\'' + satir.donem.substr(10,2) +  '\')"'  + " type='submit'>" + satir.donem.substr(0,4) + "-" + satir.donem.substr(4,2) + "<br>" + satir.donem.substr(0,4) +  "-" + satir.donem.substr(10,2)  + "</label></td><td style='word-wrap:break-word;word-break:break-word;white-space:normal;max-width:30px;'>" + satir.tsfno  + "</td><td style='text-align:center;' >" + satir1.kararno + "</td><td style='text-align:center;' >" + satir1.karartarihi + "</td><td>"+ tlCevir(satir1.matrah) + "</td></tr>");

		});

		}
	    
    });
	    
	 var raporDonemDizi = removeDuplicates(takdirDonem);
if((raporDonemDizi.length === 1 && raporDonemDizi[0] === '0015') || __tk_sadece0015()){ console.log('0015 only -> skip yearly analysis'); raporDonemDizi=[]; }

}

catch(err){
 $("#myTable6 tr:last").after( "<tr><td colspan='11'>" + err + "</td></tr>");
 $("#myTable11 tr:last").after( "<tr><td colspan='6'>" + err + "</td></tr>");


}
  
	    //YOKLAMA Talebi
	    

	try{

		$('#tablo4').after(' <table id="myTable7" border=1> <caption>Yoklama</caption>   <tr><th>Vergi Dairesi</th><th>Yoklama Türü</th><th>Yoklama Kodu</th><th>Tarih</th><th>Sonuç</th>   </tr>');

		var url5= 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch?cmd=srvcEys_getMukYoklamalar&callid=';
		var url5=url5.concat(callid + '16', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22durum%22%3A80%7D');
		var yoklama = getRemote(url5);
		var __tmp=yoklama; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};

//

		var yoklama_liste = obj.data; /// vergi dairesi listeliyor

	if (obj.data.length>0){
		$.each(yoklama_liste, function(index, satir){

		var yoklamaTarih = tarih(satir.tarih);
		var vd =vdAdi(satir.vdkodu);
		var ykodu=satir.ykodu;
		var yoklama_turu=yoklamaTuruAciklama(satir.yturu);

		$("#myTable7 tr:last").after( "<tr><td>" + vd + "</td><td>" + yoklama_turu + "</td><td>" + ykodu  + "</td><td>" + yoklamaTarih  + "</td><td><a href=http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?yKodu=" + ykodu  + " target='_blank'>Görüntüle</a></td></tr>");

		});

	}else{

	  $("#myTable7 tr:last").after( "<tr><td></td><td>Yoklama</td><td></td><td></td><td>Yoklama yok</td></tr>");

	}

	}

	catch(err){ 
	 
      $("#myTable7 tr:last").after( "<tr><td></td><td>Yoklama</td><td></td><td></td><td>Hata ile karşılaşıldı</td></tr>");

	}

////dENETİM TUTANAKLARINI GETİRİYOR
	try{
	var url5= 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch?cmd=srvcEys_getMukDenetimlerWithIhb&callid=';
      var url5=url5.concat(callid + '17', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22durum%22%3A80%7D');
      var yoklama = getRemote(url5);
      var __tmp=yoklama; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};
  
//


    var denetim_liste = obj.data; /// vergi dairesi listeliyor
	
	if (obj.data.length>0){
	$.each(denetim_liste, function(index, satir){
      
		var denetimTarih = tarih(satir.dtarih);
		var dkodu=satir.dkodu;
      
	    $("#myTable7 tr:last").after( "<tr><td></td><td>" + satir.dadi + "</td><td>" + dkodu  + "</td><td>" + denetimTarih  + "</td><td><a href=http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?dKodu=" + dkodu  + "&dfsPath=" + satir.dfspath + "&bkodu=" + satir.bkodu + " target='_blank'>Görüntüle</a></td></tr>");

      
	  });

	}else{

	 $("#myTable7 tr:last").after( "<tr><td></td><td>Denetim</td><td></td><td>Denetim tutanağı bulunmamaktadır.</td><td></td></tr>");

	}

	}

	catch(err){

	  $("#myTable7 tr:last").after( "<tr><td></td><td>Denetim</td><td></td><td>Hata ile karşılaşıldı</td><td></td></tr>");
	
	}

          
    /////Matrah artırımı kontrol ediliyor
     
    $('#tablo5').after('<table id="myTable8" border=1><caption>Matrah Artırımı 7326-7440</caption><tr><th>Vergi Dairesi</th><th>Vergi Kodu</th><th>Tecil Türü</th><th>Tecil Dosya No</th><th>Kaldırılma Tarihi</th><th>Kaldırılma Nedeni</th><th>Ödenmesi Gereken</th><th>Ödenen</th><th>Beyanname</th><th>Tahakkuk-Tahsilat</th></tr>');
      
	try{  
    var vd_listesi=hangiVD2(vkno);
  
	$.each(vd_listesi, function(index, vd){
	  			  
			var url5= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid='; 
			var url5=url5.concat(callid + '48', '&token=', _tok(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22orgOid%22%3A%22',orgIDGetir(vd),'%22%2C%22tecilTip%22%3A%22%22%2C%22tclKaldirmaNdn%22%3A%22%22%7D%7D');
			var liste = getRemote(url5);
			var __tmp=liste; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};
			
			$.each(obj.data.tecilKayitlari, function(index, satir){
			  
				if (satir.basvuruMad.includes("MADDE 5")==true){
					
				  var url6= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=mhkTecilService_tecilDetayGetir&callid='; 
				  var url6=url6.concat(callid + '50', '&token=', _tok(), '&jp=%7B%22input%22%3A%7B%22tecilDosyaNo%22%3A%22',satir.tecilDosyaNo,'%22%2C%22tecilDilekceNo%22%3A%22',satir.tecilDilekceNo,'%22%2C%22tecilDilekceTarihi%22%3A%22',satir.tecilDilekceTarihi,'%22%2C%22tecildenKaldirmaTarihi%22%3A%22',satir.tecildenKaldirmaTarihi ,'%22%2C%22tecildenKaldirmaNedeni%22%3A%22K%C4%B1smi%20%C3%96dendi%22%2C%22ortakVkn%22%3A%22%22%2C%22ortakTckn%22%3A%22%22%2C%22plakano%22%3A%22%22%2C%22tecilTuru%22%3A%22',satir.tecilTuru,'%20Tecil%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22orgOid%22%3A%22',orgIDGetir(vd),'%22%2C%22tecilTipi%22%3A%22',satir.tecilTipi,'%22%7D%7D');
				  var liste1 = getRemote(url6);
				  var obj1 =JSON.parse(liste1);
				  if (obj1.data.tecilSatirlari.length==1){
				  
					 var thkfisno=obj1.data.tecilSatirlari[0].thkfisno;
					 var vergikodu=obj1.data.tecilSatirlari[0].vergikodu;  
				  
				  }else{
				  
				 	 var thkfisno=obj1.data.tecilSatirlari[1].thkfisno;
  				     var vergikodu=obj1.data.tecilSatirlari[1].vergikodu;
				  }
			    
			      var vab=(obj1.data.tecilToplamVab + obj1.data.tecilToplamGz).toLocaleString("tr-TR");
		          var tecilOdenenToplam= (obj1.data.tecilOdenenToplamVab+obj1.data.tecilOdenenToplamTecilFaizi+obj1.data.tecilOdenenToplamGz).toLocaleString("tr-TR");


				  $("#myTable8 tr:last").after( "<tr><td>"+ vdAdi(vd)  +"</td><td>" + vergikodu + "</td><td>"+ satir.basvuruMad +"</td><td>"+ satir.tecilDosyaNo +"</td><td>"+ tarihFormat(satir.tecildenKaldirmaTarihi) +"</td><td>"+ satir.tecildenKaldirmaNedeni +"</td><td>" + vab + "</td><td>" + tecilOdenenToplam + "</td><td>" + '<input rel="sorgula" onclick="beyanname_getir_guncel(\'' + vkno + '\',\'' + vd + '\',\'' +  vergikodu +   '\')"'  + " type='submit' value='GÖSTER'>"+"</td><td><a target='_blank' href='diger/matrah-artirimi-tahakkuk-tahsilat.html?token=" + _tok() + "&vkn="+ vkno + "&tecilDosyaNo="+ satir.tecilDosyaNo + "&tecilDilekceNo="+ satir.tecilDilekceNo +"&tecilDosyaNo="+ satir.tecilDosyaNo +"&tecilDilekceTarihi="+ satir.tecilDilekceTarihi +"&tecildenKaldirmaTarihi="+ satir.tecildenKaldirmaTarihi + "&tecilTuru="+ satir.tecilTuru +"&vd="+ vd + "'>Göster   </a></tr>");
				  }
		 
		
			  });
			  
	    });
    
	}

	catch(err){

		  $("#myTable8 tr:last").after( "<tr><td>Hata ile karşılaşıldı</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></tr>");

	}

//ilgili dairenini ilgili dönemindeki Raporları getitiriyor

try{

      $('#tablo9').after('<table id="myTable9" border=1><caption>Rapor Kayıt Defteri</caption><tr><th>Rapor Kayıt No</th><th>Türü</th><th>Vergi Kodu</th><th>Vergi Dönemi</th><th>Rapor Tarih</th><th>Rapor Sayısı</th><th>Rapor Geliş Tarih</th><th>Evrak No</th></tr>');

		var url5= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=raporDefteriService_raporDefteriSorgula&callid=';
		var url5=url5.concat(callid + '28', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22durum%22%3A0%7D');
		var rapor = getRemote(url5);
		var obj_rapor =JSON.parse(rapor);
		var rapor_liste = obj_rapor.data.raporDefterleri;
		var raporSayisi=obj_rapor.data.raporDefterleri.length;
		var ilgiliDonemRaporSayisi=0;
	if (raporSayisi>0){
		$.each(rapor_liste, function(index, satir){
			var rapor_kayit_no="";
		    var aciklama= "";
		    var vergiKodu=""; 
		    var vergidonem="";  
  	        var raptuttarih="";
            var raptutno="";
  		    var raptutgelisno="";

		 if (raporDonemDizi.includes(satir.vergidonem.substr(0,4))){
	      
		    rapor_kayit_no=satir.rapordefterino;
		    aciklama= satir.aciklama;
		    vergiKodu=satir.vergikodu; 
		    vergidonem=satir.vergidonem;  
  	        raptuttarih=satir.raptuttarih;
            raptutno=satir.raptutanakno;
  		    raptutgelisno=satir.evrakNo;
			ilgiliDonemRaporSayisi=ilgiliDonemRaporSayisi+1;
		    
		    $("#myTable9 tr:last").after( "<tr><td>" + rapor_kayit_no + "</td><td>" + aciklama + "</td><td>"+vergiKodu+"</td><td>"+vergidonem+"</td><td>"+tarih(raptuttarih)+"</td><td>"+raptutno+"</td><td>" + tarih(raptutgelisno) + "</td><td>"+raptutgelisno+"</td></tr>");
		    
		    }


		    });

		}else{
	
			$("#myTable9 tr:last").after( "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Kayıtlı rapor bulunmamaktadır.</td></tr>");

		}


		if (ilgiliDonemRaporSayisi==0 && raporSayisi!=0 ){ $("#myTable9 tr:last").after( "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Takdire sevk dönemlerine ilişkin rapor bulunmamaktadır.</td></tr>");	 
  

}

}

catch(err){

$("#myTable9 tr:last").after( "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>Hata ile Karşılaşıldı : " + err  +" </td></tr>");	 
}



// KDVİRA Hata (Arşiv Dahil) tablosunu rapor kayıt defterinden sonra bas
try{
      $('#tablo9').after('<table id="myTable13" border=1><caption>KDVİRA Hata (Arşiv Dahil)</caption><tr><th>Durum</th><th>Dönem</th><th>Segment Kodu</th></tr>');

      (function(){
        var __kdviraRows__ = 0;
        var __callidKdvira__ = (typeof makeid === 'function' ? makeid(13) : String(new Date().getTime())) + '-';
        var __vknKdvira__ = (typeof vkno !== 'undefined' && vkno) ? vkno : ((typeof vkn !== 'undefined' && vkn) ? vkn : $('#input').val());
        var __vdKoduKdvira__ = (typeof vdKodu === 'function') ? vdKodu() : '';
        var __tokenKdvira__ = (typeof _tok === 'function') ? _tok() : '';

        function __appendKdviraRows__(durumText, liste){
          if (liste && liste.length > 0){
            $.each(liste, function(index, satir){
              __kdviraRows__++;
              $('#myTable13 tr:last').after('<tr><td>' + durumText + '</td><td>' + (satir.donem || '') + '</td><td>' + (satir.segmentKodu || '') + '</td></tr>');
            });
          }
        }

        try{
          var __urlAktif__ = 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=mukellefKarnesiYazismaService_mukellefListesiGetirVergilendirme&callid=';
          __urlAktif__ = __urlAktif__.concat(__callidKdvira__ + '32', '&token=', __tokenKdvira__, '&jp=%7B%22vdKodu%22%3A%22', __vdKoduKdvira__, '%22%2C%22faturaDonemi%22%3A%22%22%2C%22yazismaDurum%22%3A%220%22%2C%22basVkn%22%3A%22', __vknKdvira__, '%22%2C%22bitVkn%22%3A%22', __vknKdvira__, '%22%2C%22segmentKodu%22%3A%22%22%2C%22iadeDonemi%22%3A%22%22%2C%22gunSayisi%22%3A%220%22%2C%22vknIadeci%22%3A%22%22%2C%22mudurluk%22%3A%22%22%7D');
          var __txtAktif__ = getRemote(__urlAktif__);
          var __objAktif__ = JSON.parse(__txtAktif__);
          __appendKdviraRows__('Aktif', (__objAktif__ && __objAktif__.data && __objAktif__.data.liste) ? __objAktif__.data.liste : []);
        } catch(__errAktif__){
          $('#myTable13 tr:last').after('<tr><td>Aktif</td><td></td><td>Hata: ' + __errAktif__ + '</td></tr>');
        }

        try{
          var __urlArsiv__ = 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=mukellefKarnesiYazismaService_mukellefListesiGetirVergilendirme4Arsiv&callid=';
          __urlArsiv__ = __urlArsiv__.concat(__callidKdvira__ + '21', '&token=', __tokenKdvira__, '&jp=%7B%22vdKodu%22%3A%22', __vdKoduKdvira__, '%22%2C%22basVkn%22%3A%22', __vknKdvira__, '%22%2C%22bitVkn%22%3A%22', __vknKdvira__, '%22%2C%22iadeDonemi%22%3A%22%22%2C%22gunSayisi%22%3A%220%22%2C%22vknIadeci%22%3A%22%22%2C%22arsivBasTar%22%3A%22%22%2C%22arsivBitTar%22%3A%22%22%2C%22segmentKodu%22%3A%22%22%2C%22faturaDonemi%22%3A%22%22%2C%22yazismaDurum%22%3A%220%22%2C%22mudurluk%22%3A%22%22%7D');
          var __txtArsiv__ = getRemote(__urlArsiv__);
          var __objArsiv__ = JSON.parse(__txtArsiv__);
          __appendKdviraRows__('Arşiv', (__objArsiv__ && __objArsiv__.data && __objArsiv__.data.liste) ? __objArsiv__.data.liste : []);
        } catch(__errArsiv__){
          $('#myTable13 tr:last').after('<tr><td>Arşiv</td><td></td><td>Hata: ' + __errArsiv__ + '</td></tr>');
        }

        if (__kdviraRows__ === 0 && $('#myTable13 tr').length === 1){
          $('#myTable13 tr:last').after('<tr><td></td><td></td><td>Kayıt bulunamadı</td></tr>');
        }
      })();
}
catch(err){
      $('#tablo9').after('<table id="myTable13" border=1><caption>KDVİRA Hata (Arşiv Dahil)</caption><tr><th>Durum</th><th>Dönem</th><th>Segment Kodu</th></tr><tr><td></td><td></td><td>Hata ile karşılaşıldı: ' + err + '</td></tr></table>');
}

// Satış / Karşıt Alış toplu sorgu ve otomatik tekrar deneme
// Tek motor: tüm yıl (1-12) satış/karşıt alış + POS/banka + kümülatif yazım
try { if (!__skipAutoPosSatisKarsit__ && window.tkkomFullYearStart) { window.tkkomFullYearStart(_tok(), vkno); } } catch(e) {}

ozesTabloGetir(_tok(),vkn,tabloID='12');


});

$('#go2').click(function() { // Gayrimenkul Alan kişilerin dökümleri
  
 var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
    
  var vkn=$('#input').val();
  
  window.open('diger/gmenkulAlanSatan.html?vkn=' + vkn + "&token=" + _tok());
  
	
  
  
});


$('#go86').click(function() { // TAKBİS  ve 2012 sonrası Gayrimenkul Alan kişilerin dökümleri
  
 var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
    
  var vkn=$('#input').val();
  
  window.open('diger/takbis-gMenkulAlanSatan.html?vkn=' + vkn + "&token=" + _tok());
  
	
  
  
});

$('#go3').click(function() { // Kesinti dökümleri

	var myRegex= /[0-9]+/;
	var tokenlink =$('#token').val();
	var myRegexp= /token=([^&\s]+)/;
	var token = myRegexp.exec(tokenlink);
	var callid=makeid(13) + '-';
	var vkn=$('#input').val();
      
	window.open('diger/kesinti-getir.html?vkn=' + vkn + "&token=" + _tok());
	
});	


$('#go4').click(function() { // Yoklama Listesi

 tabloSil();
  $("#tablo6").remove();
  $("#tablo7").remove();
  $("#tablo8").remove();
 
  var myRegex= /[0-9]+/;
      var tokenlink =$('#token').val();
      var myRegexp= /token=([^&\s]+)/;
      var token = myRegexp.exec(tokenlink);
      var callid=makeid(13) + '-';
      var vkn=$('#input').val();
     	 
	 var durum={
				'10':'Memurda',
				'20':'Müdürde',
				'30':'Koordinatörde',
				'40':'Ekipte',
				'60':'Sonuçlandı',
				'70':'Sonuçlanmayanlar',
				'80':'Görevli VD de',
				'90':'Sonlandırılanlar',
				'0':'İptal Edilen'		};

$('#tablo1').after('<table id="myTable4" border=1><caption>İşlemi Bitmemiş Yoklama Listesi</caption><tr>><th>VKN</th><th>Ünvan</th><th>Tür</th><th>Son İşlem Tarihi</th><th>Durum</th><th>Aciklama</th></tr>');


      var url5= 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch?cmd=srvcYoklamalar_getYoklamalar&callid=';
      var url5=url5.concat(callid + '49', '&token=', _tok(), '&jp=%7B%22data%22%3A%7B%22koor%22%3A%22%22%2C%22vd%22%3A%22',vdKodu(),'%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22sorgukaynak%22%3A%220%22%2C%22icdis%22%3A%220%22%2C%22disil%22%3A%22%22%2C%22disvd%22%3A%22%22%2C%22basvkn%22%3A%22',vkn,'%22%2C%22sonvkn%22%3A%22',vkn,'%22%2C%22bastckn%22%3A%22%22%2C%22sontckn%22%3A%22%22%2C%22yabanci%22%3A0%2C%22vkn%22%3A%22%22%2C%22tckn%22%3A%22%22%2C%22yturu%22%3A%5B%5D%2C%22ydurum%22%3A%22%22%2C%22sonucislem%22%3A1%2C%22servis%22%3A%22%22%2C%22bastar%22%3A%2220221101%22%2C%22bittar%22%3A%2220221121%22%2C%22unvan%22%3A%22%22%2C%22ym%22%3A%22%22%2C%22usekullanici%22%3Afalse%2C%22eosusergiris%22%3A%2236178538168%22%2C%22eosuser%22%3A%2236178538168%22%2C%22ihbaraDayali%22%3Afalse%7D%2C%22sessionData%22%3A%7B%22rol%22%3A10%2C%22user%22%3A%2236178538168%22%2C%22giris%22%3A%2236178538168%22%2C%22birim%22%3A%22',vdKodu(),'%22%2C%22il%22%3A%22016%22%2C%22adi%22%3A%22NUR%C4%B0%20S%C4%B0RT%20%22%7D%7D');
      var yoklama = getRemote(url5);
      var __tmp=yoklama; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};



	$.each(obj.data, function(index, satir){
	
	    
		  $("#myTable4 tr:last").after( "<tr><td>" + satir. vkn   + "</td><td>" +  satir.unvan + "</td><td>" + yoklamaTuruAciklama(satir.yturu)	 + "</td><td>" + tarihFormat(satir.sonislem) + "</td><td>" + durum[satir.durum]+ "</td><td>"+satir.aciklama+"</td></tr>");

	
	});
	
});	


$('#go5').click(function() { // Gelen Giden Evrak Listesi

  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';

  var vkn=$('#input').val();


  window.open('diger/gelen-giden-evrak.html?vkn=' + vkn + "&token=" + _tok());
  
	
});	

$('#go6').click(function() { // BS Karşılaştırma

  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';

  var vkn=$('#input').val();


  window.open('diger/bs-karsilastirma.html?vkn=' + vkn + "&token=" + _tok() );
  
	
});	


$('#go80').click(function() { // Mükellefin POS UYUMSUZLUĞU HK	
  
 
  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
  var tespit_bas=prompt("Yıl Giriniz","");
  var vkn=$('#input').val();


  window.open('diger/pos-uyumsuzlugu-takdir.html?vkn=' + vkn + "&token=" + _tok() + "&yil=" + tespit_bas );
	


});


$('#go81').click(function() { // Mükellefin E Fatura yada E ARşiv Faturalarına aylık olarak sorgulamak için kullanıyoruz
  
 
  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
  var tur=prompt("E-Fatura mı (1) / E-Arşiv Fatura(2)",1);
  var yil=prompt("Fatura Yılı","");
  var ay=prompt("Fatura ayı","");
  
  var vkn=$('#input').val();


  window.open('diger/efatura-earsiv-sorgulama-aylik.html?vkn=' + vkn + "&token=" + _tok() + "&yil=" + yil + "&ay=" + ay   + "&tur=" + tur);
	


});



$('#go82').click(function() { // Mükellefin Tüm Motorlu araçların listesini veriyor
  
 
  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
 
  var vkn=$('#input').val();


  window.open('diger/tum-motorlu-tasitlar.html?vkn=' + vkn + "&token=" + _tok() );
	


});


$('#go83').click(function() { //Gerçek Kişi Mükellefin TAKBİS Kayıt listesini veriyor
  
 
  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
 
  var vkn=$('#input').val();


  window.open('diger/takbis.html?vkn=' + vkn + "&token=" + _tok() );
	


});

$('#go84').click(function() { // Mükellefin KDVİRA Hatalarını Sorguluyor
  
 
  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
 
  var vkn=$('#input').val();


  window.open('diger/kdviraHata.html?vkn=' + vkn + "&token=" + _tok() );

});
	
$('#go85').click(function() { // Beyanname Getir

  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
  var vergiDairesi=prompt("Vergi Dairesi Kodunu Giriniz (Örnek:016253)",vdKodu() );
  var vergiKodu=prompt("Vergi Kodunu Giriniz (Örnek:0001 yada 0015)","0015");
  
  var vkn=$('#input').val();
    
  
   var url5= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=bynIslemleriService_bynSorgula&callid=';
   var url5=url5.concat(callid + '25', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',vergiDairesi ,'%22%2C%22vergiKodu%22%3A%22',vergiKodu,'%22%2C%22donemBas%22%3A%22%22%2C%22donemBit%22%3A%22%22%2C%22arsiv%22%3A%22T%22%7D');
   var beyanname = getRemote(url5);
   var __tmp=beyanname; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};
   var ip=obj.data.kullaniciIp;
  
    
   window.open('http://10.251.67.110:30080/ebyn/vdintraDispatch?SVERGINO='+vkn+'&VERGIKODU='+vergiKodu+'&VDKODU='+ vergiDairesi  +'&tD1yil=&tD2yil=&tD1ay=&tD2ay=&ARSIV=F&BFORMUCIKAR=1&KESINMIZANCIKAR=1&cmd=BEYANNAMELISTESIVDO&origin=vdintra&USERID=tcnumaran&USERIP='+ ip + "'");



});

$('#go21').click(function() { // Mükellefin KDV Beyannamelerinin dökümü yapmaktadır.
  
     
    var myRegex= /[0-9]+/;
    var tokenlink =$('#token').val();
    var myRegexp= /token=([^&\s]+)/;
    var token = myRegexp.exec(tokenlink)
    var callid=makeid(13) + '-';
    var vkno=$('#input').val();
   
    var tespit_bas=prompt("Hangi Yıldan itibaren başlasın","");
    
 	if (tespit_bas==""){ alert("Yıl Girilmesi Gerekiyor"); return;}
 	 
    var tarih=new Date();
    var yil=tarih.getFullYear();
    var vd_listesi=new Array();
    var vergikodu="0015";
    var vdkodu=vdKodu();
    var mesaj="";                
     
     
     window.open('diger/kdv_beyanlari.html?tekYil=Evet&vkn=' + vkno + "&token=" + _tok() + "&yil=" + tespit_bas);
    
   
});

$('#go22').click(function() { // Mükellefin KDV Beyannameleri, BS Karşılaştırma ve POS dökümü yapmaktadır.
  
     
    var myRegex= /[0-9]+/;
    var tokenlink =$('#token').val();
    var myRegexp= /token=([^&\s]+)/;
    var token = myRegexp.exec(tokenlink)
    var callid=makeid(13) + '-';
    var vkno=$('#input').val();
   
    var tespit_bas=prompt("Hangi Yıldan itibaren başlasın","");
    
 	if (tespit_bas==""){ alert("Yıl Girilmesi Gerekiyor"); return;}
 	 
    var tarih=new Date();
    var yil=tarih.getFullYear();
    var vd_listesi=new Array();
    var vergikodu="0015";
    var vdkodu=vdKodu();
    var mesaj="";                
     
     
     window.open('diger/kdv_beyanlari_bs_pos.html?tekYil=Evet&vkn=' + vkno + "&token=" + _tok() + "&yil=" + tespit_bas);
    
   
});
 
function getRemote(url){
	return $.ajax({
	  type:"GET",
	  url:url,
	  async:false
	}).responseText;
      
      }
      

       
function postRemote(url){
	return $.ajax({
	  type:"POST",
	  url:url,
	  async:false
	}).responseText;
      
      }
      
      
function makeid(length) {
  var text = "";
  var possible = "abcde0123456789";

  for (var i = 0; i < length; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}
