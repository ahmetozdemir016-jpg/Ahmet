Takdire Sevk 2 Bot - Chrome Eklentisi v1.0.1

Bu sürümde eski doğrudan IP üzerinden yapılan gibintranet_server çağrıları
http://keys.ggm.bim/gibintranet_server/dispatch adresine yönlendirildi.
Ayrıca Service Unavailable durumunda alternatif endpoint denemesi yapan küçük bir yama eklendi.

Kurulum:
1) chrome://extensions açılır.
2) Geliştirici modu açılır.
3) Paketlenmemiş öğe yükle seçilir.
4) Bu klasör seçilir.

Not:
GİB/kurum ağına ve geçerli token/oturuma ihtiyaç duyar.
Yeni sekme açıldığında takdire-sevk2.html çalışır.
