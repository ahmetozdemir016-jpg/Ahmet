v4.31.33 Önceki Yoklama Direkt Açma

Düzeltme:
- Önceki yoklama açılırken panel içinde “iframe içinde açılmıyor” uyarısı gösterilmiyor.
- eyoklama.gelirler.gov.tr / getSonuc bağlantıları doğrudan yeni sekme/pencerede açılıyor.
- Böylece Chrome PDF viewer ikinci görseldeki gibi açılır.
- Tarayıcı yeni sekmeyi engellerse sadece o durumda küçük uyarı ve “Sekmede Aç” butonu gösterilir.
