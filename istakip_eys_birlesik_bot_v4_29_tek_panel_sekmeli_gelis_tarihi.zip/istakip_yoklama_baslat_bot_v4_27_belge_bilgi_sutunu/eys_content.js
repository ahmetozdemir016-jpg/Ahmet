(() => {
  'use strict';

  function eysLocalGet(key) {
    try {
      const raw = localStorage.getItem('eys_storage_' + key);
      return raw ? JSON.parse(raw) : null;
    } catch (_) { return null; }
  }

  function eysLocalSet(key, value) {
    try { localStorage.setItem('eys_storage_' + key, JSON.stringify(value)); } catch (_) {}
  }

  function eysLocalRemove(key) {
    try { localStorage.removeItem('eys_storage_' + key); } catch (_) {}
  }

  async function eysStorageGet(key) {
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return eysLocalGet(key);
      const data = await chrome.storage.local.get(key);
      return data ? data[key] : eysLocalGet(key);
    } catch (_) {
      return eysLocalGet(key);
    }
  }

  async function eysStorageSet(key, value) {
    eysLocalSet(key, value);
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return;
      await chrome.storage.local.set({ [key]: value });
    } catch (_) {}
  }

  async function eysStorageRemove(key) {
    eysLocalRemove(key);
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return;
      await chrome.storage.local.remove(key);
    } catch (_) {}
  }


  if (window.__eysTabbedBotLoaded) return;
  window.__eysTabbedBotLoaded = true;

  function isPdfResultPage() {
    try {
      const u = new URL(window.location.href);
      return /\/edenetis\/getSonuc/i.test(u.pathname) && !!u.searchParams.get('yKodu');
    } catch (_) {
      return false;
    }
  }

  function showPdfPrintOverlay(msg) {
    try {
      const id = 'eys-pdf-print-overlay';
      let box = document.getElementById(id);
      if (!box) {
        box = document.createElement('div');
        box.id = id;
        box.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;background:#111827;color:#fff;padding:10px 12px;border:1px solid #334155;border-radius:8px;font:12px/1.4 sans-serif;box-shadow:0 10px 25px rgba(0,0,0,.35)';
        document.documentElement.appendChild(box);
      }
      box.textContent = msg;
    } catch (_) {}
  }

  function setupPdfAutoPrintPage() {
    if (!isPdfResultPage()) return false;
    try {
      const u = new URL(window.location.href);
      const auto = u.searchParams.get('eys_autoprint') === '1';
      if (!auto) return true;
      const delay = Math.max(800, Number(u.searchParams.get('eys_delay') || '1800') || 1800);
      const ykodu = u.searchParams.get('yKodu') || '';
      const closeAfter = u.searchParams.get('eys_close') === '1';
      showPdfPrintOverlay(`EYS yazdırma hazırlanıyor... ${ykodu}`);
      setTimeout(() => {
        try { window.focus(); } catch (_) {}
        showPdfPrintOverlay('Yazdırma komutu gönderiliyor...');
        try { window.print(); } catch (_) {}
        if (closeAfter) {
          setTimeout(() => { try { window.close(); } catch (_) {} }, 1500);
        }
      }, delay);
    } catch (_) {}
    return true;
  }

  if (setupPdfAutoPrintPage()) return;

  const CFG = {
    PANEL_ID: 'eys-tabbed-bot-panel',
    STYLE_ID: 'eys-tabbed-bot-style',
    STORAGE_KEY: 'eys_pending_action',
    FIXED_SIDE_URL: 'http://10.251.63.99:30870/side/side-dispatch',
    EYS_URL: 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch',
    RESCAN_MS: 5 * 60 * 1000,
    AFTER_MEMUR_SEND_WAIT_MS: 2500,
    SERVICES: [
      ['10', '1. Sürekli yükümlülükler'],
      ['20', '2. Sürekli yükümlülükler'],
      ['30', '3. Sürekli yükümlülükler'],
      ['40', '4. Sürekli yükümlülükler'],
      ['50', 'Tarama kontrol bölümü'],
      ['60', 'Sicil yoklama'],
      ['70', 'KDV iade servisi'],
      ['91', 'İnteraktif VD'],
      ['92', 'Ticaret sicil servisi'],
      ['93', 'GİB robot']
    ],
    COMMANDS: {
      SIDE_GET_MODULE_INFO: 'SIDE.GET_MODULE_INFO',
      SIDE_GET_EAGER_BF_DEFS: 'SIDE.GET_EAGER_BF_DEFS',
      SIDE_GET_SERVICE_DEF_LIST: 'SIDE.GET_SERVICE_DEF_LIST',
      CREATE_SESSION: 'eosKullaniciServices_createSession',
      GET_VD_ADI: 'srvcRefData_getVDAdi',
      CHECK_USER: 'srvcEysUser_isFatihTopkapiOrHatayIskenderun',
      MEMUR_LIST: 'srvcDashboard_getMemurIslemlerYTum',
      MEMUR_SEND: 'srvcYoklama_submitYoklamalarToMudur',
      MUDUR_LIST: 'srvcDashboard_getMudurIslemlerYOnayBekleyen',
      MUDUR_SEND: 'srvcYoklama_submitYoklamalarToKoor',
      GET_YOKLAMALAR: 'srvcYoklama_getYoklamalar',
      ARCHIVE_YOKLAMA: 'srvcArchive_archiveYoklama',
      ISLEM_YAPILDI: 'srvcYoklama_islemYapildiYoklamaSonuc'
    }
  };

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function visible(el) {
    return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  }

  function textOf(el) {
    return ((el?.innerText || el?.textContent || el?.value || el?.title || el?.alt || '') + '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function safeCall(obj, fn) {
    try { return obj && typeof obj[fn] === 'function' ? obj[fn]() : undefined; }
    catch (_) { return undefined; }
  }

  function getToken() {
    return new URLSearchParams(window.location.search).get('token') || '';
  }

  function formatDateYYYYMMDD(d = new Date()) {
    return d.toISOString().slice(0, 10).replaceAll('-', '');
  }

  function getSessionSeed() {
    const c = window.CSSession || {};
    const birim = String(
      safeCall(c, 'getVdKodu') || c.vdKodu || c.vdkodu || c.birim || '016253'
    ).trim();

    const user = String(
      safeCall(c, 'getUserId') || c.userId || window.userId || '35353114746'
    ).trim();

    const adi = String(
      safeCall(c, 'getUserName') || c.adi || window.userName || ''
    ).trim();

    return {
      user,
      giris: user,
      birim,
      il: birim.slice(0, 3),
      adi,
      userx: user
    };
  }

  function buildSessionData(role) {
    const seed = getSessionSeed();
    return {
      rol: String(role),
      user: seed.user,
      giris: seed.giris,
      birim: seed.birim,
      il: seed.il,
      adi: seed.adi,
      userx: seed.userx
    };
  }

  async function post(url, cmd, jp) {
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', String(Date.now()));
    const token = getToken();
    if (token) p.append('token', token);
    p.append('jp', JSON.stringify(jp || {}));

    const res = await fetch(url, {
      method: 'POST',
      body: p,
      credentials: 'include'
    });

    if (!res.ok) throw new Error(`Ağ hatası: ${res.status} (${cmd}) @ ${url}`);

    const text = await res.text();
    try { return JSON.parse(text); } catch (_) { return text; }
  }

  async function tryPost(url, cmd, jp) {
    try { return await post(url, cmd, jp); }
    catch (e) { return { __error: e.message || String(e) }; }
  }

  function buildSideCandidates() {
    const origin = window.location.origin;
    const path = window.location.pathname || '';
    const firstSeg = path.split('/').filter(Boolean)[0] || '';
    const candidates = [
      CFG.FIXED_SIDE_URL,
      origin + '/side/side-dispatch',
      origin + '/side-dispatch'
    ];
    if (firstSeg) {
      candidates.push(origin + '/' + firstSeg + '/side-dispatch');
      candidates.push(origin + '/' + firstSeg + '/side/side-dispatch');
    }
    return Array.from(new Set(candidates));
  }

  function looksLikeYkodu(value) {
    return typeof value === 'string' && /^\d{8}Y\d{6}[A-Z0-9]+$/i.test(value);
  }

  function collectObjects(root, out = []) {
    if (Array.isArray(root)) {
      for (const item of root) collectObjects(item, out);
      return out;
    }
    if (root && typeof root === 'object') {
      out.push(root);
      for (const value of Object.values(root)) collectObjects(value, out);
    }
    return out;
  }

  function extractYkodlariStrict(resp) {
    const found = new Set();
    const objects = collectObjects(resp);
    for (const obj of objects) {
      if (!obj || typeof obj !== 'object') continue;
      const direct = obj.ykodu || obj.yKod || obj.ykod || obj.yoklamaKodu || obj.yoklamakodu;
      if (looksLikeYkodu(direct)) found.add(direct);
      if (Array.isArray(obj.ykodlari)) {
        for (const value of obj.ykodlari) if (looksLikeYkodu(value)) found.add(value);
      }
    }
    return Array.from(found);
  }

  function extractYoklamaRows(resp) {
    const rows = [];
    const objects = collectObjects(resp);
    const seen = new Set();
    for (const obj of objects) {
      const ykodu = obj?.ykodu || obj?.yKod || obj?.ykod;
      if (!looksLikeYkodu(ykodu) || seen.has(ykodu)) continue;
      seen.add(ykodu);
      rows.push({
        ykodu,
        durum: obj?.durum || '',
        servis: String(obj?.servis || ''),
        archived: String(obj?.archived || ''),
        ilkislem: obj?.ilkislem || '',
        sonislem: obj?.sonislem || '',
        unvan: obj?.unvan || obj?.adsoyad || '',
        vkn: obj?.vkn || '',
        tckn: obj?.tckn || ''
      });
    }
    return rows;
  }

  function toYmd(value) {
    return String(value || '').replace(/\D/g, '').slice(0, 8);
  }

  function inYmdRange(ymd, start, end) {
    if (!ymd) return false;
    if (start && ymd < start) return false;
    if (end && ymd > end) return false;
    return true;
  }

  function clientFilterRows(rows, cfg = {}) {
    const start = toYmd(cfg.bastar);
    const end = toYmd(cfg.bittar);
    const servis = String(cfg.servis || '').trim();
    return (rows || []).filter(row => {
      const rowServis = String(row?.servis || '').trim();
      const ilk = toYmd(row?.ilkislem);
      const son = toYmd(row?.sonislem);
      const yk = toYmd(row?.ykodu);
      const rowDate = ilk || son || yk;
      if (servis && rowServis && rowServis !== servis) return false;
      return inYmdRange(rowDate, start, end);
    });
  }

  function previewResponse(resp) {
    try {
      const text = JSON.stringify(resp);
      return text.length > 500 ? text.slice(0, 500) + ' ...' : text;
    } catch (_) {
      return String(resp);
    }
  }

  function serviceOptionsHtml(selected = '60') {
    return CFG.SERVICES.map(([value, label]) =>
      `<option value="${value}" ${value === selected ? 'selected' : ''}>${value} — ${label}</option>`
    ).join('');
  }

  function injectStyle() {
    if (document.getElementById(CFG.STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = CFG.STYLE_ID;
    s.textContent = `
      #${CFG.PANEL_ID}{position:fixed;top:6%;right:1.5%;width:620px;max-width:96vw;z-index:2147483647;background:#060912;color:#eaf0ff;font:12px/1.45 'Segoe UI',sans-serif;border:1px solid #232b3a;border-radius:10px;box-shadow:0 20px 50px rgba(0,0,0,.8)}
      #${CFG.PANEL_ID}, #${CFG.PANEL_ID} *{box-sizing:border-box}
      #${CFG.PANEL_ID} .h{display:flex;justify-content:space-between;align-items:center;padding:10px 15px;background:#121826;border-radius:10px 10px 0 0;border-bottom:1px solid #232b3a}
      #${CFG.PANEL_ID} .w{padding:12px}
      #${CFG.PANEL_ID} label{display:block;font-size:10px;color:#9aa6bf;margin:6px 0 3px;font-weight:bold;text-transform:uppercase}
      #${CFG.PANEL_ID} input,#${CFG.PANEL_ID} select{width:100%;background:#050814;border:1px solid #273048;padding:8px;color:#eaf0ff;border-radius:4px}
      #${CFG.PANEL_ID} input:disabled{opacity:.8;color:#9ddcff}
      #${CFG.PANEL_ID} button.action{width:100%;padding:10px;border:0;border-radius:4px;font-weight:bold;cursor:pointer;margin-top:8px}
      #${CFG.PANEL_ID} .mini{width:auto;background:none;color:#9ddcff;border:0;font-size:18px;margin-left:10px;padding:0;cursor:pointer}
      #${CFG.PANEL_ID} .row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      #${CFG.PANEL_ID} .row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}
      #${CFG.PANEL_ID} .tabs{display:flex;gap:6px;margin:10px 0 12px;flex-wrap:wrap}
      #${CFG.PANEL_ID} .tab-btn{flex:1;min-width:120px;padding:9px 10px;border:1px solid #273048;border-radius:6px;background:#0a1020;color:#c8d5f0;cursor:pointer;font-weight:bold}
      #${CFG.PANEL_ID} .tab-btn.active{background:#173056;color:#fff;border-color:#2d8cff}
      #${CFG.PANEL_ID} .tab-page{display:none}
      #${CFG.PANEL_ID} .tab-page.active{display:block}
      #${CFG.PANEL_ID} .card{margin-top:10px;padding:10px;border:1px solid #273048;border-radius:6px;background:#0a1020}
      #${CFG.PANEL_ID} .mutedtitle{font-weight:bold;color:#c4d5ff;margin-bottom:6px}
      #${CFG.PANEL_ID} .hint{margin-top:5px;color:#93a1c1;font-size:11px}
      #${CFG.PANEL_ID} .subnote{margin-top:6px;color:#9aa6bf;font-size:11px}
      #${CFG.PANEL_ID} .monitor{background:#000;color:#0f0;font-family:monospace;height:210px;overflow:auto;border:1px solid #333;padding:8px;margin-top:10px;border-radius:4px}
      #${CFG.PANEL_ID} .monitor .err{color:#ff6b6b}
      #${CFG.PANEL_ID} .list{max-height:180px;overflow:auto;border:1px solid #273048;border-radius:4px;margin-top:8px;background:#050814}
      #${CFG.PANEL_ID} .list-row{padding:7px 8px;border-bottom:1px solid #172034;display:flex;justify-content:space-between;gap:10px;align-items:center}
      #${CFG.PANEL_ID} .list-row:last-child{border-bottom:0}
      #${CFG.PANEL_ID} .tiny{font-size:11px;color:#aeb9d4}
      #${CFG.PANEL_ID} .inline-btn{width:auto;margin:0 0 0 6px;padding:5px 8px;font-size:11px;border-radius:4px;border:1px solid #36517d;background:#10213d;color:#fff;cursor:pointer}
      #${CFG.PANEL_ID} .inline-btn.warn{background:#4a3510;border-color:#9b7426}
      #${CFG.PANEL_ID} .inline-btn.good{background:#15391f;border-color:#2f8f4e}
    `;
    document.head.appendChild(s);
  }

  function createPanel() {
    const existing = document.getElementById(CFG.PANEL_ID);
    if (existing) return existing;

    const seed = getSessionSeed();
    const today = formatDateYYYYMMDD();
    const past180 = formatDateYYYYMMDD(new Date(Date.now() - 180 * 24 * 60 * 60 * 1000));

    const panel = document.createElement('div');
    panel.id = CFG.PANEL_ID;
    panel.innerHTML = `
      <div class="h">
        <strong>EYS Modülü</strong>
        <div>
          <button class="mini" id="eys_toggle">−</button>
          <button class="mini" id="eys_close" style="color:#ff6b6b">×</button>
        </div>
      </div>
      <div class="w" id="eys_wrap">
        <div class="row">
          <div><label>Kullanıcı ID</label><input id="u_user" value="${seed.user}" disabled></div>
          <div><label>Birim</label><input id="u_birim" value="${seed.birim}" disabled></div>
        </div>

        <div class="tabs">
          <button class="tab-btn active" data-tab="main">Akış</button>
          <button class="tab-btn" data-tab="filtered">Filtreli İşlem</button>
          <button class="tab-btn" data-tab="daily">Günlük PDF</button>
        </div>

        <div class="tab-page active" data-page="main">
          <div class="row">
            <div><label>Akış başlangıç</label><input id="main_bastar" value="${past180}"></div>
            <div><label>Akış bitiş</label><input id="main_bittar" value="${today}"></div>
          </div>
          <div class="row3">
            <button class="action" id="runBtn" style="background:#3ccf91;color:#00170c">AKIŞI BAŞLAT</button>
            <button class="action" id="memurBtn" style="background:#2d8cff;color:#fff">MEMUR REFRESH AÇ</button>
            <button class="action" id="mudurBtn" style="background:#8b5cf6;color:#fff">MÜDÜR REFRESH AÇ</button>
          </div>
          <button class="action" id="stopBtn" style="background:#cf3c3c;color:#fff;display:none">DURDUR</button>
          <div class="subnote">Bu sekme yalnız kendi tarih alanlarını kullanır. Memur→Müdür otomatik döngüsüdür.</div>
          <div class="monitor" id="log_main"></div>
        </div>

        <div class="tab-page" data-page="filtered">
          <div class="row3">
            <div>
              <label>Rol</label>
              <select id="filtered_role">
                <option value="20">Müdür</option>
                <option value="10">Memur</option>
              </select>
            </div>
            <div>
              <label>Servis</label>
              <select id="filtered_servis">${serviceOptionsHtml('60')}</select>
            </div>
            <div>
              <label>Aksiyon</label>
              <select id="filtered_action">
                <option value="archive">Arşive Kaldır</option>
                <option value="islem">İşlem Yapıldı</option>
              </select>
            </div>
          </div>
          <div class="row">
            <div><label>Filtre başlangıç</label><input id="filtered_bastar" value="${past180}"></div>
            <div><label>Filtre bitiş</label><input id="filtered_bittar" value="${today}"></div>
          </div>
          <button class="action" id="filteredBtn" style="background:#f59e0b;color:#111">SORGULA VE UYGULA</button>
          <div class="subnote">Bu sekme yalnız kendi tarih/rol/servis/aksiyon verisini kullanır.</div>
          <div class="monitor" id="log_filtered"></div>
        </div>

        <div class="tab-page" data-page="daily">
          <div class="row3">
            <div>
              <label>Rol</label>
              <select id="daily_role">
                <option value="20">Müdür</option>
                <option value="10">Memur</option>
              </select>
            </div>
            <div>
              <label>Servis</label>
              <select id="daily_servis">${serviceOptionsHtml('60')}</select>
            </div>
            <div>
              <label>Günlük tarih</label>
              <input id="daily_date" value="${today}">
            </div>
          </div>
          <div class="row">
            <div>
              <label>Yazıcı adı</label>
              <input id="daily_printer" placeholder="Örn: Lexmark_MS811_230">
            </div>
            <div>
              <label>PDF arası bekleme (ms)</label>
              <input id="daily_delay" value="1800">
            </div>
          </div>
          <div class="row3">
            <button class="action" id="dailyQueryBtn" style="background:#22c55e;color:#04140c">BUGÜN SORGULA</button>
            <button class="action" id="dailyOpenAllBtn" style="background:#2563eb;color:#fff">TÜM PDF'LERİ AÇ</button>
            <button class="action" id="dailyQueueBtn" style="background:#a855f7;color:#fff">KUYRUK YAZDIR</button>
          </div>
          <div class="hint">Chrome PDF viewer açılır. Bu sürüm PDF sekmesini otomatik print parametresiyle açar; yazıcı seçimi Linux/Chrome politikasına göre değişebilir.</div>
          <div class="list" id="daily_list"></div>
          <div class="monitor" id="log_daily"></div>
        </div>
      </div>
    `;

    document.body.appendChild(panel);
    return panel;
  }


  function eysTryEmbedIntoMainPanel() {
    try {
      const eysPanel = document.getElementById(CFG.PANEL_ID);
      const eysPage = document.getElementById('it_eys_tab_page');
      if (eysPanel && eysPage && eysPanel.parentElement !== eysPage) {
        eysPage.appendChild(eysPanel);
        eysPanel.classList.add('it-embedded-eys');
        if (!document.getElementById('it_tab_eys')?.classList.contains('active')) eysPage.style.display = 'none';
      }
    } catch (_) {}
  }

  function createLogger(box) {
    return (msg, err = false) => {
      const line = `[${new Date().toLocaleTimeString()}] ${msg}`;
      console.log('[EYS-EXT]', line);
      const row = document.createElement('div');
      if (err) row.className = 'err';
      row.textContent = err ? `HATA: ${line}` : line;
      box.appendChild(row);
      box.scrollTop = box.scrollHeight;
    };
  }

  class EysFullBot {
    constructor(panel) {
      this.panel = panel;
      this.logs = {
        main: createLogger(panel.querySelector('#log_main')),
        filtered: createLogger(panel.querySelector('#log_filtered')),
        daily: createLogger(panel.querySelector('#log_daily'))
      };
      this.running = false;
      this.timer = null;
      this.inFlight = false;
      this.filteredInFlight = false;
      this.dailyInFlight = false;
      this.dailyQueueInFlight = false;
      this.cycleNo = 0;
      this.sideUrl = null;
      this.dailyRows = [];
      this.bind();
    }

    log(tab, msg, err = false) {
      (this.logs[tab] || this.logs.main)(msg, err);
    }

    bind() {
      this.panel.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', () => this.activateTab(btn.dataset.tab)));
      this.panel.querySelector('#runBtn').addEventListener('click', () => this.start());
      this.panel.querySelector('#stopBtn').addEventListener('click', () => this.stop());
      this.panel.querySelector('#filteredBtn').addEventListener('click', () => this.runFilteredWorkflow());
      this.panel.querySelector('#dailyQueryBtn').addEventListener('click', () => this.runDailyQuery());
      this.panel.querySelector('#dailyOpenAllBtn').addEventListener('click', () => this.openAllDailyPdfs());
      this.panel.querySelector('#dailyQueueBtn').addEventListener('click', () => this.queuePrintDailyPdfs());
      this.panel.querySelector('#memurBtn').addEventListener('click', async () => {
        await eysStorageSet(CFG.STORAGE_KEY, { role: '10', t: Date.now() });
        this.log('main', 'Memur için refresh başlatılıyor...');
        location.reload();
      });
      this.panel.querySelector('#mudurBtn').addEventListener('click', async () => {
        await eysStorageSet(CFG.STORAGE_KEY, { role: '20', t: Date.now() });
        this.log('main', 'Müdür için refresh başlatılıyor...');
        location.reload();
      });
      this.panel.querySelector('#eys_toggle').addEventListener('click', () => {
        const wrap = this.panel.querySelector('#eys_wrap');
        wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
      });
      this.panel.querySelector('#eys_close').addEventListener('click', () => {
        this.stop();
        this.panel.remove();
      });
    }

    activateTab(tab) {
      this.panel.querySelectorAll('.tab-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
      this.panel.querySelectorAll('.tab-page').forEach(page => page.classList.toggle('active', page.dataset.page === tab));
    }

    setButtons(running) {
      this.panel.querySelector('#runBtn').style.display = running ? 'none' : 'block';
      this.panel.querySelector('#stopBtn').style.display = running ? 'block' : 'none';
    }

    getMainConfig() {
      return {
        bastar: this.panel.querySelector('#main_bastar').value.trim(),
        bittar: this.panel.querySelector('#main_bittar').value.trim()
      };
    }

    getFilteredConfig() {
      return {
        role: this.panel.querySelector('#filtered_role').value.trim() || '20',
        servis: this.panel.querySelector('#filtered_servis').value.trim(),
        action: this.panel.querySelector('#filtered_action').value.trim(),
        bastar: this.panel.querySelector('#filtered_bastar').value.trim(),
        bittar: this.panel.querySelector('#filtered_bittar').value.trim()
      };
    }

    getDailyConfig() {
      return {
        role: this.panel.querySelector('#daily_role').value.trim() || '20',
        servis: this.panel.querySelector('#daily_servis').value.trim(),
        date: this.panel.querySelector('#daily_date').value.trim(),
        printer: this.panel.querySelector('#daily_printer').value.trim(),
        delay: Number(this.panel.querySelector('#daily_delay').value.trim() || '1800') || 1800
      };
    }

    async ensureSideUrl() {
      if (this.sideUrl) return this.sideUrl;
      const candidates = buildSideCandidates();
      this.log('main', 'side-dispatch adresi aranıyor...');
      for (const url of candidates) {
        const probe = await tryPost(url, CFG.COMMANDS.SIDE_GET_MODULE_INFO, { moduleName: 'e', excludeList: [], lang: 'tr' });
        if (!probe || !probe.__error) {
          this.sideUrl = url;
          this.log('main', 'Kullanılacak side-dispatch: ' + url);
          return url;
        }
      }
      throw new Error('Çalışan side-dispatch adresi bulunamadı.');
    }

    async bootRole(role, tab = 'main') {
      const sessionData = buildSessionData(role);
      const isMudur = String(role) === '20';
      const user = sessionData.user;
      const sideUrl = await this.ensureSideUrl();
      const bfNames = isMudur ? ['e.P_DESKTOP_MUDUR'] : ['e.PG_INDEX'];
      const loadedList = isMudur ? ['g.PG_INDEX', 'e.PG_INDEX'] : ['g.PG_INDEX', 'g.PG_MHK_ANA_SAYFA'];

      this.log(tab, `${isMudur ? 'Müdür' : 'Memur'} bot BF yükleniyor: ${bfNames.join(', ')}`);

      await post(sideUrl, CFG.COMMANDS.SIDE_GET_MODULE_INFO, {
        moduleName: 'e',
        excludeList: [
          'jquery','jquery-ui','jquery-ui-timepicker','ui.datepicker-tr','jquery.maskedinput',
          'jquery.ratings','jquery-jmenu','jquery-currency-autonumeric','underscore','tinymce','nouislider','tus'
        ],
        lang: 'tr'
      });

      await post(sideUrl, CFG.COMMANDS.SIDE_GET_EAGER_BF_DEFS, {
        userid: user,
        bfnames: bfNames,
        loadedList,
        resourceBundleLang: 'tr'
      });

      try { await post(sideUrl, CFG.COMMANDS.SIDE_GET_SERVICE_DEF_LIST, {}); } catch (_) {}
      await post(CFG.EYS_URL, CFG.COMMANDS.CREATE_SESSION, { orgs: [{ birimKodu: sessionData.birim }], sessionData });
      try { await post(CFG.EYS_URL, CFG.COMMANDS.CHECK_USER, { tckn: sessionData.user, sessionData }); } catch (_) {}
      try { await post(CFG.EYS_URL, CFG.COMMANDS.GET_VD_ADI, { vdkodu: sessionData.birim, sessionData }); } catch (_) {}
      return sessionData;
    }

    async getMemurList(sessionData, config = null) {
      const { bastar, bittar } = config || this.getMainConfig();
      return post(CFG.EYS_URL, CFG.COMMANDS.MEMUR_LIST, { bastar, bittar, vdkodu: sessionData.birim, sessionData });
    }

    async sendToMudur(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MEMUR_SEND, { ykodlari, sessionData });
    }

    async getMudurList(sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MUDUR_LIST, { birim: sessionData.birim, sessionData });
    }

    async sendToKoor(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MUDUR_SEND, { ykodlari, sessionData });
    }

    async getYoklamalarFiltered(sessionData, servis, range, tab = 'filtered', opts = {}) {
      const ydurum = String(opts.ydurum ?? '');
      const sonucislem = String(opts.sonucislem ?? '1');
      this.log(tab, `Yoklamalar sorgulanıyor. servis=${servis} bastar=${range.bastar} bittar=${range.bittar} ydurum=${ydurum || '-'} sonucislem=${sonucislem}`);
      return post(CFG.EYS_URL, CFG.COMMANDS.GET_YOKLAMALAR, {
        data: {
          koor: '', vd: sessionData.birim, vdkodu: sessionData.birim, sorgukaynak: '0', icdis: '0',
          disil: '', disvd: '', basvkn: '', sonvkn: '', bastckn: '', sontckn: '', yabanci: 0,
          vkn: '', tckn: '', yturu: [], ydurum, sonucislem, servis: String(servis || ''),
          bastar: range.bastar, bittar: range.bittar, unvan: '', ym: '', usekullanici: false,
          eosusergiris: sessionData.giris, eosuser: sessionData.user, ihbaraDayali: false
        },
        sessionData
      });
    }

    async archiveYoklamalar(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.ARCHIVE_YOKLAMA, { ykodlari, sessionData });
    }

    async markIslemYapildi(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.ISLEM_YAPILDI, { ykodlari, durum: '80', islem: 'işlem', sessionData });
    }

    async runFilteredWorkflow() {
      if (this.filteredInFlight) return this.log('filtered', 'Filtreli işlem zaten çalışıyor.');
      const cfg = this.getFilteredConfig();
      if (!cfg.servis || !cfg.bastar || !cfg.bittar) return this.log('filtered', 'Rol/servis/tarih alanları boş bırakılamaz.', true);

      this.filteredInFlight = true;
      try {
        const roleName = cfg.role === '10' ? 'Memur' : 'Müdür';
        this.log('filtered', `Filtreli işlem başlatıldı. rol=${roleName} servis=${cfg.servis} aksiyon=${cfg.action}`);
        const sessionData = await this.bootRole(cfg.role, 'filtered');
        const listResp = await this.getYoklamalarFiltered(sessionData, cfg.servis, { bastar: cfg.bastar, bittar: cfg.bittar }, 'filtered');
        const rows = extractYoklamaRows(listResp);
        const filteredRows = clientFilterRows(rows, cfg);
        const ykodlari = filteredRows.map(x => x.ykodu);
        this.log('filtered', `Sorgu response önizleme: ${previewResponse(listResp)}`);
        this.log('filtered', `Servisten gelen kayıt: ${rows.length}, istemci filtresinden geçen: ${filteredRows.length}`);
        if (rows.length && !filteredRows.length) {
          this.log('filtered', 'Uyarı: servis kayıt döndürdü ama tarih/servis istemci filtresinden hiç kayıt geçmedi.', true);
        }
        if (!ykodlari.length) return this.log('filtered', 'Uygun yoklama bulunamadı.');
        this.log('filtered', `Toplam ${ykodlari.length} yoklama işlenecek. İlk kayıt: ${ykodlari[0]}`);
        const actionResp = cfg.action === 'archive'
          ? await this.archiveYoklamalar(ykodlari, sessionData)
          : await this.markIslemYapildi(ykodlari, sessionData);
        this.log('filtered', `${cfg.action === 'archive' ? 'Arşive kaldırma' : 'İşlem yapıldı'} tamamlandı. (${ykodlari.length} kayıt)`);
        this.log('filtered', `Aksiyon response: ${previewResponse(actionResp)}`);
      } catch (err) {
        this.log('filtered', err?.message || String(err), true);
      } finally {
        this.filteredInFlight = false;
      }
    }

    buildPdfUrl(ykodu, opts = {}) {
      const base = window.location.origin.includes('eyoklama.gelirler.gov.tr')
        ? window.location.origin
        : 'http://eyoklama.gelirler.gov.tr:32516';
      const u = new URL(`${base}/edenetis/getSonuc`);
      u.searchParams.set('yKodu', String(ykodu || ''));
      if (opts.autoPrint) u.searchParams.set('eys_autoprint', '1');
      if (opts.delay) u.searchParams.set('eys_delay', String(opts.delay));
      if (opts.closeAfter) u.searchParams.set('eys_close', '1');
      return u.toString();
    }

    renderDailyList() {
      const box = this.panel.querySelector('#daily_list');
      box.innerHTML = '';
      if (!this.dailyRows.length) {
        box.innerHTML = '<div class="list-row"><span class="tiny">Henüz kayıt yok.</span></div>';
        return;
      }
      this.dailyRows.forEach((row, index) => {
        const div = document.createElement('div');
        div.className = 'list-row';
        div.innerHTML = `
          <div>
            <div><strong>${row.ykodu}</strong></div>
            <div class="tiny">servis=${row.servis || '-'} durum=${row.durum || '-'} archived=${row.archived || '-'} ${row.unvan || ''}</div>
          </div>
          <div>
            <button class="inline-btn" data-open="${index}">PDF Aç</button>
            <button class="inline-btn good" data-print="${index}">Yazdır 1-2</button>
          </div>`;
        box.appendChild(div);
      });
      box.querySelectorAll('[data-open]').forEach(btn => btn.addEventListener('click', () => this.openDailyPdf(Number(btn.dataset.open))));
      box.querySelectorAll('[data-print]').forEach(btn => btn.addEventListener('click', () => this.printDailyPdf(Number(btn.dataset.print))));
    }

    async runDailyQuery() {
      if (this.dailyInFlight) return this.log('daily', 'Günlük sorgu zaten çalışıyor.');
      const cfg = this.getDailyConfig();
      if (!cfg.servis || !cfg.date) return this.log('daily', 'Rol/servis/tarih boş bırakılamaz.', true);

      this.dailyInFlight = true;
      try {
        this.log('daily', `Günlük sorgu başlatıldı. rol=${cfg.role === '10' ? 'Memur' : 'Müdür'} servis=${cfg.servis} tarih=${cfg.date}`);
        const sessionData = await this.bootRole(cfg.role, 'daily');
        const listResp = await this.getYoklamalarFiltered(
          sessionData,
          cfg.servis,
          { bastar: cfg.date, bittar: cfg.date },
          'daily',
          { ydurum: '60', sonucislem: '1' }
        );
        this.dailyRows = extractYoklamaRows(listResp);
        this.log('daily', `Sorgu response önizleme: ${previewResponse(listResp)}`);
        this.log('daily', 'Günlük sorgu filtreleri: yoklama durumu=sonuçlandı (60), işlem durumu=işlem yapılacaklar (1)');
        this.log('daily', `Toplam ${this.dailyRows.length} kayıt bulundu.`);
        if (cfg.printer) this.log('daily', `Seçili yazıcı notu: ${cfg.printer}`);
        this.renderDailyList();
      } catch (err) {
        this.log('daily', err?.message || String(err), true);
      } finally {
        this.dailyInFlight = false;
      }
    }

    openDailyPdf(index) {
      const row = this.dailyRows[index];
      if (!row) return;
      const url = this.buildPdfUrl(row.ykodu);
      this.log('daily', `PDF açılıyor: ${row.ykodu}`);
      window.open(url, '_blank', 'noopener');
    }

    async printDailyPdf(index) {
      const row = this.dailyRows[index];
      if (!row) return;
      const cfg = this.getDailyConfig();
      const url = this.buildPdfUrl(row.ykodu, { autoPrint: true, delay: cfg.delay });
      this.log('daily', `PDF yazdırma denemesi: ${row.ykodu} (Chrome PDF viewer otomatik print)`);
      const win = window.open(url, '_blank');
      if (!win) return this.log('daily', 'Popup engellendi. PDF penceresi açılamadı.', true);
      try {
        await sleep(300);
        win.focus();
        this.log('daily', 'PDF sekmesi açıldı. Otomatik print parametresi gönderildi; olmazsa Ctrl+P kullan.');
      } catch (err) {
        this.log('daily', 'PDF sekmesi açıldı ama focus/print izleme başarısız: ' + (err?.message || String(err)), true);
      }
    }

    openAllDailyPdfs() {
      if (!this.dailyRows.length) return this.log('daily', 'Önce günlük sorgu yap.', true);
      this.log('daily', `Toplam ${this.dailyRows.length} PDF açılıyor...`);
      this.dailyRows.forEach((_, index) => this.openDailyPdf(index));
    }

    async queuePrintDailyPdfs() {
      if (this.dailyQueueInFlight) return this.log('daily', 'Kuyruk yazdırma zaten çalışıyor.');
      if (!this.dailyRows.length) return this.log('daily', 'Önce günlük sorgu yap.', true);
      this.dailyQueueInFlight = true;
      const cfg = this.getDailyConfig();
      try {
        this.log('daily', `Kuyruk yazdırma başladı. kayıt=${this.dailyRows.length} gecikme=${cfg.delay}ms`);
        if (cfg.printer) this.log('daily', `Hedef yazıcı notu: ${cfg.printer}`);
        for (let i = 0; i < this.dailyRows.length; i += 1) {
          const row = this.dailyRows[i];
          this.log('daily', `${i + 1}/${this.dailyRows.length} işleniyor: ${row.ykodu}`);
          const autoUrl = this.buildPdfUrl(row.ykodu, { autoPrint: true, delay: cfg.delay });
          const win = window.open(autoUrl, '_blank');
          if (!win) {
            this.log('daily', `Popup engellendi: ${row.ykodu}`, true);
          } else {
            try { win.focus(); } catch (_) {}
          }
          await sleep(Math.max(1200, cfg.delay + 700));
        }
        this.log('daily', 'Kuyruk açma tamamlandı. Her PDF sekmesi otomatik print denedi; gerekirse Ctrl+P ile devam et.');
      } catch (err) {
        this.log('daily', err?.message || String(err), true);
      } finally {
        this.dailyQueueInFlight = false;
      }
    }

    scheduleNext(reason) {
      if (!this.running) return;
      clearTimeout(this.timer);
      this.log('main', `${reason} 5 dakika sonra yeni tur başlayacak...`);
      this.timer = setTimeout(() => this.runCycle(), CFG.RESCAN_MS);
    }

    async runMudurStage() {
      this.log('main', 'Müdür oturumu açılıyor...');
      const mudurSession = await this.bootRole('20', 'main');
      this.log('main', 'Müdür onay bekleyen listesi sorgulanıyor...');
      const mudurResp = await this.getMudurList(mudurSession);
      const mudurYkodlari = extractYkodlariStrict(mudurResp);
      this.log('main', `Müdür response önizleme: ${previewResponse(mudurResp)}`);
      if (mudurYkodlari.length > 0) {
        this.log('main', `Müdür listesinde ${mudurYkodlari.length} kayıt bulundu. İlk kayıt: ${mudurYkodlari[0]}`);
        const sendResp = await this.sendToKoor(mudurYkodlari, mudurSession);
        this.log('main', `Müdür → Koordinatör gönderimi tamamlandı. (${mudurYkodlari.length} kayıt)`);
        this.log('main', `Müdür gönderim response: ${previewResponse(sendResp)}`);
        return true;
      }
      this.log('main', 'Müdür listesi boş.');
      return false;
    }

    async runCycle() {
      if (!this.running || this.inFlight) return;
      this.inFlight = true;
      this.cycleNo += 1;
      try {
        const dateCfg = this.getMainConfig();
        this.log('main', `Tur #${this.cycleNo} başladı. bastar=${dateCfg.bastar} bittar=${dateCfg.bittar}`);
        this.log('main', 'Memur oturumu açılıyor...');
        const memurSession = await this.bootRole('10', 'main');
        this.log('main', 'Memur listesi sorgulanıyor...');
        const memurResp = await this.getMemurList(memurSession, dateCfg);
        const memurYkodlari = extractYkodlariStrict(memurResp);
        this.log('main', `Memur response önizleme: ${previewResponse(memurResp)}`);
        if (memurYkodlari.length > 0) {
          this.log('main', `Memur listesinde ${memurYkodlari.length} kayıt bulundu. İlk kayıt: ${memurYkodlari[0]}`);
          const sendResp = await this.sendToMudur(memurYkodlari, memurSession);
          this.log('main', `Memur → Müdür gönderimi tamamlandı. (${memurYkodlari.length} kayıt)`);
          this.log('main', `Memur gönderim response: ${previewResponse(sendResp)}`);
          await sleep(CFG.AFTER_MEMUR_SEND_WAIT_MS);
          const mudurProcessed = await this.runMudurStage();
          this.scheduleNext(mudurProcessed ? 'Müdür aşaması da çalıştı.' : 'Müdür aşaması boş geçti.');
          return;
        }
        this.log('main', 'Memur listesi boş. Doğrudan müdür aşamasına geçiliyor...');
        const mudurProcessed = await this.runMudurStage();
        this.scheduleNext(mudurProcessed ? 'Müdür aşaması çalıştı.' : 'Bekleyen kayıt yok.');
      } catch (err) {
        this.log('main', err?.message || String(err), true);
        this.scheduleNext('Hata sonrası yeniden deneme için');
      } finally {
        this.inFlight = false;
      }
    }

    start() {
      if (this.running) return;
      this.running = true;
      this.setButtons(true);
      this.log('main', 'Bot başlatıldı. Bu akış yalnız Akış sekmesinin tarihlerini kullanır.');
      this.runCycle();
    }

    stop() {
      this.running = false;
      this.inFlight = false;
      clearTimeout(this.timer);
      this.timer = null;
      this.setButtons(false);
      this.log('main', 'Bot durduruldu.');
    }
  }

  function findRoleSelect() {
    const candidates = Array.from(document.querySelectorAll('select.csc-combobox, select'));
    for (const sel of candidates) {
      if (!visible(sel)) continue;
      const joined = Array.from(sel.options || []).map(o => textOf(o).toLowerCase()).join(' | ');
      if (joined.includes('yoklama') || joined.includes('memur') || joined.includes('müdür')) return sel;
    }
    return null;
  }

  function findOpenButton() {
    const candidates = Array.from(document.querySelectorAll('input.csc-button,input[type="button"],input[type="submit"],button'));
    for (const el of candidates) {
      if (!visible(el)) continue;
      const txt = textOf(el).toLowerCase();
      if (txt.includes('eys modülünü aç') || txt.includes('eys modulunu ac') || txt.includes('eys mod')) return el;
    }
    return null;
  }

  function findEysLauncher() {
    const exact = document.querySelector('#gen__1023.csc-button.gibintra-uyg-btns.gibintra-eds-btn');
    if (exact && visible(exact)) return exact;
    const all = Array.from(document.querySelectorAll('input.csc-button,button,input[type="button"],input[type="submit"],a,div,span')).filter(visible);
    const scored = all.map(el => {
      const txt = `${textOf(el)} ${el.id || ''} ${el.className || ''}`.toLowerCase();
      let score = 0;
      if (txt.includes('eys')) score += 10;
      if (txt.includes('elektronik yoklama')) score += 8;
      if (txt.includes('yoklama')) score += 6;
      if (txt.includes('gibintra-eds-btn')) score += 5;
      if (txt.includes('uyg-btn')) score += 3;
      return { el, score };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);
    return scored[0]?.el || null;
  }

  async function waitForPopupReady(log) {
    const started = Date.now();
    while (Date.now() - started < 15000) {
      const sel = findRoleSelect();
      const btn = findOpenButton();
      if (sel && btn) {
        log('Popup hazır. Rol seçimi ve aç butonu bulundu.');
        return true;
      }
      await sleep(300);
    }
    return false;
  }

  function selectRole(role, log) {
    const sel = findRoleSelect();
    if (!sel) return false;
    const targetNeedle = String(role) === '20' ? 'müdür' : 'memur';
    const opt = Array.from(sel.options).find(o => textOf(o).toLowerCase().includes(targetNeedle));
    if (!opt) return false;
    sel.value = opt.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    log(`Rol seçildi: ${opt.text}`);
    return true;
  }

  async function openFlow(role, log) {
    const launcher = findEysLauncher();
    if (!launcher) return log('EYS launcher bulunamadı.', true);
    log('EYS launcher tetikleniyor...');
    launcher.click();
    const ready = await waitForPopupReady(log);
    if (!ready) return log('Popup hazır olmadı.', true);
    const selected = selectRole(role, log);
    if (!selected) return log('Rol seçilemedi.', true);
    const btn = findOpenButton();
    if (!btn) return log('"EYS MODÜLÜNÜ AÇ" butonu bulunamadı.', true);
    log('Aç butonuna basılıyor...');
    btn.click();
    log('Açma akışı gönderildi.');
  }

  async function resumeIfNeeded(log) {
    const data = await eysStorageGet(CFG.STORAGE_KEY);
    if (!data || !data.role || Date.now() - Number(data.t || 0) > 120000) return;
    await eysStorageRemove(CFG.STORAGE_KEY);
    log(`Refresh sonrası otomatik devam ediyor. role=${data.role}`);
    openFlow(data.role, log);
  }

  injectStyle();
  const panel = createPanel();
  eysTryEmbedIntoMainPanel();
  const bot = new EysFullBot(panel);
  bot.log('main', 'Hazır.');
  bot.log('filtered', 'Hazır. Bu monitör yalnız Filtreli İşlem sekmesine aittir.');
  bot.log('daily', 'Hazır. Bu monitör yalnız Günlük PDF sekmesine aittir.');
  resumeIfNeeded(msg => bot.log('main', msg));
})();

try { setInterval(eysTryEmbedIntoMainPanel, 800); } catch (_) {}
