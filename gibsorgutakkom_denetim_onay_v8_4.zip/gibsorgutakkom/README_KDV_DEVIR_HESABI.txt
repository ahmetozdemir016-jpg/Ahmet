YILLIK KDV DEVİR HESABI

Normal “Yıllık KDV-BS-POS” ekranı değiştirilmemiştir. Yeni hesaplama ayrı bir sayfadadır.

1. Ana ekranda “Yıllık KDV Devir Hesabı” düğmesine basın.
2. Hesabın başlayacağı yılı girin. Program başlangıç yılından itibaren en fazla 5 yılı getirir.
3. KDV beyan verileri otomatik çekilir.
4. Düzeltme bulunan aylarda yalnızca ilgili sarı alanları doldurun:
   - İlave Matrah
   - İlave matrahın yanındaki KDV Oranı
   - Reddedilen İndirim KDV
5. “Hesapla ve Devret” düğmesine basın.

Aynı ayda birden fazla ilave matrah ve oran girilebilir. “+ Matrah / Oran Ekle” düğmesi yeni satır açar. KDV oranı serbestçe değiştirilebilir. Program 2023/06 ve önceki dönemler için %18, 2023/07 ve sonraki dönemler için %20 oranını başlangıç değeri olarak getirir; eski dönemlerde %1/%8/%18, yeni dönemlerde %1/%10/%20 seçeneklerini de önerir.

Tevkifatlı işlem varsa aynı satırdaki “Tevkifat” alanına 5/10, 7/10, 9/10 gibi kesir veya 50, 70, 90 gibi yüzde yazılabilir. Boş bırakılırsa tevkifat uygulanmaz. Program brüt hesaplanan KDV’den tevkif edilen kısmı ayırır ve satıcının beyan edeceği ilave KDV’yi düzeltme hesabına ekler.

“Çıktı Al” düğmesi önce mevcut girişleri hesaplar. Çıktıda her yıl ayrı bir yatay A4 sayfasında ve tek tabloda gösterilir. Normal beyan ve düzeltilmiş tutarlar yan yana sütunlardadır; ödenecek ve devreden KDV farkları ayrıca gösterilir. Boş matrah giriş alanları çıktıya basılmaz.
Çıktıda Hesaplanan KDV hücrelerinde yalnızca beyan ve düzeltilmiş tutarlar yer alır; okunabilirliği azaltan alt “Toplam KDV” satırı bulunmaz.
Matrah takdirinden hesaplanan yeni vergi, yıllık KDV cevabındaki ayrı “İlave Edilecek KDV” alanına eklenir. Hesaplanan KDV alanı değiştirilmez; Toplam KDV, Hesaplanan KDV ile İlave Edilecek KDV toplamına göre güncellenir. Karşılaştırma ekranı beyan tablosundaki sırayı izler ve Önceki Dönem Devri de beyan/düzeltilmiş olarak gösterilir.

Matrah takdirinden doğan KDV, Hesaplanan KDV'nin düzeltilmiş tutarına eklenir. İlave Edilecek KDV alanı matrah takdiri nedeniyle değiştirilmez.

Çıktıda her yıl aynı A4 yatay sayfada iki geniş tablo halinde gösterilir: üst tabloda Önceki Dönem Devri'ne kadar olan alanlar, alt tabloda Toplam İndirim ve sonrasındaki sonuç alanları bulunur.

İade KDV de “Beyan / Düzeltilmiş / Fark” sütunlarında karşılaştırılır. İlave KDV veya reddedilen indirim nedeniyle kullanılabilir alacak bakiyesi azalırsa düzeltilmiş iade KDV azalabilir ya da sıfırlanabilir. Düzeltme, devreden ve iade bakiyelerinin toplamını da aşarsa kalan kısım ödenecek farkına dönüşür.

Reddedilen indirim toplam indirilecek KDV’den düşülür. Düzeltilmiş devreden KDV bir sonraki aya aktarılır. Beyannamedeki iade edilmesi gereken KDV de korunur; indirim bakiyesi hem toplam KDV’yi hem iadeyi karşılamazsa eksik kalan kısım düzeltilmiş ödenecek KDV’ye ve ödenecek farkına dahil edilir.

Girilen düzeltmeler mükellef VKN’sine göre tarayıcıda saklanır. “Girdileri Temizle” yalnızca bu mükellefe ait ilave matrah ve indirim reddi girişlerini siler.

İlave matrah ve reddedilen indirim girilmemişse beyan ödenecek/devreden sonuçları aynen korunur; iki fark sütunu da 0,00 olur. Bir ayın beyan edilen önceki devri ile önceki ayın sonraki devri farklı olsa bile bu beyan farklılığı düzeltme olarak ileri taşınmaz.
