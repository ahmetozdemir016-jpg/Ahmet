/* file:// TAKKOM sayfası <-> uzantı köprüsü */
(function () {
  window.addEventListener('message', function (ev) {
    if (ev.source !== window) return;
    const d = ev.data || {};
    if (d.type === 'TAKKOM_PDF_PING') { window.postMessage({ type: 'TAKKOM_PDF_PONG', version: '1.0.0' }, '*'); return; }
    if (d.type === 'TAKKOM_PDF_REQUEST') {
      const rid = String(d.requestId || '');
      try {
        chrome.runtime.sendMessage({ type: 'TK_PDF_FETCH', url: String(d.url || '') }, function (resp) {
          window.postMessage(Object.assign({ type: 'TAKKOM_PDF_RESPONSE', requestId: rid }, resp || { ok: false, error: 'uzantı cevap vermedi' }), '*');
        });
      } catch (e) { window.postMessage({ type: 'TAKKOM_PDF_RESPONSE', requestId: rid, ok: false, error: String(e) }, '*'); }
    }
  });
})();
