TAKKOM PDF OKUYUCU v1.0

Ne için: Denetim Tutanağı ekranındaki "Tutanak Bilgilerini Getir" (Belge İhlal / Diğer Hususlar sütunları)
ve sayfa içi Sonuç/Ek görüntüleme. Tarayıcı, file:// sayfasının eyoklama sunucusundan PDF içeriğini
okumasına CORS nedeniyle izin vermez; bu uzantı PDF'i kendi izniyle indirip sayfaya verir.
Token Dinleyici'den bağımsızdır; onunla birlikte çalışır. Kurulu değilse sayfanın diğer işlevleri etkilenmez.

Kurulum: Chrome > Uzantılar > Geliştirici modu > Paketlenmemiş yükle > bu klasör > uzantı detayında
"Dosya URL'lerine erişime izin ver" AÇIK olmalı (file:// sayfalarında çalışabilmesi için).

Ne yapar / yapmaz: Yalnızca http://eyoklama.gelirler.gov.tr adreslerine GET atar, sonucu sayfaya döndürür.
Hiçbir veri saklamaz, başka adrese istek atmaz.
