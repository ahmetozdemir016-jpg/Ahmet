DENETİM TUTANAĞI – YOKLAMA ONAY (İŞLEM BEKLEYEN DENETİMLER) TOPLU İŞLEM EKRANI

Ana ekranda "Denetim Tutanağı – Yoklama Onay (toplu arşiv/iade)" düğmesi
diger/denetim-tutanagi-onay.html sayfasını açar. Sayfa KEYS'teki
"Denetim Tutanağı Düzenlenen Mükellefler / İşlem Bekleyen Denetimler"
listesini tüm sayfalarıyla çeker; Öneri / İşlem / Düzenleyen filtreleri,
VKN-ünvan arama, tik kutuları ile seçim ve seçilenlere toplu
"Kontrol Edildi (arşive kaldır)" veya "İade Et" uygular. İşlemler KEYS
akışındaki gibi tek tek, satır satır gönderilir; ilerleme çubuğu ve her
satırın sonucu tabloda gösterilir. Satır başındaki "Sonuç" / "Ek"
düğmeleri yoklama sonucunu ve ekini açar.

ÖN KOŞUL: Token Dinleyici uzantısını v1.18 (eklentiler/gib_token_dinleyici_v1_18) ile
güncelleyin. v1.17 yalnızca keyss/external_dispatch ve gibintranet_server/dispatch
isteklerini kaydediyordu; Denetim Tutanağı ekranının istekleri bu yollarda değil.
v1.18 keys.ggm.bim/gibintranet altındaki tüm dinamik istekleri ve her */dispatch
yolunu kaydeder; ayrıca TAKKOM sayfalarının KEYS'e tarayıcı oturumu (çerez) ile
istek atmasını sağlayan bir köprü içerir (klasik JSP ekranları için gerekli).
Sayfa üstünde "uzantı köprüsü hazır (v1.18)" yazmalı.

İLK KULLANIM – SERVİSLERİ ÖĞRETME (bir kez)
Bu ekranın KEYS'te hangi servisleri çağırdığı elimizde olmadığından sayfa
bunları Token Dinleyici uzantısının istek kayıtlarından öğrenir:
1. KEYS'te ekranı açın, "Listeyi Yenile"ye basın, sayfalayıcıdan 2. sayfaya geçin
   (sayfalama parametresi böyle öğrenilir).
2. Bir satırda sağ tık > Sonuç Göster, sonra Sonuç Ek Göster yapın.
3. Gerçekten arşive kaldırılacak bir satırda "Kontrol Edildi", gerçekten
   iade edilecek bir satırda "İade Et" yapın (KEYS'te uygulanır).
4. TAKKOM sayfasında "Yakalanan İsteklerden Servisleri Öğren"e basın,
   listede her isteğe rolünü seçip Kaydet'e basın. Roller otomatik
   tahmin edilir; emin olmadığınız satırı boş bırakın.
5. "Listeyi Getir"e basın. Sayfa öğrenilen işlem parametrelerinde hangi
   değerin satıra özgü olduğunu (oid vb.) listeden bularak eşler.
   Eşleme bulunamadıysa öğretilen satır listede yok demektir; tekrar
   öğretin veya Servis Ayarları'nda "map" alanını elle girin.

Öğrenilen servisler tarayıcıda (takkom_denetim_onay_servis_v1) saklanır.
"Servis Ayarları" JSON'unu "Kopyala" ile paylaşırsanız servis adları
sonraki sürümde sayfaya sabit olarak yazılabilir.

NOTLAR
- Token: gibintranet tokeni (takdire-sevk menüsünden açınca gelir).
- "Bekleme (ms)" iki istek arasındaki beklemedir (varsayılan 400).
- İade Et parametrelerinde neden/açıklama alanı varsa toplu iadede sorulur.
- Sonuç / Ek açmada cevaptaki PDF (base64), URL veya öğrenme sırasında
  yakalanan görüntüleme adresi kullanılır; hiçbiri yoksa ham cevap gösterilir.

VKN ARALIĞI VE SIRALAMA
- Filtre kutusundaki "VKN aralığı" alanlarına başlangıç/bitiş yazılınca
  yalnızca o aralıktaki satırlar gösterilir (VKN boşsa TCKN kullanılır).
  Aralık, "Görünenlerin tümünü seç" ile birlikte toplu işlem için de geçerlidir.
- "VKN'ye göre sırala" düğmesi veya VKN sütun başlığı listeyi rakamsal
  olarak sıralar; ikinci tıklama ters çevirir.

İSTEK TÜRLERİ
Sayfa iki tür isteği öğrenip tekrar oynatır: dispatch (cmd/jp JSON) ve klasik
form/JSP (POST/GET parametreleri, HTML cevap). HTML cevapta en büyük tablo satırlara
çevrilir; satırdaki gizli kimlikler (input value, onclick, href içindeki oid/no)
__id1, __id2... alanları olarak saklanır ve satır eşlemesinde kullanılır.
Öğrenme listesinde TAKKOM'un kendi sorguları ve portal genel istekleri gizlidir;
"gizlenenleri de göster" ile açılır. Takılınca satırları işaretleyip
"Seçilenleri Kopyala" ile paylaşın (tokenler maskelenir).

EYS / e-DENETİM NOTLARI (İş Takip + EYS Bot v4.31'den)
- Ekran EYS sistemidir: http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch
- Satır kimliği ykodu; toplu işlem jp = {ykodlari:[...], sessionData}
- Bilinen servisler: liste srvcDashboard_getMudurIslemlerYOnayBekleyen / srvcDashboard_getMemurIslemlerYTum /
  srvcYoklama_getYoklamalar (data:{vd,vdkodu,ydurum:'60',sonucislem:'0',...}); Kontrol Edildi =
  srvcYoklama_islemYapildiYoklamaSonuc {ykodlari,durum:'80',islem:'işlem',sessionData} veya
  srvcArchive_archiveYoklama {ykodlari,sessionData}; iadeler srvcYoklama_getIadeler; PDF edenetis/getSonuc?yKodu=
- "İade Et" servisi bot'ta yok; öğrenme ile bulunur (v1.18 uzantı edenetis isteklerini kaydeder).
- sessionData ve EYS tokeni her işlemden önce yakalanan en yeni edenetis isteğinden alınır; KEYS'te EYS
  ekranı açık ve oturum canlı olmalı. Sonuç düğmesi öğrenme olmasa da ykodu varsa getSonuc ile PDF açar.

SABİT SERVİSLER (HAR'dan, 22.09.2026) — artık öğretme gerektirmez
- Liste: srvcDenetim... değil, srvcDashboard_getMudurIslemlerDIslemBekleyen  jp={birim:VD, sessionData}
  Cevap: data[] → koor_kodu, koor_name (Düzenleyen), vdkodu, bkodu (benzersiz kod = satır kimliği),
  durum, vkn, tckn, unvan, islem (1 İşleme Gerek Duyulmadı, 2 Hıfz, 4 Ceza Önerildi, 6 Genel Durum
  Tespiti, 7 Yeni Kayıt), cezalar, miktarlar, cezamiktart, oneri, optime, dmemuru, islendi.
  Tüm liste tek cevapta gelir (sayfalama yok).
- Kontrol Edildi: srvcDenetimSonuc_setGerekliIslemYapildi
  jp={vdkodu, bkodu, vkn, unvan, aciklama:"Öneri <öneri metni>", sessionData} → {"data":"ok"}
- İade Et: srvcDenetimSonuc_rejectOneri jp={bkodu, vdkodu, vkn, sebep:"...", sessionData}
  → {"data":"Öneri Koordinatörlüğe IADE edildi..."}; sebep toplu iade öncesi sorulur (varsayılan "sehven").
- Token: gibintranet tokeni ile aynı. sessionData={rol:"20",user:TC,giris:TC,birim:VD,il:VD[0..3],adi,userx:TC};
  yakalanan en yeni EYS isteğinden alınır, yoksa TC bir kez sorulup saklanır (takkom_eys_user).
- Sonuç Göster: GET http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?bkodu=<bkodu>  (çok sayfalı e-yoklama fişi PDF)
- Sonuç Ek Göster: GET http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?dKoduEk=<bkodu>  (tutanak fotoğrafı PDF)
  Her ikisi de uzantı köprüsüyle çerezli alınıp blob olarak açılır; köprü yoksa adres yeni sekmede açılır.
  Artık hiçbir öğretme adımı gerekmez; öğrenme kutusu yalnızca KEYS değişirse kullanılır.

v7.1: Sonuç / Ek PDF'leri ayrı sekme yerine sayfa içi açılır pencerede (Kapat düğmeli) gösterilir.
"Yakalanan İsteklerden Servisleri Öğren" bölümü kaldırıldı; tüm servisler sabit. Servis Ayarları (JSON) ileri düzey için durur.

v7.2 – v1.17 UYUMU
Sayfa Token Dinleyici v1.18 köprüsü olmadan da çalışır. Açılışta köprü 6 sn içinde yanıt vermezse
"köprüsüz mod" etiketi görünür ve:
- liste / Kontrol Edildi / İade Et istekleri doğrudan XHR ile eyoklama sunucusuna gider (gibintranet tokeni ile;
  EYS aynı tokeni kullanır),
- Sonuç / Ek PDF'leri açılır penceredeki iframe'e doğrudan adres olarak yüklenir (tarayıcı KEYS oturum çerezini
  kullanır; KEYS'te oturum açık olmalı),
- sessionData için TC kimlik no bir kez sorulur (v1.17 EYS isteklerini yakalamaz).
v1.18 kuruluysa köprü otomatik kullanılır.

v7.3 – KÖPRÜ KALDIRILDI
Uzantı köprüsü (v1.18) sayfadan tamamen çıkarıldı; Token Dinleyici v1.17 yeterlidir. Tüm istekler doğrudan XHR ile
gider. Sonuç/Ek PDF'leri: eyoklama sunucusu X-Frame-Options: DENY gönderdiğinden adres iframe'e konamaz; PDF önce
XHR ile blob olarak indirilip sayfa içi açılır pencerede (iframe, blob adresi) gösterilir; indirilemezse tarayıcının
ayrı açılır penceresinde (popup) açılır. Uzantı klasörü v1.18 kullanılmıyorsa silinebilir.

v8 – TUTANAK BİLGİLERİ + EXCEL
- "Tutanak Bilgilerini Getir (görünen satırlar)": her görünen satırın Sonuç PDF'i (getSonuc?bkodu=) indirilip
  js/pdf.js ile okunur; "BELGE İHLAL BİLGİLERİ" ve "TESPİT EDİLEN DİĞER HUSUSLAR" bölümleri iki yeni sütuna
  yazılır. Sonuçlar tarayıcıda (takkom_denetim_tutanak_v1, en çok 3000 kayıt) saklanır; aynı bkodu bir daha
  okunmaz. Arama kutusu bu iki sütunda da arar. Durdur ile kesilebilir.
- js/pdf.js ve js/pdf.worker.js: pdf.js 5.6.205 legacy yapısının klasik script (ESM olmayan) sarmalı;
  file:// altında modül/worker kısıtı olmadığı için bu şekilde paketlendi (worker ana iş parçacığında çalışır).
- Excel: artık gerçek .xlsx (JSZip ile) — başlık satırı renkli, otomatik filtre, uzun sütunlar geniş, Toplam Ceza sayısal.
- Satırdaki {} (ham veri) düğmesi kaldırıldı.

v8.1 – PDF OKUYUCU UZANTISI (isteğe bağlı)
getSonuc cevabında Access-Control-Allow-Origin başlığı olmadığından file:// sayfası PDF içeriğini XHR ile
okuyamaz (CORS). Bu yüzden eklentiler/takkom_pdf_okuyucu_v1 adında Token Dinleyici'den bağımsız, sadece
eyoklama adreslerine GET atan küçük bir uzantı eklendi. Kuruluysa: "Tutanak Bilgilerini Getir" çalışır ve
Sonuç/Ek sayfa içi pencerede açılır. Kurulu değilse: tutanak sütunları doldurulamaz (düğme uyarı verir),
Sonuç/Ek ayrı açılır pencerede açılır, diğer her şey aynen çalışır.
