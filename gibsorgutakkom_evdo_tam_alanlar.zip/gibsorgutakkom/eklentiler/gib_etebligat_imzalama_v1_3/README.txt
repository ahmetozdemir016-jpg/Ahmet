GİB E-Tebligat İmzalama v1.1

Kurulum:
1. ZIP dosyasını bir klasöre çıkarın.
2. Chrome adres çubuğuna chrome://extensions yazın.
3. Geliştirici modu'nu açın.
4. Paketlenmemiş öğe yükle seçeneğine basın.
5. Bu klasörü seçin.
6. E-Tebligat ekranını açın/yenileyin.

v1.1 değişiklikleri:
- Eklenti E-Tebligat sayfası açılırken yüklenir.
- Sabit kullanıcı kodu kaldırıldı.
- Sabit vergi dairesi / orgOid kaldırıldı.
- userSessionService_getUserSessionInfo açılış sorgusundan kullanıcı adı,
  kullanıcı kodu, orgOidList ve birimKoduList otomatik alınır.
- Panelde Kullanıcı, VD/Org OID ve VD Adı/Birim alanları otomatik gösterilir.
- VD adı sayfada bulunabiliyorsa ekrandan yakalanır; aksi halde oturumdaki
  birim kodu kullanılır.
- Başlat'a oturum bilgisi gelmeden basılırsa oturum sorgusunun tamamlanması beklenir.

v1.2: Panel yalnızca https://keys.ggm.bim/etebligat/index.jsp adresinde otomatik açılır. Diğer GİB sayfalarında otomatik çalışmaz.

v1.3 (v1.2 üzerine; oturum mantığı aynen korundu):
- HATA TESPİTİ DÜZELTİLDİ: yerel imza aracı/sunucu hata verince cevapta "success" alanı yoktur,
  {"error":"1","messages":[...]} gelir. v1.0–v1.2 bunu görmeyip "imzalandı" yazıyordu; artık yalnızca
  {"data":true} başarı sayılır (sertifika seçimi, iptal kontrolü ve imza için). Hata metni günlüğe düşer.
- Sonsuz döngü koruması: imzalanamayan belge sonraki turda tekrar denenmez; yeni belge kalmayınca durur.
- Belge Türü: 66 Ödeme Emri (eski davranış) / 13 İhbarname. Parti: 15 / 5 / 1 (tek tek, belge başına sonuç).
- Belge No listesi: doldurulursa YALNIZCA listedekiler imzalanır. TAKKOM "e-Tebligat İmza Bekleyen
  İhbarnameler" sayfasındaki "Seçili belge no'ları kopyala" düğmesiyle alınan liste buraya yapıştırılır.
- Bir belge/parti hata alınca işlem durmaz, sonrakine geçer; yalnızca kart oturumu düştüğünde (SELECT_CERTIFICATE) durur.
- PIN, sertifika seçilir seçilmez alandan silinir. İlerleme çubuğu ve sayaç eklendi.
