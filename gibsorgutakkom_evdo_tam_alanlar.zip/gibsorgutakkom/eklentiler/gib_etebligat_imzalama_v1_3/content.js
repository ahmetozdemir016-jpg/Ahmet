
(() => {
    'use strict';

    // Otomatik panel yalnızca E-Tebligat ana ekranında açılsın.
    if (window.location.hostname !== 'keys.ggm.bim' || window.location.pathname !== '/etebligat/index.jsp') return;

    function initExtension() {

    if (window.__gibETebligatPanelLoaded) return;
    window.__gibETebligatPanelLoaded = true;

    const existingPanel = document.getElementById('gib-etebligat-panel');
    if (existingPanel) {
        existingPanel.style.display = 'block';
        return;
    }

    // E-Tebligat açılışındaki gerçek oturum sorgusundan doldurulur.
    // Sabit kullanıcı / vergi dairesi bilgisi kullanılmaz.
    let detectedOrgOid = "";
    let detectedVdAdi = "";
    let detectedUserId = "";
    let detectedUserName = "";
    let detectedBirimKodu = "";
    let sessionInfo = null;

    const style = document.createElement('style');
    style.id = 'gib-etebligat-style';
    style.textContent = `
      #gib-etebligat-panel {
        position: fixed;
        top: 10%;
        right: 2%;
        width: 430px;
        max-width: 95vw;
        z-index: 999999;
        background: #060912;
        color: #eaf0ff;
        font: 12px/1.5 'Segoe UI', monospace, sans-serif;
        border: 1px solid #232b3a;
        border-radius: 8px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.8);
      }
      #gib-etebligat-panel * { box-sizing: border-box; }
      #gib-etebligat-panel .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 15px;
        border-bottom: 1px solid #232b3a;
        background: #121826;
        border-radius: 8px 8px 0 0;
      }
      #gib-etebligat-panel .header h3 {
        margin: 0;
        font-size: 14px;
        color: #eaf0ff;
      }
      #gib-etebligat-panel .header-btns button {
        background: none;
        border: 0;
        cursor: pointer;
        font-weight: bold;
        margin-left: 10px;
        font-size: 18px;
      }
      #gib-etebligat-panel .wrap {
        padding: 15px;
      }
      #gib-etebligat-panel label {
        display: block;
        color: #9aa6bf;
        margin-bottom: 3px;
        font-size: 10px;
        font-weight: bold;
        text-transform: uppercase;
      }
      #gib-etebligat-panel input {
        width: 100%;
        background: #050814;
        border: 1px solid #273048;
        padding: 8px;
        color: #eaf0ff;
        font-family: monospace;
        border-radius: 4px;
        font-size: 12px;
        margin-bottom: 10px;
      }
      #gib-etebligat-panel input:disabled {
        opacity: 0.7;
        cursor: not-allowed;
        border-color: #3ccf91;
        color: #3ccf91;
      }
      #gib-etebligat-panel button.action-btn {
        width: 100%;
        padding: 10px;
        border-radius: 4px;
        border: 0;
        font-weight: bold;
        cursor: pointer;
        transition: 0.2s;
        margin-bottom: 6px;
      }
      #gib-etebligat-panel #u_run { background: #3ccf91; color: #00170c; }
      #gib-etebligat-panel #u_stop { background: #ff6b6b; color: #fff; display: none; }
      #gib-etebligat-panel #logBox {
        background: #000;
        color: #0f0;
        font-family: Consolas, monospace;
        font-size: 11px;
        padding: 10px;
        border-radius: 5px;
        height: 230px;
        overflow-y: auto;
        border: 1px solid #333;
        margin-top: 10px;
      }
      #gib-etebligat-panel .log-line {
        margin-bottom: 3px;
        border-bottom: 1px solid #1a1a1a;
        padding-bottom: 2px;
      }
    `;
    if (!document.getElementById(style.id)) {
        document.head.appendChild(style);
    }

    const panel = document.createElement('div');
    panel.id = 'gib-etebligat-panel';
    panel.innerHTML = `
      <div class="header">
        <h3>⚡ GİB E-Tebligat İmzalama v1.3</h3>
        <div class="header-btns">
          <button type="button" id="u_toggle_panel" style="color:#00d2ff;" title="Küçült/Büyüt">−</button>
          <button type="button" id="u_close_panel" style="color:red;" title="Kapat">×</button>
        </div>
      </div>
      <div class="wrap" id="panel-wrap">
        <label>PIN Kodu</label>
        <input type="password" id="u_pin" placeholder="Şifrenizi Girin">

        <label>Kullanıcı</label>
        <input id="u_user" value="Oturum bilgisi bekleniyor..." disabled title="E-Tebligat açılış oturumundan otomatik çekilir">

        <label>VD / Org OID</label>
        <input id="u_orgoid" value="Oturum bilgisi bekleniyor..." disabled title="E-Tebligat açılış oturumundan otomatik çekilir">

        <label>VD Adı / Birim</label>
        <input id="u_vdadi" value="Oturum bilgisi bekleniyor..." disabled title="Sistemden otomatik belirlenir">

        <label>Belge Türü</label>
        <select id="u_tur" style="width:100%;background:#050814;border:1px solid #273048;padding:8px;color:#eaf0ff;border-radius:4px;margin-bottom:10px">
          <option value="66">66 — Ödeme Emri</option><option value="13">13 — İhbarname</option></select>

        <label>Parti (bir seferde kaç belge)</label>
        <select id="u_parti" style="width:100%;background:#050814;border:1px solid #273048;padding:8px;color:#eaf0ff;border-radius:4px;margin-bottom:10px">
          <option value="15">15</option><option value="5">5</option><option value="1">1 (tek tek, belge başına sonuç)</option></select>

        <label>Belge No listesi (isteğe bağlı — doldurulursa YALNIZCA bunlar imzalanır)</label>
        <textarea id="u_liste" rows="3" placeholder="TAKKOM inceleme sayfasından kopyalanan belge no'lar" style="width:100%;background:#050814;border:1px solid #273048;padding:8px;color:#eaf0ff;font-family:monospace;border-radius:4px;font-size:12px;margin-bottom:10px"></textarea>

        <label>Tek VKN</label>
        <input id="u_vkn" placeholder="Boş = Aralık" maxlength="11">

        <label>Aralık Baş</label>
        <input id="u_start" value="0000000000" maxlength="10">

        <label>Aralık Bit</label>
        <input id="u_end" value="9999999999" maxlength="10">

        <button id="u_run" type="button" class="action-btn">BAŞLAT</button>
        <button id="u_stop" type="button" class="action-btn">DURDUR</button>
        <div style="height:8px;background:#1a2133;border-radius:4px;margin:2px 0 4px;overflow:hidden"><div id="u_bar" style="height:100%;width:0;background:#3ccf91"></div></div>
        <div id="u_sayac" style="color:#9aa6bf;font-size:11px"></div>

        <div id="logBox"></div>
      </div>
    `;
    document.body.appendChild(panel);

    const _q = s => panel.querySelector(s);
    window.u_halt = false;

    const _log = (m, e = false) => {
        const b = _q('#logBox');
        if (!b) return;
        b.innerHTML += '<div class="log-line"><span style="color:#666">[' + new Date().toLocaleTimeString() + ']</span> ' + (e ? '<b style="color:#f55">HATA:</b> ' : '') + m + '</div>';
        b.scrollTop = b.scrollHeight;
    };

    async function _api(url, cmd, jp, local = false) {
        const p = new URLSearchParams();
        const token = new URLSearchParams(window.location.search).get('token');
        if (cmd) p.append('cmd', cmd);
        p.append('callid', Date.now());
        if (token) p.append('token', token);
        if (jp) p.append('jp', JSON.stringify(jp));
        if (local) p.append('module', 'sila');

        const r = await fetch(url, { method: 'POST', body: p, credentials: local ? 'omit' : 'include' });
        if (!r.ok) throw new Error("Ağ Hatası: " + r.status);
        const respText = await r.text();
        try { return JSON.parse(respText); } catch (e) { return respText; }
    }

    /* Cevap biçimi (HAR ile doğrulandı): başarı {"data":true}; hata {"error":"1","messages":[{"text":"..."}]} — "success" alanı YOKTUR. */
    const _hata = r => {
        if (!r || typeof r !== 'object') return 'boş/çözülemeyen cevap';
        if (r.error === '1' || r.error === 1 || r.error === true || r.success === false) return (r.messages && r.messages[0] && r.messages[0].text) || 'hata';
        if (Array.isArray(r.messages) && r.messages.some(m => String(m && m.type) === '1')) return r.messages.map(m => m.text).join('; ');
        return '';
    };
    const _sayac = (yapilan, toplam) => { const s = _q('#u_sayac'), b = _q('#u_bar'); if (s) s.textContent = toplam ? ('İmzalanan: ' + yapilan + ' / ' + toplam) : ''; if (b) b.style.width = (toplam ? Math.round(yapilan * 100 / toplam) : 0) + '%'; };

    function resetButtons() {
        _q('#u_run').style.display = 'block';
        _q('#u_stop').style.display = 'none';
    }

    function parseSideList(value) {
        if (Array.isArray(value)) return value;
        if (value === null || value === undefined) return [];
        const text = String(value).trim();
        if (!text) return [];
        const inner = text.startsWith('[') && text.endsWith(']') ? text.slice(1, -1) : text;
        return inner.split(',').map(x => x.trim()).filter(Boolean);
    }

    function findVdNameFromPage(orgOid, birimKodu) {
        const candidates = [];
        document.querySelectorAll('input, select, option, span, div, td, label').forEach(el => {
            const text = (el.value || el.textContent || '').trim();
            if (!text || text.length > 160) return;
            const upper = text.toLocaleUpperCase('tr-TR');
            if (upper.includes('VERGİ DAİRESİ') || upper.includes('VERGI DAIRESI')) candidates.push(text);
        });
        for (const el of document.querySelectorAll('tr, div, li, option')) {
            const text = (el.textContent || '').trim();
            if (!text || text.length > 300) continue;
            if ((orgOid && text.includes(orgOid)) || (birimKodu && text.includes(birimKodu))) {
                const upper = text.toLocaleUpperCase('tr-TR');
                if (upper.includes('VERGİ DAİRESİ') || upper.includes('VERGI DAIRESI')) return text;
            }
        }
        return candidates[0] || '';
    }

    function applySessionInfo(data) {
        const orgList = parseSideList(data.orgOidList);
        const birimList = parseSideList(data.birimKoduList);
        detectedUserId = String(data.kullaniciKodu || '').trim();
        detectedUserName = String(data.ad || '').trim();
        detectedOrgOid = String(orgList[0] || '').trim();
        detectedBirimKodu = String(birimList[0] || '').trim();
        const domVdName = findVdNameFromPage(detectedOrgOid, detectedBirimKodu);
        detectedVdAdi = domVdName || detectedBirimKodu || detectedOrgOid;
        _q('#u_user').value = [detectedUserName, detectedUserId && '(' + detectedUserId + ')'].filter(Boolean).join(' ');
        _q('#u_orgoid').value = detectedOrgOid;
        _q('#u_vdadi').value = detectedVdAdi;
        _log('Oturum bilgisi alındı: ' + (detectedUserName || detectedUserId) + ' / OrgOid: ' + detectedOrgOid);
    }

    async function loadSessionInfo() {
        const token = new URLSearchParams(window.location.search).get('token');
        if (!token) throw new Error('E-Tebligat token bilgisi bulunamadı.');
        const disp = window.location.origin + '/etebligat_server/dispatch';
        const rfDataInfo = [
            { rf: 'RF_ETEBLIGAT_SAYMANLIKLAR', v: '34' },
            { rf: 'RF_ETEBLIGAT_DURUM', v: '7' },
            { rf: 'RF_ETEBLIGAT_VERGI_DAIRELERI', v: '5' },
            { rf: 'RF_IHBARNAME_EK_TURU', v: '4' }
        ];
        let lastErr = null;
        for (let attempt = 1; attempt <= 20; attempt++) {
            try {
                const res = await _api(disp, 'userSessionService_getUserSessionInfo', { token, rfDataInfo });
                if (res && res.data && res.data.kullaniciKodu && res.data.orgOidList) {
                    sessionInfo = res.data;
                    applySessionInfo(sessionInfo);
                    setTimeout(() => {
                        const name = findVdNameFromPage(detectedOrgOid, detectedBirimKodu);
                        if (name) {
                            detectedVdAdi = name;
                            _q('#u_vdadi').value = name;
                        }
                    }, 1200);
                    return sessionInfo;
                }
                lastErr = new Error('Oturum cevabı henüz hazır değil.');
            } catch (e) { lastErr = e; }
            await new Promise(r => setTimeout(r, 250));
        }
        throw lastErr || new Error('E-Tebligat oturum bilgisi alınamadı.');
    }

    const sessionReady = loadSessionInfo().catch(err => {
        _q('#u_user').value = 'Oturum bilgisi alınamadı';
        _q('#u_orgoid').value = '';
        _q('#u_vdadi').value = '';
        _log('Oturum bilgisi alınamadı: ' + (err.message || err), true);
        return null;
    });

    async function runUniversal() {
        _q('#u_run').style.display = 'none';
        _q('#u_stop').style.display = 'block';
        window.u_halt = false;

        const loc = "http://localhost:2023/";
        const disp = window.location.origin + "/etebligat_server/dispatch";
        const sideDisp = window.location.origin + "/etebligat/side-dispatch";
        const token = new URLSearchParams(window.location.search).get('token');

        const p_pin = _q('#u_pin').value.trim();
        await sessionReady;
        const p_orgoid = _q('#u_orgoid').value.trim();
        const p_vdadi = _q('#u_vdadi').value.trim();
        const p_vkn = _q('#u_vkn').value.trim();
        const p_start = _q('#u_start').value.trim();
        const p_end = _q('#u_end').value.trim();
        const p_tur = _q('#u_tur').value;
        const p_parti = Math.max(1, parseInt(_q('#u_parti').value, 10) || 1);
        const listeSet = new Set((_q('#u_liste').value || '').split(/[\s,;]+/).map(x => x.trim()).filter(Boolean));
        const denenen = new Set();          /* sonsuz döngü koruması */
        let toplamHedef = 0, imzalanan = 0, hatali = 0;

        if (!p_pin) {
            _log("Lütfen E-İmza PIN kodunuzu girin!", true);
            resetButtons();
            return;
        }
        if (!detectedUserId || !p_orgoid) {
            _log("E-Tebligat kullanıcı/vergi dairesi oturumu alınamadı. Sayfayı yenileyin.", true);
            resetButtons();
            return;
        }

        try {
            await _api(loc + "?cmd=mainService_checkStatus", null, null, true);
            _log("Yerel e-imza servisi aktif.");

            const userId = detectedUserId;

            await _api(sideDisp, 'SIDE.GET_EAGER_BF_DEFS', {
                userid: String(userId),
                bfnames: ['etebligat.P_ETEBLIGAT_IMZALANACAK_IN'],
                loadedList: ['etebligat.PG_MAIN_PAGE'],
                resourceBundleLang: 'tr'
            });
            await _api(sideDisp, 'SIDE.GET_MODULE_INFO', {
                moduleName: "sila",
                excludeList: ["jquery", "jquery-ui", "underscore", "tus"],
                lang: "tr"
            });
            await _api(sideDisp, 'SIDE.GET_SERVICE_DEF_LIST', {});

            const rCards = await _api(loc, 'signerService_getSmartCardsAndCertificates', {}, true);
            const c = rCards.data?.certificates?.[0];
            if (!c) throw new Error("Bilgisayara takılı e-imza kartı bulunamadı!");

            const sel = await _api(loc, 'signerService_selectCertificate', {
                smartCardId: c.smartCardId,
                certificateId: c.certificateId,
                password: p_pin,
                askPassword: false,
                tcKimlikNo: null
            }, true);

            _q('#u_pin').value = '';                       /* PIN alanı hemen temizlenir */
            if (!(sel && sel.data === true)) {
                throw new Error("E-İmza Hatası: " + (_hata(sel) || "Sertifika seçilemedi (PIN hatalı olabilir)"));
            }
            if (listeSet.size) _log("Belge No listesi aktif: yalnızca " + listeSet.size + " belge imzalanacak (tür " + p_tur + ").");

            _log("Sertifika bağlandı. VD Adı: " + p_vdadi + " (" + p_orgoid + ")");

            let hasMoreDocs = true;
            let iteration = 1;

            while (hasMoreDocs && !window.u_halt) {
                _log("Sunucudan belge aranıyor (Tur " + iteration + ")...");

                const sRes = await _api(disp, 'etebligatService_etebligatBelgeSorgulaImzaIcin', {
                    respKeyParam: "list",
                    orgoid: p_orgoid,
                    vkn: /^\d{11}$/.test(p_vkn) ? "" : p_vkn,
                    baslangic: p_start,
                    bitis: p_end,
                    tckn: /^\d{11}$/.test(p_vkn) ? p_vkn : "",
                    belgoNo: "",
                    belgeDurumlari: ["250"],
                    zarfDurumlari: ["210"],
                    belgeTuru: p_tur,
                    imzalanmaTarihi: "",
                    pv: { start: 0, limit: "30", sorters: [] }
                });

                { const sh = _hata(sRes); if (sh) throw new Error("Belge sorgusu: " + sh); }
                if (!sRes || !sRes.data) throw new Error("GİB sunucusu veri döndürmedi.");

                let pageList = [];
                let totalCount = 0;

                if (Array.isArray(sRes.data.list)) {
                    pageList = sRes.data.list;
                    totalCount = sRes.data.totalCount || pageList.length;
                } else if (Array.isArray(sRes.data)) {
                    pageList = sRes.data;
                    totalCount = pageList.length;
                }

                pageList = pageList.filter(r => r && r.hashValue && !denenen.has(r.belgeNo) && (!listeSet.size || listeSet.has(String(r.belgeNo).trim())));
                if (!toplamHedef) toplamHedef = listeSet.size ? listeSet.size : totalCount;
                if (pageList.length === 0) {
                    _log(listeSet.size ? "Listedeki belgelerden imzalanacak (tebliğe hazır, denenmemiş) kalmadı." : "🎉 İmzalanacak belge kalmadı (sunucu toplam: " + totalCount + ").");
                    hasMoreDocs = false;
                    break;
                }

                _log("Kalan Toplam Belge: " + totalCount + " -> İlk 30'luk parti işleniyor...");

                for (let j = 0; j < pageList.length; j += p_parti) {
                    if (window.u_halt) break;

                    const chunk = pageList.slice(j, j + p_parti);
                    chunk.forEach(r => denenen.add(r.belgeNo));
                    try {
                    const oids = chunk.map(r =>
                        [r.oid, r.zarfOid, r.vergiNo || "", btoa(unescape(encodeURIComponent(r.unvan || ""))), r.belgeNo, r.tcKimlikNo || "", r.belgeTuruAciklama || (String(r.belgeTuru) === "13" ? "IHBARNAME" : ""), r.belgeTuru, r.hashValue].join("`a`")
                    );

                    const iptalRes = await _api(disp, 'etebligatService_etebligatIptalKontrolCoklu', {
                        orgOid: p_orgoid,
                        belgeTuru: p_tur,
                        belgeNoList: chunk.map(r => r.belgeNo),
                        oidList: chunk.map(r => r.oid),
                        zarfOidList: chunk.map(r => r.zarfOid)
                    });
                    { const ih = _hata(iptalRes); if (ih) throw new Error("İptal kontrolü: " + ih); }

                    const signRes = await _api(loc, 'signerService_imzala', {
                        dokumanOids: oids,
                        downloadUrl: disp + "?cmd=etebligatImzaServis_imzalanacakVerileriIndir",
                        uploadUrl: disp + "?cmd=etebligatImzaServis_imzaliVerileriYukle",
                        orgOid: p_orgoid,
                        vdAdi: p_vdadi,
                        tokenParamName: "token",
                        token: token,
                        autoDetectSmartCardType: "true",
                        progressBar: true,
                        passwordTimeout: "30",
                        loadSmartCards: false
                    }, true);

                    if (!(signRes && signRes.data === true)) {
                        throw new Error("İmza atılamadı: " + (_hata(signRes) || "beklenmeyen cevap"));
                    }

                    imzalanan += chunk.length; _sayac(imzalanan, toplamHedef);
                    _log("✅ " + (chunk.length === 1 ? chunk[0].belgeNo + " " + (chunk[0].unvan || "") : chunk.length + " adet belge") + " imzalandı.");
                    } catch (err) {
                        hatali += chunk.length;
                        _log((chunk.length === 1 ? chunk[0].belgeNo + ": " : chunk.length + " belgelik parti: ") + (err.message || err), true);
                        if (/SELECT_CERTIFICATE/i.test(String(err.message || ''))) throw new Error("Kart oturumu süresi doldu (SELECT_CERTIFICATE). PIN girip yeniden başlatın.");
                    }
                }
                if (listeSet.size && imzalanan >= listeSet.size) { _log("Listedeki belgelerin tümü imzalandı."); break; }

                iteration++;
            }

            _log((window.u_halt ? "⏹ Durduruldu. " : "🏁 Bitti. ") + imzalanan + " belge imzalandı" + (hatali ? ", " + hatali + " belge hata aldı (günlükte)." : "."));
        } catch (err) {
            _log(err.message || String(err), true);
        }

        resetButtons();
    }

    _q('#u_run').addEventListener('click', runUniversal);
    _q('#u_tur').addEventListener('change', () => { _q('#u_parti').value = _q('#u_tur').value === '13' ? '1' : '15'; });
    _q('#u_stop').addEventListener('click', () => {
        window.u_halt = true;
        _log("Durdurma isteği alındı. Aktif adım tamamlanınca işlem sonlanacak.");
    });
    _q('#u_toggle_panel').addEventListener('click', () => {
        const wrap = _q('#panel-wrap');
        wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
    });
    _q('#u_close_panel').addEventListener('click', () => {
        window.u_halt = true;
        panel.style.display = 'none';
    });

    _log("Panel yüklendi. E-Tebligat oturum bilgisi bekleniyor...");
    }

    if (document.body) initExtension();
    else document.addEventListener('DOMContentLoaded', initExtension, { once: true });
})();
