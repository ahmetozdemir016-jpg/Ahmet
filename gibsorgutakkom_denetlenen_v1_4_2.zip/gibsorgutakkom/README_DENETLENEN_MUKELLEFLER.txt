DENETİM TUTANAĞI DÜZENLENEN MÜKELLEFLER – DAVA + 3073/3074 CEZA KONTROLÜ
dosya: diger/denetlenen-mukellefler.html   (v1 – 07.10.2026)

NE YAPAR
- KEYS "Denetim Tutanağı Düzenlenen Mükellefler" ekranındaki listeyi (EYS srvcOneri_getDenetlenenMukellefListesiv2)
  aynı filtrelerle çeker: Sonuç/İşlem (Hepsi / İşlem Yapılacak / İşlem Yapılanlar), Durum, İşlem,
  VKN aralığı, TCKN aralığı, tarih aralığı. Tüm liste tek seferde gelir (KEYS'teki 26 sayfa yok).
- "Dava + 3073/3074 Kontrolü Yap": listedeki (veya sadece seçili) her mükellef için sırayla
    1) davaKayitService_davaKayitSorgula {vkn, vdkodu}          -> Dava sütunu
    2) tarhiyatService_mukTarhiyatSorgulama vergiKodu 3073      -> Usulsüzlük cezası
    3) tarhiyatService_mukTarhiyatSorgulama vergiKodu 3074      -> Özel usulsüzlük cezası
  Ceza yılı: "Tutanak yılı" = tutanağın İşlem Zamanı yılı (basAy 01 / bitAy 12); "Tüm yıllar" = dönem boş.
  Dönem parametresi reddedilirse tüm liste çekilip yıla göre sayfada süzülür.
- Sonuç: Yok (yeşil) / VAR (n) (dava kırmızı, ceza sarı). VAR'a tıklayınca kayıtların tamamı tablo olarak açılır.
  Kısa özet hücrede yazılır (dava: kayıt no / durum; ceza: toplam tutar ve dönemler – alan adları KEYS'in
  döndürdüğü isimlere göre otomatik seçilir).
- Liste filtresi: ara kutusu, sadece davası olan / sadece cezası olan / sadece kontrol edilmemiş.
- Sütun başlığına tıklayınca sıralanır. Sonuç / Ek: tutanak PDF'i (getSonuc?bkodu= / ?dKoduEk=) sayfa içinde,
  olmazsa açılır pencerede.
- Excel'e Aktar (CSV, ; ayraçlı, Excel doğrudan açar) ve Çıktı Al (yatay A4; tik, Tutanak sütunu yazdırılmaz).
- Bekleme (ms): iki istek arası bekleme (varsayılan 300). Durdur ile yarıda kesilir; yapılanlar kalır.

AÇMA
- takdire-sevk menüsünden token ile açılır: diger/denetlenen-mukellefler.html?token=...&vd=016252
  (VD her zaman 016252 varsayılır; 016253 gelirse 016252'ye çevrilir.)
- EYS oturumu (sessionData): Token Dinleyici'nin yakaladığı en yeni edenetis isteğinden alınır; yoksa daha önce
  saklanan değer; o da yoksa TC bir kez sorulur ve saklanır (takkom_eys_user).

ANA EKRANA DÜĞME (takdire-sevk1.html / takdire-sevk2.html) – go95 düğmesinin altına:
  <input id="go96" class="button2 w3-amber" type="button" value="Denetlenen Mükellefler – Dava / Ceza Kontrolü"><br>
  ve go95 click bloğunun yanına:
  $('#go96').click(function(){ var t=_tok(); if(!t){alert('Token bulunamadı.');return false;}
    window.open('diger/denetlenen-mukellefler.html?token='+encodeURIComponent(t)+'&vd=016252'); return false; });

DENETİM TUTANAĞI ONAY SAYFASINA BAĞLANTI (diger/denetim-tutanagi-onay.html) – üst düğme satırına:
  <button type="button" onclick="window.open('denetlenen-mukellefler.html'+location.search)">Denetlenen Mükellefler (dava/ceza)</button>

KODLAR (KEYS açılır listelerinden)
  durum : 0 Hiçbir Yere Gönderilmedi, 1 VD'de Beklemede, 2 VD İşlem Yaptı/Değerlendirdi, 3 VD İade Etti,
          4 VD İhbarname Hazırladı, 5 ONAYDA-İncelemeye Sevk, 6 İncelemeye Sevk Edildi, 7 ONAYDA-Mükellef İzahı,
          8 Mükellef İzahı Kabul Edildi, 9 Mahkeme Kararına Göre Terkin
  islem : 1 İşleme Gerek Duyulmadı, 2 Hıfz Edildi, 3 Denetim Tekrar Edildi, 4 Ceza Önerildi (HAR'da doğrulandı),
          5 İncelemeye Sevk Edildi, 6 Genel Durum Tespiti (HAR'da doğrulandı), 7 Yeni Kayıt

v1.1 (08.10.2026)
- "Ceza yılı" seçiminde yeni varsayılan: "Tutanaktaki ceza önerilen aylar (fiil tarihleri)". Her mükellefin Sonuç PDF'i
  (getSonuc?bkodu=, TAKKOM PDF Okuyucu uzantısıyla) okunur, BELGE İHLAL BİLGİLERİ tablosundaki tarihlerin ayları alınır;
  3073/3074 sorgusu en erken aydan en geç aya kadar (basAy/basYil–bitAy/bitYil) yapılır. İhlal tarihi bulunamazsa
  tutanak yılına düşer; sebep "Ceza Sorgu Dönemi" sütununda yazılır (ör. "yıl 2026 (ihlal tarihi yok)").
- "Paralel" kutusu (1–8): aynı anda o kadar mükellef kontrol edilir; her mükellefin kendi istekleri (dava → PDF → 3073 → 3074)
  sırayla gider. Bekleme (ms) her istek arası ve mükellef bitişinde uygulanır.
- Dava sorgusu değişmedi: davaKayitService_davaKayitSorgula {vkn, vdkodu}.
- Yeni "Ceza Sorgu Dönemi" sütunu (ekran + CSV).
- v1.2: 3073/3074 hücresindeki özete, tarhiyat kaydında gelen dava / düzeltme / tahakkuk / tebliğ alanları da yazılır
  (alan adları esnek eşleşir: dava*, duzelt*/dzt*, tahakkuk*/thk*, teblig*); tam alan listesi VAR(n) bağlantısında.

v1.3 (09.10.2026) – "Tutanağa Kesilen Ceza" için ikinci kaynak: EVDB Tarh Defteri
- Adaylar: (1) 3073/3074 tarhiyat kayıtlarındaki ihbarname fiş noları, (2) EVDB Tarh Defteri Sorgulama (geciciIhbarnameFisiListesi)
  tutanak ayından bugüne aylık, VKN=VKN (TCKN ise TCKN), dayanak Hepsi, durum Hepsi → PDF'teki her "Fiş No" kaydı.
  Tarh defteri PDF'inde ek numarası tutanak belge koduyla eşleşen ihbarnameler önce bakılır.
- Her aday için EVDB İhbarname Sorgulama PDF'i okunur; İHBARNAME EKLERİ'nde ek numarası = tutanak belge kodu (bkodu) ise
  "VAR: fiş no · durum · cezalar" yazılır. Hücrenin sonunda "tarh defteri: n ay, m ihbarname" notu.
- Tarh defteri ve ihbarname PDF'leri önbelleğe alınır (aynı VKN/ay ve aynı fiş bir kez okunur).
v1.3.1 – Ceza satırı okuma düzeltmesi: EVDB ihbarname PDF'inde CEZALAR tablosunda "Tutar" hücresi satırın biraz altına
  basılıyor; önceki sürüm satırın son sayısını alınca "Toplam" (indirim öncesi) tutarını gösteriyordu. Artık satırın
  devamındaki yalnız-sayı satırları aynı cezaya eklenir; gösterim "kod fiil Tutar (toplam …, önceden …) · toplam ceza …".
  Ceza Sorgu Dönemi hücresi artık satır kırıyor (komşu sütunların üstüne taşmıyor).
v1.3.3 – Tutanak içeriği daha çok kullanılıyor (denetim-tutanağı-onay'daki okuma mantığı):
  Sonuç PDF'inden "Bitiş Zamanı" = tutanak tarihi ve BELGE İHLAL BİLGİLERİ'ndeki belge tarihleri alınır.
  - Ceza Sorgu Dönemi hücresi "tutanak gg/aa/yyyy · aylar (kaynak)" olarak yazılır.
  - Tarh Defteri taraması tutanak tarihinin ayından başlar (yoksa işlem zamanı ayından).
  - Eşleşen ihbarnamedeki her cezanın fiil tarihi tutanaktaki belge tarihleriyle karşılaştırılır: ✓ uyumlu, ✗ tutanakta yok;
    uyuşmayan varsa "fiil tarihi tutanak belgeleriyle uyuşmuyor" notu eklenir.
v1.3.4 – "Ceza Sorgu Dönemi" sütunu kaldırıldı (bilgi CSV'de kalır), "Tutanağa Kesilen Ceza" sütunu genişletildi.
  3073/3074 özetindeki "tebliğ" yalnız tarih değeri ise gösterilir (kod değeri "11" artık yazılmaz).
  Ceza satırı okuma: CEZALAR tablosunda "Önceden Kesilen"/"Tutar" hücreleri satırın üstüne/altına basıldığında
  aynı sayfada ±10 px içindeki öğeler x sırasıyla birleştirilir; böylece Toplam/Önceden/Tutar doğru sütundan okunur.
v1.4 – Tutanağa Kesilen Ceza: eşleşen her ihbarname için PDF'ten "İhbarname Durumu" (İptal ise kırmızı İPTAL),
  "Düzeltme Fiş No" (varsa "düzeltme: …"), "Dava Dosya No" (varsa kırmızı DAVA, yoksa "dava yok"), "Tebliğ Tarihi" okunur.
  İhbarname fiş no tıklanınca EVDB İhbarname Sorgulama PDF'i, düzeltme fiş no tıklanınca Düzeltme Fişi Sorgulama PDF'i
  yeni sekmede açılır (keys.ggm.bim/evdorapor_server/pdf, EVDB rapor tokeni ile).
v1.4.1 – İhbarname / düzeltme fişi PDF'i, Sonuç/Ek gibi sayfa içi pencerede (iframe) açılır; PDF uzantıyla alınamazsa yeni pencere.
  Ceza satırı birleştirme toleransı ±6 px'e indirildi ("Toplam Ceza Tutarı" satırındaki tutar satıra karışıp
  "toplam 0,00, önceden 17.000,00" gibi yanlış değerler üretiyordu).
v1.4.2 – TCKN sütunu yerine 'Tutanak Belge Kodu' (bkodu) sütunu; liste filtresi belge koduyla da arar. TCKN CSV'de kalır.
