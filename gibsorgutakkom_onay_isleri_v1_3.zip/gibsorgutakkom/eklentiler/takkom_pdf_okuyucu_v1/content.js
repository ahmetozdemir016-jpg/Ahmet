/* file:// TAKKOM sayfası <-> uzantı köprüsü */
(function () {
  window.addEventListener('message', function (ev) {
    if (ev.source !== window) return;
    const d = ev.data || {};
    if (d.type === 'TAKKOM_PDF_PING') { window.postMessage({ type: 'TAKKOM_PDF_PONG', version: '1.3.0', md: true }, '*'); return; }
    if (d.type === 'TAKKOM_MD_REQUEST') {
      const rid2 = String(d.requestId || '');
      try {
        chrome.runtime.sendMessage({ type: 'TK_MD_FETCH', url: String(d.url || ''), body: d.body, token: String(d.token || '') }, function (resp) {
          window.postMessage(Object.assign({ type: 'TAKKOM_MD_RESPONSE', requestId: rid2 }, resp || { ok: false, error: 'uzantı cevap vermedi' }), '*');
        });
      } catch (e) { window.postMessage({ type: 'TAKKOM_MD_RESPONSE', requestId: rid2, ok: false, error: String(e) }, '*'); }
      return;
    }
    if (d.type === 'TAKKOM_PDF_REQUEST') {
      const rid = String(d.requestId || '');
      try {
        chrome.runtime.sendMessage({ type: 'TK_PDF_FETCH', url: String(d.url || '') }, function (resp) {
          window.postMessage(Object.assign({ type: 'TAKKOM_PDF_RESPONSE', requestId: rid }, resp || { ok: false, error: 'uzantı cevap vermedi' }), '*');
        });
      } catch (e) { window.postMessage({ type: 'TAKKOM_PDF_RESPONSE', requestId: rid, ok: false, error: String(e) }, '*'); }
    }
  });
})();
