GİB Sadece Token Yakalama Köprüsü v5

Bu sürüm komple ağ dinlemez. Sadece tokenleri yakalamaya çalışır:
- CSSession.getToken(g/gp/evdo/izah)
- token içeren URL/body
- yalnızca token üreten bilinen assos-login cevaplarındaki token alanı

Yakalanan tokenler chrome.storage.local içinde takkom_token_cache_v1 anahtarında saklanır.
Takkom yerel HTML sayfası token istediğinde uzantı bu cache'i döndürür.

Kurulum:
1) Eski dinleyici uzantısını kaldırın.
2) Bu klasörü Chrome > Uzantılar > Paketlenmemiş öğe yükle ile yükleyin.
3) Uzantı detayında Dosya URL'lerine erişime izin verin.
4) GİB intranet, KEYS, EVDB Rapor, İzaha/SMİYB ekranlarını aynı tarayıcıda bir kez açın.
5) Popup'ta ilgili tokenlerin var olduğunu görün, sonra TAKKOM ekranını kullanın.
