
(function(){
  if(window.__TAKKOM_TOKEN_ONLY_CONTENT__) return;
  window.__TAKKOM_TOKEN_ONLY_CONTENT__ = true;

  function canReplyToPage(){
    try{
      const href = location.href || '';
      return location.protocol === 'file:' || /gibsorgutakkom|takdire-sevk|takkom|10\.251\.63\.99/i.test(href);
    }catch(e){ return false; }
  }
  function inject(){
    try{
      if(location.protocol === 'file:') return; // yerel sayfada hook gerekmez; sadece köprü gerekir.
      if(!/10\.251\.63\.99|arkaofis\.gelbim\.gov\.tr|keys\.ggm|ggm\.gov\.tr/i.test(location.href)) return;
      const s = document.createElement('script');
      s.src = chrome.runtime.getURL('page_hook.js');
      s.onload = function(){ this.remove(); };
      (document.documentElement || document.head || document.body).appendChild(s);
    }catch(e){}
  }

  window.addEventListener('message', function(event){
    if(event.source !== window) return;
    const msg = event.data || {};
    if(msg.source === 'TAKKOM_TOKEN_ONLY_PAGE'){
      chrome.runtime.sendMessage({type:'TOKEN_ONLY_CAPTURE', payload: msg.payload || {}}, function(){});
      return;
    }
    if(msg.type === 'TAKKOM_TOKEN_REQUEST'){
      if(!canReplyToPage()) return;
      chrome.runtime.sendMessage({type:'GET_TOKENS'}, function(resp){
        try{
          window.postMessage({type:'TAKKOM_TOKEN_RESPONSE', ok:!!(resp && resp.ok), cache:(resp && resp.cache)||{}, error:(resp && resp.error)||''}, '*');
        }catch(e){}
      });
    }
  });

  inject();
})();
