YILLIK KDV DEVİR HESABI

Normal “Yıllık KDV-BS-POS” ekranı değiştirilmemiştir. Yeni hesaplama ayrı bir sayfadadır.

1. Ana ekranda “Yıllık KDV Devir Hesabı” düğmesine basın.
2. Hesabın başlayacağı yılı girin. Program başlangıç yılından itibaren en fazla 5 yılı getirir.
3. KDV beyan verileri otomatik çekilir.
4. Düzeltme bulunan aylarda yalnızca ilgili sarı alanları doldurun:
   - İlave Matrah
   - İlave matrahın yanındaki KDV Oranı
   - Reddedilen İndirim KDV
5. “Hesapla ve Devret” düğmesine basın.

Aynı ayda birden fazla ilave matrah ve oran girilebilir. “+ Matrah / Oran Ekle” düğmesi yeni satır açar. KDV oranı serbestçe değiştirilebilir. Program 2023/06 ve önceki dönemler için %18, 2023/07 ve sonraki dönemler için %20 oranını başlangıç değeri olarak getirir; eski dönemlerde %1/%8/%18, yeni dönemlerde %1/%10/%20 seçeneklerini de önerir.

“Çıktı Al” düğmesi önce mevcut girişleri hesaplar, ardından Yıllık KDV Devir Hesabı bölümünü yazdırma penceresinde açar.

Reddedilen indirim toplam indirilecek KDV’den düşülür. Düzeltilmiş devreden KDV bir sonraki aya aktarılır. Beyannamedeki iade edilmesi gereken KDV de korunur; indirim bakiyesi hem toplam KDV’yi hem iadeyi karşılamazsa eksik kalan kısım düzeltilmiş ödenecek KDV’ye ve ödenecek farkına dahil edilir.

Girilen düzeltmeler mükellef VKN’sine göre tarayıcıda saklanır. “Girdileri Temizle” yalnızca bu mükellefe ait ilave matrah ve indirim reddi girişlerini siler.

İlave matrah ve reddedilen indirim girilmemişse beyan ödenecek/devreden sonuçları aynen korunur; iki fark sütunu da 0,00 olur. Bir ayın beyan edilen önceki devri ile önceki ayın sonraki devri farklı olsa bile bu beyan farklılığı düzeltme olarak ileri taşınmaz.
