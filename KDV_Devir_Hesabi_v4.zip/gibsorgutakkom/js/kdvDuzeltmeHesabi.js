(function(global){
  'use strict';

  var MAX_MONTHS = 60;

  function numberValue(value){
    if(value === null || value === undefined || value === '') return 0;
    if(typeof value === 'number') return isFinite(value) ? value : 0;
    var text=String(value).trim(), negative=false;
    if(!text || text==='-' || /^HATA$/i.test(text) || /^NaN$/i.test(text)) return 0;
    if(/^\(.*\)$/.test(text)){ negative=true; text=text.slice(1,-1); }
    text=text.replace(/\s/g,'').replace(/[^0-9,\.\-]/g,'');
    if(text.charAt(0)==='-'){ negative=true; text=text.slice(1); }
    var comma=text.lastIndexOf(','), dot=text.lastIndexOf('.');
    if(comma>=0 && dot>=0) text=comma>dot ? text.replace(/\./g,'').replace(',','.') : text.replace(/,/g,'');
    else if(comma>=0){ var cp=text.split(','); text=cp.length===2 && cp[1].length<=2 ? text.replace(',','.') : text.replace(/,/g,''); }
    else if(dot>=0){ var dp=text.split('.'); if(dp.length>2 || (dp.length===2 && dp[1].length===3)) text=text.replace(/\./g,''); }
    var parsed=parseFloat(text); if(!isFinite(parsed)) return 0;
    return negative ? -parsed : parsed;
  }
  function nonNegative(value){ return Math.max(0,numberValue(value)); }
  function roundMoney(value){ return Math.round((numberValue(value)+1e-9)*100)/100; }
  function money(value){ return roundMoney(value).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
  function esc(value){ return String(value==null?'':value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function inputValue(value){ return numberValue(value) ? String(numberValue(value)).replace('.',',') : ''; }
  function differenceClass(value){ return numberValue(value)>0?'kdvh-increase':(numberValue(value)<0?'kdvh-decrease':''); }
  function defaultRateForPeriod(period){ return String(period||'')<'2023-07' ? 18 : 20; }
  function rateListForPeriod(period){ return String(period||'')<'2023-07' ? 'kdvhRatesOld' : 'kdvhRatesNew'; }
  function adjustmentItems(adjustment,period,includeEmpty){
    adjustment=adjustment||{}; var items=[], raw=adjustment.items;
    if(Array.isArray(raw)){
      for(var i=0;i<raw.length;i++) items.push({base:roundMoney(nonNegative(raw[i]&&raw[i].base)),rate:nonNegative(raw[i]&&raw[i].rate)});
    }else if(adjustment.base!==undefined || adjustment.rate!==undefined){
      items.push({base:roundMoney(nonNegative(adjustment.base)),rate:nonNegative(adjustment.rate)||defaultRateForPeriod(period)});
    }else{
      if(nonNegative(adjustment.base1)) items.push({base:roundMoney(nonNegative(adjustment.base1)),rate:1});
      if(nonNegative(adjustment.base10)) items.push({base:roundMoney(nonNegative(adjustment.base10)),rate:10});
      if(nonNegative(adjustment.base20)) items.push({base:roundMoney(nonNegative(adjustment.base20)),rate:20});
    }
    if(includeEmpty && !items.length) items.push({base:0,rate:defaultRateForPeriod(period)});
    return items;
  }

  function calculate(sourceRows,adjustments){
    var rows=(sourceRows||[]).slice(0,MAX_MONTHS), output=[], previousCarryDifference=0;
    for(var i=0;i<rows.length;i++){
      var source=rows[i]||{}, adjustment=(adjustments&&adjustments[source.period])||{};
      var items=adjustmentItems(adjustment,source.period,false), additionalBase=0, additionalVat=0;
      for(var j=0;j<items.length;j++){
        additionalBase=roundMoney(additionalBase+items[j].base);
        additionalVat=roundMoney(additionalVat+items[j].base*items[j].rate/100);
      }
      var rejectedInputVat=roundMoney(nonNegative(adjustment.rejectedInputVat));
      // Beyan zincirinde düzeltme beyannamesi, yuvarlama veya başka bir nedenle bir ayın
      // sonraki devri ile takip eden ayın önceki devri farklı olabilir. Bu nedenle normal
      // beyanı yeniden kurmuyoruz; yalnızca yapılan düzeltmenin farkını beyan tutarlarına taşırız.
      var declaredPreviousCarry=roundMoney(source.declaredPreviousCarry);
      var adjustedPreviousCarry=roundMoney(Math.max(0,declaredPreviousCarry+previousCarryDifference));
      var appliedPreviousDifference=roundMoney(adjustedPreviousCarry-declaredPreviousCarry);
      var adjustedTotalDeductible=roundMoney(Math.max(0,roundMoney(source.declaredTotalDeductible)+appliedPreviousDifference-rejectedInputVat));
      var adjustedMatrah=roundMoney(source.declaredMatrah+additionalBase);
      var adjustedCalculatedVat=roundMoney(source.declaredCalculatedVat+additionalVat);
      var adjustedTotalVat=roundMoney(source.declaredTotalVat+additionalVat);
      var refundVat=roundMoney(nonNegative(source.declaredRefundVat));
      var adjustmentBurden=roundMoney(additionalVat+rejectedInputVat-appliedPreviousDifference);

      // Beyan devri, iade KDV düşüldükten sonraki sonuçtur. Önce iade öncesi bakiye
      // yeniden kurulur. Düzeltme bu bakiyeyi azaltır; karşılanamayan iade ve bakiyeyi
      // aşan düzeltme ayrı ayrı ödenecek farkına eklenir.
      var declaredBalanceBeforeRefund=roundMoney(numberValue(source.declaredNextCarry)+refundVat);
      var adjustedBalanceBeforeRefund=roundMoney(Math.max(0,declaredBalanceBeforeRefund-adjustmentBurden));
      var adjustedCarry=roundMoney(Math.max(0,adjustedBalanceBeforeRefund-refundVat));
      var uncoveredRefund=roundMoney(Math.max(0,refundVat-adjustedBalanceBeforeRefund));
      var burdenBeyondBalance=roundMoney(Math.max(0,adjustmentBurden-declaredBalanceBeforeRefund));
      var payableDifference=roundMoney(uncoveredRefund+burdenBeyondBalance);
      var adjustedPayable=roundMoney(numberValue(source.declaredPayableVat)+payableDifference);
      var carryDifference=roundMoney(adjustedCarry-roundMoney(source.declaredNextCarry));
      if(additionalVat===0 && rejectedInputVat===0 && appliedPreviousDifference===0){
        adjustedCarry=roundMoney(source.declaredNextCarry);
        adjustedPayable=roundMoney(source.declaredPayableVat);
        payableDifference=0;
        carryDifference=0;
      }
      output.push({period:source.period,declaredMatrah:roundMoney(source.declaredMatrah),additionalItems:items,additionalBase:additionalBase,additionalVat:additionalVat,adjustedMatrah:adjustedMatrah,rejectedInputVat:rejectedInputVat,adjustedCalculatedVat:adjustedCalculatedVat,adjustedPreviousCarry:adjustedPreviousCarry,adjustedTotalDeductible:adjustedTotalDeductible,adjustedTotalVat:adjustedTotalVat,refundVat:refundVat,declaredPayableVat:roundMoney(source.declaredPayableVat),adjustedPayable:adjustedPayable,payableDifference:payableDifference,declaredNextCarry:roundMoney(source.declaredNextCarry),adjustedCarry:adjustedCarry,carryDifference:carryDifference});
      previousCarryDifference=carryDifference;
    }
    return output;
  }

  function storageKey(vkn){ return 'takkom_kdv_devir_hesabi_v2_'+String(vkn||'').replace(/\D/g,''); }
  function loadAdjustments(vkn){ try{ var d=JSON.parse(localStorage.getItem(storageKey(vkn))||'{}'); return d&&d.adjustments?d.adjustments:{}; }catch(e){ return {}; } }
  function saveAdjustments(vkn,adjustments){ try{ localStorage.setItem(storageKey(vkn),JSON.stringify({version:2,vkn:String(vkn||'').replace(/\D/g,''),updatedAt:(new Date()).toISOString(),adjustments:adjustments})); }catch(e){} }
  function readAdjustments(panel){
    var data={};
    Array.prototype.forEach.call(panel.querySelectorAll('tr[data-kdvh-period]'),function(row){
      var items=[];
      Array.prototype.forEach.call(row.querySelectorAll('.kdvh-entry'),function(entry){
        var base=roundMoney(nonNegative(entry.querySelector('[data-kdvh-field="base"]').value));
        var rate=nonNegative(entry.querySelector('[data-kdvh-field="rate"]').value);
        if(base) items.push({base:base,rate:rate});
      });
      var rejected=row.querySelector('[data-kdvh-field="rejectedInputVat"]');
      data[row.getAttribute('data-kdvh-period')]={items:items,rejectedInputVat:roundMoney(nonNegative(rejected&&rejected.value))};
    });
    return data;
  }

  function entryHtml(period,item){
    item=item||{};
    return '<div class="kdvh-entry"><input class="kdvh-base" data-kdvh-field="base" inputmode="decimal" value="'+esc(inputValue(item.base))+'" placeholder="Matrah"><span class="kdvh-rate-sep">×</span><input class="kdvh-rate" data-kdvh-field="rate" inputmode="decimal" list="'+rateListForPeriod(period)+'" value="'+esc(inputValue(item.rate||defaultRateForPeriod(period)))+'" placeholder="Oran"><span>%</span><button type="button" class="kdvh-entry-remove" title="Satırı kaldır">−</button></div>';
  }

  function renderRows(panel,sourceRows,adjustments){
    var result=calculate(sourceRows,adjustments), body=panel.querySelector('#kdvhBody'), html='';
    var totals={base:0,vat:0,rejected:0,refund:0,payableDifference:0,rates:{}};
    for(var i=0;i<result.length;i++){
      var row=result[i], input=adjustments[row.period]||{};
      var entries=adjustmentItems(input,row.period,true), entriesHtml='';
      for(var e=0;e<entries.length;e++) entriesHtml+=entryHtml(row.period,entries[e]);
      for(var t=0;t<row.additionalItems.length;t++){
        var rateKey=String(row.additionalItems[t].rate).replace('.',',');
        totals.rates[rateKey]=roundMoney((totals.rates[rateKey]||0)+row.additionalItems[t].base);
      }
      totals.base+=row.additionalBase; totals.vat+=row.additionalVat; totals.rejected+=row.rejectedInputVat; totals.refund+=row.refundVat; totals.payableDifference+=row.payableDifference;
      html+='<tr data-kdvh-period="'+esc(row.period)+'"><td class="kdvh-period">'+esc(row.period)+'</td><td class="kdvh-money">'+money(row.declaredMatrah)+'</td>'+
        '<td class="kdvh-entry-cell">'+entriesHtml+'<button type="button" class="kdvh-entry-add" data-kdvh-add="1">+ Matrah / Oran Ekle</button></td>'+
        '<td class="kdvh-money">'+money(row.additionalVat)+'</td><td class="kdvh-money">'+money(row.adjustedCalculatedVat)+'</td><td class="kdvh-money">'+money(row.adjustedMatrah)+'</td>'+
        '<td><input data-kdvh-field="rejectedInputVat" inputmode="decimal" value="'+esc(inputValue(input.rejectedInputVat))+'" placeholder="0,00"></td>'+
        '<td class="kdvh-money">'+money(row.adjustedPreviousCarry)+'</td><td class="kdvh-money">'+money(row.adjustedTotalDeductible)+'</td><td class="kdvh-money">'+money(row.adjustedTotalVat)+'</td>'+
        '<td class="kdvh-money">'+money(row.refundVat)+'</td><td class="kdvh-money">'+money(row.declaredPayableVat)+'</td><td class="kdvh-money">'+money(row.adjustedPayable)+'</td>'+
        '<td class="kdvh-money '+differenceClass(row.payableDifference)+'">'+money(row.payableDifference)+'</td><td class="kdvh-money">'+money(row.declaredNextCarry)+'</td><td class="kdvh-money">'+money(row.adjustedCarry)+'</td><td class="kdvh-money '+differenceClass(row.carryDifference)+'">'+money(row.carryDifference)+'</td></tr>';
    }
    body.innerHTML=html;
    var rateSummary=[], rateKeys=Object.keys(totals.rates).sort(function(a,b){ return numberValue(a)-numberValue(b); });
    for(var k=0;k<rateKeys.length;k++) rateSummary.push('%'+rateKeys[k]+' matrah: <b>'+money(totals.rates[rateKeys[k]])+'</b>');
    panel.querySelector('#kdvhSummary').innerHTML='<b>'+result.length+' dönem hesaplandı.</b> İlave matrah: <b>'+money(totals.base)+'</b>'+(rateSummary.length?' ('+rateSummary.join(' | ')+')':'')+' | İlave hesaplanan KDV: <b>'+money(totals.vat)+'</b> | Reddedilen indirim: <b>'+money(totals.rejected)+'</b> | İade KDV: <b>'+money(totals.refund)+'</b> | Ödenecek farkı: <b>'+money(totals.payableDifference)+'</b>';
    return result;
  }

  function ensureStyle(){
    if(document.getElementById('kdvhStyle')) return;
    var style=document.createElement('style'); style.id='kdvhStyle';
    style.textContent='#kdvhPanel{margin:16px 0;padding:12px;border:2px solid #1769aa;background:#eef7ff}#kdvhPanel h2{margin:0 0 6px;color:#0d4775}.kdvh-note{font-size:12px;margin-bottom:8px}.kdvh-actions{margin:8px 0}#kdvhPanel button{border:0;padding:8px 13px;margin-right:6px;cursor:pointer;color:#fff;background:#1769aa}#kdvhPanel button.kdvh-clear{background:#6c757d}#kdvhPanel button.kdvh-print{background:#28783e}#kdvhWrap{overflow:auto;max-height:72vh;border:1px solid #99b8d0;background:#fff}#kdvhTable{border-collapse:collapse;min-width:2080px;margin:0;padding:0}#kdvhTable th{position:sticky;top:0;z-index:2;background:#1769aa;color:#fff;font-size:11px}#kdvhTable td{font-size:11px;white-space:nowrap}#kdvhTable input{width:92px;padding:4px;border:1px solid #d59d00;background:#fff5bf;text-align:right}.kdvh-entry{display:flex;align-items:center;gap:3px;margin:2px 0}.kdvh-entry .kdvh-base{width:88px}.kdvh-entry .kdvh-rate{width:45px}.kdvh-entry-remove{padding:2px 6px!important;margin:0!important;background:#a94442!important}.kdvh-entry-add{padding:3px 7px!important;margin-top:3px!important;font-size:10px}.kdvh-money{text-align:right}.kdvh-period{font-weight:bold}.kdvh-increase{background:#ffd9d9;color:#a00000;font-weight:bold}.kdvh-decrease{background:#e4f7e8;color:#176b2c;font-weight:bold}#kdvhSummary{margin-top:8px;padding:7px;background:#fff;border:1px solid #99b8d0;font-size:12px}@media print{body.kdvh-print-mode>h1,body.kdvh-print-mode>.note,body.kdvh-print-mode>#reload,body.kdvh-print-mode>#status,body.kdvh-print-mode>.source-wrap{display:none!important}#kdvhPanel .kdvh-actions,#kdvhPanel .kdvh-entry-add,#kdvhPanel .kdvh-entry-remove{display:none!important}#kdvhPanel{border:0;margin:0;padding:0;background:#fff}#kdvhWrap{max-height:none;overflow:visible;border:0}#kdvhTable{min-width:0;width:100%}#kdvhTable th{position:static}#kdvhTable input{border:0;background:transparent;padding:0;width:65px}.kdvh-entry .kdvh-rate{width:28px}}';
    document.head.appendChild(style);
  }

  function init(options){
    options=options||{}; var sourceRows=(options.sourceRows||[]).slice(0,MAX_MONTHS); if(!sourceRows.length) return;
    ensureStyle(); var vkn=String(options.vkn||'').replace(/\D/g,''), old=document.getElementById('kdvhPanel'); if(old&&old.parentNode) old.parentNode.removeChild(old);
    var panel=document.createElement('div'); panel.id='kdvhPanel';
    panel.innerHTML='<h2>Yıllık KDV Devir Hesabı</h2><div class="kdvh-note">KDV beyan verileri otomatik alınmıştır. İlave matrahı ve yanındaki KDV oranını sarı alanlara girin; oran elle değiştirilebilir. Aynı aya başka oran eklemek için “+ Matrah / Oran Ekle”yi kullanın. 2023/06 ve öncesinde %18, 2023/07 ve sonrasında %20 otomatik önerilir. İade edilmesi gereken KDV ödenecek farkı hesabına dahildir. En fazla 5 yıl (60 dönem) hesaplanır.</div><div class="kdvh-actions"><button type="button" id="kdvhCalculate">Hesapla ve Devret</button><button type="button" class="kdvh-clear" id="kdvhClear">Girdileri Temizle</button><button type="button" class="kdvh-print" id="kdvhPrint">Çıktı Al</button></div><datalist id="kdvhRatesOld"><option value="1"><option value="8"><option value="18"></datalist><datalist id="kdvhRatesNew"><option value="1"><option value="10"><option value="20"></datalist><div id="kdvhWrap"><table id="kdvhTable"><thead><tr><th>Dönem</th><th>Beyan Matrahı</th><th>İlave Matrah × KDV Oranı %</th><th>İlave Hesaplanan KDV</th><th>Düzeltilmiş Hesaplanan KDV</th><th>Düzeltilmiş Matrah</th><th>Reddedilen İndirim KDV</th><th>Düzeltilmiş Önceki Devir</th><th>Düzeltilmiş Toplam İndirim</th><th>Düzeltilmiş Toplam KDV</th><th>İade Edilmesi Gereken KDV</th><th>Beyan Ödenecek</th><th>Düzeltilmiş Ödenecek</th><th>Ödenecek Farkı</th><th>Beyan Devreden</th><th>Düzeltilmiş Devreden</th><th>Devreden Farkı</th></tr></thead><tbody id="kdvhBody"></tbody></table></div><div id="kdvhSummary"></div>';
    var anchor=options.anchor||document.body; anchor.appendChild(panel);
    var adjustments=loadAdjustments(vkn); renderRows(panel,sourceRows,adjustments);
    panel.querySelector('#kdvhCalculate').onclick=function(){ adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments); renderRows(panel,sourceRows,adjustments); };
    panel.querySelector('#kdvhClear').onclick=function(){ if(!global.confirm('Bu mükellef için girilen ilave matrah ve indirim reddi tutarları temizlensin mi?')) return; adjustments={}; saveAdjustments(vkn,adjustments); renderRows(panel,sourceRows,adjustments); };
    panel.onclick=function(event){
      var add=event.target.closest&&event.target.closest('[data-kdvh-add]');
      if(add){ var row=add.closest('tr[data-kdvh-period]'); add.insertAdjacentHTML('beforebegin',entryHtml(row.getAttribute('data-kdvh-period'),{})); return; }
      var remove=event.target.closest&&event.target.closest('.kdvh-entry-remove');
      if(remove){ var entry=remove.closest('.kdvh-entry'), cell=entry.parentNode; if(cell.querySelectorAll('.kdvh-entry').length>1) entry.parentNode.removeChild(entry); else{ entry.querySelector('[data-kdvh-field="base"]').value=''; } }
    };
    panel.querySelector('#kdvhPrint').onclick=function(){ adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments); renderRows(panel,sourceRows,adjustments); document.body.classList.add('kdvh-print-mode'); global.print(); setTimeout(function(){ document.body.classList.remove('kdvh-print-mode'); },500); };
  }

  global.KdvDuzeltmeHesabi={version:'3.0.0',maxMonths:MAX_MONTHS,calculate:calculate,init:init,numberValue:numberValue,roundMoney:roundMoney,defaultRateForPeriod:defaultRateForPeriod};
})(window);
