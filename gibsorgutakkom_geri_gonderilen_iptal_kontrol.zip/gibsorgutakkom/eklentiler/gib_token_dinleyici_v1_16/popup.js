
const KEY='takkom_token_cache_v1';
function short(v){ v=String(v||''); return v ? (v.slice(0,8)+'...'+v.slice(-6)) : ''; }
function age(t){ if(!t)return '-'; const s=Math.round((Date.now()-t)/1000); if(s<60)return s+' sn'; if(s<3600)return Math.round(s/60)+' dk'; return Math.round(s/3600)+' sa'; }
function render(cache){
  cache=cache||{}; const toks=cache.tokens||{};
  const rows=[['gibintranet','GİB intranet'],['keys','KEYS/GP'],['evdbrapor','EVDB Rapor'],['istakip','İş Takip'],['eys','EYS'],['izah','İzaha/SMİYB']];
  let h='<table><tr><th>Token</th><th>Durum</th><th>Yaş</th></tr>';
  rows.forEach(r=>{ const x=toks[r[0]] || cache[r[0]] || {}; h+='<tr><td>'+r[1]+'</td><td>'+(x.token?'<span class="ok">var</span> '+short(x.token):'<span class="no">yok</span>')+'</td><td>'+age(x.time)+'</td></tr>'; });
  h+='</table><div class="small">Son güncelleme: '+(cache.updatedAt?new Date(cache.updatedAt).toLocaleString():'-')+'</div>';
  document.getElementById('status').innerHTML=h;
}
function load(){ chrome.storage.local.get(KEY, o=>render(o[KEY]||{})); }
document.getElementById('refresh').onclick=load;
document.getElementById('clear').onclick=()=>chrome.runtime.sendMessage({type:'CLEAR_TOKENS'}, load);
load();
