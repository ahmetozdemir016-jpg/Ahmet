/* file:// TAKKOM sayfası <-> uzantı köprüsü */
(function () {
  window.addEventListener('message', function (ev) {
    if (ev.source !== window) return;
    const d = ev.data || {};
    if (d.type === 'TAKKOM_PDF_PING') { window.postMessage({ type: 'TAKKOM_PDF_PONG', version: '1.3.1', md: true }, '*'); return; }
    if (d.type === 'TAKKOM_MD_REQUEST') {
      const rid2 = String(d.requestId || '');
      try {
        chrome.runtime.sendMessage({ type: 'TK_MD_FETCH', url: String(d.url || ''), body: d.body, token: String(d.token || '') }, function (resp) {
          var le = chrome.runtime.lastError;
          if (!resp) resp = { ok: false, error: (le && /port closed/i.test(le.message)) ? 'TAKKOM PDF Okuyucu arka planı eski sürümde çalışıyor — chrome://extensions sayfasında uzantıyı Yenile (⟳) ve sayfayı yeniden açın' : ('uzantı cevap vermedi' + (le ? ': ' + le.message : '')) };
          window.postMessage(Object.assign({ type: 'TAKKOM_MD_RESPONSE', requestId: rid2 }, resp), '*');
        });
      } catch (e) { window.postMessage({ type: 'TAKKOM_MD_RESPONSE', requestId: rid2, ok: false, error: String(e) }, '*'); }
      return;
    }
    if (d.type === 'TAKKOM_PDF_REQUEST') {
      const rid = String(d.requestId || '');
      try {
        chrome.runtime.sendMessage({ type: 'TK_PDF_FETCH', url: String(d.url || '') }, function (resp) {
          var le = chrome.runtime.lastError;
          if (!resp) resp = { ok: false, error: 'uzantı cevap vermedi' + (le ? ': ' + le.message : '') };
          window.postMessage(Object.assign({ type: 'TAKKOM_PDF_RESPONSE', requestId: rid }, resp), '*');
        });
      } catch (e) { window.postMessage({ type: 'TAKKOM_PDF_RESPONSE', requestId: rid, ok: false, error: String(e) }, '*'); }
    }
  });
})();
