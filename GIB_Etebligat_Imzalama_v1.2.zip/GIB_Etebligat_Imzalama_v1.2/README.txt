GİB E-Tebligat İmzalama v1.1

Kurulum:
1. ZIP dosyasını bir klasöre çıkarın.
2. Chrome adres çubuğuna chrome://extensions yazın.
3. Geliştirici modu'nu açın.
4. Paketlenmemiş öğe yükle seçeneğine basın.
5. Bu klasörü seçin.
6. E-Tebligat ekranını açın/yenileyin.

v1.1 değişiklikleri:
- Eklenti E-Tebligat sayfası açılırken yüklenir.
- Sabit kullanıcı kodu kaldırıldı.
- Sabit vergi dairesi / orgOid kaldırıldı.
- userSessionService_getUserSessionInfo açılış sorgusundan kullanıcı adı,
  kullanıcı kodu, orgOidList ve birimKoduList otomatik alınır.
- Panelde Kullanıcı, VD/Org OID ve VD Adı/Birim alanları otomatik gösterilir.
- VD adı sayfada bulunabiliyorsa ekrandan yakalanır; aksi halde oturumdaki
  birim kodu kullanılır.
- Başlat'a oturum bilgisi gelmeden basılırsa oturum sorgusunun tamamlanması beklenir.

v1.2: Panel yalnızca https://keys.ggm.bim/etebligat/index.jsp adresinde otomatik açılır. Diğer GİB sayfalarında otomatik çalışmaz.
