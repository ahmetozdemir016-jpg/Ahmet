v4.31.7 Panel Düzeltme

Düzeltilen sorun:
- v4.31.6'da Ana Modül sekmesi açıkken panel içeriğinin büyük kısmı görünmüyor/boş kalıyordu.

Sebep:
- Sekmeli yapıda ana modül elemanları yanlış zamanda başka kapsayıcıya taşınıyordu.

Düzeltme:
- Ana modül elemanları artık taşınmıyor.
- Sekme çubuğu yalnızca panelin en üstüne ekleniyor.
- EYS seçilince ana modül elemanları gizleniyor.
- Ana Modül seçilince ana modül elemanları tekrar görünüyor.
- EYS paneli yalnızca EYS sekmesi içindeki alana taşınıyor.

Korunanlar:
- v4.31.6'daki tek tek gönderim mantığı
- iade kayıtlarını atlama
- Günlük PDF / Filtreli İşlem VKN filtreleri
- Bugün butonu
- CFG düzeltmesi
