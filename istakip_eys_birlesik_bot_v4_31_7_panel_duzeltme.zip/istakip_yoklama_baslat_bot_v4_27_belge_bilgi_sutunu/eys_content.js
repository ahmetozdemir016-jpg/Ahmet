(() => {
  'use strict';

  function fmtDateYYYYMMDD(d) {
    d = d || new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}${m}${day}`;
  }


  function eysTodayYYYYMMDD() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}${m}${day}`;
  }


  function eysOpenPdfPopup(url) {
    if (!url) return;
    try {
      const w = Math.min(980, Math.max(720, Math.floor(window.screen.availWidth * 0.62)));
      const h = Math.min(900, Math.max(620, Math.floor(window.screen.availHeight * 0.88)));
      const left = Math.max(0, Math.floor((window.screen.availLeft || 0) + window.screen.availWidth - w - 20));
      const top = Math.max(0, Math.floor((window.screen.availTop || 0) + 40));
      const features = [
        'popup=yes',
        'noopener=no',
        'noreferrer=no',
        'resizable=yes',
        'scrollbars=yes',
        'toolbar=no',
        'menubar=no',
        'location=yes',
        'status=no',
        `width=${w}`,
        `height=${h}`,
        `left=${left}`,
        `top=${top}`
      ].join(',');
      const win = window.open(url, 'EYS_PDF_POPUP', features);
      if (win) {
        try { win.focus(); } catch (_) {}
      } else {
        window.open(url, '_blank');
      }
    } catch (_) {
      window.open(url, '_blank');
    }
  }


  function eysLocalGet(key) {
    try {
      const raw = localStorage.getItem('eys_storage_' + key);
      return raw ? JSON.parse(raw) : null;
    } catch (_) { return null; }
  }

  function eysLocalSet(key, value) {
    try { localStorage.setItem('eys_storage_' + key, JSON.stringify(value)); } catch (_) {}
  }

  function eysLocalRemove(key) {
    try { localStorage.removeItem('eys_storage_' + key); } catch (_) {}
  }

  async function eysStorageGet(key) {
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return eysLocalGet(key);
      const data = await chrome.storage.local.get(key);
      return data ? data[key] : eysLocalGet(key);
    } catch (_) {
      return eysLocalGet(key);
    }
  }

  async function eysStorageSet(key, value) {
    eysLocalSet(key, value);
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return;
      await chrome.storage.local.set({ [key]: value });
    } catch (_) {}
  }

  async function eysStorageRemove(key) {
    eysLocalRemove(key);
    try {
      if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) return;
      await chrome.storage.local.remove(key);
    } catch (_) {}
  }


  if (window.__eysTabbedBotLoaded) return;
  window.__eysTabbedBotLoaded = true;

  function isPdfResultPage() {
    try {
      const u = new URL(window.location.href);
      return /\/edenetis\/getSonuc/i.test(u.pathname) && !!u.searchParams.get('yKodu');
    } catch (_) {
      return false;
    }
  }

  function showPdfPrintOverlay(msg) {
    try {
      const id = 'eys-pdf-print-overlay';
      let box = document.getElementById(id);
      if (!box) {
        box = document.createElement('div');
        box.id = id;
        box.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483647;background:#111827;color:#fff;padding:10px 12px;border:1px solid #334155;border-radius:8px;font:12px/1.4 sans-serif;box-shadow:0 10px 25px rgba(0,0,0,.35)';
        document.documentElement.appendChild(box);
      }
      box.textContent = msg;
    } catch (_) {}
  }

  function setupPdfAutoPrintPage() {
    if (!isPdfResultPage()) return false;
    try {
      const u = new URL(window.location.href);
      const auto = u.searchParams.get('eys_autoprint') === '1';
      if (!auto) return true;
      const delay = Math.max(800, Number(u.searchParams.get('eys_delay') || '1800') || 1800);
      const ykodu = u.searchParams.get('yKodu') || '';
      const closeAfter = u.searchParams.get('eys_close') === '1';
      showPdfPrintOverlay(`EYS yazdırma hazırlanıyor... ${ykodu}`);
      setTimeout(() => {
        try { window.focus(); } catch (_) {}
        showPdfPrintOverlay('Yazdırma komutu gönderiliyor... Sayfa aralığı: 1-2 seçilmeli.');
        try { window.print(); } catch (_) {}
        if (closeAfter) {
          setTimeout(() => { try { window.close(); } catch (_) {} }, 1500);
        }
      }, delay);
    } catch (_) {}
    return true;
  }

  if (setupPdfAutoPrintPage()) return;

  const CFG = {
    PANEL_ID: 'eys-tabbed-bot-panel',
    STYLE_ID: 'eys-tabbed-bot-style',
    STORAGE_KEY: 'eys_pending_action',
    FIXED_SIDE_URL: 'http://10.251.63.99:30870/side/side-dispatch',
    EYS_URL: 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch',
    RESCAN_MS: 5 * 60 * 1000,
    AFTER_MEMUR_SEND_WAIT_MS: 2500,
    SEQUENTIAL_SEND_WAIT_MS: 450,
    SERVICES: [
      ['10', '1. Sürekli yükümlülükler'],
      ['20', '2. Sürekli yükümlülükler'],
      ['30', '3. Sürekli yükümlülükler'],
      ['40', '4. Sürekli yükümlülükler'],
      ['50', 'Tarama kontrol bölümü'],
      ['60', 'Sicil yoklama'],
      ['70', 'KDV iade servisi'],
      ['91', 'İnteraktif VD'],
      ['92', 'Ticaret sicil servisi'],
      ['93', 'GİB robot']
    ],
    COMMANDS: {
      SIDE_GET_MODULE_INFO: 'SIDE.GET_MODULE_INFO',
      SIDE_GET_EAGER_BF_DEFS: 'SIDE.GET_EAGER_BF_DEFS',
      SIDE_GET_SERVICE_DEF_LIST: 'SIDE.GET_SERVICE_DEF_LIST',
      CREATE_SESSION: 'eosKullaniciServices_createSession',
      GET_VD_ADI: 'srvcRefData_getVDAdi',
      CHECK_USER: 'srvcEysUser_isFatihTopkapiOrHatayIskenderun',
      MEMUR_LIST: 'srvcDashboard_getMemurIslemlerYTum',
      MEMUR_SEND: 'srvcYoklama_submitYoklamalarToMudur',
      MUDUR_LIST: 'srvcDashboard_getMudurIslemlerYOnayBekleyen',
      IADE_LIST: 'srvcYoklama_getIadeler',
      MUDUR_SEND: 'srvcYoklama_submitYoklamalarToKoor',
      GET_YOKLAMALAR: 'srvcYoklama_getYoklamalar',
      ARCHIVE_YOKLAMA: 'srvcArchive_archiveYoklama',
      ISLEM_YAPILDI: 'srvcYoklama_islemYapildiYoklamaSonuc'
    }
  };

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function visible(el) {
    return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  }

  function textOf(el) {
    return ((el?.innerText || el?.textContent || el?.value || el?.title || el?.alt || '') + '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function safeCall(obj, fn) {
    try { return obj && typeof obj[fn] === 'function' ? obj[fn]() : undefined; }
    catch (_) { return undefined; }
  }

  function getToken() {
    return new URLSearchParams(window.location.search).get('token') || '';
  }

  function formatDateYYYYMMDD(d = new Date()) {
    return d.toISOString().slice(0, 10).replaceAll('-', '');
  }

  function getSessionSeed() {
    const c = window.CSSession || {};
    const birim = String(
      safeCall(c, 'getVdKodu') || c.vdKodu || c.vdkodu || c.birim || '016253'
    ).trim();

    const user = String(
      safeCall(c, 'getUserId') || c.userId || window.userId || '35353114746'
    ).trim();

    const adi = String(
      safeCall(c, 'getUserName') || c.adi || window.userName || ''
    ).trim();

    return {
      user,
      giris: user,
      birim,
      il: birim.slice(0, 3),
      adi,
      userx: user
    };
  }

  function buildSessionData(role) {
    const seed = getSessionSeed();
    return {
      rol: String(role),
      user: seed.user,
      giris: seed.giris,
      birim: seed.birim,
      il: seed.il,
      adi: seed.adi,
      userx: seed.userx
    };
  }

  async function post(url, cmd, jp) {
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', String(Date.now()));
    const token = getToken();
    if (token) p.append('token', token);
    p.append('jp', JSON.stringify(jp || {}));

    const res = await fetch(url, {
      method: 'POST',
      body: p,
      credentials: 'include'
    });

    if (!res.ok) throw new Error(`Ağ hatası: ${res.status} (${cmd}) @ ${url}`);

    const text = await res.text();
    try { return JSON.parse(text); } catch (_) { return text; }
  }

  async function tryPost(url, cmd, jp) {
    try { return await post(url, cmd, jp); }
    catch (e) { return { __error: e.message || String(e) }; }
  }

  function buildSideCandidates() {
    const origin = window.location.origin;
    const path = window.location.pathname || '';
    const firstSeg = path.split('/').filter(Boolean)[0] || '';
    const candidates = [
      CFG.FIXED_SIDE_URL,
      origin + '/side/side-dispatch',
      origin + '/side-dispatch'
    ];
    if (firstSeg) {
      candidates.push(origin + '/' + firstSeg + '/side-dispatch');
      candidates.push(origin + '/' + firstSeg + '/side/side-dispatch');
    }
    return Array.from(new Set(candidates));
  }

  function looksLikeYkodu(value) {
    return typeof value === 'string' && /^\d{8}Y\d{6}[A-Z0-9]+$/i.test(value);
  }

  function collectObjects(root, out = []) {
    if (Array.isArray(root)) {
      for (const item of root) collectObjects(item, out);
      return out;
    }
    if (root && typeof root === 'object') {
      out.push(root);
      for (const value of Object.values(root)) collectObjects(value, out);
    }
    return out;
  }

  function extractYkodlariStrict(resp) {
    const found = new Set();
    const objects = collectObjects(resp);
    for (const obj of objects) {
      if (!obj || typeof obj !== 'object') continue;
      const direct = obj.ykodu || obj.yKod || obj.ykod || obj.yoklamaKodu || obj.yoklamakodu;
      if (looksLikeYkodu(direct)) found.add(direct);
      if (Array.isArray(obj.ykodlari)) {
        for (const value of obj.ykodlari) if (looksLikeYkodu(value)) found.add(value);
      }
    }
    return Array.from(found);
  }

  function extractYoklamaRows(resp) {
    const rows = [];
    const objects = collectObjects(resp);
    const seen = new Set();
    for (const obj of objects) {
      const ykodu = obj?.ykodu || obj?.yKod || obj?.ykod;
      if (!looksLikeYkodu(ykodu) || seen.has(ykodu)) continue;
      seen.add(ykodu);
      rows.push({
        ykodu,
        durum: obj?.durum || '',
        servis: String(obj?.servis || ''),
        archived: String(obj?.archived || ''),
        ilkislem: obj?.ilkislem || '',
        sonislem: obj?.sonislem || '',
        unvan: obj?.unvan || obj?.adsoyad || '',
        vkn: obj?.vkn || '',
        tckn: obj?.tckn || ''
      });
    }
    return rows;
  }

  function toYmd(value) {
    return String(value || '').replace(/\D/g, '').slice(0, 8);
  }

  function inYmdRange(ymd, start, end) {
    if (!ymd) return false;
    if (start && ymd < start) return false;
    if (end && ymd > end) return false;
    return true;
  }

  function clientFilterRows(rows, cfg = {}) {
    const start = toYmd(cfg.bastar);
    const end = toYmd(cfg.bittar);
    const servis = String(cfg.servis || '').trim();
    return (rows || []).filter(row => {
      const rowServis = String(row?.servis || '').trim();
      const ilk = toYmd(row?.ilkislem);
      const son = toYmd(row?.sonislem);
      const yk = toYmd(row?.ykodu);
      const rowDate = ilk || son || yk;
      if (servis && rowServis && rowServis !== servis) return false;
      return inYmdRange(rowDate, start, end);
    });
  }

  function previewResponse(resp) {
    try {
      const text = JSON.stringify(resp);
      return text.length > 500 ? text.slice(0, 500) + ' ...' : text;
    } catch (_) {
      return String(resp);
    }
  }

  function serviceOptionsHtml(selected = '60') {
    const empty = `<option value="" ${selected === '' ? 'selected' : ''}>Hepsi / servis boş</option>`;
    return empty + CFG.SERVICES.map(([value, label]) =>
      `<option value="${value}" ${value === selected ? 'selected' : ''}>${value} — ${label}</option>`
    ).join('');
  }

  function sourceOptionsHtml(selected = '0') {
    const options = [
      ['0', 'Kullanılan veriler'],
      ['1', 'Sadece arşiv verileri'],
      ['2', 'Arşiv dahil tüm veriler / durum+servis']
    ];
    return options.map(([value, label]) =>
      `<option value="${value}" ${String(value) === String(selected) ? 'selected' : ''}>${value} — ${label}</option>`
    ).join('');
  }

  function ydurumOptionsHtml(selected = '') {
    const options = [
      ['', 'Hepsi / boş'],
      ['10', 'Memurda'],
      ['20', 'Müdürde'],
      ['30', 'Koordinatörde'],
      ['40', 'Ekipte'],
      ['60', 'Yoklama sonuçlandı'],
      ['70', 'Sonuçlanmayanlar'],
      ['80', 'Görevli VD’de'],
      ['90', 'Sonlandırılanlar'],
      ['0', 'İptal edilenler']
    ];
    return options.map(([value, label]) =>
      `<option value="${value}" ${String(value) === String(selected) ? 'selected' : ''}>${value === '' ? '' : value + ' — '}${label}</option>`
    ).join('');
  }

  function sonucIslemOptionsHtml(selected = '1') {
    const options = [
      ['1', 'İşlem yapılacaklar'],
      ['2', 'İşlem yapılanlar'],
      ['0', 'Hepsi']
    ];
    return options.map(([value, label]) =>
      `<option value="${value}" ${String(value) === String(selected) ? 'selected' : ''}>${value} — ${label}</option>`
    ).join('');
  }

  function injectStyle() {
    if (document.getElementById(CFG.STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = CFG.STYLE_ID;
    s.textContent = `
      #${CFG.PANEL_ID}{position:fixed;top:6%;right:1.5%;width:620px;max-width:96vw;z-index:2147483647;background:#060912;color:#eaf0ff;font:12px/1.45 'Segoe UI',sans-serif;border:1px solid #232b3a;border-radius:10px;box-shadow:0 20px 50px rgba(0,0,0,.8)}
      #${CFG.PANEL_ID}, #${CFG.PANEL_ID} *{box-sizing:border-box}
      #${CFG.PANEL_ID} .h{display:flex;justify-content:space-between;align-items:center;padding:10px 15px;background:#121826;border-radius:10px 10px 0 0;border-bottom:1px solid #232b3a}
      #${CFG.PANEL_ID} .w{padding:12px}
      #${CFG.PANEL_ID} label{display:block;font-size:10px;color:#9aa6bf;margin:6px 0 3px;font-weight:bold;text-transform:uppercase}
      #${CFG.PANEL_ID} input,#${CFG.PANEL_ID} select{width:100%;background:#050814;border:1px solid #273048;padding:8px;color:#eaf0ff;border-radius:4px}
      #${CFG.PANEL_ID} input:disabled{opacity:.8;color:#9ddcff}
      #${CFG.PANEL_ID} button.action{width:100%;padding:10px;border:0;border-radius:4px;font-weight:bold;cursor:pointer;margin-top:8px}
      #${CFG.PANEL_ID} .mini{width:auto;background:none;color:#9ddcff;border:0;font-size:18px;margin-left:10px;padding:0;cursor:pointer}
      #${CFG.PANEL_ID} .row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      #${CFG.PANEL_ID} .row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}
      #${CFG.PANEL_ID} .tabs{display:flex;gap:6px;margin:10px 0 12px;flex-wrap:wrap}
      #${CFG.PANEL_ID} .tab-btn{flex:1;min-width:120px;padding:9px 10px;border:1px solid #273048;border-radius:6px;background:#0a1020;color:#c8d5f0;cursor:pointer;font-weight:bold}
      #${CFG.PANEL_ID} .tab-btn.active{background:#173056;color:#fff;border-color:#2d8cff}
      #${CFG.PANEL_ID} .tab-page{display:none}
      #${CFG.PANEL_ID} .tab-page.active{display:block}
      #${CFG.PANEL_ID} .card{margin-top:10px;padding:10px;border:1px solid #273048;border-radius:6px;background:#0a1020}
      #${CFG.PANEL_ID} .mutedtitle{font-weight:bold;color:#c4d5ff;margin-bottom:6px}
      #${CFG.PANEL_ID} .hint{margin-top:5px;color:#93a1c1;font-size:11px}
      #${CFG.PANEL_ID} .subnote{margin-top:6px;color:#9aa6bf;font-size:11px}
      #${CFG.PANEL_ID} .monitor{background:#000;color:#0f0;font-family:monospace;height:210px;overflow:auto;border:1px solid #333;padding:8px;margin-top:10px;border-radius:4px}
      #${CFG.PANEL_ID} .monitor .err{color:#ff6b6b}
      #${CFG.PANEL_ID} .list{max-height:180px;overflow:auto;border:1px solid #273048;border-radius:4px;margin-top:8px;background:#050814}
      #${CFG.PANEL_ID} .list-row{padding:7px 8px;border-bottom:1px solid #172034;display:flex;justify-content:space-between;gap:10px;align-items:center}
      #${CFG.PANEL_ID} .list-row:last-child{border-bottom:0}
      #${CFG.PANEL_ID} .tiny{font-size:11px;color:#aeb9d4}
      #${CFG.PANEL_ID} .inline-btn{width:auto;margin:0 0 0 6px;padding:5px 8px;font-size:11px;border-radius:4px;border:1px solid #36517d;background:#10213d;color:#fff;cursor:pointer}
      #${CFG.PANEL_ID} .inline-btn.warn{background:#4a3510;border-color:#9b7426}
      #${CFG.PANEL_ID} .inline-btn.good{background:#15391f;border-color:#2f8f4e}

      #${CFG.PANEL_ID} .today-mini{width:auto!important;margin-left:6px!important;padding:2px 7px!important;font-size:10px!important;line-height:1.2!important;border-radius:4px!important;background:#2563eb!important;color:#fff!important;border:1px solid #60a5fa!important;vertical-align:middle!important}


      #${CFG.PANEL_ID} .filter-tools{display:grid;grid-template-columns:1fr 1fr auto auto;gap:8px;align-items:end;margin-top:8px}
      #${CFG.PANEL_ID} .result-row{padding:7px 8px;border-bottom:1px solid #172034;display:grid;grid-template-columns:24px 1fr auto;gap:8px;align-items:center}
      #${CFG.PANEL_ID} .result-row:last-child{border-bottom:0}
      #${CFG.PANEL_ID} .result-row .code{font-family:monospace;color:#9ddcff}
      #${CFG.PANEL_ID} .result-row .meta{font-size:11px;color:#aeb9d4;margin-top:2px}
      #${CFG.PANEL_ID} .result-actions{display:flex;gap:6px;flex-wrap:wrap}
      #${CFG.PANEL_ID} .result-actions button{width:auto;margin:0;padding:5px 8px;font-size:11px;border-radius:4px;border:1px solid #36517d;background:#10213d;color:#fff;cursor:pointer}

    `;
    document.head.appendChild(s);
  }

  function createPanel() {
    const existing = document.getElementById(CFG.PANEL_ID);
    if (existing) return existing;

    const seed = getSessionSeed();
    const today = formatDateYYYYMMDD();
    const past180 = formatDateYYYYMMDD(new Date(Date.now() - 180 * 24 * 60 * 60 * 1000));

    const panel = document.createElement('div');
    panel.id = CFG.PANEL_ID;
    panel.innerHTML = `
      <div class="h">
        <strong>EYS Modülü</strong>
        <div>
          <button class="mini" id="eys_toggle">−</button>
          <button class="mini" id="eys_close" style="color:#ff6b6b">×</button>
        </div>
      </div>
      <div class="w" id="eys_wrap">
        <div class="row">
          <div><label>Kullanıcı ID</label><input id="u_user" value="${seed.user}" disabled></div>
          <div><label>Birim</label><input id="u_birim" value="${seed.birim}" disabled></div>
        </div>

        <div class="tabs">
          <button class="tab-btn active" data-tab="main">Akış</button>
          <button class="tab-btn" data-tab="filtered">Filtreli İşlem</button>
          <button class="tab-btn" data-tab="daily">Günlük PDF</button>
        </div>

        <div class="tab-page active" data-page="main">
          <div class="row">
            <div><label>Akış başlangıç</label><input id="main_bastar" value="${past180}"></div>
            <div><label>Akış bitiş</label><input id="main_bittar" value="${today}"></div>
          </div>
          <div class="row3">
            <button class="action" id="runBtn" style="background:#3ccf91;color:#00170c">AKIŞI BAŞLAT</button>
            <button class="action" id="memurBtn" style="background:#2d8cff;color:#fff">MEMUR REFRESH AÇ</button>
            <button class="action" id="mudurBtn" style="background:#8b5cf6;color:#fff">MÜDÜR REFRESH AÇ</button>
          </div>
          <button class="action" id="stopBtn" style="background:#cf3c3c;color:#fff;display:none">DURDUR</button>
          <div class="subnote">Bu sekme yalnız kendi tarih alanlarını kullanır. Memur→Müdür ve Müdür→Koordinatör tek tek gönderim döngüsüdür.</div>
          <div class="monitor" id="log_main"></div>
        </div>

        <div class="tab-page" data-page="filtered">
          <div class="row3">
            <div>
              <label>Rol</label>
              <select id="filtered_role">
                <option value="20" selected>Müdür</option>
                <option value="10">Memur</option>
              </select>
            </div>
            <div>
              <label>Servis</label>
              <select id="filtered_servis">${serviceOptionsHtml('60')}</select>
            </div>
            <div>
              <label>Aksiyon</label>
              <select id="filtered_action">
                <option value="archive">Arşive Kaldır</option>
                <option value="islem">İşlem Yapıldı</option>
              </select>
            </div>
          </div>
          <div class="row3">
            <div>
              <label>Veri kaynağı</label>
              <select id="filtered_source">${sourceOptionsHtml('0')}</select>
            </div>
            <div>
              <label>Yoklama durumu</label>
              <select id="filtered_ydurum">${ydurumOptionsHtml('')}</select>
            </div>
            <div>
              <label>İşlem durumu</label>
              <select id="filtered_sonucislem">${sonucIslemOptionsHtml('1')}</select>
            </div>
          </div>
          <div class="row">
            <div><label>Filtre başlangıç <button type="button" class="inline-btn today-mini" id="filtered_bastar_today">Bugün</button></label><input id="filtered_bastar" value="${past180}"></div>
            <div><label>Filtre bitiş</label><input id="filtered_bittar" value="${today}"></div>
          </div>
          <div class="row">
            <div><label>VKN Başlangıç</label><input id="filtered_vkn_start" placeholder="0000000000" maxlength="10" value="0000000000"></div>
            <div><label>VKN Bitiş</label><input id="filtered_vkn_end" placeholder="9999999999" maxlength="10" value="9999999999"></div>
          </div>
          <div class="row3">
            <button class="action" id="filteredQueryBtn" style="background:#22c55e;color:#04140c">SORGULA / LİSTELE</button>
            <button class="action" id="filteredApplyBtn" style="background:#f59e0b;color:#111">SEÇİLİLERE UYGULA</button>
            <button class="action" id="filteredSelectAllBtn" style="background:#2563eb;color:#fff">TÜMÜNÜ SEÇ / KALDIR</button>
          </div>
          <div class="subnote">Listeyi sorgula, çıkan kayıtlardan istediklerini işaretle, sonra seçilenlere arşiv veya işlem yapıldı uygula.</div>
          <div class="list" id="filtered_list"></div>
          <div class="monitor" id="log_filtered"></div>
        </div>

        <div class="tab-page" data-page="daily">
          <div class="row3">
            <div>
              <label>Rol</label>
              <select id="daily_role">
                <option value="20">Müdür</option>
                <option value="10" selected>Memur</option>
              </select>
            </div>
            <div>
              <label>Servis</label>
              <select id="daily_servis">${serviceOptionsHtml('60')}</select>
            </div>
            <div>
              <label>Günlük tarih</label>
              <input id="daily_date" value="${today}">
            </div>
          </div>
          <div class="row3">
            <div>
              <label>Veri kaynağı</label>
              <select id="daily_source">${sourceOptionsHtml('0')}</select>
            </div>
            <div>
              <label>Yoklama durumu</label>
              <select id="daily_ydurum">${ydurumOptionsHtml('60')}</select>
            </div>
            <div>
              <label>İşlem durumu</label>
              <select id="daily_sonucislem">${sonucIslemOptionsHtml('1')}</select>
            </div>
          </div>
          <div class="row">
            <div>
              <label>Yazıcı adı</label>
              <input id="daily_printer" placeholder="Örn: Lexmark_MS811_230">
            </div>
            <div>
              <label>PDF arası bekleme (ms)</label>
              <input id="daily_delay" value="1800">
            </div>
          </div>
          <div class="row">
            <div><label>VKN Başlangıç</label><input id="daily_vkn_start" placeholder="0000000000" maxlength="10" value="0000000000"></div>
            <div><label>VKN Bitiş</label><input id="daily_vkn_end" placeholder="9999999999" maxlength="10" value="9999999999"></div>
          </div>
          <div class="row3">
            <button class="action" id="dailyQueryBtn" style="background:#22c55e;color:#04140c">BUGÜN SORGULA</button>
            <button class="action" id="dailyOpenAllBtn" style="background:#2563eb;color:#fff">TÜM PDF'LERİ AÇ</button>
            <button class="action" id="dailyQueueBtn" style="background:#a855f7;color:#fff">KUYRUK YAZDIR</button>
          </div>
          <div class="hint">Chrome PDF viewer açılır. Bu sürüm PDF sekmesini otomatik print parametresiyle açar; yazıcı seçimi Linux/Chrome politikasına göre değişebilir.</div>
          <div class="list" id="daily_list"></div>
          <div class="monitor" id="log_daily"></div>
        </div>
      </div>
    `;

    document.body.appendChild(panel);
    return panel;
  }



  function eysTryEmbedIntoMainPanel() {
    try {
      const eysPanel = document.getElementById(CFG.PANEL_ID);
      const eysPage = document.getElementById('it_eys_tab_page');
      if (eysPanel && eysPage && eysPanel.parentElement !== eysPage) {
        eysPage.appendChild(eysPanel);
        eysPanel.classList.add('it-embedded-eys');
        if (!document.getElementById('it_tab_eys')?.classList.contains('active')) eysPage.style.display = 'none';
      }
    } catch (_) {}
  }

  function createLogger(box) {
    return (msg, err = false) => {
      const line = `[${new Date().toLocaleTimeString()}] ${msg}`;
      console.log('[EYS-EXT]', line);
      const row = document.createElement('div');
      if (err) row.className = 'err';
      row.textContent = err ? `HATA: ${line}` : line;
      box.appendChild(row);
      box.scrollTop = box.scrollHeight;
    };
  }

  class EysFullBot {
    constructor(panel) {
      this.panel = panel;
      this.logs = {
        main: createLogger(panel.querySelector('#log_main')),
        filtered: createLogger(panel.querySelector('#log_filtered')),
        daily: createLogger(panel.querySelector('#log_daily'))
      };
      this.running = false;
      this.timer = null;
      this.inFlight = false;
      this.filteredInFlight = false;
      this.dailyInFlight = false;
      this.dailyQueueInFlight = false;
      this.cycleNo = 0;
      this.sideUrl = null;
      this.dailyRows = [];
      this.filteredRows = [];
      this.filteredSelectAllState = false;
      this.applyEysDefaultSelections();
      this.bind();
    }

    log(tab, msg, err = false) {
      (this.logs[tab] || this.logs.main)(msg, err);
    }

    bind() {
      this.panel.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', () => this.activateTab(btn.dataset.tab)));
      this.panel.querySelector('#runBtn').addEventListener('click', () => this.start());
      this.panel.querySelector('#stopBtn').addEventListener('click', () => this.stop());
      const oldFilteredBtn = this.panel.querySelector('#filteredBtn');
      if (oldFilteredBtn) oldFilteredBtn.addEventListener('click', () => this.runFilteredWorkflow());
      
      const filteredTodayBtn = this.panel.querySelector('#filtered_bastar_today');
      if (filteredTodayBtn) {
        filteredTodayBtn.addEventListener('click', () => {
          const el = this.panel.querySelector('#filtered_bastar');
          if (el) {
            el.value = eysTodayYYYYMMDD();
            this.log('filtered', `Filtre başlangıç bugüne alındı: ${el.value}`);
          }
        });
      }

      const filteredQueryBtn = this.panel.querySelector('#filteredQueryBtn');
      if (filteredQueryBtn) filteredQueryBtn.addEventListener('click', () => this.runFilteredQueryOnly());
      const filteredApplyBtn = this.panel.querySelector('#filteredApplyBtn');
      if (filteredApplyBtn) filteredApplyBtn.addEventListener('click', () => this.applySelectedFilteredRows());
      const filteredSelectAllBtn = this.panel.querySelector('#filteredSelectAllBtn');
      if (filteredSelectAllBtn) filteredSelectAllBtn.addEventListener('click', () => this.toggleFilteredSelection());
      this.panel.querySelector('#dailyQueryBtn').addEventListener('click', () => this.runDailyQuery());
      this.panel.querySelector('#dailyOpenAllBtn').addEventListener('click', () => this.openAllDailyPdfs());
      this.panel.querySelector('#dailyQueueBtn').addEventListener('click', () => this.queuePrintDailyPdfs());
      ['#daily_vkn_start','#daily_vkn_end'].forEach(sel => {
        const el = this.panel.querySelector(sel);
        if (el) el.addEventListener('input', () => {
          el.value = (this.onlyDigits ? this.onlyDigits(el.value) : String(el.value || '').replace(/\D+/g, '')).slice(0, 10);
          this.renderDailyList();
        });
      });
      ['#filtered_vkn_start','#filtered_vkn_end'].forEach(sel => {
        const el = this.panel.querySelector(sel);
        if (el) el.addEventListener('input', () => {
          el.value = (this.onlyDigits ? this.onlyDigits(el.value) : String(el.value || '').replace(/\D+/g, '')).slice(0, 10);
        });
      });
      this.panel.querySelector('#memurBtn').addEventListener('click', async () => {
        await eysStorageSet(CFG.STORAGE_KEY, { role: '10', t: Date.now() });
        this.log('main', 'Memur için refresh başlatılıyor...');
        location.reload();
      });
      this.panel.querySelector('#mudurBtn').addEventListener('click', async () => {
        await eysStorageSet(CFG.STORAGE_KEY, { role: '20', t: Date.now() });
        this.log('main', 'Müdür için refresh başlatılıyor...');
        location.reload();
      });
      this.panel.querySelector('#eys_toggle').addEventListener('click', () => {
        const wrap = this.panel.querySelector('#eys_wrap');
        wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
      });
      this.panel.querySelector('#eys_close').addEventListener('click', () => {
        this.stop();
        this.panel.remove();
      });
    }

    activateTab(tab) {
      this.panel.querySelectorAll('.tab-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
      this.panel.querySelectorAll('.tab-page').forEach(page => page.classList.toggle('active', page.dataset.page === tab));
    }

    setButtons(running) {
      this.panel.querySelector('#runBtn').style.display = running ? 'none' : 'block';
      this.panel.querySelector('#stopBtn').style.display = running ? 'block' : 'none';
    }

    getMainConfig() {
      return {
        bastar: this.panel.querySelector('#main_bastar').value.trim(),
        bittar: this.panel.querySelector('#main_bittar').value.trim()
      };
    }

    getFilteredConfig() {
      return {
        role: this.panel.querySelector('#filtered_role').value.trim() || '20',
        servis: this.panel.querySelector('#filtered_servis').value.trim(),
        action: this.panel.querySelector('#filtered_action').value.trim(),
        source: this.panel.querySelector('#filtered_source')?.value ?? '0',
        ydurum: this.panel.querySelector('#filtered_ydurum')?.value ?? '',
        sonucislem: this.panel.querySelector('#filtered_sonucislem')?.value ?? '1',
        bastar: this.panel.querySelector('#filtered_bastar').value.trim(),
        bittar: this.panel.querySelector('#filtered_bittar').value.trim(),
        vknStart: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#filtered_vkn_start')?.value || '') : String(this.panel.querySelector('#filtered_vkn_start')?.value || '').replace(/\D+/g, '')).slice(0, 10),
        vknEnd: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#filtered_vkn_end')?.value || '') : String(this.panel.querySelector('#filtered_vkn_end')?.value || '').replace(/\D+/g, '')).slice(0, 10)
      };
    }

    getDailyConfig() {
      return {
        role: this.panel.querySelector('#daily_role').value.trim() || '20',
        servis: this.panel.querySelector('#daily_servis').value.trim(),
        date: this.panel.querySelector('#daily_date').value.trim(),
        source: this.panel.querySelector('#daily_source')?.value ?? '0',
        ydurum: this.panel.querySelector('#daily_ydurum')?.value ?? '60',
        sonucislem: this.panel.querySelector('#daily_sonucislem')?.value ?? '1',
        printer: this.panel.querySelector('#daily_printer').value.trim(),
        delay: Number(this.panel.querySelector('#daily_delay').value.trim() || '1800') || 1800,
        vknStart: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#daily_vkn_start')?.value || '') : String(this.panel.querySelector('#daily_vkn_start')?.value || '').replace(/\D+/g, '')).slice(0, 10),
        vknEnd: (this.onlyDigits ? this.onlyDigits(this.panel.querySelector('#daily_vkn_end')?.value || '') : String(this.panel.querySelector('#daily_vkn_end')?.value || '').replace(/\D+/g, '')).slice(0, 10)
      };
    }


    onlyDigits(v) {
      return String(v || '').replace(/\D+/g, '');
    }

    rowVkn(row) {
      const raw = String(row?.vkn || row?.vkntckn || row?.tckn || row?.tcKimlikNo || row?.vergiNo || '');
      const nums = raw.match(/\d{10,11}/g) || [];
      return nums.find(x => String(x).length === 10) || '';
    }

    inVknRange(vkn, start, end) {
      start = this.onlyDigits(start || '').slice(0, 10);
      end = this.onlyDigits(end || '').slice(0, 10);
      if (!start && !end) return true;
      if (!vkn || String(vkn).length !== 10) return false;
      if (start && !end) return String(vkn) >= start;
      if (!start && end) return String(vkn) <= end;
      return String(vkn) >= start && String(vkn) <= end;
    }

    filterRowsByVkn(rows, cfg) {
      const start = this.onlyDigits(cfg?.vknStart || '').slice(0, 10);
      const end = this.onlyDigits(cfg?.vknEnd || '').slice(0, 10);
      return (rows || []).filter(row => this.inVknRange(this.rowVkn(row), start, end));
    }

    selectedFilteredRows() {
      const box = this.panel.querySelector('#filtered_list');
      if (!box) return [];
      const checked = Array.from(box.querySelectorAll('input[data-fidx]:checked'))
        .map(x => Number(x.dataset.fidx))
        .filter(n => Number.isFinite(n));
      return checked.map(i => this.filteredRows[i]).filter(Boolean);
    }

    renderFilteredList() {
      const box = this.panel.querySelector('#filtered_list');
      if (!box) return;
      box.innerHTML = '';
      if (!this.filteredRows || !this.filteredRows.length) {
        box.innerHTML = '<div class="list-row"><span class="tiny">Kayıt yok.</span></div>';
        return;
      }
      this.filteredRows.forEach((row, index) => {
        const div = document.createElement('div');
        div.className = 'result-row';
        div.innerHTML = `
          <div><input type="checkbox" data-fidx="${index}"></div>
          <div>
            <div><strong class="code">${row.ykodu || '-'}</strong></div>
            <div class="meta">VKN: ${row.vkn || '-'} | TCKN: ${row.tckn || '-'} | servis=${row.servis || '-'} | durum=${row.durum || '-'} | ${row.unvan || ''}</div>
          </div>
          <div class="result-actions">
            <button type="button" data-open-filtered="${index}">PDF Aç</button>
          </div>`;
        box.appendChild(div);
      });
      box.querySelectorAll('[data-open-filtered]').forEach(btn => {
        btn.addEventListener('click', () => this.openFilteredPdf(Number(btn.dataset.openFiltered)));
      });
    }

    openFilteredPdf(index) {
      const row = this.filteredRows?.[index];
      if (!row || !row.ykodu) return this.log('filtered', 'PDF için yKodu bulunamadı.', true);
      const url = this.buildPdfUrl(row.ykodu);
      this.log('filtered', `PDF açılıyor: ${row.ykodu}`);
      eysOpenPdfPopup(url);
    }

    toggleFilteredSelection() {
      const box = this.panel.querySelector('#filtered_list');
      if (!box) return;
      this.filteredSelectAllState = !this.filteredSelectAllState;
      box.querySelectorAll('input[data-fidx]').forEach(x => x.checked = this.filteredSelectAllState);
      this.log('filtered', this.filteredSelectAllState ? 'Tüm kayıtlar seçildi.' : 'Seçimler kaldırıldı.');
    }

    async runFilteredQueryOnly() {
      if (this.filteredInFlight) return this.log('filtered', 'Filtreli sorgu zaten çalışıyor.');
      const cfg = this.getFilteredConfig();
      if (!cfg.bastar || !cfg.bittar) return this.log('filtered', 'Tarih alanları boş bırakılamaz.', true);
      this.filteredInFlight = true;
      try {
        const roleName = cfg.role === '10' ? 'Memur' : 'Müdür';
        this.log('filtered', `Filtreli liste sorgusu başladı. rol=${roleName} kaynak=${cfg.source} servis=${cfg.servis || '-'} ydurum=${cfg.ydurum || '-'} sonucislem=${cfg.sonucislem}`);
        const sessionData = await this.bootRole(cfg.role, 'filtered');
        const listResp = await this.getYoklamalarFiltered(sessionData, cfg.servis, { bastar: cfg.bastar, bittar: cfg.bittar }, 'filtered', { sorgukaynak: cfg.source, ydurum: cfg.ydurum, sonucislem: cfg.sonucislem, vknStart: cfg.vknStart, vknEnd: cfg.vknEnd });
        const rows = extractYoklamaRows(listResp);
        const dateFiltered = clientFilterRows(rows, cfg);
        this.filteredRows = this.filterRowsByVkn(dateFiltered, cfg);
        this.filteredSelectAllState = false;
        this.renderFilteredList();
        this.log('filtered', `Kayıt: ${rows.length}, tarih/servis sonrası: ${dateFiltered.length}, VKN sonrası: ${this.filteredRows.length}`);
      } catch (err) {
        this.log('filtered', err?.message || String(err), true);
      } finally {
        this.filteredInFlight = false;
      }
    }

    async applySelectedFilteredRows() {
      if (this.filteredInFlight) return this.log('filtered', 'İşlem zaten çalışıyor.');
      const cfg = this.getFilteredConfig();
      const selected = this.selectedFilteredRows();
      const ykodlari = selected.map(x => x.ykodu).filter(Boolean);
      if (!ykodlari.length) return this.log('filtered', 'Seçili kayıt yok.', true);
      this.filteredInFlight = true;
      try {
        const sessionData = await this.bootRole(cfg.role, 'filtered');
        this.log('filtered', `Seçili ${ykodlari.length} kayıt için işlem uygulanacak: ${cfg.action}`);
        const actionResp = cfg.action === 'archive'
          ? await this.archiveYoklamalar(ykodlari, sessionData)
          : await this.markIslemYapildi(ykodlari, sessionData);
        this.log('filtered', `${cfg.action === 'archive' ? 'Arşive kaldırma' : 'İşlem yapıldı'} tamamlandı. (${ykodlari.length} kayıt)`);
        this.log('filtered', `Aksiyon response: ${previewResponse(actionResp)}`);
        await this.runFilteredQueryOnly();
      } catch (err) {
        this.log('filtered', err?.message || String(err), true);
      } finally {
        this.filteredInFlight = false;
      }
    }

    getVisibleDailyRows() {
      const cfg = this.getDailyConfig();
      return this.filterRowsByVkn(this.dailyRows || [], cfg);
    }



    applyEysDefaultSelections() {
      const forceVal = (id, val) => {
        const el = this.panel.querySelector('#' + id);
        if (el) el.value = val;
      };
      forceVal('filtered_role', '20');
      forceVal('filtered_service', '60');
      forceVal('filtered_source', '0');
      forceVal('filtered_ydurum', '');
      forceVal('filtered_sonucislem', '1');
      forceVal('daily_role', '10');
      forceVal('daily_service', '91');
      forceVal('daily_source', '0');
      forceVal('daily_ydurum', '60');
      forceVal('daily_sonucislem', '1');

      const fvs = this.panel.querySelector('#filtered_vkn_start'); if (fvs && !fvs.value) fvs.value = '0000000000';
      const fve = this.panel.querySelector('#filtered_vkn_end'); if (fve && !fve.value) fve.value = '9999999999';
      const dvs = this.panel.querySelector('#daily_vkn_start'); if (dvs && !dvs.value) dvs.value = '0000000000';
      const dve = this.panel.querySelector('#daily_vkn_end'); if (dve && !dve.value) dve.value = '9999999999';
      const delay = this.panel.querySelector('#daily_delay'); if (delay && !delay.value) delay.value = '1800';
    }


    uniqueYkodlari(list) {
      const out = [];
      const seen = new Set();
      for (const y of list || []) {
        const v = String(y || '').trim();
        if (!v || seen.has(v)) continue;
        seen.add(v);
        out.push(v);
      }
      return out;
    }

    async getIadeler(sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.IADE_LIST, {
        data: {
          koor: '',
          vd: sessionData.birim,
          vdkodu: sessionData.birim,
          icdis: '0'
        },
        sessionData
      });
    }

    async sendYoklamalarTekTek(ykodlari, sessionData, sendMethod, label, tab = 'main') {
      const list = this.uniqueYkodlari(ykodlari);
      const results = [];
      let ok = 0;
      let fail = 0;

      if (!list.length) {
        this.log(tab, `${label}: gönderilecek kayıt yok.`);
        return { ok, fail, total: 0, results };
      }

      this.log(tab, `${label}: ${list.length} kayıt tek tek gönderilecek.`);

      for (let i = 0; i < list.length; i += 1) {
        const ykodu = list[i];
        try {
          this.log(tab, `${label}: ${i + 1}/${list.length} gönderiliyor → ${ykodu}`);
          const resp = await sendMethod.call(this, [ykodu], sessionData);
          results.push({ ykodu, ok: true, resp });
          ok += 1;
          this.log(tab, `${label}: ${i + 1}/${list.length} tamam → ${previewResponse(resp)}`);
        } catch (err) {
          fail += 1;
          results.push({ ykodu, ok: false, error: err?.message || String(err) });
          this.log(tab, `${label}: ${i + 1}/${list.length} hata → ${ykodu} | ${err?.message || String(err)}`, true);
        }
        await sleep(CFG.SEQUENTIAL_SEND_WAIT_MS || 450);
      }

      this.log(tab, `${label}: tek tek gönderim bitti. Başarılı=${ok}, Hatalı=${fail}, Toplam=${list.length}`);
      return { ok, fail, total: list.length, results };
    }


    async ensureSideUrl() {
      if (this.sideUrl) return this.sideUrl;
      const candidates = buildSideCandidates();
      this.log('main', 'side-dispatch adresi aranıyor...');
      for (const url of candidates) {
        const probe = await tryPost(url, CFG.COMMANDS.SIDE_GET_MODULE_INFO, { moduleName: 'e', excludeList: [], lang: 'tr' });
        if (!probe || !probe.__error) {
          this.sideUrl = url;
          this.log('main', 'Kullanılacak side-dispatch: ' + url);
          return url;
        }
      }
      throw new Error('Çalışan side-dispatch adresi bulunamadı.');
    }

    async bootRole(role, tab = 'main') {
      const sessionData = buildSessionData(role);
      const isMudur = String(role) === '20';
      const user = sessionData.user;
      const sideUrl = await this.ensureSideUrl();
      const bfNames = isMudur ? ['e.P_DESKTOP_MUDUR'] : ['e.PG_INDEX'];
      const loadedList = isMudur ? ['g.PG_INDEX', 'e.PG_INDEX'] : ['g.PG_INDEX', 'g.PG_MHK_ANA_SAYFA'];

      this.log(tab, `${isMudur ? 'Müdür' : 'Memur'} bot BF yükleniyor: ${bfNames.join(', ')}`);

      await post(sideUrl, CFG.COMMANDS.SIDE_GET_MODULE_INFO, {
        moduleName: 'e',
        excludeList: [
          'jquery','jquery-ui','jquery-ui-timepicker','ui.datepicker-tr','jquery.maskedinput',
          'jquery.ratings','jquery-jmenu','jquery-currency-autonumeric','underscore','tinymce','nouislider','tus'
        ],
        lang: 'tr'
      });

      await post(sideUrl, CFG.COMMANDS.SIDE_GET_EAGER_BF_DEFS, {
        userid: user,
        bfnames: bfNames,
        loadedList,
        resourceBundleLang: 'tr'
      });

      try { await post(sideUrl, CFG.COMMANDS.SIDE_GET_SERVICE_DEF_LIST, {}); } catch (_) {}
      await post(CFG.EYS_URL, CFG.COMMANDS.CREATE_SESSION, { orgs: [{ birimKodu: sessionData.birim }], sessionData });
      try { await post(CFG.EYS_URL, CFG.COMMANDS.CHECK_USER, { tckn: sessionData.user, sessionData }); } catch (_) {}
      try { await post(CFG.EYS_URL, CFG.COMMANDS.GET_VD_ADI, { vdkodu: sessionData.birim, sessionData }); } catch (_) {}
      return sessionData;
    }

    async getMemurList(sessionData, config = null) {
      const { bastar, bittar } = config || this.getMainConfig();
      return post(CFG.EYS_URL, CFG.COMMANDS.MEMUR_LIST, { bastar, bittar, vdkodu: sessionData.birim, sessionData });
    }

    async sendToMudur(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MEMUR_SEND, { ykodlari, sessionData });
    }

    async getMudurList(sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MUDUR_LIST, { birim: sessionData.birim, sessionData });
    }

    async sendToKoor(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.MUDUR_SEND, { ykodlari, sessionData });
    }

    async getYoklamalarFiltered(sessionData, servis, range, tab = 'filtered', opts = {}) {
      const ydurum = String(opts.ydurum ?? '');
      const sonucislem = String(opts.sonucislem ?? '1');
      const sorgukaynak = String(opts.sorgukaynak ?? opts.source ?? '0');
      const basvkn = this.onlyDigits(opts.vknStart || '').slice(0, 10);
      const sonvkn = this.onlyDigits(opts.vknEnd || '').slice(0, 10);
      this.log(tab, `Yoklamalar sorgulanıyor. kaynak=${sorgukaynak} servis=${servis || '-'} bastar=${range.bastar} bittar=${range.bittar} ydurum=${ydurum || '-'} sonucislem=${sonucislem} vkn=${basvkn || '-'}..${sonvkn || '-'}`);
      return post(CFG.EYS_URL, CFG.COMMANDS.GET_YOKLAMALAR, {
        data: {
          koor: '', vd: sessionData.birim, vdkodu: sessionData.birim, sorgukaynak, icdis: '0',
          disil: '', disvd: '', basvkn, sonvkn, bastckn: '', sontckn: '', yabanci: 0,
          vkn: basvkn || '', tckn: '', yturu: [], ydurum, sonucislem, servis: String(servis || ''),
          bastar: range.bastar, bittar: range.bittar, unvan: '', ym: '', usekullanici: false,
          eosusergiris: sessionData.giris, eosuser: sessionData.user, ihbaraDayali: false
        },
        sessionData
      });
    }

    async archiveYoklamalar(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.ARCHIVE_YOKLAMA, { ykodlari, sessionData });
    }

    async markIslemYapildi(ykodlari, sessionData) {
      return post(CFG.EYS_URL, CFG.COMMANDS.ISLEM_YAPILDI, { ykodlari, durum: '80', islem: 'işlem', sessionData });
    }

    async runFilteredWorkflow() {
      if (this.filteredInFlight) return this.log('filtered', 'Filtreli işlem zaten çalışıyor.');
      const cfg = this.getFilteredConfig();
      if (!cfg.bastar || !cfg.bittar) return this.log('filtered', 'Tarih alanları boş bırakılamaz.', true);

      this.filteredInFlight = true;
      try {
        const roleName = cfg.role === '10' ? 'Memur' : 'Müdür';
        this.log('filtered', `Filtreli işlem başlatıldı. rol=${roleName} kaynak=${cfg.source} servis=${cfg.servis || '-'} ydurum=${cfg.ydurum || '-'} sonucislem=${cfg.sonucislem} aksiyon=${cfg.action}`);
        const sessionData = await this.bootRole(cfg.role, 'filtered');
        const listResp = await this.getYoklamalarFiltered(sessionData, cfg.servis, { bastar: cfg.bastar, bittar: cfg.bittar }, 'filtered', { sorgukaynak: cfg.source, ydurum: cfg.ydurum, sonucislem: cfg.sonucislem, vknStart: cfg.vknStart, vknEnd: cfg.vknEnd });
        const rows = extractYoklamaRows(listResp);
        const filteredRows = this.filterRowsByVkn(clientFilterRows(rows, cfg), cfg);
        const ykodlari = filteredRows.map(x => x.ykodu);
        this.log('filtered', `Sorgu response önizleme: ${previewResponse(listResp)}`);
        this.log('filtered', `Servisten gelen kayıt: ${rows.length}, istemci filtresinden geçen: ${filteredRows.length}`);
        if (rows.length && !filteredRows.length) {
          this.log('filtered', 'Uyarı: servis kayıt döndürdü ama tarih/servis istemci filtresinden hiç kayıt geçmedi.', true);
        }
        if (!ykodlari.length) return this.log('filtered', 'Uygun yoklama bulunamadı.');
        this.log('filtered', `Toplam ${ykodlari.length} yoklama işlenecek. İlk kayıt: ${ykodlari[0]}`);
        const actionResp = cfg.action === 'archive'
          ? await this.archiveYoklamalar(ykodlari, sessionData)
          : await this.markIslemYapildi(ykodlari, sessionData);
        this.log('filtered', `${cfg.action === 'archive' ? 'Arşive kaldırma' : 'İşlem yapıldı'} tamamlandı. (${ykodlari.length} kayıt)`);
        this.log('filtered', `Aksiyon response: ${previewResponse(actionResp)}`);
      } catch (err) {
        this.log('filtered', err?.message || String(err), true);
      } finally {
        this.filteredInFlight = false;
      }
    }

    buildPdfUrl(ykodu, opts = {}) {
      const base = window.location.origin.includes('eyoklama.gelirler.gov.tr')
        ? window.location.origin
        : 'http://eyoklama.gelirler.gov.tr:32516';
      const u = new URL(`${base}/edenetis/getSonuc`);
      u.searchParams.set('yKodu', String(ykodu || ''));
      if (opts.autoPrint) u.searchParams.set('eys_autoprint', '1');
      if (opts.delay) u.searchParams.set('eys_delay', String(opts.delay));
      if (opts.closeAfter) u.searchParams.set('eys_close', '1');
      return u.toString();
    }

    renderDailyList() {
      const box = this.panel.querySelector('#daily_list');
      box.innerHTML = '';
      const visibleRows = this.getVisibleDailyRows();
      this.dailyVisibleRows = visibleRows;
      if (!visibleRows.length) {
        box.innerHTML = '<div class="list-row"><span class="tiny">Henüz kayıt yok veya VKN filtresine uyan kayıt yok.</span></div>';
        return;
      }
      visibleRows.forEach((row, index) => {
        const div = document.createElement('div');
        div.className = 'list-row';
        div.innerHTML = `
          <div>
            <div><strong>${row.ykodu}</strong></div>
            <div class="tiny">servis=${row.servis || '-'} durum=${row.durum || '-'} archived=${row.archived || '-'} ${row.unvan || ''}</div>
          </div>
          <div>
            <button class="inline-btn" data-open="${index}">PDF Aç</button>
            <button class="inline-btn good" data-print="${index}">Yazdır 1-2</button>
          </div>`;
        box.appendChild(div);
      });
      box.querySelectorAll('[data-open]').forEach(btn => btn.addEventListener('click', () => this.openDailyPdf(Number(btn.dataset.open))));
      box.querySelectorAll('[data-print]').forEach(btn => btn.addEventListener('click', () => this.printDailyPdf(Number(btn.dataset.print))));
    }

    async runDailyQuery() {
      if (this.dailyInFlight) return this.log('daily', 'Günlük sorgu zaten çalışıyor.');
      const cfg = this.getDailyConfig();
      if (!cfg.date) return this.log('daily', 'Günlük tarih boş bırakılamaz.', true);

      this.dailyInFlight = true;
      try {
        this.log('daily', `Günlük sorgu başlatıldı. rol=${cfg.role === '10' ? 'Memur' : 'Müdür'} kaynak=${cfg.source} servis=${cfg.servis || '-'} tarih=${cfg.date} ydurum=${cfg.ydurum || '-'} sonucislem=${cfg.sonucislem}`);
        const sessionData = await this.bootRole(cfg.role, 'daily');
        const listResp = await this.getYoklamalarFiltered(
          sessionData,
          cfg.servis,
          { bastar: cfg.date, bittar: cfg.date },
          'daily',
          { sorgukaynak: cfg.source, ydurum: cfg.ydurum, sonucislem: cfg.sonucislem, vknStart: cfg.vknStart, vknEnd: cfg.vknEnd }
        );
        this.dailyRows = extractYoklamaRows(listResp);
        this.log('daily', `Sorgu response önizleme: ${previewResponse(listResp)}`);
        this.log('daily', `Günlük sorgu filtreleri: kaynak=${cfg.source}, yoklama durumu=${cfg.ydurum || 'hepsi'}, işlem durumu=${cfg.sonucislem}`);
        this.log('daily', `Toplam ${this.dailyRows.length} kayıt bulundu. VKN filtresine uyan: ${this.getVisibleDailyRows().length}`);
        if (cfg.printer) this.log('daily', `Seçili yazıcı notu: ${cfg.printer}`);
        this.renderDailyList();
      } catch (err) {
        this.log('daily', err?.message || String(err), true);
      } finally {
        this.dailyInFlight = false;
      }
    }

    openDailyPdf(index) {
      const row = (this.dailyVisibleRows || this.dailyRows || [])[index];
      if (!row) return;
      const url = this.buildPdfUrl(row.ykodu);
      this.log('daily', `PDF açılıyor: ${row.ykodu}`);
      eysOpenPdfPopup(url);
    }

    async printDailyPdf(index) {
      const row = (this.dailyVisibleRows || this.dailyRows || [])[index];
      if (!row) return;
      const cfg = this.getDailyConfig();
      const url = this.buildPdfUrl(row.ykodu, { autoPrint: true, delay: cfg.delay });
      this.log('daily', `PDF yazdırma denemesi: ${row.ykodu} (Chrome PDF viewer otomatik print)`);
      const win = eysOpenPdfPopup(url);
      if (!win) return this.log('daily', 'Popup engellendi. PDF penceresi açılamadı.', true);
      try {
        await sleep(300);
        win.focus();
        this.log('daily', 'PDF sekmesi açıldı. Otomatik print parametresi gönderildi; olmazsa Ctrl+P kullan.');
      } catch (err) {
        this.log('daily', 'PDF sekmesi açıldı ama focus/print izleme başarısız: ' + (err?.message || String(err)), true);
      }
    }

    openAllDailyPdfs() {
      const rows = this.getVisibleDailyRows();
      if (!rows.length) return this.log('daily', 'Önce günlük sorgu yap veya VKN filtresine uyan kayıt yok.', true);
      this.log('daily', `Toplam ${rows.length} PDF açılıyor...`);
      rows.forEach(row => {
        const url = this.buildPdfUrl(row.ykodu);
        eysOpenPdfPopup(url);
      });
    }

    async queuePrintDailyPdfs() {
      if (this.dailyQueueInFlight) return this.log('daily', 'Kuyruk yazdırma zaten çalışıyor.');
      const rows = this.getVisibleDailyRows();
      if (!rows.length) return this.log('daily', 'Önce günlük sorgu yap veya VKN filtresine uyan kayıt yok.', true);
      this.dailyQueueInFlight = true;
      const cfg = this.getDailyConfig();
      try {
        this.log('daily', `Kuyruk yazdırma başladı. kayıt=${rows.length} gecikme=${cfg.delay}ms. Sayfa aralığı 1-2 için print penceresinde kontrol gerekir.`);
        if (cfg.printer) this.log('daily', `Hedef yazıcı notu: ${cfg.printer}`);
        for (let i = 0; i < rows.length; i += 1) {
          const row = rows[i];
          this.log('daily', `${i + 1}/${rows.length} işleniyor: ${row.ykodu}`);
          const autoUrl = this.buildPdfUrl(row.ykodu, { autoPrint: true, delay: cfg.delay });
          const win = window.open(autoUrl, '_blank');
          if (!win) {
            this.log('daily', `Popup engellendi: ${row.ykodu}`, true);
          } else {
            try { win.focus(); } catch (_) {}
          }
          await sleep(Math.max(1200, cfg.delay + 700));
        }
        this.log('daily', 'Kuyruk açma tamamlandı. Her PDF sekmesi otomatik print denedi; gerekirse Ctrl+P ile devam et.');
      } catch (err) {
        this.log('daily', err?.message || String(err), true);
      } finally {
        this.dailyQueueInFlight = false;
      }
    }

    scheduleNext(reason) {
      if (!this.running) return;
      clearTimeout(this.timer);
      this.log('main', `${reason} 5 dakika sonra yeni tur başlayacak...`);
      this.timer = setTimeout(() => this.runCycle(), CFG.RESCAN_MS);
    }

    async runMudurStage() {
      this.log('main', 'Müdür oturumu açılıyor...');
      const mudurSession = await this.bootRole('20', 'main');

      let iadeSet = new Set();
      try {
        this.log('main', 'Koordinatörden iade/geri dönen yoklamalar sorgulanıyor...');
        const iadeResp = await this.getIadeler(mudurSession);
        const iadeYkodlari = this.uniqueYkodlari(extractYkodlariStrict(iadeResp));
        iadeSet = new Set(iadeYkodlari);
        this.log('main', `İade sorgusu tamamlandı. Tekrar gönderilmeyecek kayıt: ${iadeYkodlari.length}`);
      } catch (err) {
        this.log('main', 'İade sorgusu alınamadı; akış devam edecek: ' + (err?.message || String(err)), true);
      }

      this.log('main', 'Müdür onay bekleyen listesi sorgulanıyor...');
      const mudurResp = await this.getMudurList(mudurSession);
      const mudurYkodlariRaw = this.uniqueYkodlari(extractYkodlariStrict(mudurResp));
      const mudurYkodlari = mudurYkodlariRaw.filter(yk => !iadeSet.has(yk));

      this.log('main', `Müdür response önizleme: ${previewResponse(mudurResp)}`);
      this.log('main', `Müdür listesi: ${mudurYkodlariRaw.length}, iade nedeniyle atlanan: ${mudurYkodlariRaw.length - mudurYkodlari.length}, gönderilecek: ${mudurYkodlari.length}`);

      if (mudurYkodlari.length > 0) {
        const sendSummary = await this.sendYoklamalarTekTek(
          mudurYkodlari,
          mudurSession,
          this.sendToKoor,
          'Müdür → Koordinatör',
          'main'
        );
        this.log('main', `Müdür → Koordinatör aşaması bitti. Başarılı=${sendSummary.ok}, Hatalı=${sendSummary.fail}`);
        return sendSummary.ok > 0;
      }

      this.log('main', 'Müdür listesinde gönderilecek kayıt yok.');
      return false;
    }

    async runCycle() {
      if (!this.running || this.inFlight) return;
      this.inFlight = true;
      this.cycleNo += 1;
      try {
        const dateCfg = this.getMainConfig();
        this.log('main', `Tur #${this.cycleNo} başladı. bastar=${dateCfg.bastar} bittar=${dateCfg.bittar}`);
        this.log('main', 'Memur oturumu açılıyor...');
        const memurSession = await this.bootRole('10', 'main');
        this.log('main', 'Memur listesi sorgulanıyor...');
        const memurResp = await this.getMemurList(memurSession, dateCfg);
        const memurYkodlari = extractYkodlariStrict(memurResp);
        this.log('main', `Memur response önizleme: ${previewResponse(memurResp)}`);
        if (memurYkodlari.length > 0) {
          this.log('main', `Memur listesinde ${memurYkodlari.length} kayıt bulundu. İlk kayıt: ${memurYkodlari[0]}`);
          const sendSummary = await this.sendYoklamalarTekTek(
            memurYkodlari,
            memurSession,
            this.sendToMudur,
            'Memur → Müdür',
            'main'
          );
          this.log('main', `Memur → Müdür aşaması bitti. Başarılı=${sendSummary.ok}, Hatalı=${sendSummary.fail}`);
          await sleep(CFG.AFTER_MEMUR_SEND_WAIT_MS);
          const mudurProcessed = await this.runMudurStage();
          this.scheduleNext(mudurProcessed ? 'Müdür aşaması da çalıştı.' : 'Müdür aşaması boş geçti.');
          return;
        }
        this.log('main', 'Memur listesi boş. Doğrudan müdür aşamasına geçiliyor...');
        const mudurProcessed = await this.runMudurStage();
        this.scheduleNext(mudurProcessed ? 'Müdür aşaması çalıştı.' : 'Bekleyen kayıt yok.');
      } catch (err) {
        this.log('main', err?.message || String(err), true);
        this.scheduleNext('Hata sonrası yeniden deneme için');
      } finally {
        this.inFlight = false;
      }
    }

    start() {
      if (this.running) return;
      this.running = true;
      this.setButtons(true);
      this.log('main', 'Bot başlatıldı. Bu akış yalnız Akış sekmesinin tarihlerini kullanır.');
      this.runCycle();
    }

    stop() {
      this.running = false;
      this.inFlight = false;
      clearTimeout(this.timer);
      this.timer = null;
      this.setButtons(false);
      this.log('main', 'Bot durduruldu.');
    }
  }

  function findRoleSelect() {
    const candidates = Array.from(document.querySelectorAll('select.csc-combobox, select'));
    for (const sel of candidates) {
      if (!visible(sel)) continue;
      const joined = Array.from(sel.options || []).map(o => textOf(o).toLowerCase()).join(' | ');
      if (joined.includes('yoklama') || joined.includes('memur') || joined.includes('müdür')) return sel;
    }
    return null;
  }

  function findOpenButton() {
    const candidates = Array.from(document.querySelectorAll('input.csc-button,input[type="button"],input[type="submit"],button'));
    for (const el of candidates) {
      if (!visible(el)) continue;
      const txt = textOf(el).toLowerCase();
      if (txt.includes('eys modülünü aç') || txt.includes('eys modulunu ac') || txt.includes('eys mod')) return el;
    }
    return null;
  }

  function findEysLauncher() {
    const exact = document.querySelector('#gen__1023.csc-button.gibintra-uyg-btns.gibintra-eds-btn');
    if (exact && visible(exact)) return exact;
    const all = Array.from(document.querySelectorAll('input.csc-button,button,input[type="button"],input[type="submit"],a,div,span')).filter(visible);
    const scored = all.map(el => {
      const txt = `${textOf(el)} ${el.id || ''} ${el.className || ''}`.toLowerCase();
      let score = 0;
      if (txt.includes('eys')) score += 10;
      if (txt.includes('elektronik yoklama')) score += 8;
      if (txt.includes('yoklama')) score += 6;
      if (txt.includes('gibintra-eds-btn')) score += 5;
      if (txt.includes('uyg-btn')) score += 3;
      return { el, score };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);
    return scored[0]?.el || null;
  }

  async function waitForPopupReady(log) {
    const started = Date.now();
    while (Date.now() - started < 15000) {
      const sel = findRoleSelect();
      const btn = findOpenButton();
      if (sel && btn) {
        log('Popup hazır. Rol seçimi ve aç butonu bulundu.');
        return true;
      }
      await sleep(300);
    }
    return false;
  }

  function selectRole(role, log) {
    const sel = findRoleSelect();
    if (!sel) return false;
    const targetNeedle = String(role) === '20' ? 'müdür' : 'memur';
    const opt = Array.from(sel.options).find(o => textOf(o).toLowerCase().includes(targetNeedle));
    if (!opt) return false;
    sel.value = opt.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    log(`Rol seçildi: ${opt.text}`);
    return true;
  }

  async function openFlow(role, log) {
    const launcher = findEysLauncher();
    if (!launcher) return log('EYS launcher bulunamadı.', true);
    log('EYS launcher tetikleniyor...');
    launcher.click();
    const ready = await waitForPopupReady(log);
    if (!ready) return log('Popup hazır olmadı.', true);
    const selected = selectRole(role, log);
    if (!selected) return log('Rol seçilemedi.', true);
    const btn = findOpenButton();
    if (!btn) return log('"EYS MODÜLÜNÜ AÇ" butonu bulunamadı.', true);
    log('Aç butonuna basılıyor...');
    btn.click();
    log('Açma akışı gönderildi.');
  }

  async function resumeIfNeeded(log) {
    const data = await eysStorageGet(CFG.STORAGE_KEY);
    if (!data || !data.role || Date.now() - Number(data.t || 0) > 120000) return;
    await eysStorageRemove(CFG.STORAGE_KEY);
    log(`Refresh sonrası otomatik devam ediyor. role=${data.role}`);
    openFlow(data.role, log);
  }

  injectStyle();
  const panel = createPanel();
  eysTryEmbedIntoMainPanel();
  const bot = new EysFullBot(panel);
  bot.log('main', 'Hazır.');
  bot.log('filtered', 'Hazır. Bu monitör yalnız Filtreli İşlem sekmesine aittir.');
  bot.log('daily', 'Hazır. Bu monitör yalnız Günlük PDF sekmesine aittir.');
  resumeIfNeeded(msg => bot.log('main', msg));
})();

try { setInterval(eysTryEmbedIntoMainPanel, 800); } catch (_) {}
