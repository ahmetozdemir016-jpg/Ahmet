v4.31.7 Bugün Butonu Düzeltme

Düzeltilen hata:
- Bugün butonuna tıklayınca gelen 'fmtDateYYYYMMDD is not defined' hatası giderildi.

Düzeltme:
- EYS dosyasına eysTodayYYYYMMDD() yardımcı fonksiyonu eklendi.
- Bugün butonu artık tarihi doğrudan YYYYMMDD formatında üretir.
