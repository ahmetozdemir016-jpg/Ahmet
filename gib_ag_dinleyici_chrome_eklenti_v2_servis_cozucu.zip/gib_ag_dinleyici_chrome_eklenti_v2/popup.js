
let logs = [];
let mask = true;
let currentFilter = 'all';

function $(id){ return document.getElementById(id); }

function esc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function cut(s,n){ s=String(s||''); return s.length>n ? s.slice(0,n)+' ...[kesildi]' : s; }
function maskText(s){
  s=String(s||'');
  if(!mask) return s;
  return s
    .replace(/(token=)[^&\s"']+/ig, '$1***TOKEN***')
    .replace(/("token"\s*:\s*")[^"]+/ig, '$1***TOKEN***')
    .replace(/(JSESSIONID=)[^;&\s"']+/ig, '$1***JSESSIONID***')
    .replace(/("password"\s*:\s*")[^"]+/ig, '$1***PASSWORD***')
    .replace(/("pin"\s*:\s*")[^"]+/ig, '$1***PIN***')
    .replace(/(password=)[^&\s"']+/ig, '$1***PASSWORD***')
    .replace(/(pin=)[^&\s"']+/ig, '$1***PIN***');
}

function parseQueryString(qs){
  const obj = {};
  String(qs||'').replace(/^\?/,'').split('&').forEach(p=>{
    if(!p) return;
    const i = p.indexOf('=');
    let k = i>=0 ? p.slice(0,i) : p;
    let v = i>=0 ? p.slice(i+1) : '';
    try{k = decodeURIComponent(k.replace(/\+/g,' '));}catch(e){}
    try{v = decodeURIComponent(v.replace(/\+/g,' '));}catch(e){}
    if(k) obj[k]=v;
  });
  return obj;
}
function serviceInfo(e){
  if(e.serviceInfo) return e.serviceInfo;
  const info = {cmd:'', jpRaw:'', jp:null, params:{}, serviceHint:''};
  try{
    const u = String(e.url||'');
    const qi = u.indexOf('?');
    const qu = parseQueryString(qi>=0 ? u.slice(qi+1) : '');
    const bo = parseQueryString(String(e.body||''));
    const all = {...qu, ...bo};
    info.params = all;
    info.cmd = all.cmd || all.CMD || '';
    info.jpRaw = all.jp || all.JP || all.json || all.JSON || '';
    if(info.jpRaw){
      try{ info.jp = JSON.parse(info.jpRaw); }catch(err){ info.jp = null; }
    }
    if(info.cmd){
      const m = String(info.cmd).match(/^([^_]+)_/);
      info.serviceHint = m ? m[1] : '';
    }
  }catch(err){}
  return info;
}
function prettyJson(x){
  try{return JSON.stringify(x, null, 2);}catch(e){return String(x||'');}
}

function typeOf(e){
  if(e.classType) return e.classType;
  const u = e.url || '';
  if(/dispatch/i.test(u)) return 'dispatch';
  if(/BEYANNAME|vdintra|pdf|goruntule|tahakkuk/i.test(u)) return 'beyan';
  if(/debugger/i.test(e.kind||'')) return 'debugger';
  return 'other';
}
function passFilter(e){
  if(currentFilter === 'all') return true;
  if(currentFilter === 'error') return !!e.error || (e.status && e.status >= 400);
  if(currentFilter === 'open') return /open|link/i.test(e.kind||'');
  if(currentFilter === 'service') { const si = serviceInfo(e); return !!(si.cmd || si.jpRaw); }
  if(currentFilter === 'debugger') return /debugger/i.test(e.kind||'');
  return typeOf(e) === currentFilter;
}
function render(){
  const box = $('logs');
  box.innerHTML = '';
  const filtered = logs.filter(passFilter).slice().reverse();
  filtered.forEach(e => {
    const div = document.createElement('div');
    div.className = 'log';
    const status = e.status ? ` | HTTP ${e.status}` : '';
    const dur = e.durationMs != null ? ` | ${e.durationMs} ms` : '';
    const mime = e.mimeType || e.contentType ? ` | ${esc(e.mimeType || e.contentType)}` : '';
    div.innerHTML =
      `<div class="top">#${esc(e.globalId || e.id || '')} | ${esc(e.createdAt || e.when || '')} | ${esc(e.kind || '')} | ${esc(e.method || '')}${status}${dur}${mime} | <span class="badge">${esc(typeOf(e))}</span></div>`+
      `<div class="url"><b>URL:</b> ${esc(maskText(e.url || ''))}</div>`+
      (() => { const si = serviceInfo(e); return (si.cmd || si.jpRaw) ? `<div style="margin-top:5px;color:#ffcf5a"><b>CMD:</b> ${esc(si.cmd || '')} ${si.serviceHint ? ' | <b>Servis:</b> '+esc(si.serviceHint) : ''}</div>` + (si.jp ? `<details open><summary>JP JSON / Sorgu Parametresi</summary><pre>${esc(maskText(prettyJson(si.jp)))}</pre></details>` : (si.jpRaw ? `<details open><summary>JP RAW</summary><pre>${esc(maskText(cut(si.jpRaw,7000)))}</pre></details>` : '')) : ''; })()+
      (e.body ? `<details><summary>Gönderilen veri</summary><pre>${esc(maskText(cut(e.body,7000)))}</pre></details>` : '')+
      (e.response ? `<details><summary>Yanıt önizleme</summary><pre>${esc(maskText(cut(e.response,12000)))}</pre></details>` : '')+
      (e.error ? `<div class="err">Hata: ${esc(e.error)}</div>` : '');
    box.appendChild(div);
  });
  updateStats();
}
function updateStats(){
  const dispatch = logs.filter(e => typeOf(e)==='dispatch').length;
  const beyan = logs.filter(e => typeOf(e)==='beyan').length;
  const dbg = logs.filter(e => /debugger/i.test(e.kind||'')).length;
  const svc = logs.filter(e => { const si = serviceInfo(e); return !!(si.cmd || si.jpRaw); }).length;
  const err = logs.filter(e => e.error || (e.status && e.status >= 400)).length;
  $('stats').textContent = `Toplam: ${logs.length} | Servis/CMD: ${svc} | Dispatch: ${dispatch} | Beyan/PDF: ${beyan} | Debugger: ${dbg} | Hata: ${err}`;
}
function loadLogs(){
  chrome.runtime.sendMessage({type:'GET_LOGS'}, res => {
    logs = res && res.logs ? res.logs : [];
    render();
  });
}
function downloadLogs(){
  const data = JSON.stringify(logs, null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({
    url,
    filename: 'gib-ag-dinleyici-log-' + new Date().toISOString().replace(/[:.]/g,'-') + '.json',
    saveAs: true
  }, () => setTimeout(()=>URL.revokeObjectURL(url), 2000));
}
function activeTabInfo(){
  chrome.tabs.query({active:true, currentWindow:true}, tabs => {
    const t = tabs && tabs[0];
    if(t) $('tabInfo').textContent = 'Sekme: ' + (t.title || t.url || '').slice(0,60);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  activeTabInfo();
  loadLogs();

  $('btnRefresh').onclick = loadLogs;
  $('btnClear').onclick = () => chrome.runtime.sendMessage({type:'CLEAR_LOGS'}, () => { logs=[]; render(); });
  $('btnDownload').onclick = downloadLogs;
  $('filter').onchange = e => { currentFilter = e.target.value; render(); };
  $('mask').onchange = e => { mask = e.target.checked; render(); };

  $('btnInject').onclick = () => chrome.runtime.sendMessage({type:'INJECT_CURRENT'}, res => {
    alert(res && res.ok ? 'Sayfaya enjekte edildi. Şimdi sorguyu yap.' : 'Enjekte edilemedi: ' + (res && res.error || 'bilinmeyen hata'));
    setTimeout(loadLogs, 500);
  });
  $('btnDbg').onclick = () => chrome.runtime.sendMessage({type:'START_DEBUGGER'}, res => {
    alert(res && res.ok ? 'Debugger başladı. Chrome uyarısı normaldir. Şimdi sorguyu/PDF açmayı yap.' : 'Debugger başlatılamadı: ' + (res && res.error || 'bilinmeyen hata'));
    setTimeout(loadLogs, 500);
  });
  $('btnDbgStop').onclick = () => chrome.runtime.sendMessage({type:'STOP_DEBUGGER'}, res => {
    alert(res && res.ok ? 'Debugger durduruldu.' : 'Debugger durdurulamadı: ' + (res && res.error || 'bilinmeyen hata'));
    setTimeout(loadLogs, 500);
  });

  setInterval(loadLogs, 1500);
});
