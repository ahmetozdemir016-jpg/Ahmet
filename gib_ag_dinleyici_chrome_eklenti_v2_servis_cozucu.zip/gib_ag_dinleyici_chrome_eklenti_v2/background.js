
const STATE = {
  logs: [],
  maxLogs: 1500,
  debuggerTabs: {},
  requestMap: {}
};

function classify(url){
  url = String(url || '');
  if (/dispatch/i.test(url)) return 'dispatch';
  if (/BEYANNAME|vdintra|pdf|goruntule|tahakkuk/i.test(url)) return 'beyan';
  if (/127\.0\.0\.1|localhost|2023/i.test(url)) return 'local-imza';
  return 'other';
}
function cut(s,n){ s=String(s || ''); return s.length > n ? s.slice(0,n) + ' ...[kesildi]' : s; }

function parseQueryString(qs){
  const obj = {};
  String(qs||'').replace(/^\?/,'').split('&').forEach(p=>{
    if(!p) return;
    const i = p.indexOf('=');
    let k = i>=0 ? p.slice(0,i) : p;
    let v = i>=0 ? p.slice(i+1) : '';
    try{k = decodeURIComponent(k.replace(/\+/g,' '));}catch(e){}
    try{v = decodeURIComponent(v.replace(/\+/g,' '));}catch(e){}
    if(k) obj[k]=v;
  });
  return obj;
}
function parseServiceInfo(url, body){
  const info = {cmd:'', jpRaw:'', jp:null, params:{}, serviceHint:''};
  try{
    const u = String(url||'');
    const qi = u.indexOf('?');
    const qu = parseQueryString(qi>=0 ? u.slice(qi+1) : '');
    const bo = parseQueryString(String(body||''));
    const all = {...qu, ...bo};
    info.params = all;
    info.cmd = all.cmd || all.CMD || '';
    info.jpRaw = all.jp || all.JP || all.json || all.JSON || '';
    if(info.jpRaw){
      try{ info.jp = JSON.parse(info.jpRaw); }catch(e){ info.jp = null; }
    }
    if(info.cmd){
      const m = String(info.cmd).match(/^([^_]+)_/);
      info.serviceHint = m ? m[1] : '';
    }
  }catch(e){}
  return info;
}

function addLog(entry){
  entry = entry || {};
  entry.globalId = Date.now() + '-' + Math.random().toString(36).slice(2,8);
  entry.createdAt = new Date().toISOString();
  entry.classType = entry.classType || classify(entry.url);
  entry.serviceInfo = entry.serviceInfo || parseServiceInfo(entry.url, entry.body);
  STATE.logs.push(entry);
  if(STATE.logs.length > STATE.maxLogs) STATE.logs.splice(0, STATE.logs.length - STATE.maxLogs);
  chrome.storage.local.set({logs: STATE.logs.slice(-500)}).catch(()=>{});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg) return;

  if(msg.type === 'PAGE_LOG'){
    const e = msg.entry || {};
    e.tabId = sender && sender.tab ? sender.tab.id : undefined;
    e.tabUrl = msg.url || (sender && sender.tab ? sender.tab.url : '');
    e.tabTitle = msg.title || (sender && sender.tab ? sender.tab.title : '');
    addLog(e);
    sendResponse({ok:true});
    return true;
  }

  if(msg.type === 'GET_LOGS'){
    sendResponse({ok:true, logs: STATE.logs});
    return true;
  }

  if(msg.type === 'CLEAR_LOGS'){
    STATE.logs = [];
    STATE.requestMap = {};
    chrome.storage.local.set({logs: []}).catch(()=>{});
    sendResponse({ok:true});
    return true;
  }

  if(msg.type === 'INJECT_CURRENT'){
    chrome.tabs.query({active:true, currentWindow:true}, async tabs => {
      try{
        const tab = tabs && tabs[0];
        if(!tab || !tab.id) return sendResponse({ok:false, error:'Aktif sekme bulunamadı.'});
        await chrome.scripting.executeScript({target:{tabId:tab.id, allFrames:true}, files:['content.js']});
        chrome.tabs.sendMessage(tab.id, {type:'INJECT_HOOK'}, () => {});
        sendResponse({ok:true});
      }catch(err){
        sendResponse({ok:false, error:String(err && err.message || err)});
      }
    });
    return true;
  }

  if(msg.type === 'START_DEBUGGER'){
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      const tab = tabs && tabs[0];
      if(!tab || !tab.id) return sendResponse({ok:false, error:'Aktif sekme bulunamadı.'});
      startDebugger(tab.id).then(() => sendResponse({ok:true, tabId:tab.id})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    });
    return true;
  }

  if(msg.type === 'STOP_DEBUGGER'){
    chrome.tabs.query({active:true, currentWindow:true}, tabs => {
      const tab = tabs && tabs[0];
      if(!tab || !tab.id) return sendResponse({ok:false, error:'Aktif sekme bulunamadı.'});
      stopDebugger(tab.id).then(() => sendResponse({ok:true})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    });
    return true;
  }
});

async function startDebugger(tabId){
  if(STATE.debuggerTabs[tabId]) return;
  await chrome.debugger.attach({tabId}, '1.3');
  STATE.debuggerTabs[tabId] = true;
  await chrome.debugger.sendCommand({tabId}, 'Network.enable', {maxResourceBufferSize: 1024*1024*20, maxTotalBufferSize: 1024*1024*50});
  addLog({kind:'debugger', method:'START', url:'tab:'+tabId, body:'Chrome debugger Network.enable aktif', tabId});
}
async function stopDebugger(tabId){
  if(!STATE.debuggerTabs[tabId]) return;
  try{ await chrome.debugger.detach({tabId}); }catch(e){}
  delete STATE.debuggerTabs[tabId];
  addLog({kind:'debugger', method:'STOP', url:'tab:'+tabId, body:'Chrome debugger durduruldu', tabId});
}

chrome.debugger.onEvent.addListener(async (source, method, params) => {
  if(!source || !source.tabId || !STATE.debuggerTabs[source.tabId]) return;
  const tabId = source.tabId;

  if(method === 'Network.requestWillBeSent'){
    const req = params.request || {};
    STATE.requestMap[params.requestId] = {
      tabId,
      requestId: params.requestId,
      kind: 'debugger.request',
      method: req.method,
      url: req.url,
      body: req.postData || '',
      startTs: Date.now(),
      resourceType: params.type
    };
    addLog({
      kind:'debugger.request',
      method:req.method,
      url:req.url,
      body:cut(req.postData || '', 12000),
      tabId,
      requestId: params.requestId,
      resourceType: params.type
    });
  }

  if(method === 'Network.responseReceived'){
    const resp = params.response || {};
    const prev = STATE.requestMap[params.requestId] || {};
    prev.status = resp.status;
    prev.mimeType = resp.mimeType;
    prev.responseUrl = resp.url;
    prev.resourceType = params.type;
    STATE.requestMap[params.requestId] = prev;
  }

  if(method === 'Network.loadingFinished'){
    const prev = STATE.requestMap[params.requestId];
    if(!prev) return;
    let bodyText = '';
    let base64Encoded = false;
    try{
      const body = await chrome.debugger.sendCommand({tabId}, 'Network.getResponseBody', {requestId: params.requestId});
      bodyText = body.body || '';
      base64Encoded = !!body.base64Encoded;
      if(base64Encoded){
        bodyText = '[base64 response, ilk 12000 karakter]\n' + bodyText.slice(0,12000);
      }
    }catch(e){
      bodyText = '[response body alınamadı: '+String(e && e.message || e)+']';
    }
    addLog({
      kind:'debugger.response',
      method:prev.method,
      url:prev.responseUrl || prev.url,
      body:cut(prev.body || '', 12000),
      response:cut(bodyText, 20000),
      status:prev.status,
      mimeType:prev.mimeType,
      durationMs:Date.now()-(prev.startTs||Date.now()),
      tabId,
      requestId: params.requestId,
      resourceType: prev.resourceType,
      base64Encoded
    });
    delete STATE.requestMap[params.requestId];
  }

  if(method === 'Network.loadingFailed'){
    const prev = STATE.requestMap[params.requestId] || {};
    addLog({
      kind:'debugger.error',
      method:prev.method || '',
      url:prev.url || '',
      error:params.errorText || 'loadingFailed',
      tabId,
      requestId: params.requestId
    });
    delete STATE.requestMap[params.requestId];
  }
});

chrome.debugger.onDetach.addListener((source, reason) => {
  if(source && source.tabId) {
    delete STATE.debuggerTabs[source.tabId];
    addLog({kind:'debugger', method:'DETACH', url:'tab:'+source.tabId, body:'Debugger ayrıldı: '+reason, tabId:source.tabId});
  }
});

// Pasif webRequest metadata. Response body vermez, ama doğrudan PDF / navigation URL'lerini yakalar.
chrome.webRequest.onBeforeRequest.addListener(
  details => {
    if(details.tabId < 0) return;
    if(/dispatch|BEYANNAME|vdintra|pdf|goruntule|tahakkuk/i.test(details.url)){
      addLog({
        kind:'webRequest.before',
        method:details.method,
        url:details.url,
        tabId:details.tabId,
        requestId:details.requestId,
        resourceType:details.type
      });
    }
  },
  {urls:["http://*/*", "https://*/*"]},
  ["requestBody"]
);

chrome.webRequest.onCompleted.addListener(
  details => {
    if(details.tabId < 0) return;
    if(/dispatch|BEYANNAME|vdintra|pdf|goruntule|tahakkuk/i.test(details.url)){
      addLog({
        kind:'webRequest.completed',
        method:details.method,
        url:details.url,
        status:details.statusCode,
        tabId:details.tabId,
        requestId:details.requestId,
        resourceType:details.type
      });
    }
  },
  {urls:["http://*/*", "https://*/*"]}
);

chrome.runtime.onInstalled.addListener(async () => {
  const old = await chrome.storage.local.get('logs');
  STATE.logs = old.logs || [];
});
