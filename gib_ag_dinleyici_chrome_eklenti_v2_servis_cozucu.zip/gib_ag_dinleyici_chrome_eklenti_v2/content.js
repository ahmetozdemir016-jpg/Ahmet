
(function(){
  if (window.__GIB_DINLEYICI_CONTENT_ACTIVE__) return;
  window.__GIB_DINLEYICI_CONTENT_ACTIVE__ = true;

  function inject(){
    try{
      var s = document.createElement('script');
      s.src = chrome.runtime.getURL('page_hook.js');
      s.onload = function(){ this.remove(); };
      (document.documentElement || document.head || document.body).appendChild(s);
    }catch(e){}
  }

  window.addEventListener('message', function(event){
    if(event.source !== window) return;
    var msg = event.data;
    if(!msg || msg.source !== 'GIB_DINLEYICI_PAGE') return;
    chrome.runtime.sendMessage({
      type: 'PAGE_LOG',
      entry: msg.entry || {},
      url: location.href,
      title: document.title
    });
  });

  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
    if(!msg) return;
    if(msg.type === 'INJECT_HOOK'){
      inject();
      sendResponse({ok:true});
    }
  });

  inject();
})();
