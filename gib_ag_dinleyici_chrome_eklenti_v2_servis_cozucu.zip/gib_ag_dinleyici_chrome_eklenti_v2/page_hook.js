
(function(){
  if(window.__GIB_DINLEYICI_PAGE_HOOK_ACTIVE__) return;
  window.__GIB_DINLEYICI_PAGE_HOOK_ACTIVE__ = true;

  var seq = 0;

  function safeStr(v){
    try{
      if(v == null) return '';
      if(typeof v === 'string') return v;
      if(v instanceof FormData){
        var arr=[]; v.forEach(function(val,key){ arr.push(key+'='+(val && val.name ? '[FILE:'+val.name+']' : String(val))); });
        return arr.join('&');
      }
      if(v instanceof URLSearchParams) return v.toString();
      if(v instanceof Blob) return '[Blob '+v.type+' '+v.size+' bytes]';
      if(v instanceof ArrayBuffer) return '[ArrayBuffer '+v.byteLength+' bytes]';
      return JSON.stringify(v);
    }catch(e){ return String(v); }
  }
  function cut(s,n){ s=String(s||''); return s.length>n ? s.slice(0,n)+' ...[kesildi]' : s; }
  function classify(url){
    url=String(url||'');
    if(/dispatch/i.test(url)) return 'dispatch';
    if(/BEYANNAME|vdintra|pdf|goruntule|tahakkuk/i.test(url)) return 'beyan';
    if(/127\.0\.0\.1|localhost|2023/i.test(url)) return 'local-imza';
    return 'other';
  }
  
  function parseQueryString(qs){
    var obj={};
    String(qs||'').replace(/^\?/,'').split('&').forEach(function(p){
      if(!p)return;
      var i=p.indexOf('=');
      var k=i>=0?p.slice(0,i):p;
      var v=i>=0?p.slice(i+1):'';
      try{k=decodeURIComponent(k.replace(/\+/g,' '));}catch(e){}
      try{v=decodeURIComponent(v.replace(/\+/g,' '));}catch(e){}
      if(k)obj[k]=v;
    });
    return obj;
  }
  function parseServiceInfo(url, body){
    var info={cmd:'', jpRaw:'', jp:null, params:{}, serviceHint:''};
    try{
      var u=String(url||'');
      var q='';
      var qi=u.indexOf('?');
      if(qi>=0) q=u.slice(qi+1);
      var qu=parseQueryString(q);
      var bo=parseQueryString(String(body||''));
      var all={};
      Object.keys(qu).forEach(function(k){all[k]=qu[k];});
      Object.keys(bo).forEach(function(k){all[k]=bo[k];});
      info.params=all;
      info.cmd=all.cmd || all.CMD || '';
      info.jpRaw=all.jp || all.JP || all.json || all.JSON || '';
      if(info.jpRaw){
        try{ info.jp=JSON.parse(info.jpRaw); }catch(e){ info.jp=null; }
      }
      if(info.cmd){
        var m=String(info.cmd).match(/^([^_]+)_/);
        info.serviceHint=m?m[1]:'';
      }
      if(!info.cmd){
        var m2=u.match(/[?&]cmd=([^&]+)/i);
        if(m2){ try{info.cmd=decodeURIComponent(m2[1]);}catch(e){info.cmd=m2[1];} }
      }
    }catch(e){}
    return info;
  }
  function logServiceToConsole(entry){
    try{
      var si=entry.serviceInfo || parseServiceInfo(entry.url, entry.body);
      if(!si.cmd && !si.jpRaw && !/dispatch|vdintra|BEYANNAME|pdf/i.test(entry.url||'')) return;
      var title='🛰️ GİB SERVİS: '+(si.cmd || entry.method || entry.kind || 'URL');
      console.groupCollapsed(title);
      console.log('URL:', entry.url);
      console.log('Metod:', entry.method, 'Tür:', entry.kind, 'HTTP:', entry.status);
      if(si.cmd) console.log('CMD:', si.cmd);
      if(si.serviceHint) console.log('Servis ipucu:', si.serviceHint);
      if(si.jp) console.log('JP JSON:', si.jp);
      else if(si.jpRaw) console.log('JP RAW:', si.jpRaw);
      if(entry.body) console.log('Gönderilen veri:', entry.body);
      if(entry.response) console.log('Yanıt önizleme:', entry.response);
      console.groupEnd();
    }catch(e){}
  }

function send(entry){
    entry.id = ++seq;
    entry.when = new Date().toISOString();
    entry.pageUrl = location.href;
    entry.kind = entry.kind || 'page';
    entry.classType = entry.classType || classify(entry.url);
    entry.serviceInfo = parseServiceInfo(entry.url, entry.body);
    logServiceToConsole(entry);
    window.postMessage({source:'GIB_DINLEYICI_PAGE', entry:entry}, '*');
  }

  if(window.fetch && !window.fetch.__gibDinleyici){
    var origFetch = window.fetch;
    var hookedFetch = function(input, init){
      var url = (typeof input === 'string') ? input : (input && input.url) || '';
      var method = (init && init.method) || (input && input.method) || 'GET';
      var body = init && init.body ? safeStr(init.body) : '';
      var t0 = Date.now();
      return origFetch.apply(this, arguments).then(function(resp){
        var clone = resp.clone();
        var entry = {
          kind:'fetch',
          method:method,
          url:String(url),
          body:cut(body,10000),
          status:resp.status,
          durationMs:Date.now()-t0
        };
        var ct = resp.headers && resp.headers.get ? (resp.headers.get('content-type') || '') : '';
        entry.contentType = ct;
        if(/json|text|html|xml|javascript/i.test(ct)){
          clone.text().then(function(txt){
            entry.response = cut(txt,15000);
            send(entry);
          }).catch(function(){ send(entry); });
        }else{
          entry.response = '[binary/other content-type: '+ct+']';
          send(entry);
        }
        return resp;
      }).catch(function(err){
        send({kind:'fetch', method:method, url:String(url), body:cut(body,10000), error:String(err), durationMs:Date.now()-t0});
        throw err;
      });
    };
    hookedFetch.__gibDinleyici = true;
    window.fetch = hookedFetch;
  }

  if(window.XMLHttpRequest && !window.XMLHttpRequest.prototype.__gibDinleyici){
    var XHR = window.XMLHttpRequest;
    var origOpen = XHR.prototype.open;
    var origSend = XHR.prototype.send;
    XHR.prototype.open = function(method, url){
      this.__gibDin = {method:method, url:String(url), start:0};
      return origOpen.apply(this, arguments);
    };
    XHR.prototype.send = function(body){
      var xhr = this;
      var meta = xhr.__gibDin || {};
      meta.body = safeStr(body);
      meta.start = Date.now();
      function done(){
        try{
          var response = '';
          try{ response = xhr.responseType && xhr.responseType !== 'text' ? '[responseType '+xhr.responseType+']' : xhr.responseText; }
          catch(e){ response = '[responseText okunamadı]'; }
          send({
            kind:'xhr',
            method:meta.method||'',
            url:meta.url||'',
            body:cut(meta.body,10000),
            status:xhr.status,
            durationMs:Date.now()-meta.start,
            response:cut(response,15000)
          });
        }catch(e){}
      }
      xhr.addEventListener('load', done);
      xhr.addEventListener('error', function(){
        send({kind:'xhr', method:meta.method, url:meta.url, body:cut(meta.body,10000), error:'XHR error', durationMs:Date.now()-meta.start});
      });
      xhr.addEventListener('abort', function(){
        send({kind:'xhr', method:meta.method, url:meta.url, body:cut(meta.body,10000), error:'XHR abort', durationMs:Date.now()-meta.start});
      });
      return origSend.apply(this, arguments);
    };
    XHR.prototype.__gibDinleyici = true;
  }

  if(window.open && !window.open.__gibDinleyici){
    var origOpenWin = window.open;
    var openHook = function(url, name, features){
      send({kind:'window.open', method:'OPEN', url:String(url||''), body:'name='+safeStr(name)+' features='+safeStr(features)});
      return origOpenWin.apply(window, arguments);
    };
    openHook.__gibDinleyici = true;
    window.open = openHook;
  }

  document.addEventListener('submit', function(ev){
    try{
      var f = ev.target;
      var fd = new FormData(f);
      send({kind:'form.submit', method:(f.method||'GET').toUpperCase(), url:f.action||location.href, body:safeStr(fd)});
    }catch(e){}
  }, true);

  document.addEventListener('click', function(ev){
    var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
    if(a){
      send({kind:'link.click', method:'CLICK', url:a.href, body:'text='+cut((a.textContent||'').trim(),500)});
    }
  }, true);

  if(navigator.sendBeacon && !navigator.sendBeacon.__gibDinleyici){
    var origBeacon = navigator.sendBeacon.bind(navigator);
    var beaconHook = function(url, data){
      send({kind:'sendBeacon', method:'BEACON', url:String(url||''), body:safeStr(data)});
      return origBeacon(url, data);
    };
    beaconHook.__gibDinleyici = true;
    navigator.sendBeacon = beaconHook;
  }

  send({kind:'listener', method:'START', url:location.href, body:'Page hook aktif'});
})();
