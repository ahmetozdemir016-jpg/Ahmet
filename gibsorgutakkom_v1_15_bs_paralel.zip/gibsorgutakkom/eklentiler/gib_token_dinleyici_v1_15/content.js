
(function(){
  if(window.__TAKKOM_TOKEN_ONLY_CONTENT__) return;
  window.__TAKKOM_TOKEN_ONLY_CONTENT__ = true;

  function canReplyToPage(){
    try{
      const href = location.href || '';
      return location.protocol === 'file:' || /gibsorgutakkom|takdire-sevk|takkom|10\.251\.63\.99/i.test(href);
    }catch(e){ return false; }
  }

  function tokenFromCache(cache, mod){
    try{
      cache = cache || {};
      mod = String(mod||'').toLowerCase();
      var aliases = {
        gibintranet:['gibintranet','g','gibIntranet','gib_intranet'],
        keys:['keys','gp','key','keysToken','gpToken'],
        evdbrapor:['evdbrapor','evdo','evdb','evdbRapor','evdbRaporToken','evdorapor','evdoRapor'],
        izah:['izah','izahaDavet','smiyb','izahServer','izahToken'],
        istakip:['istakip','isTakip'],
        eys:['eys','e','edenetis'],
        ebeyan:['ebeyan','ebyn','vdintra']
      }[mod] || [mod];
      for(var i=0;i<aliases.length;i++){
        var a=aliases[i];
        if(cache.tokensByModule && cache.tokensByModule[a]) return cache.tokensByModule[a];
        if(cache.tokens && cache.tokens[a]){
          if(typeof cache.tokens[a] === 'string') return cache.tokens[a];
          if(cache.tokens[a].token) return cache.tokens[a].token;
        }
        if(cache[a]){
          if(typeof cache[a] === 'string') return cache[a];
          if(cache[a].token) return cache[a].token;
        }
      }
    }catch(e){}
    return '';
  }
  function syncCacheToPageLocalStorage(cache){
    try{
      if(!cache || typeof cache !== 'object') return;
      localStorage.setItem('takkom_token_cache_v1', JSON.stringify(cache));
      var map = {
        gibintranet:['gib_token_gibintranet','takkom_gibintranet_token','gibIntranetToken'],
        keys:['gib_token_keys','takkom_keys_token','keysToken','gpToken'],
        evdbrapor:['gib_token_evdbrapor','takkom_evdbrapor_token','evdbRaporToken','evdoRaporToken'],
        izah:['gib_token_izah','takkom_izah_token','izahToken','izahaDavetToken','smiybToken'],
        istakip:['gib_token_istakip','takkom_istakip_token'],
        eys:['gib_token_eys','takkom_eys_token'],
        ebeyan:['gib_token_ebeyan','takkom_ebeyan_token']
      };
      Object.keys(map).forEach(function(mod){
        var t=tokenFromCache(cache, mod);
        if(t){ map[mod].forEach(function(k){ try{ localStorage.setItem(k,t); }catch(e){} }); }
      });
      var g=tokenFromCache(cache,'gibintranet');
      if(g){
        localStorage.setItem('gibToken','token='+g);
      }
    }catch(e){}
  }

  function syncCapturesToPageLocalStorage(captures){
    try{
      if(!Array.isArray(captures)) return;
      var KEY='takkom_keys_capture_v1';
      var tryWrite=function(arr){
        try{ localStorage.setItem(KEY, JSON.stringify(arr)); return true; }catch(e){ return false; }
      };
      if(tryWrite(captures)) return;
      var sizes=[220,150,100,60,30,15];
      for(var i=0;i<sizes.length;i++){
        if(captures.length>sizes[i] && tryWrite(captures.slice(-sizes[i]))) return;
      }
      var slim=captures.slice(-60).map(function(c){
        var o={};
        for(var k in c){ if(Object.prototype.hasOwnProperty.call(c,k)) o[k]=c[k]; }
        if(typeof o.responseText==='string' && o.responseText.length>20000) o.responseText=o.responseText.slice(0,20000);
        return o;
      });
      if(tryWrite(slim)) return;
      tryWrite(captures.slice(-10));
    }catch(e){}
  }
  function requestCapturesAndSync(){
    try{
      chrome.runtime.sendMessage({type:'GET_CAPTURES'}, function(resp){
        try{ if(resp && resp.ok) syncCapturesToPageLocalStorage(resp.captures || []); }catch(e){}
      });
    }catch(e){}
  }

  function requestAndSync(){
    try{
      chrome.runtime.sendMessage({type:'GET_TOKENS'}, function(resp){
        try{
          if(resp && resp.ok && resp.cache){ syncCacheToPageLocalStorage(resp.cache); }
        }catch(e){}
      });
    }catch(e){}
  }

  function inject(){
    try{
      if(location.protocol === 'file:') return;
      if(!/10\.251\.63\.99|arkaofis\.gelbim\.gov\.tr|keys\.ggm|ggm\.gov\.tr/i.test(location.href)) return;
      const s = document.createElement('script');
      s.src = chrome.runtime.getURL('page_hook.js');
      s.onload = function(){ this.remove(); };
      (document.documentElement || document.head || document.body).appendChild(s);
    }catch(e){}
  }

  window.addEventListener('message', function(event){
    if(event.source !== window) return;
    const msg = event.data || {};
    if(msg.source === 'TAKKOM_KEYS_CAPTURE_PAGE'){
      chrome.runtime.sendMessage({type:'KEYS_CAPTURE', payload: msg.payload || {}}, function(resp){
        try{ if(resp && resp.ok) syncCapturesToPageLocalStorage(resp.captures || []); }catch(e){}
      });
      return;
    }
    if(msg.source === 'TAKKOM_TOKEN_ONLY_META_PAGE'){
      chrome.runtime.sendMessage({type:'TOKEN_ONLY_META', payload: msg.payload || {}}, function(){});
      return;
    }
    if(msg.source === 'TAKKOM_TOKEN_ONLY_PAGE'){
      chrome.runtime.sendMessage({type:'TOKEN_ONLY_CAPTURE', payload: msg.payload || {}}, function(){});
      return;
    }
    if(msg.type === 'TAKKOM_TCMB_BRIDGE_PING'){
      if(!canReplyToPage()) return;
      window.postMessage({type:'TAKKOM_TCMB_BRIDGE_READY', version:'1.14.0'}, '*');
      return;
    }
    if(msg.type === 'TAKKOM_TCMB_FETCH_REQUEST'){
      if(!canReplyToPage()) return;
      const requestId = String(msg.requestId || '');
      chrome.runtime.sendMessage({type:'TCMB_FETCH_XML', url:String(msg.url || '')}, function(resp){
        try{
          window.postMessage({
            type:'TAKKOM_TCMB_FETCH_RESPONSE',
            requestId:requestId,
            ok:!!(resp && resp.ok),
            status:(resp && resp.status) || 0,
            kind:(resp && resp.kind) || '',
            text:(resp && resp.text) || '',
            error:(resp && resp.error) || '',
            url:(resp && resp.url) || String(msg.url || '')
          }, '*');
        }catch(e){}
      });
      return;
    }
    if(msg.type === 'TAKKOM_CAPTURE_REQUEST'){
      if(!canReplyToPage()) return;
      chrome.runtime.sendMessage({type:'GET_CAPTURES'}, function(resp){
        try{
          if(resp && resp.ok) syncCapturesToPageLocalStorage(resp.captures || []);
          window.postMessage({type:'TAKKOM_CAPTURE_RESPONSE', ok:!!(resp && resp.ok), captures:(resp && resp.captures)||[], error:(resp && resp.error)||''}, '*');
        }catch(e){}
      });
      return;
    }
    if(msg.type === 'TAKKOM_TOKEN_REQUEST'){
      if(!canReplyToPage()) return;
      chrome.runtime.sendMessage({type:'GET_TOKENS'}, function(resp){
        try{
          if(resp && resp.ok && resp.cache){ syncCacheToPageLocalStorage(resp.cache); }
          window.postMessage({type:'TAKKOM_TOKEN_RESPONSE', ok:!!(resp && resp.ok), cache:(resp && resp.cache)||{}, error:(resp && resp.error)||''}, '*');
        }catch(e){}
      });
    }
  });

  try {
    chrome.storage.onChanged.addListener(function(changes, area){
      if(area !== 'local') return;
      try {
        if(changes['takkom_token_cache_v1'] && changes['takkom_token_cache_v1'].newValue){
          syncCacheToPageLocalStorage(changes['takkom_token_cache_v1'].newValue);
        }
        if(changes['takkom_keys_capture_v1'] && changes['takkom_keys_capture_v1'].newValue){
          syncCapturesToPageLocalStorage(changes['takkom_keys_capture_v1'].newValue);
        }
      } catch(e){}
    });
  } catch(e){}

  inject();
  requestAndSync();
  requestCapturesAndSync();
  setTimeout(requestAndSync, 500);
  setTimeout(requestCapturesAndSync, 700);
  setTimeout(requestAndSync, 2000);
  setTimeout(requestCapturesAndSync, 2500);
  try{ window.postMessage({type:'TAKKOM_TCMB_BRIDGE_READY', version:'1.14.0'}, '*'); }catch(e){}
})();
