İş Takip + EYS Botu v4.31.5
- Tarama tablosunda 'Akış OID' sütunu kaldırıldı.
- Yerine 'Belge Bilgi' sütunu eklendi.
- Bu sütunda `is_kaynakbilgi` / `kaynakEkBilgiler` içindeki belge bilgi metni gösterilir.
- Uzun belge bilgi metinleri hücre içinde satıra kırılır.


v4_27_8 notu:
- Önizleme tokeni istakip tokeni değil, ilk giriş oturumu (gp/keys) tokeni önceliklidir.
- external_dispatch payload alanı evrakVersiyonOid olarak gönderilir.
- Flexpaper linki fileID üzerinden '.pdf#navpanes=0' mantığıyla üretilir.


Bu sürümde önizleme linki external_dispatch cevabından fileID ile şu formatta üretilir:
/keyss/flexpaper/pdf/?token=<keysToken>&fileID=<fileID>.pdf#navpanes=0
