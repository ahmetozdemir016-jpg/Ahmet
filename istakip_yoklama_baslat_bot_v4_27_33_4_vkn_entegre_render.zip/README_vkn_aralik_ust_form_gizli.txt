Bu sürümde token/keşif ekranları geri getirildi.
İŞLERİ TARA üstündeki form alanları gizlendi.
Yeni VKN Başlangıç / VKN Bitiş alanları eklendi.
Tarama sonrası listede İşTakip sütununda ikinci satırdaki vergi no/tc no bu aralıkta ise satır gösterilir.
İki alan da boşsa tüm işler görünür.
