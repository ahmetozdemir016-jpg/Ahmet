Bu sürümde VKN aralık filtresi doğrudan tabloda görünen satırlar üzerinden uygulanır.
İşTakip sütununda ikinci satırdaki 10 haneli VKN okunur ve başlangıç/bitiş aralığına göre satır gizlenir/gösterilir.
Tarama sonrası satırlar yeniden çizilse bile MutationObserver ile filtre tekrar uygulanır.
Üstteki token ekranları görünür kalır, buton üstündeki eski form satırları gizlenir.
