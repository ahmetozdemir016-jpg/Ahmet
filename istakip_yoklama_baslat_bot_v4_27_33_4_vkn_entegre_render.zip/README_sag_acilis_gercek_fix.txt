Bu sürümde ana panelin gerçek başlangıç konumu sağ üst olarak düzeltildi.
Önceki sürümde solda açılmasına neden olan left/top değerleri temizlendi.
