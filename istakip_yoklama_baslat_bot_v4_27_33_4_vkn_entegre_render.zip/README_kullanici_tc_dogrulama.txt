Bu sürümde 'Keşfedilen Kullanıcı' alanı sadece 11 haneli TCKN ise gösterilir. Uygun değilse boş bırakılır.
