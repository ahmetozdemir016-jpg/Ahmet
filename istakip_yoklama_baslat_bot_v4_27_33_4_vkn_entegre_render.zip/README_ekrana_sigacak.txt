Bu sürümde ana panel ekran yüksekliğine göre otomatik sığdırılır. Alt kısmı ekran dışında kalmaz; iç gövde kendi içinde scroll olur.
