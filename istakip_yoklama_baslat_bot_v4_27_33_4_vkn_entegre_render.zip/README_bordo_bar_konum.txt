Bu sürümde panel başlangıçta ve küçültülünce üst uygulama simgelerinin üzerine gelmesin diye bordo bar hizasına alınmıştır.
Küçük halde sağ üstte ama biraz aşağıda durur. Tekrar açılınca eski yerine döner.
