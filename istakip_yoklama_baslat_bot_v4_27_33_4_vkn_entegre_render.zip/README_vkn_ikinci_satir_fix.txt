Bu sürümde VKN filtrelemesi sadece İşTakip sütunundaki ikinci satıra göre yapılır.
Birinci satır iş takip no, ikinci satır VKN, üçüncü satır varsa TCKN kabul edilir.
VKN Başlangıç/Bitiş aralığı bu ikinci satırdaki VKN değerine uygulanır.
İşleri Tara üstündeki eski form satırları gizlenir; token ekranları görünür kalır.
