Bu sürümde panel küçültülünce üstteki uygulama simgelerini kapatmasın diye sağ alt köşeye taşınır. Tekrar açılınca eski yerine döner.
