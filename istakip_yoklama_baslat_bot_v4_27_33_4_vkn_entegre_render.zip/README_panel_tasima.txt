Bu sürümde ana panel taşıma mantığı pointer/mouse olarak güçlendirildi. Başlıktan sürükleyerek taşıyabilirsin.
