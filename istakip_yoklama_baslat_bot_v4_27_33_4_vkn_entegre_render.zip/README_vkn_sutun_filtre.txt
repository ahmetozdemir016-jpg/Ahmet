Bu sürümde VKN/TCKN filtresi sadece İşTakip sütunundaki ikinci satırdaki vergi no / tc no değerine göre çalışır.
Vergi No / TCKN / Ünvan alanı boşsa tüm işler görünür.
Alan doluysa sadece eşleşen işlerin tüm satır bilgileri gösterilir.
