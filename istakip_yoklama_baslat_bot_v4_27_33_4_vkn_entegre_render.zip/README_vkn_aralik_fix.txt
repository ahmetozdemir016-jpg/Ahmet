Bu sürümde İşleri Tara butonunun üstündeki form satırları gerçekten gizlendi.
VKN Başlangıç ve VKN Bitiş alanları eklendi.
Tarama sonrası tablo, İşTakip sütunundaki ikinci satırdaki vergi no / tc no değerine göre aralık filtresi uygular.
Örnek: başlangıç 0000000000, bitiş 3000000000.
