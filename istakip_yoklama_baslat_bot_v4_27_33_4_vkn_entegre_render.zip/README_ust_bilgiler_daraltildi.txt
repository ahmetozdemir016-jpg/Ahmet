Bu sürümde üstteki seçili/keşfedilen bilgi alanları daha az yer kaplayacak şekilde daraltıldı.
Uzun token ve kaynak metinleri tek satıra indirildi; aşağı kaydırarak diğer alanlara bakılabilir.
