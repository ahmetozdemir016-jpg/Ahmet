Bu sürümde:
- Ana bot paneli sürüklenebilir
- Ana bot paneli köşeden büyütülüp küçültülebilir
- Önizleme penceresi sürüklenebilir
- Önizleme penceresi köşeden büyütülüp küçültülebilir
- Önizleme başlığında küçült ve sıfırla butonları eklendi
- İleride yoklama ekranı ile önizleme aynı anda yan yana kullanılabilsin diye iki pencere de serbest taşınabilir hale getirildi
