Bu sürümde VKN aralık filtresi doğrudan tablo satırlarında İşTakip hücresindeki ilk 10 haneli sayıyı VKN kabul ederek uygulanır.
İşleri Tara üstündeki eski form satırları gizlenir.
VKN Başlangıç/VKN Bitiş alanları yoksa otomatik eklenir.
Tarama ve yenileme sonrası filtre yeniden uygulanır.
