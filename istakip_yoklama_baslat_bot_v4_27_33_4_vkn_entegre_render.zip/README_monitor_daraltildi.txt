Bu sürümde yeşil işlem monitörü alanı yaklaşık yarı yüksekliğe düşürüldü. İşleri Tara satırı üstte kalacak şekilde ayarlandı.
