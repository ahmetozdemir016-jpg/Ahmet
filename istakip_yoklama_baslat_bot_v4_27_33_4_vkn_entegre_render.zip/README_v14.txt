Bu sürümde ana panel başlık seviyesine kadar küçülür ve başlıktan sürüklenerek taşınır.
