Bu sürümde content.js içindeki syntax hatası düzeltildi. İşTakip başlığındaki filtre kutusunun konumlandırma kodunda kalan hatalı ifade temizlendi.
