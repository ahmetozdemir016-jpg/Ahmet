Bu sürümde VKN Başlangıç/VKN Bitiş alanları üstte değil, işler tablosunda İşTakip başlığına tıklanınca açılan küçük filtre kutusunda yer alır.
Kutular 10 haneden fazla giriş kabul etmez.
Aralık yazınca sadece o aralıktaki VKN'ye sahip satırlar görünür.
