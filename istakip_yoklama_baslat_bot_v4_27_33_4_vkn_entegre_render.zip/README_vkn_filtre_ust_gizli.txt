Bu sürümde üstteki keşfedilen/seçili bilgi kutuları gizlendi.
Vergi No / TCKN / Ünvan alanına sayı girilmişse, tarama sonrası alttaki listede sadece o VKN/TCKN ile ilgili satırlar gösterilir.
