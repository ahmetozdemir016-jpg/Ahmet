Bu sürümde panel başlangıçta biraz daha aşağıda, kırmızı bordo alan hizasında açılır.
