Bu sürümde ana panel sağ üstte açılır. Küçültülünce sadece ince başlık satırı kalır. Başlık yüksekliği daraltıldı.
