Bu sürümde gerçek selectorlar üzerinden düzeltme yapıldı.
Yeşil monitör alanı 82px'e indirildi.
İşler tablosu alanı büyütüldü ve başlık satırı sabitlendi.
Üst bilgi kutuları küçültülüp scroll yapılabilir hale getirildi.
