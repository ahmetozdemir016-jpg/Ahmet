Bu sürümde önizleme akışı şu mantıkla sabitlendi:

1) Önizle butonuna basılır.
2) external_dispatch / evrakOrtakServis_evrakOnizle çağrısı yapılır.
3) Bu çağrıda ilk giriş oturumu tokeni kullanılır.
4) Cevaptan fileID / uuid / dosyaId benzeri alanlar alınır.
5) Son flexpaper/pdf linki oluşturulurken de yine aynı ilk giriş oturumu tokeni kullanılır.
6) Üretilen link modal içindeki önizleme penceresinde açılır.

Not:
- İş takip akış tokeni değil, ilk giriş tokeni esas alınmalıdır.
- Son linkte de aynı ilk giriş tokeni kullanılmalıdır.
