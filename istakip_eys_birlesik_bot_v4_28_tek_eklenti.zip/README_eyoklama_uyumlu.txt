Bu sürümde yoklama sorguları EYS Tam Bot Full eklentisindeki yapıya göre düzeltildi.
- cmd: srvcYoklama_getYoklamalar
- endpoint: http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch
- jp: { data:{...}, sessionData }
- bastar: bugünden 6 ay önce, bittar: bugün
- PDF: /edenetis/getSonuc?yKodu=...
