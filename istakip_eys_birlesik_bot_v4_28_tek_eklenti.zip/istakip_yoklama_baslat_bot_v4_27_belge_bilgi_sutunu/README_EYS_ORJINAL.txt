Chrome eklentisi kullanımı

1. Bu klasörü bilgisayarına çıkar.
2. Chrome adres satırına şunu yaz:
   chrome://extensions
3. Sağ üstten Geliştirici modu'nu aç.
4. Paketlenmemiş öğe yükle'ye bas.
5. Bu klasörü seç.
6. GİB sayfasını yenile.

Özellikler:
- AKIŞI BAŞLAT: memur oturumu açar, listeyi çeker, müdüre gönderir; sonra müdür oturumu açar, onay bekleyenleri koordinatöre yollar; 5 dakikada bir tekrar eder.
- MEMUR REFRESH AÇ / MÜDÜR REFRESH AÇ: sayfayı yenileyip rol popupını otomatik açar ve ilgili ekranı yükler.
