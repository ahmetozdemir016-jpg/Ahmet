İş Takip + EYS Birleşik Bot v4.28

Kurulum:
1. ZIP dosyasını klasöre çıkar.
2. Chrome adres satırına chrome://extensions yaz.
3. Geliştirici modu aç.
4. Paketlenmemiş öğe yükle ile bu klasörü seç.
5. GİB / İş Takip / EYS sayfalarını yenile.

İçerik:
- İş Takip modülü:
  - İşleri Tara
  - VKN filtre
  - Evrak Önizleme
  - Yoklama durum/kod sorgusu
  - Yoklama koduna tıklayınca PDF açma
  - İşTakip hücresinde gerçek akış seçeneklerini gösterme

- EYS modülü:
  - Memur oturumu ile liste çekme
  - Memurdan müdüre gönderme
  - Müdür oturumu ile onay bekleyenleri çekme
  - Müdürden koordinatöre gönderme
  - 5 dakikada bir tekrar döngüsü
  - Filtreli işlem / arşiv / işlem yapıldı
  - Günlük PDF açma/yazdırma akışı

Not:
Bu paket iki ayrı paneli tek Chrome eklentisinde toplar. İş Takip paneli İş Takip ekranında, EYS paneli EYS/e-Yoklama ekranında görünür.
