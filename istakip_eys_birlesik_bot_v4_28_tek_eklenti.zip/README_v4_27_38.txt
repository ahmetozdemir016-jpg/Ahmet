1) İşTakip hücresinin üzerine gelince işlem seçenekleri menüsü açılır.
2) Yoklama sorgusu başlangıç tarihi işin geliş/kaynak/talep tarihinden alınır; bulunamazsa 6 ay önce kullanılır.
3) Yoklama sorgusu bitiş tarihi bugündür.
