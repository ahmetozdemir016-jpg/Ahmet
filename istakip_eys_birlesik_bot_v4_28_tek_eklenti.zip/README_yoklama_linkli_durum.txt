Bu sürümde yoklama PDF iframe/modal içinde açılmaz; X-Frame-Options engeline takılmamak için yoklama kodu link olarak yeni sekmede açılır.
Yoklama Durum sütununda birden fazla yoklama varsa her birinin son durumu ayrı satır gösterilir.
Yoklama Kodu sütununda her kod tıklanabilir linktir ve /edenetis/getSonuc?yKodu=... yeni sekmede açılır.
