Bu sürümde İşTakip hücresi üzerine gelince seçenekler statik değil, gerçek servisle alınır.
Kullanılan istek: akisIslemleri_isTakipSonrakiAdimlariBul
Payload: { orgoid, akisOid }
Response: data.hedefAdimlar menüye basılır.
Seçenek tıklanınca şimdilik loga yazar; gönderme akışı için sonraki adımda SAVE_STEP bağlanabilir.
