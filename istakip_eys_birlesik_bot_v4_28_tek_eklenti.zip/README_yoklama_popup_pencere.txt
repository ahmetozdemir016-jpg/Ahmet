Bu sürümde yoklama koduna tıklayınca PDF ayrı sekme yerine popup/pencere olarak açılmaya çalışır.
e-Yoklama X-Frame-Options: deny gönderdiği için iframe/modal içinde gösterilemez; bu nedenle en yakın çözüm tarayıcı popup penceresidir.
