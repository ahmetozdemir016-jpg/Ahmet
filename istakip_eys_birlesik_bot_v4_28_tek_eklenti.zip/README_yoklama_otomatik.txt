Bu sürümde Yoklama Durum, Yoklama Kodu ve Yoklama Aç sütunları eklendi.
İşleri Tara sonrası her iş için srvYoklama_getYoklamalar sorgusu yapılır.
Tarih aralığı: başlangıç bugünden 6 ay önce, bitiş bugündür.
Son durum optime'a göre belirlenir; varsa srvYoklama_getYoklamaGunluk akışı ile güncellenir.
Yoklama Aç, yKodu ile getSonuc PDF'sini modal içinde açar.
