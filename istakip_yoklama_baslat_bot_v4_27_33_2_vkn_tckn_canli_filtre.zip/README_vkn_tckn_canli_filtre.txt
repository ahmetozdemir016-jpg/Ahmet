Son çalışan v4.27.33 temel alındı.
VKN aralık filtresi düzeltildi ve TCKN canlı filtre eklendi.
VKN: İşTakip hücresindeki 10 haneli sayı.
TCKN: İşTakip hücresindeki 11 haneli sayı.
VKN başlangıç/bitiş 10 haneden fazla, TCKN 11 haneden fazla kabul etmez.
Yazarken canlı süzer; boşsa tüm liste görünür.
