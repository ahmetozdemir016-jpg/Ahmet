Son çalışan v4.27.33 temel alındı. Sadece VKN filtre katmanı eklendi/düzeltildi.
İşleri Tara sonrası tabloda İşTakip hücresindeki 10 haneli VKN okunur.
VKN Başlangıç / VKN Bitiş tablonun üstüne gelir, 10 haneden fazla yazdırmaz.
