KDV DÜZELTME VE DEVİR HESABI

1. Ana ekranda “Yıllık KDV-BS-POS” düğmesine basın.
2. Hesabın başlayacağı yılı girin. Program başlangıç yılından itibaren en fazla 5 yılı getirir.
3. KDV beyan verileri otomatik çekildikten sonra “KDV Düzeltme ve Devir Hesabı” tablosu oluşur.
4. Düzeltme bulunan aylarda yalnızca şu sarı alanları doldurun:
   - İlave Matrah
   - KDV Oranı %
   - Reddedilen İndirim KDV
5. “Hesapla ve Devret” düğmesine basın.

Program ilave matraha ait KDV’yi hesaplanan ve toplam KDV’ye ekler. Reddedilen indirimi toplam indirimden düşer. Düzeltilmiş devreden KDV’yi bir sonraki aya aktararak ödenecek ve devreden KDV’yi dönem dönem yeniden hesaplar.

KDV oranı dönemine göre başlangıç değeri olarak 01.07.2023 öncesinde %18, bu tarihten itibaren %20 gelir. İşlemin gerçek oranı farklıysa (örneğin %1, %8 veya %10) oran alanını değiştirin.

Girilen düzeltmeler mükellef VKN’sine göre tarayıcıda saklanır. “Girdileri Temizle” yalnızca bu mükellefe ait ilave matrah ve indirim reddi girişlerini siler.
