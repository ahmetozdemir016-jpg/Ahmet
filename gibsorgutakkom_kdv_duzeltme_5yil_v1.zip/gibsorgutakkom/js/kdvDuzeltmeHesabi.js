(function(global){
  'use strict';

  var MODULE_VERSION = '1.0.0';
  var MAX_MONTHS = 60;

  function numberValue(value){
    if(value === null || value === undefined || value === '') return 0;
    if(typeof value === 'number') return isFinite(value) ? value : 0;
    var text = String(value).trim();
    if(!text || text === '-' || /^HATA$/i.test(text) || /^NaN$/i.test(text)) return 0;
    var negative = /^\(.*\)$/.test(text);
    if(negative) text = text.slice(1, -1);
    text = text.replace(/\s/g, '').replace(/[^0-9,\.\-]/g, '');
    if(text.charAt(0) === '-') { negative = true; text = text.slice(1); }
    var comma = text.lastIndexOf(','), dot = text.lastIndexOf('.');
    if(comma >= 0 && dot >= 0){
      text = comma > dot ? text.replace(/\./g, '').replace(',', '.') : text.replace(/,/g, '');
    }else if(comma >= 0){
      var commaParts = text.split(',');
      text = commaParts.length === 2 && commaParts[1].length <= 2 ? text.replace(',', '.') : text.replace(/,/g, '');
    }else if(dot >= 0){
      var dotParts = text.split('.');
      if(dotParts.length > 2 || (dotParts.length === 2 && dotParts[1].length === 3)) text = text.replace(/\./g, '');
    }
    var parsed = parseFloat(text);
    if(!isFinite(parsed)) return 0;
    return negative ? -parsed : parsed;
  }

  function nonNegative(value){ return Math.max(0, numberValue(value)); }
  function roundMoney(value){ return Math.round((numberValue(value) + 1e-9) * 100) / 100; }
  function money(value){
    return roundMoney(value).toLocaleString('tr-TR', {minimumFractionDigits:2, maximumFractionDigits:2});
  }
  function esc(value){
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function defaultRate(period){ return String(period) >= '2023-07' ? 20 : 18; }
  function periodIsNotFuture(period){
    var match = /^(\d{4})-(\d{2})$/.exec(String(period || ''));
    if(!match) return false;
    var now = new Date();
    return (parseInt(match[1],10) * 12 + parseInt(match[2],10)) <= (now.getFullYear() * 12 + now.getMonth() + 1);
  }

  function calculate(sourceRows, adjustments){
    var rows = (sourceRows || []).slice(0, MAX_MONTHS);
    var output = [], previousAdjustedCarry = null;
    for(var i=0; i<rows.length; i++){
      var source = rows[i] || {};
      var adjustment = (adjustments && adjustments[source.period]) || {};
      var additionalBase = roundMoney(nonNegative(adjustment.additionalBase));
      var rate = nonNegative(adjustment.rate);
      if(rate > 100) rate = 100;
      var rejectedInputVat = roundMoney(nonNegative(adjustment.rejectedInputVat));
      var additionalVat = roundMoney(additionalBase * rate / 100);
      var adjustedPreviousCarry = i === 0 ? roundMoney(source.declaredPreviousCarry) : roundMoney(previousAdjustedCarry);
      var ownPeriodDeductions = Math.max(0, roundMoney(source.declaredTotalDeductible - source.declaredPreviousCarry));
      var adjustedTotalDeductible = roundMoney(Math.max(0, adjustedPreviousCarry + ownPeriodDeductions - rejectedInputVat));
      var adjustedMatrah = roundMoney(source.declaredMatrah + additionalBase);
      var adjustedCalculatedVat = roundMoney(source.declaredCalculatedVat + additionalVat);
      var adjustedTotalVat = roundMoney(source.declaredTotalVat + additionalVat);
      var taxAfterDeductions = roundMoney(Math.max(0, adjustedTotalVat - adjustedTotalDeductible));
      var adjustedPayable = roundMoney(Math.max(0, taxAfterDeductions - nonNegative(source.declaredDeferredVat)));
      var adjustedCarry = taxAfterDeductions > 0 ? 0 : roundMoney(Math.max(0, adjustedTotalDeductible - adjustedTotalVat - nonNegative(source.declaredRefundVat)));
      var payableDifference = roundMoney(adjustedPayable - source.declaredPayableVat);
      var carryDifference = roundMoney(adjustedCarry - source.declaredNextCarry);
      output.push({
        period:source.period,
        declaredMatrah:roundMoney(source.declaredMatrah),
        additionalBase:additionalBase,
        rate:rate,
        additionalVat:additionalVat,
        adjustedMatrah:adjustedMatrah,
        rejectedInputVat:rejectedInputVat,
        adjustedCalculatedVat:adjustedCalculatedVat,
        adjustedPreviousCarry:adjustedPreviousCarry,
        adjustedTotalDeductible:adjustedTotalDeductible,
        adjustedTotalVat:adjustedTotalVat,
        declaredPayableVat:roundMoney(source.declaredPayableVat),
        adjustedPayable:adjustedPayable,
        payableDifference:payableDifference,
        declaredNextCarry:roundMoney(source.declaredNextCarry),
        adjustedCarry:adjustedCarry,
        carryDifference:carryDifference
      });
      previousAdjustedCarry = adjustedCarry;
    }
    return output;
  }

  function sourceRowsFromTable(){
    var table = document.getElementById('myTable24'), rows = [];
    if(!table) return rows;
    Array.prototype.forEach.call(table.rows, function(row){
      var period = row.cells && row.cells[0] ? String(row.cells[0].textContent || '').trim() : '';
      if(!/^\d{4}-\d{2}$/.test(period) || !periodIsNotFuture(period)) return;
      function cell(index){ return row.cells && row.cells[index] ? numberValue(row.cells[index].textContent || row.cells[index].innerText || '') : 0; }
      rows.push({
        period:period,
        declaredMatrah:cell(8),
        declaredCalculatedVat:cell(9),
        declaredTotalVat:cell(11),
        declaredPreviousCarry:cell(12),
        declaredTotalDeductible:cell(15),
        declaredDeferredVat:cell(16),
        declaredPayableVat:cell(17),
        declaredRefundVat:cell(18),
        declaredNextCarry:cell(19)
      });
    });
    rows.sort(function(a,b){ return a.period < b.period ? -1 : (a.period > b.period ? 1 : 0); });
    return rows.slice(0, MAX_MONTHS);
  }

  function storageKey(vkn){ return 'takkom_kdv_duzeltme_v1_' + String(vkn || '').replace(/\D/g,''); }
  function loadAdjustments(vkn){
    try{
      var data = JSON.parse(localStorage.getItem(storageKey(vkn)) || '{}');
      return data && data.adjustments ? data.adjustments : {};
    }catch(e){ return {}; }
  }
  function saveAdjustments(vkn, adjustments){
    try{
      localStorage.setItem(storageKey(vkn), JSON.stringify({version:1, vkn:String(vkn || '').replace(/\D/g,''), updatedAt:(new Date()).toISOString(), adjustments:adjustments}));
    }catch(e){}
  }
  function readAdjustments(panel, sourceRows){
    var data = {};
    Array.prototype.forEach.call(panel.querySelectorAll('tr[data-kdvh-period]'), function(row){
      var period = row.getAttribute('data-kdvh-period');
      var base = nonNegative(row.querySelector('[data-kdvh-field="additionalBase"]').value);
      var rate = nonNegative(row.querySelector('[data-kdvh-field="rate"]').value);
      var reject = nonNegative(row.querySelector('[data-kdvh-field="rejectedInputVat"]').value);
      data[period] = {additionalBase:roundMoney(base), rate:Math.min(rate,100), rejectedInputVat:roundMoney(reject)};
    });
    for(var i=0; i<sourceRows.length; i++){
      if(!data[sourceRows[i].period]) data[sourceRows[i].period] = {additionalBase:0, rate:defaultRate(sourceRows[i].period), rejectedInputVat:0};
    }
    return data;
  }
  function inputValue(value){ return numberValue(value) ? String(numberValue(value)).replace('.',',') : ''; }
  function differenceClass(value){ return numberValue(value) > 0 ? 'kdvh-increase' : (numberValue(value) < 0 ? 'kdvh-decrease' : ''); }

  function renderRows(panel, sourceRows, adjustments){
    var result = calculate(sourceRows, adjustments), body = panel.querySelector('#kdvhBody'), html = '';
    var totals = {base:0, additionalVat:0, rejected:0, payableDifference:0};
    for(var i=0; i<result.length; i++){
      var row = result[i], input = adjustments[row.period] || {};
      totals.base += row.additionalBase; totals.additionalVat += row.additionalVat; totals.rejected += row.rejectedInputVat; totals.payableDifference += row.payableDifference;
      html += '<tr data-kdvh-period="'+esc(row.period)+'">' +
        '<td class="kdvh-period">'+esc(row.period)+'</td>' +
        '<td class="kdvh-money">'+money(row.declaredMatrah)+'</td>' +
        '<td><input data-kdvh-field="additionalBase" inputmode="decimal" value="'+esc(inputValue(input.additionalBase))+'" placeholder="0,00"></td>' +
        '<td><input class="kdvh-rate" data-kdvh-field="rate" inputmode="decimal" value="'+esc(input.rate === undefined ? defaultRate(row.period) : input.rate)+'"></td>' +
        '<td class="kdvh-money">'+money(row.additionalVat)+'</td>' +
        '<td class="kdvh-money">'+money(row.adjustedMatrah)+'</td>' +
        '<td><input data-kdvh-field="rejectedInputVat" inputmode="decimal" value="'+esc(inputValue(input.rejectedInputVat))+'" placeholder="0,00"></td>' +
        '<td class="kdvh-money">'+money(row.adjustedPreviousCarry)+'</td>' +
        '<td class="kdvh-money">'+money(row.adjustedTotalDeductible)+'</td>' +
        '<td class="kdvh-money">'+money(row.adjustedTotalVat)+'</td>' +
        '<td class="kdvh-money">'+money(row.declaredPayableVat)+'</td>' +
        '<td class="kdvh-money">'+money(row.adjustedPayable)+'</td>' +
        '<td class="kdvh-money '+differenceClass(row.payableDifference)+'">'+money(row.payableDifference)+'</td>' +
        '<td class="kdvh-money">'+money(row.declaredNextCarry)+'</td>' +
        '<td class="kdvh-money">'+money(row.adjustedCarry)+'</td>' +
        '<td class="kdvh-money '+differenceClass(row.carryDifference)+'">'+money(row.carryDifference)+'</td>' +
      '</tr>';
    }
    body.innerHTML = html;
    panel.querySelector('#kdvhSummary').innerHTML = '<b>'+result.length+' dönem hesaplandı.</b> İlave matrah: <b>'+money(totals.base)+'</b> | İlave hesaplanan KDV: <b>'+money(totals.additionalVat)+'</b> | Reddedilen indirim: <b>'+money(totals.rejected)+'</b> | Ödenecek farkı toplamı: <b>'+money(totals.payableDifference)+'</b>';
    return result;
  }

  function ensureStyle(){
    if(document.getElementById('kdvhStyle')) return;
    var style = document.createElement('style'); style.id = 'kdvhStyle';
    style.textContent = '#kdvhPanel{margin:18px 0;padding:12px;border:2px solid #1769aa;background:#eef7ff;}' +
      '#kdvhPanel h2{margin:0 0 6px;color:#0d4775;}#kdvhPanel .kdvh-note{font-size:12px;margin-bottom:8px;}' +
      '#kdvhPanel .kdvh-actions{margin:8px 0;}#kdvhPanel button{border:0;padding:7px 12px;margin-right:6px;cursor:pointer;color:#fff;background:#1769aa;}' +
      '#kdvhPanel button.kdvh-clear{background:#6c757d;}#kdvhWrap{overflow:auto;max-height:70vh;border:1px solid #99b8d0;background:#fff;}' +
      '#kdvhTable{border-collapse:collapse;min-width:1900px;margin:0;padding:0;}#kdvhTable th{position:sticky;top:0;z-index:2;background:#1769aa;color:#fff;font-size:11px;}' +
      '#kdvhTable td{font-size:11px;white-space:nowrap;}#kdvhTable input{width:92px;padding:4px;border:1px solid #d59d00;background:#fff5bf;text-align:right;}' +
      '#kdvhTable input.kdvh-rate{width:52px}.kdvh-money{text-align:right}.kdvh-period{font-weight:bold}.kdvh-increase{background:#ffd9d9;color:#a00000;font-weight:bold;}.kdvh-decrease{background:#e4f7e8;color:#176b2c;font-weight:bold;}' +
      '#kdvhSummary{margin-top:8px;padding:7px;background:#fff;border:1px solid #99b8d0;font-size:12px;}' +
      '@media print{#kdvhPanel{display:none !important;}}';
    document.head.appendChild(style);
  }

  function init(options){
    options = options || {};
    var sourceRows = sourceRowsFromTable();
    if(!sourceRows.length) return;
    ensureStyle();
    var vkn = String(options.vkn || '').replace(/\D/g,'');
    var old = document.getElementById('kdvhPanel'); if(old && old.parentNode) old.parentNode.removeChild(old);
    var panel = document.createElement('div'); panel.id = 'kdvhPanel';
    panel.innerHTML = '<h2>KDV Düzeltme ve Devir Hesabı</h2>' +
      '<div class="kdvh-note">Beyan verileri yukarıdaki tablodan otomatik alınır. Yalnızca ilave matrahı, o matraha uygulanacak KDV oranını ve reddedilen indirim KDV’yi girin. Hesaplama dönem dönem ilerler ve önceki ayın düzeltilmiş devreden KDV’sini sonraki aya taşır. En fazla 5 yıl (60 dönem) hesaplanır.</div>' +
      '<div class="kdvh-actions"><button type="button" id="kdvhCalculate">Hesapla ve Devret</button><button type="button" class="kdvh-clear" id="kdvhClear">Girdileri Temizle</button></div>' +
      '<div id="kdvhWrap"><table id="kdvhTable"><thead><tr>' +
      '<th>Dönem</th><th>Beyan Matrahı</th><th>İlave Matrah</th><th>KDV Oranı %</th><th>İlave Hesaplanan KDV</th><th>Düzeltilmiş Matrah</th><th>Reddedilen İndirim KDV</th><th>Düzeltilmiş Önceki Devir</th><th>Düzeltilmiş Toplam İndirim</th><th>Düzeltilmiş Toplam KDV</th><th>Beyan Ödenecek</th><th>Düzeltilmiş Ödenecek</th><th>Ödenecek Farkı</th><th>Beyan Devreden</th><th>Düzeltilmiş Devreden</th><th>Devreden Farkı</th>' +
      '</tr></thead><tbody id="kdvhBody"></tbody></table></div><div id="kdvhSummary"></div>';
    var table = document.getElementById('myTable24');
    table.parentNode.insertBefore(panel, table.nextSibling);
    var adjustments = loadAdjustments(vkn);
    renderRows(panel, sourceRows, adjustments);
    panel.querySelector('#kdvhCalculate').onclick = function(){
      adjustments = readAdjustments(panel, sourceRows); saveAdjustments(vkn, adjustments); renderRows(panel, sourceRows, adjustments);
    };
    panel.querySelector('#kdvhClear').onclick = function(){
      if(!global.confirm('Bu mükellef için girilen ilave matrah ve indirim reddi tutarları temizlensin mi?')) return;
      adjustments = {}; saveAdjustments(vkn, adjustments); renderRows(panel, sourceRows, adjustments);
    };
  }

  global.KdvDuzeltmeHesabi = {version:MODULE_VERSION, maxMonths:MAX_MONTHS, calculate:calculate, init:init, numberValue:numberValue, roundMoney:roundMoney};
})(window);
