
(() => {
  'use strict';

  if (window.__istakipEysLauncherLoaded) return;
  window.__istakipEysLauncherLoaded = true;

  function addBtn() {
    if (document.getElementById('istakip-eys-launcher')) return;

    const box = document.createElement('div');
    box.id = 'istakip-eys-launcher';
    box.style.cssText = [
      'position:fixed',
      'right:16px',
      'bottom:16px',
      'z-index:2147483647',
      'background:#0d1b31',
      'color:#fff',
      'border:1px solid #274063',
      'border-radius:10px',
      'box-shadow:0 12px 30px rgba(0,0,0,.35)',
      'padding:8px',
      'font:12px/1.35 Segoe UI,Arial,sans-serif'
    ].join(';');

    box.innerHTML = `
      <button id="istakip-open-eys-module" style="background:#8b5cf6;color:#fff;border:0;border-radius:7px;padding:8px 10px;font-weight:700;cursor:pointer">
        EYS Modülü
      </button>
    `;

    document.documentElement.appendChild(box);

    box.querySelector('#istakip-open-eys-module').onclick = () => {
      const panel = document.getElementById('eys-tabbed-bot-panel');
      if (panel) {
        panel.style.display = '';
        const wrap = document.getElementById('eys_wrap');
        if (wrap) wrap.style.display = 'block';
        try { panel.scrollIntoView({ block: 'center' }); } catch (_) {}
        return;
      }

      alert('EYS modülü bu sayfada henüz yüklenmemiş. Eklentiyi güncelledikten sonra sayfayı Ctrl+R ile yenileyin. EYS/GİBIntranet sayfasında otomatik açılacaktır.');
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addBtn, { once: true });
  } else {
    addBtn();
  }
})();
