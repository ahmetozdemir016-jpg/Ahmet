v4.31.32 VD Kodu / Önizleme Fix

Resimlerden yakalanan iki sorun düzeltildi:

1) Bilinen adres sorgusu
- EYS'in kendi requestinde seçili görünen VD metni 016253 ile başlıyor, fakat gönderilen gerçek vdkodu 016258 olabiliyor.
- Panel artık vdKodu / vdkodu / kod / KODU vb. gerçek alanları text/value'dan önce kullanır.
- Bilinen adres sorgusunda sadece seçili kod değil, aynı VD listesinde gelen alternatif kodlar da denenir.
- Hata devam ederse panelde denenen VD kodları ve son payload açık gösterilir.

2) Önceki yoklama önizleme
- eyoklama.gelirler.gov.tr iframe içinde bağlantıyı reddettiği için artık iframe'e yüklenmez.
- Panel içinde açıklama gösterilir ve üstteki “Sekmede Aç” düğmesiyle açılır.
