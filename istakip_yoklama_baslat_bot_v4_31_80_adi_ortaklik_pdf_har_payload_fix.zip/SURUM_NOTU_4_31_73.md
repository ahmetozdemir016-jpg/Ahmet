# Sürüm Notu v4.31.73

- Adi Ortaklık İşe Başlama özel akışında önizleme PDF indirme mantığı Ana Modül önizleme akışıyla eşitlendi.
- EYS tarafındaki önizleme URL üretiminde fileID sonuna .pdf eklenmemesi kaynaklı 401 ihtimali düzeltildi.
- PDF indirilemezse fileID.pdf, encode edilmiş fileID, ham fileID ve fileID/dosyaId yedekleri denenir.
- Ana Modülün çalışan önizleme bilgisi EYS özel akışına köprü olarak açıldı.
