# Sürüm Notu v4.31.72

- Yoklama Süreci Başlat adımı sistemde görünmeye devam etse bile bot artık mükerrer yoklama göndermeden önce mevcut yoklama kodu kontrolü yapar.
- Ana Modül > Uygunları Gönder otomatik akışında, aynı İşTakip için Yoklama Durum/Kodu varsa satır atlanır.
- Adi Ortaklık İşe Başlama özel akışında daha önce oluşturulmuş ortak yoklamaları varsa tekrar yoklama çıkarılmaz; mevcut kodlar gösterilir.
- EYS Modülü > Yoklama Giriş işlem menüsünde Yoklama Süreci Başlat seçilirse önce canlı yoklama kodu kontrol edilir; kod varsa gönderim iptal edilir.
