# Sürüm Notu v4.31.69

Yüklenen memur modu Yoklama Giriş HAR dosyası incelendi.

## HAR’da görülen ek akışlar
- Açılışta `srvcRefData_getVDLERForCmb` ve `srvcRemoteCall_getAdresDataForCombo(type=1)` çağrıları var.
- VKN sorgusu sonrası `srvcRemoteCall_getSicilByVKN`, `srvcRemoteCall_getMukellefTerkBilgisiX`, `srvcRemoteCall_getMerkezFaaliyetKonulari`, `srvcRemoteCall_getVDsOfVKN`, `srvcYoklama_getEskiYoklamaListesi` çağrıları geliyor.
- VD listesi geldikten sonra gerçek sistem şube faaliyetlerini `srvcRemoteCall_getSubeFaaliyetKonulari` ile `vdKodu + birimfaal=0` payload’ıyla deniyor.
- Bilinen adresler sadece tek VD’den değil, VKN’ye bağlı VD’lerin tamamı için `srvcRemoteCall_getVDAdresleri` ile taranıyor.
- Adres seçilince adres zinciri `getAdresAsStringByAdresNo`, adres combo type 2-6, `getAdresTextByAdresNo`, `getCoordinatesFromAdresno` olarak ilerliyor.
- Kaydet payload’ı `srvcYoklama_saveYoklama` ile sade `yoklama` JSON string + `sessionData` biçiminde gidiyor.

## Yapılan düzeltmeler
- VD’ye bağlı şube faaliyet sorgusuna gerçek HAR’daki `vdKodu` ve `birimfaal: 0` payload’ı bağlandı.
- VKN’ye bağlı tüm VD’ler için şube faaliyet taraması eklendi.
- VKN’ye bağlı tüm VD’ler için bilinen adres taraması eklendi.
- Bilinen adres listesi VD bilgisiyle birlikte birleştirilip gösterilecek.
- Tek adres bulunursa otomatik adres no/zincir sorgusu çalışacak.
- Save payload’ında boş/yardımcı alanlar temizlenip gerçek memur HAR’a daha yakın sade payload gönderilecek.
