# Sürüm Notu v4.31.79

- Adi Ortaklık özel akışında PDF önce URL cevabından Blob/ArrayBuffer olarak indirilip okunur.
- PDF byte/metin katmanı okunamazsa aynı indirilen Blob panel içi iframe ile açılıp Chrome PDF text-layer üzerinden okunur.
- Bu da olmazsa doğrudan iframe ve manuel/yedek akış devam eder.
- Tarayıcının indirme klasörüne kaydedilen dosyaya güvenlik nedeniyle doğrudan erişilemediğinden, aynı dosya cevabı bellekte indirilmiş dosya gibi okunur.
