# Sürüm Notu v4.31.70

- Ana Modül üstündeki VKN Başlangıç / VKN Bitiş alanları görünümden kaldırıldı.
- Ana Modül Listeyi Yenile artık Yoklama Durum / Yoklama Kodu bilgisini cache'den değil canlı olarak yeniden sorgular.
- EYS Modülü > Yoklama Giriş > İş Takip İşlerini Getir butonu da her basıldığında yoklama durum/kod cache'ini temizler ve güncel durumları yeniden çeker.
- Müdür onayı, koordinatör gönderimi, ekip atama/gönderim gibi işlemlerden sonra liste yenilendiğinde eski durumların görünmesi engellendi.
