# Sürüm Notu v4.31.75

- Adi ortaklık özel akışında PDF açılışı Önizle sütunundaki akışla eşitlendi.
- PDF önce popup olarak açılır.
- Otomatik PDF metni okunamazsa aynı PDF iframe yedeğiyle de gösterilir.
- PDF metni yine okunamazsa ortak TCKN/VKN numaralarını manuel girerek akışa devam etme yedeği eklendi.
- Panel sürümü v4.31.75 olarak güncellendi.
