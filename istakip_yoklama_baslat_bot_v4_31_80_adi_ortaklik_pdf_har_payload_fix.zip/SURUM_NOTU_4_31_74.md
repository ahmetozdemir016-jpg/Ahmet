# Sürüm Notu v4.31.74

- Adi ortaklık özel akışında PDF 401 hatası düzelse bile PDF metin katmanı okunamadığında akış artık durmaz.
- PDF metni okunamazsa İş Takip satırındaki / önizleme cevabındaki VKN-TCKN alanlarından ortak kimlik adayları yedek olarak çıkarılır.
- Bulunan ortaklar yine onay ekranında gösterilir; onaydan sonra her ortak adına ayrı işe başlama yoklaması oluşturulur.
- Panel sürümü v4.31.74 olarak güncellendi.
