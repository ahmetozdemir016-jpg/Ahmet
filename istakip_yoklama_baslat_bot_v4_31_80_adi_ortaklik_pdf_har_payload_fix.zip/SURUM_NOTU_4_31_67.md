# Sürüm Notu v4.31.67

- Önizle Aç artık panel içi iframe yerine her seferinde ayrı Chrome penceresi açar.
- Yoklama/getSonuc PDF artık sabit pencere adı kullanmaz; her tıklamada yeni pencere açılır.
- PDF ve getSonuc pencerelerinde İş Takip + EYS Bot paneli yüklenmez; pencere temiz kalır.
- Popup engellenirse yedek modalda Sekmede Aç seçeneği gösterilir.
