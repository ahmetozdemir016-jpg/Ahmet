# Sürüm Notu v4.31.77

- Adi Ortaklık İşe Başlama özel akışında iframe/popup metninden alan okuma genişletildi.
- Ortaklığa ilişkin bilgilerden ünvan, işe başlama tarihi, faaliyet adresi ve adres numarası okunur.
- Ortaklara ilişkin bilgilerden 10 haneli numara VKN, 11 haneli numara TCKN kabul edilerek ortak listesi çıkarılır.
- İşçi bilgileri, işyeri kira/mülk bilgileri, kira dönemi, kira tutarı, para cinsi ve mülk sahibi TC/VKN bilgisi payload içine bağlanır.
- Adres numarası okunursa artık “Adres Yetersizdir” hatasına düşmeden kayıt akışına devam eder.
