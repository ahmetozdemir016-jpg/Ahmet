# Sürüm Notu v4.31.68

- EYS Modülü > Yoklama Giriş ekranında İş Takip İşleri listesi daha fazla yer kaplayacak şekilde büyütüldü.
- Ön Bilgi alanı kompakt hale getirildi; üzerine tıklanınca genişler, tekrar tıklanınca küçülür.
- İşlem Monitörü alanı kompakt hale getirildi; üzerine tıklanınca genişler, tekrar tıklanınca küçülür.
- Liste satırları biraz sıkıştırıldı; aynı ekranda daha fazla iş görünür.
