# Sürüm Notu v4.31.78

- Adi Ortaklık İşe Başlama özel akışında PDF artık popup olarak denenmeden doğrudan panel içi iframe içinde açılır.
- Ortak TC/VKN, ortaklık/adres/kira/mülk bilgileri önce iframe metninden okunur.
- Chrome PDF görüntüleyici sayfaları geç yüklediği için iframe okuma süresi uzatıldı ve sayfa metni daha derin taranır hale getirildi.
- Normal Önizle sütunundaki popup açma davranışı değiştirilmedi.
