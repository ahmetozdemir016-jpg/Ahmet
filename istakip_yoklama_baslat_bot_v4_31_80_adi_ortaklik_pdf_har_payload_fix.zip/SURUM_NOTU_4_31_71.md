# Sürüm Notu v4.31.71

- Ana Modül / EYS İş Takip listelerinde Adi Ortaklık İşe Başlama özel akışı eklendi.
- Yoklama Süreci Başlat adımı seçildiğinde önizleme PDF metninden ortak TCKN/VKN listesi okunur.
- Her ortak adına ayrı İşe Başlama yoklaması kaydedilir.
- Oluşan birden fazla yoklama kodu ilgili satırın Yoklama Durum / Yoklama Kodu sütununda gösterilir.
- Oluşan kodlar localStorage ile saklanır; liste yenilense de aynı İşTakip satırında görünmeye devam eder.
- Özel akıştan sonra İş Takip akışı da gönderilmeye çalışılır.
