# Sürüm Notu v4.31.80

- Adi Ortaklık İşe Başlama PDF kopya metni ve örnek HAR payloadına göre parser/payload eşleştirmesi güçlendirildi.
- Ortaklığa ilişkin bilgilerden ünvan, işe başlama tarihi, faaliyet adresi ve adres numarası okunur.
- Ortaklara ilişkin bilgilerde 10 haneli numara VKN, 11 haneli numara TCKN kabul edilir.
- İşçi bilgileri, işyeri mülk/kira bilgileri, kira tutar çeşidi, kira tutarı, para cinsi ve mülk sahibi bilgileri payloada aktarılır.
- Mülk sahibi TCKN/VKN için EYS sicil sorgusu yapılarak VKN/TCKN/unvan bilgisi HAR örneğine daha uygun doldurulur.
- PDF'deki faaliyet bilgileri yoklama açıklamasına yazılır; EYS sicil/faaliyet servisinden gelen NACE bilgisi varsa mukGrupData içinde korunur.
