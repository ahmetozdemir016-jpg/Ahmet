# Sürüm Notu v4.31.76

- Adi ortaklık özel akışında PDF önce Önizle sütunu gibi popup açılır.
- Popup içinden okunabilir HTML/metin varsa otomatik yakalanır.
- Fetch/PDF stream parser yedeği korunur.
- Popup okunamazsa iframe yedeği açılır ve iframe iç metni denenir.
- Chrome PDF görüntüleyici metin erişimini engellerse kullanıcıdan ortaklar tablosunu kopyala-yapıştır veya TC/VKN girme yedeği istenir.
