v4.28.2 düzeltmeleri

- Extension context invalidated hatasına karşı chrome.storage erişimi güvenli hale getirildi.
- EYS modülü artık sayfaya script olarak enjekte edilmiyor.
- EYS modülü manifest üzerinden content script olarak gp/gibintranet/eyoklama sayfalarında doğrudan çalışır.
- Sağ alttaki EYS Modülü butonu mevcut EYS panelini öne getirir.

Kurulumdan sonra mutlaka:
1. chrome://extensions sayfasında eski eklentiyi kaldır veya yeni klasörü tekrar yükle.
2. GİB sayfasını Ctrl+R ile yenile.
3. Hata ekranında eski hataları Tümünü temizle ile temizle.
