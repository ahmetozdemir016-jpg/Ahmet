İş Takip + EYS Birleşik Bot v4.28.1

Bu sürümde EYS modülü ayrıca görünür hale getirildi.

Kullanım:
1. Eklentiyi paketlenmemiş olarak yükle.
2. GİB / İş Takip / EYS sayfasını yenile.
3. Sağ altta mor renkli 'EYS Modülü' butonu görünür.
4. Butona basınca EYS paneli açılır.
5. EYS/e-Yoklama sayfasında panel otomatik de açılabilir.

Dosyalar:
- content.js: İş Takip botu
- eys_content.js: EYS/e-Yoklama botu
- eys_launcher.js: EYS modülünü görünür başlatıcı butonla açar

Not:
EYS botunda Memur → Müdür ve Müdür → Koordinatör akışı, filtreli işlem ve günlük PDF alanları bulunur.
