v4.31 EYS Sorgu Seçenekleri

README(2).md dosyasındaki örnek sorgulara göre EYS Filtreli İşlem ve Günlük PDF alanlarına ek seçenekler eklendi.

Eklenen alanlar:
- Veri kaynağı / sorgukaynak:
  0 = Kullanılan veriler
  1 = Sadece arşiv verileri
  2 = Arşiv dahil tüm veriler / durum+servis

- Yoklama durumu / ydurum:
  boş = Hepsi
  10 = Memurda
  20 = Müdürde
  30 = Koordinatörde
  40 = Ekipte
  60 = Yoklama sonuçlandı
  70 = Sonuçlanmayanlar
  80 = Görevli VD’de
  90 = Sonlandırılanlar
  0 = İptal edilenler

- İşlem durumu / sonucislem:
  1 = İşlem yapılacaklar
  2 = İşlem yapılanlar
  0 = Hepsi

Servis alanı korunmuştur. İnteraktif VD seçeneği 91 koduyla listede yer alır. Servis boş bırakılırsa sorguya boş servis gider.

VKN başlangıç/bitiş alanları sorgu payload içinde basvkn/sonvkn olarak da gönderilir, ayrıca istemci tarafında da filtrelenir.

Günlük PDF alanında Tüm PDF'leri Aç ve Kuyruk Yazdır, seçilen VKN aralığı ve yeni sorgu seçenekleriyle gelen/görünen kayıtler üzerinden çalışır.
