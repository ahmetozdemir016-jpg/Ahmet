v4.30.1 EYS Method Fix

Düzeltilen hata:
- this.onlyDigits is not a function
- this.runFilteredQueryOnly is not a function

Sebep:
v4.30'da EYS filtre fonksiyonları class dışına/yanlış noktaya yerleşmişti.

Düzeltme:
- onlyDigits, runFilteredQueryOnly, applySelectedFilteredRows, getVisibleDailyRows ve ilgili yardımcılar EysFullBot class içine doğru şekilde yerleştirildi.
- VKN input eventleri ayrıca güvenli fallback ile çalışacak hale getirildi.
