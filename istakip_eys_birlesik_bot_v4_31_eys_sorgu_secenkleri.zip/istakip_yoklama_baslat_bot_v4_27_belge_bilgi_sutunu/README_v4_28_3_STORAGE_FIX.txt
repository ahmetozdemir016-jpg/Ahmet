v4.28.3 Storage Fix

Düzeltme:
- İş Takip content.js içindeki chrome.storage.local.get/set çağrıları güvenli wrapper içine alındı.
- EYS eys_content.js içindeki chrome.storage.local.get/set/remove çağrıları güvenli wrapper içine alındı.
- Chrome storage bağlamı geçersiz olursa localStorage yedeği kullanılır.
- Böylece Extension context invalidated hatası paneli durdurmaz.

Kurulum:
1. Eski eklentiyi kaldır.
2. Bu ZIP'i klasöre çıkarıp paketlenmemiş olarak yükle.
3. GİB sayfasını tamamen yenile. Mümkünse sekmeyi kapatıp yeniden aç.
4. chrome://extensions hata ekranında eski hataları temizle.
