v4.31.2 Başlık Düzeltme

Düzeltme:
- Panelde görünen eski 'İş Takip Yoklama Başlat Botu v4.27' başlığı kaldırıldı.
- Başlık 'İş Takip + EYS Botu v4.31.2' olarak güncellendi.
- manifest version alanı 4.31.2 yapıldı.

Not:
Fonksiyonel akış v4.31.1 ile aynıdır; sadece görünen sürüm/başlık bilgisi düzeltilmiştir.
