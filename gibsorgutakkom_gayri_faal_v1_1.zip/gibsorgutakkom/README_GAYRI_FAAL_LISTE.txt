GAYRİ FAAL MÜKELLEFLERİN TESPİTİNE İLİŞKİN LİSTE (Rapor Alma – EVDB Raporları içinde)

Rapor seçiminde "Gayri Faal Mükelleflerin Tespitine İlişkin Liste Hakkında Yapılan İşlemler (çoklu liste · birleştir)".
Servisler (HAR 23.09.2026, gibintranet tokeni):
- resenTerkIslService_tespitTarihleriGetir {}  → liste hazırlanma tarihleri (checkbox olarak, yeniden eskiye)
- resenTerkIslService_resenTerkIslemGorenlerListesiSorgula {vdkodu, vkodu:'' (HEPSİ), tarih:YYYYAAGG}
Seçilen her liste ayrı sorgulanır (3 paralel), VKN bazında tekilleştirilir. Alanlar mükellefin en son çıktığı listeden alınır;
"Çıktığı Listeler" sütunu hangi listelerde çıktığını (o listede FAAL ise "(FAAL)") ve "Liste Sayısı" kaç listede çıktığını gösterir.
Sorumlu sütunu sayfadaki Personel VKN aralıklarından (seçili bölüm) gelir; aralık değişince "Listeye uygula" ile yenilenir.
Süzgeçler: Faal durumu (Hepsi / Sadece FAAL / FAAL olmayanlar), Sorumlu, Terk Nedeni, En az N listede, VKN/ünvan arama.
Hızlı seçim: Son 3 / Son 6 / Son 12 / Bu yıl / Hepsi / Temizle. Excel (.xlsx: Liste + Parametreler) ve yatay A4 yazdırma.

v1.1
- Terk Nedeni süzgecinde "(boş)" seçeneği; yeni "Terk Tarihi" süzgeci: Hepsi / Boş olanlar / Dolu olanlar.
- "Yoklamaları Getir (görünen satırlar)": süzülmüş listedeki her mükellef için takdire-sevk'teki Yoklama bölümüyle aynı servis
  (EYS srvcEys_getMukYoklamalar {vkn, tckn:'', durum:80}) sorgulanır; sonuç "Yoklama Fiş No / Yoklamalar" sütununa
  "▸ N yoklama" olarak yazılır, tıklayınca "Yoklama türü – Yoklama kodu (tarih)" listesi açılır, her satır
  getSonuc?yKodu= ile yoklama sonucunu açar. Daha önce getirilenler tekrar sorgulanmaz. Excel'e liste metin olarak,
  çıktıya açık hâlde gider.
