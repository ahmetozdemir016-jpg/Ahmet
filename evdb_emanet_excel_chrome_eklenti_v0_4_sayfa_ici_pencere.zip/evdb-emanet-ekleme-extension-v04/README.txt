EVDB Emanet Excel Aktarım Botu v0.4

Kurulum:
1) Zip dosyasını çıkarın.
2) Chrome > chrome://extensions açın.
3) Geliştirici modunu açın.
4) Paketlenmemiş öğe yükle deyip evdb-emanet-ekleme-extension-v04 klasörünü seçin.
5) EVDB Emanet MİF(A) > Emanet Bilgileri ekranını yenileyin.

Kullanım:
- Bot artık sayfanın içinde sağ üstte pencere olarak görünür.
- Görünmezse eklenti ikonuna tıklayın.
- Excel dosyasını pencere içinden seçin veya sürükle bırak yapın.
- Dosyayı Oku > Başlat.

Varsayılan:
- Sadece İşlem Yönü=Giriş işler.
- Belge Türü=Diğer seçer.
- Vergi No varsa VKN alanına, yoksa TC No alanına yazar.
- Ad/Soyad/Unvan dolmasını bekler.
- Belge No formatını EVDB formatına çevirir.
- Emanet Türü=39 Diğer Çeşitli Emanetler seçer.
- Emanet Ekle ve onayda Evet yapar.
- Kaydet butonuna basmaz; sadece alta ekler.
