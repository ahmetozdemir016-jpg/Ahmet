(() => {
  if (window.__evdbEmanetBotV04Loaded) return;
  window.__evdbEmanetBotV04Loaded = true;

  const state = {
    running: false,
    paused: false,
    stopped: false,
    current: 0,
    total: 0,
    results: [],
    options: {},
    selectedFile: null,
    preparedRows: []
  };

  const PANEL_ID = 'evdb-emanet-bot-panel-v04';
  const $ = id => document.getElementById(id);

  function norm(s) {
    return String(s || '').toLocaleLowerCase('tr-TR')
      .replace(/ı/g, 'i').replace(/İ/g, 'i')
      .replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c')
      .replace(/\s+/g, ' ').replace(/[：:]/g, '').trim();
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
  }

  function makeDraggable(panel, handle) {
    let down = false, sx = 0, sy = 0, sl = 0, st = 0;
    handle.addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;
      down = true; sx = e.clientX; sy = e.clientY;
      const r = panel.getBoundingClientRect(); sl = r.left; st = r.top;
      document.body.style.userSelect = 'none';
    });
    document.addEventListener('mousemove', e => {
      if (!down) return;
      panel.style.left = Math.max(0, sl + e.clientX - sx) + 'px';
      panel.style.top = Math.max(0, st + e.clientY - sy) + 'px';
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => { down = false; document.body.style.userSelect = ''; });
  }

  function ensurePanel(show = true) {
    let panel = $(PANEL_ID);
    if (panel) {
      if (show) panel.style.display = 'block';
      return panel;
    }
    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.style.cssText = `
      position:fixed; right:18px; top:90px; width:430px; z-index:2147483647;
      background:#f6f7fb; color:#1f2933; border:1px solid #4b5563; border-radius:10px;
      font:13px Arial, sans-serif; box-shadow:0 8px 28px rgba(0,0,0,.32); overflow:hidden;
    `;
    panel.innerHTML = `
      <div id="evdb-bot-drag" style="background:#263449;color:#fff;padding:9px 10px;cursor:move;display:flex;align-items:center;justify-content:space-between;gap:8px">
        <div style="font-weight:bold">EVDB Emanet Botu v0.4</div>
        <div>
          <button id="evdb-bot-min" title="Küçült" style="margin-right:4px">—</button>
          <button id="evdb-bot-close" title="Gizle">×</button>
        </div>
      </div>
      <div id="evdb-bot-body" style="padding:10px">
        <div style="font-size:12px;margin-bottom:8px;color:#374151">Emanet MİF(A) &gt; Emanet Bilgileri ekranı açıkken çalıştır.</div>
        <div style="border:1px dashed #9ca3af;border-radius:8px;padding:8px;background:#fff;margin-bottom:8px">
          <div style="font-weight:bold;margin-bottom:6px">Excel dosyası (.xlsx)</div>
          <input id="evdb-bot-file" type="file" accept=".xlsx" style="display:none">
          <button id="evdb-bot-choose">Dosya Seç</button>
          <span id="evdb-bot-file-name" style="margin-left:8px;color:#4b5563">Dosya seçilmedi</span>
          <div id="evdb-bot-drop" style="margin-top:7px;padding:8px;text-align:center;background:#eef2ff;border-radius:6px;color:#374151">veya Excel dosyasını buraya sürükle-bırak</div>
        </div>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-only-giris" type="checkbox" checked> Sadece İşlem Yönü = Giriş</label>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-no-save" type="checkbox" checked> Kaydet butonuna basma, sadece alta ekle</label>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-stop-error" type="checkbox" checked> Hata olursa dur</label>
        <div style="display:flex;align-items:center;gap:8px;margin:7px 0">
          <label>Satır bekleme ms</label><input id="evdb-bot-delay" type="number" value="750" min="100" step="100" style="width:90px">
        </div>
        <div style="margin:8px 0;background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:6px">
          Okunan kayıt: <b id="evdb-bot-total">0</b> &nbsp; İşlenecek kayıt: <b id="evdb-bot-usable">0</b> &nbsp; Şu an: <b id="evdb-bot-current">0</b>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">
          <button id="evdb-bot-read">Dosyayı Oku</button>
          <button id="evdb-bot-start" disabled>Başlat</button>
          <button id="evdb-bot-pause" disabled>Duraklat</button>
          <button id="evdb-bot-resume" disabled>Devam</button>
          <button id="evdb-bot-stop" disabled>Durdur</button>
          <button id="evdb-bot-clear">Log Temizle</button>
        </div>
        <div id="evdb-bot-status" style="margin:6px 0;color:#111827;font-weight:bold">Hazır.</div>
        <pre id="evdb-bot-log" style="height:170px;overflow:auto;white-space:pre-wrap;background:#111827;color:#d1fae5;padding:8px;margin:0;border-radius:6px;font-size:12px"></pre>
      </div>`;
    document.documentElement.appendChild(panel);
    makeDraggable(panel, $('evdb-bot-drag'));
    wirePanel();
    log('Bot penceresi hazır. Excel dosyasını seçip “Dosyayı Oku” deyin.');
    if (!show) panel.style.display = 'none';
    return panel;
  }

  function setStatus(msg) {
    const s = $('evdb-bot-status');
    if (s) s.textContent = msg;
    log(msg, false);
  }
  function log(msg, includeStatus = true) {
    ensurePanel(false);
    const line = `[${new Date().toLocaleTimeString('tr-TR')}] ${msg}`;
    console.log('[EVDB Emanet Bot]', msg);
    const box = $('evdb-bot-log');
    if (box) { box.textContent += line + '\n'; box.scrollTop = box.scrollHeight; }
    if (includeStatus) {
      const cur = $('evdb-bot-current'); if (cur) cur.textContent = String(state.current || 0);
    }
  }
  function updateCounters(total, usable) {
    if ($('evdb-bot-total')) $('evdb-bot-total').textContent = String(total ?? state.total ?? 0);
    if ($('evdb-bot-usable')) $('evdb-bot-usable').textContent = String(usable ?? state.preparedRows.length ?? 0);
    if ($('evdb-bot-current')) $('evdb-bot-current').textContent = String(state.current || 0);
  }

  function wirePanel() {
    $('evdb-bot-close').onclick = () => { $(PANEL_ID).style.display = 'none'; };
    $('evdb-bot-min').onclick = () => {
      const b = $('evdb-bot-body');
      b.style.display = b.style.display === 'none' ? 'block' : 'none';
    };
    $('evdb-bot-clear').onclick = () => { $('evdb-bot-log').textContent = ''; };
    $('evdb-bot-choose').onclick = () => $('evdb-bot-file').click();
    $('evdb-bot-file').addEventListener('change', e => setFile(e.target.files && e.target.files[0]));

    const dz = $('evdb-bot-drop');
    ['dragenter','dragover'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.style.background = '#dbeafe'; }));
    ['dragleave','drop'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.style.background = '#eef2ff'; }));
    dz.addEventListener('drop', e => {
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (!file) return setStatus('Bırakılan dosya alınamadı.');
      setFile(file);
    });

    $('evdb-bot-read').onclick = readExcel;
    $('evdb-bot-start').onclick = () => runRows(state.preparedRows, getOptions());
    $('evdb-bot-pause').onclick = () => { state.paused = true; setStatus('Duraklatıldı.'); updateButtons(); };
    $('evdb-bot-resume').onclick = () => { state.paused = false; setStatus('Devam ediyor.'); updateButtons(); };
    $('evdb-bot-stop').onclick = () => { state.stopped = true; state.running = false; setStatus('Durduruluyor...'); updateButtons(); };
  }

  function updateButtons() {
    const start = $('evdb-bot-start'), pause = $('evdb-bot-pause'), resume = $('evdb-bot-resume'), stop = $('evdb-bot-stop');
    if (!start) return;
    start.disabled = state.running || !state.preparedRows.length;
    pause.disabled = !state.running || state.paused;
    resume.disabled = !state.running || !state.paused;
    stop.disabled = !state.running;
  }

  function setFile(file) {
    if (!file) return setStatus('Dosya seçilmedi.');
    if (!file.name.toLowerCase().endsWith('.xlsx')) return setStatus('Sadece .xlsx dosyası seçin.');
    state.selectedFile = file;
    state.preparedRows = [];
    updateCounters(0,0);
    $('evdb-bot-file-name').textContent = `${file.name} (${Math.round(file.size/1024)} KB)`;
    $('evdb-bot-start').disabled = true;
    setStatus('Dosya seçildi. Şimdi “Dosyayı Oku” butonuna basın.');
  }

  function normalizeDate(v) {
    v = String(v || '').trim();
    if (!v) return '';
    let m = v.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
    if (m) return `${m[1].padStart(2,'0')}.${m[2].padStart(2,'0')}.${m[3]}`;
    if (/^\d+(\.\d+)?$/.test(v)) {
      const n = Number(v);
      if (n > 20000 && n < 80000) {
        const d = new Date(Math.round((n - 25569) * 86400 * 1000));
        return `${String(d.getUTCDate()).padStart(2,'0')}.${String(d.getUTCMonth()+1).padStart(2,'0')}.${d.getUTCFullYear()}`;
      }
    }
    return v;
  }
  function normalizeAmount(v) {
    v = String(v || '').trim();
    if (!v) return '';
    if (v.includes(',') && v.includes('.')) return v.replace(/\./g, '');
    return v.replace(/\s/g, '').replace('.', ',');
  }
  function formatEvdbBelgeNo(raw, tarih, fisNo) {
    let v = String(raw || '').trim();
    const digits = v.replace(/\D/g, '');
    if (digits.length >= 15 && /^20\d{6}/.test(digits)) return `${digits.slice(0,8)}/00-000/${digits.slice(-7)}`;
    const t = String(tarih || '').trim();
    const f = String(fisNo || '').replace(/\D/g, '');
    const m = t.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
    if (!v && m && f) return `${m[3]}${m[2]}${m[1]}/00-000/${f.padStart(7,'0')}`;
    return v;
  }
  function pick(r, names) {
    for (const n of names) if (r[n] !== undefined && r[n] !== null && String(r[n]).trim() !== '') return r[n];
    return '';
  }
  function mapRows(rows) {
    const onlyGiris = $('evdb-bot-only-giris')?.checked ?? true;
    return rows.map(r => {
      const tarih = normalizeDate(pick(r, ['Tarih', 'İşlem Tarihi', 'Duzenleme Tarihi', 'Düzenleme Tarihi']));
      const fisNo = String(pick(r, ['Fiş No', 'Fis No', 'Fiş Numarası']) || '').trim();
      const belgeRaw = String(pick(r, ['Belge No', 'Belge Numarası', 'Belge No.']) || '').trim();
      return {
        excelRow: r.__rownum,
        tarih,
        fisNo,
        belgeNo: formatEvdbBelgeNo(belgeRaw, tarih, fisNo),
        belgeNoExcel: belgeRaw,
        tutar: normalizeAmount(pick(r, ['İşlem Tutarı', 'Islem Tutari', 'Tutar', 'Tutarı'])),
        islemYonu: String(pick(r, ['İşlem Yönü', 'Islem Yonu', 'Yön']) || '').trim(),
        tcNo: String(pick(r, ['T.C. No', 'TC No', 'T.C.Kimlik No', 'T.C. Kimlik No']) || '').replace(/\D/g, ''),
        vergiNo: String(pick(r, ['Vergi No', 'Vergi Kimlik No', 'VKN']) || '').replace(/\D/g, ''),
        ham: r
      };
    }).filter(r => !onlyGiris || norm(r.islemYonu) === 'giris')
      .filter(r => r.tarih || r.belgeNo || r.tutar || r.tcNo || r.vergiNo);
  }
  async function readExcel() {
    const file = state.selectedFile || ($('evdb-bot-file')?.files && $('evdb-bot-file').files[0]);
    if (!file) return setStatus('Önce Excel dosyası seçin.');
    try {
      setStatus('Excel okunuyor...');
      if (!window.XLSXLite) throw new Error('Excel okuyucu yüklenmedi. Eklentiyi yeniden yükleyin.');
      const wb = await XLSXLite.readXlsx(file, 'Emanet_Rapor');
      state.preparedRows = mapRows(wb.rows);
      state.total = wb.rows.length;
      state.current = 0;
      updateCounters(wb.rows.length, state.preparedRows.length);
      updateButtons();
      setStatus(`Okundu. Sayfa: ${wb.sheetName}. İşlenecek kayıt: ${state.preparedRows.length}.`);
      log('İlk kayıt örnekleri: ' + JSON.stringify(state.preparedRows.slice(0,3), null, 2));
    } catch (e) {
      setStatus('Excel okuma hatası: ' + (e?.message || e));
    }
  }
  function getOptions() {
    return {
      noAutoSave: $('evdb-bot-no-save')?.checked ?? true,
      stopOnError: $('evdb-bot-stop-error')?.checked ?? true,
      delay: Number($('evdb-bot-delay')?.value || 750),
      belgeTuru: 'Diğer',
      emanetTuru: '39 Diğer Çeşitli Emanetler'
    };
  }

  function injectConfirmOverride() {
    if (document.getElementById('evdb-emanet-confirm-override')) return;
    const s = document.createElement('script');
    s.id = 'evdb-emanet-confirm-override';
    s.textContent = `(() => {
      if (window.__evdbEmanetConfirmPatched) return;
      window.__evdbEmanetConfirmPatched = true;
      const oldConfirm = window.confirm;
      window.confirm = function(msg) {
        try { if (String(msg || '').toLocaleLowerCase('tr-TR').includes('zaman aşımı')) return true; } catch(e) {}
        return oldConfirm.apply(this, arguments);
      };
    })();`;
    (document.head || document.documentElement).appendChild(s);
  }

  function allCandidates() {
    return [...document.querySelectorAll('input, textarea, select, [contenteditable="true"], [role="combobox"]')].filter(visible);
  }
  function findLabelNode(label) {
    const nlabel = norm(label);
    let best = null;
    for (const el of [...document.querySelectorAll('label, td, th, div, span, font, b')].filter(visible)) {
      if (el.closest('#' + PANEL_ID)) continue;
      const t = norm(el.innerText || el.textContent || '');
      if (!t) continue;
      if (t === nlabel || t.includes(nlabel)) {
        if (!best || t.length < norm(best.innerText || best.textContent || '').length) best = el;
      }
    }
    return best;
  }
  function findControlAfterLabel(label) {
    const nlabel = norm(label);
    const controls = allCandidates().filter(c => !c.closest('#' + PANEL_ID));
    for (const c of controls) {
      const attrs = [c.name, c.id, c.title, c.placeholder, c.getAttribute('aria-label'), c.getAttribute('fieldLabel')].map(norm).join(' ');
      if (attrs.includes(nlabel)) return c;
    }
    const labelNode = findLabelNode(label);
    if (!labelNode) return null;
    const near = labelNode.closest('tr, .x-form-item, .form-group, table, div') || labelNode.parentElement;
    if (near) {
      const inside = [...near.querySelectorAll('input, textarea, select, [contenteditable="true"], [role="combobox"]')].filter(visible).filter(c => !c.closest('#' + PANEL_ID));
      if (inside.length) return inside[0];
    }
    const lr = labelNode.getBoundingClientRect();
    let best = null, bestScore = Infinity;
    for (const c of controls) {
      const r = c.getBoundingClientRect();
      const rightSameLine = r.left >= lr.left - 5 && Math.abs(r.top - lr.top) < 60;
      const below = r.top >= lr.top && r.top - lr.top < 130;
      if (rightSameLine || below) {
        const score = Math.abs(r.top - lr.top) * 4 + Math.max(0, r.left - lr.left);
        if (score < bestScore) { best = c; bestScore = score; }
      }
    }
    return best;
  }
  function setNativeValue(el, value) {
    if (!el) throw new Error('Alan bulunamadı.');
    el.scrollIntoView({ block: 'center', inline: 'center' });
    el.focus();
    if (el.tagName === 'SELECT') {
      const nval = norm(value);
      let opt = [...el.options].find(o => norm(o.textContent).includes(nval) || norm(o.value).includes(nval));
      if (!opt) throw new Error('Açılır listede seçenek yok: ' + value);
      el.value = opt.value;
    } else if (el.isContentEditable) {
      el.textContent = value;
    } else {
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, value); else el.value = value;
    }
    ['input','change','keyup','blur'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Tab', code: 'Tab' }));
  }
  async function typeValue(label, value) {
    const el = findControlAfterLabel(label);
    if (!el) throw new Error(`Alan bulunamadı: ${label}`);
    setNativeValue(el, String(value || ''));
    await sleep(170);
    return el;
  }
  async function selectByText(label, text) {
    const el = findControlAfterLabel(label);
    if (!el) throw new Error(`Liste alanı bulunamadı: ${label}`);
    el.scrollIntoView({ block: 'center', inline: 'center' });
    if (el.tagName === 'SELECT') { setNativeValue(el, text); await sleep(250); return; }
    el.focus(); el.click();
    await sleep(140);
    setNativeValue(el, text);
    await sleep(450);
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'ArrowDown', code: 'ArrowDown' }));
    await sleep(90);
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter' }));
    await sleep(250);
    clickVisibleText(text, false);
    await sleep(200);
  }
  function clickVisibleText(text, required = true) {
    const target = norm(text);
    const nodes = [...document.querySelectorAll('button, input[type="button"], input[type="submit"], a, span, div, td')].filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    let best = null;
    for (const el of nodes) {
      const val = el.tagName === 'INPUT' ? el.value : (el.innerText || el.textContent || '');
      const t = norm(val);
      if (t === target || t.includes(target)) { best = el; break; }
    }
    if (!best) {
      if (required) throw new Error('Buton/metin bulunamadı: ' + text);
      return false;
    }
    best.scrollIntoView({ block: 'center', inline: 'center' });
    best.click();
    return true;
  }
  async function clickButton(text) { clickVisibleText(text, true); await sleep(500); }
  async function clickYesIfExists() {
    for (let i=0; i<24; i++) {
      const ok = clickVisibleText('Evet', false) || clickVisibleText('Tamam', false);
      if (ok) { log('Onay penceresi: Evet/Tamam tıklandı.'); return true; }
      await sleep(150);
    }
    return false;
  }
  async function waitForIdentityFilled(timeoutMs = 9000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const ad = findControlAfterLabel('Ad');
      const soyad = findControlAfterLabel('Soyad');
      const unvan = findControlAfterLabel('Unvan') || findControlAfterLabel('Adı Soyadı') || findControlAfterLabel('Mükellef');
      const vals = [ad, soyad, unvan].filter(Boolean).map(x => String(x.value || x.textContent || '').trim()).filter(Boolean);
      if (vals.length >= 1) return true;
      await sleep(350);
    }
    return false;
  }
  function validateRow(row) {
    const missing = [];
    if (!row.vergiNo && !row.tcNo) missing.push('Vergi No/T.C. No');
    if (!row.belgeNo) missing.push('Belge No');
    if (!row.tutar) missing.push('Tutar');
    if (!row.tarih) missing.push('Tarih');
    return missing;
  }
  async function processRow(row) {
    log(`Satır ${row.excelRow} başlıyor: ${row.vergiNo || row.tcNo} / ${row.tutar} / ${row.belgeNo}`);
    const missing = validateRow(row);
    if (missing.length) throw new Error('Eksik alan: ' + missing.join(', '));
    await selectByText('Belge Türü', state.options.belgeTuru || 'Diğer');
    if (row.vergiNo) {
      const tc = findControlAfterLabel('T.C. Kimlik No') || findControlAfterLabel('TC Kimlik No');
      if (tc) setNativeValue(tc, '');
      await typeValue('Vergi Kimlik No', row.vergiNo);
    } else {
      const vn = findControlAfterLabel('Vergi Kimlik No');
      if (vn) setNativeValue(vn, '');
      await typeValue('T.C. Kimlik No', row.tcNo);
    }
    log('Ad/Soyad/Unvan dolması bekleniyor...');
    if (!(await waitForIdentityFilled())) throw new Error('Ad/Soyad/Unvan otomatik dolmadı.');
    await typeValue('Belge No', row.belgeNo);
    await typeValue('Tutar', row.tutar);
    await typeValue('Düzenleme Tarihi', row.tarih);
    await typeValue('Zaman Aşımı Başlangıç Tarihi', row.tarih);
    await selectByText('Emanet Türü', state.options.emanetTuru || '39 Diğer Çeşitli Emanetler');
    await clickButton('Emanet Ekle');
    await clickYesIfExists();
    await sleep(state.options.delay || 750);
    log(`Satır ${row.excelRow} eklendi kabul edildi.`);
    return { row: row.excelRow, status: 'Eklendi' };
  }
  async function runRows(rows, options) {
    if (state.running) return log('Zaten çalışıyor.');
    if (!rows.length) return setStatus('İşlenecek kayıt yok. Önce dosyayı oku.');
    injectConfirmOverride();
    state.running = true; state.paused = false; state.stopped = false; state.current = 0; state.total = rows.length; state.options = options || {}; state.results = [];
    updateButtons(); updateCounters(state.total, rows.length);
    setStatus(`Aktarım başladı. Kayıt sayısı: ${rows.length}.`);
    for (let i=0; i<rows.length; i++) {
      while (state.paused && !state.stopped) await sleep(300);
      if (state.stopped) break;
      state.current = i + 1; updateCounters(state.total, rows.length);
      try { state.results.push(await processRow(rows[i])); }
      catch (e) {
        log(`HATA - Excel satır ${rows[i]?.excelRow}: ${e.message}`);
        state.results.push({ row: rows[i]?.excelRow, status: 'Hata', message: e.message });
        if (state.options.stopOnError) break;
      }
    }
    state.running = false; updateButtons();
    if (!state.stopped && !state.options.noAutoSave) {
      try { await clickButton('Kaydet'); log('Kaydet butonuna basıldı.'); } catch (e) { log('Kaydet basılamadı: ' + e.message); }
    }
    setStatus('İşlem bitti. Sonuçlar log ekranında.');
    log('Sonuçlar: ' + JSON.stringify(state.results));
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      if (message.type === 'EVDB_EMANET_TOGGLE_PANEL') {
        const p = ensurePanel(true);
        p.style.display = p.style.display === 'none' ? 'block' : 'none';
        sendResponse({ ok:true });
      } else if (message.type === 'EVDB_EMANET_START') {
        state.preparedRows = message.rows || state.preparedRows;
        runRows(state.preparedRows, message.options || getOptions());
        sendResponse({ ok:true });
      } else if (message.type === 'EVDB_EMANET_PAUSE') { state.paused = true; updateButtons(); sendResponse({ ok:true }); }
      else if (message.type === 'EVDB_EMANET_RESUME') { state.paused = false; updateButtons(); sendResponse({ ok:true }); }
      else if (message.type === 'EVDB_EMANET_STOP') { state.stopped = true; state.running = false; updateButtons(); sendResponse({ ok:true }); }
    } catch (e) { sendResponse({ ok:false, error:e.message }); }
    return true;
  });

  // EVDB sayfasında pencere otomatik görünsün. Diğer sayfalarda ikonla açılabilir.
  if (/evdb|emanet|gib|intranet/i.test(location.href + ' ' + document.title)) ensurePanel(true);
})();
