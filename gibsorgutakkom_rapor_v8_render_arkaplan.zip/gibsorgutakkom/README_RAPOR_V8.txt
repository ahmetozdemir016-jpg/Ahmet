V8:
V7'deki visibility:hidden kaldırıldı. KEYS/GİB eski ekranı artık gerçekten render ediliyor.
Iframe tam ekran ölçüsünde ve opacity 0.001 ile görünmez; pointer-events kapalı.
Ana rapor ekranı iframe'in üstünde kalıyor.
Ama arka tarafta çalışan Gelen/Giden Evrak ekranı normal görünür ekran gibi layout/render
aldığı için evrak satırı -> OID -> ek listesi -> rapor/tutanak eşleştirme zinciri çalışabilir.
