Bu sürümde:
- Ana ekranda altta görünen bozuk JavaScript yazıları temizlendi.
- Rapor Kayıt Defteri Evrak Önizle ara penceresi kullanıcıya gösterilmez.
- Evrak ve ek listesi arka planda sorgulanır.
- Rapor/Tutanak No ile eşleşen ek bulununca doğrudan nihai PDF açılır.
- Ekler 1., 2., 3. sayfaya bölünmüş görünse de arama bütün ek listesinde yapılır.
