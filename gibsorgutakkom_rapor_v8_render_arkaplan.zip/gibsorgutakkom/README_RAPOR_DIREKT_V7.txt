V7 düzeltmesi:
- V6'da kullanılan 1x1/off-screen arka plan iframe kaldırıldı.
- Çalışan görünür Gelen/Giden Evrak akışıyla aynı tam ekran ölçüsünde çalışır,
  fakat visibility:hidden + opacity:0 ile kullanıcıya gösterilmez.
- Böylece satır oluşturma/otomatik evrak açma/ek listesi alma akışı görünür
  ekrandakiyle aynı şekilde çalışır.
- Nihai rapor/tutanak PDF bulunduğunda yalnız PDF penceresi gösterilir.
- Arama bütün ek listesinde yapılır; rapor 2. veya 3. sayfada görünen ekte de olabilir.
