function beyanname_getir_guncel(vkn,vdKodu,vergiKodu){
  
  var myRegex= /[0-9]+/;
  var tokenlink =$('#token').val();
  var myRegexp= /token=([^&\s]+)/;
  var token = myRegexp.exec(tokenlink)
  var callid=makeid(13) + '-';
 
   var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=bynIslemleriService_bynSorgula&callid=';
   var url5=url5.concat(callid + '25', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',vdKodu,'%22%2C%22vergiKodu%22%3A%22',vergiKodu,'%22%2C%22donemBas%22%3A%22%22%2C%22donemBit%22%3A%22%22%2C%22arsiv%22%3A%22T%22%7D');
   var beyanname = getRemote(url5);
   var __tmp=beyanname; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};
   var ip=obj.data.kullaniciIp;
   
   
   window.open('http://10.251.67.110:30080/ebyn/vdintraDispatch?SVERGINO='+vkn+'&VERGIKODU='+vergiKodu+'&VDKODU='+vdKodu+'&tD1yil=&tD2yil=&tD1ay=&tD2ay=' + '&ARSIV=F&BFORMUCIKAR=1&KESINMIZANCIKAR=1&cmd=BEYANNAMELISTESIVDO&origin=vdintra&USERID=tcnumaran&USERIP='+ ip + "'");
   
  
     
   
  }
  

function sifirSil(veri){

return veri.replace(".",","); 

}
// =====================
// 4) MYTABLE6: BEYAN / TAKDİR / FARK
// - Kullanıcı beyan ve takdir değerlerini TR formatında girer
// - blur olayında otomatik TR formatına çevrilir
// - FARK = Takdir - Beyan otomatik hesaplanır
// =====================
// ===== TR sayı formatı (1.000.000,56) + FARK otomatik (myTable6) =====
function __parseTrNumber__(s){
  if (s == null) return NaN;
  var t = String(s).trim();
  if (!t) return NaN;

  // Binlik ayırıcı noktaları kaldır, ondalık virgülü noktaya çevir
  t = t.replace(/\./g, '').replace(/,/g, '.');

  // Sadece rakam, nokta, eksi kalsın
  t = t.replace(/[^0-9.\-]/g, '');

  var n = parseFloat(t);
  return isNaN(n) ? NaN : n;
}

function __formatTrNumber__(n){
  if (n == null || isNaN(n)) return '';
  return Number(n).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function __updateMyTable6DiffForRow__(row){
  if (!row) return;

  var beyanEl  = row.querySelector('input.beyan-input');
  var takdirEl = row.querySelector('input.takdir-input');
  var farkEl   = row.querySelector('input.fark-output');

  if (!beyanEl || !takdirEl || !farkEl) return;

  var beyan  = __parseTrNumber__(beyanEl.value);
  var takdir = __parseTrNumber__(takdirEl.value);

  if (isNaN(beyan) || isNaN(takdir)) {
    farkEl.value = '';
    return;
  }

  var fark = takdir - beyan;
  farkEl.value = __formatTrNumber__(fark);
}

// Tablo sonradan üretildiği için event delegation:
document.addEventListener('input', function(e){
  var t = e.target;
  if (t && (t.classList.contains('beyan-input') || t.classList.contains('takdir-input'))) {
    __updateMyTable6DiffForRow__(t.closest('tr'));
  }
});

document.addEventListener('blur', function(e){
  var t = e.target;
  if (t && (t.classList.contains('beyan-input') || t.classList.contains('takdir-input'))) {
    var n = __parseTrNumber__(t.value);
    t.value = isNaN(n) ? '' : __formatTrNumber__(n);
    __updateMyTable6DiffForRow__(t.closest('tr'));
  }
}, true);

function sortTable(a) {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("myTable6");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 2; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[a].innerHTML;
      y = rows[i + 1].getElementsByTagName("TD")[a].innerHTML;
      //check if the two rows should switch place:
      if (x > y) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}

function sortTable1(a) {
  var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("myTable11");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[a].innerHTML;
      y = rows[i + 1].getElementsByTagName("TD")[a].innerHTML;
      //check if the two rows should switch place:
      if (x > y) {
        //if so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}


function gonulluUyum(vkn){

try{
var myRegex= /[0-9]+/;
var tokenlink =$('#token').val();
var myRegexp= /token=([^&\s]+)/;
var token = myRegexp.exec(tokenlink)
var callid=makeid(13) + '-';


//
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=gmsiGUyumService_vknTcknGoreIsinAdiniGetir&callid=';
	var url=url.concat(callid + '10', '&token=', _tok(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22uyumYili%22%3A%22%22%2C%22gonKonusu%22%3A%22%22%7D');
	var gonullu = getRemote(url);
	var __tmp=gonullu; var obj = (__tmp && __tmp!=='undefined') ? JSON.parse(__tmp) : {};
	var kayitSayisi2023=obj.data.gUyum2023Havuzu.length;
	var kayitSayisi2024=obj.data.gUyum2024Havuzu.length;
	var toplam=kayitSayisi2023+kayitSayisi2024;
	
	if (toplam>0){ return "VAR" ; }else{ return "YOK";}
	
}

catch(err){

return "Yetkiniz Yok / Hata ile Karşılaşıldı";

}	

}


function gunSayisiHesapla(yil1, ay1, gun1, yil2, ay2, gun2) {
  const tarih1 = new Date(yil1, ay1, gun1);
  const tarih2 = new Date(yil2, ay2, gun2);

  const farkMs = Math.abs(tarih2 - tarih1);
  const gunSayisi = Math.floor(farkMs / (1000 * 60 * 60 * 24));

  return gunSayisi;
}

function saveVdKodu() {
    var vdKodu = document.getElementById('vdKoduInput').value;
    if (vdKodu && vdKodu.trim() !== '') {
      localStorage.setItem('vdKodu', vdKodu.trim());
      document.getElementById('vdKoduModal').style.display = 'none';
      updateVdKoduDisplay();
    } else {
      alert('Lütfen geçerli bir vergi dairesi kodu giriniz!');
    }
  }

  // Sayfa yüklendiğinde localStorage'dan vergi dairesi kodunu kontrol et
  window.onload = function() {
    var savedVdKodu = localStorage.getItem('vdKodu');
    if (savedVdKodu) {
      document.getElementById('vdKoduInput').value = savedVdKodu;
      document.getElementById('vdKoduModal').style.display = 'none';
    }
    updateVdKoduDisplay();
  }

  // Vergi dairesi kodu görüntüsünü güncelle
  function updateVdKoduDisplay() {
    var currentVdKodu = vdKodu();
    var displayElement = document.getElementById('currentVdKodu');
    if (displayElement) {
      displayElement.textContent = currentVdKodu;
    }
  }

// Modal'ı göster
  function showVdKoduModal() {
    var savedVdKodu = localStorage.getItem('vdKodu');
    if (savedVdKodu) {
      document.getElementById('vdKoduInput').value = savedVdKodu;
    }
    document.getElementById('vdKoduModal').style.display = 'block';
  }

  // Enter tuşu ile kaydetme
  document.addEventListener('DOMContentLoaded', function() {
    var vdKoduInput = document.getElementById('vdKoduInput');
    if (vdKoduInput) {
      vdKoduInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
          saveVdKodu();
        }
      });
    }
  });
/* === Açıklama textarea yazdıkça otomatik büyüsün === */
document.addEventListener('input', function (e) {
  if (e.target && e.target.classList.contains('aciklama-textarea')) {
    const ta = e.target;
    ta.style.height = 'auto';                // sıfırla
    ta.style.height = ta.scrollHeight + 'px'; // içerik kadar büyüt
  }
});
