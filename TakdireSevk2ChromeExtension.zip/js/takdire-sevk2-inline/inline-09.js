// === GO85 FIX: "Beyanname Getir" eski (çalışan) mantığa döndürüldü ===
(function(){
  if(!window.jQuery) return;

  function tokAl(){
    try{
      if (window._tok && typeof window._tok === "function"){
        var t = window._tok();
        if (t) return String(t);
      }
    }catch(e){}
    try{
      var tokenlink = ($('#token').val()||'').trim();
      var m = /token=([^&\s]+)/.exec(tokenlink);
      return m ? m[1] : "";
    }catch(e){}
    return "";
  }

  function getRemoteSafe(url){
    // Bu projede genelde fonksiyon.js içindeki getRemote kullanılıyor.
    if (window.getRemote && typeof window.getRemote === "function") return window.getRemote(url);
    // yoksa jQuery ile senkron çekmeye çalışmayalım; kullanıcıda zaten getRemote var.
    throw new Error("getRemote fonksiyonu bulunamadı (fonksiyon.js yüklenmemiş olabilir).");
  }

  $(function(){
    var el = document.getElementById('go85');
    if(!el) return;

    // Çift açılmayı önlemek için inline onclick varsa temizle
    try{ el.onclick=null; el.removeAttribute('onclick'); }catch(e){}

    // eski event'leri temizle
    var $el = $(el);
    var $clone = $el.clone(false);
    $el.replaceWith($clone);

    $('#go85').on('click', function(e){
      e.preventDefault(); e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();

      var callid = (window.makeid ? window.makeid(13) : (Math.random().toString(36).slice(2,15))) + '-';
      var vergiDairesi = prompt("Vergi Dairesi Kodunu Giriniz (Örnek:016253)", (window.vdKodu ? window.vdKodu() : "") );
      if (vergiDairesi === null) return false;

      var vergiKodu = prompt("Vergi Kodunu Giriniz (Örnek:0001 yada 0015)", "0015");
      if (vergiKodu === null) return false;

      var vkn = ($('#input').val()||'').trim();
      if(!vkn){ alert("VKN/TCKN giriniz."); return false; }

      var t = tokAl();
      if(!t){ alert("Token bulunamadı."); return false; }

      try{
        var url5 = 'http://10.251.63.99/gibintranet_server/dispatch?cmd=bynIslemleriService_bynSorgula&callid=';
        url5 = url5.concat(callid + '25', '&token=', encodeURIComponent(t),
          '&jp=%7B%22vkn%22%3A%22', encodeURIComponent(vkn),
          '%22%2C%22vdKodu%22%3A%22', encodeURIComponent(vergiDairesi),
          '%22%2C%22vergiKodu%22%3A%22', encodeURIComponent(vergiKodu),
          '%22%2C%22donemBas%22%3A%22%22%2C%22donemBit%22%3A%22%22%2C%22arsiv%22%3A%22T%22%7D'
        );

        var beyanname = getRemoteSafe(url5);
        var obj = (typeof beyanname === 'string') ? JSON.parse(beyanname) : beyanname;
        var ip = obj && obj.data ? obj.data.kullaniciIp : '';
        if(!ip){ console.warn("kullaniciIp alınamadı", obj); }

        var openUrl =
          'http://10.251.67.110:30080/ebyn/vdintraDispatch?SVERGINO=' + encodeURIComponent(vkn) +
          '&VERGIKODU=' + encodeURIComponent(vergiKodu) +
          '&VDKODU=' + encodeURIComponent(vergiDairesi) +
          '&tD1yil=&tD2yil=&tD1ay=&tD2ay=&ARSIV=F&BFORMUCIKAR=1&KESINMIZANCIKAR=1&cmd=BEYANNAMELISTESIVDO&origin=vdintra&USERID=tcnumaran&USERIP=' + encodeURIComponent(ip);

        window.open(openUrl, '_blank');
      }catch(err){
        console.error(err);
        alert("Beyanname Getir çalışırken hata: " + (err && err.message ? err.message : err));
      }

      return false;
    });
  });
})();
