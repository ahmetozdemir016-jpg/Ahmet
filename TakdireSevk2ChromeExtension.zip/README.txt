Takdire Sevk 2 Bot - Chrome Eklentisi

Kurulum:
1) Chrome adres çubuğuna chrome://extensions yazın.
2) Sağ üstten Geliştirici modu'nu açın.
3) Paketlenmemiş öğe yükle'ye basın.
4) Bu klasörü seçin: TakdireSevk2ChromeExtension

Kullanım:
- Yeni sekme / boş sayfa açıldığında takdire-sevk2.html otomatik açılır.
- Dosya, js klasörüyle birlikte eklenti içine alınmıştır.

Notlar:
- Manifest V3 inline script engellediği için takdire-sevk2.html içindeki script blokları js/takdire-sevk2-inline/ altına çıkarıldı.
- Eski inline onclick komutları js/takdire-sevk2-csp-handlers.js üzerinden çalıştırılır.
- GİB intranet servisleri için host_permissions eklendi. Kurum ağı dışında bu servisler cevap vermeyebilir.
