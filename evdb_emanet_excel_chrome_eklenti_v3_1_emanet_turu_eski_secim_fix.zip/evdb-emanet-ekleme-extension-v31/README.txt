EVDB Emanet Excel Chrome Eklentisi v3.1

Bu sürüm v3.0 akışını korur; Emanet Türü seçimini eski çalışan 39 seçme mantığıyla güçlendirir.

Yeni eklenen / düzeltilen davranış:
- Emanet Türü Excel’den okunmaya devam eder; fakat seçim yaparken v2.8’de 39 için çalışan eski liste açma + satır metnine koordinattan tıklama mantığı kullanılır.
- 33 / 39 / 44 için kod ve metin alternatifleriyle aranır; gerekirse açılan listenin kendi kaydırma alanı taranır.

- Excel Emanet_Rapor sayfasındaki Emanet Türü sütununu okur.
  - 44 Vergi Teminatları
  - 33 Kişilere Ait Diğer Emanetler
  - 39 Diğer Çeşitli Emanetler
- Plaka No sütunu doluysa EVDB Plaka No alanına yazar.
- Plaka No sütunu boşsa açıklamadan plaka aramaz; EVDB Plaka No alanını boş bırakır.
- Emanet Türü sütunu boşsa açıklamaya göre otomatik belirler:
  - D.F.I.F / DFIF geçenler: 33 Kişilere Ait Diğer Emanetler
  - Teminat geçenler: 44 Vergi Teminatları
  - Diğerleri: 39 Diğer Çeşitli Emanetler
- BORCNO:...;VKN:10140122630 formatında gelen 11 haneli VKN bilgisi T.C. No gibi değerlendirilir.

Korunan özellikler:
- TC No / Vergi No yazıldıktan sonra Ad/Soyad/Unvan gelmezse birkaç kez boş alan tıklamasıyla sorguyu tetikler.
- Yine gelmezse Emanet Bilgilerini Temizle yapar, aynı satırı bir kez daha dener.
- İkinci denemede de bilgi gelmezse Fiş No ile Ad/Soyad gelmeyen / sorgu sonuçsuz olarak sayar ve sonraki kayda geçer.
- Her başarılı Emanet Ekle + Evet sonrasında üstteki Emanet Bilgilerini Temizle yapılır.
- Boş TC/VKN, hatalı kimlik, mükellef bulunamadı, emanette mevcut, çıkış/aktarım kayıtlarını Fiş No ile raporlayıp atlar.
- Başarılı kayıtları hatırlar ve aynı Excel tekrar seçildiğinde kaldığı yerden devam eder.

Kurulum:
1. Chrome > chrome://extensions açın.
2. Eski eklentiyi kaldırın.
3. Geliştirici modunu açın.
4. Paketlenmemiş öğe yükle seçin.
5. evdb-emanet-ekleme-extension-v31 klasörünü seçin.
