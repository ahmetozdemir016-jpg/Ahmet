(() => {
  if (window.__istakipPageHookV455) return;
  window.__istakipPageHookV455 = true;
  const currentScript = document.currentScript;
  const EVT = (currentScript && currentScript.dataset && currentScript.dataset.evt) || '__ISTAKIP_BOT_V4_DISCOVERY__';
  let networkHookStopped = false;
  let stopNetworkHook = null;
  const send = (obj) => { try { window.postMessage(Object.assign({ type: EVT }, obj || {}), '*'); } catch (_) {} };
  const parseJson = (txt) => {
    try {
      if (!txt || typeof txt !== 'string') return null;
      txt = txt.trim();
      if (!txt || (txt[0] !== '{' && txt[0] !== '[')) return null;
      return JSON.parse(txt);
    } catch (_) { return null; }
  };
  let pendingModule = '';
  const guessModuleFromUrl = (url) => {
    const s = String(url || '').toLowerCase();
    if (s.includes('/istakip') || s.includes('istakip_server')) return 'istakip';
    if (s.includes('/evdo') || s.includes('evdo_server')) return 'evdo';
    if (s.includes('edenetis') || s.includes('eyoklama')) return 'e';
    if (s.includes('gibintranet')) return 'g';
    if (s.includes('/gp') || s.includes('gp_server')) return 'gp';
    return '';
  };
  const deepCollect = (obj, out = {}, depth = 0, seen = new WeakSet()) => {
    try {
      if (!obj || typeof obj !== 'object' || depth > 6) return out;
      if (seen.has(obj)) return out;
      seen.add(obj);
      const pick = (key, val) => {
        if (val === undefined || val === null || val === '') return;
        const k = String(key || '').toLowerCase();
        const v = typeof val === 'string' ? val.trim() : val;
        if (!v) return;
        if (!out.token && k === 'token') out.token = v;
        if (!out.orgoid && k === 'orgoid') out.orgoid = v;
        if (!out.userId && /^(userid|kullanicikodu|atamayapankullaniciuserid|islemyapanuserid)$/i.test(String(key))) out.userId = v;
        if (!out.moduleName && /^(moduladi|modulename|module|modul)$/i.test(String(key))) out.moduleName = v;
      };
      if (Array.isArray(obj)) {
        for (const item of obj) deepCollect(item, out, depth + 1, seen);
        return out;
      }
      for (const [k, v] of Object.entries(obj)) {
        pick(k, v);
        if (typeof v === 'string') {
          const j = parseJson(v);
          if (j) deepCollect(j, out, depth + 1, seen);
        } else if (v && typeof v === 'object') {
          deepCollect(v, out, depth + 1, seen);
        }
      }
    } catch (_) {}
    return out;
  };
  const learn = (obj, source, cmd = '') => {
    try {
      if (!obj || typeof obj !== 'object') return;
      const found = deepCollect(obj, {});
      let moduleName = (found.moduleName || '').trim();
      if (!moduleName) moduleName = pendingModule || '';
      send({ token: found.token || '', userId: found.userId || '', orgoid: found.orgoid || '', moduleName, cmd, source, payload: obj });
      if (/assos-login-response/i.test(source) && found.token) {
        send({ token: found.token, moduleName: moduleName || '', cmd, source: source + ':module-bound', payload: { moduleName: moduleName || '', token: found.token } });
      }
      if (obj.jp && typeof obj.jp === 'string') {
        const jp = parseJson(obj.jp);
        if (jp) learn(jp, source + ':jp', cmd);
      }
    } catch (_) {}
  };
  const inspectBody = (body, source, url = '') => {
    try {
      if (networkHookStopped) return;
      const urlModule = guessModuleFromUrl(url);
      if (!body) return;
      if (typeof body === 'string') {
        const usp = new URLSearchParams(body);
        if ([...usp.keys()].length) {
          const cmd = usp.get('cmd') || '';
          const token = usp.get('token') || '';
          const jpText = usp.get('jp') || '';
          let jp = null;
          if (jpText) jp = parseJson(jpText);
          let moduleName = (jp && (jp.moduleName || jp.modulAdi || jp.module || '')) || urlModule || '';
          if (!moduleName && /istakip/i.test(location.href)) moduleName = 'istakip';
          if (moduleName) pendingModule = moduleName;
          if (token || jp) send({ token, cmd, source: source + ':form-combined', moduleName, payload: jp || {} });
          if (token) send({ token, source: source + ':form-token', cmd, moduleName });
          if (jp) learn(jp, source + ':form-jp', cmd);
        } else {
          const j = parseJson(body);
          if (j) learn(j, source + ':json-body', '');
        }
      } else if (body instanceof URLSearchParams) {
        inspectBody(body.toString(), source, url);
      } else if (typeof FormData !== 'undefined' && body instanceof FormData) {
        const o = {};
        for (const [k, v] of body.entries()) o[k] = v;
        let moduleName = urlModule || '';
        if (typeof o.jp === 'string') {
          const jp = parseJson(o.jp);
          if (jp) {
            moduleName = moduleName || jp.moduleName || jp.modulAdi || jp.module || '';
            if (moduleName) pendingModule = moduleName;
            send({ token: o.token || '', cmd: o.cmd || '', source: source + ':formdata-combined', moduleName, payload: jp });
          }
        }
        learn(o, source + ':formdata', o.cmd || '');
      }
    } catch (_) {}
  };


  let lastEysPageCaller = null;

  const rememberEysPageCaller = (name, obj, serviceName) => {
    try {
      if (!obj || typeof obj.call !== 'function') return;
      lastEysPageCaller = { name: name || 'captured-page', obj, serviceName: serviceName || '', at: Date.now() };
      window.__istakipEysPageCaller = obj;
      send({
        source: 'page-call-capture',
        payload: {
          captured: true,
          caller: lastEysPageCaller.name,
          serviceName: lastEysPageCaller.serviceName,
          pageSession: getSessionDataFromPage ? getSessionDataFromPage() : {}
        }
      });
    } catch (_) {}
  };

  const patchLibEDenetisPageCaller = () => {
    try {
      const lib = window.libEDenetis;
      if (!lib || typeof lib.serviceCall !== 'function' || lib.__istakipServiceCallPatched) return !!lastEysPageCaller;
      const orig = lib.serviceCall;
      Object.defineProperty(lib, '__istakipServiceCallPatched', { value: true, configurable: true });
      lib.serviceCall = function(page, serviceName, parameters, returnFunc, errorFunc) {
        rememberEysPageCaller('libEDenetis.serviceCall.page', page, serviceName);
        return orig.apply(this, arguments);
      };
      send({ source: 'page-call-capture', payload: { patched: 'libEDenetis.serviceCall' } });
      return true;
    } catch (_) {
      return false;
    }
  };

  const startLibEDenetisPatchLoop = () => {
    try {
      patchLibEDenetisPageCaller();
      let n = 0;
      const timer = setInterval(() => {
        n += 1;
        const ok = patchLibEDenetisPageCaller();
        if (ok || n > 40) clearInterval(timer);
      }, 250);
    } catch (_) {}
  };


  const PAGE_CALL_REQ = '__ISTAKIP_EYS_PAGE_CALL__';
  const PAGE_CALL_RES = '__ISTAKIP_EYS_PAGE_CALL_RESULT__';
  const CS_CALL_REQ = '__ISTAKIP_EYS_CS_CALL__';
  const CS_CALL_RES = '__ISTAKIP_EYS_CS_CALL_RESULT__';

  const getSessionDataFromPage = () => {
    try {
      const C = window.CSSession || {};
      const get = (k) => {
        try { return C && typeof C.get === 'function' ? String(C.get(k) || '').trim() : ''; } catch (_) { return ''; }
      };
      return {
        rol: get('EOSROL'),
        user: get('EOSUSER'),
        giris: get('EOSUSERGIRIS') || get('EOSUSER'),
        birim: get('EOSBIRIMKODU'),
        il: get('EOSDEFILKODU') || String(get('EOSBIRIMKODU') || '').slice(0, 3),
        adi: get('EOSADI'),
        userx: get('EOSUSERGIRISX') || get('EOSUSER')
      };
    } catch (_) {
      return {};
    }
  };


  const PAGE_SESSION_REQ = '__ISTAKIP_EYS_SESSION_REQUEST__';
  const STOP_HOOK_REQ = '__ISTAKIP_EYS_STOP_HOOK__';
  const postEysPageSession = (source = 'page-session-probe') => {
    try {
      const payload = getSessionDataFromPage() || {};
      window.postMessage({ type: 'ISTAKIP_EYS_PAGE_SESSION', payload }, '*');
      send({ source, payload: { pageSession: payload } });
    } catch (_) {}
  };

  window.addEventListener('message', (event) => {
    try {
      if (event.source !== window) return;
      const data = event.data || {};
      if (data.type === PAGE_SESSION_REQ) postEysPageSession('page-session-request');
      if (data.type === STOP_HOOK_REQ && typeof stopNetworkHook === 'function') stopNetworkHook(data.reason || 'content-request');
    } catch (_) {}
  });

  postEysPageSession('page-session-mainworld-start');
  setTimeout(() => postEysPageSession('page-session-mainworld-250'), 250);
  setTimeout(() => postEysPageSession('page-session-mainworld-900'), 900);
  setTimeout(() => postEysPageSession('page-session-mainworld-2500'), 2500);
  setTimeout(() => postEysPageSession('page-session-mainworld-6000'), 6000);

  const findEysPageCaller = () => {
    try {
      patchLibEDenetisPageCaller();
      if (lastEysPageCaller && lastEysPageCaller.obj && typeof lastEysPageCaller.obj.call === 'function') {
        return { score: 999, name: lastEysPageCaller.name || 'captured-page', obj: lastEysPageCaller.obj };
      }
      if (window.__istakipEysPageCaller && typeof window.__istakipEysPageCaller.call === 'function') {
        return { score: 998, name: 'window.__istakipEysPageCaller', obj: window.__istakipEysPageCaller };
      }
    } catch (_) {}
    const scored = [];
    const scoreCandidate = (name, obj) => {
      try {
        if (!obj || typeof obj !== 'object' || typeof obj.call !== 'function') return;
        const text = [
          name,
          obj.$CS$ && obj.$CS$.definition && obj.$CS$.definition.BF_NAME,
          obj.definition && obj.definition.BF_NAME,
          obj.moduleName,
          obj.bfName,
          obj.name
        ].map(x => String(x || '')).join(' ');
        let score = 1;
        if (/edenetis|yoklama|yoklamatalebi|e\./i.test(text)) score += 20;
        if (/^page$/i.test(name)) score += 10;
        scored.push({ score, name, obj });
      } catch (_) {}
    };

    for (const k of ['page', 'Page', 'ePage', 'edenetisPage', 'yoklamaPage']) {
      try { scoreCandidate(k, window[k]); } catch (_) {}
    }

    try {
      for (const k of Object.keys(window)) {
        if (scored.length > 40) break;
        try { scoreCandidate(k, window[k]); } catch (_) {}
      }
    } catch (_) {}

    scored.sort((a, b) => b.score - a.score);
    return scored[0] || null;
  };

  const getEysDispatchUrlFromPage = () => {
    try {
      if (window.SideModuleManager && typeof SideModuleManager.getAppUrl === 'function') {
        return SideModuleManager.getAppUrl('e', '/edenetis/dispatch') || SideModuleManager.getAppUrl('e', 'edenetis/dispatch') || '';
      }
    } catch (_) {}
    return '';
  };

  const REQUIRED_HOOK_TOKEN_MODULES = ['gp', 'g', 'istakip', 'evdo', 'e'];

  const moduleFromTokenSource = (source) => {
    const s = String(source || '');
    let m = '';
    const m1 = s.match(/CSSession\.getToken\((?:module:)?([^\)]+)\)/i);
    if (m1) m = m1[1];
    if (!m) {
      const m2 = s.match(/getToken[:\s]+(gp|g|istakip|evdo|e)\b/i);
      if (m2) m = m2[1];
    }
    m = String(m || '').replace(/^module:/i, '').trim().toLowerCase();
    if (m === 'eys' || m.includes('edenetis')) return 'e';
    if (m.includes('istakip')) return 'istakip';
    if (m.includes('evdo') || m.includes('evdb')) return 'evdo';
    if (m === 'gp' || m === 'g' || m === 'e') return m;
    return '';
  };

  const pageTokensHaveAllRequiredModules = (tokens) => {
    try {
      const found = {};
      for (const item of tokens || []) {
        const token = String(item && item.token || '').trim();
        const moduleName = moduleFromTokenSource(item && item.source || '');
        if (token && moduleName) found[moduleName] = true;
      }
      return REQUIRED_HOOK_TOKEN_MODULES.every(m => found[m]);
    } catch (_) { return false; }
  };

  const maybeStopNetworkHookAfterAllTokens = (tokens, reason = 'all-module-tokens-captured') => {
    // v4.31.124: EVDB Rapor /evdorapor_server/assos-login daha geç açılabiliyor.
    // Bu yüzden tokenler tamamlandı diye hook otomatik kapanmasın; yalnızca içerik scripti açıkça durdurursa kapanır.
    return;
  };

  const collectEysTokensFromPage = () => {
    const tokens = [];
    const push = (v, source) => {
      const s = String(v || '').trim();
      if (s && !tokens.some(x => x.token === s)) tokens.push({ token: s, source });
    };
    try {
      const C = window.CSSession || {};
      if (C && typeof C.getToken === 'function') {
        try { push(C.getToken(), 'CSSession.getToken()'); } catch (_) {}
        for (const arg of ['e', 'edenetis', 'g', 'gp']) {
          try { push(C.getToken(arg), 'CSSession.getToken(' + arg + ')'); } catch (_) {}
        }
        try {
          const mods = window.SideModuleManager && typeof SideModuleManager.getModules === 'function' ? SideModuleManager.getModules() : {};
          for (const [k, v] of Object.entries(mods || {})) {
            try { push(C.getToken(v), 'CSSession.getToken(module:' + k + ')'); } catch (_) {}
          }
        } catch (_) {}
      }
    } catch (_) {}
    try { maybeStopNetworkHookAfterAllTokens(tokens, 'all-module-tokens-captured'); } catch (_) {}
    return tokens;
  };



  const getEysAppUrlForCSCaller = (moduleName) => {
    moduleName = moduleName || 'e';
    try {
      if (window.SideModuleManager && typeof SideModuleManager.getAppUrl === 'function') {
        return SideModuleManager.getAppUrl(moduleName) || SideModuleManager.getAppUrl(moduleName, undefined) || SideModuleManager.getAppUrl(moduleName, '/edenetis/dispatch') || '';
      }
    } catch (_) {}
    try {
      return moduleName === 'e' ? 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch' : '';
    } catch (_) { return ''; }
  };

  const getLocalModuleNameSafe = () => {
    try {
      if (window.SideModuleManager && typeof SideModuleManager.getLocalModuleName === 'function') {
        return SideModuleManager.getLocalModuleName() || '';
      }
    } catch (_) {}
    try {
      if (/\/gibintranet\//i.test(location.pathname)) return 'g';
      if (/\/gp\//i.test(location.pathname)) return 'gp';
    } catch (_) {}
    return '';
  };

  const callEysServiceWithCSCaller = (cmd, payload, moduleName, requestId) => {
    const requestedModuleName = String(moduleName || '').trim();
    const useLocalDispatch = !requestedModuleName || requestedModuleName === '__local__' || requestedModuleName === 'local' || requestedModuleName === 'auto' || requestedModuleName === 'g-local';
    const localModuleName = getLocalModuleNameSafe();
    moduleName = useLocalDispatch ? (localModuleName || 'g') : (requestedModuleName || 'e');
    payload = (payload && typeof payload === 'object') ? Object.assign({}, payload) : {};
    if (!payload.sessionData) {
      try {
        if (window.libEDenetis && typeof libEDenetis.getSessionData === 'function') payload.sessionData = libEDenetis.getSessionData();
      } catch (_) {}
      if (!payload.sessionData) payload.sessionData = getSessionDataFromPage();
    }

    const pageSession = getSessionDataFromPage();
    const url = useLocalDispatch ? '' : getEysAppUrlForCSCaller(moduleName);
    const finish = (ok, extra) => {
      send(Object.assign({
        type: CS_CALL_RES,
        requestId,
        ok,
        cmd,
        moduleName,
        requestedModuleName,
        useLocalDispatch,
        dispatchUrl: url,
        pageSession,
        tokens: collectEysTokensFromPage()
      }, extra || {}));
    };

    try {
      if (!window.CSCaller || typeof CSCaller.call !== 'function') {
        finish(false, { error: 'CSCaller.call bulunamadı' });
        return;
      }
      const config = { showMessages: false };
      if (!useLocalDispatch && moduleName) config.module = moduleName;
      if (!useLocalDispatch && url) config.url = url;
      const ret = CSCaller.call(cmd, payload, config);
      if (!ret || typeof ret.then !== 'function') {
        finish(false, { error: 'CSCaller.call dönüş nesnesi beklenen yapıda değil' });
        return;
      }
      const chained = ret.then(function(data, messages, metadata) {
        finish(true, {
          response: { data: data, messages: messages || [], metadata: metadata || null },
          data: data,
          messages: messages || [],
          metadata: metadata || null
        });
      });
      if (chained && typeof chained.error === 'function') {
        chained.error(function(messages, thrown) {
          finish(false, {
            error: (messages && messages[0] && (messages[0].text || messages[0].message)) || (thrown && thrown.message) || String(thrown || 'CSCaller error'),
            response: { messages: messages || [], thrown: thrown ? String(thrown) : '' }
          });
        });
      }
    } catch (err) {
      finish(false, { error: err && err.message ? err.message : String(err) });
    }
  };

  window.addEventListener('message', (event) => {
    try {
      if (event.source !== window) return;
      const data = event.data || {};
      if (data.type !== CS_CALL_REQ) return;
      callEysServiceWithCSCaller(String(data.cmd || ''), data.payload || {}, data.moduleName || 'e', String(data.requestId || ''));
    } catch (err) {
      try {
        send({ type: CS_CALL_RES, requestId: event && event.data ? event.data.requestId : '', ok: false, error: err && err.message ? err.message : String(err) });
      } catch (_) {}
    }
  });


  startLibEDenetisPatchLoop();

  window.addEventListener('message', (event) => {
    try {
      if (event.source !== window) return;
      const data = event.data || {};
      if (data.type !== PAGE_CALL_REQ) return;

      const requestId = String(data.requestId || '');
      const cmd = String(data.cmd || '');
      const payload = (data.payload && typeof data.payload === 'object') ? Object.assign({}, data.payload) : {};
      if (!payload.sessionData) payload.sessionData = getSessionDataFromPage();

      const caller = findEysPageCaller();
      if (!caller || !caller.obj) {
        send({
          type: PAGE_CALL_RES,
          requestId,
          ok: false,
          error: 'EYS page.call nesnesi bulunamadı',
          pageSession: getSessionDataFromPage(),
          dispatchUrl: getEysDispatchUrlFromPage(),
          tokens: collectEysTokensFromPage()
        });
        return;
      }

      let ret;
      try {
        ret = caller.obj.call(cmd, payload, { progress: 'Lütfen bekleyiniz..' });
      } catch (err) {
        send({
          type: PAGE_CALL_RES,
          requestId,
          ok: false,
          error: err && err.message ? err.message : String(err),
          caller: caller.name,
          pageSession: getSessionDataFromPage(),
          dispatchUrl: getEysDispatchUrlFromPage(),
          tokens: collectEysTokensFromPage()
        });
        return;
      }

      const done = (resp) => send({
        type: PAGE_CALL_RES,
        requestId,
        ok: true,
        response: resp,
        caller: caller.name,
        pageSession: getSessionDataFromPage(),
        dispatchUrl: getEysDispatchUrlFromPage(),
        tokens: collectEysTokensFromPage()
      });
      const fail = (err) => send({
        type: PAGE_CALL_RES,
        requestId,
        ok: false,
        error: err && err.message ? err.message : String(err),
        response: err,
        caller: caller.name,
        pageSession: getSessionDataFromPage(),
        dispatchUrl: getEysDispatchUrlFromPage(),
        tokens: collectEysTokensFromPage()
      });

      if (ret && typeof ret.then === 'function') {
        try {
          const p = ret.then(done);
          if (p && typeof p.error === 'function') p.error(fail);
          else if (p && typeof p.catch === 'function') p.catch(fail);
          else if (ret && typeof ret.error === 'function') ret.error(fail);
        } catch (err) {
          fail(err);
        }
      } else {
        done(ret);
      }
    } catch (err) {
      try {
        send({
          type: PAGE_CALL_RES,
          requestId: event && event.data ? event.data.requestId : '',
          ok: false,
          error: err && err.message ? err.message : String(err)
        });
      } catch (_) {}
    }
  });

  setTimeout(() => {
    try {
      send({
        source: 'page-runtime-probe',
        payload: {
          pageSession: getSessionDataFromPage(),
          dispatchUrl: getEysDispatchUrlFromPage(),
          tokens: collectEysTokensFromPage(),
          hasPageCaller: !!findEysPageCaller(), hasCSCaller: !!(window.CSCaller && typeof CSCaller.call === 'function'), lastCapturedPageCaller: lastEysPageCaller ? { name: lastEysPageCaller.name, serviceName: lastEysPageCaller.serviceName, at: lastEysPageCaller.at } : null
        }
      });
    } catch (_) {}
  }, 800);


  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = async function (...args) {
      try {
        const [input, init] = args;
        const url = typeof input === 'string' ? input : input?.url || '';
        const body = init?.body || (typeof input !== 'string' ? input?.body : undefined);
        if (!networkHookStopped && /dispatch|assos-login|index\.jsp/i.test(url)) inspectBody(body, 'page-fetch:' + url, url);
      } catch (_) {}
      const res = await origFetch.apply(this, args);
      try {
        const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
        if (!networkHookStopped && /dispatch|assos-login/i.test(url)) {
          const clone = res.clone();
          clone.text().then(txt => {
            const j = parseJson(txt);
            if (j) {
              const src = /assos-login/i.test(url) ? 'assos-login-response:' + url : 'page-fetch-response:' + url;
              learn(j.data || j, src, '');
            }
          }).catch(() => {});
        }
      } catch (_) {}
      return res;
    };
  }
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  stopNetworkHook = (reason = 'stop') => {
    try { networkHookStopped = true; } catch (_) {}
    try { if (origFetch) window.fetch = origFetch; } catch (_) {}
    try { XMLHttpRequest.prototype.open = origOpen; } catch (_) {}
    try { XMLHttpRequest.prototype.send = origSend; } catch (_) {}
    try { send({ source: 'page-hook-stopped', payload: { reason } }); } catch (_) {}
  };
  // v4.31.124: 10 saniyede otomatik kapatma kaldırıldı; EVDB Rapor tokeni yakalanana kadar XHR/fetch hook açık kalır.
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__it_v411_url = url;
    return origOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (!networkHookStopped && /dispatch|assos-login|index\.jsp/i.test(this.__it_v411_url || '')) inspectBody(body, 'page-xhr:' + this.__it_v411_url, this.__it_v411_url);
      this.addEventListener('load', () => {
        try {
          if (!networkHookStopped && /dispatch|assos-login/i.test(this.__it_v411_url || '')) {
            const j = parseJson(this.responseText);
            if (j) {
              const src = /assos-login/i.test(this.__it_v411_url || '') ? 'assos-login-response:' + this.__it_v411_url : 'page-xhr-response:' + this.__it_v411_url;
              learn(j.data || j, src, '');
            }
          }
        } catch (_) {}
      });
    } catch (_) {}
    return origSend.call(this, body);
  };
  send({ source: 'page-hook', payload: { ready: true, stopWhenAllTokens: [], autoStopMs: 0, keepUntilEvdbRaporAsosLogin: true } });
})();
