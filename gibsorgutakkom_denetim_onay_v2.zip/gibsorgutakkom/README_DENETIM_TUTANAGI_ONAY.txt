DENETİM TUTANAĞI – YOKLAMA ONAY (İŞLEM BEKLEYEN DENETİMLER) TOPLU İŞLEM EKRANI

Ana ekranda "Denetim Tutanağı – Yoklama Onay (toplu arşiv/iade)" düğmesi
diger/denetim-tutanagi-onay.html sayfasını açar. Sayfa KEYS'teki
"Denetim Tutanağı Düzenlenen Mükellefler / İşlem Bekleyen Denetimler"
listesini tüm sayfalarıyla çeker; Öneri / İşlem / Düzenleyen filtreleri,
VKN-ünvan arama, tik kutuları ile seçim ve seçilenlere toplu
"Kontrol Edildi (arşive kaldır)" veya "İade Et" uygular. İşlemler KEYS
akışındaki gibi tek tek, satır satır gönderilir; ilerleme çubuğu ve her
satırın sonucu tabloda gösterilir. Satır başındaki "Sonuç" / "Ek"
düğmeleri yoklama sonucunu ve ekini açar.

İLK KULLANIM – SERVİSLERİ ÖĞRETME (bir kez)
Bu ekranın KEYS'te hangi servisleri çağırdığı elimizde olmadığından sayfa
bunları Token Dinleyici uzantısının istek kayıtlarından öğrenir:
1. KEYS'te ekranı açın, "Listeyi Yenile"ye basın.
2. Bir satırda sağ tık > Sonuç Göster, sonra Sonuç Ek Göster yapın.
3. Gerçekten arşive kaldırılacak bir satırda "Kontrol Edildi", gerçekten
   iade edilecek bir satırda "İade Et" yapın (KEYS'te uygulanır).
4. TAKKOM sayfasında "Yakalanan İsteklerden Servisleri Öğren"e basın,
   listede her isteğe rolünü seçip Kaydet'e basın. Roller otomatik
   tahmin edilir; emin olmadığınız satırı boş bırakın.
5. "Listeyi Getir"e basın. Sayfa öğrenilen işlem parametrelerinde hangi
   değerin satıra özgü olduğunu (oid vb.) listeden bularak eşler.
   Eşleme bulunamadıysa öğretilen satır listede yok demektir; tekrar
   öğretin veya Servis Ayarları'nda "map" alanını elle girin.

Öğrenilen servisler tarayıcıda (takkom_denetim_onay_servis_v1) saklanır.
"Servis Ayarları" JSON'unu "Kopyala" ile paylaşırsanız servis adları
sonraki sürümde sayfaya sabit olarak yazılabilir.

NOTLAR
- Token: gibintranet tokeni (takdire-sevk menüsünden açınca gelir).
- "Bekleme (ms)" iki istek arasındaki beklemedir (varsayılan 400).
- İade Et parametrelerinde neden/açıklama alanı varsa toplu iadede sorulur.
- Sonuç / Ek açmada cevaptaki PDF (base64), URL veya öğrenme sırasında
  yakalanan görüntüleme adresi kullanılır; hiçbiri yoksa ham cevap gösterilir.

VKN ARALIĞI VE SIRALAMA
- Filtre kutusundaki "VKN aralığı" alanlarına başlangıç/bitiş yazılınca
  yalnızca o aralıktaki satırlar gösterilir (VKN boşsa TCKN kullanılır).
  Aralık, "Görünenlerin tümünü seç" ile birlikte toplu işlem için de geçerlidir.
- "VKN'ye göre sırala" düğmesi veya VKN sütun başlığı listeyi rakamsal
  olarak sıralar; ikinci tıklama ters çevirir.
