EVDB Emanet Excel Bot v1.4

Fix: Onay penceresinde Evet tıklama güçlendirildi; Emanet Ekle sonrası üst form temizlenmeden ikinci satıra geçmez. Bot sadece eklenti ikonuna basınca açılır.


v1.7: v1.5 referans alındı; TC girildikten sonra Vergi Kimlik No alanına tıklayarak EVDB sorgusu tetiklenir.
