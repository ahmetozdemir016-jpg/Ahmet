EVDB Emanet Excel Bot v1.4

Fix: Onay penceresinde Evet tıklama güçlendirildi; Emanet Ekle sonrası üst form temizlenmeden ikinci satıra geçmez. Bot sadece eklenti ikonuna basınca açılır.
