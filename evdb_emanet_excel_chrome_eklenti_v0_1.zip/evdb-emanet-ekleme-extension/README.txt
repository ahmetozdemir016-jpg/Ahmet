EVDB Emanet Excel Aktarım Botu - Chrome Eklentisi

KURULUM
1) Zip dosyasını bir klasöre çıkarın.
2) Chrome adres çubuğuna chrome://extensions yazın.
3) Sağ üstten Geliştirici modu açın.
4) Paketlenmemiş öğe yükle butonuna basın.
5) Zipten çıkardığınız evdb-emanet-ekleme-extension klasörünü seçin.

KULLANIM
1) EVDB'de Emanet MİF(A) > Emanet Bilgileri ekranını açın.
2) Chrome sağ üstteki EVDB Emanet Botu simgesine tıklayın.
3) Excel dosyasını seçin. Dosyada Emanet_Rapor sayfası olmalı.
4) Dosyayı Oku butonuna basın.
5) Başlat butonuna basın.

İŞ AKIŞI
Her Excel satırı için:
- Belge Türü: Diğer seçilir.
- Vergi No varsa Vergi Kimlik No alanına yazılır.
- Vergi No yoksa T.C. No varsa T.C. Kimlik No alanına yazılır.
- Ad/Soyad/Unvan otomatik dolması beklenir.
- Belge No yazılır.
- İşlem Tutarı tutar alanına yazılır.
- Tarih, Düzenleme Tarihi ve Zaman Aşımı Başlangıç Tarihi alanlarına yazılır.
- Emanet Türü: 39 Diğer Çeşitli Emanetler seçilir.
- Emanet Ekle tıklanır.
- Zaman aşımı onayı gelirse Evet/Tamam tıklanır.

NOTLAR
- İlk sürümde Kaydet butonuna otomatik basmama seçeneği varsayılan açıktır.
- EVDB alanlarının HTML/ExtJS yapısı farklıysa bazı alanlar bulunamayabilir. O durumda ekrandaki alanların HTML selector bilgilerine göre content.js içindeki alan bulma kısmı netleştirilmelidir.
- Hatalı satırda durması için “Hata olursa dur” seçeneği açık bırakılmalıdır.
