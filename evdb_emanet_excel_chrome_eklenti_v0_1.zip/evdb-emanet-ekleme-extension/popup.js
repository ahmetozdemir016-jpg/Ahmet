const $ = id => document.getElementById(id);
let preparedRows = [];

function log(msg) {
  const el = $('log');
  el.textContent += `[${new Date().toLocaleTimeString('tr-TR')}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
}
function status(msg) { $('status').textContent = msg; log(msg); }
function normalizeDate(v) {
  v = String(v || '').trim();
  if (!v) return '';
  // Already like 04.06.2026
  let m = v.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
  if (m) return `${m[1].padStart(2,'0')}.${m[2].padStart(2,'0')}.${m[3]}`;
  // Excel serial number fallback
  if (/^\d+(\.\d+)?$/.test(v)) {
    const n = Number(v);
    if (n > 20000 && n < 80000) {
      const d = new Date(Math.round((n - 25569) * 86400 * 1000));
      return `${String(d.getUTCDate()).padStart(2,'0')}.${String(d.getUTCMonth()+1).padStart(2,'0')}.${d.getUTCFullYear()}`;
    }
  }
  return v;
}
function normalizeAmount(v) {
  v = String(v || '').trim();
  if (!v) return '';
  // Browser/EVDB can generally accept Turkish decimal comma. Use comma for safety.
  return v.replace(/\s/g, '').replace('.', ',');
}
function mapRows(rows) {
  const onlyGiris = $('onlyGiris').checked;
  return rows.map(r => ({
    excelRow: r.__rownum,
    tarih: normalizeDate(r['Tarih']),
    belgeNo: String(r['Belge No'] || '').trim(),
    tutar: normalizeAmount(r['İşlem Tutarı']),
    islemYonu: String(r['İşlem Yönü'] || '').trim(),
    tcNo: String(r['T.C. No'] || '').replace(/\D/g, ''),
    vergiNo: String(r['Vergi No'] || '').replace(/\D/g, ''),
    gonderen: String(r['Gönderen/Ödeyen'] || '').trim(),
    ham: r
  })).filter(r => !onlyGiris || r.islemYonu.toLocaleLowerCase('tr-TR') === 'giriş')
    .filter(r => r.tarih || r.belgeNo || r.tutar || r.tcNo || r.vergiNo);
}

$('preview').addEventListener('click', async () => {
  const file = $('file').files[0];
  if (!file) return status('Önce Excel dosyası seçin.');
  try {
    status('Excel okunuyor...');
    const wb = await XLSXLite.readXlsx(file, 'Emanet_Rapor');
    preparedRows = mapRows(wb.rows);
    $('total').textContent = wb.rows.length;
    $('usable').textContent = preparedRows.length;
    $('start').disabled = preparedRows.length === 0;
    status(`Okundu. Sayfa: ${wb.sheetName}. İşlenecek kayıt: ${preparedRows.length}`);
    log(JSON.stringify(preparedRows.slice(0, 3), null, 2));
  } catch (e) {
    status('Excel okuma hatası: ' + e.message);
  }
});

async function sendToTab(message) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error('Aktif sekme bulunamadı.');
  return await chrome.tabs.sendMessage(tab.id, message);
}

$('start').addEventListener('click', async () => {
  if (!preparedRows.length) return status('Önce dosyayı okuyun.');
  try {
    await chrome.storage.local.set({ evdbEmanetRows: preparedRows });
    await sendToTab({
      type: 'EVDB_EMANET_START',
      rows: preparedRows,
      options: {
        noAutoSave: $('noAutoSave').checked,
        stopOnError: $('stopOnError').checked,
        delay: Number($('delay').value || 750),
        belgeTuru: 'Diğer',
        emanetTuru: '39 Diğer Çeşitli Emanetler'
      }
    });
    $('start').disabled = true; $('pause').disabled = false; $('stop').disabled = false; $('resume').disabled = true;
    status('Aktarım başlatıldı. EVDB ekranındaki bot panelinden ilerlemeyi izleyin.');
  } catch (e) { status('Başlatma hatası: ' + e.message); }
});
$('pause').addEventListener('click', async () => { await sendToTab({ type: 'EVDB_EMANET_PAUSE' }); $('pause').disabled=true; $('resume').disabled=false; status('Duraklatıldı.'); });
$('resume').addEventListener('click', async () => { await sendToTab({ type: 'EVDB_EMANET_RESUME' }); $('pause').disabled=false; $('resume').disabled=true; status('Devam ediyor.'); });
$('stop').addEventListener('click', async () => { await sendToTab({ type: 'EVDB_EMANET_STOP' }); $('start').disabled=false; $('pause').disabled=true; $('resume').disabled=true; $('stop').disabled=true; status('Durduruldu.'); });
