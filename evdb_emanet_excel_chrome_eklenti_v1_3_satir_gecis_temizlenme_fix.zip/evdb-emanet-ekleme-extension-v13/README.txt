EVDB Emanet Excel Chrome Eklentisi v1.3
- TC/VKN yazıldıktan sonra EVDB sorgusunun çalışması için kimlik alanından çıkış, Belge No/boş alan tıklaması ve blur tetiklenir.
- Ad/Soyad/Unvan dolması daha uzun beklenir.
- Bot sadece eklenti ikonuna basınca açılır.
