GİB Token Dinleyici v1.15 (v517-fix)

NE SAKLAR
Uzantı iki ayrı şey saklar. Eski README yalnızca birincisini anlatıyordu:

1) Tokenler  -> chrome.storage.local : takkom_token_cache_v1
   Yakaladığı token türleri:
   - GİB intranet : gib_token_gibintranet
   - KEYS / GP    : gib_token_keys
   - EVDB Rapor   : gib_token_evdbrapor
   - İzaha Davet / SMİYB : gib_token_izah
   - İsteğe bağlı : istakip / eys / ebeyan
   Ayrıca oturumun orgoid ve userId bilgisi (sessionByModule altında).

2) İstek kayıtları -> chrome.storage.local : takkom_keys_capture_v1
   DİKKAT: Bu kayıtlar isteklerin TAM GÖVDESİNİ içerir ve gövdelerde
   token= parametresi geçer. Yani tokenlar bu listede de açık metin
   olarak, en fazla 8 saat boyunca durur (CAPTURE_TTL).
   En fazla 250 kayıt tutulur, eskiler atılır.

   Bu kayıtlar yalnızca evrak/doküman önizleme akışları için gerekli
   (takdire-sevk*.html ve gelen-giden-evrak.html içindeki
   capturedTemplates / capturedPdfDocs).

   Gövde kaydına ihtiyacın yoksa background.js sonundaki
   chrome.webRequest.onBeforeRequest bloğunu kaldırabilirsin; token
   yakalama page_hook.js üzerinden çalışmaya devam eder.

ÇALIŞMA MANTIĞI
1) GİB/KEYS/EVDB/İzaha Davet sekmelerinde CSSession.getToken(...) çağrılarından
   ve token içeren istek/cevaplardan tokeni ayıklar.
2) Token yakalanınca chrome.storage.local içinde saklar.
3) Dosya URL erişimi açıksa TAKKOM sayfası açıldığında yakalanan tokenleri
   localStorage'a köprüler.
4) Yanlış token karışmasın diye generic gibToken yalnızca GİB intranet tokeni
   ile doldurulur; izah/evdb/keys ayrı anahtarlarda tutulur.
5) Page hook periyodik token taramasını 120 saniye sonra durdurur.
   (Eski README "30 saniye" diyordu; doğru değer 120.) Erken durma yalnızca
   ALTI modülün tokeni birden yakalanmışsa olur, ki pratikte nadirdir —
   bu bilinçli: sonradan tazelenen tokenler de yakalanabilsin diye.

v517-fix İLE GELEN DEĞİŞİKLİKLER
- background.js: her istekte chrome.storage'a yazmak yerine kayıtlar bellekte
  biriktirilip 1 saniyede bir (veya 25 kayıt dolunca) tek seferde yazılıyor.
  Tüm storage yazmaları tek sıraya dizildi (eşzamanlı yazmalar birbirini
  eziyordu).
- page_hook.js: cevap gövdesi artık YALNIZCA belge/evrak ile ilgili komutlarda
  kopyalanıyor. Eskiden her dispatch cevabı resp.clone() ile kopyalanıp 200 KB'a
  kadar saklanıyordu; TAKKOM bir sorguda yüzlerce dispatch attığı için bu ciddi
  bir yüktü ve o cevaplar hiçbir zaman okunmuyordu.
  Evrak önizlemede eksik fark edersen konsoldan eski davranışa dön:
      window.__TAKKOM_TUM_CEVAPLARI_YAKALA = true;
- content.js: İş Takip + EYS Bot'un keşfettiği orgoid de okunup köprüleniyor
  (o bot file:// sayfalarında çalışmadığı için TAKKOM onu göremiyordu).

KURULUM
Chrome > Uzantılar > Geliştirici modu > Paketlenmemiş yükle > bu klasörü seç.
Uzantı detayında "Dosya URL'lerine erişime izin ver" seçeneğini aç.


v1.16 (etebligat modülü):
- keys.ggm.bim üzerindeki e-Tebligat (etebligat_server) KEYS ile aynı host'ta ama
  KENDİ tokenini kullanıyor. Eskiden bu token 'keys' sayılıp KEYS tokeninin üzerine
  yazılıyordu. Artık ayrı 'etebligat' modülü olarak yakalanır:
  gib_token_etebligat / takkom_etebligat_token / takkom_token_cache_v1.tokens.etebligat
- Rapor Kayıt Defteri kontrol ekranındaki İhbarname No -> e-Tebligat belge + ekleri açma bu tokeni kullanır.


v1.17 (evdoserver modülü):
- keys.ggm.bim/evdo_server (EVDO uygulama sunucusu: ihbarnameServiceImpl_ihbarnameSorgulama vb.)
  eskiden 'keys' sayılıp KEYS tokeninin üzerine yazılıyordu; artık ayrı 'evdoserver' modülü:
  gib_token_evdoserver / takkom_evdoserver_token / takkom_token_cache_v1.tokens.evdoserver
- e-Tebligat İmza Bekleyen İhbarnameler sayfasındaki "EVDO ihbarname (ekler / tekerrür / aktivasyon)" sütunu bu tokeni kullanır.
