EVDB Emanet Excel Aktarım Botu v0.8

Düzeltmeler:
- Belge No alanını açılır liste gibi algılama hatası düzeltildi.
- Belge No, Tutar, Düzenleme Tarihi ve Zaman Aşımı Başlangıç Tarihi alanları metin/input olarak aranır.
- Emanet Türü seçimi açılır liste üzerinden yapılır.
- Her yazılan alan log ekranına yazılır.

Kurulum:
1) Chrome > chrome://extensions
2) Geliştirici modu açık
3) Eski sürümü kaldır
4) Paketlenmemiş öğe yükle
5) evdb-emanet-ekleme-extension-v08 klasörünü seç
6) EVDB sayfasında Ctrl+R yap
