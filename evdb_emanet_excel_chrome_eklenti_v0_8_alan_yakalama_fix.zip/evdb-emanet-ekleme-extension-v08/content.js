(() => {
  if (window.__evdbEmanetBotV08Loaded) return;
  window.__evdbEmanetBotV08Loaded = true;

  const state = {
    running: false,
    paused: false,
    stopped: false,
    current: 0,
    total: 0,
    results: [],
    options: {},
    selectedFile: null,
    preparedRows: []
  };

  const PANEL_ID = 'evdb-emanet-bot-panel-v08';
  const $ = id => document.getElementById(id);

  function norm(s) {
    return String(s || '').toLocaleLowerCase('tr-TR')
      .replace(/ı/g, 'i').replace(/İ/g, 'i')
      .replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c')
      .replace(/[\.：:]/g, '').replace(/\s+/g, ' ').trim();
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
  }

  function makeDraggable(panel, handle) {
    let down = false, sx = 0, sy = 0, sl = 0, st = 0;
    handle.addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;
      down = true; sx = e.clientX; sy = e.clientY;
      const r = panel.getBoundingClientRect(); sl = r.left; st = r.top;
      document.body.style.userSelect = 'none';
    });
    document.addEventListener('mousemove', e => {
      if (!down) return;
      panel.style.left = Math.max(0, sl + e.clientX - sx) + 'px';
      panel.style.top = Math.max(0, st + e.clientY - sy) + 'px';
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => { down = false; document.body.style.userSelect = ''; });
  }

  function ensurePanel(show = true) {
    let panel = $(PANEL_ID);
    if (panel) {
      if (show) panel.style.display = 'block';
      return panel;
    }
    panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.style.cssText = `
      position:fixed; right:18px; top:90px; width:430px; z-index:2147483647;
      background:#f6f7fb; color:#1f2933; border:1px solid #4b5563; border-radius:10px;
      font:13px Arial, sans-serif; box-shadow:0 8px 28px rgba(0,0,0,.32); overflow:hidden;
    `;
    panel.innerHTML = `
      <div id="evdb-bot-drag" style="background:#263449;color:#fff;padding:9px 10px;cursor:move;display:flex;align-items:center;justify-content:space-between;gap:8px">
        <div style="font-weight:bold">EVDB Emanet Botu v0.8</div>
        <div>
          <button id="evdb-bot-min" title="Küçült" style="margin-right:4px">—</button>
          <button id="evdb-bot-close" title="Gizle">×</button>
        </div>
      </div>
      <div id="evdb-bot-body" style="padding:10px">
        <div style="font-size:12px;margin-bottom:8px;color:#374151">Emanet MİF(A) &gt; Emanet Bilgileri ekranı açıkken çalıştır.</div>
        <div style="border:1px dashed #9ca3af;border-radius:8px;padding:8px;background:#fff;margin-bottom:8px">
          <div style="font-weight:bold;margin-bottom:6px">Excel dosyası (.xlsx)</div>
          <input id="evdb-bot-file" type="file" accept=".xlsx" style="display:none">
          <button id="evdb-bot-choose">Dosya Seç</button>
          <span id="evdb-bot-file-name" style="margin-left:8px;color:#4b5563">Dosya seçilmedi</span>
          <div id="evdb-bot-drop" style="margin-top:7px;padding:8px;text-align:center;background:#eef2ff;border-radius:6px;color:#374151">veya Excel dosyasını buraya sürükle-bırak</div>
        </div>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-only-giris" type="checkbox" checked> Sadece İşlem Yönü = Giriş</label>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-no-save" type="checkbox" checked> Kaydet butonuna basma, sadece alta ekle</label>
        <label style="display:block;margin:4px 0"><input id="evdb-bot-stop-error" type="checkbox" checked> Hata olursa dur</label>
        <div style="display:flex;align-items:center;gap:8px;margin:7px 0">
          <label>Satır bekleme ms</label><input id="evdb-bot-delay" type="number" value="750" min="100" step="100" style="width:90px">
        </div>
        <div style="margin:8px 0;background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:6px">
          Okunan kayıt: <b id="evdb-bot-total">0</b> &nbsp; İşlenecek kayıt: <b id="evdb-bot-usable">0</b> &nbsp; Şu an: <b id="evdb-bot-current">0</b>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">
          <button id="evdb-bot-read">Dosyayı Oku</button>
          <button id="evdb-bot-start" disabled>Başlat</button>
          <button id="evdb-bot-pause" disabled>Duraklat</button>
          <button id="evdb-bot-resume" disabled>Devam</button>
          <button id="evdb-bot-stop" disabled>Durdur</button>
          <button id="evdb-bot-clear">Log Temizle</button>
        </div>
        <div id="evdb-bot-status" style="margin:6px 0;color:#111827;font-weight:bold">Hazır.</div>
        <pre id="evdb-bot-log" style="height:170px;overflow:auto;white-space:pre-wrap;background:#111827;color:#d1fae5;padding:8px;margin:0;border-radius:6px;font-size:12px"></pre>
      </div>`;
    document.documentElement.appendChild(panel);
    makeDraggable(panel, $('evdb-bot-drag'));
    wirePanel();
    log('Bot penceresi hazır. Excel dosyasını seçip “Dosyayı Oku” deyin.');
    if (!show) panel.style.display = 'none';
    return panel;
  }

  function setStatus(msg) {
    const s = $('evdb-bot-status');
    if (s) s.textContent = msg;
    log(msg, false);
  }
  function log(msg, includeStatus = true) {
    ensurePanel(false);
    const line = `[${new Date().toLocaleTimeString('tr-TR')}] ${msg}`;
    console.log('[EVDB Emanet Bot]', msg);
    const box = $('evdb-bot-log');
    if (box) { box.textContent += line + '\n'; box.scrollTop = box.scrollHeight; }
    if (includeStatus) {
      const cur = $('evdb-bot-current'); if (cur) cur.textContent = String(state.current || 0);
    }
  }
  function updateCounters(total, usable) {
    if ($('evdb-bot-total')) $('evdb-bot-total').textContent = String(total ?? state.total ?? 0);
    if ($('evdb-bot-usable')) $('evdb-bot-usable').textContent = String(usable ?? state.preparedRows.length ?? 0);
    if ($('evdb-bot-current')) $('evdb-bot-current').textContent = String(state.current || 0);
  }

  function wirePanel() {
    $('evdb-bot-close').onclick = () => { $(PANEL_ID).style.display = 'none'; };
    $('evdb-bot-min').onclick = () => {
      const b = $('evdb-bot-body');
      b.style.display = b.style.display === 'none' ? 'block' : 'none';
    };
    $('evdb-bot-clear').onclick = () => { $('evdb-bot-log').textContent = ''; };
    $('evdb-bot-choose').onclick = () => $('evdb-bot-file').click();
    $('evdb-bot-file').addEventListener('change', e => setFile(e.target.files && e.target.files[0]));

    const dz = $('evdb-bot-drop');
    ['dragenter','dragover'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.style.background = '#dbeafe'; }));
    ['dragleave','drop'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.style.background = '#eef2ff'; }));
    dz.addEventListener('drop', e => {
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (!file) return setStatus('Bırakılan dosya alınamadı.');
      setFile(file);
    });

    $('evdb-bot-read').onclick = readExcel;
    $('evdb-bot-start').onclick = () => runRows(state.preparedRows, getOptions());
    $('evdb-bot-pause').onclick = () => { state.paused = true; setStatus('Duraklatıldı.'); updateButtons(); };
    $('evdb-bot-resume').onclick = () => { state.paused = false; setStatus('Devam ediyor.'); updateButtons(); };
    $('evdb-bot-stop').onclick = () => { state.stopped = true; state.running = false; setStatus('Durduruluyor...'); updateButtons(); };
  }

  function updateButtons() {
    const start = $('evdb-bot-start'), pause = $('evdb-bot-pause'), resume = $('evdb-bot-resume'), stop = $('evdb-bot-stop');
    if (!start) return;
    start.disabled = state.running || !state.preparedRows.length;
    pause.disabled = !state.running || state.paused;
    resume.disabled = !state.running || !state.paused;
    stop.disabled = !state.running;
  }

  function setFile(file) {
    if (!file) return setStatus('Dosya seçilmedi.');
    if (!file.name.toLowerCase().endsWith('.xlsx')) return setStatus('Sadece .xlsx dosyası seçin.');
    state.selectedFile = file;
    state.preparedRows = [];
    updateCounters(0,0);
    $('evdb-bot-file-name').textContent = `${file.name} (${Math.round(file.size/1024)} KB)`;
    $('evdb-bot-start').disabled = true;
    setStatus('Dosya seçildi. Şimdi “Dosyayı Oku” butonuna basın.');
  }

  function normalizeDate(v) {
    v = String(v || '').trim();
    if (!v) return '';
    let m = v.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
    if (m) return `${m[1].padStart(2,'0')}.${m[2].padStart(2,'0')}.${m[3]}`;
    if (/^\d+(\.\d+)?$/.test(v)) {
      const n = Number(v);
      if (n > 20000 && n < 80000) {
        const d = new Date(Math.round((n - 25569) * 86400 * 1000));
        return `${String(d.getUTCDate()).padStart(2,'0')}.${String(d.getUTCMonth()+1).padStart(2,'0')}.${d.getUTCFullYear()}`;
      }
    }
    return v;
  }
  function normalizeAmount(v) {
    v = String(v || '').trim();
    if (!v) return '';
    if (v.includes(',') && v.includes('.')) return v.replace(/\./g, '');
    return v.replace(/\s/g, '').replace('.', ',');
  }
  function formatEvdbBelgeNo(raw, tarih, fisNo) {
    let v = String(raw || '').trim();
    const digits = v.replace(/\D/g, '');
    if (digits.length >= 15 && /^20\d{6}/.test(digits)) return `${digits.slice(0,8)}/00-000/${digits.slice(-7)}`;
    const t = String(tarih || '').trim();
    const f = String(fisNo || '').replace(/\D/g, '');
    const m = t.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
    if (!v && m && f) return `${m[3]}${m[2]}${m[1]}/00-000/${f.padStart(7,'0')}`;
    return v;
  }
  function pick(r, names) {
    for (const n of names) if (r[n] !== undefined && r[n] !== null && String(r[n]).trim() !== '') return r[n];
    return '';
  }
  function mapRows(rows) {
    const onlyGiris = $('evdb-bot-only-giris')?.checked ?? true;
    return rows.map(r => {
      const tarih = normalizeDate(pick(r, ['Tarih', 'İşlem Tarihi', 'Duzenleme Tarihi', 'Düzenleme Tarihi']));
      const fisNo = String(pick(r, ['Fiş No', 'Fis No', 'Fiş Numarası']) || '').trim();
      const belgeRaw = String(pick(r, ['Belge No', 'Belge Numarası', 'Belge No.']) || '').trim();
      return {
        excelRow: r.__rownum,
        tarih,
        fisNo,
        belgeNo: formatEvdbBelgeNo(belgeRaw, tarih, fisNo),
        belgeNoExcel: belgeRaw,
        tutar: normalizeAmount(pick(r, ['İşlem Tutarı', 'Islem Tutari', 'Tutar', 'Tutarı'])),
        islemYonu: String(pick(r, ['İşlem Yönü', 'Islem Yonu', 'Yön']) || '').trim(),
        tcNo: String(pick(r, ['T.C. No', 'TC No', 'T.C.Kimlik No', 'T.C. Kimlik No']) || '').replace(/\D/g, ''),
        vergiNo: String(pick(r, ['Vergi No', 'Vergi Kimlik No', 'VKN']) || '').replace(/\D/g, ''),
        ham: r
      };
    }).filter(r => !onlyGiris || norm(r.islemYonu) === 'giris')
      .filter(r => r.tarih || r.belgeNo || r.tutar || r.tcNo || r.vergiNo);
  }
  async function readExcel() {
    const file = state.selectedFile || ($('evdb-bot-file')?.files && $('evdb-bot-file').files[0]);
    if (!file) return setStatus('Önce Excel dosyası seçin.');
    try {
      setStatus('Excel okunuyor...');
      if (!window.XLSXLite) throw new Error('Excel okuyucu yüklenmedi. Eklentiyi yeniden yükleyin.');
      const wb = await XLSXLite.readXlsx(file, 'Emanet_Rapor');
      state.preparedRows = mapRows(wb.rows);
      state.total = wb.rows.length;
      state.current = 0;
      updateCounters(wb.rows.length, state.preparedRows.length);
      updateButtons();
      setStatus(`Okundu. Sayfa: ${wb.sheetName}. İşlenecek kayıt: ${state.preparedRows.length}.`);
      log('İlk kayıt örnekleri: ' + JSON.stringify(state.preparedRows.slice(0,3), null, 2));
    } catch (e) {
      setStatus('Excel okuma hatası: ' + (e?.message || e));
    }
  }
  function getOptions() {
    return {
      noAutoSave: $('evdb-bot-no-save')?.checked ?? true,
      stopOnError: $('evdb-bot-stop-error')?.checked ?? true,
      delay: Number($('evdb-bot-delay')?.value || 750),
      belgeTuru: 'Diğer',
      emanetTuru: '39 Diğer Çeşitli Emanetler'
    };
  }

  function injectConfirmOverride() {
    // v0.6: EVDB sayfasının CSP kuralı inline script çalıştırmaya izin vermiyor.
    // Bu yüzden window.confirm override yapılmıyor; uyarı penceresi görünürse Evet/Tamam butonu tıklanıyor.
  }

  function isTextLike(el) {
    if (!el) return false;
    const tag = el.tagName;
    const type = String(el.getAttribute('type') || '').toLowerCase();
    if (tag === 'TEXTAREA' || el.isContentEditable) return true;
    if (tag !== 'INPUT') return false;
    return !['button','submit','reset','checkbox','radio','hidden','image','file'].includes(type);
  }
  function isComboLike(el) {
    if (!el) return false;
    const tag = el.tagName;
    const role = String(el.getAttribute('role') || '').toLowerCase();
    const cls = String(el.className || '').toLowerCase();
    return tag === 'SELECT' || role === 'combobox' || cls.includes('combo') || cls.includes('x-form-field');
  }
  function allCandidates(kind = 'any') {
    let q = 'input, textarea, select, [contenteditable="true"], [role="combobox"]';
    let arr = [...document.querySelectorAll(q)].filter(visible).filter(c => !c.closest('#' + PANEL_ID));
    if (kind === 'text') arr = arr.filter(isTextLike);
    if (kind === 'combo') arr = arr.filter(c => c.tagName === 'SELECT' || c.getAttribute('role') === 'combobox' || isTextLike(c));
    return arr;
  }
  function findLabelNode(label) {
    const nlabel = norm(label);
    let best = null;
    const nodes = [...document.querySelectorAll('label, td, th, div, span, font, b')].filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    for (const el of nodes) {
      const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
      const t = norm(txt);
      if (!t) continue;
      if (t === nlabel || t.includes(nlabel)) {
        // Çok uzun metinler yakın etiket değildir. En kısa ve en soldaki/üstteki gerçek etiketi seç.
        const score = t.length + (el.getBoundingClientRect().width > 250 ? 200 : 0);
        if (!best || score < best._score) { best = el; best._score = score; }
      }
    }
    return best;
  }
  function scoreCandidate(labelRect, r, preferRight = true) {
    const vgap = Math.abs((r.top + r.height/2) - (labelRect.top + labelRect.height/2));
    const rightDist = r.left - labelRect.right;
    const leftPenalty = rightDist < -20 ? 600 : 0;
    const tooFarV = vgap > 75 ? 400 : 0;
    return vgap * 10 + Math.max(0, rightDist) + leftPenalty + tooFarV;
  }
  function findControlAfterLabel(label, kind = 'any') {
    const nlabel = norm(label);
    const controls = allCandidates(kind);

    // 1) Önce attribute üzerinden net eşleşme.
    for (const c of controls) {
      const attrs = [c.name, c.id, c.title, c.placeholder, c.getAttribute('aria-label'), c.getAttribute('fieldLabel'), c.getAttribute('data-qtip')].map(norm).join(' ');
      if (attrs && attrs.includes(nlabel)) return c;
    }

    // 2) Ekrandaki etiketin aynı satırındaki en yakın uygun input/select.
    const labelNode = findLabelNode(label);
    if (!labelNode) return null;
    const lr = labelNode.getBoundingClientRect();
    let best = null, bestScore = Infinity;

    for (const c of controls) {
      const r = c.getBoundingClientRect();
      if (r.width < 15 || r.height < 8) continue;
      // Aynı satırda etiketin sağındaki alanlara öncelik ver.
      const sameLine = Math.abs((r.top + r.height/2) - (lr.top + lr.height/2)) < 35;
      const toRight = r.left > lr.left - 10;
      const closeBelow = r.top >= lr.top - 5 && r.top - lr.top < 95 && r.left > lr.left - 20;
      if (!(sameLine && toRight) && !closeBelow) continue;
      const score = scoreCandidate(lr, r);
      if (score < bestScore) { best = c; bestScore = score; }
    }
    if (best) return best;

    // 3) Eski yöntem: aynı kapsayıcı içinde ilk uygun kontrol.
    const near = labelNode.closest('tr, .x-form-item, .form-group, table, div') || labelNode.parentElement;
    if (near) {
      const inside = [...near.querySelectorAll('input, textarea, select, [contenteditable="true"], [role="combobox"]')]
        .filter(visible).filter(c => !c.closest('#' + PANEL_ID));
      const filtered = kind === 'text' ? inside.filter(isTextLike) : inside;
      if (filtered.length) return filtered[0];
    }
    return null;
  }
  function getValue(el) {
    return String((el && ('value' in el ? el.value : el.textContent)) || '').trim();
  }
  function setNativeValue(el, value) {
    if (!el) throw new Error('Alan bulunamadı.');
    const v = String(value ?? '');
    el.scrollIntoView({ block: 'center', inline: 'center' });
    el.focus();
    if (el.tagName === 'SELECT') {
      const nval = norm(v);
      let opt = [...el.options].find(o => norm(o.textContent).includes(nval) || norm(o.value).includes(nval));
      if (!opt) throw new Error('Açılır listede seçenek yok: ' + v);
      el.value = opt.value;
    } else if (el.isContentEditable) {
      el.textContent = v;
    } else {
      try { el.select && el.select(); } catch(e) {}
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) setter.call(el, v); else el.value = v;
    }
    ['focus','input','change','keyup'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Tab', code: 'Tab' }));
    el.blur && el.blur();
  }
  async function typeValue(label, value) {
    const el = findControlAfterLabel(label, 'text');
    if (!el) throw new Error(`Alan bulunamadı: ${label}`);
    if (el.tagName === 'SELECT') throw new Error(`Metin alanı yerine liste bulundu: ${label}`);
    setNativeValue(el, String(value || ''));
    await sleep(250);
    log(`${label} yazıldı: ${value}`);
    return el;
  }
  async function typeValueAny(labels, value) {
    for (const label of labels) {
      const el = findControlAfterLabel(label, 'text');
      if (el && el.tagName !== 'SELECT') {
        setNativeValue(el, String(value || ''));
        await sleep(250);
        log(`${label} yazıldı: ${value}`);
        return el;
      }
    }
    throw new Error(`Alan bulunamadı: ${labels.join(' / ')}`);
  }
  function findOpenOption(text) {
    const target = norm(text);
    const nodes = [...document.querySelectorAll('div, li, td, span')].filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    let best = null;
    for (const el of nodes) {
      const t = norm(el.innerText || el.textContent || '');
      if (!t) continue;
      if (t === target || t.includes(target)) {
        const r = el.getBoundingClientRect();
        if (r.width > 20 && r.height > 8) { best = el; break; }
      }
    }
    return best;
  }
  async function selectByText(label, text) {
    const el = findControlAfterLabel(label, 'combo') || findControlAfterLabel(label, 'text');
    if (!el) throw new Error(`Liste alanı bulunamadı: ${label}`);
    el.scrollIntoView({ block: 'center', inline: 'center' });
    if (el.tagName === 'SELECT') { setNativeValue(el, text); await sleep(350); log(`${label} seçildi: ${text}`); return; }

    // ExtJS/EVDB combo: önce alanı temizle, metni yaz, sonra listeden görünen seçeneği tıkla.
    el.focus(); el.click();
    await sleep(180);
    setNativeValue(el, text);
    await sleep(450);
    let opt = findOpenOption(text);
    if (!opt && /^39\b/.test(text)) opt = findOpenOption('39 Diğer Çeşitli Emanetler') || findOpenOption('Diğer Çeşitli Emanetler');
    if (!opt && norm(text) === 'diger') opt = findOpenOption('Diğer');
    if (opt) {
      opt.scrollIntoView({block:'center'}); opt.click();
      await sleep(350);
    } else {
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'ArrowDown', code: 'ArrowDown' }));
      await sleep(100);
      el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter' }));
      await sleep(350);
    }
    log(`${label} seçildi: ${text}`);
  }
  function clickVisibleText(text, required = true) {
    const target = norm(text);
    const nodes = [...document.querySelectorAll('button, input[type="button"], input[type="submit"], a, span, div, td')].filter(visible).filter(el => !el.closest('#' + PANEL_ID));
    let best = null;
    for (const el of nodes) {
      const val = el.tagName === 'INPUT' ? el.value : (el.innerText || el.textContent || '');
      const t = norm(val);
      if (t === target || t.includes(target)) { best = el; break; }
    }
    if (!best) {
      if (required) throw new Error('Buton/metin bulunamadı: ' + text);
      return false;
    }
    best.scrollIntoView({ block: 'center', inline: 'center' });
    best.focus && best.focus();
    best.click();
    return true;
  }
  async function clickButton(text) { clickVisibleText(text, true); await sleep(600); log(`${text} tıklandı.`); }
  async function clickYesIfExists() {
    for (let i=0; i<30; i++) {
      const ok = clickVisibleText('Evet', false) || clickVisibleText('Tamam', false);
      if (ok) { log('Onay penceresi: Evet/Tamam tıklandı.'); return true; }
      await sleep(150);
    }
    log('Onay penceresi görünmedi veya otomatik tıklanamadı.');
    return false;
  }
  async function waitForIdentityFilled(timeoutMs = 9000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const ad = findControlAfterLabel('Ad', 'text');
      const soyad = findControlAfterLabel('Soyad', 'text');
      const unvan = findControlAfterLabel('Unvan', 'text') || findControlAfterLabel('Adı Soyadı', 'text') || findControlAfterLabel('Mükellef', 'text');
      const vals = [ad, soyad, unvan].filter(Boolean).map(getValue).filter(Boolean);
      if (vals.length >= 1) return true;
      await sleep(350);
    }
    return false;
  }
  function validateRow(row) {
    const missing = [];
    if (!row.vergiNo && !row.tcNo) missing.push('Vergi No/T.C. No');
    if (!row.belgeNo) missing.push('Belge No');
    if (!row.tutar) missing.push('Tutar');
    if (!row.tarih) missing.push('Tarih');
    return missing;
  }
  async function processRow(row) {
    log(`Satır ${row.excelRow} başlıyor: ${row.vergiNo || row.tcNo} / ${row.tutar} / ${row.belgeNo}`);
    const missing = validateRow(row);
    if (missing.length) throw new Error('Eksik alan: ' + missing.join(', '));
    await selectByText('Belge Türü', state.options.belgeTuru || 'Diğer');
    if (row.vergiNo) {
      const tc = findControlAfterLabel('T.C. Kimlik No') || findControlAfterLabel('TC Kimlik No');
      if (tc) setNativeValue(tc, '');
      await typeValueAny(['Vergi Kimlik No', 'Vergi No', 'VKN'], row.vergiNo);
    } else {
      const vn = findControlAfterLabel('Vergi Kimlik No');
      if (vn) setNativeValue(vn, '');
      await typeValueAny(['T.C.Kimlik No', 'T.C. Kimlik No', 'TC Kimlik No', 'T.C Kimlik No'], row.tcNo);
    }
    log('Ad/Soyad/Unvan dolması bekleniyor...');
    if (!(await waitForIdentityFilled())) throw new Error('Ad/Soyad/Unvan otomatik dolmadı.');
    await typeValue('Belge No', row.belgeNo);
    await typeValue('Tutar', row.tutar);
    await typeValue('Düzenleme Tarihi', row.tarih);
    await typeValue('Zaman Aşımı Başlangıç Tarihi', row.tarih);
    await selectByText('Emanet Türü', state.options.emanetTuru || '39 Diğer Çeşitli Emanetler');
    await clickButton('Emanet Ekle');
    await clickYesIfExists();
    await sleep(state.options.delay || 750);
    log(`Satır ${row.excelRow} eklendi kabul edildi.`);
    return { row: row.excelRow, status: 'Eklendi' };
  }
  async function runRows(rows, options) {
    if (state.running) return log('Zaten çalışıyor.');
    if (!rows.length) return setStatus('İşlenecek kayıt yok. Önce dosyayı oku.');
    injectConfirmOverride();
    state.running = true; state.paused = false; state.stopped = false; state.current = 0; state.total = rows.length; state.options = options || {}; state.results = [];
    updateButtons(); updateCounters(state.total, rows.length);
    setStatus(`Aktarım başladı. Kayıt sayısı: ${rows.length}.`);
    for (let i=0; i<rows.length; i++) {
      while (state.paused && !state.stopped) await sleep(300);
      if (state.stopped) break;
      state.current = i + 1; updateCounters(state.total, rows.length);
      try { state.results.push(await processRow(rows[i])); }
      catch (e) {
        log(`HATA - Excel satır ${rows[i]?.excelRow}: ${e.message}`);
        state.results.push({ row: rows[i]?.excelRow, status: 'Hata', message: e.message });
        if (state.options.stopOnError) break;
      }
    }
    state.running = false; updateButtons();
    if (!state.stopped && !state.options.noAutoSave) {
      try { await clickButton('Kaydet'); log('Kaydet butonuna basıldı.'); } catch (e) { log('Kaydet basılamadı: ' + e.message); }
    }
    setStatus('İşlem bitti. Sonuçlar log ekranında.');
    log('Sonuçlar: ' + JSON.stringify(state.results));
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      if (message.type === 'EVDB_EMANET_TOGGLE_PANEL') {
        const existing = $(PANEL_ID);
        if (!existing) {
          ensurePanel(true);
        } else {
          existing.style.display = existing.style.display === 'none' ? 'block' : 'none';
        }
        sendResponse({ ok:true });
      } else if (message.type === 'EVDB_EMANET_START') {
        state.preparedRows = message.rows || state.preparedRows;
        runRows(state.preparedRows, message.options || getOptions());
        sendResponse({ ok:true });
      } else if (message.type === 'EVDB_EMANET_PAUSE') { state.paused = true; updateButtons(); sendResponse({ ok:true }); }
      else if (message.type === 'EVDB_EMANET_RESUME') { state.paused = false; updateButtons(); sendResponse({ ok:true }); }
      else if (message.type === 'EVDB_EMANET_STOP') { state.stopped = true; state.running = false; updateButtons(); sendResponse({ ok:true }); }
    } catch (e) { sendResponse({ ok:false, error:e.message }); }
    return true;
  });

  function shouldAutoOpenPanel() {
    const hay = (location.href + ' ' + document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLocaleLowerCase('tr-TR');
    return /evdb|emanet|mif|gib|gelir idaresi|keysggm|gibintranet|intranet/i.test(hay);
  }

  // EVDB sayfasında pencere otomatik görünsün. Sayfa geç yüklenirse birkaç defa tekrar dener.
  if (shouldAutoOpenPanel()) ensurePanel(true);
  let autoTry = 0;
  const autoTimer = setInterval(() => {
    autoTry++;
    if (shouldAutoOpenPanel()) {
      const p = ensurePanel(true);
      p.style.display = 'block';
      p.style.visibility = 'visible';
      p.style.opacity = '1';
      p.style.zIndex = '2147483647';
      if (autoTry > 6) clearInterval(autoTimer);
    }
    if (autoTry > 10) clearInterval(autoTimer);
  }, 1000);
})();
