
const TOKEN_KEY = 'takkom_token_cache_v1';
const CAPTURE_TTL = 8 * 60 * 60 * 1000;
const KEYS_CAPTURE_KEY = 'takkom_keys_capture_v1';
const KEYS_CAPTURE_MAX = 250;

let __capBuf = [];
let __capTimer = null;
let __ioChain = Promise.resolve();          // tüm storage yazmaları sırayla

function cleanToken(v){
  let t = String(v || '').trim();
  if(!t || t.includes('***') || t.includes('...')) return '';
  for(let i=0;i<4;i++){
    const m = /[?&]token=([^&\s#]+)/i.exec(t) || /token%3D([^%&#\s]+)/i.exec(t);
    if(m && m[1]) t = m[1];
    try{ const d = decodeURIComponent(t); if(d === t) break; t = d; }catch(e){ break; }
  }
  t = String(t || '').replace(/["'<>]/g,'').trim();
  if(!t || t.length < 20) return '';
  return t;
}
function normModule(m){
  m = String(m || '').trim().toLowerCase();
  if(!m) return '';
  if(m === 'g' || m.includes('gibintranet') || m.includes('gib_intranet')) return 'gibintranet';
  if(m.includes('etebligat') || m === 'eteb') return 'etebligat';
  if(m === 'gp' || m === 'key' || m === 'keys' || m.includes('keyss')) return 'keys';
  if(m === 'evdoserver' || m === 'evdosrv') return 'evdoserver';   /* keys.ggm.bim/evdo_server — EVDO uygulama sunucusu, kendi tokeni */
  if(m === 'evdo' || m === 'evdb' || m.includes('evdo') || m.includes('evdb') || m.includes('evdorapor')) return 'evdbrapor';
  if(m === 'izah' || m.includes('izah') || m.includes('smiyb')) return 'izah';
  if(m.includes('istakip')) return 'istakip';
  if(m === 'e' || m.includes('eys') || m.includes('edenetis')) return 'eys';
  if(m.includes('ebyn') || m.includes('vdintra')) return 'ebeyan';
  return '';
}
function moduleFromContext(url, body, source){
  const u = String(url || '').toLowerCase();
  const b = String(body || '').toLowerCase();
  const s = String(source || '').toLowerCase();
  const all = u + ' ' + b + ' ' + s;
  let mm = /(?:^|[?&\s])module=([^&\s]+)/i.exec(all);
  if(mm) return normModule(mm[1]);
  mm = /cssession\.gettoken\(([^\)]+)\)/i.exec(all);
  if(mm) return normModule(mm[1]);
  if(u.includes('/izah-server/') || all.includes('module=izah') || all.includes('smiybraporservice') || all.includes('izahraporservice')) return 'izah';
  if(u.includes('/evdo_server/') || all.includes('module=evdoserver')) return 'evdoserver';
  if(u.includes('evdorapor_server') || all.includes('module=evdorapor')) return 'evdbrapor';
  if(u.includes('gibintranet_server') || u.includes('/gibintranet/') || all.includes('module=gibintranet') || all.includes('cssession.gettoken(g)')) return 'gibintranet';
  if(u.includes('etebligat_server') || u.includes('/etebligat/') || all.includes('module=etebligat')) return 'etebligat';
  if(u.includes('keys.ggm') || u.includes('/keyss/') || u.includes('/gp/') || all.includes('module=gp') || all.includes('cssession.gettoken(gp)')) return 'keys';
  if(u.includes('istakip')) return 'istakip';
  if(u.includes('eyoklama') || u.includes('edenetis') || all.includes('module=eys') || all.includes('module=e')) return 'eys';
  if(u.includes('vdintra') || u.includes('/ebyn/')) return 'ebeyan';
  return '';
}
function aliases(mod){
  const m = normModule(mod); const out = [];
  const add = x => { if(x && !out.includes(x)) out.push(x); };
  add(m);
  if(m === 'gibintranet'){ add('g'); add('gibIntranet'); add('gib_intranet'); }
  if(m === 'keys'){ add('gp'); add('key'); add('keysToken'); add('gpToken'); }
  if(m === 'etebligat'){ add('eteb'); add('etebligatToken'); add('eTebligat'); }
  if(m === 'evdoserver'){ add('evdosrv'); add('evdoServerToken'); }
  if(m === 'evdbrapor'){ add('evdo'); add('evdb'); add('evdbRapor'); add('evdbRaporToken'); add('evdorapor'); add('evdoRapor'); }
  if(m === 'izah'){ add('izahaDavet'); add('smiyb'); add('izahServer'); add('izahToken'); }
  if(m === 'istakip') add('isTakip');
  if(m === 'eys'){ add('e'); add('edenetis'); }
  return out;
}
function storeTokens(list, meta={}){        /* v517-fix: yazmalar sıraya dizildi */
  __ioChain = __ioChain.then(() => __storeTokens(list, meta)).catch(()=>{});
  return __ioChain;
}
async function __storeTokens(list, meta={}){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  const cache = old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{}};
  cache.tokens = cache.tokens || {};
  cache.tokensByModule = cache.tokensByModule || {};
  cache.captureStatus = cache.captureStatus || {};
  const now = Date.now();
  let changed = 0;
  for(const item of (Array.isArray(list) ? list : [])){
    const token = cleanToken(item && item.token);
    const mod = normModule((item && item.module) || moduleFromContext(item && item.url, item && item.body, item && item.source));
    if(!token || !mod) continue;
    for(const a of aliases(mod)){
      cache.tokens[a] = {token, time: now, source: (item.source || meta.source || ''), module: mod};
      cache.tokensByModule[a] = token;
    }
    cache[mod] = {token, time: now, source: item.source || meta.source || '', module: mod};
    changed++;
  }
  if(changed){
    cache.updatedAt = now;
    cache.captureStatus.lastSource = meta.source || '';
    cache.captureStatus.lastUrl = meta.url || '';
    cache.captureStatus.modules = Object.keys(cache.tokensByModule || {}).filter(k => ['gibintranet','g','keys','gp','evdbrapor','evdo','evdb','izah','smiyb','istakip','isTakip','eys','e','edenetis','etebligat','evdoserver'].includes(k));
    await chrome.storage.local.set({[TOKEN_KEY]: cache});
  }
  return cache;
}


function storeSessionMeta(meta){            /* v517-fix: yazmalar sıraya dizildi */
  __ioChain = __ioChain.then(() => __storeSessionMeta(meta)).catch(()=>{});
  return __ioChain;
}
async function __storeSessionMeta(meta){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  const cache = old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{}};
  cache.sessionByModule = cache.sessionByModule || {};
  const mod = normModule(meta && meta.module) || 'istakip';
  const prev = cache.sessionByModule[mod] || {};
  const next = Object.assign({}, prev);
  const orgoid = String(meta && meta.orgoid || '').trim();
  const userId = String(meta && meta.userId || '').trim();
  if(/^[a-z0-9_-]{6,64}$/i.test(orgoid)) next.orgoid = orgoid;
  if(/^\d{5,24}$/.test(userId)) next.userId = userId;
  next.time = Date.now(); next.source = String(meta && meta.source || '');
  cache.sessionByModule[mod] = next;
  if(mod === 'istakip'){
    if(next.orgoid) cache.istakipOrgoid = next.orgoid;
    if(next.userId) cache.istakipUserId = next.userId;
  }
  cache.updatedAt = Date.now();
  await chrome.storage.local.set({[TOKEN_KEY]: cache});
  return cache;
}
/* v517-fix: storeKeyCaptures her yakalanan istekte chrome.storage'ı baştan
   okuyup 250 kayıtlık diziyi tekrar yazıyordu. TAKKOM bir sorguda yüzlerce
   dispatch isteği attığı için bu, sorgu boyunca sürekli disk yazması demekti;
   ayrıca eşzamanlı çağrılar birbirinin yazdığını eziyordu (read-modify-write
   yarışı). Artık kayıtlar bellekte biriktirilip tek seferde, sıraya dizilerek
   yazılıyor.                                                              */

function flushCaptures(){
  if(__capTimer){ clearTimeout(__capTimer); __capTimer = null; }
  const batch = __capBuf;
  __capBuf = [];
  if(!batch.length) return __ioChain;
  __ioChain = __ioChain.then(async () => {
    const old = await chrome.storage.local.get(KEYS_CAPTURE_KEY).catch(()=>({}));
    let arr = old[KEYS_CAPTURE_KEY] || [];
    if(!Array.isArray(arr)) arr = [];
    const now = Date.now();
    arr = arr.concat(batch).filter(x => x && x.url && (!x.createdAtMs || now - x.createdAtMs < CAPTURE_TTL));
    if(arr.length > KEYS_CAPTURE_MAX) arr = arr.slice(arr.length - KEYS_CAPTURE_MAX);
    await chrome.storage.local.set({[KEYS_CAPTURE_KEY]: arr});
  }).catch(()=>{});
  return __ioChain;
}

function storeKeyCaptures(items){
  const now = Date.now();
  for(const it of (Array.isArray(items) ? items : [items])){
    if(!it || !it.url) continue;
    __capBuf.push(Object.assign({}, it, {createdAtMs: it.createdAtMs || now}));
  }
  if(__capBuf.length > KEYS_CAPTURE_MAX) __capBuf = __capBuf.slice(-KEYS_CAPTURE_MAX);
  // MV3 service worker uykuya dalabildiği için dolan tamponu hemen boşalt
  if(__capBuf.length >= 25) return flushCaptures().then(()=>__capBuf);
  if(!__capTimer) __capTimer = setTimeout(flushCaptures, 1000);
  return Promise.resolve(__capBuf);
}

async function getKeyCaptures(){
  await flushCaptures();          /* v517-fix: bekleyen kayıtlar da görünsün */
  const old = await chrome.storage.local.get(KEYS_CAPTURE_KEY).catch(()=>({}));
  let arr = old[KEYS_CAPTURE_KEY] || [];
  if(!Array.isArray(arr)) arr = [];
  const now = Date.now();
  arr = arr.filter(x => x && x.url && (!x.createdAtMs || now - x.createdAtMs < CAPTURE_TTL));
  return arr;
}

async function getCache(){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  return old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0};
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg) return;
  if(msg.type === 'TCMB_FETCH_XML'){
    const url = String(msg.url || '').trim();
    if(!/^https:\/\/www\.tcmb\.gov\.tr\/kurlar\/\d{6}\/\d{8}\.xml(?:\?.*)?$/i.test(url)){
      sendResponse({ok:false, kind:'invalid_url', status:0, error:'Geçersiz TCMB kur adresi'});
      return;
    }
    fetch(url, {method:'GET', cache:'no-store', credentials:'omit', redirect:'follow'})
      .then(async resp => {
        const text = await resp.text();
        if(resp.ok){
          sendResponse({ok:true, status:resp.status, text:text, url:resp.url || url});
        }else{
          sendResponse({ok:false, kind:resp.status === 404 ? 'notfound' : 'http', status:resp.status, text:text.slice(0,500), url:resp.url || url});
        }
      })
      .catch(err => sendResponse({ok:false, kind:'network', status:0, error:String(err && err.message || err), url:url}));
    return true;
  }
  if(msg.type === 'KEYS_PROXY_FETCH'){
    /* v1.18: TAKKOM (file://) sayfaları adına KEYS/GİB/eyoklama sunucularına ÇEREZLİ istek atar.
       Klasik JSP ekranları (Denetim Tutanağı / Yoklama Onay) oturumu çerezden okuduğu için file:// altından
       doğrudan XHR ile çalışmaz; bu köprü uzantının host izniyle isteği tarayıcı oturumu üzerinden gönderir. */
    const url = String(msg.url || '').trim();
    if(!/^http:\/\/(keys\.ggm\.bim|keys\.ggm\.bim\.gov\.tr|10\.251\.63\.99|[a-z0-9.-]+\.ggm\.gov\.tr|eyoklama\.gelirler\.gov\.tr(:32516)?|arkaofis\.gelbim\.gov\.tr:32174)\//i.test(url)){
      sendResponse({ok:false, kind:'invalid_url', status:0, error:'İzin verilmeyen adres: '+url});
      return;
    }
    const method = String(msg.method || 'GET').toUpperCase();
    const headers = Object.assign({}, msg.headers || {});
    if(method !== 'GET' && !Object.keys(headers).some(k => k.toLowerCase() === 'content-type')) headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
    fetch(url, {method, headers, body: method === 'GET' ? undefined : String(msg.body || ''), cache:'no-store', credentials:'include', redirect:'follow'})
      .then(async resp => {
        const ct = resp.headers.get('content-type') || '';
        if(/pdf|octet-stream|zip|excel|spreadsheet|msword/i.test(ct)){
          const buf = await resp.arrayBuffer(); let bin=''; const u8=new Uint8Array(buf); for(let i=0;i<u8.length;i++) bin+=String.fromCharCode(u8[i]);
          sendResponse({ok:resp.ok, status:resp.status, contentType:ct, base64:btoa(bin), url:resp.url || url});
        }else{
          const text = await resp.text();
          sendResponse({ok:resp.ok, status:resp.status, contentType:ct, text:text.slice(0, 4000000), url:resp.url || url});
        }
      })
      .catch(err => sendResponse({ok:false, kind:'network', status:0, error:String(err && err.message || err), url:url}));
    return true;
  }
  if(msg.type === 'TOKEN_ONLY_META'){
    storeSessionMeta(msg.payload || {})
      .then(cache => sendResponse({ok:true, cache}))
      .catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'TOKEN_ONLY_CAPTURE'){
    const payload = msg.payload || {};
    const tokens = Array.isArray(payload.tokens) ? payload.tokens : [];
    storeTokens(tokens, {source: payload.reason || payload.source || '', url: payload.pageUrl || ''})
      .then(cache => sendResponse({ok:true, cache}))
      .catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'KEYS_CAPTURE'){
    storeKeyCaptures((msg.payload && msg.payload.items) || msg.items || [])
      .then(captures => sendResponse({ok:true, captures}))
      .catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'GET_CAPTURES'){
    getKeyCaptures().then(captures => sendResponse({ok:true, captures})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'GET_TOKENS'){
    getCache().then(cache => sendResponse({ok:true, cache})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'CLEAR_TOKENS'){
    chrome.storage.local.set({[TOKEN_KEY]: {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{clearedAt:Date.now()}}})
      .then(() => sendResponse({ok:true})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  getCache().then(cache => chrome.storage.local.set({[TOKEN_KEY]: cache})).catch(()=>{});
});


function __takkomBodyFromRequestBody(rb){
  try{
    if(!rb) return '';
    if(rb.formData){
      const parts=[];
      Object.keys(rb.formData).forEach(k=>{
        const vals=Array.isArray(rb.formData[k])?rb.formData[k]:[rb.formData[k]];
        vals.forEach(v=>parts.push(encodeURIComponent(k)+'='+encodeURIComponent(String(v==null?'':v))));
      });
      return parts.join('&');
    }
    if(rb.raw && rb.raw.length){
      let out='';
      for(const r of rb.raw){
        if(r && r.bytes){
          try{ out += new TextDecoder('utf-8').decode(r.bytes); }catch(e){}
        }
      }
      return out;
    }
  }catch(e){}
  return '';
}
try{
  if(chrome.webRequest && chrome.webRequest.onBeforeRequest && !globalThis.__TAKKOM_V126_WEBREQ_CAPTURE__){
    globalThis.__TAKKOM_V126_WEBREQ_CAPTURE__=true;
    chrome.webRequest.onBeforeRequest.addListener(function(details){
      try{
        const u=String(details.url||'');
        /* v1.18: dispatch yolları + keys.ggm.bim/gibintranet altındaki tüm dinamik istekler (Denetim Tutanağı/Yoklama Onay gibi JSP ekranları) */
        if(/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff2?|ttf|map)(\?|$)/i.test(u)) return;
        if(!(/\/dispatch(\?|$)/i.test(u) || /\/keyss\/flexpaper\/pdf/i.test(u) || /keys\.ggm\.bim\/gibintranet\//i.test(u) || /eyoklama\.gelirler\.gov\.tr/i.test(u))) return;
        const body=__takkomBodyFromRequestBody(details.requestBody);
        const item={
          kind:'webRequest.before',
          method:details.method||'',
          url:u,
          body:body,
          tabId:details.tabId,
          requestId:details.requestId,
          resourceType:details.type,
          source:'webRequest.requestBody',
          createdAt:new Date().toISOString(),
          createdAtMs:Date.now()
        };
        storeKeyCaptures([item]).catch(()=>{});
      }catch(e){}
    }, {urls:['http://keys.ggm.bim/*','http://10.251.63.99/*','http://eyoklama.gelirler.gov.tr/*','http://eyoklama.gelirler.gov.tr:32516/*']}, ['requestBody']);
  }
}catch(e){}
