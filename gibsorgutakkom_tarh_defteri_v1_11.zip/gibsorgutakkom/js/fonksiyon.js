
/* TK GLOBAL AJAX CACHE + QUEUE PATCH  (v517-fix) */
(function(){
 if(typeof window.TK_AJAX_PATCHED!=="undefined") return;
 window.TK_AJAX_PATCHED=true;

 /* ---- Ayarlanabilir parametreler ----------------------------------------
    TK_AJAX.delayMs   : her isteğe eklenen taban gecikme (ms). Eskiden 1000-3000
                        idi; sunucuyu yormamak için konulmuştu ama tüm sorguyu
                        dakikalarca yavaşlatıyordu. Sunucu şikâyet ederse
                        konsoldan TK_AJAX.delayMs = 400 gibi yükseltebilirsin.
    TK_AJAX.jitterMs  : gecikmeye eklenen rastgele pay (ms)
    TK_AJAX.max       : eşzamanlı istek sayısı
    TK_AJAX.ttlMs     : cevap önbelleğinin ömrü. 0 = önbellek kapalı.
   ------------------------------------------------------------------------ */
 var CFG = window.TK_AJAX = window.TK_AJAX || {};
 if(CFG.delayMs  == null) CFG.delayMs  = 0;
 if(CFG.jitterMs == null) CFG.jitterMs = 60;
 if(CFG.max      == null) CFG.max      = 8;
 if(CFG.ttlMs    == null) CFG.ttlMs    = 120000;
 if(CFG.maxCache == null) CFG.maxCache = 500;

 var TK_CACHE   = {};   // key -> {res, ts}
 var TK_INFLIGHT= {};   // key -> [deferred, ...]   aynı istek iki kez gitmesin
 var TK_QUEUE   = [];
 var TK_RUNNING = 0;

 function tkDelay(){ return CFG.delayMs + Math.floor(Math.random()*(CFG.jitterMs||0)); }

 function cacheGet(key){
   if(!CFG.ttlMs) return undefined;
   var e = TK_CACHE[key];
   if(!e) return undefined;
   if(Date.now() - e.ts > CFG.ttlMs){ delete TK_CACHE[key]; return undefined; }
   return e;                                  // e.res boş string/0 olabilir
 }
 function cacheSet(key,res){
   if(!CFG.ttlMs) return;
   var keys = Object.keys(TK_CACHE);
   if(keys.length >= CFG.maxCache){           // sınırsız büyümeyi engelle
     keys.sort(function(a,b){ return TK_CACHE[a].ts - TK_CACHE[b].ts; });
     for(var i=0;i<Math.ceil(CFG.maxCache/4);i++) delete TK_CACHE[keys[i]];
   }
   TK_CACHE[key] = {res:res, ts:Date.now()};
 }
 function settle(key, ok, val){
   var waiters = TK_INFLIGHT[key] || [];
   delete TK_INFLIGHT[key];
   for(var i=0;i<waiters.length;i++){
     try{ ok ? waiters[i].resolve(val) : waiters[i].reject(val); }catch(e){}
   }
 }

 function runNext(){
   while(TK_RUNNING < CFG.max && TK_QUEUE.length){
     (function(job){
       TK_RUNNING++;
       var released = false;
       function release(){                    // slot her hâlükârda geri verilsin
         if(released) return;
         released = true;
         TK_RUNNING--;
         runNext();
       }
       setTimeout(function(){
         var real;
         try{
           real = window.__tk_realAjax(job.opts);
         }catch(err){                         // senkron patlarsa kuyruk kilitlenmesin
           settle(job.key,false,err);
           release();
           return;
         }
         real.then(function(res){
           cacheSet(job.key,res);
           settle(job.key,true,res);
         }, function(err){
           settle(job.key,false,err);
         }).always(release);
       }, tkDelay());
     })(TK_QUEUE.shift());
   }
 }

 if(window.$ && $.ajax){
   window.__tk_realAjax = $.ajax;
   $.ajax = function(opts){
      opts = opts || {};

      // Legacy synchronous calls expect jqXHR.responseText immediately.
      // Do not route async:false requests through the queue/promise wrapper.
      if(opts.async === false){
         return window.__tk_realAjax.call($, opts);
      }

      // Anahtara metot da girsin: aynı url'e GET ve POST çakışmasın.
      var key = (opts.type || opts.method || 'GET').toUpperCase() + ' ' +
                (opts.url || '') + ' ' +
                (opts.data == null ? '' : (typeof opts.data === 'string' ? opts.data : JSON.stringify(opts.data)));

      var hit = cacheGet(key);
      if(hit !== undefined){
         var d=$.Deferred();
         d.resolve(hit.res);
         return d.promise();
      }

      var def=$.Deferred();
      if(TK_INFLIGHT[key]){          // aynı istek zaten yolda: cevabı paylaş
         TK_INFLIGHT[key].push(def);
         return def.promise();
      }
      TK_INFLIGHT[key] = [def];
      TK_QUEUE.push({opts:opts,key:key});
      runNext();
      return def.promise();
   };

   // Önbelleği elle boşaltmak için: TK_AJAX.temizle()
   CFG.temizle = function(){ TK_CACHE = {}; };
 }
})();

/* ==========================================================================
   v517-fix: ORTAK SERVİS CEVABI KATMANI
   Eskiden servis cevabı doğrudan JSON.parse'a veriliyordu. Oturum düştüğünde
   GİB login sayfası (HTML) döndüğü için kullanıcı ekranda
   "Unexpected token < in JSON at position 0" gibi bir mesaj görüyordu; bunun
   token süresiyle ilgili olduğunu anlamak mümkün değildi.
   tkParse aynı işi yapar ama ne olduğunu Türkçe söyler ve token sorununu
   ayırt eder.
   ========================================================================== */
function TkServisHatasi(nerede, mesaj, tokenSorunu){
  this.name       = 'TkServisHatasi';
  this.nerede     = nerede || 'Servis';
  this.tokenSorunu= !!tokenSorunu;
  this.message    = (nerede ? nerede + ': ' : '') + mesaj;
}
TkServisHatasi.prototype = Object.create(Error.prototype);
TkServisHatasi.prototype.constructor = TkServisHatasi;

/* Cevap metnini nesneye çevirir. Sorun varsa anlaşılır hata fırlatır. */
function tkParse(raw, nerede){
  if(raw == null || raw === ''){
    throw new TkServisHatasi(nerede, 'servisten boş cevap geldi (oturum düşmüş olabilir)', true);
  }
  if(typeof raw !== 'string') return raw;          // zaten nesneyse dokunma
  var t = raw.replace(/^﻿/, '').trim();
  if(t.charAt(0) === '<'){
    // JSON yerine HTML: neredeyse her zaman login sayfası veya ağ geçidi hatası
    throw new TkServisHatasi(nerede, 'servis JSON yerine HTML döndürdü — GİB oturumu düşmüş olabilir', true);
  }
  try{
    return JSON.parse(t);
  }catch(e){
    throw new TkServisHatasi(nerede, 'servis cevabı okunamadı (' + t.slice(0,60) + '…)', false);
  }
}

/* errorMessage metninden token/oturum kaynaklı mı anlamaya çalışır. */
function tkTokenHatasiMi(obj){
  if(!obj) return false;
  var m = String(obj.errorMessage || obj.message || obj.mesaj || '');
  return /oturum|session|token|yetki|login|giri[sş]|expired|unauthor|forbidden/i.test(m);
}

/* Ekranın üstünde kaybolmayan bir uyarı şeridi gösterir. */
function tkUyariGoster(mesaj, tokenSorunu){
  try{
    var id = 'tkHataSeridi';
    var el = document.getElementById(id);
    if(!el){
      el = document.createElement('div');
      el.id = id;
      el.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:2147483647;'+
        'background:#b00020;color:#fff;font:13px/1.5 Arial,Helvetica,sans-serif;'+
        'padding:9px 40px 9px 14px;box-shadow:0 2px 8px rgba(0,0,0,.35)';
      var kapat = document.createElement('button');
      kapat.textContent = '✕';
      kapat.style.cssText='position:absolute;right:8px;top:6px;background:transparent;'+
        'border:1px solid #fff;color:#fff;cursor:pointer;padding:1px 7px';
      kapat.onclick = function(){ el.parentNode && el.parentNode.removeChild(el); };
      el.appendChild(document.createElement('span')).id = id + 'Metin';
      el.appendChild(kapat);
      document.body.appendChild(el);
    }
    var ipucu = tokenSorunu
      ? ' → GİB intranet ekranını bir kez açıp tazeleyin, sonra sorguyu tekrarlayın.'
      : '';
    document.getElementById(id + 'Metin').textContent = mesaj + ipucu;
  }catch(e){}
}

/* Yakalanmamış hatalar sessizce konsola düşmesin. */
try{
  window.addEventListener('error', function(ev){
    var e = ev && ev.error;
    if(e && e.name === 'TkServisHatasi') tkUyariGoster(e.message, e.tokenSorunu);
  });
  window.addEventListener('unhandledrejection', function(ev){
    var e = ev && ev.reason;
    if(e && e.name === 'TkServisHatasi') tkUyariGoster(e.message, e.tokenSorunu);
  });
}catch(e){}


// --- TAKKOM patch: ensure parseMoney exists (compat) ---
if (typeof window !== 'undefined' && typeof window.parseMoney !== 'function') {
  window.parseMoney = function(v){
    try { return (typeof parseTlNum === 'function') ? parseTlNum(v) : (typeof v==='number'?v:0); } catch(e){ return 0; }
  };
}

// --- TAKKOM patch: lightweight $ shim (pre-jQuery) to avoid "$ is not defined" ---
(function(){
  if (typeof window === 'undefined') return;
  if (typeof window.$ === 'function') return; // jQuery already loaded
  function wrap(el){
    var api = {
      0: el || null,
      length: el ? 1 : 0,
      val: function(v){
        if (!el) return (arguments.length===0)? undefined : api;
        if (arguments.length===0) return el.value;
        el.value = v; return api;
      },
      text: function(v){
        if (!el) return (arguments.length===0)? undefined : api;
        if (arguments.length===0) return el.textContent;
        el.textContent = v; return api;
      },
      html: function(v){
        if (!el) return (arguments.length===0)? undefined : api;
        if (arguments.length===0) return el.innerHTML;
        el.innerHTML = v; return api;
      }
    };
    return api;
  }
  var shim = function(selector){
    try { return wrap(document.querySelector(selector)); }
    catch(e){ return wrap(null); }
  };
  shim.fn = {};
  window.$ = shim;
  window.jQuery = shim;
})();
 // ---------------------------------------------------------------------------

// -------------------------------------------------------

// --- TAKKOM çoklu token köprüsü: uzantının yakaladığı tokenleri yerel sayfaya alır ---
(function(){
  if(typeof window==='undefined' || window.__takkomCokluTokenBridgeInstalled) return;
  window.__takkomCokluTokenBridgeInstalled = true;
  function saveCache(cache){
    if(!cache) return;
    try{ localStorage.setItem('takkom_token_cache_v1', JSON.stringify(cache)); }catch(e){}
    try{
      var toks = cache.tokens || {};
      function val(names){ for(var i=0;i<names.length;i++){ var x=toks[names[i]] || cache[names[i]]; if(x && x.token) return x.token; if(typeof x==='string') return x; } return ''; }
      var g=val(['gibintranet','g']); if(g) localStorage.setItem('gibToken','token='+g);
      var k=val(['keys','gp']); if(k) localStorage.setItem('takkom_keys_token', k);
      var e=val(['evdbrapor','evdo','evdb']); if(e) localStorage.setItem('takkom_evdbrapor_token', e);
      var z=val(['izah','smiyb','izahaDavet']); if(z) localStorage.setItem('takkom_izah_token', z);
    }catch(e){}
  }
  window.addEventListener('message', function(ev){
    try{
      if(ev.source!==window) return;
      var d=ev.data||{};
      if(d.type==='TAKKOM_TOKEN_RESPONSE' && d.cache) saveCache(d.cache);
    }catch(e){}
  });
  window.takkomTokenBridgeRequest=function(){
    try{ window.postMessage({type:'TAKKOM_TOKEN_REQUEST', modules:['gibintranet','keys','evdbrapor','izah'], from:'takkom-common'}, '*'); }catch(e){}
  };
  setTimeout(window.takkomTokenBridgeRequest,100);
  setTimeout(window.takkomTokenBridgeRequest,1000);
  setTimeout(window.takkomTokenBridgeRequest,2500);
})();
function __takkomCleanToken(v){
  var t=String(v||'').trim();
  if(!t || t.indexOf('***')>=0 || t.indexOf('...')>=0) return '';
  for(var i=0;i<4;i++){
    var m=/[?&]token=([^&\s#]+)/i.exec(t) || /token%3D([^%&#\s]+)/i.exec(t);
    if(m && m[1]) t=m[1];
    try{ var d=decodeURIComponent(t); if(d===t) break; t=d; }catch(e){break;}
  }
  t=String(t||'').replace(/["'<>]/g,'').trim();
  return t.length>=20 ? t : '';
}
function __takkomTokenGetirRaw(moduleName){
  moduleName=String(moduleName||'gibintranet').toLowerCase();
  try{ if(window.takkomTokenBridgeRequest) window.takkomTokenBridgeRequest(); }catch(e){}
  var aliases={
    gibintranet:['gibintranet','g','gibIntranet','gib_intranet'],
    g:['gibintranet','g'],
    keys:['keys','gp','key','keysToken','gpToken'],
    gp:['keys','gp'],
    evdbrapor:['evdbrapor','evdo','evdb','evdbRapor','evdbRaporToken','evdorapor','evdoRapor'],
    evdo:['evdbrapor','evdo','evdb'],
    evdb:['evdbrapor','evdo','evdb'],
    izah:['izah','izahaDavet','smiyb','izahToken','izahServer'],
    smiyb:['izah','smiyb','izahaDavet']
  };
  var names=aliases[moduleName] || [moduleName];
  try{
    var raw=localStorage.getItem('takkom_token_cache_v1');
    if(raw){
      var obj=JSON.parse(raw); var toks=obj.tokens || {}; var by=obj.tokensByModule || {};
      for(var i=0;i<names.length;i++){
        var n=names[i];
        var vals=[toks[n]&&toks[n].token, by[n], obj[n]&&obj[n].token, obj[n]];
        for(var j=0;j<vals.length;j++){ var t=__takkomCleanToken(vals[j]); if(t) return t; }
      }
    }
  }catch(e){}
  try{
    var direct={gibintranet:['gibToken','token'],keys:['takkom_keys_token','keysToken','gpToken'],evdbrapor:['takkom_evdbrapor_token','evdbRaporToken','evdoRaporToken'],izah:['takkom_izah_token','izahToken','izahaDavetToken','smiybToken']};
    var dk=direct[moduleName] || [];
    for(var k=0;k<dk.length;k++){ var tt=__takkomCleanToken(localStorage.getItem(dk[k])); if(tt) return tt; }
  }catch(e){}
  return '';
}

/* v517-fix: takkomTokenGetir() sorgu başına yüzlerce kez çağrılıyordu ve her
   çağrıda localStorage okuyup JSON.parse ediyordu. Token saatlerce geçerli
   olduğu için kısa ömürlü bir bellek önbelleği güvenli ve çok daha hızlı.
   Uzantı yeni token yakalarsa en geç TTL kadar sonra görülür.            */
var __tkTokenMemo = {};
var __TK_TOKEN_TTL = 3000;
function takkomTokenGetir(moduleName){
  var k = String(moduleName||'gibintranet').toLowerCase();
  var now = Date.now();
  var e = __tkTokenMemo[k];
  if(e && (now - e.ts) < __TK_TOKEN_TTL) return e.v;
  var v = __takkomTokenGetirRaw(k);
  __tkTokenMemo[k] = {v:v, ts:now};
  return v;
}
takkomTokenGetir.temizle = function(){ __tkTokenMemo = {}; };

function token(){
  // Önce uzantının yakaladığı GİB intranet tokeni kullanılır; yoksa eski yerel mantığa dönülür.
  try{ var bt=takkomTokenGetir('gibintranet'); if(bt) return bt; }catch(e){}
  var tokenlink = localStorage.getItem('gibToken');
  var myRegexp= /token=([^&\s]+)/;
  if (!tokenlink) {
    tokenlink = $('#token').val();
    var mt = myRegexp.exec(tokenlink || '');
    return mt && mt[1] ? mt[1] : null;
  } else {
    var mt2 = myRegexp.exec(tokenlink || '');
    if (mt2 && mt2[1]) return mt2[1];
    return __takkomCleanToken(tokenlink) || null;
  }
}





//vdKodu,vdOrgId
/* v517-fix: vergi dairesi kodu normalizasyonu.
   Kaynak fikir: İş Takip + EYS Bot'taki itExtractVdKodu6 (content.js).
   Kod 6 hanelidir ama kullanıcı "016253 - ÇEKİRGE" gibi yapıştırabiliyor ya da
   baştaki sıfırı düşürüp "16253" yazabiliyor. Eskiden bu değer olduğu gibi
   saklanıyordu; sonuçta orgIDGetir/vdAdi undefined dönüyor ve isteğe
   orgOid="undefined" gidiyordu.                                            */
function tkVdKoduNormalize(v){
  var s = String(v == null ? '' : v).trim();
  if (!s) return '';
  var sadeceRakam = s.replace(/\D+/g, '');
  if (/^\d{6}$/.test(sadeceRakam)) return sadeceRakam;      // "016253", "016253 - ÇEKİRGE"
  var m = s.match(/(?:^|\D)(\d{6})(?:\D|$)/);               // metin içinde 6 hane
  if (m) return m[1];
  /* 5 hane girilmişse baştaki sıfır düşmüş olabilir; ancak tabloda
     karşılığı varsa kabul et — yoksa uydurma koda dönüşmesin. */
  if (/^\d{5}$/.test(sadeceRakam)) {
    var aday = '0' + sadeceRakam;
    try{
      if ((typeof __ORGID_MAP === 'object' && __ORGID_MAP[aday]) ||
          (typeof __VDADI_MAP === 'object' && __VDADI_MAP[aday])) return aday;
    }catch(e){}
  }
  return '';
}

/* Girilen kodun tablolarda karşılığı var mı? */
function tkVdKoduGecerliMi(kod){
  try{
    if (typeof __VDADI_MAP === 'object' && __VDADI_MAP[kod]) return true;
    if (typeof __ORGID_MAP === 'object' && __ORGID_MAP[kod]) return true;
  }catch(e){}
  return false;
}

function vdKodu(){
  // localStorage'dan vergi dairesi kodunu al
  var savedVdKodu = localStorage.getItem('vdKodu');
  if (savedVdKodu && savedVdKodu.trim() !== '') {
    /* Eskiden kaydedilmiş bozuk değerler de burada toparlanır */
    var norm = tkVdKoduNormalize(savedVdKodu);
    return norm || savedVdKodu.trim();
  }
  
}


function vdOrgId(){

var vd_kodu=vdKodu();

return orgIDGetir(vd_kodu);


}

function vdDiziGetir() {
    
        return ['016105','016111','016112','016201','016202','016203','016204','016205','016206','016207','016208','016250','016251','016252','016253','016254','016255','016256','016257','016258','016259','016260','016261'];
    }



function tabloSil(){

    $("#myTable").remove();
    $("#myTable1").remove();
    $("#myTable2").remove();
    $("#myTable4").remove();
    $("#myTable5").remove();
    $("#myTable6").remove();
    $("#myTable7").remove();
    $("#myTable8").remove();
    $("#myTable9").remove();
    $("#myTable10").remove();
    $("#myTable11").remove();
    $("#myTable12").remove();
    $("#myTable13").remove();
    $("#myTable14").remove();
    $("#myTable15").remove();
    $("#myTable16").remove();
    $("#myTable17").remove();
    $("#myTable18").remove();
    $("#myTable19").remove();
    $("#myTable20").remove();
    $("#myTable21").remove();
    $("#myTable22").remove();
    $("#myTable23").remove();
    $("#myTable24").remove();
    $("#myTable25").remove();
	$("#myTable700").remove();
	$("#myTable701").remove();
	$("#myTable702").remove();
	$("#myTable703").remove();
	$("#myTable704").remove();
	$("#myTable705").remove();
	$("#myTable706").remove();
    $("#error-container").remove();
    $("#notlar").remove();
    
    
    
}


function evdoRaporLogin(token){

	var url= 'http://10.251.63.99/evdorapor_server/assos-login?&assoscmd=shlogin&rtype=json&token=' + token;
	var user = postRemote(url);
	var obj =tkParse(user,'evdoRaporLogin');
	
	return (obj.token);


}


function sessionID(token){

	var callid=makeid(13) + '-';

	var url= 'http://10.251.63.99/evdorapor_server/dispatch?cmd=userSessionService_getUserSessionInfo&callid=';
	var url=url.concat(callid + '61&module=evdorapor', '&token=', token, '&jp=%7B%22rfDataInfo%22%3A%5B%5D%7D');
	var getURl = postRemote(url);
	var obj =tkParse(getURl,'sessionID');

	return (obj.data.ASessionId);

}


function izahaDavetRaporLogin(token){

	var url= 'http://arkaofis.gelbim.gov.tr:32174/izah-server/assos-login?&assoscmd=shlogin&rtype=json&token=' + token;
	var user = postRemote(url);
	var obj =tkParse(user,'izahaDavetRaporLogin');
	
	return (obj.token);


}

function izahaDavetsessionID(token){

	var callid=makeid(13) + '-';

	var url= 'http://arkaofis.gelbim.gov.tr:32174/izah-server/dispatch?cmd=userSessionService_getUserSessionInfo&callid=';
	var url=url.concat(callid + '61&module=izah', '&token=', token, '&jp=%7B%22rfDataInfo%22%3A%5B%7B%22rf%22%3A%22RF_IZAHA_DAVET_VERGI_DAIRELERI%22%2C%22v%22%3A%2234%22%7D%2C%7B%22rf%22%3A%22RF_IZAHA_DAVET_SMIYB_DURUMU%22%2C%22v%22%3A%2230%22%7D%2C%7B%22rf%22%3A%22RF_IZAHA_DAVET_KONU%22%2C%22v%22%3A%2231%22%7D%2C%7B%22rf%22%3A%22RF_IZAHA_DAVET_DURUMU%22%2C%22v%22%3A%2230%22%7D%2C%7B%22rf%22%3A%22RF_IZAHA_DAVET_ILLER%22%2C%22v%22%3A%2230%22%7D%2C%7B%22rf%22%3A%22RF_IZAHA_DAVET_KOMISYON_TURU%22%2C%22v%22%3A%2230%22%7D%5D%7D');
	var getURl = postRemote(url);
	var obj =tkParse(getURl,'izahaDavetsessionID');

	return (obj.data.ASessionId);

}

function izahaDavetLoginDestroy(token,SessionId){

	var callid=makeid(13) + '-';

//&jp=%7B%22ASessionId%22%3A%2291581607612453691525334678253371159158%22%7D

	var url= 'http://arkaofis.gelbim.gov.tr:32174/izah-server/dispatch?cmd=sessionCsapService_destroySession&callid=';
	var url=url.concat(callid + '22&module=izah', '&token=', token, '&jp=%7B%22ASessionId%22%3A%22',SessionId,'%22%7D');
	var getURl = postRemote(url);
	var obj =tkParse(getURl,'izahaDavetLoginDestroy');

	alert("İzaha Davet Oturumu Kapatıldı");	

}

function evdoRaporLoginDestroy(token,SessionId){

	var callid=makeid(13) + '-';

	var url= 'http://10.251.63.99/evdorapor_server/dispatch?cmd=sessionCsapService_destroySession&callid=';
	var url=url.concat(callid + '22&module=evdorapor', '&token=', token, '&jp=%7B%22ASessionId%22%3A%22',SessionId,'%22%7D');
	var getURl = postRemote(url);
	var obj =tkParse(getURl,'evdoRaporLoginDestroy');

	document.getElementById("oturumDurumu").innerHTML="Oturum Kapatıldı";

	document.getElementById("oturumDurumu").style.backgroundColor="Green";

	console.log("EVDB Rapor Oturumu Kapatıldı");	

}


function evdoRaporLoginDestroy2(token,SessionId){

	var callid=makeid(13) + '-';

	var url= 'http://10.251.63.99/evdorapor_server/dispatch?cmd=sessionCsapService_destroySession&callid=';
	var url=url.concat(callid + '22&module=evdorapor', '&token=', token, '&jp=%7B%22ASessionId%22%3A%22',SessionId,'%22%7D');
	var getURl = postRemote(url);
	var obj =tkParse(getURl,'evdoRaporLoginDestroy2');

	console.log("EVDB Rapor Oturumu Kapatıldı");	

}


function getAssosLogin(){

	if (evdbAssosLogin==""){

	 var evdbAssosLogin=prompt("EVDB Assos Login Şifrenizi Giriniz",localStorage.getItem("evdbAssosLogin"));
	   localStorage.setItem("evdbAssosLogin", evdbAssosLogin);


	}

	if (evdbRaporAssosLogin==""){

		var evdbRaporAssosLogin=prompt("EVDB Rapor Assos Login Şifrenizi Giriniz",localStorage.getItem("evdbRaporAssosLogin"));
	   localStorage.setItem("evdbRaporAssosLogin", evdbRaporAssosLogin);


	}
		  
 
  
}

 function ihbarname_getir(ihbarnameNo,token){
  
   
   window.open('http://10.251.63.99/evdorapor_server/pdf?params=%7B%22serviceName%22%3A%22evdoLRTarhiyatServices_ihbarnameFisnoSorgulama%22%2C%22reportName%22%3A%22RP_EVDO_IHBARNAME_FIS_SORGULAMA%22%2C%22IHBARNAME_FISNO%22%3A%22'+ihbarnameNo +'%22%7D&cmd=evdorapor&token='+token+'');
     
   
  }
  
   function tahakkuk_getir(tahakkukNo,token){
  
   
   window.open('http://10.251.63.99/evdorapor_server/pdf?params=%7B%22serviceName%22%3A%22evdoLRTahakkukServices_tahakkukFisiSorgulama%22%2C%22reportName%22%3A%22RP_EVDO_MUKELLEF_LISTELERI_THK_FISI_SORGULAMA%22%2C%22FISNUMARASI%22%3A%22' + tahakkukNo+ '%22%7D&cmd=evdorapor&token='+token+'');

   
  }
  
  
   function borc_getir(vkn,vade,token){
  
  
  //
   window.open('http://10.251.63.99/evdorapor_server/pdf?params=%7B%22serviceName%22%3A%22evdoLrBorcServices_belirliTariheKadarSorgulama%22%2C%22reportName%22%3A%22RP_EVDO_BORC_BELIRLITARIHEKADAR_SORGULAMA%22%2C%22VERGINO%22%3A%22'+vkn+'%22%2C%22TCKIMLIKNO%22%3A%22%22%2C%22PLAKANO%22%3A%22%22%2C%22ANAVERGIKODU%22%3A%22%22%2C%22SORGUTARIHI%22%3A%22'+vade+'%22%7D&cmd=evdorapor&token='+ token + '');
     
   
  }
  
   function tahakkuk_getir(tahakkukNo,token){
  
   
   window.open('http://10.251.63.99/evdorapor_server/pdf?params=%7B%22serviceName%22%3A%22evdoLRTahakkukServices_tahakkukFisiSorgulama%22%2C%22reportName%22%3A%22RP_EVDO_MUKELLEF_LISTELERI_THK_FISI_SORGULAMA%22%2C%22FISNUMARASI%22%3A%22' + tahakkukNo+ '%22%7D&cmd=evdorapor&token='+token+'');

   
  }
  
  
  function tahsilatListeGetir(vkn,token){
  
  //tahsilatta sadece vezne ve nakit olan ödemeleri getiriyor
  
  window.open('diger/tahsilat.html?vkn=' + vkn + "&token=" + token );
  
  }
  

function kdvMatrahgetir(vkn,yil,month){

	
	var callid=makeid(13) + '-';
	var tutar=0;

	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=bynIslemleriService_yilKdvBynSorgula&callid='; 
	var url5=url5.concat(callid + '122', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22%22%2C%22yil%22%3A%22',yil,'%22%7D');
	var liste = getRemote(url5);
	var obj =tkParse(liste,'kdvMatrahgetir');

	if (month=="01") {tutar= obj.data.liste[0].ay1;}
	else if (month=="02") {tutar= obj.data.liste[0].ay2;}
	else if (month=="03") {tutar= obj.data.liste[0].ay3;}
	else if (month=="04") {tutar= obj.data.liste[0].ay4;}
	else if (month=="05") {tutar= obj.data.liste[0].ay5;}
	else if (month=="06") {tutar= obj.data.liste[0].ay6;}
	else if (month=="07") {tutar= obj.data.liste[0].ay7;}
	else if (month=="08") {tutar= obj.data.liste[0].ay8;}
	else if (month=="09") {tutar= obj.data.liste[0].ay9;}
	else if (month=="10") {tutar= obj.data.liste[0].ay10;}
	else if (month=="11") {tutar= obj.data.liste[0].ay11;}
	else if (month=="12") {tutar= obj.data.liste[0].ay12;}
	
  if (tutar==""){return "Veri Yok";}else{return Number(tutar).toLocaleString("tr-TR");}

}


function kdvMatrahgetir1(vkn,yil,month,token){

	
	try{
	
	var callid=makeid(13) + '-';
	var tutar=0;
//	var vergi_dairesi=vdKodu();
	var vergi_dairesi="";
	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=bynIslemleriService_yilKdvBynSorgula&callid='; 
	var url5=url5.concat(callid + '122', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',vergi_dairesi,'%22%2C%22yil%22%3A%22',yil,'%22%7D');
	var liste = getRemote(url5);
	var obj =JSON.parse(liste);

	if (month=="01") {tutar= obj.data.liste[0].ay1;}
	else if (month=="02") {tutar= obj.data.liste[0].ay2;}
	else if (month=="03") {tutar= obj.data.liste[0].ay3;}
	else if (month=="04") {tutar= obj.data.liste[0].ay4;}
	else if (month=="05") {tutar= obj.data.liste[0].ay5;}
	else if (month=="06") {tutar= obj.data.liste[0].ay6;}
	else if (month=="07") {tutar= obj.data.liste[0].ay7;}
	else if (month=="08") {tutar= obj.data.liste[0].ay8;}
	else if (month=="09") {tutar= obj.data.liste[0].ay9;}
	else if (month=="10") {tutar= obj.data.liste[0].ay10;}
	else if (month=="11") {tutar= obj.data.liste[0].ay11;}
	else if (month=="12") {tutar= obj.data.liste[0].ay12;}
	
if (tutar==0){

		return 0;

	}else  if (tutar==""){
		
		return "Veri Yok";

	}else{
	
		return tlCevir(tutar);

		}

}



catch(err){

	return "Hata";

}

}

function tahsilat(vkn,vergiDairesi,vergiKodu,donem1,donem2) {

	try{

		
		var mukellef_sayisi=0;
		
		
		var callid=makeid(13) + '-';
		var org_id=orgIDGetir(vergiDairesi);

///

		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTahsilatService_tahsilatSorgula&callid=';
		var url=url.concat(callid + '17', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vergiKodu%22%3A%22',vergiKodu,'%22%2C%22basDonem%22%3A%22',donem1,'%22%2C%22bitDonem%22%3A%22',donem2,'%22%2C%22orgOid%22%3A%22',org_id,'%22%2C%22bastar%22%3A%22%22%2C%22bittar%22%3A%22%22%2C%22thsSekli%22%3A%22%22%2C%22odmSekli%22%3A%22%22%2C%22thsIslemTuru%22%3A%22%22%7D');
		var tahsilat = getRemote(url);
		var obj =JSON.parse(tahsilat);
		var tahsilat=0;


		$.each(obj.data, function(index, satir){
		  if (satir.islemTuru!="32"){   //Başka saymanlık adına otomatik tahsilat engelliyor.
				$.each(satir.thsSatirDetaylari, function(index, satir1){
					
				tahsilat=tahsilat + satir1.odenen + satir1.feri + satir1.tecilGz ;
		
			});

		}

		});


		return Number(tahsilat).toLocaleString("tr-TR");
	}


	catch(err){

		return "Hata ile karşılaşıldı";

	}

}  


function tahsilat1(vkn,vergiDairesi,vergiKodu,donem1,donem2,basTar,bitTar) {

	try{

		var mukellef_sayisi=0;
		var callid=makeid(13) + '-';
		var org_id=orgIDGetir(vergiDairesi);
		var nakit=0;
		var mahsup=0;
		var baskaSaymanlik=0;
		var diger=0;
		var sonTarihTahsilatDizi1=new Array();
///

		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTahsilatService_tahsilatSorgula&callid=';
		var url=url.concat(callid + '17', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vergiKodu%22%3A%22',vergiKodu,'%22%2C%22basDonem%22%3A%22',donem1,'%22%2C%22bitDonem%22%3A%22',donem2,'%22%2C%22orgOid%22%3A%22',org_id,'%22%2C%22bastar%22%3A%22',basTar,'%22%2C%22bittar%22%3A%22',bitTar,'%22%2C%22thsSekli%22%3A%22%22%2C%22odmSekli%22%3A%22%22%2C%22thsIslemTuru%22%3A%22%22%7D');
		var tahsilat = getRemote(url);
		var obj =JSON.parse(tahsilat);
		var tahsilat=0;
		var sonTarihTahsilatDizi=new Array();
		

		if (obj.data.length>0){

				$.each(obj.data, function(index, satir){

					  if (satir.islemTuru!="32"){   //Başka saymanlık adına otomatik tahsilat engelliyor.
					
							$.each(satir.thsSatirDetaylari, function(index, satir1){
							
							if (satir.thsSekli=="0" ||	satir.thsSekli=="1") { nakit= nakit + satir1.odenen + satir1.feri + satir1.tecilGz } //banka ve vezne ödemeleri

							else if (satir.thsSekli=="64") { mahsup= mahsup + satir1.odenen + satir1.feri + satir1.tecilGz } //Başka Saymanlık Tarafından ve mahsuben

							else if (satir.thsSekli=="4") { baskaSaymanlik= baskaSaymanlik + satir1.odenen + satir1.feri + satir1.tecilGz } //Başka Saymanlık Tarafından ve mahsuben

							else if (satir.thsSekli=="8" ||	satir.thsSekli=="16" ||	satir.thsSekli=="32") { diger= diger + satir1.odenen + satir1.feri + satir1.tecilGz } //diğer

							tahsilat=tahsilat + satir1.odenen + satir1.feri + satir1.tecilGz ;
						
							sonTarihTahsilatDizi.push(satir.odemeBelgeNo);

					
							});

					}

				});

				if (sonTarihTahsilatDizi.length>0){

					sonTarihTahsilatDizi1= sonTarihTahsilatDizi.sort();
					sonTarihTahsilat=(sonTarihTahsilatDizi1[sonTarihTahsilatDizi.length-1]).substr(0,8);

				
				}else{

				sonTarihTahsilat="";

				}

				return JSON.stringify({
					nakit: tlCevir(nakit),
					mahsup: tlCevir(mahsup),
					baskaSaymanlik: tlCevir(baskaSaymanlik),
					diger: tlCevir(diger),
					toplam: tlCevir(tahsilat),
					sonTarih: sonTarihTahsilat
				});

		}else{

		return JSON.stringify({
			nakit: "0,00",
			mahsup: "0,00", 
			baskaSaymanlik: "0,00", 
			diger: "0,00",
			toplam: "0,00",
			sonTarih: ""
		});
	}

	} catch(err) {
		console.log("tahsilat1 fonksiyonu hatası:", err);
		// Hata durumunda exception fırlat ki üst seviyede yakalanabilsin
		throw new Error("Tahsilat sorgulama hatası: " + err.message);
	}
}

function borcDurumu (vkno,vdkodu,vergiKodu,vadeTar1,vadeTar2) { // Tek Daire için borç sorgulama

try{
	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';
	var vadesiGecmis=0;
	var vadesiGelmemis=0;
	var orgID=orgIDGetir(vdkodu);
	
	var url_kdv= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkBorcService_detayliBorcBilgileriGetir&callid=';
	var url_kdv=url_kdv.concat(callid + '85', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgID,'%22%2C%22anaVergiKodu%22%3A%22',vergiKodu,'%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22%22%2C%22vergilendirmeDonemiBit%22%3A%22%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22unvan%22%3A%22%22%7D%7D');
	var kdv_borcu = getRemote(url_kdv);
	var obj_kdv_borcu =JSON.parse(kdv_borcu);
	
	vadesiGecmis = Number(obj_kdv_borcu.data.satir12).toLocaleString("tr-TR"); //M - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN TOPLAM BORÇ (A+F+G+I) GETİRİYOR
	vadesiGelmemis =Number(obj_kdv_borcu.data.satir13).toLocaleString("tr-TR"); //M - VADESİ GELMEMİŞ TOPLAM BORÇ (B+H+J)
	
	return "VADESİ GEÇMİŞ : " + vadesiGecmis + "<br>" + "VADESİ GELMEMİŞ : "  + vadesiGelmemis;
}


catch(err){

	return "Hata ile Karşılaşıldı";
}

	
}


function borcDurumu1 (vkno,vdkodu,vadeTar1,vadeTar2) { //tek vergi dairesi için sorgulama

try{
	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';
	var vadesiGecmis=0;
	var vadesiGelmemis=0;
	var orgID=orgIDGetir(vdkodu);
	
	var url_kdv= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkBorcService_detayliBorcBilgileriGetir&callid=';
	var url_kdv=url_kdv.concat(callid + '85', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgID,'%22%2C%22anaVergiKodu%22%3A%22%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22%22%2C%22vergilendirmeDonemiBit%22%3A%22%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22unvan%22%3A%22%22%7D%7D');
	var kdv_borcu = getRemote(url_kdv);
	var obj_kdv_borcu =JSON.parse(kdv_borcu);
	
	vadesiGecmis = Number(obj_kdv_borcu.data.satir12).toLocaleString("tr-TR"); //M - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN TOPLAM BORÇ (A+F+G+I) GETİRİYOR
	vadesiGelmemis =Number(obj_kdv_borcu.data.satir13).toLocaleString("tr-TR"); //M - VADESİ GELMEMİŞ TOPLAM BORÇ (B+H+J)
	
	return "VADESİ GEÇMİŞ : " + vadesiGecmis + "<br>" + "VADESİ GELMEMİŞ : "  + vadesiGelmemis;
}


catch(err){

	return "Hata ile Karşılaşıldı";
}

	
}


function borcDurumu2 (vkno,vdkodu,vergiKodu,vergiDonemi1,vergiDonemi2,vadeTar1,vadeTar2) {



	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';
	var vadesiGecmis=0;
	var vadesiGelmemis=0;
	var orgID=orgIDGetir(vdkodu);
	var hata=true;
	
	var hata_deneme=0;   /* v517-fix: sonsuz döngü koruması */
	while(hata){	
		if(++hata_deneme>3){ hata=false; throw new Error("borcDurumu2: servis 3 denemede de hata döndürdü (token süresi dolmuş olabilir)"); }

			var url_kdv= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkBorcService_detayliBorcBilgileriGetir&callid=';
			var url_kdv=url_kdv.concat(callid + '85', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgID,'%22%2C%22anaVergiKodu%22%3A%22',vergiKodu,'%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22',vergiDonemi1,'%22%2C%22vergilendirmeDonemiBit%22%3A%22',vergiDonemi2,'%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22unvan%22%3A%22%22%7D%7D');
			var kdv_borcu = getRemote(url_kdv);
			var obj_kdv_borcu =tkParse(kdv_borcu,'borcDurumu2');
			
			if (obj_kdv_borcu.error==undefined){

			hata=false;

			vadesiGecmis = Number(obj_kdv_borcu.data.satir12).toLocaleString("tr-TR"); //M - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN TOPLAM BORÇ (A+F+G+I) GETİRİYOR
			vadesiGelmemis =Number(obj_kdv_borcu.data.satir13).toLocaleString("tr-TR"); //M - VADESİ GELMEMİŞ TOPLAM BORÇ (B+H+J)
			
			return vadesiGecmis + "-" + vadesiGelmemis;

		}else{

			console.log("Hata ile Karşılaşıldı Tekrar Deneyeceğim " +  vkno + "-" + vdkodu );		

		}

	}
	
}


function borcDurumu3 (vkn,ilgiliVD,vadeTar1,vadeTar2) { // toplam borç sorgulama

try{
	
	var callid=makeid(13) + '-';
	var vadesiGecmis=0;
//	var orgID=orgIDGetir(vdkodu);
    var vd_listesi= hangiVD3(vkn);
	var toplamBorc=0;
	var toplamBorcAsli=0;
	var ilgiliVDBorc=0;
	var ihtisasBorc=0;
		$.each(vd_listesi, function(index, vd){
			 
			var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=borcService_borcBilgileriGetir&callid=';
			var url=url.concat(callid + '120', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22anaVergiKodu%22%3A%22%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22%22%2C%22vergilendirmeDonemiBit%22%3A%22%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22satirlar%22%3A%22447%22%2C%22detayliOzet%22%3A%222%22%7D%7D');
			var borc = getRemote(url);
			var obj =JSON.parse(borc);

			if (obj.error==undefined){
				
				if (obj.data.mVadesiGecmisBugunOdenmesiGerekenTop!=undefined){

					if (vd==ilgiliVD) { ilgiliVDBorc=ilgiliVDBorc + parseFloat(obj.data.mVadesiGecmisBugunOdenmesiGerekenTop); } //

					if (vd=="016250") { ihtisasBorc=ihtisasBorc + parseFloat(obj.data.mVadesiGecmisBugunOdenmesiGerekenTop); } //

					toplamBorc=toplamBorc + parseFloat(obj.data.mVadesiGecmisBugunOdenmesiGerekenTop); //M - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN TOPLAM BORÇ (A+F+G+I) GETİRİYOR

					toplamBorcAsli= toplamBorcAsli +  parseFloat(obj.data.aVadesiGecmis);  // A - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN VERGİ ASLI BORCU:

				}

			}else{

					toplamBorc="HATA";
					toplamBorcAsli="HATA";
					ilgiliVDBorc="HATA";
					ihtisasBorc="HATA";
			}
		});

		

	return  (tlCevir(toplamBorc) + "-" +  tlCevir(toplamBorcAsli) + "-" + tlCevir(ilgiliVDBorc) +  "-" + tlCevir(ihtisasBorc)) ;

}

catch(err){ 
	console.log("borcDurumu3 fonksiyonu hatası:", err);
	throw new Error("Borç sorgulama hatası: " + err.message);
}

}


function localTLconvert(veri){

 return (Number(veri).toLocaleString("tr-TR"));


}

function borcDurumu4 (vkn,vd,vadeTar1,vadeTar2) { // toplam borç sorgulama

try{
	
	var callid=makeid(13) + '-';

	var vadesiGecmis=0;

	var toplamBorc=0;
	
			 
			var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=borcService_borcBilgileriGetir&callid=';
			var url=url.concat(callid + '120', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22anaVergiKodu%22%3A%22%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22%22%2C%22vergilendirmeDonemiBit%22%3A%22%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22satirlar%22%3A%22447%22%2C%22detayliOzet%22%3A%222%22%7D%7D');
			var borc = getRemote(url);
			var obj =JSON.parse(borc);
		
	
				if (obj.data.mVadesiGecmisBugunOdenmesiGerekenTop!=undefined){

				toplamBorc=  parseFloat(obj.data.mVadesiGecmisBugunOdenmesiGerekenTop); //M - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN TOPLAM BORÇ (A+F+G+I) GETİRİYOR

				}
		

	return  tlCevir(toplamBorc) ;

}

	catch(err){ 

	return  "Hata ile karşılaşıldı" ;

	}

}
function borcDurumu5 (vkn,vd,vergiKodu,donem1,donem2,vadeTar1,vadeTar2) { // toplam borç sorgulama

try{
	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';
	var vadesiGecmis=0;

	var toplamBorc=0;
	
			 
			var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=borcService_borcBilgileriGetir&callid=';
			var url=url.concat(callid + '120', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22anaVergiKodu%22%3A%22',vergiKodu,'%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22',donem1,'%22%2C%22vergilendirmeDonemiBit%22%3A%22',donem2,'%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22satirlar%22%3A%22447%22%2C%22detayliOzet%22%3A%222%22%7D%7D');
			var borc = getRemote(url);
			var obj =JSON.parse(borc);
		
	
				if (obj.data.mVadesiGecmisBugunOdenmesiGerekenTop!=undefined){

				toplamBorc=  parseFloat(obj.data.mVadesiGecmisBugunOdenmesiGerekenTop); //M - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN TOPLAM BORÇ (A+F+G+I) GETİRİYOR

				}
		

	return  Number(toplamBorc).toFixed(2) ;

}

catch(err){ 

return  "Hata ile karşılaşıldı" ;

}

}

function borcDurumuVergiKoduAciklama(vkno,vergiKodu,donem1,donem2) {

try{

	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';
	var vdkodu=vdKodu();
	var orgID=vdOrgId();

	
	var url_kdv= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkBorcService_detayliBorcBilgileriGetir&callid=';
	var url_kdv=url_kdv.concat(callid + '85', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgID,'%22%2C%22anaVergiKodu%22%3A%22', vergiKodu ,'%22%2C%22vergiKodu%22%3A%22',vergiKodu,'%22%2C%22vergilendirmeDonemiBas%22%3A%22',donem1,'%22%2C%22vergilendirmeDonemiBit%22%3A%22',donem2,'%22%2C%22vadeBasTarih%22%3A%22%22%2C%22vadeBitTarih%22%3A%22%22%2C%22unvan%22%3A%22%22%7D%7D');
	var kdv_borcu = getRemote(url_kdv);
	var obj =JSON.parse(kdv_borcu);
	


	var aciklama = obj.data.borcDetaylari[0].thkBorcDetaylari[0].aciklama;
	var tutar = obj.data.borcDetaylari[0].thkBorcDetaylari[0].borc;

	return "Borç Tutarı : " + Number(tutar).toLocaleString("tr-TR") + " - Açıklama : " + aciklama;
	
	
}


catch(err){

	return "Hata ile Karşılaşıldı";
}

	
}

function borcDurumuGet (vkno,vdkodu,vadeTar1,vadeTar2,token) {

try{
	
	var callid=makeid(13) + '-';
	var vadesiGecmis=0;
	var vadesiGelmemis=0;
	
	var url_kdv= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkBorcService_detayliBorcBilgileriGetir&callid=';
	var orgOidDinamik = (typeof orgIDGetir==='function' ? (orgIDGetir(vdkodu) || '') : '');
	var url_kdv=url_kdv.concat(callid + '85', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgOidDinamik,'%22%2C%22anaVergiKodu%22%3A%22%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22%22%2C%22vergilendirmeDonemiBit%22%3A%22%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22unvan%22%3A%22%22%7D%7D');
	var kdv_borcu = getRemote(url_kdv);
	var obj_kdv_borcu =JSON.parse(kdv_borcu);
	
	vadesiGecmis = Number(obj_kdv_borcu.data.satir12).toLocaleString("tr-TR"); //M - VADESİ GEÇMİŞ VE BUGÜN ÖDENMESİ GEREKEN TOPLAM BORÇ (A+F+G+I) GETİRİYOR
	vadesiGelmemis =Number(obj_kdv_borcu.data.satir13).toLocaleString("tr-TR"); //M - VADESİ GELMEMİŞ TOPLAM BORÇ (B+H+J)
	
	return "VADESİ GEÇMİŞ : " + vadesiGecmis + "<br>" + "VADESİ GELMEMİŞ : "  + vadesiGelmemis;
}


catch(err){

	return "Hata ile Karşılaşıldı";
}

	
}

function izahToken (token) {


	
}


function vimerVarmi() {

try{
 	  var myRegex= /[0-9]+/;
      
      
      ;
      var callid=makeid(13) + '-';
      
      //
      
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=vimerService_isTalepGoruntuleme&callid=';
      var url5=url5.concat(callid + '12', '&token=', token(), '&jp=%7B%22talepNo%22%3A%22%22%2C%22vdKodu%22%3A%22',vdKodu() ,'%22%2C%22cagriDurumu%22%3A%221%22%2C%22cagriTuru%22%3A%220%22%2C%22cagriKonusu%22%3A%220%22%2C%22cagriDetayi%22%3A%220%22%2C%22basTar%22%3A%22%22%2C%22bitTar%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
      var kayit_sayisi=obj.data.talepListe.length;
      
      if (kayit_sayisi>0){ alert("Cevap Bekleyen VİMER Çağrısı Bulunmaktadır");}
      
}


catch(err){

	alert("Hata ile Karşılaşıldı");
}


}


function unvanDurumTahsilGuclugu(vkn,vd){

  var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};

	
	var callid=makeid(13) + '-';
	var hata=true;
	var hataDeneme=0;
	var ilgiDairethGucalacakList=0;
	var digerDairethGucalacakList=0;

	while(hata){

			var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
			var url5=url5.concat(callid + '203', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
			var daireler = getRemote(url5);
			var obj =tkParse(daireler,'unvanDurumTahsilGuclugu');


			
		if (obj.error==undefined){	

			hata=false;

			var unvan=obj.data.kimlikunvan;
			var durum =terkdurumu[obj.data.vdler.baglivd[0].mukblgislemturubittur];
			
			if (obj.data.thGucalacakList!=null) { 

			 	$.each(obj.data.thGucalacakList, function(index, satir){

					if (satir.vKodu==vd){   ilgiDairethGucalacakList++;   }else{ digerDairethGucalacakList++; }

				});
			
			}
			

			return  unvan + "//" + durum + "//" +  ilgiDairethGucalacakList + "//" + digerDairethGucalacakList  ;

		}else{

			hataDeneme++;

		 	if (hataDeneme>2){

				hata=false;

				console.log("unvanDurumTahsilGuclugu Sorgularken Hata ile Karşılaşıldı 3 Hata nedeniyle exception fırlatıyoruz-" +  vkn );

				throw new Error("Unvan sorgulama hatası: 3 deneme sonrası başarısız - VKN: " + vkn);
			
			}else{

				console.log("unvanDurumTahsilGuclugu - Tekrar Deniyoruz -" +  vkn );
		
			}

		}

	}

}

function zamanAsimi() {

  var bugun=new Date();
  
  var yil= bugun.getFullYear();
  
  return (yil-5);
    

}


function faaliyetDurumuGetir(vkn){

  
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};

try{
      var myRegex= /[0-9]+/;
      
      
      ;
      var callid=makeid(13) + '-';
      
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
   	

 	  var faal = terkdurumu[obj.data.vdler.baglivd[0].mukblgislemturubittur]  ; /// vergi dairesi listeliyor
	  var vd =  obj.data.vdler.baglivd[0].vdadi ; /// vergi dairesi listeliyor
	  var isebaslamatarihi=tarihFormat(obj.data.vdler.baglivd[0].isebaslamatarihi);	  
	  var isibirakmatarihi=tarihFormat(obj.data.vdler.baglivd[0].isibirakmatarihi);

//    return  "<a href='diger/sicil-tablo-getir.html?token=" + token() + "&vkn=" + vkn +  "' target='_blank' >" + isibirakmatarihi + "-" +  faal + "</a>" ;
	
	  return  isebaslamatarihi + "-" + isibirakmatarihi + "-" +  faal + "-" + vd ;
      
      }

	catch(err){

	return "Hata ile karşılaşıldı";
}
    
}


function faaliyetDurumuGetirGet(vkn){

  
		  var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};

	try{

 	      var tokenlink =GetUrlValue('token');
		  var callid=makeid(13) + '-';
		  
		  var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
		  var url5=url5.concat(callid + '15', '&token=', tokenlink, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
		  var daireler = getRemote(url5);
		  var obj =JSON.parse(daireler);
	   	

	 	  var faal = terkdurumu[obj.data.vdler.baglivd[0].mukblgislemturubittur]; /// vergi dairesi listeliyor
		  var isibirakmatarihi=tarihFormat(obj.data.vdler.baglivd[0].isibirakmatarihi);
		  return  "<a href='sicil-tablo-getir.html?token=" + tokenlink + "&vkn=" + vkn +  "' target='_blank' >" + isibirakmatarihi + "-" +  faal + "</a>" ;
		  
		  }

		catch(err){

		return "Hata ile karşılaşıldı";
	}
		
}


function muhasebe(vkn){

try{
      var myRegex= /[0-9]+/;
      
      
      ;
      var callid=makeid(13) + '-';
      var dizi=new Array();
      
      //

      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=bynIslemleriService_beyannameVerenBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '75', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vkodu%22%3A%22%22%2C%22basdonem%22%3A%22%22%2C%22bitdonem%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
   	
	     
	     
	     	$.each(obj.data.liste, function(index, satir){
	     	
	     	dizi.push(satir.tcknvkn_muh + "-" + satir.unvan_muh + "<br>");
	     	
	     	})
	     	
	  var yeni_dizi=   	removeDuplicates(dizi) ;

      return yeni_dizi.join("");
      
      
      }
      

	catch(err){

	return "Hata ile karşılaşıldı";
}  


}


function tumAdres(vkn){

try{
      var myRegex= /[0-9]+/;
      
      
      ;
      var callid=makeid(13) + '-';
      var dizi=new Array();
      
      //

      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_evdoYsicilMukAdresSorgulama&callid=';
      var url5=url5.concat(callid + '83', '&token=', token(), '&jp=%7B%22vergiNo%22%3A%22',vkn,'%22%2C%22ilKodu%22%3A%22%22%2C%22ilceKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
   	
	     
	     
	     	$.each(obj.data.liste2, function(index, satir){
	     	
	     	dizi.push(satir.acikadres1 + "<br>");
	     	
	     	
	     	})
	     	
	  var yeni_dizi= removeDuplicates(dizi) ;

      return yeni_dizi.join("");
      
      
      }
      

	catch(err){

		return "Hata ile karşılaşıldı";
	}  


}

function sicilOrtaklik(vkn){

try{
    
      var callid=makeid(13) + '-';
      var dizi=new Array();
    
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sirOrtYonTarihSorgulama&callid=';
      var url5=url5.concat(callid + '105', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22basTar%22%3A%2219800101%22%2C%22bitTar%22%3A%2220240311%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
   	
	     
	     
	     	$.each(obj.data.tuzelortak, function(index, satir){
	     	
	     	dizi.push("Ortak-" + satir.adsoyad + "<br>");
	     	
	     	
	     	});
	     	
	     	$.each(obj.data.tuzelyonetici, function(index, satir1){
	     	
	     	dizi.push("Yönetici-" + satir1.adsoyad + "<br>");
	     	
	     	
	     	});
	     	
	  var yeni_dizi= removeDuplicates(dizi) ;

      return yeni_dizi.join("");
      
      
      }
      

	catch(err){

	return "Hata ile karşılaşıldı";
}  


}

function mersisOrtaklik(vkn){
   
   try{ 
 		
		  
		  var callid=makeid(13) + '-';
		  var dizi=new Array();

		   
		  var url_muk_mersis= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_tuzelKisiOrtaklikBilgisiSorgula&callid=';
		  var url_muk_mersis=url_muk_mersis.concat(callid + '309', '&token=', token(), '&jp=%7B%22vergino%22%3A%22', vkn, '%22%2C%22unvan%22%3A%22%22%7D');
		  var muk_arastir_mersis = getRemote(url_muk_mersis);
		  var obj_muk_mersis_arastir =JSON.parse(muk_arastir_mersis);
		  

				
			$.each(obj_muk_mersis_arastir.data.firmaBilgileri, function(index, satir){
		   
			   var mersisno=satir.mersisno;
				unvan=satir.unvani; 
			 if (unvan.includes("ŞUBESİ")==false){
				  var url_mersis_liste= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_tuzelKisiOrtaklikDetayBilgisiSorgula&callid=';
				  var url_mersis_liste=url_mersis_liste.concat(callid + '311', '&token=', token(), '&jp=%7B%22mersisno%22%3A%22', mersisno, '%22%2C%22sirketturu%22%3A%22%22%7D');
				  var liste_mersis = getRemote(url_mersis_liste);
				  var obj_liste_mersis =JSON.parse(liste_mersis);  
				  
				  
				  $.each(obj_liste_mersis.data.temsilci, function(index, satir1){
				  			  
					dizi.push("Temsilci-" + satir1.tadisoyadi  + "<br>");
							
				  });
			  	  
					$.each(obj_liste_mersis.data.ortak, function(index, satir2){
					
						dizi.push("Ortak-" + satir2.oadisoyadi  + "<br>");
				 		
					});
			  
			  }
		   });
		   
			 var yeni_dizi= removeDuplicates(dizi) ;

			  return yeni_dizi.join("");

}
	catch(err){

	return "Hata ile karşılaşıldı";
}  

}
 
function faaliyetDurumuGetir1(vkn){

  
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};

	try{
      var myRegex= /[0-9]+/;
      
      
      ;
      var callid=makeid(13) + '-';
      
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
   	

 	  var faal = terkdurumu[obj.data.vdler.baglivd[0].mukblgislemturubittur]; /// vergi dairesi listeliyor
 	  
 	  
	     
      return  faal ;
      
      }

	catch(err){

	return "Hata ile karşılaşıldı";
}  

}


function iadeDosyaKapatma(token,iadeDosyaNo,vkno,tckn,tutar,muhasebe,iadeOid){



try{

	var callid=makeid(13) + '-';
	
	var url5= 'http://10.251.63.99/evdo_server/dispatch?cmd=EIadeMahsup_execute&callid=';
	var url5=url5.concat(callid + '292', '&token=', token, '&jp=%7B%22servisAdi%22%3A%22EVDO_IADEMAHSUP_IADEDOSYASI_TOPLU_KAPATMA%22%2C%22marj%22%3A%220%22%2C%22tableIadeDosyalari%22%3A%5B%7B%22iadedosyano%22%3A%22',iadeDosyaNo,'%22%2C%22vergino%22%3A%22',vkno,'%22%2C%22tckimlikno%22%3A%22',tckn,'%22%2C%22tutar%22%3A%22',tutar,'%22%2C%22muhasebelesen%22%3A%22',muhasebe,'%22%2C%22iadedosyasioid%22%3A%22',iadeOid,'%22%7D%5D%7D');
	var daireler = getRemote(url5);

	var obj =JSON.parse(daireler);

	return (obj.data.CORE_INFO_MESSAGE_ID);
	
	}
	
	catch(err){
	
	console.log(err);
	
	}
	

}

function faaliyetBilgiGetir(vkn){

try{

      var callid=makeid(13) + '-';
      
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
      
		var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
		var faaliyetDizi =new Array();
		var faaliyetKodu=new Array();
	 
	$.each(daireListesi, function(index, satir){
	
		 
		  var vdkodu=satir.vdkodu;
		  var birimOid= satir.birimoid;
		  var subeno = satir.subeno;
		  var isyerinitelik=satir.isyerinitelik;
		  var isyerituru= satir.isyerituru;
		  var mukblgoid=satir.mukblgoid;
		  
		  ////////////fAALİYET BİLGİLERİNİ GETİRECEZ
		  
			  var urlFaaliyet= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukSicilDetayBilgileriGetir&callid=';
			  var urlFaaliyet=urlFaaliyet.concat(callid + '56', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdkodu%22%3A%22',vdkodu,'%22%2C%22birimOid%22%3A%22',birimOid,'%22%2C%22subeno%22%3A%22',subeno,'%22%2C%22subeadi%22%3A%22%22%2C%22isyerituru%22%3A%22',isyerituru,'%22%2C%22isyerinitelik%22%3A%22',isyerinitelik,'%22%2C%22mukblgoid%22%3A%22',mukblgoid,'%22%7D');
			  var faaliyet = getRemote(urlFaaliyet);
			  var objFaaliyet =JSON.parse(faaliyet);
			  
			  var faaliyetListesi=objFaaliyet.data.faaliyetListesi.faaliyet;
			  
				  $.each(faaliyetListesi, function(index, satir1){
				  
					  if (faaliyetKodu.includes(satir1.faaliyetkod)){
					  
					  }else{
					  faaliyetKodu.push(satir1.faaliyetkod);
					  faaliyetDizi.push(satir1.faaliyetkod + "-" + satir1.faaliyetad + "<br>");
					  
					
					  
					  }
				  
				  });
	   	
	

	 });


	 faaliyetDizi =	removeDuplicates(faaliyetDizi);

 	 return faaliyetDizi;
	 
	



}

catch(err){

console.log(err);

}

}

function faaliyetBilgiGetir1(vkn){

try{

      var callid=makeid(13) + '-';
      
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
      
		var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
		var faaliyetDizi =new Array();
		var faaliyetKodu=new Array();
	
		 
		  var vdkodu=daireListesi[0].vdkodu;
		  var birimOid= daireListesi[0].birimoid;
		  var subeno = daireListesi[0].subeno;
		  var isyerinitelik=daireListesi[0].isyerinitelik;
		  var isyerituru= daireListesi[0].isyerituru;
		  var mukblgoid=daireListesi[0].mukblgoid;
		  
		  ////////////fAALİYET BİLGİLERİNİ GETİRECEZ
		  
			  var urlFaaliyet= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukSicilDetayBilgileriGetir&callid=';
			  var urlFaaliyet=urlFaaliyet.concat(callid + '56', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdkodu%22%3A%22',vdkodu,'%22%2C%22birimOid%22%3A%22',birimOid,'%22%2C%22subeno%22%3A%22',subeno,'%22%2C%22subeadi%22%3A%22%22%2C%22isyerituru%22%3A%22',isyerituru,'%22%2C%22isyerinitelik%22%3A%22',isyerinitelik,'%22%2C%22mukblgoid%22%3A%22',mukblgoid,'%22%7D');
			  var faaliyet = getRemote(urlFaaliyet);
			  var objFaaliyet =JSON.parse(faaliyet);
			  
			  var faaliyetListesi=objFaaliyet.data.faaliyetListesi.faaliyet;
			  
				  $.each(faaliyetListesi, function(index, satir1){
				  
					  if (faaliyetKodu.includes(satir1.faaliyetkod)){
					  
					  }else{
					  faaliyetKodu.push(satir1.faaliyetkod);
					  faaliyetDizi.push(satir1.faaliyetkod + "-" + satir1.faaliyetad + "<br>");
					  
					
					  
					  }
				  
				  });
	   	
	


	 faaliyetDizi =	removeDuplicates(faaliyetDizi);

 	 return faaliyetDizi;
	 
	



}

catch(err){

console.log(err);

return "Hata ile karşılaşıldı";

}

}

function ozesMukellefArastir(vkn){
 
try{
	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';

	//

	var url= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozelEsaslarListelemeService_mukellefArastirSonucListesiGetir&callid='; 
	var url=url.concat(callid + '23', '&token=', token(), '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%7D');
	var ozelesas = getRemote(url);
	var objOzelEsas =JSON.parse(ozelesas);
	var adresteBulunmama=0;

		$.each(objOzelEsas.data.liste, function(index, satir1){ //
		
		if (satir1.girisNedeni="014"){     adresteBulunmama= adresteBulunmama + 1;    }


		});

		$.each(objOzelEsas.data.ekListe, function(index, satir2){ //
		
		if (satir2.ataGirisNedeni="014"){     adresteBulunmama= adresteBulunmama + 1;    }


		});
		
		return adresteBulunmama;

}

	catch(err){

	return "Hata ile karşılaşıldı";
}  

}


function ozesMukellefArastir1(vkn){
 
try{
	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';

	//

	var url= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozelEsaslarListelemeService_mukellefArastirSonucListesiGetir&callid='; 
	var url=url.concat(callid + '23', '&token=', token(), '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%7D');
	var ozelesas = getRemote(url);
	var objOzelEsas =JSON.parse(ozelesas);
	var adresteBulunmama=0;

	

		$.each(objOzelEsas.data.ekListe, function(index, satir2){ //
		
		if (satir2.ataGirisNedeni="014"){     adresteBulunmama= adresteBulunmama + 1;    }


		});
		
		if (adresteBulunmama>0) {return "Devam Eden Adreste Bulunmama var";}else{ return "Yok"; }
		


}

	catch(err){

	return "Hata ile karşılaşıldı";
}  

}


function okcSorgula(vkn){
 
try{
	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';

	//

	var url= 'http://10.251.63.99/ozes_server/dispatch?cmd=odmKaydediciCihazService_odemeKaydediciTumunuGetir&callid='; 
	var url=url.concat(callid + '263', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdkodu%22%3A%22%22%7D');
	var ozelesas = getRemote(url);
	var obj =JSON.parse(ozelesas);
	var eskiOKC=0;
	var yeniOKC=0;
	

		$.each(obj.data.liste.sorguSonucu.liste, function(index, satir){ 
		
	
		
	     eskiOKC= obj.data.liste.sorguSonucu.liste.length;  


		});
		
		
		$.each(obj.data.liste.yeniNesil, function(index, satir1){ 
		
	
		
		if (satir1.status==1){     yeniOKC= yeniOKC + 1;    } 


		});
		
	
		return ("Eski OKC : " + eskiOKC + " - Yeni Nesil OKC : " + yeniOKC );
	
		


}

	catch(err){

	return (err);
}  

}


function faaliyetDurumuGet(vkn,token){

	try{
  
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};


      var callid=makeid(13) + '-';
      
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
      var url5=url5.concat(callid + '15', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
   	
    	if (obj.error==1) {return "Bir Hata ile Karşılaşıldı";}

 	 var faal = terkdurumu[obj.data.vdler.baglivd[0].mukblgislemturubittur]; /// vergi dairesi listeliyor
	     
      return  faal ;
      
      }
      
	catch(err){

	 	return "Hata ile karşılaşıldı";
	}  

}

function faaliyetDurumuGetir1(vkn){

  try{
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};

      var myRegex= /[0-9]+/;
      
      
      ;
      var callid=makeid(13) + '-';
      
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
   	
    	if (obj.error==1) {return "Bir Hata ile Karşılaşıldı";}

 	 var faal = terkdurumu[obj.data.vdler.baglivd[0].mukblgislemturubittur]; /// vergi dairesi listeliyor
	
      if (faal=="Faal"){
      
      return "<td style='background:red; color:white''>" + faal + "</td>";
      }else{
      return "<td>" + faal + "</td>";
      
      }
      
  }
      
      catch(err){
      
      	return "Hata ile karşılaşıldı";
      
      }

}


function temelDegisiklikTabloGetir (vkno){

	try{
		
		var mukellef_sayisi=0;
		
		
		var callid=makeid(13) + '-';

	  
		var url_temel= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_temelBilgiDegisiklikSorgula&callid=';
		var url_temel=url_temel.concat(callid + '22', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%7D');
		var temel_bilgi = getRemote(url_temel);
		var obj_temel_bilgi =JSON.parse(temel_bilgi);  

		var temel_bilgi_degisikligi =  obj_temel_bilgi.data.degisiklikBilgileri.tuzelDegisiklik;

		if (temel_bilgi_degisikligi!=undefined){

			$.each(temel_bilgi_degisikligi,function(index,satir){

			var kisaUnvan = satir.kisaunvan;

			if (kisaUnvan!=undefined){

			if (kisaUnvan.includes("YENİ KURULACAK")==false){

			$("#myTable5 tr:last").after( "<tr><td colspan='5'>" + kisaUnvan + "- İşlem tarihi " + tarih(satir.islemtarihi) + "</td></tr>");

			  }
			  
			}

			});

		}
	
	}
	
	catch(err){
	
		$("#myTable5 tr:last").after( "<tr><td colspan='5'>Hata ile karşılaşıldı</td></tr>");
	
	}
}

function temelDegisiklikTabloGetirGet(vkno){

	try{
	  var tokenlink =GetUrlValue('token');
		var callid=makeid(13) + '-';

	  
		var url_temel= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_temelBilgiDegisiklikSorgula&callid=';
		var url_temel=url_temel.concat(callid + '22', '&token=', tokenlink, '&jp=%7B%22vkn%22%3A%22',vkno,'%22%7D');
		var temel_bilgi = getRemote(url_temel);
		var obj_temel_bilgi =JSON.parse(temel_bilgi);  

		var temel_bilgi_degisikligi =  obj_temel_bilgi.data.degisiklikBilgileri.tuzelDegisiklik;

		if (temel_bilgi_degisikligi!=undefined){

			$.each(temel_bilgi_degisikligi,function(index,satir){

			var kisaUnvan = satir.kisaunvan;

			if (kisaUnvan!=undefined){

			if (kisaUnvan.includes("YENİ KURULACAK")==false){

			$("#myTable5 tr:last").after( "<tr><td colspan='5'>" + kisaUnvan + "- İşlem tarihi " + tarih(satir.islemtarihi) + "</td></tr>");

			  }
			  
			}

			});

		}
	
	}
	
	catch(err){
	
		$("#myTable5 tr:last").after( "<tr><td colspan='5'>Hata ile karşılaşıldı</td></tr>");
	
	}
}

function emanetKalanTutar(vkn) {

	try{

		
		var mukellef_sayisi=0;
		
		
		var callid=makeid(13) + '-';


		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkEmanetService_emanetKayitlariniGetir&callid=';
		var url=url.concat(callid + '163', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22orgoid%22%3A%22',vdOrgId(),'%22%7D%7D');
		var emanet = getRemote(url);
		var obj =JSON.parse(emanet);
		var kalanMiktar=0;


		$.each(obj.data.emanetverileri, function(index, satir){
				
		kalanMiktar=kalanMiktar + satir.kalanmiktar;		

		});


		return Number(kalanMiktar).toLocaleString("tr-TR");;
	}

	catch(err){

		return "Hata ile karşılaşıldı";

	}

}

function emanetKalanTutar1(vkn,vd) {

	try{

				
		var callid=makeid(13) + '-';

		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkEmanetService_emanetKayitlariniGetir&callid=';
		var url=url.concat(callid + '163', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vd,'%22%2C%22orgoid%22%3A%22',orgIDGetir(vd),'%22%7D%7D');
		var emanet = getRemote(url);
		var obj =JSON.parse(emanet);
		var emanetteKalanTutar=0;

		if (obj.data.emanetverileri.length>0){

			$.each(obj.data.emanetverileri, function(index, satir){
					
			emanetteKalanTutar=emanetteKalanTutar + parseFloat(satir.kalanmiktar);		

			});

		}

		return emanetteKalanTutar;
	}

	catch(err){

		console.log("Emanet sorgularken Hata ile karşılaşıldı."+ err);

		return "Hata";

	}

}

function ortakTakibiVarmi(vkn,vd) {

try{

	
	var mukellef_sayisi=0;
	
	
	var callid=makeid(13) + '-';
	var orgID = orgIDGetir(vd);

	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkOrtakTakipService_ortakTakipleriGetir&callid=';
	var url=url.concat(callid + '29', '&token=', token(), '&jp=%7B%22orgOid%22%3A%22',orgID,'%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22bastar%22%3A%2220090101%22%2C%22bittar%22%3A%22',bugunTarih(),'%22%7D');

	var emanet = getRemote(url);
	var obj =JSON.parse(emanet);
	
		

	  if (obj.data.liste.length>0) {
	  
	  
	  return ("<td style='background:red; color:white'><a href='../diger/ortak-takip.html?token=" + token() + "&vkn=" + vkn +  "' target='_blank'>Var</a></td>");  
	  
	  }else{
	  
	  return "<td>Yok</td>";
	  
	  }
		 			
	}
	

catch(err){

	return "Hata ile karşılaşıldı";

}      
	      


}

function ortakTakibiVarmi1(vkn) {

try{

	
	var mukellef_sayisi=0;
	
	
	var callid=makeid(13) + '-';

	//
//vdOrgId()
	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkOrtakTakipService_ortakTakipleriGetir&callid=';
	var url=url.concat(callid + '26', '&token=', token(), '&jp=%7B%22orgOid%22%3A%22',vdOrgId(),'%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22bastar%22%3A%2220090101%22%2C%22bittar%22%3A%22',bugunTarih(),'%22%7D');
	var emanet = getRemote(url);
	var obj =JSON.parse(emanet);
	
		

	  if (obj.data.result.length>0) {
	  
	  
	  return ("<a href='diger/ortak-takip.html?token=" + token() + "&vkn=" + vkn +  "' target='_blank'>Var</a>");  
	  
	  }else{
	  
	  return "Yok";
	  
	  }
		 			
	}
	

catch(err){

	return "Hata ile karşılaşıldı";

}      
	      


}

function ortakTakibiVarmi3(vkn,vd) {

try{


	var mukellef_sayisi=0;
	var callid=makeid(13) + '-';
	var orgID = orgIDGetir(vd);

	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkOrtakTakipService_ortakTakipleriGetir&callid=';
	var url=url.concat(callid + '29', '&token=', token(), '&jp=%7B%22orgOid%22%3A%22',orgID,'%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22bastar%22%3A%2220090101%22%2C%22bittar%22%3A%22',bugunTarih(),'%22%7D');

	var emanet = getRemote(url);
	var obj =JSON.parse(emanet);
	
	var kayit_sayisi = obj.data.result.length;	


	  if (kayit_sayisi>0) {

		var sonTarih=(obj.data.result[kayit_sayisi-1].anatkpdosyano).substr(0,8);
	  
 	    return tarihFormat3(sonTarih) ;  
	  
	  }else{
	  
		  return "";
	  
	  }
		 			
	}
	

catch(err){

	console.log("Ortak Takibi Hata ile karşılaşıldı." + err);

	return "Hata";


}      
	      


}


function ortakTakibiVarmi4(vkn,vd) {

try{


	var mukellef_sayisi=0;
	var callid=makeid(13) + '-';
	var orgID = orgIDGetir(vd);

	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkOrtakTakipService_ortakTakipleriGetir&callid=';
	var url=url.concat(callid + '29', '&token=', token(), '&jp=%7B%22orgOid%22%3A%22',orgID,'%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22bastar%22%3A%2220090101%22%2C%22bittar%22%3A%22',bugunTarih(),'%22%7D');

	var emanet = getRemote(url);
	var obj =JSON.parse(emanet);
	
	var kayit_sayisi = obj.data.result.length;	
	var ortakTakipYapilan=new Array();
	var takibiYapilanBorcToplami=0;
	  if (kayit_sayisi>0) {

		$.each(obj.data.result, function(index, satir){

			ortakTakipYapilan.push(satir.vergino);

			takibiYapilanBorcToplami = takibiYapilanBorcToplami + parseFloat(satir.borc);

			});


		
		var sonTarihAnaTakip=(obj.data.result[kayit_sayisi-1].anatkpdosyano).substr(0,8);

		var sonTarihVergiDonem=(obj.data.result[kayit_sayisi-1].vergiDonemi);
	  
 	    return tarihFormat3(sonTarihAnaTakip) + "*" + sonTarihVergiDonem + "*" + removeDuplicates(ortakTakipYapilan) + "*" + tlCevir(takibiYapilanBorcToplami)  ;  
	  
	  }else{
	  
		  return "";
	  
	  }
		 			
	}
	

catch(err){

	console.log("Ortak Takibi Hata ile karşılaşıldı." + err);

	return "Hata";


}      
	      


}


function eDefterKullanici(vkn) {

try{

	
	var mukellef_sayisi=0;
	
	
	var callid=makeid(13) + '-';
	var dizi =new Array();


	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=efaturaService_eDefterKayitliKullaniciSorgula&callid=';
	var url=url.concat(callid + '186', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%7D');
	var emanet = getRemote(url);
	var obj =JSON.parse(emanet);
	
		

	  if (obj.data.length>0) {
	  
	  		$.each(obj.data, function(index, satir){
	  		
	  				if (satir.neviYadaTerkTarihi==""){ 
				
					dizi.push("Başvuru Zamanı : " + satir.islemZamani + " - Uygulama Başlangıç Tarihi : " + satir.uygBaslamaTarihi + "<br>");
				
					}else{
					
					dizi.push("Başvuru Zamanı : " + satir.islemZamani + " - Uygulama Başlangıç Tarihi : " + satir.uygBaslamaTarihi + " - Uygulama Bitiş Tarihi : " + satir.neviYadaTerkTarihi + " - Bitiş Nedeni : " + satir.terkNedeni +   "<br>");
					
					}
				
				});				
	  
	  
	  }
	  
	  return dizi;
	  
	  }

catch(err){

	return "Hata ile karşılaşıldı";

}      
	      


}




function takipNoBul(vkno,tahakkukNo,token){


var callid=makeid(13) + '-';
var takip_dosya_no="";
var dizi=new Array();
		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTakipService_anaTakipleriGetir&callid='; 
		var url5=url5.concat(callid + '100', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22orgoid%22%3A%22',vdOrgId(),'%22%2C%22anavergikodu%22%3A%22%22%2C%22vergilendirmedonemibas%22%3A%22%22%2C%22vergilendirmedonemibit%22%3A%22%22%2C%22anatkpdurum%22%3A%22%22%7D%7D');
		var liste = getRemote(url5);
		var obj =tkParse(liste,'takipNoBul');

		$.each( obj.data.anatakipkayitlari, function(index, satir){
		
			var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTakipService_anaTakipDetayGetir&callid='; 
			var url6=url6.concat(callid + '102', '&token=', token, '&jp=%7B%22input%22%3A%7B%22orgoid%22%3A%22',vdOrgId(),'%22%2C%22anatkpdosyano%22%3A%22',satir.anatkpdosyano ,'%22%2C%22anavergikodu%22%3A%22%22%2C%22vergidonembas%22%3A%22%22%2C%22vergidonembit%22%3A%22%22%7D%7D');
			var liste1 = getRemote(url6);
			var obj1 =tkParse(liste1,'takipNoBul');
			
				$.each( obj1.data.takipdetaylari, function(index, satir1){
				
					if (tahakkukNo==satir1.thkfisno) { 	dizi.push(satir1.tkpdosyano + "-" + tarihFormat(satir1.tebligtarihi) +  "<br>");	}
				
				
				});				
						
		});
		
		return dizi;
		

}

function takipNoBul1(vkno,token){


var callid=makeid(13) + '-';
var takip_dosya_no="";
var dizi=new Map();
		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTakipService_anaTakipleriGetir&callid='; 
		var url5=url5.concat(callid + '100', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22orgoid%22%3A%22',vdOrgId(),'%22%2C%22anavergikodu%22%3A%22%22%2C%22vergilendirmedonemibas%22%3A%22%22%2C%22vergilendirmedonemibit%22%3A%22%22%2C%22anatkpdurum%22%3A%22%22%7D%7D');
		var liste = getRemote(url5);
		var obj =tkParse(liste,'takipNoBul1');

		$.each( obj.data.anatakipkayitlari, function(index, satir){
		
			var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTakipService_anaTakipDetayGetir&callid='; 
			var url6=url6.concat(callid + '102', '&token=', token, '&jp=%7B%22input%22%3A%7B%22orgoid%22%3A%22',vdOrgId(),'%22%2C%22anatkpdosyano%22%3A%22',satir.anatkpdosyano ,'%22%2C%22anavergikodu%22%3A%22%22%2C%22vergidonembas%22%3A%22%22%2C%22vergidonembit%22%3A%22%22%7D%7D');
			var liste1 = getRemote(url6);
			var obj1 =tkParse(liste1,'takipNoBul1');
			
				$.each( obj1.data.takipdetaylari, function(index, satir1){
				
					if (tahakkukNo==satir1.thkfisno) { 	dizi.push(satir1.tkpdosyano + "-" + tarihFormat(satir1.tebligtarihi) +  "<br>");	}
				
				
				});				
						
		});
		
		return dizi;
		

}

function emanetKontrol(vkn,belgeNo) {
try{
	
	var mukellef_sayisi=0;
	
	
	var callid=makeid(13) + '-';


	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkEmanetService_emanetKayitlariniGetir&callid=';
	var url=url.concat(callid + '163', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22orgoid%22%3A%22',vdOrgId(),'%22%7D%7D');
	var emanet = getRemote(url);
	var obj =JSON.parse(emanet);
	var kalanMiktar=0;


		$.each(obj.data.emanetverileri, function(index, satir){

			var belgeno=satir.belgeno;


			if (belgeNo==belgeno && satir.belgeturu!=14) { 

				kalanMiktar=kalanMiktar + satir.kalanmiktar;		

			}else{

				kalanMiktar=0;		
			}

	});


	return kalanMiktar;

}

catch(err){

	return "Hata ile Karşılaşıldı";

}

}

function emanetKontrolSGK(vkn,belgeNo) {

try{
	
	var mukellef_sayisi=0;
	
	
	var callid=makeid(13) + '-';

	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkEmanetService_emanetKayitlariniGetir&callid=';
	var url=url.concat(callid + '163', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22orgoid%22%3A%22',vdOrgId(),'%22%7D%7D');
	var emanet = getRemote(url);
	var obj =JSON.parse(emanet);
	var kalanMiktar=0;


	$.each(obj.data.emanetverileri, function(index, satir){

		var belgeno=satir.belgeno;

			if (belgeNo==belgeno && satir.belgeturu==14) { 

				kalanMiktar=satir.kalanmiktar;		

			}else if (belgeNo==belgeno && satir.belgeturu!=14) { 

				kalanMiktar="SGK'ya ödemek üzere Emanet kaydı yok";		

			}else{

				kalanMiktar=0;		
			}

	});


	return kalanMiktar;

}

catch(err){

	return "Hata ile karşılaşıldı";

}

}


function vknKontrol(){

var veri= $('#input').val();

veri = veri.replace(/'/g,"");  // tek tırnak (apostrophe) siler

veri = veri.replace(/\s/g,"");  //yapıştırılan vkn içinde boşlukları silmek için

veri = veri.replace(/-/g,"");  //yapıştırılan vkn içinde tire silmek için

if (veri.length==8) {veri = "00" + veri ;}

else if (veri.length==9) {veri =  "0" + veri ;}

else if (veri.length==11) {veri = vknGetirGet(veri,token());}

document.getElementById('input').value=veri;

return veri;


}

function boslukSil(veri){

veri = veri.replace(/\s/g,"");  //yapıştırılan vkn içinde boşlukları silmek için

veri = veri.replace(/-/g,"");  //yapıştırılan vkn içinde tire silmek için

return veri;


}


function vknKontrol1(token, veri){

try{

veri = veri.replace(/'/g,"");  // tek tırnak (apostrophe) siler

veri = veri.replace(/\s/g,"");  //yapıştırılan vkn içinde boşlukları silmek için

veri = veri.replace(/-/g,"");  //yapıştırılan vkn içinde tire silmek için

veri = veri.replace(/[^0-9]/g,"");  //yapıştırılan vkn içinde . silmek için



if (veri.length==8) {veri = "00" + veri ;}

if (veri.length==9) {veri =  "0" + veri ;}

if (veri.length==11) {veri = vknGetirGet(veri,token);}


return veri;

}


catch(err){

console.log(err);

return false;
}


}


function vknGetir(veri){


try{

	if (veri.length==11) {
	
		
		
		
		var callid=makeid(13) + '-';

		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
		var url=url.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22%22%2C%22tckn%22%3A%22', veri, '%22%2C%22vdKodu%22%3A%22%22%7D');
		var daireler = getRemote(url);
		var obj =JSON.parse(daireler);
   	
   		document.getElementById('input').value= obj.data.vkn;
   		
		return obj.data.vkn; 

	}else if (veri.length==10){

	return veri;
	
	}else{
	
	alert("10 haneli bir VKN girmeniz gerekmektedir.");
	
	}
	
}

	catch(err){

	alert("Hata ile karşılaşıldı");

	}	
	

}

function vknGetirGet(veri,token){

try{

		var callid=makeid(13) + '-';

		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukellefTcknVknBagliVDGetir&callid=';
		var url=url.concat(callid + '9', '&token=', token, '&jp=%7B%22vknTckn%22%3A%22',veri,'%22%7D');
		var daireler = getRemote(url);
		var obj =JSON.parse(daireler);  	
   		
		return obj.data.vkn; 

	

	
}

	catch(err){

	alert("Hata ile karşılaşıldı");

	}	
	

}

function tcGetir(vkn){

		
		
		
		var callid=makeid(13) + '-';

		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukellefTcknVknBagliVDGetir&callid=';
		var url=url.concat(callid + '9', '&token=', token(), '&jp=%7B%22vknTckn%22%3A%22',vkn,'%22%7D');
		var daireler = getRemote(url);
		var obj =tkParse(daireler,'tcGetir');
		return obj.data.tckn; 
      
      
}

function tcGetirGet(token,vkn){

	
		var callid=makeid(13) + '-';


		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukellefTcknVknBagliVDGetir&callid=';
		var url=url.concat(callid + '9', '&token=', token, '&jp=%7B%22vknTckn%22%3A%22',vkn,'%22%7D');
		var daireler = getRemote(url);
		var obj =tkParse(daireler,'tcGetirGet');
		return obj.data.tckn; 
      
      
}

function GetUrlValue(VarSearch)
{
    if (!VarSearch) return null;
    
    const params = new URLSearchParams(window.location.search);
    return params.get(VarSearch);
}



function sicilTabloGetir(vkno){

  
  var mukellef_sayisi=0;
  
  
  var callid=makeid(13) + '-';


	$('#tablo5').after(' <table id="myTable5" border=1> <caption>Araştırılan </caption>   <tr>     <th>Vergi No</th>     <th>TC</th>    <th>Ünvan</th> <th>Potansiyel</th> </tr>');

	try{

	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
	var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
	var daireler = getRemote(url5);
	var obj =JSON.parse(daireler);

	var vkn=obj.data.vkn; 
	var tckn=obj.data.tckn; 
	var unvan=obj.data.kimlikunvan; 
	if (obj.data.kimlikpotansiyel==9){var potansiyel="Potansiyel Mükellef"}else{ var potansiyel = " Değil " }

	$("#myTable5 tr:last").after( "<tr><td>" + vkno  + "</td><td>" + tckn  + "</td><td>" + unvan + "</td><td>" + potansiyel + "</td></tr>");

	}
	
	
	catch(err){
	
	$("#myTable5 tr:last").after( "<tr><td>" + vkno + "</td><td></td><td>Hata ile karşılaşıldı</td></tr>");
	
	}
}





function sicilTabloGetir2(vkno){
  
  var mukellef_sayisi=0;
  var callid=makeid(13) + '-';
  var vergikodu="0015";

  var iliski_tur_dizi={'3':'3 - Genel Müdür; Şirket Müdürü','2':'2 - Yönetim Kurulu Üyesi'};
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};
      var potansiyelListe ={'1':'Potansiyel Değil', '9':'Potansiyel'};
      var isyeriNitelikListe ={'1':'Merkez', '2':'Şube', '3':'Depo', '4':'KDV İhtisas Şubesi'};
       
      
  $('#tablo5').after(' <table id="myTable5" border=1> <caption>Araştırılan </caption>   <tr>     <th>Vergi No</th>     <th>TC</th>    <th>Ünvan</th> <th> Potansiyel </th></tr>');
   
  $('#tablo4').after('<table id="myTable4" border=1><caption>Mükellefiyet Bilgileri</caption><tr><th>İŞ YERİ NİTELİK</th><th>DAİRE KODU</th><th>DAİRE ADI</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAAL TERK</th><th>KDV Beyanı</th></tr>');
      
        
	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
	var url5=url5.concat(callid + '15', '&token=', token() , '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
	var daireler = getRemote(url5);
	var obj =tkParse(daireler,'sicilTabloGetir2');

	var vkn=obj.data.vkn; 
	var tckn=obj.data.tckn; 
	var unvan=obj.data.kimlikunvan; 
	if (obj.data.kimlikpotansiyel==9){var potansiyel="Potansiyel Mükellef"}else{ var potansiyel = " Değil " }
		
       $("#myTable5 tr:last").after( "<tr><td>" + vkn  + "</td><td>" + tckn  + "</td><td>" + unvan + "</td><td>" + potansiyel + "</td></tr>");
       
	var sicil_mesaj_liste=obj.data.hatakontrol;

		if (sicil_mesaj_liste!=undefined){

			$.each(sicil_mesaj_liste,function(index,satir){

				 $("#myTable5 tr:last").after( "<tr><td colspan='5'>" + satir.mesaj + "</td></tr>");

			});

		}
	
	

	var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
	  var isyerinitelik = satir.isyerinitelik;
	
		  
	  if (isyerinitelik==1 || isyerinitelik==4){
	  
	      var isyerinitelik = isyeriNitelikListe[isyerinitelik];   
	      
	      var bastarih =tarih(satir.isebaslamatarihi);  	      
	      var bittarih =tarih(satir.isibirakmatarihi);
	      
	      var mukblgislemturubittur=satir.mukblgislemturubittur;
	      var faal = terkdurumu[mukblgislemturubittur];
	    
	      $("#myTable4 tr:last").after( "<tr><td>" + isyerinitelik + "</td><td>" + satir.vdkodu  + "</td><td>" + satir.vdadi  + "</td><td>" + bastarih  + "</td><td>" + bittarih  + "</td><td>" + faal  + '</td><td><input rel="sorgula" class="w3-btn w3-green" onclick="beyanname_getir_guncel(\'' + vkno + '\',\'' + satir.vdkodu + '\',\'' +  vergikodu +   '\')"'  + "type='submit' value='Göster'> " + "</td></tr>");
	     	      
	 
	      
	    
	      
	 }
      
      });

}

function sicilTabloGetir3(vkno){
  
  var mukellef_sayisi=0;
  
  
  var callid=makeid(13) + '-';
  var vergikodu1="0001";
  var vergikodu2="0012";

  var iliski_tur_dizi={'3':'3 - Genel Müdür; Şirket Müdürü','2':'2 - Yönetim Kurulu Üyesi'};
  var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};
  var potansiyelListe ={'1':'Potansiyel Değil', '9':'Potansiyel'};
  var isyeriNitelikListe ={'1':'Merkez', '2':'Şube', '3':'Depo', '4':'KDV İhtisas Şubesi'};
        
      
  $('#tablo5').after(' <table id="myTable5" border=1> <caption>Araştırılan </caption>   <tr>     <th>Vergi No</th>     <th>TC</th>    <th>Ünvan</th>  <th>Potansiyel</th>  <th>Gelen Giden Evrak</th><th>Kesinti Listesi</th> </tr>');
   
  $('#tablo4').after('<table id="myTable4" border=1><caption>Mükellefiyet Bilgileri</caption><tr><th>İŞ YERİ NİTELİK</th><th>DAİRE KODU</th><th>DAİRE ADI</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAAL TERK</th><th>0001 Beyanı</th><th>0012 Beyanı</th></tr>');
      
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', token() , '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'sicilTabloGetir3');
	
	var vkn=obj.data.vkn; 
	var tckn=obj.data.tckn; 
	var unvan=obj.data.kimlikunvan; 
	if (obj.data.kimlikpotansiyel==9){var potansiyel="Potansiyel Mükellef"}else{ var potansiyel = " Değil " }
	
       $("#myTable5 tr:last").after( "<tr><td>" + vkn  + "</td><td>" + tckn  + "</td><td>" + unvan + "</td><td>" + potansiyel + "</td><td><a target='_blank' href='diger/gelen-giden-evrak.html?vkn=" + vkno + "&token=" + token() + "' > Evrak Getir</a></td><td><a target='_blank' href='diger/kesinti-getir.html?vkn=" + vkno + "&token=" + token() + "' > Kesinti Listesi Getir</a></td></tr>");
       $("#myTable5 tr:last").after( "<tr><td colspan='4' >Açık Adres : " +  adresSorgulama(tckn)  + "</td></tr>");
       
	var sicil_mesaj_liste=obj.data.hatakontrol;

		if (sicil_mesaj_liste!=undefined){

			$.each(sicil_mesaj_liste,function(index,satir){

				 $("#myTable5 tr:last").after( "<tr><td colspan='5'>" + satir.mesaj + "</td></tr>");

			});

		}
	
	

	var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
	  var isyerinitelik = satir.isyerinitelik;
	
		  
	  if (isyerinitelik==1 || isyerinitelik==4){
	  
	      var isyerinitelik = isyeriNitelikListe[isyerinitelik];   
	      
	      var bastarih =tarih(satir.isebaslamatarihi);  	      
	      var bittarih =tarih(satir.isibirakmatarihi);
	      
	      var mukblgislemturubittur=satir.mukblgislemturubittur;
	      var faal = terkdurumu[mukblgislemturubittur];
	    
	      $("#myTable4 tr:last").after( "<tr><td>" + isyerinitelik + "</td><td>" + satir.vdkodu  + "</td><td>" + satir.vdadi  + "</td><td>" + bastarih  + "</td><td>" + bittarih  + "</td><td>" + faal  + '</td><td><input rel="sorgula" class="w3-btn w3-green" onclick="beyanname_getir_guncel(\'' + vkno + '\',\'' + satir.vdkodu + '\',\'' +  vergikodu1 +   '\')"'  + "type='submit' value='Göster'> </td><td>" + '<input rel="sorgula" class="w3-btn w3-green" onclick="beyanname_getir_guncel(\'' + vkno + '\',\'' + satir.vdkodu + '\',\'' +  vergikodu2 +   '\')"'  + "type='submit' value='Göster'> </td></tr>");
	     	      
	 
	      
	    
	      
	 }
      
      });
      
	

}


function sicilTabloGetir4(vkno){
  
  var mukellef_sayisi=0;
  var callid=makeid(13) + '-';
  var vergikodu="0015";

  var iliski_tur_dizi={'3':'3 - Genel Müdür; Şirket Müdürü','2':'2 - Yönetim Kurulu Üyesi'};
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};
      var potansiyelListe ={'1':'Potansiyel Değil', '9':'Potansiyel'};
      var isyeriNitelikListe ={'1':'Merkez', '2':'Şube', '3':'Depo', '4':'KDV İhtisas Şubesi'};
       
      
  $('#tablo5').after(' <table id="myTable5" border=1> <caption>Araştırılan </caption>   <tr>     <th>Vergi No</th>     <th>TC</th>    <th>Ünvan</th> <th> Potansiyel </th></tr>');
   
  $('#tablo4').after('<table id="myTable4" border=1><caption>Mükellefiyet Bilgileri</caption><tr><th>İŞ YERİ NİTELİK</th><th>DAİRE KODU</th><th>DAİRE ADI</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAAL TERK</th><th>KDV Beyanı</th></tr>');
      
        
	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
	var url5=url5.concat(callid + '15', '&token=', token() , '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
	var daireler = getRemote(url5);
	var obj =tkParse(daireler,'sicilTabloGetir4');

	var vkn=obj.data.vkn; 
	var tckn=obj.data.tckn; 
	var unvan=obj.data.kimlikunvan; 
	if (obj.data.kimlikpotansiyel==9){var potansiyel="Potansiyel Mükellef"}else{ var potansiyel = " Değil " }
		
       $("#myTable5 tr:last").after( "<tr><td>" + vkn  + "</td><td>" + tckn  + "</td><td>" + unvan + "</td><td>" + potansiyel + "</td></tr>");
       
	var sicil_mesaj_liste=obj.data.hatakontrol;

		if (sicil_mesaj_liste!=undefined){

			$.each(sicil_mesaj_liste,function(index,satir){

				 $("#myTable5 tr:last").after( "<tr><td colspan='5'>" + satir.mesaj + "</td></tr>");

			});

		}


var tahsilGuclugu_Mesaj=obj.data.thGucalacakList;

		if (tahsilGuclugu_Mesaj.length>0){

			$.each(tahsilGuclugu_Mesaj,function(index,satir){

				 $("#myTable5 tr:last").after( "<tr><td colspan='5' style='color:red'>" + vdAdi(satir.vKodu) + " tarafından Tahsil Güçlüğüne alınmıştır</td></tr>");

			});

		}
	
	

	var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
	  var isyerinitelik = satir.isyerinitelik;
	
		  
	  if (isyerinitelik==1 || isyerinitelik==4){
	  
	      var isyerinitelik = isyeriNitelikListe[isyerinitelik];   
	      
	      var bastarih =tarih(satir.isebaslamatarihi);  	      
	      var bittarih =tarih(satir.isibirakmatarihi);
	      
	      var mukblgislemturubittur=satir.mukblgislemturubittur;
	      var faal = terkdurumu[mukblgislemturubittur];
	    
	      $("#myTable4 tr:last").after( "<tr><td>" + isyerinitelik + "</td><td>" + satir.vdkodu  + "</td><td>" + satir.vdadi  + "</td><td>" + bastarih  + "</td><td>" + bittarih  + "</td><td>" + faal  + '</td><td><input rel="sorgula" class="w3-btn w3-green" onclick="beyanname_getir_guncel(\'' + vkno + '\',\'' + satir.vdkodu + '\',\'' +  vergikodu +   '\')"'  + "type='submit' value='Göster'> " + "</td></tr>");
	     	      
	 
	      
	    
	      
	 }
      
      });

}

function unvanGetir(vkno){

try{
  
  var mukellef_sayisi=0;
  
  
  var callid=makeid(13) + '-';

  
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
	

	var unvan=obj.data.kimlikunvan; 
	
     return  unvan ;
}

  catch(err){
  
  	return "Hata ile Karşılaşıldı";
  	
  
  }

}


function unvanTCGetir(vkno){


  
  var mukellef_sayisi=0;
  
  
  var callid=makeid(13) + '-';

  //

        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
        var url5=url5.concat(callid + '36', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'unvanTCGetir');
	

		var unvan=obj.data.kimlikunvan; 
		var tckn=obj.data.tckn;
		
	
      return tckn + "-" + unvan ;
      


}





function unvanGetirGet(vkno,token){
  
  var callid=makeid(13) + '-';

  
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', token, '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'unvanGetirGet');
	

	var unvan=obj.data.kimlikunvan; 
	
     return  unvan ;


}

function unvanGetirTCdenGet(tc,token){
  
  var callid=makeid(13) + '-';

  
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', token, '&jp=%7B%22vkn%22%3A%22%22%2C%22tckn%22%3A%22',tc,'%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'unvanGetirTCdenGet');
	

	var unvan=obj.data.kimlikunvan; 
	
     return  unvan ;


}
function get_sicilTabloGetir(){


    var token = GetUrlValue('token');
    var vkno=GetUrlValue('vkn');
   var callid=makeid(13) + '-';

  $('#tablo5').after(' <table id="myTable5" border=1> <caption>Araştırılan</caption>   <tr>     <th>Vergi No</th>     <th>TC</th>    <th>Ünvan</th> </tr>');
     
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', token , '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'get_sicilTabloGetir');
	
	if (obj.error!="1"){
		var vkn=obj.data.vkn; 
		var tckn=obj.data.tckn; 
		var unvan=obj.data.kimlikunvan; 
		
		   $("#myTable5 tr:last").after( "<tr><td>" + vkn  + "</td><td>" + tckn  + "</td><td>" + unvan + "</td></tr>");
		   
		   }else{
		   
		   	  $("#myTable5 tr:last").after( "<tr><td colspan='3' >" +	 obj.messages[0].text  + "</td></tr>");
		   		   
		   }

	
}


function mukTumAdresGetir(){

try{

    var token = GetUrlValue('token');
    var vkno=GetUrlValue('vkn');
	var tckn= tcGetirGet(token,vkno);

   var callid=makeid(13) + '-';

  $('#tablo6').after(' <table id="myTable6" border=1> <caption>Tüm Adresler</caption><tr>	<th>Adres No</th>	<th>Yerleşim Yeri</th>    <th>Adres Türü</th>	<th>Beyan Kurum</th>	<th>Beyan Kişi</th>    <th>Beyan Tarihi</th> 	<th>Tescil Tarihi</th> 	<th>Taşınmaz Tarihi</th> 	<th>Adres Durumu</th> 	<th>Açıklamalar</th> </tr>');


      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mernisService_getTarihceliAdresBilgileri&callid=';
      var url5=url5.concat(callid + '94', '&token=', token , '&jp=%7B%22tckn%22%3A%22',tckn,'%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);

		$.each(obj.data.adres,function(index,satir){
		
		   $("#myTable6 tr:last").after( "<tr><td>" + satir.adrno  + "</td><td>" + satir.acikadres  + "</td><td>" + satir.adresturu + "</td><td>" + satir.beyanedenkurum + "</td><td>" + satir.beyankisi + "</td><td>" + tarihFormat(satir.beyantar) + "</td><td>" + tarihFormat(satir.tesciltar) + "</td><td>" + tarihFormat(satir.tasinmatar) + "</td><td>" + satir.adresdurum + "</td><td>" + satir.aciklama + "</td></tr>");

		});
}

catch(err)		   
	{

	   $("#myTable6 tr:last").after( "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td>" + err + "</td></tr>");

}
	
	
}


function get_sicilTabloGetir2(){


  var tokenlink = GetUrlValue('token');
   var vkno=GetUrlValue('vkn');
   var callid=makeid(13) + '-';
   var mukellef_sayisi=0;
 


  var vergikodu="0015";

  var iliski_tur_dizi={'3':'3 - Genel Müdür; Şirket Müdürü','2':'2 - Yönetim Kurulu Üyesi'};
      var terkdurumu ={'0':'Faal', '1':'', '2':'Terk', '3':'Nakil Halinde Terk', '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk','17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk','20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk','21':'21 - VUK 160/A Maddesi Kapsamında Terk'};
      var potansiyelListe ={'1':'Potansiyel Değil', '9':'Potansiyel'};
      var isyeriNitelikListe ={'1':'Merkez', '2':'Şube', '3':'Depo', '4':'KDV İhtisas Şubesi'};
        
      
  $('#tablo5').after(' <table id="myTable5" border=1> <caption>Araştırılan </caption>   <tr>     <th>Vergi No</th>     <th>TC</th>    <th>Ünvan</th> </tr>');
   
  $('#tablo4').after('<table id="myTable4" border=1><caption>Mükellefiyet Bilgileri</caption><tr><th>İŞ YERİ NİTELİK</th><th>DAİRE KODU</th><th>DAİRE ADI</th><th>BAŞLAMA TARİHİ</th><th>BİTİŞ TARİHİ</th><th>FAAL TERK</th><th>KDV Beyanı</th></tr>');
      
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=',tokenlink , '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'get_sicilTabloGetir2');
	
	var vkn=obj.data.vkn; 
	var tckn=obj.data.tckn; 
	var unvan=obj.data.kimlikunvan; 
	
       $("#myTable5 tr:last").after( "<tr><td>" + vkn  + "</td><td>" + tckn  + "</td><td>" + unvan + "</td></tr>");
       
	var sicil_mesaj_liste=obj.data.hatakontrol;

		if (sicil_mesaj_liste!=undefined){

			$.each(sicil_mesaj_liste,function(index,satir){

				 $("#myTable5 tr:last").after( "<tr><td colspan='5'>" + satir.mesaj + "</td></tr>");

			});

		}
	
	

	var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
	  var isyerinitelik = satir.isyerinitelik;
	
		  
	  if (isyerinitelik==1 || isyerinitelik==4){
	  
	      var isyerinitelik = isyeriNitelikListe[isyerinitelik];   
	      
	      var bastarih =tarih(satir.isebaslamatarihi);  	      
	      var bittarih =tarih(satir.isibirakmatarihi);
	      
	      var mukblgislemturubittur=satir.mukblgislemturubittur;
	      var faal = terkdurumu[mukblgislemturubittur];
	    
	      $("#myTable4 tr:last").after( "<tr><td>" + isyerinitelik + "</td><td>" + satir.vdkodu  + "</td><td>" + satir.vdadi  + "</td><td>" + bastarih  + "</td><td>" + bittarih  + "</td><td>" + faal  + '</td><td><input rel="sorgula" class="w3-btn w3-green" onclick="get_beyanname_getir_guncel(\'' + vkno + '\',\'' + satir.vdkodu + '\',\'' +  vergikodu +   '\')"'  + "type='submit' value='Göster'> " + "</td></tr>");
	     	      
	 
	      
	    
	      
	 }
      
      });

}



function get_matrahTecilno(vkno,vdkodu,thkNo) {

var tokenlink =GetUrlValue('token');
var callid=makeid(13) + '-';
var dizi =new Array();


    var orgOid=orgIDGetir(vdkodu);
    
	
    if (orgOid!="undefined") { 
    
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid=';
    var url=url.concat(callid + '197', '&token=', tokenlink, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22', orgOid ,'%22%2C%22tecilTip%22%3A%22%22%2C%22tclKaldirmaNdn%22%3A%22%22%7D%7D');


    var url_thk = getRemote(url);
    var obj =tkParse(url_thk,'get_matrahTecilno');

    var a=0;
    var b=0;

    var liste = obj.data.tecilKayitlari; /// 

      $.each(liste, function(index, satir){ //bütün tecil numaralarının tahakkuk numaralı kontrol ediliyor

	    
	    var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilDetayGetir&callid=';
	    var url1=url1.concat(callid + '30', '&token=', tokenlink, '&jp=%7B%22input%22%3A%7B%22tecilDosyaNo%22%3A%22',satir.tecilDosyaNo,'%22%2C%22tecilDilekceNo%22%3A%22%22%2C%22tecilDilekceTarihi%22%3A%22%22%2C%22tecildenKaldirmaTarihi%22%3A%22%22%2C%22tecildenKaldirmaNedeni%22%3A%22',satir.tecildenKaldirmaNedeni,'%22%2C%22ortakVkn%22%3A%22%22%2C%22ortakTckn%22%3A%22%22%2C%22plakano%22%3A%22%22%2C%22tecilTuru%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgOid,'%22%2C%22tecilTipi%22%3A%22',satir.tecilTipi,'%22%7D%7D');
	   
	    var url_thk1 = getRemote(url1);
	    var obj1 =tkParse(url_thk1,'get_matrahTecilno');
	    var tecil_thk=obj1.data.tecilSatirlari[0].thkfisno;
	    
	    
	    if (tecil_thk==thkNo) {
	   	    
	    dizi[0] = satir.tecilDosyaNo;

	    tecilOdenenToplamVab=obj1.data.tecilOdenenToplamVab;
	    
	    tecilOdenenToplamTecilFaizi=obj1.data.tecilOdenenToplamTecilFaizi;
	    
	    tecilToplamIndirim =obj1.data.tecilToplamIndirim;
	    
       toplam= Number(tecilOdenenToplamVab+tecilOdenenToplamTecilFaizi+tecilToplamIndirim).toLocaleString("tr-TR");
	    
       dizi[2]=toplam;
 
       dizi[1]= Number(obj1.data.tecilToplamVab).toLocaleString("tr-TR");
		    
	   dizi[3]= satir.tecildenKaldirmaNedeni;

	    }
	    
	    
	});

   
    }
    
     return dizi;

}

function bugunTarih(){

  var bugun=new Date();
  
  var yil= String(bugun.getFullYear());
  
  var gun = String(bugun.getDate());
  
  if (gun.length==1){   gun= "0" + gun;  }
  
  var ay = String(bugun.getMonth()+1);
  
  if (ay.length==1){   ay= "0" + ay;  }
  
  return yil + ay + gun;
    


}

function bugunTarih1(){

  var bugun=new Date();
  
  var yil= String(bugun.getFullYear());

  var ay = String(bugun.getMonth()+1);
  
  var gun = String(bugun.getDate());

  
 return yil + "-" + ay + "-" + gun  ;
    


}

function bugunTarih2(){

	var bugun=new Date();
	var yil= String(bugun.getFullYear());
	 var ay = String(bugun.getMonth()+1);
	var gun = String(bugun.getDate());
	var saat = String(bugun.getHours());
	var dakika = String(bugun.getMinutes());
	var saniye = String(bugun.getSeconds());

	return yil + "-" + ay + "-" + gun + "-" + saat + "-" + dakika  + "-" + saniye;
    


}

function iadeDosyaSure(iadeTakipNo,token){

var callid=makeid(13) + '-';

	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeIzlemeService_iadeTakipIzlemeIadeSureleri&callid='; 
	var url5=url5.concat(callid + '76', '&token=', token, '&jp=%7B%22input%22%3A%7B%22iadetakipno%22%3A%22',iadeTakipNo,'%22%2C%22merkez%22%3A%22%22%7D%7D');
	var liste = getRemote(url5);
	var obj =tkParse(liste,'iadeDosyaSure');
	var vdSure="";
	var mukSure="";
	var sure = "";
	
	if(obj.data.iadeDetay.length>0)	{
		
		for(i=0;i<obj.data.iadeDetay.length;i++){
				var label = obj.data.iadeDetay[i].label;
				var labelSure = obj.data.iadeDetay[i].value;
				if (label=="Vergi Dairesinde \nGeçen Süre"){
					vdSure=Number(labelSure)/(60*24);
				}else if (label=="Mükellefte \nGeçen Süre"){
					mukSure=Number(labelSure)/(60*24);
				}
				else if (label=="Deftardarlikta \nGeçen Süre"){
					vdSure=vdSure + Number(labelSure)/(60*24);
				}
		}

		return (Math.round(vdSure)+ "-" + Math.round(mukSure) );

	}else {
	
 		return ("-");

	}



}


function bugun(){

  var bugun=new Date();
  
  var yil= String(bugun.getFullYear());
  
  var gun = String(bugun.getDate());
  
  if (gun.length==1){   gun= "0" + gun;  }
  
  var ay = String(bugun.getMonth()+1);
  
  if (ay.length==1){   ay= "0" + ay;  }
  
  return gun + "-"+  ay + "-" + yil;
    


}

function bugun(){

  var bugun=new Date();
  
  var yil= String(bugun.getFullYear());
  
  var gun = String(bugun.getDate());
  
  if (gun.length==1){   gun= "0" + gun;  }
  
  var ay = String(bugun.getMonth()+1);
  
  if (ay.length==1){   ay= "0" + ay;  }
  
  return gun + "-"+  ay + "-" + yil;
    


}


function kapat(ekOid){

      document.getElementById(ekOid).style.display="none";
       
    
}

function adresSorgulama(tckno){

//

  
  var mukellef_sayisi=0;
  
  
  var callid=makeid(13) + '-';

  
      var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mernisService_getAdresBilgileri&callid=';
      var url1=url1.concat(callid + '88', '&token=', token(), '&jp=%7B%22tckn%22%3A%22',tckno,'%22%7D');
    
        var adres = getRemote(url1);
	var obj =tkParse(adres,'adresSorgulama');
	
      var hataVarmi=obj.error;
            
     if (hataVarmi==undefined || hataVarmi=="undefined" ){
     
    
     return obj.data.acikAdres;   
     
     }else{
     
    
     
     
     }
	
	

}

function devamEdenIadeBilgilerin (yil,tur){

    var myRegex= /[0-9]+/;


;
var callid=makeid(13) + '-';
var talep_sayisi=0;
var talep_tutari=0;

var evdbRaporAssosLogin=localStorage.getItem("evdbRaporAssosLogin");

      
   
      var url= 'http://10.251.63.99/evdorapor_server/dispatch?cmd=evdoLRIadeMahsupServices_iadeStandartDilekcelerListesi&callid=';
      var url=url.concat(callid + '1062', '&token=', evdbRaporAssosLogin, '&jp=%7B%22serviceName%22%3A%22evdoLRIadeMahsupServices_iadeStandartDilekcelerListesi%22%2C%22reportName%22%3A%22RP_EVDO_IADEMAHSUP_STANDARTDILEKCE_IADEDOSYASI_LISTESI%22%2C%22BASVERGIDONEM%22%3A%22%22%2C%22BITVERGIDONEM%22%3A%22%22%2C%22VERGIKODU%22%3A%22%22%2C%22VNOBASLANGIC%22%3A%220000000000%22%2C%22VNOBITIS%22%3A%224999999999%22%2C%22BASTARIHI%22%3A%22',yil,'0101%22%2C%22BITISTARIHI%22%3A%22',yil,'1231%22%2C%22DOSYADURUMU%22%3A%220%22%2C%22TALEPDETAY%22%3A%220%22%2C%22BASTCKIMLIKNO%22%3A%22%22%2C%22BITTCKIMLIKNO%22%3A%22%22%2C%22DZTMUHDURUM%22%3A%225%22%2C%22DILEKCETIPI%22%3A%22',tur,'%22%2C%22DOSYADURUMUSTR%22%3A%22Aktifler%22%2C%22SERVISOID%22%3A%2200000000000001%22%2C%22SERVISADI%22%3A%22%C3%87EK%C4%B0RGE%20VERG%C4%B0%20DA%C4%B0RES%C4%B0%22%2C%22DILEKCEDETAY%22%3A%22%25%22%7D');
      var daireler = getRemote(url);
      var obj =tkParse(daireler,'devamEdenIadeBilgilerin');
      var hataVarmi=obj.messages;   
    
	    if (hataVarmi=="undefined" || hataVarmi==undefined) {
		  
		  $.each(obj.data.VERILER, function(index, satir){
		  
		  talep_sayisi=talep_sayisi + 1;
	          
	          //talep_tutari=talep_tutari + Number(satir.TUTAR);
		
		
		  });
	      
	      }
	      
	      
      var url= 'http://10.251.63.99/evdorapor_server/dispatch?cmd=evdoLRIadeMahsupServices_iadeStandartDilekcelerListesi&callid=';
      var url=url.concat(callid + '1062', '&token=', evdbRaporAssosLogin , '&jp=%7B%22serviceName%22%3A%22evdoLRIadeMahsupServices_iadeStandartDilekcelerListesi%22%2C%22reportName%22%3A%22RP_EVDO_IADEMAHSUP_STANDARTDILEKCE_IADEDOSYASI_LISTESI%22%2C%22BASVERGIDONEM%22%3A%22%22%2C%22BITVERGIDONEM%22%3A%22%22%2C%22VERGIKODU%22%3A%22%22%2C%22VNOBASLANGIC%22%3A%225000000000%22%2C%22VNOBITIS%22%3A%229999999999%22%2C%22BASTARIHI%22%3A%22',yil,'0101%22%2C%22BITISTARIHI%22%3A%22',yil,'1231%22%2C%22DOSYADURUMU%22%3A%220%22%2C%22TALEPDETAY%22%3A%220%22%2C%22BASTCKIMLIKNO%22%3A%22%22%2C%22BITTCKIMLIKNO%22%3A%22%22%2C%22DZTMUHDURUM%22%3A%225%22%2C%22DILEKCETIPI%22%3A%22',tur,'%22%2C%22DOSYADURUMUSTR%22%3A%22Aktifler%22%2C%22SERVISOID%22%3A%2200000000000001%22%2C%22SERVISADI%22%3A%22%C3%87EK%C4%B0RGE%20VERG%C4%B0%20DA%C4%B0RES%C4%B0%22%2C%22DILEKCEDETAY%22%3A%22%25%22%7D');
      var daireler = getRemote(url);
      var obj =tkParse(daireler,'devamEdenIadeBilgilerin');
      var hataVarmi=obj.messages;   
    
	    if (hataVarmi=="undefined" || hataVarmi==undefined) {
		  
		  $.each(obj.data.VERILER, function(index, satir){
		  
		  talep_sayisi=talep_sayisi + 1;
	          
	          //talep_tutari=talep_tutari + Number(satir.TUTAR);
		
		
		  });
	      
	      }
      
   
      
      
      return talep_sayisi;	

}



function tapuBilgileri(tapuId,vkn){

var myRegex= /[0-9]+/;


;
var callid=makeid(13) + '-';


 var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=gayrimenkulService_gayrimenkulAlansatan1noluFormSorgulama&callid=';
 var url5=url5.concat(callid + '33', '&token=', token(), '&jp=%7B%22tasinmazid%22%3A%22',tapuId,'%22%2C%22vkn0%22%3A%22',vkn,'%22%2C%22tckn0%22%3A%22%22%2C%22vkn1%22%3A%22%22%2C%22tckn1%22%3A%22%22%2C%22islemid%22%3A%22171628124%22%2C%22kurum%22%3A%22Nil%C3%BCfer%22%2C%22il%22%3A%22BURSA%22%2C%22ilce%22%3A%22N%C4%B0L%C3%9CFER%22%2C%22mahKoy%22%3A%22AK%C3%87ALAR%22%2C%22cins%22%3A%22DA%C4%B0RE%22%2C%22adaNo%22%3A%22144%22%2C%22parselNo%22%3A%2231%22%2C%22yuzOlcum%22%3A%220%22%7D');
 var evrak = getRemote(url5);
 var obj =tkParse(evrak,'tapuBilgileri');

}



function tarih(tarih_veri){

      if(tarih_veri != ""){
		var year2 = parseFloat(tarih_veri.substring(0,4));
		var month2 = parseFloat(tarih_veri.substring(4,6));
		var day2 = parseFloat(tarih_veri.substring(6,8));
		    
		    return (day2 + '.'+ month2 + '.' + year2);
		    
      }else{
      
      return '';
      }



}

function tarihFormat(tarih_veri){


      if(tarih_veri != "" && tarih_veri != null ){
		var year2 = parseFloat(tarih_veri.substring(0,4));
		var month2 = parseFloat(tarih_veri.substring(4,6));
		var day2 = parseFloat(tarih_veri.substring(6,8));
		    
		    return (day2 + '.'+ month2 + '.' + year2);
		    
      }else{
      
      return '';
      }

}

function tarihFormat1(tarih_veri){

      if(tarih_veri != ""){
		var year2 = parseFloat(tarih_veri.substring(0,4));
		var month2 = parseFloat(tarih_veri.substring(4,6));
		var day2 = parseFloat(tarih_veri.substring(6,8));
		    
		    return (year2 + '-'+ month2 + '-' + day2);
		    
      }else{
      
      return '';
      }



}


function tarihFormat2(tarih_veri){

      if(tarih_veri != "" && tarih_veri != null ){
		var year2 = tarih_veri.substring(6,10);
		var month2 = tarih_veri.substring(10,12);
		var day2 = tarih_veri.substring(12,14);
		    
		    return (day2 + '/'+ month2 + '/' + year2);
		    
      }else{
      
      return '';
      }



}




function tarihFormat3(tarih_veri){


	if(tarih_veri =="Hata") {return "Hata";}


      if(tarih_veri != "" && tarih_veri != null  && tarih_veri != "undefined" && tarih_veri != undefined){
		var year2 = tarih_veri.substring(0,4);
		var month2 = tarih_veri.substring(4,6);
		var day2 = tarih_veri.substring(6,8);
		    
		    return (year2 + '-'+ month2 + '-' + day2 );
		    
      }else{
      
      return ' ';
      }



}



function donemDonustur(veri){


      if(veri != "" && veri != null ){
		var year2 = parseFloat(veri.substring(0,4));
		var month2 = parseFloat(veri.substring(4,6));
				    
		    return (year2 + '-'+ month2);
		    

      }else{
      
      return '';
      }

}


function donemDonustur1(veri){


      if(veri != "" && veri != null ){
		var year2 = parseFloat(veri.substring(3,7));
		var month2 = veri.substring(0,2);
		
			    
		    return (year2 + '-'+ month2);
		    

      }else{
      
      return '';
      }

}


function donemDonustur2(veri){


      if(veri != "" && veri != null ){
		var year2 = veri.substring(0,4);
		var month2 = veri.substring(4,6);
				    
		    return (year2 + month2);
		    

      }else{
      
      return '';
      }

}

function cariDonem(){


	return donemDonustur2(bugunTarih());


}
function kullanmaTespiti(servis,asama){

var myRegex= /[0-9]+/;


;
var callid=makeid(13) + '-';


      if (servis==1){

      var servisAralik={'vn1':'0000000000','vn2':'3249999999'};

      }else if (servis==2){

      var servisAralik={'vn1':'3250000000','vn2':'6349999999'};


      }else if (servis==3){

      var servisAralik={'vn1':'6350000000','vn2':'9999999999'};


      }
      
      
      if (asama==1) {
      
      var asama="K10";
      
      }else{
      
      var asama="KE1";
      
      }
      
      
	    
      
      var url5= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozelEsaslarListelemeService_kulTespListesiGetir&callid=';
      var url5=url5.concat(callid + '94', '&token=', token(), '&jp=%7B%22vdIlKodu%22%3A%22',vdKodu(),'%22%2C%22basVkn%22%3A%22', servisAralik['vn1'],'%22%2C%22bitVkn%22%3A%22',servisAralik['vn2'],'%22%2C%22basTckn%22%3A%22%22%2C%22bitTckn%22%3A%22%22%2C%22akisDurumu%22%3A%22',asama,'%22%2C%22parafSayisi%22%3A%22%22%2C%22raporAralikBas%22%3A%22%22%2C%22raporAralikBit%22%3A%22%22%2C%22lastUpdateOptimeBas%22%3A%22%22%2C%22lastUpdateOptimeBit%22%3A%22%22%2C%22listFilter%22%3A%22VD_MEMUR%22%2C%22respKeyParam%22%3A%22liste%22%2C%22pv%22%3A%7B%22start%22%3A0%2C%22limit%22%3A%221	%22%2C%22sorters%22%3A%5B%5D%7D%7D');
      var evrak = getRemote(url5);
      var obj =tkParse(evrak,'kullanmaTespiti');

      if (obj.data.toplam==undefined || obj.data.toplam=='undefined' ){
      
      return 'Bir Hata ile Karşılaşıldı';
      
      }else{
      
      return obj.data.toplam;
      
      }
      
      

      
      
      

}


function yoklamaBilgisi(vkn){

      var myRegex= /[0-9]+/;
      
      
      
      var callid=makeid(13) + '-';


      var url= 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch?cmd=srvcYoklamalar_getEskiYoklamaListesi&callid=';
      var url=url.concat(callid + '165', '&token=', token(), '&jp=%7B%22vdkodu%22%3A%22',vdKodu(),'%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22sessionData%22%3A%7B%22rol%22%3A10%2C%22user%22%3A%22%22%2C%22giris%22%3A%22%22%2C%22birim%22%3A%22',vdKodu(),'%22%2C%22il%22%3A%22016%22%2C%22adi%22%3A%22%22%7D%7D');
      var yoklama = getRemote(url);
      var obj_yoklama =tkParse(yoklama,'yoklamaBilgisi');
     
      var yoklamaListesi=obj_yoklama.data; 
      
      
      
      /* 
       var yoklama_dizi=new Array();
      yoklama_dizi=obj_yoklama.data;
      var yoklamaDizi=new Array();
      var a=0;
      
      $.each(yoklama_dizi, function(index, value){ //bütün tecil numaralarının tahakkuk numaralı kontrol ediliyor

      var esonuc=yoklama_dizi['esonuc'];
      var eykodu=yoklama_dizi['eykodu'];
      var egiristar=tarih(yoklama_dizi['egiristar']);
       
       yoklamaDizi[a]= esonuc + "- " +  eykodu + "- " + egiristar +  "<hr><br>";
	
	a=a+1;
	    
	});

      //return (yoklamaListesi);
      
      return yoklamaDizi;*/
      
      return (yoklamaListesi);
      
}




function ozel_esas(vkn,tokenlink){
	try {

	
    var callid=makeid(13) + '-';



	var url= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_mukellefSorgulamaSonucListesiGetirDurumMain&callid=';
	var url=url.concat(callid + '122', '&token=', tokenlink , '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%7D');
	var olumsuzluk = getRemote(url);
	var obj =JSON.parse(olumsuzluk);
	var durum="Yok";
	
	if (obj.data.listBir=="visible"){ durum="Var"; 	}

	else if (obj.data.listIki=="visible"){ durum="Var";	}

	else if (obj.data.listUc=="visible"){durum="Var";	}

	else if (obj.data.listDort=="visible"){durum="Var";	}

	else if (obj.data.listBes=="visible"){durum="Var";	}

	else if (obj.data.listAlti=="visible"){durum="Var";	}

	else if (obj.data.listYedi=="visible"){durum="Var";	}

	else if (obj.data.listSekiz=="visible"){durum="Var";	}

	else if (obj.data.listDokuz=="visible"){durum="Var";	}
	
	else if (obj.data.listOn=="visible"){durum="Var";	}

	else if (obj.data.listOnbir=="visible"){durum="Var";	}

	else if (obj.data.listOniki=="visible"){durum="Var";	}
	
	else if (obj.data.listOnuc=="visible"){durum="Var";	}


//	if (durum=="Var"){ return "<a href='diger/ozel-esas-getir.html?token=" + tokenlink + "&vkn=" + vkn +  "' target='_blank'>Olumsuz rapor/tespit var</a>"; }else{ return durum; }

	return durum;

	}

	catch(err){

	return "Hata ile Karşılaşıldı";
}	
}

function ozel_esasGet(vkno,token){


  var callid=makeid(13) + '-';


var url= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozelEsaslarListelemeService_mukellefSorgulamaSonucListesiGetir&callid=';
      var url=url.concat(callid + '92', '&token=', token, '&jp=%7B%22mukVkn%22%3A%22', vkno, '%22%2C%22mukTckn%22%3A%22%22%7D');
      var ozel_esas = getRemote(url);
      var obj_ozel_esas =tkParse(ozel_esas,'ozel_esasGet');
      
      if (obj_ozel_esas.error==1){
      
      return "Bir Hata ile karşılaşıldı";
      
      }
      
      var ozel_esas_durumu=obj_ozel_esas.data.mukellefOzelEsasDurum; 
      
      if (ozel_esas_durumu=="ozelEsas")  {return  "<a href='ozel-esas-getir.html?token=" + token + "&vkn=" + vkno +  "' target='_blank'>Özel Esaslara tabidir</a>";}
      if (ozel_esas_durumu=="genelEsas") {return  "<a href='ozel-esas-getir.html?token=" + token + "&vkn=" + vkno +  "' target='_blank'>Genel Esaslara tabidir</a>";}

      return ozel_esas_durumu;
	
	//if (feto_durum=='Sorgulanmış olan mükellefin bu kapsamda kaydı bulunmamaktadır.'){return "Kayıt Yok";}else{ return "Kayıt var";}


}


function matrahTecilno(vkno,vdkodu,thkNo) {
var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var dizi =new Array();


    var orgOid=orgIDGetir(vdkodu);

    if (orgOid!="undefined") { 
    
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid=';
    var url=url.concat(callid + '197', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22', orgOid ,'%22%2C%22tecilTip%22%3A%22%22%2C%22tclKaldirmaNdn%22%3A%22%22%7D%7D');


    var url_thk = getRemote(url);
    var obj =tkParse(url_thk,'matrahTecilno');

    var a=0;
    var b=0;

    var liste = obj.data.tecilKayitlari; /// 

      $.each(liste, function(index, satir){ //bütün tecil numaralarının tahakkuk numaralı kontrol ediliyor

	    
	    var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilDetayGetir&callid=';
	    var url1=url1.concat(callid + '30', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22tecilDosyaNo%22%3A%22',satir.tecilDosyaNo,'%22%2C%22tecilDilekceNo%22%3A%22%22%2C%22tecilDilekceTarihi%22%3A%22%22%2C%22tecildenKaldirmaTarihi%22%3A%22%22%2C%22tecildenKaldirmaNedeni%22%3A%22',satir.tecildenKaldirmaNedeni,'%22%2C%22ortakVkn%22%3A%22%22%2C%22ortakTckn%22%3A%22%22%2C%22plakano%22%3A%22%22%2C%22tecilTuru%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgOid,'%22%2C%22tecilTipi%22%3A%22',satir.tecilTipi,'%22%7D%7D');
	   
	    var url_thk1 = getRemote(url1);
	    var obj1 =tkParse(url_thk1,'matrahTecilno');
	    var tecil_thk=obj1.data.tecilSatirlari[0].thkfisno;
	    
	    
	    if (tecil_thk==thkNo) {
	   	    
	    dizi[0] = satir.tecilDosyaNo;

	    tecilOdenenToplamVab=obj1.data.tecilOdenenToplamVab;
	    
	    tecilOdenenToplamTecilFaizi=obj1.data.tecilOdenenToplamTecilFaizi;
	    
	    tecilToplamIndirim =obj1.data.tecilToplamIndirim;
	    
       toplam= Number(tecilOdenenToplamVab+tecilOdenenToplamTecilFaizi+tecilToplamIndirim).toLocaleString("tr-TR");
	    
       dizi[2]=toplam;
 
       dizi[1]= Number(obj1.data.tecilToplamVab).toLocaleString("tr-TR");
		    
	   dizi[3]= satir.tecildenKaldirmaNedeni;

	    }
	    
	    
	});

   
    }
    
     return dizi;

}


function tecilListesi(vkno){


var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var vd=vdKodu();

  $('#tablo21').after('<table id="myTable24" border=1><tr><caption>' + (typeof vdAdi==='function' ? vdAdi(vd) : vd) + ' - Tecil Taksitlendirme Listesi</caption><th>Tecil Türü</th><th>Tecil Dosya No</th><th>Kaldırılma Tarihi</th><th>Kaldırılma Nedeni</th><th>Tahakkuk-Tahsilat</th></tr>');



var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid='; 
			var url5=url5.concat(callid + '48', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdKodu(),'%22%2C%22orgOid%22%3A%22',vdOrgId(),'%22%2C%22tecilTip%22%3A%22%22%2C%22tclKaldirmaNdn%22%3A%22%22%7D%7D');
			var liste = getRemote(url5);
			var obj =tkParse(liste,'tecilListesi');
			
			
			  $.each(obj.data.tecilKayitlari, function(index, satir){
					

				  $("#myTable24 tr:last").after( "<tr><td>"+ satir.tecilTuru + "-" + satir.basvuruMad +"</td><td>"+ satir.tecilDosyaNo +"</td><td>"+ tarihFormat(satir.tecildenKaldirmaTarihi) +"</td><td>"+ satir.tecildenKaldirmaNedeni +"</td><td><a target='_blank' href='../diger/matrah-artirimi-tahakkuk-tahsilat.html?token=" + token() + "&vkn="+ vkno + "&tecilDosyaNo="+ satir.tecilDosyaNo + "&tecilDilekceNo="+ satir.tecilDilekceNo +"&tecilDosyaNo="+ satir.tecilDosyaNo +"&tecilDilekceTarihi="+ satir.tecilDilekceTarihi +"&tecildenKaldirmaTarihi="+ satir.tecildenKaldirmaTarihi + "&tecilTuru="+ satir.tecilTuru +"&vd="+ vd + "'>Göster   </a></td></tr>");
				  				   
			  
	    });


}
function tecilListesi1(vkno,token){

var callid=makeid(13) + '-';
var vd=vdKodu();

  $('#tablo21').after('<table id="myTable24" border=1><tr><caption>' + (typeof vdAdi==='function' ? vdAdi(vd) : vd) + ' - Tecil Taksitlendirme Listesi</caption><th>Tecil Türü</th><th>Tecil Dosya No</th><th>Kaldırılma Tarihi</th><th>Kaldırılma Nedeni</th><th>Tahakkuk-Tahsilat</th></tr>');



var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid='; 
			var url5=url5.concat(callid + '48', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdKodu(),'%22%2C%22orgOid%22%3A%22',vdOrgId(),'%22%2C%22tecilTip%22%3A%22%22%2C%22tclKaldirmaNdn%22%3A%22%22%7D%7D');
			var liste = getRemote(url5);
			var obj =tkParse(liste,'tecilListesi1');
			
			
			  $.each(obj.data.tecilKayitlari, function(index, satir){
					

				  $("#myTable24 tr:last").after( "<tr><td>"+ satir.tecilTuru + "-" + satir.basvuruMad +"</td><td>"+ satir.tecilDosyaNo +"</td><td>"+ tarihFormat(satir.tecildenKaldirmaTarihi) +"</td><td>"+ satir.tecildenKaldirmaNedeni +"</td><td><a target='_blank' href='../diger/matrah-artirimi-tahakkuk-tahsilat.html?token=" + token + "&vkn="+ vkno + "&tecilDosyaNo="+ satir.tecilDosyaNo + "&tecilDilekceNo="+ satir.tecilDilekceNo +"&tecilDosyaNo="+ satir.tecilDosyaNo +"&tecilDilekceTarihi="+ satir.tecilDilekceTarihi +"&tecildenKaldirmaTarihi="+ satir.tecildenKaldirmaTarihi + "&tecilTuru="+ satir.tecilTuru +"&vd="+ vd + "'>Göster   </a></td></tr>");
				  				   
			  
	    });


}



function tecilListesiAktifVarmi(vkno){


var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var aktif=0;
 
var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid='; 
			var url5=url5.concat(callid + '48', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdKodu(),'%22%2C%22orgOid%22%3A%22',vdOrgId(),'%22%2C%22tecilTip%22%3A%22%22%2C%22tclKaldirmaNdn%22%3A%22%22%7D%7D');
			var liste = getRemote(url5);
			var obj =tkParse(liste,'tecilListesiAktifVarmi');
			
			
			  $.each(obj.data.tecilKayitlari, function(index, satir){
					
					if (satir.tecildenKaldirmaNedeni=="Aktif"){ aktif=aktif+1;}
					
					
	    });
	    
	    if (aktif==0){
	    
	        return "<td>Yok</td>";
	        
	        }else{
	        
	          return "<td style='background:red; color:white'>Var</td>";
	          
	        }


}
function fetoSorgu(vkno,tokenlink){

try{
var callid=makeid(13) + '-';

var url3= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_fetoPDYSorusturmaBilgisiListesi&callid=';
var url3=url3.concat(callid + '96', '&token=', tokenlink, '&jp=%7B%22vergino%22%3A%22', vkno, '%22%2C%22tckimlikno%22%3A%22%22%2C%22unvan%22%3A%22%22%2C%22babaadi%22%3A%22%22%2C%22anaadi%22%3A%22%22%2C%22dogumtarihi%22%3A%22%22%7D');
var feto = getRemote(url3);
var feto1 =JSON.parse(feto);

var feto_durum = feto1.data.message;

if (feto_durum=='Sorgulanmış olan mükellefin bu kapsamda kaydı bulunmamaktadır.'){return 'Kayıt Yok';}else{ return 'Kayıt var';}

}

catch(err){

return "Hata ile Karşılaşıldı"

}

}
  
  
function fetoSorguGet(vkno){


	try{

			var tokenlink =GetUrlValue('token');

			var callid=makeid(13) + '-';

			var url3= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_fetoPDYSorusturmaBilgisiListesi&callid=';
			var url3=url3.concat(callid + '96', '&token=', tokenlink , '&jp=%7B%22vergino%22%3A%22', vkno, '%22%2C%22tckimlikno%22%3A%22%22%2C%22unvan%22%3A%22%22%2C%22babaadi%22%3A%22%22%2C%22anaadi%22%3A%22%22%2C%22dogumtarihi%22%3A%22%22%7D');
			var feto = getRemote(url3);	
			var feto1 =JSON.parse(feto);

			var feto_durum = feto1.data.message;

			if (feto_durum=='Sorgulanmış olan mükellefin bu kapsamda kaydı bulunmamaktadır.'){return 'Kayıt Yok';}else{ return 'Kayıt var';}
	}


	catch(err){

	return "Hata ile Karşılaşıldı";

	}


}
  

function yoklamaGetir(vkno) {

  
  var callid=makeid(13) + '-';
  
   
  var yoklamaListe=new Array(); 
  var a=0; 

      var url5= 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch?cmd=srvcEys_getMukYoklamalar&callid=';
      var url5=url5.concat(callid + '463', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkno,'%22%2C%22tckn%22%3A%22%22%2C%22durum%22%3A80%7D');
      var yoklama = getRemote(url5);
      var obj =tkParse(yoklama,'yoklamaGetir');
  

    var yoklama_liste = obj.data; /// vergi dairesi listeliyor
	
	$.each(yoklama_liste, function(index, satir){
      
	var yoklamaTarih = tarih(satir.tarih);

	var ykodu=satir.ykodu;
	var yoklama_turu=yoklamaTuruAciklama(satir.yturu);
      
	yoklamaListe.push(yoklama_turu + " - " + ykodu + " - " + yoklamaTarih + " - " + "<a href=http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?yKodu=" + ykodu  + " target='_blank'>Görüntüle</a><br>");               
	
	
      
	  });



return yoklamaListe;



} 


function yoklamaVarmi(vkno) {
 
   
  var callid=makeid(13) + '-';
  
   
  var yoklamaListe=new Array(); 
  var a=0; 

      
      var url5= 'http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch?cmd=srvcYoklama_getYoklamalar&callid=';
      var url5=url5.concat(callid + '463', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkno,'%22%2C%22tckn%22%3A%22%22%2C%22durum%22%3A80%7D');
      var yoklama = getRemote(url5);
      var obj =tkParse(yoklama,'yoklamaVarmi');
  

    var yoklama_liste = obj.data; /// vergi dairesi listeliyor
	
	$.each(yoklama_liste, function(index, satir){
      
		var yoklamaTarih = tarih(satir.tarih);
		var ykodu=satir.ykodu;
		var yoklama_turu=yoklamaTuruAciklama(satir.yturu);
      
		yoklamaListe.push(yoklama_turu + " - " + ykodu + " - " + yoklamaTarih + " - " + "<a href=http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?yKodu=" + ykodu  + " target='_blank'>Görüntüle</a><br>");               
	
	
      
	  });



	return yoklamaListe;

} 




function sicil_bilgi_getir(vkn){


	try{

		  var isyeriNitelikListe ={'1':'Merkez', '2':'Şube', '3':'Depo', '4':'KDV İhtisas Şubesi'};
		  var terkdurumu ={'0':'Faal',
		   '1':'', '2':'Terk', '3':'Nakil Halinde Terk', 
		   '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', 
		   '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', 
		   '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk',
		   '17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk',
		   '19':'19 - İnteraktif Vergi Dairesi Üzerinden Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk',
		   '20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk',
		   '21':'21 - VUK 160/A Maddesi Kapsamında Terk'};

		  var callid=makeid(13) + '-';
		  
		  var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
		  var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
		  var daireler = getRemote(url5);
		  var obj =JSON.parse(daireler);
		  var vd_return =new Array();
		  var i=0;
		  
  	  	 if (obj.data.kimlikpotansiyel==9){var potansiyel="Potansiyel Mükellef"}else{ var potansiyel = " Potansiyel Değil " }

		
  	  	 vd_return.push(potansiyel);
		  
		  var sirketturu=obj.data.sirketturu;
	   	  //var kimlikpotansiyel=obj.data.kimlikpotansiyel;
	   	  //if (kimlikpotansiyel==9){kimlikpotansiyel="Potansiyel";}else{kimlikpotansiyel="";}
		      
		///////////////////////////////////////////////////////////////////////////////////////// Mükellefin bağlı bulunduğu merkez ve KDV İhtisas vergi dairesi bilgilerini getiriyor
		
		var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
		
		$.each(daireListesi, function(index, satir){
		
		
		  var daireadi=satir.vdadi; 
		  var isyerinitelik = satir.isyerinitelik;
		  var isyerituru= satir.isyerituru;
		  var mukblgislemturubittur=satir.mukblgislemturubittur;
		  var faal = terkdurumu[mukblgislemturubittur];

			
			if (isyerinitelik==1 || isyerinitelik==4){

			  var isyerinitelik = isyeriNitelikListe[isyerinitelik];   
		  
			  var bastarih =tarih(satir.isebaslamatarihi);  	      
			  var bittarih =tarih(satir.isibirakmatarihi);
			  		  

			  vd_return.push(satir.vdkodu + "-" +  daireadi  + " / " +  bastarih  + " - " + bittarih  +  "(" + faal  +  ")***") ;
			  
			  

			  }
	  });

	  
		  return vd_return;
      
      }
      
      
      catch(err){
      
       return "Hata ile karşılışldı";
      
      
      }

}


function sicil_merkez_bilgi_getir(vkn){


	try{

		  var isyeriNitelikListe ={'1':'Merkez', '2':'Şube', '3':'Depo', '4':'KDV İhtisas Şubesi'};
		  var terkdurumu ={'0':'Faal',
		   '1':'', '2':'Terk', '3':'Nakil Halinde Terk', 
		   '4':'Nakil Halinde Terk','5':'Ölüm/Tasfiye Halinde Terk','6':'Diğer Terk', '7':'Resen Terk', 
		   '8':'V.İ.R Terk', '11':'Diğer Terk', '10':'Diğer Terk', '12':'Diğer Terk',  '13':'Diğer Terk', 
		   '15':'Nevi Değişikliği Halinde Terk', '9':'Diğer Terk', '16':'670 sayılı KHK Kapsamına Göre Terk',
		   '17':'17 - Elektronik Tescil Olan Tüzel Kişinin İlk Yoklamada Bulunamadığından Terk',
		   '19':'19 - İnteraktif Vergi Dairesi Üzerinden Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk',
		   '20':'20 - Elden/Posta Yolu ile İşe Başlama Bildirimi Mükellefiyet Tesisinde İlk Yoklamada Bulunamadığından Terk',
		   '21':'21 - VUK 160/A Maddesi Kapsamında Terk'};

		
		  var callid=makeid(13) + '-';
		  
		  var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
		  var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
		  var daireler = getRemote(url5);
		  var obj =JSON.parse(daireler);
		
  	  	 if (obj.data.kimlikpotansiyel==9){var potansiyel="Potansiyel Mükellef"}else{ var potansiyel = " Potansiyel Değil " }

	  

	   	 var unvan= obj.data.kimlikunvan;	      
		///////////////////////////////////////////////////////////////////////////////////////// Mükellefin bağlı bulunduğu merkez ve KDV İhtisas vergi dairesi bilgilerini getiriyor
		
		
		var daireadi= obj.data.vdler.baglivd[0].vdadi;	
		var vdkodu= obj.data.vdler.baglivd[0].vdkodu;
		var bastarih =tarih(obj.data.vdler.baglivd[0].isebaslamatarihi);  	      
        var bittarih =tarih(obj.data.vdler.baglivd[0].isibirakmatarihi);
        var mukblgislemturubittur=obj.data.vdler.baglivd[0].mukblgislemturubittur;
		var faal = terkdurumu[mukblgislemturubittur] ;

		  
 	     return (unvan + "/" + vdkodu + "/" +   daireadi  + "/" +  bastarih  + "/" + bittarih  + "/" + faal  + "/" + potansiyel ) ;
			  			
	
      
      }
      
      
      catch(err){
      
       return "Hata ile karşılışldı";
      
      
      }

}


function baSorgula(vkno,donem,mukVkn) {

  var myRegex= /[0-9]+/;
  
  
  
  var callid=makeid(13) + '-';
  var tutar=0;
  
	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=formBABSService_formBAGoruntuleYeni&callid=';
	var url5=url5.concat(callid + '16', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22yil%22%3A%22',donem,'%22%2C%22ay%22%3A%22%22%7D');
	var ba = getRemote(url5);
	var obj =tkParse(ba,'baSorgula');
  

	var ba_liste = obj.data.liste2; /// vergi dairesi listeliyor
	
	$.each(ba_liste, function(index, satir){
      
		if (satir.vergiNo==mukVkn) {
	
			tutar = tutar + parseFloat(satir.malHizmetBedeliToplam);
		
			}
	      
	  });
  
  return Number(tutar).toLocaleString("tr-TR");
}


function baKarsilastirmaSorgula(vkno,donem,mukVkn) {

  var myRegex= /[0-9]+/;
  
  
  
  var callid=makeid(13) + '-';
  var tutar=0;
  var bedel1=0;
  var bedel2=0;


  	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=alisSatisAnaliziService_getAlisSatisAnaliz&callid=';
	var url5=url5.concat(callid + '176', '&token=', token(), '&jp=%7B%22clientObj%22%3A%7B%22vergiNumarasi%22%3A%22',vkno,'%22%2C%22tcKimlikNo%22%3A%22%22%2C%22yil%22%3A%22',donem,'%22%2C%22ay%22%3A%2213%22%2C%22hvBabsMi%22%3Atrue%7D%7D');
	var ba = getRemote(url5);
	var obj =tkParse(ba,'baKarsilastirmaSorgula');
	// success=false (HTTP 200) durumunda 0 yazmak yanıltıcı. 'Hata' döndürelim.
	if ((obj && obj.success === false) || (obj && obj.data && obj.data.success === false)) {
		return 'Hata' + '-' + 'Hata';
	}


		// GİB yanıtı:
	//  - data.liste1 : Mal/Hizmet SATILAN (Satış / Karşıt Alış)
	//  - data.liste  : Mal/Hizmet SATIN ALINAN (Alış / Karşıt Satış)
	// Bu fonksiyon BS (satılan) tarafını kullanmalı.
	var ba_liste = (obj && obj.data && $.isArray(obj.data.liste1)) ? obj.data.liste1 : ((obj && obj.data && $.isArray(obj.data.liste)) ? obj.data.liste : []);
	
		if (ba_liste.length>0){

			$.each(ba_liste, function(index, satir){
			  
				if (satir.vkn==mukVkn) {
					
					bedel1= bedel1 + parseFloat(satir.malHizmetBedeli1);

					bedel2= bedel2 + parseFloat(satir.malHizmetBedeli2);
				
					}
				  
			  });

		}

  
  return (Number(bedel1).toLocaleString("tr-TR") + "-" +  Number(bedel2).toLocaleString("tr-TR"));

}



function removeDuplicates(arr) {
        return arr.filter((item,
            index) => arr.indexOf(item) === index);
    }
  /*  
function gekCevaplanmismi(){

	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';

return;
}


function gekArsivVarmi(){

return;

}    
*/


function cariYil(){

      var tarih=new Date();

     return tarih.getFullYear();

}
function hangiVD (vkno,yil) {
    
      var callid=makeid(13) + '-';
      var vdListe=new Array();
      var a =0;
      var tarih=new Date();
      var cariYil=tarih.getFullYear();
      
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'hangiVD');
	
	 var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
	  var vdkodu=satir.vdkodu;
	  var isyerinitelik = satir.isyerinitelik;
	  
	
	  if (isyerinitelik==1 || isyerinitelik==4){
	  
	      var bas_yil =satir.isebaslamatarihi.substr(0,4);  	      
	      
	      
	      if (satir.isibirakmatarihi.substr(0,4)=='') {bit_yil=cariYil;}else{var bit_yil =satir.isibirakmatarihi.substr(0,4);}
	      
		
		if (bas_yil<=yil) {
		
		    if (yil<=bit_yil) {
	
			vdListe.push(vdkodu);

		
		}
			}
	  }

    });

   return removeDuplicates(vdListe);
}


function hangiVD2 (vkno) {

      var callid=makeid(13) + '-';
      var vdListe=new Array();
      var a =0;
      var tarih=new Date();
      var cariYil=tarih.getFullYear();
      
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'hangiVD2');
	
	 var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
		  var vdkodu=satir.vdkodu;

		  var isyerinitelik = satir.isyerinitelik;
		  
		  if (isyerinitelik==1 || isyerinitelik==4){	vdListe.push(vdkodu);   }


    });

   return removeDuplicates(vdListe);
}


function hangiVD3 (vkno) { // Borç Sorgulaması için VD

try{
      
      var callid=makeid(13) + '-';
      var vdListe=new Array();
      var a =0;
      var tarih=new Date();
      var cariYil=tarih.getFullYear();
      
        //
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukellefTcknVknBagliVDGetirThkOlanlarDahil&callid=';
      var url5=url5.concat(callid + '130', '&token=', token(), '&jp=%7B%22vknTckn%22%3A%22',vkno,'%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
	
	 var daireListesi = obj.data.bagliVDler; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
		if ((satir.value).substr(0,3)=="016"){

			vdListe.push(satir.value); 
	
		}

    });

	
   return removeDuplicates(vdListe);

}

catch(err){

return "";

}
}


function hangiVD4 (vkno,token) { // Borç Sorgulaması için VD

try{

   
      var callid=makeid(13) + '-';
      var vdListe=new Array();
      var a =0;
      var tarih=new Date();
      var cariYil=tarih.getFullYear();
      
        //
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukellefTcknVknBagliVDGetirThkOlanlarDahil&callid=';
      var url5=url5.concat(callid + '130', '&token=', token, '&jp=%7B%22vknTckn%22%3A%22',vkno,'%22%7D');
      var daireler = getRemote(url5);
      var obj =JSON.parse(daireler);
	
	 var daireListesi = obj.data.bagliVDler; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
		if ((satir.value).substr(0,3)=="016"){

		vdListe.push(satir.value); 

		
		}

    });

   return removeDuplicates(vdListe);

}

catch(err){

console.log(err);
return "";

}
}


// === PATCH v27: Robust POS/Banka toplam okuma ===
function __parseNumberTR(val){
    if(val===null || val===undefined) return 0;
    if(typeof val === 'number') return val;
    var s = String(val).trim();
    if(!s) return 0;
    // remove thousand separators and normalize decimal comma
    // examples: 54.202.500,12 or 203006.67
    s = s.replace(/\./g,'').replace(',', '.');
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
}
function __pickPosList(data){
    if(!data) return [];
    return data.bankaSatisAylikListe || data.posSatisAylikListe || data.bankaSatisListe || data.liste || [];
}
function __extractPosTotal(data){
    var arr = __pickPosList(data);
    if(!Array.isArray(arr) || arr.length===0) return 0;

    // Prefer explicit total fields if present
    var last = arr[arr.length-1] || {};
    var totalKeys = ['toplamGenel','toplamTutar','genelToplam','toplam','toplamSatis','toplamSatisTutari','bankaSatisToplam','posSatisToplam'];
    for(var i=0;i<totalKeys.length;i++){
        var k = totalKeys[i];
        if(last[k]!==undefined && last[k]!==null && String(last[k]).trim()!==''){
            return __parseNumberTR(last[k]);
        }
    }

    // Otherwise sum the most-likely amount field on each row
    var sum = 0;
    for(var r=0;r<arr.length;r++){
        var row = arr[r];
        if(!row || typeof row!=='object') continue;
        var keys = Object.keys(row);
        // choose a deterministic candidate key per row
        var chosen = null;
        for(var j=0;j<keys.length;j++){
            var kk = keys[j].toLowerCase();
            if(kk.includes('tutar') || kk.includes('tutari') || kk.includes('toplam')){
                // skip pagination/meta-like keys
                if(kk.includes('start') || kk.includes('limit') || kk.includes('count')) continue;
                chosen = keys[j];
                break;
            }
        }
        if(chosen){
            sum += __parseNumberTR(row[chosen]);
        }
    }
    return sum;
}
// === /PATCH v27 ===

function aylikBanka(token,vkn,yil,ay){

	try{
		var callid=makeid(13) + '-';
		var gelen_toplam=0;
		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=posKrediKartiService_bankaSatisBilgGoreAylikSorgula&callid=';
		var url5=url5.concat(callid + '22', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22satisDonemAy%22%3A%22',ay,'%22%2C%22satisDonemYil%22%3A%22',yil,'%22%2C%22respKeyParam%22%3A%22bankaSatisAylikListe%22%2C%22isFullData%22%3Afalse%2C%22isFullExport%22%3Atrue%2C%22pv%22%3A%7B%22start%22%3A0%2C%22limit%22%3A%2250%22%2C%22sorters%22%3A%5B%5D%7D%7D');
		var banka = getRemote(url5);
		var obj =JSON.parse(banka);
			  
			  return __extractPosTotal(obj.data);

}

catch(err){

		return "Hata";

	}
}



function yillikBanka(token,vkn,yil){

try{

var callid=makeid(13) + '-';
var gelen_toplam=0;

	 var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=posKrediKartiService_bankaSatisBilgGoreYillikSorgula&callid=';
      var url5=url5.concat(callid + '19', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22yil%22%3A%22',yil,'%22%7D');
      var banka = getRemote(url5);
      var obj =JSON.parse(banka);
      
	  return __extractPosTotal(obj.data);

		}

	catch(err){

return "Hata";

}
}



function iadeMahsupSorgulama(token,vkn){

		var callid=makeid(13) + '-';
	var vdDizi=iadeMahsupVdSorgula1(vkn);
      

for (i;i<vdDizi.length;i++) {

      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulama&callid=';
      var url5=url5.concat(callid + '92', '&token=', token, '&jp=%7B%22vkn%22%3A%227601099913%22%2C%22vdKodu%22%3A%22',vdDizi[i],'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'iadeMahsupSorgulama');
	
	 var iade = obj.data.iadeMahsupKlm; /// vergi dairesi listeliyor
	
	$.each(iade, function(index, satir){
	
	
    	vdListe.push(satir.vdKodu); 
    	
  
    	

    });


}

}


function iadeMahsupVdSorgula(vkno) {


      var myRegex= /[0-9]+/;
      var tokenlink =GetUrlValue('token'); 
	  var vkno=GetUrlValue('vkn');
      
      
      var callid=makeid(13) + '-';
      var vdListe=new Array();


      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupOlanVDlerSorgula&callid=';
      var url5=url5.concat(callid + '169', '&token=', tokenlink, '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'iadeMahsupVdSorgula');
	


	 var daireListesi = obj.data.vdler; /// vergi dairesi listeliyor
	
		$.each(daireListesi, function(index, satir){
			
			vdListe.push(satir.vdKodu); 

		});

		return removeDuplicates(vdListe);



   
}

function iadeMahsupHangiVD(vkno) { // Mükellefin daha önce iade talebinde bulunduğu vergi dairelerini listelemek için

var callid=makeid(13) + '-';

var vdListe=new Array();

      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupOlanVDlerSorgula&callid=';
      var url5=url5.concat(callid + '169', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'iadeMahsupHangiVD');
	

	if (obj.error==undefined){
		
		 var daireListesi = obj.data.vdler; /// vergi dairesi listeliyor
			
			 if (daireListesi.length>0){
			
				$.each(daireListesi, function(index, satir){
				
				 if (satir.vdKodu.substr(0,3)=="016"){
					
					vdListe.push(satir.vdKodu); 

					}

				});

			   return removeDuplicates(vdListe);
			   
			}else{
			
			return vdListe;
			
			}

	}else{

		return "Hata";

		}
}



function hangiVD1 (vkno) {

      var tokenlink =GetUrlValue('token'); 
	  var vkno=GetUrlValue('vkn');
     
      var callid=makeid(13) + '-';
      var vdListe=new Array();
      
        
      var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgula&callid=';
      var url5=url5.concat(callid + '15', '&token=', tokenlink, '&jp=%7B%22vkn%22%3A%22', vkno, '%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'hangiVD1');
	
	 var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
	
	$.each(daireListesi, function(index, satir){
	
	  var vdkodu=satir.vdkodu;
	  var isyerinitelik = satir.isyerinitelik;
	  
	
	 	 if (isyerinitelik==1 || isyerinitelik==4){	vdListe.push(vdkodu);   }

    });

   return removeDuplicates(vdListe);
}

function gidenEvrakBul (vkn,vdKodu,bastarih) {

try{


var callid=makeid(13) + '-';

//var tarih1=new Date();
//var zamanasimi=tarih1.getFullYear()-5;
//var zamanasimiTarih=zamanasimi + "0101";


var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkEvrakService_gidenEvrakBilgileriniGetir&callid=';
var url5=url5.concat(callid + '92', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22orgOid%22%3A%22',vdOrgId(),'%22%2C%22vdKodu%22%3A%22',vdKodu,'%22%2C%22bastarih%22%3A%22',bastarih,'%22%2C%22bittarih%22%3A%22%22%7D%7D');
var evrak = getRemote(url5);
var obj =JSON.parse(evrak);
var result=0;
var tarih_sayi_liste =new Array();
var a=0;

var evrakListesi = obj.data.evrakkayitlari; /// vergi dairesi listeliyor
	
	$.each(evrakListesi, function(index, satir){
	
	var evrak_turu=satir.evrakTuru;
	var ozu=satir.ozu;
	var vergiDonem=satir.vergiDonem;
        var gelisTuru=satir.gelisTuru;
	var gittigiYer =satir.gittigiYer;
	
	
	    var url7= 'http://10.251.63.99/keyss/external_dispatch?cmd=evrakOrtakServis_evrakOnizle&callid=';
	    var url7=url7.concat(callid + '125', '&token=', token(), '&jp=%7B%22evrakOid%22%3A%22',satir.evrakOID ,'%22%2C%22konteynerOid%22%3Anull%2C%22evrakVersiyonOid%22%3Anull%2C%22yetkisiz%22%3Atrue%7D');
	    var evrak = getRemote(url7);
	    var objEvrak =JSON.parse(evrak);
	   // var evrakOid =objEvrak.data.evrakOid;
	    var dokumanVersiyonOid= objEvrak.data.dokumanVersiyonOid;
	    var konteynerOid=objEvrak.data.konteynerOid;
	  
	  
	  
	    if (dokumanVersiyonOid!=undefined){
	    
	      
	      var url6= 'http://10.251.63.99/keyss/external_dispatch?cmd=dokumanServis_dokumanOnizle&callid=';
	      var url6=url6.concat(callid + '117', '&token=', token(), '&jp=%7B%22dokumanOid%22%3Anull%2C%22dokumanVersiyonOid%22%3A%22',dokumanVersiyonOid,'%22%2C%22yetkisiz%22%3Atrue%2C%22konteynerOid%22%3A%22',konteynerOid,'%22%2C%22iptal%22%3Afalse%2C%22barkod%22%3Atrue%7D');
	      var evrakFileId = getRemote(url6);
	      var objFileId =JSON.parse(evrakFileId);
	      var evrakNo =objFileId.data.fileID;
	      
	    }
	
	    if (dokumanVersiyonOid!='undefined'){
	    tarih_sayi_liste[a]= ozu + "-" + evrak_turu + "-" + tarih(satir.gittigiTarih) + " - " + satir. evrakNoSuf + "(Vergilendirme Dönemi :" + vergiDonem+ ")<a target='_blank' href='http://10.251.63.99/keyss/flexpaper/pdf/?token=" + token() + "&fileID=" + evrakNo + ".pdf'  > Görüntüle </a><hr><br>";
	    
	    }else{
	    
	    tarih_sayi_liste[a]= ozu + "-" + evrak_turu + "-" + tarih(satir.gittigiTarih) + " - " + satir. evrakNoSuf +  "(Vergilendirme Dönemi :" + vergiDonem+ ") <hr><br>";
	    
	    }
	  a =a+1;
	  
	

	});
	
      tarih_sayi_liste.reverse();
      
      return tarih_sayi_liste ;

}

catch(err){

return "Hata ile karşılaşıldı";

}
      
    
}

function gidenEvrakBul2 (vkn,vdKodu) {

try{
var myRegex= /[0-9]+/;


;
var callid=makeid(13) + '-';

//var tarih1=new Date();
//var zamanasimi=tarih1.getFullYear()-5;
//var zamanasimiTarih=zamanasimi + "0101";


var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkEvrakService_gidenEvrakBilgileriniGetir&callid=';
var url5=url5.concat(callid + '92', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22orgOid%22%3A%22',vdOrgId(),'%22%2C%22vdKodu%22%3A%22',vdKodu,'%22%2C%22bastarih%22%3A%22%22%2C%22bittarih%22%3A%22%22%7D%7D');
var evrak = getRemote(url5);
var obj =JSON.parse(evrak);
var result=0;
var tarih_sayi_liste =new Array();
var a=0;

var evrakListesi = obj.data.evrakkayitlari; /// vergi dairesi listeliyor
	
	$.each(evrakListesi, function(index, satir){
	
	var evrak_turu=satir.evrakTuru;
	var ozu=satir.ozu;
	var vergiDonem=satir.vergiDonem;
        var gelisTuru=satir.gelisTuru;
	var gittigiYer =satir.gittigiYer;
	
	
	if (evrak_turu!="502-ÖDEME EMRİ" && evrak_turu!="403-TAKDİR KOMİSYONU EVRAĞI" && evrak_turu!="802-UZLAŞMA DAVETİYESİ") {
	
	    var url7= 'http://10.251.63.99/keyss/external_dispatch?cmd=evrakOrtakServis_evrakOnizle&callid=';
	    var url7=url7.concat(callid + '125', '&token=', token(), '&jp=%7B%22evrakOid%22%3A%22',satir.evrakOID ,'%22%2C%22konteynerOid%22%3Anull%2C%22evrakVersiyonOid%22%3Anull%2C%22yetkisiz%22%3Atrue%7D');
	    var evrak = getRemote(url7);
	    var objEvrak =JSON.parse(evrak);
	   // var evrakOid =objEvrak.data.evrakOid;
	    var hata= objEvrak.messages;
	   
	  
	    if (hata==undefined  ){
	      
	      var dokumanVersiyonOid= objEvrak.data.dokumanVersiyonOid;
	      var konteynerOid=objEvrak.data.konteynerOid; 
	      var url6= 'http://10.251.63.99/keyss/external_dispatch?cmd=dokumanServis_dokumanOnizle&callid=';
	      var url6=url6.concat(callid + '117', '&token=', token(), '&jp=%7B%22dokumanOid%22%3Anull%2C%22dokumanVersiyonOid%22%3A%22',dokumanVersiyonOid,'%22%2C%22yetkisiz%22%3Atrue%2C%22konteynerOid%22%3A%22',konteynerOid,'%22%2C%22iptal%22%3Afalse%2C%22barkod%22%3Atrue%7D');
	      var evrakFileId = getRemote(url6);
	      var objFileId =JSON.parse(evrakFileId);
	      var evrakNo =objFileId.data.fileID;
	      
	    }
	
	    if (dokumanVersiyonOid!='undefined'){
	    tarih_sayi_liste[a]= ozu + "-" + evrak_turu + "-" + tarih(satir.gittigiTarih) + " - " + satir. evrakNoSuf + "(Vergilendirme Dönemi :" + vergiDonem+ ")<a target='_blank' href='http://10.251.63.99/keyss/flexpaper/pdf/?token=" + token() + "&fileID=" + evrakNo + ".pdf'  > Görüntüle </a><hr><br>";
	    
	    }else{
	    
	    tarih_sayi_liste[a]= ozu + "-" + evrak_turu + "-" + tarih(satir.gittigiTarih) + " - " + satir. evrakNoSuf +  "(Vergilendirme Dönemi :" + vergiDonem+ ") <hr><br>";
	    
	    }
	  a =a+1;
	  
	}

	});
	
      tarih_sayi_liste.reverse();
      
      return tarih_sayi_liste ;
      
  }


catch(err){

return "Hata ile karşılaşıldı";

} 
}

////takdire sevk dosyasında çalışıyor

function beyanMatrah(vkno,vKodu,donem1,donem2,token){

try{

	var callid=makeid(13) + '-';
	var url3= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=tahakkukService_toplamBazTahakkukGetir&callid=';
	var aktifVdKodu = (typeof vdKodu==='function' ? vdKodu() : '');
	var url3=url3.concat(callid + '20', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',aktifVdKodu,'%22%2C%22unvan%22%3A%22%22%2C%22vergiKodu%22%3A%22',vKodu,'%22%2C%22ilkDonem%22%3A%22',donem1,'%22%2C%22sonDonem%22%3A%22',donem2,'%22%7D%7D');
	var beyan_matrah = getRemote(url3);
	var obj =JSON.parse(beyan_matrah);


	if (obj.data.anaListe[0].toplamMatrah!=0) {

	  var tutar=obj.data.anaListe[1].toplamMatrah;
	
	  return tlCevir(tutar);

	  }else{
	  
	  return "Veri Yok";
	  
	  
	  }

}

catch(err){

 return "Hata";

}
}


/* =========================================================
   Takdire Sevk myTable6 matrah hesabı (0032/0033/0001/0010)
   Kural:
   - thkTuru önceliği: 9000 > 9005 > 9009 > 9014 > 9021
   - ilk grup: 0010 / 0023 / 0025
     * öncelik: 0010 > 0023 > 0025
     * varsa son/geçerli kayıt alınır
   - ikinci grup: 0028 / 0029 / 0030
     * son/geçerli kayıtlar toplanır
   - nihai matrah = ilk grubun son geçerli hali + ikinci grup toplamı
   - kayıt bulunamazsa eski beyanMatrah() fallback kullanılır
   ========================================================= */
function __tkMatrahNum(v) {
  if (v === null || v === undefined || v === "") return 0;
  if (typeof v === 'number') return isNaN(v) ? 0 : v;
  var s = String(v).trim();
  if (!s) return 0;
  if (s.indexOf(',') > -1 && s.indexOf('.') > -1) {
    s = s.replace(/\./g, '').replace(',', '.');
  } else if (s.indexOf(',') > -1) {
    s = s.replace(',', '.');
  }
  var n = Number(s);
  return isNaN(n) ? 0 : n;
}
function __tkMatrahArr(v) {
  return Array.isArray(v) ? v : [];
}
function __tkMatrahFisSortValue(k) {
  if (!k) return '';
  var t = String(k.thkTarihi || '').replace(/\D/g, '');
  var f = String(k.thkFisNo || '').replace(/\D/g, '');
  return (t + '|' + f);
}
function __tkMatrahSortAsc(list) {
  return __tkMatrahArr(list).slice().sort(function(a,b){
    var va = __tkMatrahFisSortValue(a);
    var vb = __tkMatrahFisSortValue(b);
    return va.localeCompare(vb);
  });
}
function __tkMatrahLast(list) {
  var arr = __tkMatrahSortAsc(list);
  return arr.length ? arr[arr.length-1] : null;
}
function __tkMatrahGetSatirM(kayit, hedefVergiKodu) {
  var satirlar = __tkMatrahArr(kayit && kayit.mhktahakkukSatirlari);
  hedefVergiKodu = String(hedefVergiKodu || '').trim();
  for (var i=0; i<satirlar.length; i++) {
    var s = satirlar[i];
    if (String(s.vergiKodu || '').trim() === hedefVergiKodu) {
      return __tkMatrahNum(s.matrah);
    }
  }
  return 0;
}
function __tkMatrahContainsKod(kayit, hedefVergiKodu) {
  var satirlar = __tkMatrahArr(kayit && kayit.mhktahakkukSatirlari);
  hedefVergiKodu = String(hedefVergiKodu || '').trim();
  for (var i=0; i<satirlar.length; i++) {
    if (String(satirlar[i].vergiKodu || '').trim() === hedefVergiKodu) return true;
  }
  return false;
}
function __tkMatrahSelectThkPriority(kayitlar) {
  var order = ['9000','9005','9009','9014','9021'];
  var map = {};
  __tkMatrahArr(kayitlar).forEach(function(k){
    var t = String(k.thkTuru || '').trim();
    if (!map[t]) map[t] = [];
    map[t].push(k);
  });
  for (var i=0; i<order.length; i++) {
    if (map[order[i]] && map[order[i]].length) return map[order[i]];
  }
  return [];
}
function __tkMatrahLatestByIslem(list, islemKodu) {
  var arr = __tkMatrahArr(list).filter(function(k){
    return String(k.islemTuru || '').trim() === String(islemKodu || '').trim();
  });
  return __tkMatrahLast(arr);
}
function __tkMatrahSelectIlkGrup(list) {
  return __tkMatrahLatestByIslem(list,'0010') ||
         __tkMatrahLatestByIslem(list,'0023') ||
         __tkMatrahLatestByIslem(list,'0025') ||
         null;
}
/* v517-fix: bu sürüm aşağıdaki aynı adlı ikinci tanım tarafından eziliyordu (ölü kod).
   Her işlem türünün YALNIZCA EN SON kaydını toplar. Çalışan sürüm ise aynı türe
   ait BÜTÜN kayıtları topluyor. İkisi farklı sonuç verebildiği için sürüm
   karşılaştırma amacıyla saklandı; hangisinin doğru olduğu kararı verilmedi. */
function __tkMatrahIkinciGrupToplam_SonKayit(list, hedefVergiKodu) {
  var toplam = 0;
  var kodlar = ['0028','0029','0030'];
  for (var i=0; i<kodlar.length; i++) {
    var rec = __tkMatrahLatestByIslem(list, kodlar[i]);
    if (rec) toplam += __tkMatrahGetSatirM(rec, hedefVergiKodu);
  }
  return toplam;
}
function __tkMatrahFetchDztOncesi(orgOid, thkFisNo, token) {
  var payload = {
    orgOid: String(orgOid || ''),
    dztThkFisNo: String(thkFisNo || '')
  };
  var callid = makeid(13) + '-';
  var url = 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTahakkukService_dztOncesiTahakkukSorgula&callid=';
  url = url.concat(callid + '117', '&token=', token, '&jp=', encodeURIComponent(JSON.stringify(payload)));
  var txt = getRemote(url);
  return tkParse(txt,'__tkMatrahFetchDztOncesi');
}
function __tkMatrahGetIlkGrupDuzeltilmisMatrah(kayit, hedefVergiKodu, orgOid, token) {
  if (!kayit) return 0;
  var dztFisNo = String(kayit.dztFisNo || '').trim();
  if (!dztFisNo) return __tkMatrahGetSatirM(kayit, hedefVergiKodu);
  try {
    var secilenThkFisNo = String(kayit.thkFisNo || '').trim();
    var obj = __tkMatrahFetchDztOncesi(orgOid, secilenThkFisNo, token);
    if (obj && String(obj.error || '0') !== '1') {
      var arr = __tkMatrahArr(obj.data);
      if (arr.length) {
        return __tkMatrahGetSatirM(arr[arr.length - 1], hedefVergiKodu);
      }
    }
  } catch (e) {
    console.warn('dztOncesi sorgusu okunamadi', e);
  }
  return __tkMatrahGetSatirM(kayit, hedefVergiKodu);
}
function __tkMatrahIkinciGrupToplam_TumKayitlar(list, hedefVergiKodu) {
  var toplam = 0;
  var kodlar = {'0028':1,'0029':1,'0030':1};
  __tkMatrahArr(list).forEach(function(rec){
    var islem = String(rec.islemTuru || '').trim();
    if (kodlar[islem]) toplam += __tkMatrahGetSatirM(rec, hedefVergiKodu);
  });
  return toplam;
}

/* v517-fix: mevcut davranış korunuyor (TumKayitlar sürümü döndürülür).
   Ama iki yöntem farklı sonuç verirse bunu sessizce geçmek yerine görünür
   kılıyoruz: hangi mükellefte fark oluştuğunu böylece tespit edebilirsin.
   Fark listesi: window.__tkMatrahFarklari                                 */
window.__tkMatrahFarklari = [];
function __tkMatrahIkinciGrupToplam(list, hedefVergiKodu){
  var tum = __tkMatrahIkinciGrupToplam_TumKayitlar(list, hedefVergiKodu);
  try{
    var son = __tkMatrahIkinciGrupToplam_SonKayit(list, hedefVergiKodu);
    if (Math.abs((tum||0) - (son||0)) > 0.005){
      var kayit = { vergiKodu: hedefVergiKodu, tumKayitlarToplami: tum, sonKayitToplami: son };
      window.__tkMatrahFarklari.push(kayit);
      if (typeof console !== 'undefined' && console.warn){
        console.warn('[v517] Matrah 2. grup: iki hesap yöntemi farklı sonuç verdi.',
                     'Bütün kayıtlar =', tum, '| yalnız son kayıtlar =', son,
                     '| vergi kodu =', hedefVergiKodu);
      }
      if (typeof tkUyariGoster === 'function'){
        tkUyariGoster('Matrah 2. grup toplamı iki yönteme göre farklı çıktı (' +
                      tum + ' / ' + son + '). Bu mükellefte aynı işlem türünden ' +
                      'birden fazla kayıt var — hangi yöntemin doğru olduğu teyit edilmeli.', false);
      }
    }
  }catch(e){}
  return tum;
}
function __tkMatrahUnique(list){
  var seen={}, out=[];
  __tkMatrahArr(list).forEach(function(x){
    if(x===null || x===undefined) return;
    var k=String(x).trim();
    if(!k || seen[k]) return;
    seen[k]=1; out.push(k);
  });
  return out;
}
function __tkMatrahOrgCandidates(vkno, orgOid, tokenLink){
  var orgs=[];
  function addOrg(o){
    o=String(o||'').trim();
    if(o && o!=='undefined' && o!=='null') orgs.push(o);
  }
  addOrg(orgOid);
  try{ addOrg(vdOrgId()); }catch(e){}
  try{
    var vdUrl=GetUrlValue('vd') || GetUrlValue('vdKodu') || GetUrlValue('vdkodu');
    if(vdUrl) addOrg(orgIDGetir(vdUrl));
  }catch(e){}
  try{
    var vdler=hangiVD4(vkno, tokenLink || token());
    if(!Array.isArray(vdler)) vdler=[];
    vdler.forEach(function(vd){ addOrg(orgIDGetir(vd)); });
  }catch(e){ console.warn('MHK çoklu VD listesi alınamadı', e); }
  try{
    var vdler2=hangiVD2(vkno);
    if(!Array.isArray(vdler2)) vdler2=[];
    vdler2.forEach(function(vd){ addOrg(orgIDGetir(vd)); });
  }catch(e){}
  return __tkMatrahUnique(orgs);
}
function __tkMatrahQueryTahakkuk(vkno,tckn,hedefVergiKodu,donem1,donem2,orgOid,tokenLink){
  var payload = {
    vkn: String(vkno || ''),
    tckn: String(tckn || ''),
    vergiKodu: String(hedefVergiKodu || '').trim(),
    basDonem: String(donem1 || ''),
    bitDonem: String(donem2 || ''),
    orgOid: String(orgOid || ''),
    durum: '1'
  };
  var callid = makeid(13) + '-';
  var url = 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTahakkukService_tahakkukSorgula&callid=';
  url = url.concat(callid + '20', '&token=', tokenLink, '&jp=', encodeURIComponent(JSON.stringify(payload)));
  var txt = getRemote(url);
  return txt ? tkParse(txt,'__tkMatrahQueryTahakkuk') : {};
}
function __tkMatrahHesaplaKayitlar(kayitlar, hedefVergiKodu, orgOid, tokenLink){
  kayitlar = __tkMatrahArr(kayitlar).filter(function(k){
    return __tkMatrahContainsKod(k, hedefVergiKodu);
  });
  if(!kayitlar.length) return null;
  var seciliThkKayitlari = __tkMatrahSelectThkPriority(kayitlar);
  if(!seciliThkKayitlari.length) return null;
  var ilkGrupKaydi = __tkMatrahSelectIlkGrup(seciliThkKayitlari);
  var ilkGrupMatrah = ilkGrupKaydi ? __tkMatrahGetIlkGrupDuzeltilmisMatrah(ilkGrupKaydi, hedefVergiKodu, orgOid, tokenLink) : 0;
  var ikinciGrupToplam = __tkMatrahIkinciGrupToplam(seciliThkKayitlari, hedefVergiKodu);
  return ilkGrupMatrah + ikinciGrupToplam;
}
function __tkMatrahBeyanFallbackCoklu(vkno,vKodu,donem1,donem2,tokenLink){
  try{ return beyanMatrah(vkno, vKodu, donem1, donem2, tokenLink); }catch(e){ return 'Hata'; }
}
function beyanMatrahTakkomKuralli(vkno, tckn, vKodu, donem1, donem2, orgOid, tokenLink) {
  try {
    var hedefVergiKodu = String(vKodu || '').trim();
    if (['0032','0033','0001','0010'].indexOf(hedefVergiKodu) === -1) {
      return __tkMatrahBeyanFallbackCoklu(vkno, vKodu, donem1, donem2, tokenLink);
    }

    // Nakil / KDV ihtisas / dönem içi VD değişikliği için tek orgOid'e bağlı kalma.
    // Önce satırın kendi VD'si, sonra mükellefin tahakkuku olan tüm bağlı VD orgOid'leri denenir.
    var adayOrglar = __tkMatrahOrgCandidates(vkno, orgOid, tokenLink);
    if(!adayOrglar.length) adayOrglar = [String(orgOid || '')];

    var hataOldu = false;
    for(var oi=0; oi<adayOrglar.length; oi++){
      var adayOrg = adayOrglar[oi];
      try{
        var obj = __tkMatrahQueryTahakkuk(vkno,tckn,hedefVergiKodu,donem1,donem2,adayOrg,tokenLink);
        if (!obj || String(obj.error || '0') === '1') { hataOldu = true; continue; }
        var sonuc = __tkMatrahHesaplaKayitlar(obj.data, hedefVergiKodu, adayOrg, tokenLink);
        if(sonuc !== null){
          try{ console.log('MHK geçici vergi matrahı bulundu', {vkn:vkno, vergiKodu:hedefVergiKodu, donem1:donem1, donem2:donem2, orgOid:adayOrg, matrah:sonuc}); }catch(e){}
          return tlCevir(sonuc);
        }
      }catch(e){
        hataOldu = true;
        console.warn('MHK tahakkuk aday VD/org sorgu hatası', adayOrg, e);
      }
    }

    // Hiçbir VD'de MHK tahakkuk kaydı bulunamazsa eski toplamBaz fallback devam etsin.
    var fallback = __tkMatrahBeyanFallbackCoklu(vkno, vKodu, donem1, donem2, tokenLink);
    if(fallback && fallback !== 'Hata' && fallback !== 'Veri Yok') return fallback;
    return hataOldu ? 'Veri Yok' : 'Veri Yok';
  } catch(err) {
    console.error('beyanMatrahTakkomKuralli hata', err);
    return 'Hata';
  }
}

function bsSorgulaEski(vkno,yil,ay) {


try{

  var myRegex= /[0-9]+/;
  
  
  
  var callid=makeid(13) + '-';
  var tutar=0;
  
	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=formBABSService_formBSGoruntuleYeni&callid=';
	var url5=url5.concat(callid + '16', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22yil%22%3A%22',yil,'%22%2C%22ay%22%3A%22',ay,'%22%7D');
	var bs = getRemote(url5);
	var obj =JSON.parse(bs);
  

	var bs_liste = obj.data.liste2; /// vergi dairesi listeliyor
	
	$.each(bs_liste, function(index, satir){
		

			if (satir.belgeSayisiTop!=undefined){
			  	 
				  tutar = parseFloat(satir.malHizmetBedeliTop);
				  
			}
		      
	  });
  
  return tutar;

}

	catch(err){

	return (err);

	}
}


function bsSorgula(vkn,yil,ay,token) { // 	Karşılaştırmalı Alış-Satış Analizi ile çalışıyor



try{

  var callid=makeid(13) + '-';
  var tutarBS=0;
  var tutarKarsiAlis=0;

	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=alisSatisAnaliziService_getAlisSatisAnaliz&callid=';
	var url5=url5.concat(callid + '121', '&token=', token, '&jp=%7B%22clientObj%22%3A%7B%22vergiNumarasi%22%3A%22',vkn,'%22%2C%22tcKimlikNo%22%3A%22%22%2C%22yil%22%3A%22',yil,'%22%2C%22ay%22%3A%22',ay,'%22%2C%22hvBabsMi%22%3Atrue%7D%7D');
	var bs = getRemote(url5);
	var obj =JSON.parse(bs);
  

	// GİB yanıtı iki bölüm döner:
	//  - data.liste1 : "Mal ve Hizmet Satılan Kişilere İlişkin Bilgiler" (SATIŞ / KARŞIT ALIŞ)
	//  - data.liste  : "Mal ve Hizmet Satın Alınan Kişilere İlişkin Bilgiler" (ALIŞ / KARŞIT SATIŞ)
	// Bizim tabloda yazdırmak istediğimiz: SATIŞ / KARŞIT ALIŞ => liste1
	var bs_liste = obj.data.liste1; 
	
	$.each(bs_liste, function(index, satir){
		
		// Toplam satırında genelde malHizmetBedeli1Top / malHizmetBedeli2Top gelir.
		// liste1 için:
		//  - malHizmetBedeli1Top : SATIŞ toplamı
		//  - malHizmetBedeli2Top : KARŞIT ALIŞ toplamı
		if (satir && satir.malHizmetBedeli1Top != undefined) tutarBS = satir.malHizmetBedeli1Top;
		if (satir && satir.malHizmetBedeli2Top != undefined) tutarKarsiAlis = satir.malHizmetBedeli2Top;

		      
	  });
  
  return tlCevir(tutarBS) + "-" + tlCevir(tutarKarsiAlis) ;

}

	catch(err){

	console.log("Karşılaştırmalı Alış-Satış Analizi Hata ile karşılaşıldı" + err);

	return "Hata" + "-" + "Hata" ;


	}
}




/**
 * Satış / Karşıt Alış (alisSatisAnaliziService_getAlisSatisAnaliz) sorgusunu async çalıştırır.
 * Başarılı olursa {bs, karsit} döner. Hata/timeout/parse durumunda reject eder.
 */
function bsSorgulaAsync(vkn, yil, ay, token) {
  // GİB tarafında "doğru" çalışan örnek sorguda jp içinde spTip/spDonem/oranBilgisiMevcutMu alanları da gönderiliyor.
  // Biz de aynı formatı birebir kullanıyoruz.
  var ay2 = (String(ay).length === 1) ? ('0' + String(ay)) : String(ay);
  var spDonem = String(yil) + ay2; // YYYYMM
  var callid = makeid(13) + '-';
  var url5 = 'http://10.251.63.99/gibintranet_server/dispatch?cmd=alisSatisAnaliziService_getAlisSatisAnaliz&callid=';
  url5 = url5.concat(callid + '121', '&token=', token,
    '&jp=%7B%22clientObj%22%3A%7B%22vergiNumarasi%22%3A%22', vkn,
    '%22%2C%22tcKimlikNo%22%3A%22%22%2C%22yil%22%3A%22', yil,
    '%22%2C%22ay%22%3A%22', ay2,
    '%22%2C%22spTip%22%3A%221%22%2C%22spDonem%22%3A%22', spDonem,
    // hvBabsMi=true  -> BS (mal/hizmet SATILAN)
    // hvBabsMi=false -> BA (mal/hizmet ALINAN)
    // Bizim ekranda ihtiyaç duyduğumuz: SATILAN (BS)
    '%22%2C%22hvBabsMi%22%3Atrue%2C%22oranBilgisiMevcutMu%22%3Afalse%7D%7D');

  return $.ajax({
    type: 'GET',
    url: url5,
    dataType: 'json',
    // Satış/Karşıt Alış analizi bazı dönemlerde 45 sn'yi aşabiliyor.
    // 45 sn timeout Chrome Network'te "(iptal edildi)" gibi görünüyor ve sonuç gelmeden kesiliyor.
    // Bu yüzden daha uzun timeout kullanıyoruz.
    // Kullanıcı isteği: 1000 sn timeout
    timeout: 120000
  }).then(function(obj){
    // Bazı dönemlerde servis "başarısız" dönüyor ama HTTP 200 oluyor.
    // Bu durumda 0 yazıp geçersek hem yanlış sonuç oluşuyor hem de retry devreye girmiyor.
    // Dolayısıyla bu yanıtları reject edip retry mekanizmasını çalıştırıyoruz.
    var topSuccess = (obj && obj.success === false);
    var dataSuccess = (obj && obj.data && obj.data.success === false);
    var errMsg = (obj && (obj.errorMessage || obj.error || obj.message)) || (obj && obj.data && (obj.data.errorMessage || obj.data.error || obj.data.message));
    if (topSuccess || dataSuccess) {
    return {__err:true, errorMessage: (errMsg || "alisSatisAnaliziService başarısız döndü")};
}

    var tutarBS = 0;
    var tutarKarsiAlis = 0;
    // GİB yanıtı iki bölüm döner:
    //  - data.liste1 : "Mal ve Hizmet Satılan Kişilere İlişkin Bilgiler" (SATIŞ / KARŞIT ALIŞ)
    //  - data.liste  : "Mal ve Hizmet Satın Alınan Kişilere İlişkin Bilgiler" (ALIŞ / KARŞIT SATIŞ)
    // Bizim tabloda yazdırmak istediğimiz: SATIŞ / KARŞIT ALIŞ => liste1
    
// SATIŞ / KARŞIT ALIŞ bilgileri "liste1" içinde gelir.
    var bs_liste = (obj && obj.data && obj.data.liste1) ? obj.data.liste1 : [];
    var sum1 = 0, sum2 = 0;
    $.each(bs_liste, function(_i, satir){
      // Toplam satırında genelde malHizmetBedeli1Top / malHizmetBedeli2Top gelir.
      if (satir && satir.malHizmetBedeli1Top != undefined) tutarBS = satir.malHizmetBedeli1Top;
      if (satir && satir.malHizmetBedeli2Top != undefined) tutarKarsiAlis = satir.malHizmetBedeli2Top;

      // Bazı yanıtlarda *Top gelmeyebiliyor; o durumda satırları toplayalım.
      if (satir && satir.malHizmetBedeli1 != undefined) sum1 += parseMoney(satir.malHizmetBedeli1);
      if (satir && satir.malHizmetBedeli2 != undefined) sum2 += parseMoney(satir.malHizmetBedeli2);
    });
    if (tutarBS === 0 && tutarKarsiAlis === 0 && (sum1 !== 0 || sum2 !== 0)) {
      tutarBS = sum1;
      tutarKarsiAlis = sum2;
    }
    return { bs: tlCevir(tutarBS), karsit: tlCevir(tutarKarsiAlis) };

  });
}

/**
 * POS / Banka (posKrediKartiService_bankaSatisBilgGoreAylikSorgula) sorgusunu async çalıştırır.
 * Başarılı olursa tlCevir(toplamGenel) döner.
 */
function posBankaAylikAsync(vkn, yil, ay, token) {
  var callid = makeid(13) + '-';
  var url5 = 'http://10.251.63.99/gibintranet_server/dispatch?cmd=posKrediKartiService_bankaSatisBilgGoreAylikSorgula&callid=';
  url5 = url5.concat(callid + '22', '&token=', token,
    '&jp=%7B%22vkn%22%3A%22', vkn,
    '%22%2C%22tckn%22%3A%22%22%2C%22satisDonemAy%22%3A%22', ay,
    '%22%2C%22satisDonemYil%22%3A%22', yil,
    '%22%2C%22respKeyParam%22%3A%22bankaSatisAylikListe%22%2C%22isFullData%22%3Afalse%2C%22isFullExport%22%3Atrue%2C%22pv%22%3A%7B%22start%22%3A0%2C%22limit%22%3A%2250%22%2C%22sorters%22%3A%5B%5D%7D%7D');

  return $.ajax({
    type: 'GET',
    url: url5,
    dataType: 'json',
    timeout: 120000
  }).then(function(obj){
    try {
      var topSuccess = (obj && obj.success === false);
      var dataSuccess = (obj && obj.data && obj.data.success === false);
      var errMsg = (obj && (obj.errorMessage || obj.error || obj.message)) || (obj && obj.data && (obj.data.errorMessage || obj.data.error || obj.data.message));
      if (topSuccess || dataSuccess) {
    return {__err:true, errorMessage: (errMsg || "posKrediKartiService başarısız döndü")};
}
      var list  = (obj && obj.data && obj.data.bankaSatisAylikListe) ? obj.data.bankaSatisAylikListe : [];
      if (list && list.length > 0) {
        // Önce toplamGenel içeren satırı yakala
        var totalRow = null;
        for (var i=0; i<list.length; i++){
          if (list[i] && list[i].toplamGenel != null) { totalRow = list[i]; break; }
        }
        if (totalRow) {
          return parseMoney(totalRow.toplamGenel);
        }
        // toplamGenel yoksa satır satır topla
        var sum = 0;
        for (var j=0; j<list.length; j++){
          var r = list[j] || {};
          sum += parseMoney(r.tutar || r.tutari || r.toplam || r.genelToplam || r.toplamGenel || 0);
        }
        return sum;
      }
      return 0;
      } catch(e) {
      // throw -> retry devreye girsin
      throw e;
    }
  });
}

// ----- FULL-YEAR (1-12) tek motor: satış/karşıt alış + POS/banka + kümülatif yazım -----
window.tkkomFullYearStart = function(token, vkn) {
  try {
    if (!token || !vkn) return;
    if (window.__TK_FULLYEAR_RUNNING__) return;
    window.__TK_FULLYEAR_RUNNING__ = true;

    var tries = 0;
    var timer = setInterval(function(){
      tries++;
      var $tbl = $('#myTable6');
      if ($tbl.length === 0) {
        if (tries > 80) { clearInterval(timer); window.__TK_FULLYEAR_RUNNING__ = false; }
        return;
      }
      var $rows = $tbl.find('tr.takkom-row');
      if ($rows.length === 0) {
        if (tries > 80) { clearInterval(timer); window.__TK_FULLYEAR_RUNNING__ = false; }
        return;
      }

      clearInterval(timer);

      var yearsMap = {};
      
var getEndAy = function(vk, donemStr, fallbackAy){
            try {
              // donem formatı genelde "YYYYMMYYYYMM" (örn: 202004202006) veya "YYYYMM".
              // 0015 satırları aylık olduğundan data-ay'dan okunacak.
              if (vk === '0015') {
                var a = parseInt(String(fallbackAy||'').trim(), 10);
                return (a>=1 && a<=12) ? a : 12;
              }
              var d = String(donemStr||'').replace(/\D/g,'');
              if (d.length >= 12) {
                var endM = parseInt(d.substr(10,2),10);
                return (endM>=1 && endM<=12) ? endM : 12;
              }
              if (d.length >= 6) {
                var m = parseInt(d.substr(4,2),10);
                return (m>=1 && m<=12) ? m : 12;
              }
              return 12;
            } catch(e) { return 12; }
          };
var $rows2 = $('#myTable6').find('tbody tr');
          $rows2.each(function(){
        var y = String($(this).attr('data-yil') || '').trim();
        if (y) yearsMap[y] = true;
      });
      var years = Object.keys(yearsMap).sort();
      if (years.length === 0) { window.__TK_FULLYEAR_RUNNING__ = false; return; }

      $rows.each(function(){
        var $tr = $(this);
        $tr.find('td.col-satis').text('Yükleniyor');
        $tr.find('td.col-karsit').text('Yükleniyor');
        $tr.find('td.col-banka').text('Yükleniyor');
      });

      var bsCache = {};
      var posCache = {};

      function parseTlNum(tlStr) {
        if (tlStr == null) return 0;
        var s = String(tlStr).trim();
        if (s === '' || s === '-' || s === 'Hata') return 0;
        s = s.replace(/\./g,'').replace(/,/g,'.');
        var n = parseFloat(s);
        return isNaN(n) ? 0 : n;
      }

      function formatTl(n) {
        try {
          return n.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        } catch(e) {
          return String(n);
        }
      }

      function toPromise(jq){
        return new Promise(function(resolve, reject){
          jq.done(resolve).fail(function(xhr, textStatus, errorThrown){
            reject({xhr:xhr, textStatus:textStatus, errorThrown:errorThrown});
          });
        });
      }

      function withRetry(fn, maxRetry){
        return new Promise(function(resolve, reject){
          var attempt = 0;
          function run(){
            attempt++;
            Promise.resolve().then(fn).then(resolve).catch(function(err){
              if (attempt <= maxRetry) setTimeout(run, 400);
              else reject(err);
            });
          }
          run();
        });
      }

      var tasks = [];
      years.forEach(function(y){
        for (var m=1; m<=12; m++) {
          var mm = (m<10 ? '0'+m : ''+m);
          tasks.push({ year: y, month: mm });
        }
      });

      var CONCURRENCY = 8;
      var MAX_RETRY = 2;
      var idx = 0;
      var inFlight = 0;
      var doneDef = $.Deferred();

      function pump(){
        while (inFlight < CONCURRENCY && idx < tasks.length) {
          (function(task){
            inFlight++;
            var y = task.year;
            var mm = task.month;
            if (!bsCache[y]) bsCache[y] = {};
            if (!posCache[y]) posCache[y] = {};

            
            // BS (Satış/Karşıt Alış) ve POS/Banka sorgularını birbirinden bağımsız çalıştır.
            // Birinin hatası diğerini bloklamasın.
            var bsP = withRetry(function(){
              return toPromise(bsSorgulaAsync(vkn, y, mm, token));
            }, MAX_RETRY).then(function(res){
              if(res && res.__err){
                bsCache[y][mm] = {
                  err: res.errorMessage || 'HATA',
                  bsStr: 'HATA',
                  karsitStr: 'HATA',
                  bsNum: 0,
                  karsitNum: 0
                };
              } else {
                if (!res || res.bs == null || res.karsit == null) {
          bsCache[y][mm] = { err: 'Eksik/boş cevap', bsNum: 0, karsitNum: 0, bsStr: 'HATA', karsitStr: 'HATA', lastTs: Date.now() };   /* v517-fix: st ve yil bu kapsamda tanımsızdı (ReferenceError) */
          return true;
        }
        var bsStr = res.bs;
        var kaStr = res.karsit;
                var bsNum = parseTlNum(bsStr);
        var kaNum = parseTlNum(kaStr);
        if ((typeof bsStr === 'string' && !/[0-9]/.test(bsStr)) || (typeof kaStr === 'string' && !/[0-9]/.test(kaStr)) || isNaN(bsNum) || isNaN(kaNum)) {
          bsCache[y][mm] = { err: 'Geçersiz cevap', bsStr: 'HATA', karsitStr: 'HATA', bsNum: 0, karsitNum: 0 };
          return true;
        }
        bsCache[y][mm] = { err: false, bsStr: bsStr, karsitStr: kaStr, bsNum: bsNum, karsitNum: kaNum };
      }
      return false;
            }).catch(function(){
              // Hata/timeout/parse
              bsCache[y][mm] = { err:true, bsStr:'HATA', karsitStr:'HATA', bsNum:0, karsitNum:0 };
              return false;
            });

            var posP = withRetry(function(){
              return toPromise(posBankaAylikAsync(vkn, y, mm, token));
            }, MAX_RETRY).then(function(posVal){
              if(posVal && posVal.__err){
                posCache[y][mm] = { err: posVal.errorMessage || 'HATA', str:'HATA', num:0 };
                return true;
              }
              if (posVal == null) {
                posCache[y][mm] = { err: 'Eksik/boş cevap', str: 'HATA', num: 0 };
                return true;
              }
              var pStr = (typeof posVal === 'number') ? formatTl(posVal) : (posVal || '0,00');
              var pNum = parseTlNum(pStr);
              if ((typeof pStr === 'string' && !/[0-9]/.test(pStr)) || isNaN(pNum)) {
                posCache[y][mm] = { err: 'Geçersiz cevap', str: 'HATA', num: 0 };
                return true;
              }
              posCache[y][mm] = { err: false, str: pStr, num: pNum };
              return false;
            }).catch(function(){
              posCache[y][mm] = { err:true, str:'HATA', num:0 };
              return false;
            });

            Promise.all([bsP, posP]).then(function(){

              // Promise.finally bazı ortamlarda problem çıkarabiliyor; bu yüzden then ile kapatıyoruz.
              inFlight--;
              if (idx >= tasks.length && inFlight === 0) doneDef.resolve();
              else pump();
            });
          })(tasks[idx++]);
        }
      }

      pump();

      doneDef.then(function(){
        try {
          $rows.each(function(){
            var $tr = $(this);
            var vk = String($tr.attr('data-vergikodu') || '').trim();
            var donem = String($tr.attr('data-donem') || '').trim();
            var yil = String($tr.attr('data-yil') || '').trim();
            if (!vk || !donem || !yil) return;

            
var endAy = 12;
            if (vk === '0015' || vk === '0032' || vk === '0033' || vk === '0001' || vk === '0010') {
              endAy = getEndAy(vk, donem, String($tr.attr('data-ay')||''));
            }
            else {
              $tr.find('td.col-satis').text('-');
              $tr.find('td.col-karsit').text('-');
              $tr.find('td.col-banka').text('');
              return;
            }

            var sumBs = 0, sumKa = 0, sumPos = 0;
            var hataBS = false, hataPos = false;
            if (vk === '0015') {
              var ownAy = String($tr.attr('data-ay') || '').trim();
              var ownM = parseInt(ownAy,10);
              if (!(ownM>=1 && ownM<=12)) ownM = endAy;
              var mm = (ownM<10 ? '0'+ownM : ''+ownM);
              var b = (bsCache[yil] && bsCache[yil][mm]) ? bsCache[yil][mm] : null;
              var p = (posCache[yil] && posCache[yil][mm]) ? posCache[yil][mm] : null;
              if (!b || b.err) hataBS = true;
              if (!p || p.err) hataPos = true;
              sumBs = b ? b.bsNum : 0;
              sumKa = b ? b.karsitNum : 0;
              sumPos = p ? p.num : 0;
            } else {
              for (var m=1; m<=endAy; m++) {
                var mm2 = (m<10 ? '0'+m : ''+m);
                var b2 = (bsCache[yil] && bsCache[yil][mm2]) ? bsCache[yil][mm2] : null;
                var p2 = (posCache[yil] && posCache[yil][mm2]) ? posCache[yil][mm2] : null;
                if (!b2 || b2.err) hataBS = true;
                else { sumBs += b2.bsNum; sumKa += b2.karsitNum; }
                if (!p2 || p2.err) hataPos = true;
                else { sumPos += p2.num; }
              }
            }

            var $tdS = $tr.find('td.col-satis');
            var $tdK = $tr.find('td.col-karsit');
            var $tdB = $tr.find('td.col-banka');

            if (hataBS) {
              $tdS.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>');
              $tdK.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>');
            } else {
              $tdS.text(formatTl(sumBs));
              $tdK.text(formatTl(sumKa));
            }

            if (hataPos) {
              $tdB.html('<span class="tk-retry" data-kind="pos" title="Tekrar dene">HATA &#x21bb;</span>');
            } else {
              $tdB.text(formatTl(sumPos));
            }
});
        } finally {
          // Retry için state'i sakla
          window.__TK_STATE__ = window.__TK_STATE__ || {};
          window.__TK_STATE__.token = token;
          window.__TK_STATE__.vkn = vkn;
          window.__TK_STATE__.bsCache = bsCache;
          window.__TK_STATE__.posCache = posCache;

          // Tek sefer bağla
          if (!window.__TK_RETRY_BOUND__) {
            window.__TK_RETRY_BOUND__ = true;
            $(document).on('click', '.tk-retry', function(){
              try {
                var $span = $(this);
                var $tr = $span.closest('tr');
                var kind = String($span.attr('data-kind') || '');
                var st = window.__TK_STATE__ || {};
                if (!st.token || !st.vkn) return;

                var vk = String($tr.attr('data-vergikodu') || '').trim();
                var donem = String($tr.attr('data-donem') || '').trim();
                var yil = String($tr.attr('data-yil') || '').trim();
                if (!vk || !donem || !yil) return;

                var endAy = getEndAy(vk, donem, String($tr.attr('data-ay')||''));
                if (!(endAy>=1 && endAy<=12)) endAy = 12;

                // Hedef hücre(ler)i yükleniyor yap
                if (kind === 'bs') {
                  $tr.find('td.col-satis').text('Yükleniyor');
                  $tr.find('td.col-karsit').text('Yükleniyor');
                } else if (kind === 'pos') {
                  $tr.find('td.col-banka').text('Yükleniyor');
                }

                var months = [];
                if (vk === '0015') {
                  var ownAy = parseInt(String($tr.attr('data-ay')||''),10);
                  if (!(ownAy>=1 && ownAy<=12)) ownAy = endAy;
                  months = [ownAy];
                } else {
                  for (var m=1; m<=endAy; m++) months.push(m);
                }

                // Kuyrukla (limit 8)
                var q = months.slice();
                var inF = 0;
                var CONC = 8;
                var RETRY = 2;

                function runOne(m){
                  var mm = (m<10 ? '0'+m : ''+m);
                  if (kind === 'bs') {
                    if (!st.bsCache[yil]) st.bsCache[yil] = {};
                    return withRetry(function(){ return toPromise(bsSorgulaAsync(st.vkn, yil, mm, st.token)); }, RETRY)
                      .then(function(res){
                        if (!res || res.bs == null || res.karsit == null) {
          st.bsCache[yil][mm] = { err: 'Eksik/boş cevap', bsNum: 0, karsitNum: 0, bsStr: 'HATA', karsitStr: 'HATA', lastTs: Date.now() };
          return true;
        }
        var bsStr = res.bs;
        var kaStr = res.karsit;
                        st.bsCache[yil][mm] = { err:false, bsStr:bsStr, karsitStr:kaStr, bsNum:parseTlNum(bsStr), karsitNum:parseTlNum(kaStr) };
                      })
                      .catch(function(){
                        st.bsCache[yil][mm] = { err:true, bsStr:'HATA', karsitStr:'HATA', bsNum:0, karsitNum:0 };
                      });
                  } else {
                    if (!st.posCache[yil]) st.posCache[yil] = {};
                    return withRetry(function(){ return toPromise(posBankaAylikAsync(st.vkn, yil, mm, st.token)); }, RETRY)
                      .then(function(posVal){
                        if (posVal == null) {
                posCache[y][mm] = { err: 'Eksik/boş cevap', str: 'HATA', num: 0 };
                return true;
              }
              var pStr = (typeof posVal === 'number') ? formatTl(posVal) : (posVal || '0,00');
                        st.posCache[yil][mm] = { err:false, str:pStr, num:parseTlNum(pStr) };
                      })
                      .catch(function(){
                        st.posCache[yil][mm] = { err:true, str:'HATA', num:0 };
                      });
                  }
                }

                function recompute(){
                  var sumBs=0,sumKa=0,sumPos=0;
                  var hataBS=false,hataPos=false;

                  if (vk === '0015') {
                    var m = months[0];
                    var mm = (m<10 ? '0'+m : ''+m);
                    var b = (st.bsCache[yil] && st.bsCache[yil][mm]) ? st.bsCache[yil][mm] : null;
                    var p = (st.posCache[yil] && st.posCache[yil][mm]) ? st.posCache[yil][mm] : null;
                    if (b && !b.err) { sumBs=b.bsNum; sumKa=b.karsitNum; } else hataBS=true;
                    if (p && !p.err) { sumPos=p.num; } else hataPos=true;
                  } else {
                    for (var m2=1; m2<=endAy; m2++){
                      var mm2 = (m2<10 ? '0'+m2 : ''+m2);
                      var b2 = (st.bsCache[yil] && st.bsCache[yil][mm2]) ? st.bsCache[yil][mm2] : null;
                      var p2 = (st.posCache[yil] && st.posCache[yil][mm2]) ? st.posCache[yil][mm2] : null;
                      if (b2 && !b2.err) { sumBs+=b2.bsNum; sumKa+=b2.karsitNum; } else hataBS=true;
                      if (p2 && !p2.err) { sumPos+=p2.num; } else hataPos=true;
                    }
                  }

                  // Hücreleri güncelle
                  var $tdS = $tr.find('td.col-satis');
                  var $tdK = $tr.find('td.col-karsit');
                  var $tdB = $tr.find('td.col-banka');

                  if (kind === 'bs') {
                    if (hataBS) {
                      $tdS.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>');
                      $tdK.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>');
                    } else {
                      $tdS.text(formatTl(sumBs));
                      $tdK.text(formatTl(sumKa));
                    }
                  } else if (kind === 'pos') {
                    if (hataPos) {
                      $tdB.html('<span class="tk-retry" data-kind="pos" title="Tekrar dene">HATA &#x21bb;</span>');
                    } else {
                      $tdB.text(formatTl(sumPos));
                    }
                  }
                }

                function pumpRetry(){
                  while (inF < CONC && q.length){
                    (function(m){
                      inF++;
                      runOne(m).then(function(){
                        inF--;
                        if (!q.length && inF===0) recompute();
                        else pumpRetry();
                      });
                    })(q.shift());
                  }
                }

                pumpRetry();
              } catch(e){
                console.log('tk-retry hata', e);
              }
            });
          }

          window.__TK_FULLYEAR_RUNNING__ = false;
        }
      });
    }, 500);
  } catch(e) {
    window.__TK_FULLYEAR_RUNNING__ = false;
    console.log('tkkomFullYearStart hata:', e);
  }
};

/**
 * myTable6 içindeki 0015 satırlarının Satış/Karşıt Alış kolonlarını toplu doldurur.
 * 1. turda hepsini paralel (limitli) yollar, bitince "Hata" kalanları otomatik tekrar dener.
 */
window.bsBatchUpdateMyTable6 = function(token, vkn){
  try {
    var $rows = $('#myTable6 tr.bs-row');
    if (!$rows || $rows.length === 0) return;

    var tasks = [];
    $rows.each(function(){
      var $tr = $(this);
      var yil = String($tr.attr('data-yil') || '').trim();
      var ay  = String($tr.attr('data-ay')  || '').trim();
      if (!yil || !ay) return;

      tasks.push({ $tr: $tr, yil: yil, ay: ay });
      $tr.find('td.col-satis').text('Yükleniyor');
      $tr.find('td.col-karsit').text('Yükleniyor');
      $tr.addClass('bs-pending');
    });

    // Çok yüksek paralellik bazı ortamlarda isteğin iptal edilmesine/timeout'a sebep olabiliyor.
    // Daha stabil olması için düşük paralellik.
    var CONCURRENCY = 4;
    var MAX_RETRY = 2;

    function runOnce(pending){
      var d = $.Deferred();
      var idx = 0;
      var inFlight = 0;
      var failed = [];

      function pump(){
        while (inFlight < CONCURRENCY && idx < pending.length) {
          (function(t){
            inFlight++;
            bsSorgulaAsync(vkn, t.yil, t.ay, token)
              .then(function(res){
                t.$tr.find('td.col-satis').text(res.bs);
                t.$tr.find('td.col-karsit').text(res.karsit);
                t.$tr.removeClass('bs-pending');
              })
              .fail(function(){
                t.$tr.find('td.col-satis').text('Hata');
                t.$tr.find('td.col-karsit').text('Hata');
                failed.push(t);
              })
              .always(function(){
                inFlight--;
                pump();
                if (idx >= pending.length && inFlight === 0) d.resolve(failed);
              });
          })(pending[idx++]);
        }

        if (idx >= pending.length && inFlight === 0) d.resolve(failed);
      }

      pump();
      return d.promise();
    }

    runOnce(tasks).then(function(failed1){
      if (!failed1 || failed1.length === 0) return;

      var attempt = 1;
      function retryLoop(failed){
        if (!failed || failed.length === 0) return;
        if (attempt > MAX_RETRY) return;

        setTimeout(function(){
          attempt++;
          runOnce(failed).then(function(failedNext){
            retryLoop(failedNext);
          });
        }, 800 * attempt);
      }

      retryLoop(failed1);
    });

  } catch(e) {
    console.log('bsBatchUpdateMyTable6 hata:', e);
  }
};
var __sorguZamaniEl = document.getElementById('sorguZamani');
if (__sorguZamaniEl) { __sorguZamaniEl.innerHTML = "Sorgu Zamanı : " + bugun(); }

//////////////////////eski kullanılmayan////////////////////////////////////////////////////////////////////////////////////////////////////////

function matrah_odenen(vkno,vdkodu,thkNo) {


var callid=makeid(13) + '-';


    var orgOid=orgIDGetir(vdkodu);

    if (orgOid!="undefined") { 
    
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid=';
    var url=url.concat(callid + '50', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22', orgOid ,'%22%7D%7D');
    var url_thk = getRemote(url);
    var obj =tkParse(url_thk,'matrah_odenen');

    var a=0;
    var b=0;

    var liste = obj.data.tecilKayitlari; /// 

      $.each(liste, function(index, satir){ //bütün tecil numaralarının tahakkuk numaralı kontrol ediliyor

	    
	    var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilDetayGetir&callid=';
	       var url1=url1.concat(callid + '30', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22tecilDosyaNo%22%3A%22',satir.tecilDosyaNo,'%22%2C%22tecilDilekceNo%22%3A%22%22%2C%22tecilDilekceTarihi%22%3A%22%22%2C%22tecildenKaldirmaTarihi%22%3A%22%22%2C%22tecildenKaldirmaNedeni%22%3A%22',satir.tecildenKaldirmaNedeni,'%22%2C%22ortakVkn%22%3A%22%22%2C%22ortakTckn%22%3A%22%22%2C%22plakano%22%3A%22%22%2C%22tecilTuru%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgOid,'%22%2C%22tecilTipi%22%3A%22',satir.tecilTipi,'%22%7D%7D');
	    var url_thk1 = getRemote(url1);
	    var obj1 =tkParse(url_thk1,'matrah_odenen');
	    var tecil_thk=obj1.data.tecilSatirlari[0].thkfisno;
	    
	    
	    if (tecil_thk==thkNo) {
	    
	    
	    a=obj1.data.tecilOdenenToplamVab;
	    
	    b=obj1.data.tecilOdenenToplamTecilFaizi;
	    
	    c=obj1.data.tecilToplamIndirim;
	    
	    }
	    
	    
	});

    return Number(a+b+c).toLocaleString("tr-TR");
    
    }else{
    
    return "Kontrol Edilmesi Gerekiyor";
    }

}

function matrah_odenmesi_gereken(vkno,vdkodu,thkNo) {


var callid=makeid(13) + '-';

    var orgOid=orgIDGetir(vdkodu);

    if (orgOid!="undefined") { 
    
    var a=0;

    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid=';
    var url=url.concat(callid + '15', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgOid ,'%22%7D%7D');
    var url_thk = getRemote(url);
    var obj =tkParse(url_thk,'matrah_odenmesi_gereken');

    var liste = obj.data.tecilKayitlari; /// 

      $.each(liste, function(index, satir){

	    var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilDetayGetir&callid=';
	       var url1=url1.concat(callid + '30', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22tecilDosyaNo%22%3A%22',satir.tecilDosyaNo,'%22%2C%22tecilDilekceNo%22%3A%22%22%2C%22tecilDilekceTarihi%22%3A%22%22%2C%22tecildenKaldirmaTarihi%22%3A%22%22%2C%22tecildenKaldirmaNedeni%22%3A%22',satir.tecildenKaldirmaNedeni,'%22%2C%22ortakVkn%22%3A%22%22%2C%22ortakTckn%22%3A%22%22%2C%22plakano%22%3A%22%22%2C%22tecilTuru%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgOid,'%22%2C%22tecilTipi%22%3A%22',satir.tecilTipi,'%22%7D%7D');
	    var url_thk1 = getRemote(url1);
	    var obj1 =tkParse(url_thk1,'matrah_odenmesi_gereken');

	    if (obj1.data.tecilSatirlari[0].thkfisno==thkNo) {
	    
	    a= obj1.data.tecilToplamVab;
		    
	    
	    }
	    
	    
	});

    return Number(a).toLocaleString("tr-TR");

    }else{
    
    return "Kontrol Edilmesi Gerekiyor";
    }
    
    
}


function matrah_artırımı_durum(vkno,vdkodu,thkNo) {


var callid=makeid(13) + '-';


    var orgOid=orgIDGetir(vdkodu);

    if (orgOid!="undefined") { 
    
    var a="";

    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilleriGetir&callid=';
    var url=url.concat(callid + '15', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vdkodu,'%22%2C%22orgOid%22%3A%22',orgOid,'%22%7D%7D');
    var url_thk = getRemote(url);
    var obj =tkParse(url_thk,'matrah_artırımı_durum');

    var liste = obj.data.tecilKayitlari; /// 

      $.each(liste, function(index, satir){

	    var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilDetayGetir&callid=';
	    var url1=url1.concat(callid + '24', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22tecilDosyaNo%22%3A%22',satir.tecilDosyaNo,'%22%2C%22tecilDilekceNo%22%3A%22%22%2C%22tecilDilekceTarihi%22%3A%22%22%2C%22tecildenKaldirmaTarihi%22%3A%22%22%2C%22tecildenKaldirmaNedeni%22%3A%22',satir.tecildenKaldirmaNedeni,'%22%2C%22ortakVkn%22%3A%22%22%2C%22ortakTckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22orgOid%22%3A%22',orgOid,'%22%7D%7D');
	    var url_thk1 = getRemote(url1);
	    var obj1 =tkParse(url_thk1,'matrah_artırımı_durum');
	    
	    //alert(thkNo);
	    //alert(obj1.data.tecilSatirlari[0].thkfisno);
	    
	    if (obj1.data.tecilSatirlari[0].thkfisno===thkNo) {
	    
	    a= satir.tecildenKaldirmaNedeni;
	    
	  
	}
	
	
    });


    return a;
    
     }else{
    
    return "Kontrol Edilmesi Gerekiyor";
    }
    
    

}

function matrahArtirimi(vkno,durum){

  var myRegex= /[0-9]+/;
  
  
  
  var callid=makeid(13) + '-';
  var matrah_art_liste=new Array();
  var a=0; 
  var hata= "";

         	
      
      ///////////////////////////////////////////////////////////////////////////////////////// Yapılandırma Kontrolü Yapılıyor 7143 
      
   if (durum==1 || durum==4){   
		  var url_7143= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=borcYapilandirma7045Service_matrahArtirimiSorgula7045&callid=';
		  var url_7143=url_7143.concat(callid + '73', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%7D');
		  var url7143 = getRemote(url_7143);
		  var obj_7143 =tkParse(url7143,'matrahArtirimi');
		  
		  var hataVarmi=obj_7143.error;
		        
		 if (hataVarmi==undefined || hataVarmi=="undefined" ){
		   
		
		var liste_7143 = obj_7143.data.liste; /// 

		      
		$.each(liste_7143, function(index, satir){
		
		
		matrah_art_liste[a]=  vdAdi(satir.vdKodu)  + "-7143 Sayılı Kanun-" + satir.vergiKodu +  "<hr><br>";
		a=a+1; 	
		  
		  
		  });
		  
		  }else{
		  
		  hata= obj_7143.messages[0].text + "<br>" ;
		  
		  }
     
     }
     
	 if(durum==2 || durum==4){
            
       
      var url_7326= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=borcYapilandirma7326Service_matrahArtirimiSorgula7326&callid=';
      var url_7326=url_7326.concat(callid + '79', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%7D');
      var url7326 = getRemote(url_7326);
      var obj_7326 =tkParse(url7326,'matrahArtirimi');

    
      var hataVarmi=obj_7326.error;
      var hataVarmi2=obj_7326.data;
    
  
		 if (hataVarmi2!==null){
		 
			 if (hataVarmi==undefined || hataVarmi=="undefined" ){
		  
				  var liste_obj_7326 = obj_7326.data.liste; ///
				  
				  	$.each(liste_obj_7326, function(index, satir){
				  	
				  	matrah_art_liste[a]=  vdAdi(satir.vdKodu)   + "-7326 Sayılı Kanun-" + satir.vergiKodu +  "<hr><br>";
				a=a+1; 	  
				  
				  });
			  
			  }
		  
		 }
      
     } 
     
     if(durum==3 || durum==4){
      
      //////////////////////////7440 Sayılı Kanun///////////////////////////


	  var url_7440= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=borcYapilandirma7426Service_matrahArtirimiSorgula7426&callid=';
      var url_7440=url_7440.concat(callid + '25', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%7D');
      var url7440 = getRemote(url_7440);
      var obj_7440 =tkParse(url7440,'matrahArtirimi');
	
      var hataVarmi=obj_7440.error;
      
      if (hataVarmi==undefined){
  
      var liste_obj_7440 = obj_7440.data.liste; ///
      
      	$.each(liste_obj_7440, function(index, satir){
	
	 	matrah_art_liste[a]=  vdAdi(satir.vdKodu)   + "-7440 Sayılı Kanun-" + satir.vergiKodu +  "<hr><br>";
		a=a+1; 	
      
      
      });
      
       }
     
     }
return matrah_art_liste;


}   


function evdbRaporTokenGetir(){
      // EVDB Rapor tokeni tekrar assos-login ile alınmaz; uzantının yakaladığı token kullanılır.
      try{ var t=takkomTokenGetir('evdbrapor'); if(t) return t; }catch(e){}
      throw new Error('EVDB Rapor tokeni yakalanmadı. EVDB Rapor ekranını aynı tarayıcıda bir kez açıp uzantının tokeni yakalamasını sağlayın.');
}

function evdbRaporSessionGetir(token){
      
      var callid=makeid(13) + '-';

      var url5= 'http://10.251.63.99/evdorapor_server/dispatch?cmd=userSessionService_getUserSessionInfo&callid=' + callid + '19&module=evdorapor&' + token + '&jp=%7B%22rfDataInfo%22%3A%5B%5D%7D';
      var yeniToken = postRemote(url5);
      var obj =tkParse(yeniToken,'evdbRaporSessionGetir');
      return obj.data.ASessionId;

}

function evdbRaporTokenKill(token,ASessionId){

	        
      var callid=makeid(13) + '-';
      var url5= 'http://10.251.63.99/evdorapor_server/dispatch?&cmd=sessionCsapService_destroySession&callid=' + callid + '22&module=evdorapor&token=' + token + '&jp=%7B%22ASessionId%22%3A%22' + ASessionId + '%22%7D';
      var yeniToken = postRemote(url5);
      var obj =tkParse(yeniToken,'evdbRaporTokenKill');
 

}


function incelemeVarmiMDOS(vkn){

     
      var callid=makeid(13) + '-';
      var dizi =new Array();
      

      var url= 'http://arkaofis.gelbim.gov.tr:32174/izah-server/dispatch?cmd=vdkService_getVDKInceleme&callid=';
      var url=url.concat(callid + '555', '&token=', token(), '&jp=%7B%22vergiKimlikNumarasi%22%3A%22',vkn,'%22%7D');
	  var inceleme = postRemote(url);
      var obj =tkParse(inceleme,'incelemeVarmiMDOS');
      
      
	if ( obj.data.vdkInceleme.length!=0){
      $.each(obj.data.vdkInceleme, function(index, satir){
	
	 	dizi.push("Dönem: " + satir.donem + " - İnceleme Konusu: " + satir.incelemeKonusu + " -  Başlama Tarihi: " + tarihFormat(satir.baslamaTarihi) + " <br>");

      
      
      });
      
      return dizi;
      
      }else{
      
      return '--';
      
      }

}


function adiOrtaklikSorgulu(vkn){

	var myRegex= /[0-9]+/;
      
      
      
      var callid=makeid(13) + '-';
      
      
      //
      var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_adiOrtakliginOrtaklikBilgileriServisiCagir&callid=';
      var url=url.concat(callid + '180', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%7D');
      var url= getRemote(url);
      var obj =tkParse(url,'adiOrtaklikSorgulu');
      
      if(obj.data.message==undefined){
      
       $.each(obj.data.adiortak, function(index, satir){
       
       
       	$("#myTable17 tr:last").after( "<tr><td>" + satir.ortvergino  + "</td><td>" + satir.adsoyad + "</td><td>" + satir.orthisse + "</td><td>" + tarihFormat(satir.ortgiristar)  + "</td><td>" + tarihFormat(satir.ortcikistar)  + "</td></tr>");


          });
          
       }

}


function adiOrtaklikSorguluGet(vkn){



      var tokenlink =GetUrlValue('token');
		var callid=makeid(13) + '-';
      //
      var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_adiOrtakliginOrtaklikBilgileriServisiCagir&callid=';
      var url=url.concat(callid + '180', '&token=', tokenlink, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%7D');
      var url= getRemote(url);
      var obj =tkParse(url,'adiOrtaklikSorguluGet');
      
      if(obj.data.message==undefined){
      
       $.each(obj.data.adiortak, function(index, satir){
       
       
       	$("#myTable17 tr:last").after( "<tr><td>" + satir.ortvergino  + "</td><td>" + satir.adsoyad + "</td><td>" + satir.orthisse + "</td><td>" + tarihFormat(satir.ortgiristar)  + "</td><td>" + tarihFormat(satir.ortcikistar)  + "</td></tr>");


          });
          
       }

}

function mukellefinadiOrtaklikSorgulu(vkn,token){

	try{
      var callid=makeid(13) + '-';

      var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukunAdiOrtaklikBilgileriniGetir&callid=';
      var url=url.concat(callid + '215', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22basTar%22%3A%22%22%2C%22bitTar%22%3A%22%22%7D');
      var url= getRemote(url);
      var obj =JSON.parse(url);
      
      $('#tablo16').after('<table id="myTable17" border=1><caption>Adi Ortaklık Bilgileri</caption><tr><th>Adi Ortaklık VERGİ NO</th><th>Adi Ortaklık Ünvan</th><th>HİSSE</th><th>GİRİŞ TARİHİ</th><th>ÇIKIŞ TARİHİ</th></tr></table></tr>');

     if (obj.data.ortakliklar.adiortak.length>0){
    
      
      	 $.each(obj.data.ortakliklar.adiortak, function(index, satir){
           
         	$("#myTable17 tr:last").after( "<tr><td>" + satir.vergino  + "</td><td>" + satir.unvan + "</td><td>" + satir.orthisse + "</td><td>" + tarihFormat(satir.ortgiristar)  + "</td><td>" + tarihFormat(satir.ortcikistar)  + "</td></tr>");


          });  
     
     }else{

        	$("#myTable17 tr:last").after( "<tr><td></td><td></td><td></td><td></td><td></td></tr>");
}
     
     }

	catch(err){

			$("#myTable17 tr:last").after( "<tr><td colspan='5'>Hata ile karşılaşıldı" + err + "</td></tr>");

	}
          
      

}

function sahisOrtaklikGetir(vkn,token){

 $('#tablo7').after('<table id="myTable7" border=1> <caption>1. Seviye Tüzel Ortaklık Bilgileri</caption><tr><th>VERGİ NO</th><th>UNVAN</th><th>HİSSE</th><th>İLİŞKİ TÜRÜ</th><th>GİRİŞ TARİHİ</th><th>ÇIKIŞ TARİHİ</th></tr></table>');
 
 
	
      var callid=makeid(13) + '-';
      var bastar="19800101";                        
      var bittar= bugunTarih();
      

    var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukOrtYonTarihSorgulama&callid=';   
	var url1=url1.concat(callid + '62', '&token=', token, '&jp=%7B%22vkn%22%3A%22', vkn, '%22%2C%22tckn%22%3A%22%22%2C%22basTar%22%3A%22%',bastar,'%22%2C%22bitTar%22%3A%22',bittar,'%22%7D');
	var liste1 = getRemote(url1);
	var obj1 =tkParse(liste1,'sahisOrtaklikGetir');
	
	$.each(obj1.data.tuzelortak, function(index, satir){ 
	      
	  var  terk_tarih='';
	  var  terk_durum='';
	  var vn=satir.vergino;
	  var unvan=satir.unvan;
	  var hisse=satir.orthisse;
	  var giristar=satir.ortgiristar;
	  var cikistar=satir.ortcikistar;
	  var iliski_tur='Ortaklık';
		   
	$("#myTable7 tr:last").after( "<tr><td>" + vn  + "</td><td>" + unvan + "</td><td> " + hisse + " </td><td>" + iliski_tur + "</td><td>" + giristar  + "</td><td>" + cikistar + "</td></tr>"); 
		     
		
	  });
	  
	    var iliski_tur_dizi={'3':'3 - Genel Müdür; Şirket Müdürü','2':'2 - Yönetim Kurulu Üyesi'};
	    
	    
	   $.each(obj1.data.tuzelyonetici, function(index, satir){ 
	  	    
	  var vn=satir.vergino;
	  var unvan=satir.unvan;
	  var hisse='';
	  var giristar=satir.yongiristar;
	  var cikistar=satir.yoncikistar;
	  var iliski_tur=iliski_tur_dizi[satir.yonturu];
	  var giristar_yil=giristar.substring(0,4)
	  var cikistar_yil=cikistar.substring(0,4)
	
			  
		$("#myTable7 tr:last").after( "<tr><td>" + vn  + "</td><td>" + unvan + "</td><td> " + hisse + " </td><td>" + iliski_tur + "</td><td>" + giristar  + "</td><td>" + cikistar + "</td></tr>");
	    
	      
	  });



}



function borcMahsupDurumu (vkno,vdKodu) {
var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var toplam_mahsup_talebi=0;
    var url_mahsup= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupOlanVDlerSorgula&callid=';
	var url_mahsup=url_mahsup.concat(callid + '117', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
	var mahsup = getRemote(url_mahsup);
	var obj_mahsup =tkParse(mahsup,'borcMahsupDurumu');
	
	var mahsupVd=obj_mahsup.data.vdler;
	
	if (mahsupVd==''){return 'Mahsup Talebi Yok';}else {
	
	//mahsup talebi var ise
	
	
	    var url_mahsup_detay= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_mahsupDetaySorgulama&callid=';
	    var url_mahsup_detay=url_mahsup_detay.concat(callid + '226', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vdKodu%22%3A%22',vdKodu,'%22%2C%22iadeVergiKodu%22%3A%22%22%2C%22mahsupVergiKodu%22%3A%22%22%2C%22iadeBasTar%22%3A%22%22%2C%22iadeBitTar%22%3A%22%22%2C%22mahsupBasTar%22%3A%22%22%2C%22mahsupBitTar%22%3A%22%22%2C%22unvan%22%3A%22%22%7D');
	    var mahsup_detay = getRemote(url_mahsup_detay);
	    var obj_mahsup_detay =tkParse(mahsup_detay,'borcMahsupDurumu');
	    var hataVarmi =obj_mahsup_detay.messages;
	    
	    
	      if (hataVarmi==undefined){
	      
		  var mahsupDetayListe=obj_mahsup_detay.data.iadeMahsupBlg;
		  
		  $.each(mahsupDetayListe,function(index,satir1){
	
		  
		    if (satir1.durum=="Aktif"){   
		
			
			toplam_mahsup_talebi=toplam_mahsup_talebi + parseInt(satir1.tutar); 
			
			
			}
		    
		  });
		
		  
		
		  if (toplam_mahsup_talebi==0) {
		  

		  return 'Mahsup Talebi Var Ancak Aktif Toplam Tutarı 0 TL' ;
		  
		  
		  
		  }else{
		  
		  
		  return 'Aktif  İadeleri var-Kontrol edilmesi gerekiyor :<br>' + Number(toplam_mahsup_talebi).toLocaleString("tr-TR");
		  
		  		  
		  		  
		  //return  "<a href='../diger/aktif-iade.html?token=" + token() + "&vkn=" + vkno +  "' target='_blank'>Mahsup Talebi Var Aktif Toplam Tutar :" +  toplam_mahsup_talebi +  " Göster</a>";
		  
		 
		  
		  }
		
		
	    }else {
	    
	     return obj_mahsup_detay.messages[0].text;
	    
	    
	    } 
	
	}
}


function borcMahsupDurumuKalanTutar (vkno,vdKodu) {


try{
	var myRegex= /[0-9]+/;
	
	
	
	var callid=makeid(13) + '-';
	var toplamemanetkalantutar=0;
   var iadeDosyaNoDizi=new Array();
   
	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_mahsupDetaySorgulama&callid='; 
	var url5=url5.concat(callid + '165', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vdKodu%22%3A%22',vdKodu,'%22%2C%22iadeVergiKodu%22%3A%22%22%2C%22mahsupVergiKodu%22%3A%22%22%2C%22iadeBasTar%22%3A%22%22%2C%22iadeBitTar%22%3A%22%22%2C%22mahsupBasTar%22%3A%22%22%2C%22mahsupBitTar%22%3A%22%22%2C%22unvan%22%3A%22%22%7D');
	var liste = getRemote(url5);
	var obj =JSON.parse(liste);
	
	if (obj.error!="1"){	
		
			$.each( obj.data.iadeMahsupBlg, function(index, satir){
					
					var iadeDosyaNoVarmi=iadeDosyaNoDizi.includes(satir.iadedosyano );
										
						if (satir.durum=="Aktif" && iadeDosyaNoVarmi==false ) {
						
							var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulamaDetay&callid='; 
							var url6=url6.concat(callid + '171', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vdKodu%22%3A%22',vdKodu,'%22%2C%22iadeDosyaNo%22%3A%22',satir.iadedosyano,'%22%2C%22dilekceTipi%22%3A%22',satir.dTipi,'%22%2C%22donem%22%3A%22',satir.vergidonem,'%22%2C%22vKodu%22%3A%22',satir.vergikodu,'%22%2C%22iadeSatir%22%3A%22%22%7D');
							var liste1 = getRemote(url6);
							var obj1 =JSON.parse(liste1);
							
							
							toplamemanetkalantutar+=Number(obj1.data.genelbilgiler[0].emanetkalantutar);
										
						}
							
					iadeDosyaNoDizi.push(satir.iadedosyano);
		   
		   
		   });
 }else{
	   
	   	return obj.messages[0].text;
   }

   
   return Number(toplamemanetkalantutar).toLocaleString("tr-TR") ;
   
   }
   
   
   catch{
   
   
   return "Hata ile Karşılaşıldı";
   }
   
}


function borcMahsupDurumuilgiliDaire (vkno,vergiDairesi) { //Kendi Borclarına mahsup ekranından sorguluyor



try{
		var myRegex= /[0-9]+/;
		
		
		
		var callid=makeid(13) + '-';
		var toplamemanetkalantutar=0;
	    var ilgiliVergiDairesi=vdKodu();
	    var iadeMahsupAktifSorgulama=0;
	   
		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_mahsupDetaySorgulama&callid='; 
		var url5=url5.concat(callid + '165', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vdKodu%22%3A%22',vergiDairesi,'%22%2C%22iadeVergiKodu%22%3A%22%22%2C%22mahsupVergiKodu%22%3A%22%22%2C%22iadeBasTar%22%3A%22%22%2C%22iadeBitTar%22%3A%22%22%2C%22mahsupBasTar%22%3A%22%22%2C%22mahsupBitTar%22%3A%22%22%2C%22unvan%22%3A%22%22%7D');
		var liste = getRemote(url5);
		var obj =JSON.parse(liste);
		
		if (obj.error!="1"){	
				
					$.each( obj.data.iadeMahsupBlg, function(index, satir){
																
								if (satir.durum=="Aktif" && satir.vDairesi.includes(ilgiliVergiDairesi)==true ) { toplamemanetkalantutar+=Number(satir.tutar); 	}
											
				   });   	
			   	
		   }

	   
	   return Number(toplamemanetkalantutar).toLocaleString("tr-TR") ;
   
   }
   
   
   catch{
      
   		return "Hata ile Karşılaşıldı";
   
   }
   
}



function iadeMahsupSorgulamailgiliDaire(vkno,vergiDairesi) { // İade Mahsup ekranından Sorguluyor



		var myRegex= /[0-9]+/;
		
		
		
		var callid=makeid(13) + '-';
		var toplamTutar=0;
	      
	  	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulama&callid='; 
		var url5=url5.concat(callid + '94', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vdKodu%22%3A%22',vergiDairesi,'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
		var liste = getRemote(url5);
		var obj =tkParse(liste,'iadeMahsupSorgulamailgiliDaire');
		
	
		if (obj.error!="1"){	
				
					$.each( obj.data.iadeMahsupKlm, function(index, satir){
																
								if (satir.durum=="1-1") { toplamTutar+=Number(satir.iadeDosyaTutar); 	}
											
				   });
				   
			   return Number(toplamTutar).toLocaleString("tr-TR") ;
			   
			   
		 }else{
			   
			   	return obj.messages[0].text;
		   }

   
   
   
}

function iadeMahsupSorgulamailgiliDaire1(vkno,vergiDairesi) { // İade Mahsup ekranından Sorguluyor

		var myRegex= /[0-9]+/;
		
		
		
		var callid=makeid(13) + '-';
		var AktiftoplamKalanTutar=0;
		var hata1=true;

		var hata1_deneme=0;   /* v517-fix: sonsuz döngü koruması */
		while(hata1){
			if(++hata1_deneme>3){ hata1=false; throw new Error("iadeMahsupSorgulamailgiliDaire1: servis 3 denemede de hata döndürdü (token süresi dolmuş olabilir)"); }
		
		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulama&callid='; 
		var url5=url5.concat(callid + '165', '&token=', token() , '&&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vdKodu%22%3A%22',vergiDairesi,'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
		var liste = getRemote(url5);
		var obj =tkParse(liste,'iadeMahsupSorgulamailgiliDaire1');	
		

			if (obj.error==undefined){	

				hata1=false;

				$.each( obj.data.iadeMahsupKlm, function(index, satir){
			
					if (satir.durum=="1-1" ) {

					var hata2=true;	

							var hata2_deneme=0;   /* v517-fix: sonsuz döngü koruması */
							while(hata2){
								if(++hata2_deneme>3){ hata2=false; throw new Error("iadeMahsupSorgulamailgiliDaire1: servis 3 denemede de hata döndürdü (token süresi dolmuş olabilir)"); }

								var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulamaDetay&callid='; 
								var url6=url6.concat(callid + '165', '&token=', token() , '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22vdKodu%22%3A%22',vergiDairesi,'%22%2C%22iadeDosyaNo%22%3A%22',satir.iadeDosyaNo,'%22%2C%22dilekceTipi%22%3A%22%22%2C%22donem%22%3A%22%22%2C%22vKodu%22%3A%22%22%2C%22iadeSatir%22%3A%22%22%7D');
								var liste1 = getRemote(url6);
								var obj1 =tkParse(liste1,'iadeMahsupSorgulamailgiliDaire1');
								

								if (obj1.error==undefined){	

									hata2=false;
				
									AktiftoplamKalanTutar=AktiftoplamKalanTutar + parseFloat(obj1.data.genelbilgiler[0].emanetkalantutar);
				
								}else{

									console.log("Hata ile Karşılaşıldı Tekrar Deneyeceğim " +  vkno + "-" + vergiDairesi + "-" + satir.iadeDosyaNo  );		
				
								}
								
							  }		

							}
											
					});

			}else{

				console.log("Hata ile Karşılaşıldı Tekrar Deneyeceğim " +  vkno + "-" + vergiDairesi );		

			}

	}
	
			return Number(AktiftoplamKalanTutar).toFixed(2);
			

}


function iadeMahsupSorgulamailgiliDaire2(vkn,ilgiliDaire) { // İade Mahsup ekranından Sorguluyor -- Tüm daireleri de sorguluyor ilgili vd, ihtisas ve tümüne ilişkin bilgileri alabiliyoruz.

		
		var callid=makeid(13) + '-';

		var AktiftoplamKalanTutar=0;

		var ilgiliDaireKalanTutar=0;

		var ihtisasKalanTutar=0;

		var hata1=true;
		var hataSayisi1=0;
		var hataSayisi2=0;

		var vd_listesi=iadeMahsupHangiVD(vkn);

		if (vd_listesi!="Hata"){

		if (vd_listesi.length>0){

		var hata1_deneme=0;   /* v517-fix: sonsuz döngü koruması */
		while(hata1){
			if(++hata1_deneme>3){ hata1=false; throw new Error("iadeMahsupSorgulamailgiliDaire2: servis 3 denemede de hata döndürdü (token süresi dolmuş olabilir)"); }
		
			$.each(vd_listesi, function(index, vd){
			
				var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulama&callid='; 
				var url5=url5.concat(callid + '165', '&token=', token() , '&&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
				var liste = getRemote(url5);
				var obj =tkParse(liste,'iadeMahsupSorgulamailgiliDaire2');	
				

					if (obj.error==undefined){	

						hata1=false;

						$.each( obj.data.iadeMahsupKlm, function(index, satir){
					
							if (satir.durum=="1-1" ) {

							var hata2=true;	

									var hata2_deneme=0;   /* v517-fix: sonsuz döngü koruması */
									while(hata2){
										if(++hata2_deneme>3){ hata2=false; throw new Error("iadeMahsupSorgulamailgiliDaire2: servis 3 denemede de hata döndürdü (token süresi dolmuş olabilir)"); }

										var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulamaDetay&callid='; 
										var url6=url6.concat(callid + '165', '&token=', token() , '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22iadeDosyaNo%22%3A%22',satir.iadeDosyaNo,'%22%2C%22dilekceTipi%22%3A%22%22%2C%22donem%22%3A%22%22%2C%22vKodu%22%3A%22%22%2C%22iadeSatir%22%3A%22%22%7D');
										var liste1 = getRemote(url6);
										var obj1 =tkParse(liste1,'iadeMahsupSorgulamailgiliDaire2');
										

										if (obj1.error==undefined){	

											hata2=false;

											if (vd==ilgiliDaire) {	ilgiliDaireKalanTutar=ilgiliDaireKalanTutar + parseFloat(obj1.data.genelbilgiler[0].emanetkalantutar);}

											if (vd=="016250") {	ihtisasKalanTutar=ihtisasKalanTutar + parseFloat(obj1.data.genelbilgiler[0].emanetkalantutar);}
						
											AktiftoplamKalanTutar=AktiftoplamKalanTutar + parseFloat(obj1.data.genelbilgiler[0].emanetkalantutar);
						
										}else{

											hataSayisi2++;

											
										if (hataSayisi2<=2){
					
											console.log("iadeMahsupService_iadeMahsupSorgulamaDetay - Hata ile Karşılaşıldı Tekrar Deneyeceğim " +  vkn + "-" + vd + "-" + satir.iadeDosyaNo  );		
								
										}else{

 											console.log("iadeMahsupService_iadeMahsupSorgulamaDetay - Çok fazla Hata ile Karşılaşıldı Sonrakine geçiyorum " +  vkn + "-" + vd + "-" + satir.iadeDosyaNo  );		

											hata2=false;

										}

										
						
										}
										
									  }		

									}
													
							});

					}else{

						hataSayisi1++;

						if (hataSayisi1<=2){
	
						console.log("iadeMahsupService_iadeMahsupSorgulama - Hata ile Karşılaşıldı Tekrar Deneyeceğim " +  vkn + "-" + vd );		
				
						}else{

						console.log("iadeMahsupService_iadeMahsupSorgulama-Çok fazla Hata ile Karşılaşıldı Sonraki mükellefe geçiyorum " +  vkn + "-" + vd );		
			
						hata1=false;

						}

					}

			});
	}
	
			return (AktiftoplamKalanTutar + "-" + ilgiliDaireKalanTutar + "-" + ihtisasKalanTutar );
			
	}else{


	return "0-0-0";

	}

}else{

	return "Hata-Hata-Hata";	


	}

}


function iadeMahsupSorgulamailgiliDaire3(vkn,ilgiliDaire) { // İade Mahsup ekranından Sorguluyor

		var myRegex= /[0-9]+/;
		
		
		
		var callid=makeid(13) + '-';

		var AktiftoplamKalanTutar=0;

		var ilgiliDaireKalanTutar=0;

		var ihtisasKalanTutar=0;

		var hata1=true;
		var hataSayisi1=0;
		var hataSayisi2=0;

		var hata1_deneme=0;   /* v517-fix: sonsuz döngü koruması */
		while(hata1){
			if(++hata1_deneme>3){ hata1=false; throw new Error("iadeMahsupSorgulamailgiliDaire3: servis 3 denemede de hata döndürdü (token süresi dolmuş olabilir)"); }
		
				var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulama&callid='; 
				var url5=url5.concat(callid + '165', '&token=', token() , '&&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',ilgiliDaire,'%22%2C%22vergiKodu%22%3A%22%22%2C%22donemBasAy%22%3A%22%22%2C%22donemBitYil%22%3A%22%22%2C%22donemBasYil%22%3A%22%22%2C%22donemBitAy%22%3A%22%22%7D');
				var liste = getRemote(url5);
				var obj =tkParse(liste,'iadeMahsupSorgulamailgiliDaire3');	
				

					if (obj.error==undefined){	

						hata1=false;

						$.each( obj.data.iadeMahsupKlm, function(index, satir){
					
							if (satir.durum=="1-1" ) {

							var hata2=true;	

									var hata2_deneme=0;   /* v517-fix: sonsuz döngü koruması */
									while(hata2){
										if(++hata2_deneme>3){ hata2=false; throw new Error("iadeMahsupSorgulamailgiliDaire3: servis 3 denemede de hata döndürdü (token süresi dolmuş olabilir)"); }

										var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulamaDetay&callid='; 
										var url6=url6.concat(callid + '165', '&token=', token() , '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22iadeDosyaNo%22%3A%22',satir.iadeDosyaNo,'%22%2C%22dilekceTipi%22%3A%22%22%2C%22donem%22%3A%22%22%2C%22vKodu%22%3A%22%22%2C%22iadeSatir%22%3A%22%22%7D');
										var liste1 = getRemote(url6);
										var obj1 =tkParse(liste1,'iadeMahsupSorgulamailgiliDaire3');
										

										if (obj1.error==undefined){	

											hata2=false;

											ilgiliDaireKalanTutar=ilgiliDaireKalanTutar + parseFloat(obj1.data.genelbilgiler[0].emanetkalantutar);
											
						
										}else{

											hataSayisi2++;

											
										if (hataSayisi2<=2){
					
											console.log("iadeMahsupService_iadeMahsupSorgulamaDetay - Hata ile Karşılaşıldı Tekrar Deneyeceğim " +  vkn + "-" + vd + "-" + satir.iadeDosyaNo  );		
								
										}else{

 											console.log("iadeMahsupService_iadeMahsupSorgulamaDetay - Çok fazla Hata ile Karşılaşıldı Sonrakine geçiyorum " +  vkn + "-" + vd + "-" + satir.iadeDosyaNo  );		

											hata2=false;

										}

										
						
										}
										
									  }		

									}
													
							});

					}else{

						hataSayisi1++;

						if (hataSayisi1<=2){
	
						console.log("iadeMahsupService_iadeMahsupSorgulama - Hata ile Karşılaşıldı Tekrar Deneyeceğim " +  vkn + "-" + vd );		
				
						}else{

						console.log("iadeMahsupService_iadeMahsupSorgulama-Çok fazla Hata ile Karşılaşıldı Sonraki mükellefe geçiyorum " +  vkn + "-" + vd );		
			
						hata1=false;

						}

					}

		
	}
	
			return (AktiftoplamKalanTutar + "-" + ilgiliDaireKalanTutar + "-" + ihtisasKalanTutar );
			
	}





function ikincilSorumluluk(vkn,token){


var callid=makeid(13) + '-';



 var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=isEmriBorcSorgulamaService_ikincilSorumluklukBilgiBul&callid=';
	var url=url.concat(callid + '131', '&token=', token, '&jp=%7B%22orgoid%22%3A%22',vdOrgId(),'%22%2C%22vergiNo%22%3A%22',vkn,'%22%2C%22tcKimlikNo%22%3A%22%22%2C%22baslangicVadeTarihi%22%3A%2200000000%22%2C%22bitisVadeTarihi%22%3A%2299999999%22%2C%22talepNedeni%22%3A%223%22%7D');
	var ikincil = getRemote(url);
	var obj =tkParse(ikincil,'ikincilSorumluluk');
	
	
	 if (obj.data.length>0){
      
      return "<td style='background:red; color:white'><a href='../diger/ikincil-sorumluluk.html?token=" + token() + "&vkn=" + vkn +  "' target='_blank'>Var</a></td>";
      
      }else{
      
      return "<td>Yok</td>";
      
      }

}


function ikincilSorumlulukTutar(vkn,token){
	
	try{

		var callid=makeid(13) + '-';


		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=isEmriBorcSorgulamaService_ikincilSorumluklukBilgiBul&callid=';
		var url=url.concat(callid + '131', '&token=', token, '&jp=%7B%22orgoid%22%3A%22',vdOrgId(),'%22%2C%22vergiNo%22%3A%22',vkn,'%22%2C%22tcKimlikNo%22%3A%22%22%2C%22baslangicVadeTarihi%22%3A%2200000000%22%2C%22bitisVadeTarihi%22%3A%2299999999%22%2C%22talepNedeni%22%3A%223%22%7D');
		var ikincil = getRemote(url);
		var obj =JSON.parse(ikincil);
		var takipTutar=0

	if(obj.data.length>0){
			$.each(obj.data,function(index,satir){

				takipTutar = takipTutar + parseFloat(satir.tkpMiktari);

			});

		return tlCevir(takipTutar);

		}else{

			return "0";

		}

	}

	catch(err){

		return "";

		}

}

function ehacizBanka(vkn,tabloID='22',vd) {

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var hacizTarihi=prompt("Haciz Bildirisi İçin Başlangıç Dönemi  Giriniz Örnek 202501");
var hacizTarihi1=prompt("Haciz Bildirisi İçin Bitiş Dönemi  Giriniz Örnek 202501");




 var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=ehacizListeService_mukellefBazindaEhacizSorgula&callid=';
	var url=url.concat(callid + '24', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22baslangicDonem%22%3A%22',hacizTarihi,'%22%2C%22bitisDonem%22%3A%22',hacizTarihi1,'%22%7D');
	var ehaciz = getRemote(url);
	var obj =tkParse(ehaciz,'ehacizBanka');
	
	$('#tablo'+ tabloID).after('<table id="myTable700" border=1> <caption>MHK / Ehaciz Banka Bilgileri</caption><tr><th>VERGİ DAİRESİ</th><th>HACİZ NO</th><th>DURUM</th><th>TARİH</th></tr></table>');
 

	 $.each(obj.data.liste,function(index,satir){

		if (satir.vdkodu==vd){
		 
			 $("#myTable700 tr:last").after( "<tr><td>" + vdAdi(satir.vdkodu) + "</td><td>" + satir.hbno + "</td><td> " + satir.durum + " </td><td>" + satir.tarih + "</td></tr>");
	   
		 }
	 });


}


function ehacizBanka1(vkn,tabloID='22',token) {


var callid=makeid(13) + '-';

/*var hacizTarihi=prompt("Haciz Bildirisi İçin Başlangıç Dönemi  Giriniz Örnek 202501");
var hacizTarihi1=prompt("Haciz Bildirisi İçin Bitiş Dönemi  Giriniz Örnek 202501");*/


var hacizTarihi="";
var hacizTarihi1="";

 var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=ehacizListeService_mukellefBazindaEhacizSorgula&callid=';
	var url=url.concat(callid + '24', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22baslangicDonem%22%3A%22',hacizTarihi,'%22%2C%22bitisDonem%22%3A%22',hacizTarihi1,'%22%7D');
	var ehaciz = getRemote(url);
	var obj =tkParse(ehaciz,'ehacizBanka1');
	
	$('#tablo'+ tabloID).after('<table id="myTable700" border=1> <caption>MHK / Ehaciz Banka Bilgileri</caption><tr><th>VERGİ DAİRESİ</th><th>HACİZ NO</th><th>DURUM</th><th>TARİH</th></tr></table>');
 

	 $.each(obj.data.liste,function(index,satir){
		
		 
			 $("#myTable700 tr:last").after( "<tr><td>" + vdAdi(satir.vdkodu) + "</td><td>" + satir.hbno + "</td><td> " + satir.durum + " </td><td>" + satir.tarih + "</td></tr>");
	   

	 });


}


function ehacizBankaVarmi(vkn,yil,vd) { // Hem Aktif hemde Müdürlüğümüz E Haciz işlemi olup olmadığı

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var aktif=0;
var hacizBildirisiYil="";
var pasif=0;

//

 var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=ehacizListeService_mukellefBazindaEhacizSorgula&callid=';
 var url=url.concat(callid + '46', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22baslangicDonem%22%3A%22',yil,'01%22%2C%22bitisDonem%22%3A%22',yil,'12%22%7D');
 var ehaciz = getRemote(url);
 var obj =tkParse(ehaciz,'ehacizBankaVarmi');
	

	 $.each(obj.data.liste,function(index,satir){

	 hacizBildirisiYil = (satir.hbno).substr(0,4);
	 
	if (satir.durum=="AKTİF" && satir.vdkodu==vd && hacizBildirisiYil==yil ) { aktif = aktif + 1;} 
	if (satir.durum=="PASİF" && satir.vdkodu==vd && hacizBildirisiYil==yil ) { pasif = pasif + 1;} 
   
	 
	 });

	 if ( aktif==0 && pasif==0 ){
	 
	 
      return "<td>Yok</td>";
      
      }else{
      
      
      return "<td><a target='_blank' href='../diger/e-haciz-liste.html?vkn=" + vkn + "&token=" + token() + "'>" + "Aktif:" +  aktif  + "-Pasif:" +  pasif  + "</a></td>";
      }
      
      
	

}

function tasitHaciz(vkn,vd){


var callid=makeid(13) + '-';
var AktifkayitSayisi=0;
var yakalama=0;
var satis_arz=0;
var satis_kesin=0;
var donem1=""; //cariYil() + "01";
var donem2=""; //cariYil() + "12";
var bugun_yil=bugunYil();

var hata=true;
var hacizSonTarih="";
var deneme=0;
var plakaListe=new Array();
var plakaAktif=new Array();
var plakaDurum=new Array();
var plakaSonTarih=new Array();
var sonDurumTarih=new Array();
	

	 var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=ehacizListeService_egmTakyidatEklenenlerListesi&callid=';
	 var url=url.concat(callid + '214', '&token=', token(), '&jp=%7B%22vdkodu%22%3A%22',vd,'%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22tip%22%3A%221%22%2C%22baslangicDonem%22%3A%22',donem1,'%22%2C%22bitisDonem%22%3A%22',donem2,'%22%7D');
	 var haciz = getRemote(url);
	 var obj =tkParse(haciz,'tasitHaciz');

	if (obj.error==undefined){	

	

	 var kayitSayisi=(obj.data.hacizlist.length);

			if (kayitSayisi>0){

				//hacizSonTarih=obj.data.hacizlist[kayitSayisi-1].sonDurumTarih;

				$.each(obj.data.hacizlist,function(index,satir){
			
					if (satir.hbno!=undefined){

						sonDurumTarih.push(satir.eklemetarihi);
				
						if (plakaListe.includes(satir.plaka)){
							
							if (plakaSonTarih[satir.plaka]<satir.eklemetarihi) {
								
								if ( (satir.takyidatturu==35 || satir.takyidatturu==50) && satir.takyidatdurum=="PASİF" ){ //yakalama veya satışa arz pasif ise dikkate almıyoruz


								}else{
									plakaAktif[satir.plaka]=satir.takyidatdurum;								

									plakaDurum[satir.plaka]=satir.takyidatturu;

									plakaSonTarih[satir.plaka]=satir.eklemetarihi;

								}

							}
							
						}else{
							
							plakaListe.push(satir.plaka);
			
							plakaAktif[satir.plaka]=satir.takyidatdurum;		
							
							plakaDurum[satir.plaka]=satir.takyidatturu;
						
							plakaSonTarih[satir.plaka]=satir.eklemetarihi;
						}
		
					}
				});	
				

				sonDurumTarih.sort();	
			
				hacizSonTarih=sonDurumTarih[sonDurumTarih.length-1];
				
				
			}

			$.each(plakaListe,function(index,plaka){
				
						if (plakaAktif[plaka]=="AKTİF" && plakaDurum[plaka]=="3") {AktifkayitSayisi++;} //aktif hacizli araç sayısını gösteriyor
					
						if (plakaAktif[plaka]=="AKTİF" && plakaDurum[plaka]=="35") {yakalama++;} //mevcut yapılan yakalama
						
						if (plakaAktif[plaka]=="AKTİF" && plakaDurum[plaka]=="50") {satis_arz++;}  //cari yılda yapılan satış arz
						
						if ((plakaSonTarih[plaka]).substr(0,4)==bugun_yil && plakaDurum[plaka]=="49") {satis_kesin++;}  //cari yılda yapılan kesin satış	
						

				
				});	
			
			
			return AktifkayitSayisi + "-" + hacizSonTarih + "-" + yakalama + '-' + satis_arz + '-' + satis_kesin ;


	}else{
			console.log("Hata aldığımız için geçiyoruz " +  vkn + "-" + vd + "-" + err );	
			
			return "Hata-Hata-Hata-Hata-Hata" ;	


				}



}


function ehacizBankaVarmi1(vkn,yil,vd) { // Hem Aktif hemde Müdürlüğümüz E Haciz işlemi olup olmadığı

try{

var callid=makeid(13) + '-';
var tarihDizi=new Array();

 var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=ehacizListeService_mukellefBazindaEhacizSorgula&callid=';
 var url=url.concat(callid + '46', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22baslangicDonem%22%3A%22',yil,'01%22%2C%22bitisDonem%22%3A%22',yil,'12%22%7D');
 var ehaciz = getRemote(url);
 var obj =JSON.parse(ehaciz);
	
var kayitSayisi=obj.data.liste.length;
var ilgiliDaireKayitSayisi=0;

	if (kayitSayisi>0){

		 $.each(obj.data.liste,function(index,satir){

			if (satir.vdkodu==vd){

				var hacizTarihi=(satir.hbno).substr(0,8);

				tarihDizi.push(hacizTarihi);

				ilgiliDaireKayitSayisi++;

			}
				
		
		});

  		var yeniDizi = tarihDizi.sort();

		return ilgiliDaireKayitSayisi + "-" + yeniDizi[yeniDizi.length-1];

	}else{

		return "0" + "";

	}


}

catch(err){

	console.log(err);

	return "Hata-Hata ";

}


	

}

function plakaBazindaMahrumiyet(plaka,tokenA){

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var cekirgVdMahrumiyetSayisi=0;

//
if (plaka!=undefined){
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=ehacizListeService_plakaBazindaMahrumiyetSorgula&callid=';
	var url=url.concat(callid + '66', '&token=', token(), '&jp=%7B%22plaka%22%3A%22',plaka,'%22%7D');
	var malvarligi = getRemote(url);
	var obj =tkParse(malvarligi,'plakaBazindaMahrumiyet');

		if (obj.error==undefined) {


			var kayit_sayisi= obj.data.takyidat.length;
	
			
				
			if (kayit_sayisi>0) {


				 $.each(obj.data.takyidat,function(index,satir){


					if (satir.birimAd=="016253 ÇEKİRGE Vergi Dairesi") {cekirgVdMahrumiyetSayisi=cekirgVdMahrumiyetSayisi+1;}


				});



				return "<a target='_blank' href='diger/mahrumiyet.html?plaka=" + plaka + "&token=" + tokenA + "'>" + "VAR - " + cekirgVdMahrumiyetSayisi + "</a>";
				
				}else{

				return "YOK";
		
			}
		
		}else{
		
		return obj.messages[0].text;
		
		}
		
 }
	

}


function plakaBazindaMahrumiyetIlkSira(plaka,tokenA){

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';


//
if (plaka!=undefined){
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=ehacizListeService_plakaBazindaMahrumiyetSorgula&callid=';
	var url=url.concat(callid + '66', '&token=', token(), '&jp=%7B%22plaka%22%3A%22',plaka,'%22%7D');
	var malvarligi = getRemote(url);
	var obj =tkParse(malvarligi,'plakaBazindaMahrumiyetIlkSira');

		if (obj.error==undefined) {


			var kayit_sayisi= obj.data.takyidat.length;
	
			
				
			if (kayit_sayisi>0) {

				return  obj.data.takyidat[0].birimAd ;
			
				
				}else{

				return "YOK";
		
			}
		
		}else{
		
		return obj.messages[0].text;
		
		}
		
 }
	

}

function plakaBazindaMahrumiyet1(plaka,tokenA){

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';


 
return "<a target='_blank' href='../diger/mahrumiyet.html?plaka=" + plaka + "&token=" + token() + "'>" + "Göster " +  "</a>";
								
		
	

}



function odeme_emri(vkn,token,oid,i){

 
  var callid=makeid(13) + '-';
  
  var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkEtebligatService_zarfDetayGetir&callid=';
  var url=url.concat(callid + '14', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22zarfOid%22%3A%22',oid,'%22%7D%7D');
  var remote = getRemote(url);
  var obj =tkParse(remote,'odeme_emri');
  var oid1=obj.data.result[0].oid;
 
  
return '<a href="http://10.251.63.99/gibintranet_server/downloadResource?token='+ token +'&cmd=downloadTebligat&dosyaismi=' + oid1 + '&uzanti=imz&oid=' +  oid1 +  '&islem=download&tur=teblig&belgeTuru=tebligat&" target="_blank" ><img id="disket' + i + '" src="disket.png" style="width:60px;height:42px;"> </a> ';
 

}

function plakaMukellef(plaka){
var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';

//
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=motorluTasitlarService_plakadanMukBilgiSorgu&callid=';
	var url=url.concat(callid + '60', '&token=', token(), '&jp=%7B%22plaka%22%3A%22',plaka,'%22%7D');
	var malvarligi = getRemote(url);
	var obj =tkParse(malvarligi,'plakaMukellef');
	var vkn=obj.data.kisiBilgileri[0].vergiKimlikNo;
	var unvan=obj.data.kisiBilgileri[0].unvani;
	
	return vkn + "/" + unvan;
	
	

}

function acikAdres(tckn){

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';

	  var url2= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mernisService_getAdresBilgileri&callid=';
      var url2=url2.concat(callid + '88', '&token=', token(), '&jp=%7B%22tckn%22%3A%22',tckn,'%22%7D');
      var adres = getRemote(url2);
      var obj =tkParse(adres,'acikAdres');  
      var hataVarmi=obj.error;
            
     if (hataVarmi==undefined || hataVarmi=="undefined" ){
     
      return obj.data.acikAdres; 
   
	}else{
	
	return "Hata ile karşılaşıldı";
	}
}



function tumMalKaydet(metinPDF){

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';

    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=malVarligiService_tumMalVarligiKaydet&callid=';
	var url=url.concat(callid + '88', '&token=', token(), '&jp=%7B%22tumMalVarPdfByteArray%22%3A%22',metinPDF,'%22%2C%22tckn%22%3A%22',tck,'%22%2C%22unvan%22%3A%22%22%7D');
	var malvarligi = getRemote(url);
	var obj =tkParse(malvarligi,'tumMalKaydet');


}

function tumMalVarligiSorgulama(vkn,tabloID='23',tck,token){


var callid=makeid(13) + '-';


//
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=malVarligiService_tumMalVarligiBilgileriSorgula&callid=';
	var url=url.concat(callid + '125', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22',tck,'%22%2C%22unvan%22%3A%22%22%7D');
	var malvarligi = getRemote(url);
	var obj =tkParse(malvarligi,'tumMalVarligiSorgulama');
	
	
 try{
	 if (obj.data.motorluTasit.tumMotorluTasitBilgileri.veriler.length>0) {
	 
	 	$('#tablo'+ tabloID).after('<table id="myTable701" border=1> <caption>Motorlu Taşıt Bilgisi</caption><tr><th>PLAKA</th><th>MARKA-MODEL</th><th>TİPİ</th><th>CİNSİ</th><th>Terk Türü</th><th>Mahrumiyet Varmı?</th></tr></table>');
	 	
		 $.each(obj.data.motorluTasit.tumMotorluTasitBilgileri.veriler,function(index,satir){
		 
		 $("#myTable701 tr:last").after( "<tr><td>" + satir.plaka + "</td><td>" + satir.marka + "-" + satir.model + " </td><td>" + satir.tip + "</td><td>" + satir.cinsad + "</td><td>"+satir.terk_turu+"</td><td>" + plakaBazindaMahrumiyet1(satir.plaka) + "</td></tr>");
		   
		 
		 });

	}
}

catch(err){
	
				 $("#myTable701 tr:last").after( "<tr><td>Motorlu Taşıtlarda Hata ile Karşılaşıldı</td><td></td><td></td><td></td><td></td><td></td></tr>");
		
	}


/////////////////////////////////////////////////İŞ MAKİNELERERİ SORGULAMA

try{	   
	   
	   if (obj.data.isMakinalari.isMakinalariBilgileri.vehicledetail.length>0) {
	   
	   $('#tablo'+ tabloID).after('<table id="myTable702" border=1> <caption>İş Makineleri Bilgisi</caption><tr><th>SASİ NO</th><th>MARKA-TİPİ</th><th>ODA ADI</th><th>MOTOR NO</th><th>PLAKA NO</th></tr></table>');
	   
			   $.each(obj.data.isMakinalari.isMakinalariBilgileri.vehicledetail,function(index,satir){
				 
				 $("#myTable702 tr:last").after( "<tr><td>" + satir.chassisnumber + "</td><td>" + satir.vehiclebrand + "-" + satir.vehicletype + " </td><td>" + satir.commerceoffice + "</td><td>" + satir.enginenumber + "</td><td>"+satir.platenumber+"</td></tr>");
				   
				 
				 });
			 
	 }
	 
}

catch(err){
	
				 $("#myTable702 tr:last").after( "<tr><td>İş Makineleri Hata ile Karşılaşıldı</td><td></td><td></td><td></td><td></td></tr>");
		
	}
	 
	 ////////////////////////////////////////////////TAPU

try{	   
	   if (obj.data.tapu.takbisBilgileri.summary.length>0) {
	   
	     $('#tablo'+ tabloID).after('<table id="myTable703" border=1> <caption>TAPU Bilgisi</caption><tr><th>Adres</th><th>BAĞIMSIZ</th><th>PAFTA</th><th>ADA</th><th>PARSEL</th><th>TAŞINMAZ TİPİ</th><th>NİTELİK</th></tr></table>');
	 
			   $.each(obj.data.tapu.takbisBilgileri.summary	,function(index,satir){
				 
				 $("#myTable703 tr:last").after( "<tr><td>" + satir.mahalle + "-" + satir.ilce + "-" + satir.il  + "</td><td>"+satir.bagimsizbolum+"</td><td>" + satir.pafta + "</td><td>" + satir.ada + "</td><td>" + satir.parsel + "</td><td>"+satir.bagimsizbolumtip+"</td><td>"+satir.nitelik+"</td></tr>");
				   
				 
				 });
			 
	 }
	 
}

catch(err){
	
								 $("#myTable703 tr:last").after( "<tr><td>Tapu Sorgularkan Hata ile Karşılaşıldı</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
		
	}

	 
	 ////////////////////////////////////////////////GEMİ/

try{	 
	  
	   if (obj.data.denizTasit.denizTasit.gemiBilgileri.hatakodu==undefined) {
	   
	     $('#tablo'+ tabloID).after('<table id="myTable704" border=1> <caption>GEMİ Bilgisi</caption><tr><th>Gemi Adı</th><th>Gemi Numarası</th><th>CİNSİ</th><th>Bağlama Limanı</th></tr></table>');
	  
			   $.each(obj.data.denizTasit.denizTasit.gemiBilgileri.data, function(index,satir){
				 
				 $("#myTable704 tr:last").after( "<tr><td>" + satir.gemiadi + "</td><td>" + satir.gemino + "</td><td>" + satir.gemicins + " </td><td>" + satir.bagliman + "</td></tr>");
				   
				 
				 });
			 
	 }	
	 
}
catch(err){
	
			 $("#myTable704 tr:last").after( "<tr><td>Gemi Sorgulamada Hata ile Karşılaşıldı</td><td></td><td></td><td></td></tr>");
		
	}
	  
	  ////////////////////////////////////////////////UÇAK/
	 
try{	   
	   if (obj.data.sivilHavacilik.sivilHavacilikBilgileri.length>0) {
	   
	     $('#tablo'+ tabloID).after('<table id="myTable705" border=1> <caption>Hava Taşıtları Bilgisi</caption><tr><th>Tescil Tarihi</th><th>Tipi</th><th>Sınıfı</th><th>Üretim Yılı</th><th>Hisse Oranı</th></tr></table>');
	 
			   $.each(obj.data.sivilHavacilik.sivilHavacilikBilgileri, function(index,satir){
				 
				 $("#myTable705 tr:last").after( "<tr><td>" + satir.tesciltarihi + "</td><td>" + satir.tipi + "</td><td>" + satir.sinif + "</td><td>" + satir.uretimyil + "</td><td>"+satir.hisseorani+"</td></tr>");
				   
				 
				 });
			 
	 }
	 
	}
	
	catch(err){
	
			$("#myTable705 tr:last").after( "<tr><td>Uçak Sorgularken Hata ile karşılaşıldı</td><td></td><td></td><td></td><td></td></tr>");
		
	}
	   
	 
	 
	 
}


function tumMalVarligiSorgulamaGet(vkn,tabloID='23',tck,token){


var callid=makeid(13) + '-';


//
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=malVarligiService_tumMalVarligiBilgileriSorgula&callid=';
	var url=url.concat(callid + '125', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22',tck,'%22%2C%22unvan%22%3A%22%22%7D');
	var malvarligi = getRemote(url);
	var obj =tkParse(malvarligi,'tumMalVarligiSorgulamaGet');
	
	
 
  try{
	 if (obj.data.motorluTasit.tumMotorluTasitBilgileri.veriler.length>0) {
	 
	 	$('#tablo'+ tabloID).after('<table id="myTable701" border=1> <caption>Motorlu Taşıt Bilgisi</caption><tr><th>PLAKA</th><th>MARKA-MODEL</th><th>TİPİ</th><th>CİNSİ</th><th>Terk Türü</th><th>Mahrumiyet Varmı?</th></tr></table>');
	 	
		 $.each(obj.data.motorluTasit.tumMotorluTasitBilgileri.veriler,function(index,satir){
		 
		 $("#myTable701 tr:last").after( "<tr><td>" + satir.plaka + "</td><td>" + satir.marka + "-" + satir.model + " </td><td>" + satir.tip + "</td><td>" + satir.cinsad + "</td><td>"+satir.terk_turu+"</td><td>" + plakaBazindaMahrumiyet1(satir.plaka) + "</td></tr>");
		   
		 
		 });

	}
}

catch(err){
	
				 $("#myTable701 tr:last").after( "<tr><td>Motorlu Taşıtlarda Hata ile Karşılaşıldı</td><td></td><td></td><td></td><td></td><td></td></tr>");
		
	}


/////////////////////////////////////////////////İŞ MAKİNELERERİ SORGULAMA

try{	   
	   
	   if (obj.data.isMakinalari.isMakinalariBilgileri.vehicledetail.length>0) {
	   
	   $('#tablo'+ tabloID).after('<table id="myTable702" border=1> <caption>İş Makineleri Bilgisi</caption><tr><th>SASİ NO</th><th>MARKA-TİPİ</th><th>ODA ADI</th><th>MOTOR NO</th><th>PLAKA NO</th></tr></table>');
	   
			   $.each(obj.data.isMakinalari.isMakinalariBilgileri.vehicledetail,function(index,satir){
				 
				 $("#myTable702 tr:last").after( "<tr><td>" + satir.chassisnumber + "</td><td>" + satir.vehiclebrand + "-" + satir.vehicletype + " </td><td>" + satir.commerceoffice + "</td><td>" + satir.enginenumber + "</td><td>"+satir.platenumber+"</td></tr>");
				   
				 
				 });
			 
	 }
	 
}

catch(err){
	
				 $("#myTable702 tr:last").after( "<tr><td>İş Makineleri Hata ile Karşılaşıldı</td><td></td><td></td><td></td><td></td></tr>");
		
	}
	 
	 ////////////////////////////////////////////////TAPU

try{	   
	   if (obj.data.tapu.takbisBilgileri.summary.length>0) {
	   
	     $('#tablo'+ tabloID).after('<table id="myTable703" border=1> <caption>TAPU Bilgisi</caption><tr><th>Adres</th><th>BAĞIMSIZ</th><th>PAFTA</th><th>ADA</th><th>PARSEL</th><th>TAŞINMAZ TİPİ</th><th>NİTELİK</th></tr></table>');
	 
			   $.each(obj.data.tapu.takbisBilgileri.summary	,function(index,satir){
				 
				 $("#myTable703 tr:last").after( "<tr><td>" + satir.mahalle + "-" + satir.ilce + "-" + satir.il  + "</td><td>"+satir.bagimsizbolum+"</td><td>" + satir.pafta + "</td><td>" + satir.ada + "</td><td>" + satir.parsel + "</td><td>"+satir.bagimsizbolumtip+"</td><td>"+satir.nitelik+"</td></tr>");
				   
				 
				 });
			 
	 }
	 
}

catch(err){
	
								 $("#myTable703 tr:last").after( "<tr><td>Tapu Sorgularkan Hata ile Karşılaşıldı</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
		
	}

	 
	 ////////////////////////////////////////////////GEMİ/

try{	 
	  
	   if (obj.data.denizTasit.denizTasit.gemiBilgileri.hatakodu==undefined) {
	   
	     $('#tablo'+ tabloID).after('<table id="myTable704" border=1> <caption>GEMİ Bilgisi</caption><tr><th>Gemi Adı</th><th>Gemi Numarası</th><th>CİNSİ</th><th>Bağlama Limanı</th></tr></table>');
	  
			   $.each(obj.data.denizTasit.denizTasit.gemiBilgileri.data, function(index,satir){
				 
				 $("#myTable704 tr:last").after( "<tr><td>" + satir.gemiadi + "</td><td>" + satir.gemino + "</td><td>" + satir.gemicins + " </td><td>" + satir.bagliman + "</td></tr>");
				   
				 
				 });
			 
	 }	
	 
}
catch(err){
	
			 $("#myTable704 tr:last").after( "<tr><td>Gemi Sorgulamada Hata ile Karşılaşıldı</td><td></td><td></td><td></td></tr>");
		
	}
	  
	  ////////////////////////////////////////////////UÇAK/
	 
try{	   
	   if (obj.data.sivilHavacilik.sivilHavacilikBilgileri.length>0) {
	   
	     $('#tablo'+ tabloID).after('<table id="myTable705" border=1> <caption>Hava Taşıtları Bilgisi</caption><tr><th>Tescil Tarihi</th><th>Tipi</th><th>Sınıfı</th><th>Üretim Yılı</th><th>Hisse Oranı</th></tr></table>');
	 
			   $.each(obj.data.sivilHavacilik.sivilHavacilikBilgileri, function(index,satir){
				 
				 $("#myTable705 tr:last").after( "<tr><td>" + satir.tesciltarihi + "</td><td>" + satir.tipi + "</td><td>" + satir.sinif + "</td><td>" + satir.uretimyil + "</td><td>"+satir.hisseorani+"</td></tr>");
				   
				 
				 });
			 
	 }
	 
	}
	
	catch(err){
	
			$("#myTable705 tr:last").after( "<tr><td>Uçak Sorgularken Hata ile karşılaşıldı</td><td></td><td></td><td></td><td></td></tr>");
		
	}
	   
	 
	 
	 
	 
	 
	 
}
function borcAciklamaDegistir(aciklama){


 var bul ={
			'1':'TAKİPLİ',
			'2':'6183/B4/5228/5766 TECİLLİ',
			'3':'KDV/ÖTV/Muhtasar TECİLLİ',
			'4' :'414 TECİLLİ',
			'5' : 'VB TECİLLİ',
			'6' : '5335 TECİLLİ',
			'7': 'KOBİ TECİLLİ',
			'8' : 'DİĞER TECİLLİ',
			'9' : 'TAHSİLAT FAZLASI VAR',
			'10' : '6111 TECILLI',
			'11':'6552 TECİLLİ',
			'12':'6552 GEÇİCİ 2-1',
			'13': '6736 TECİLLİ',
			'14': '7020 TECİLLİ',
			'15': '7143 TECİLLİ',
			'16': '7256 TECİLLİ',
			'17': '7326 TECİLLİ',
			'18': '7440 TECİLLİ'
};


   yeni_aciklama=aciklama.replace("1", bul['1']);
   yeni_aciklama=yeni_aciklama.replace("2", bul['2']);
   yeni_aciklama=yeni_aciklama.replace("3", bul['3']);
   yeni_aciklama=yeni_aciklama.replace("4", bul['4']);
   yeni_aciklama=yeni_aciklama.replace("5", bul['5']);
   yeni_aciklama=yeni_aciklama.replace("6", bul['6']);
   yeni_aciklama=yeni_aciklama.replace("7", bul['7']);
   yeni_aciklama=yeni_aciklama.replace("8", bul['8']);
   yeni_aciklama=yeni_aciklama.replace("9", bul['9']);
   yeni_aciklama=yeni_aciklama.replace("10", bul['10']);
   yeni_aciklama=yeni_aciklama.replace("11", bul['11']);
   yeni_aciklama=yeni_aciklama.replace("12", bul['12']);
   yeni_aciklama=yeni_aciklama.replace("13", bul['13']);
   yeni_aciklama=yeni_aciklama.replace("14", bul['14']);
   yeni_aciklama=yeni_aciklama.replace("15", bul['15']);
   yeni_aciklama=yeni_aciklama.replace("16", bul['16']);
   yeni_aciklama=yeni_aciklama.replace("17", bul['17']);
   yeni_aciklama=yeni_aciklama.replace("18", bul['18']);

	return yeni_aciklama;

}

function donustur(aciklama){


 var bul ={'ı':'%C4%B1',
	    'İ':'%C4%B0',
	    'ö':'%C3%B6' , 
	    'ü':'%C3%BC',
	    'ğ':'%C4%9F',
	    'ş':'%C5%9F',
	    'ç':'%C3%A7',
	    ';':'%3B',
	    ' ': '%20',
		'/' :'%2F' };

 
   yeni_aciklama=aciklama.replace(/ı/g, bul['ı']);
   yeni_aciklama=yeni_aciklama.replace(/İ/g, bul['İ']);
   yeni_aciklama=yeni_aciklama.replace(/ö/g, bul['ö']);
   yeni_aciklama=yeni_aciklama.replace(/Ö/g, bul['ö']);
   yeni_aciklama=yeni_aciklama.replace(/ü/g, bul['ü']);
   yeni_aciklama=yeni_aciklama.replace(/Ü/g, bul['ü']);
   yeni_aciklama=yeni_aciklama.replace(/Ğ/g, bul['ğ']);
   yeni_aciklama=yeni_aciklama.replace(/ğ/g, bul['ğ']);
   yeni_aciklama=yeni_aciklama.replace(/ş/g, bul['ş']);
   yeni_aciklama=yeni_aciklama.replace(/Ş/g, bul['ş']);
   yeni_aciklama=yeni_aciklama.replace(/ç/g, bul['ç']);
   yeni_aciklama=yeni_aciklama.replace(/Ç/g, bul['ç']);
   yeni_aciklama=yeni_aciklama.replace(/ /g, bul[' ']);
   yeni_aciklama=yeni_aciklama.replace(/;/g, bul[';']);
   yeni_aciklama=yeni_aciklama.replace(/\//g, bul['/']);

	return yeni_aciklama;

}



function __smsHtmlEsc(v){
    return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});
}
function __smsMoneyFmt(v){
    if(v===null||v===undefined||v==='') return '';
    var n=Number(v);
    if(isFinite(n)){
        try{return n.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2});}catch(e){return n.toFixed(2)}
    }
    return __smsHtmlEsc(v);
}
function __smsEnsurePopupCss(){
    if(document.getElementById('smsBilgiPopupStyle')) return;
    var st=document.createElement('style');
    st.id='smsBilgiPopupStyle';
    st.textContent='.sms-pop-back{position:fixed;z-index:999999;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,.35);display:flex;align-items:flex-start;justify-content:center;padding-top:40px}.sms-pop{background:#fff;max-width:1100px;width:92%;max-height:85vh;overflow:auto;border:2px solid #159447;box-shadow:0 8px 28px rgba(0,0,0,.35);font-family:Arial,sans-serif;font-size:12px}.sms-pop-h{background:#159447;color:#fff;padding:8px 10px;font-weight:bold;position:sticky;top:0}.sms-pop-x{float:right;background:#fff;color:#159447;border:0;border-radius:3px;padding:2px 8px;font-weight:bold;cursor:pointer}.sms-pop-b{padding:10px}.sms-sec-title{margin:10px 0 4px;font-weight:bold;color:#0b6b2e}.sms-pop table{border-collapse:collapse;width:100%;margin-bottom:8px}.sms-pop th,.sms-pop td{border:1px solid #999;padding:4px 5px;vertical-align:top}.sms-pop th{background:#198754;color:#fff}.sms-empty{color:#777;font-style:italic}.sms-count{background:#fff7cc;border:1px solid #e0c55c;padding:6px;margin-bottom:8px}';
    document.head.appendChild(st);
}
function __smsField(obj,keys){
    obj=obj||{};
    for(var i=0;i<keys.length;i++){
        var k=keys[i];
        if(obj[k]!==undefined && obj[k]!==null && obj[k]!== '') return obj[k];
    }
    return '';
}
function __smsRenderTable(title,rows,cols){
    rows=Array.isArray(rows)?rows:[];
    var h='<div class="sms-sec-title">'+__smsHtmlEsc(title)+' ('+rows.length+')</div>';
    if(!rows.length) return h+'<div class="sms-empty">Kayıt yok.</div>';
    h+='<table><thead><tr>';
    for(var c=0;c<cols.length;c++) h+='<th>'+__smsHtmlEsc(cols[c].t)+'</th>';
    h+='</tr></thead><tbody>';
    for(var r=0;r<rows.length;r++){
        h+='<tr>';
        for(var c2=0;c2<cols.length;c2++){
            var col=cols[c2], val=__smsField(rows[r],col.k);
            h+='<td>'+ (col.money?__smsMoneyFmt(val):__smsHtmlEsc(val)) +'</td>';
        }
        h+='</tr>';
    }
    h+='</tbody></table>';
    return h;
}
function __smsGenericTable(title,rows){
    rows=Array.isArray(rows)?rows:[];
    if(!rows.length) return '<div class="sms-sec-title">'+__smsHtmlEsc(title)+' (0)</div><div class="sms-empty">Kayıt yok.</div>';
    var keys=[];
    rows.forEach(function(r){Object.keys(r||{}).forEach(function(k){if(keys.indexOf(k)<0)keys.push(k);});});
    var cols=keys.map(function(k){return {t:k,k:[k],money:/tutar|gelir|matrah|fark|olmat|toplam|satis|alış|alis/i.test(k)}});
    return __smsRenderTable(title,rows,cols);
}


function smsBilgileriYazdir(){
    var pop=document.getElementById('smsBilgiPopup');
    if(!pop){ return false; }
    var headEl=pop.querySelector('.sms-pop-h');
    var bodyEl=pop.querySelector('.sms-pop-b');
    var title=headEl ? headEl.cloneNode(true) : null;
    if(title){
        var buttons=title.querySelectorAll('button');
        for(var i=0;i<buttons.length;i++) buttons[i].remove();
    }
    var w=window.open('', '_blank', 'width=1100,height=800');
    if(!w){ alert('Yazdırma penceresi açılamadı. Tarayıcı popup engelini kontrol edin.'); return false; }
    var css='body{font-family:Arial,sans-serif;font-size:12px;margin:18px;color:#000} '+
            '.sms-pop-h{background:#159447;color:#fff;padding:8px 10px;font-weight:bold;margin-bottom:10px} '+
            '.sms-pop-b{padding:0} .sms-sec-title{margin:10px 0 4px;font-weight:bold;color:#0b6b2e} '+
            'table{border-collapse:collapse;width:100%;margin-bottom:8px} th,td{border:1px solid #999;padding:4px 5px;vertical-align:top} '+
            'th{background:#198754;color:#fff} .sms-empty{color:#777;font-style:italic} .sms-count{background:#fff7cc;border:1px solid #e0c55c;padding:6px;margin-bottom:8px}';
    w.document.open();
    w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>SMS / İzaha Davet Bilgileri</title><style>'+css+'</style></head><body>' +
                     (title ? title.outerHTML : '<div class="sms-pop-h">SMS / İzaha Davet Bilgileri</div>') +
                     (bodyEl ? bodyEl.outerHTML : '') +
                     '</body></html>');
    w.document.close();
    w.focus();
    setTimeout(function(){ try{ w.print(); }catch(e){} }, 300);
    return false;
}

function smsBilgileriPopup(vkn){
    vkn=String(vkn||'').trim();
    var data=(window.__smsBilgileriCache&&window.__smsBilgileriCache[vkn])||null;
    if(!data){alert('SMS detay bilgisi bulunamadı. Takdir sorguyu yeniden çalıştırın.');return false;}
    __smsEnsurePopupCss();
    var gmsi=data.listeGmsi||[], gyz=data.listeGyz||[], dki=data.listeDki||[], ucr=data.listeUcr||[];
    var total=gmsi.length+gyz.length+dki.length+ucr.length;
    var h='<div class="sms-pop-back" id="smsBilgiPopup"><div class="sms-pop"><div class="sms-pop-h">SMS / İzaha Davet Bilgileri - VKN: '+__smsHtmlEsc(vkn)+'<button class="sms-pop-x" onclick="document.getElementById(\'smsBilgiPopup\').remove()">Kapat</button><button class="sms-pop-x" style="margin-right:6px" onclick="return smsBilgileriYazdir()">Yazdır</button></div><div class="sms-pop-b">';
    h+='<div class="sms-count"><b>Toplam kayıt:</b> '+total+' &nbsp; | &nbsp; Kira/GMSİ: '+gmsi.length+' &nbsp; | &nbsp; Gayrimenkul/Değer Artış: '+gyz.length+' &nbsp; | &nbsp; Alım-Satım: '+dki.length+' &nbsp; | &nbsp; Ücret: '+ucr.length+'</div>';
    h+=__smsRenderTable('KİRA GELİRİ ELDE EDENLER / GMSİ',gmsi,[
        {t:'VKN',k:['vknGmsi','vkn']},{t:'TCKN',k:['tcknGmsi','tckn']},{t:'Adı Soyadı',k:['adsoyadGmsi','adsoyad']},{t:'VD Kodu',k:['vdkoduGmsi','vdkodu']},{t:'VD Adı',k:['vdadiGmsi','vdadi']},{t:'Adres',k:['adresGmsi','adres']},{t:'Konu',k:['konuGmsi','konu']},{t:'Dönem',k:['donemGmsi','donem']},{t:'Kira Geliri Toplamı',k:['olmatfarGmsi','olmatfar'],money:true}
    ]);
    h+=__smsRenderTable('GAYRİMENKUL / DEĞER ARTIŞI BİLGİLERİ',gyz,[
        {t:'VKN',k:['vknGyz','vkn']},{t:'TCKN',k:['tcknGyz','tckn']},{t:'Adı Soyadı',k:['adsoyadGyz','adsoyad']},{t:'VD Kodu',k:['vdkoduGyz','vdkodu']},{t:'Adres',k:['adresGyz','adres']},{t:'Konu',k:['konuGyz','konu']},{t:'Dönem',k:['donemGyz','donem']},{t:'Tutar',k:['olmatfarGyz','olmatfar'],money:true},{t:'Açıklama',k:['aciklama']}
    ]);
    h+=__smsRenderTable('GAYRİMENKUL ALIM / SATIM BİLGİLERİ',dki,[
        {t:'VKN',k:['vkn']},{t:'TCKN',k:['tckn']},{t:'Adı Soyadı',k:['adsoyad']},{t:'VD Kodu',k:['vdkodu']},{t:'Adres',k:['adres']},{t:'Konu',k:['konu']},{t:'Dönem',k:['donem']},{t:'Alış Tarihi',k:['alis_tarihi']},{t:'Satış Tarihi',k:['satis_tarihi']},{t:'Alış Tutarı',k:['toplam_alis_tutar'],money:true},{t:'Satış Tutarı',k:['toplam_satis_tutar'],money:true},{t:'Taşınmaz',k:['tasinmaz_ili','tasinmaz_ilcesi','tasinmaz_mahallesi']}
    ]);
    h+=__smsRenderTable('ÜCRET GELİRİ BİLGİLERİ',ucr,[
        {t:'VKN',k:['vknn','vkn']},{t:'TCKN',k:['tcknn','tckn']},{t:'Adı Soyadı',k:['adsoyadd','adsoyad']},{t:'VD Kodu/Adı',k:['vdkoduu','vdkodu']},{t:'Adres',k:['adress','adres']},{t:'Konu',k:['konuu','konu']},{t:'Dönem',k:['donemm','donem']},{t:'Gelir/Tutar',k:['olmatfar','textbox','textbox1','textbox2'],money:true},{t:'İş Sayısı',k:['topissay'],money:true}
    ]);
    h+='</div></div></div>';
    var old=document.getElementById('smsBilgiPopup'); if(old) old.remove();
    document.body.insertAdjacentHTML('beforeend',h);
    return false;
}

function smsVarmi(vkn,token){

try{

var callid=makeid(13) + '-';

    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=izahaDavetService_getIzahaDavetBilgileri&callid=';
	var url=url.concat(callid + '144', '&token=', token, '&jp=%7B%22reqObj%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22yil%22%3A%22%22%7D%7D');
	var sms = getRemote(url);
	var obj =JSON.parse(sms);
	var data = obj && obj.data ? obj.data : {};
	window.__smsBilgileriCache = window.__smsBilgileriCache || {};
	window.__smsBilgileriCache[String(vkn)] = data;
	
	var gmsiSMS=(data.listeGmsi||[]).length;
	var listeGyz=(data.listeGyz||[]).length;
	var listeDki=(data.listeDki||[]).length;
	var listeUcr=(data.listeUcr||[]).length;
	
	if (gmsiSMS>0 || listeGyz>0 || listeDki>0  || listeUcr>0  ){
	
	return "<a href='#' onclick='return smsBilgileriPopup(\"" + String(vkn).replace(/\"/g,'') + "\")'>VAR</a>";
	
	}	else{
	
	return "YOK";
	}

}

	catch(err){

	return "Yetkiniz Yok / Hata ile Karşılaşıldı";


	}

}




function istisnaDilekcesiVarmi(vkn,tokenDegeri){
try{
  var callid=makeid(13) + '-';
  var vergi_dairesi = vdKodu();
  var bugun_yil=bugunYil();
  var tk = (typeof tokenDegeri === 'string' && tokenDegeri) ? tokenDegeri : (typeof token === 'function' ? token() : '');
  var jp={vdKodu:String(vergi_dairesi||''),tcknVkn:String(vkn||''),donemBas:'20180101',donemBit:String(bugun_yil)+'1231',yil:''};
  var url='http://10.251.63.99/gibintranet_server/dispatch?cmd=gmsiBildirimService_gmsiIstisnaDilekceSorgu&callid=' + encodeURIComponent(callid+'12') + '&token=' + encodeURIComponent(tk) + '&jp=' + encodeURIComponent(JSON.stringify(jp));
  var dilekce=getRemote(url);
  var obj=JSON.parse(dilekce||'{}');
  var data=(obj&&obj.data)||{};
  var liste=data.gmsiDilekceSorgula || data.liste || data.veriler || [];
  if(!Array.isArray(liste)) liste=[];
  if(liste.length>0){
    return "<a target='_blank' href='diger/istisna-dilekcesi.html?vkn=" + encodeURIComponent(vkn) + "&token=" + encodeURIComponent(tk) + "&vd=" + encodeURIComponent(vergi_dairesi||'') + "' >VAR</a>";
  }
  if(obj && (obj.error || obj.hata || obj.exception)){
    return "Yetkiniz Yok / Hata ile Karşılaşıldı";
  }
  return "YOK";
}catch(err){
  try{console.warn('İstisna dilekçesi sorgu hatası',err);}catch(e){}
  return "Yetkiniz Yok / Hata ile Karşılaşıldı";
}
}


function topluTakipKontrol(evdbToken) {

 	 
      var callid=makeid(13) + '-';
     
      //
      
      var url5= 'http://10.251.63.99/evdo_server/dispatch?cmd=topluTakipEngelGiris_getGuncelDonem&&callid=';
      var url5=url5.concat(callid + '81', '&token=', evdbToken , '&jp=%7B%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'topluTakipKontrol');
      
      var cariDonem=obj.data.guncelDonemVal; 
      
      
      var url5= 'http://10.251.63.99/evdo_server/dispatch?cmd=topluTakipEngelGiris_topluTakipOnayKontrol&callid=';
      var url5=url5.concat(callid + '180', '&token=', evdbToken , '&jp=%7B%22donem%22%3A%22',cariDonem,'%22%7D');
      var daireler = getRemote(url5);
      var obj =tkParse(daireler,'topluTakipKontrol');
         
      if (obj.data.dahaoncedenonaylanmis==false){ alert("Toplu Takip Onay Bölümü Aktif Hale Gelmiştir");}
      
		



}


function eTebligatVarmi(vkn,tur,token) {

try{
		if(!vkn){ return "Yok"; }
		var callid=makeid(13) + '-';
		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=internetVergiDairesiKullanicilariService_eTebligataTabiiMukellefSorgulama&callid=';
		url=url.concat(callid + '13', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22mukTuru%22%3A%22',tur,'%22%7D');
		var raw = getRemote(url);
		if(!raw || raw === "undefined") return "Yok";
		var obj = JSON.parse(raw);
		if(!obj || !obj.data || !obj.data.list) return "Yok";
		if (obj.data.list.length===0){
			return "Yok";
		}else{
			var item=obj.data.list[0] || {};
			var tel=item.ctel1 ? ('-' + item.ctel1) : '';
			return "Var - Baş Tarihi: " + tarihFormat(item.akbastar) + tel;
		}
}catch(err){
	console.log("eTebligatVarmi hata", err);
	return "Hata ile karşılaşıldı";
}

}



function kdviraKontrol(vkn,donem) {

	try{
		var myRegex= /[0-9]+/;
		
		
		
		var callid=makeid(13) + '-';
		var kdviraVarmi=0;

		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvKontrolRaporuService_raporDonemleriGetir&callid=';
		var url=url.concat(callid + '14', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22arsivMi%22%3Afalse%7D');
		var kdvira = getRemote(url);
		var obj =JSON.parse(kdvira);

			$.each(obj.data.raporlar, function(index, satir){

				if (satir.donem==donem) { kdviraVarmi= kdviraVarmi + 1;  		}

			});		

		if (kdviraVarmi>0){ return "Var" }else { return "Yok" } 

	}

	catch(err){

	return ("Hata ile karşılaşıldı - " + err);
	}

}


function bugunDonem(){

  var bugun=new Date();
  
  var yil= String(bugun.getFullYear());
  
  var ay = String(bugun.getMonth()+1);
  
  if (ay.length==1){   ay= "0" + ay;  }
  
  return yil + ay ;

}

function bugunYil(){

  var bugun=new Date();
  
  var yil= bugun.getFullYear();
  
  return yil;

}


function FmotorluTasitlarService_aktifTasitSorgulama(vkn){
var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';


//
var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=motorluTasitlarService_aktifTasitSorgulama&callid=';
var url5=url5.concat(callid + '9', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22sorgulamaTuru%22%3A%221%22%2C%22mtvMuafiyet%22%3A%221%22%2C%22islemSahibi%22%3A%22GIBINTRA%22%7D');
var rapor = getRemote(url5);
var obj =tkParse(rapor,'FmotorluTasitlarService_aktifTasitSorgulama');

var kayitSayisi = obj.data.veriler.length;

return kayitSayisi;


}

function raporKayitGetir(vkn,vd){

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var raporDizi=new Array();
var vergi_dairesi=vdKodu();
	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=raporDefteriService_raporDefteriSorgula&callid=';
		var url5=url5.concat(callid + '21', '&token=', token(), '&jp=%7B%22vkn%22%3A%22', vkn ,'%22%2C%22vdkodu%22%3A%22',vd,'%22%7D');
		var rapor = getRemote(url5);
		var obj_rapor =tkParse(rapor,'raporKayitGetir');
		var rapor_liste = ((obj_rapor||{}).data||{}).raporDefterleri || [];
		
		$.each(rapor_liste, function(index, satir){
	      
		    var rapor_kayit_no=satir.rapordefterino;
		    var aciklama= satir.aciklama;
		    
		    
		    // rapor kayıt defteri içerisinde yer alan bilgiler alınyor
		    
		    //
		      
		    var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=raporDefteriService_raporDefteriDetaySorgula&callid=';
		    var url6=url6.concat(callid + '30', '&token=', token(), '&jp=%7B%22rapordefno%22%3A%22',rapor_kayit_no,'%22%2C%22vdkodu%22%3A%22',vergi_dairesi,'%22%2C%22vkn%22%3A%22',vkn,'%22%7D');
		    var rapor_detay = getRemote(url6);
		    var obj_rapor_detay =tkParse(rapor_detay,'raporKayitGetir');  
		    
		    var vergiKodu=obj_rapor_detay.data.incelemeBilgileri.vergikodu;
		    var vergidonem=obj_rapor_detay.data.incelemeBilgileri.vergidonem;
			
		    		    		   
		    
		    
		   raporDizi.push( aciklama + "-" + vergiKodu+ "-" +vergidonem + "-"  );
		   
		    
		   
		    
		    });

return raporDizi;
}

function iade_azaltan_mukellefler(){
var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var zamanAsimiYil=zamanAsimi();
var kayit_sayisiKDV=0;
var kayit_sayisiVergilendirme=0;
var zamanAsimliKayitSayisiKDV=0;
var zamanAsimliKayitSayisiVergilendirme=0;
//
var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvIadeSonrasiTutarAzaltanService_tutarAzaltanMukListesiGetir&callid=';
		var url5=url5.concat(callid + '57', '&token=', token(), '&jp=%7B%22vdKodu%22%3A%22',vdKodu(),'%22%2C%22basVkn%22%3A%22%22%2C%22bitVkn%22%3A%22%22%2C%22basDonem%22%3A%22%22%2C%22bitDonem%22%3A%22%22%7D');
		var rapor = getRemote(url5);
		var obj =tkParse(rapor,'iade_azaltan_mukellefler');
		var rapor_liste = obj.data.liste;
        kayit_sayisiKDV=rapor_liste.length;
		
				
		$.each(rapor_liste, function(index, satir){

				if (satir.donem.substring(0,4)==zamanAsimiYil){
				
				zamanAsimliKayitSayisiKDV=zamanAsimliKayitSayisiKDV + 1 ;
				
				}
	    });
	    
//
	    
var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=gkIadeAzaltanService_iadeAzaltanMukListesiGetir&callid=';
		var url5=url5.concat(callid + '86', '&token=', token(), '&jp=%7B%22vdKodu%22%3A%22',vdKodu(),'%22%2C%22basVkn%22%3A%220000000000%22%2C%22bitVkn%22%3A%229999999999%22%2C%22basDonem%22%3A%22%22%2C%22bitDonem%22%3A%22%22%7D	    ');
		var rapor = getRemote(url5);
		var obj =tkParse(rapor,'iade_azaltan_mukellefler');
		var rapor_liste = obj.data.liste;
        kayit_sayisiVergilendirme=rapor_liste.length;
		
				
		$.each(rapor_liste, function(index, satir){

				if (satir.donem.substring(0,4)==zamanAsimiYil){
				
				zamanAsimliKayitSayisiVergilendirme=zamanAsimliKayitSayisiVergilendirme + 1 ;
				
				}
	    });
	    
        alert("KDV İade İşlemi Gerçekleştirildikten Sonra İade Tutarını Azaltan Mükellefler Listesinde Toplam:" + kayit_sayisiKDV + "\n" + "Zamanaşımlı:" + zamanAsimliKayitSayisiKDV );	  
        
	    alert("Gelir/Kurumlar Vergisi İade İşlemleri Gerçekleştirildikten Sonra İade Tutarını Azaltan Mükellefler Listesi:" + kayit_sayisiVergilendirme + "\n" + "Zamanaşımlı:" + zamanAsimliKayitSayisiVergilendirme );			
	    
	    
	    
}


function __beyanDonemHazirla(y1,a1,y2,a2){
  y1 = (y1==null?'':String(y1)).trim();
  a1 = (a1==null?'':String(a1)).trim();
  y2 = (y2==null?'':String(y2)).trim();
  a2 = (a2==null?'':String(a2)).trim();

  function padAy(a){
    a = (a==null?'':String(a)).replace(/\D/g,'');
    if(!a) return '';
    if(a.length===1) return '0'+a;
    return a.substr(0,2);
  }

  a1 = padAy(a1);
  a2 = padAy(a2);
  if(!y2) y2 = y1;
  if(!a2) a2 = a1;

  return {
    y1:y1,
    a1:a1,
    y2:y2,
    a2:a2,
    donemBas:(y1 && a1 ? y1+a1 : ''),
    donemBit:(y2 && a2 ? y2+a2 : '')
  };
}

function __beyanHazirlikIp(vkn,vdKodu,vergiKodu,donem,arsiv,tk){
  var callid = makeid(13) + '-';
  var jp = {
    vkn:String(vkn||''),
    vdKodu:String(vdKodu||''),
    vergiKodu:String(vergiKodu||''),
    donemBas:donem.donemBas || '',
    donemBit:donem.donemBit || '',
    arsiv:arsiv || 'T'
  };
  var url = 'http://10.251.63.99/gibintranet_server/dispatch?cmd=bynIslemleriService_bynSorgula&callid=' +
            encodeURIComponent(callid + '25') +
            '&token=' + encodeURIComponent(tk || token()) +
            '&jp=' + encodeURIComponent(JSON.stringify(jp));
  var beyanname = getRemote(url);
  var obj = tkParse(beyanname || '{}','__beyanHazirlikIp');
  return (obj && obj.data) ? obj.data : {};
}


function __beyanPostAc(params){
  // E-Beyan liste ekranı GET ile dönem filtresini dikkate almayabiliyor.
  // Beyanname / KDV / E-Belge Karşılaştırma ekranındaki çalışan mantık gibi form POST ile açıyoruz.
  var f=document.createElement('form');
  f.method='POST';
  f.action='http://10.251.67.110:30080/ebyn/vdintraDispatch';
  f.target='_blank';
  f.style.display='none';
  Object.keys(params||{}).forEach(function(k){
    var inp=document.createElement('input');
    inp.type='hidden';
    inp.name=k;
    inp.value=(params[k]===undefined||params[k]===null)?'':String(params[k]);
    f.appendChild(inp);
  });
  document.body.appendChild(f);
  f.submit();
  setTimeout(function(){try{f.remove()}catch(e){}},1000);
}

function __beyanListeAc(vkn,vdKodu,vergiKodu,y1,a1,y2,a2,arsiv,tk){
  var donem = __beyanDonemHazirla(y1,a1,y2,a2);
  var data = __beyanHazirlikIp(vkn,vdKodu,vergiKodu,donem,arsiv || 'F',tk);
  var ip = data.kullaniciIp || '';
  var userId = data.kullaniciKodu || data.userid || data.userId || 'tcnumaran';

  var params = {
    SVERGINO:String(vkn||''),
    VERGIKODU:String(vergiKodu||''),
    VDKODU:String(vdKodu||''),
    tD1yil:donem.y1 || '',
    tD2yil:donem.y2 || '',
    tD1ay:donem.a1 || '',
    tD2ay:donem.a2 || '',
    ARSIV:arsiv || 'F',
    BFORMUCIKAR:'1',
    KESINMIZANCIKAR:'1',
    cmd:'BEYANNAMELISTESIVDO',
    origin:'vdintra',
    USERID:userId,
    USERIP:ip
  };

  // Kontrol için console'a sadece dönem filtresini yazıyoruz.
  try{console.log('Beyanname POST filtre:', params.VERGIKODU, params.tD1yil+'/'+params.tD1ay, params.tD2yil+'/'+params.tD2ay);}catch(e){}
  __beyanPostAc(params);
}

function beyanname_getir_guncel(vkn,vdKodu,vergiKodu,y1,a1,y2,a2){
  // Takdir tablosundan tıklanan satırın dönemini filtreleyerek açar.
  // Örnek 0015 2020-09 için sadece 09/2020 KDV listesi gelir.
  __beyanListeAc(vkn,vdKodu,vergiKodu,y1,a1,y2,a2,'F',token());
}

function get_beyanname_getir_guncel(vkn,vdKodu,vergiKodu,y1,a1,y2,a2){
  var tk = GetUrlValue('token');
  __beyanListeAc(vkn,vdKodu,vergiKodu,y1,a1,y2,a2,'F',tk);
}

function beyanname_getir_arsiv(vkn,vdKodu,vergiKodu,y1,a1,y2,a2){
  __beyanListeAc(vkn,vdKodu,vergiKodu,y1,a1,y2,a2,'T',token());
}


 function eFaturaAktifMi(vkn,token){

  var callid=makeid(13) + '-';
  var kayit=0;

  var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=efaturaService_eFaturaKayitliKullaniciSorgula&callid=';
  var url1=url1.concat(callid + '219', '&token=', token, '&jp=%7B%22vkn%22%3A%22', vkn,'%22%2C%22tckn%22%3A%22%22%7D');
  var daireler = getRemote(url1);
  var obj =tkParse(daireler,'eFaturaAktifMi');
	
	
  var kayitSayisi=obj.data.eFaturaKayitliKullaniciListesi.length;

	if (kayitSayisi>0) {
	
		 $.each(obj.data.eFaturaKayitliKullaniciListesi, function(index, satir){ // kullanıcı olarak her  bir kaydın listesini veriyor

			 if (satir.eklenmeTarihi!="" && satir.kapanmaTarihi==undefined ) {
			 
				 kayit= kayit +1;
			 
			 }
		
		});

   }

	return kayit;	

}

function eArsivFaturaAktifMi(vkn,token){

  var callid=makeid(13) + '-';
  var kayit=0;

  var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=efaturaService_eArsivKayitliKullaniciSorgula&callid=';
  var url1=url1.concat(callid + '219', '&token=', token, '&jp=%7B%22vkn%22%3A%22', vkn,'%22%2C%22tckn%22%3A%22%22%7D');
  var daireler = getRemote(url1);
  var obj =tkParse(daireler,'eArsivFaturaAktifMi');
	
	
  var kayitSayisi=obj.data.eArsivKayitliKullaniciListesi.length;

	if (kayitSayisi>0) {
	
		 $.each(obj.data.eArsivKayitliKullaniciListesi, function(index, satir){ // kullanıcı olarak her  bir kaydın listesini veriyor

			 if (satir.eklenmeTarihi!="" && satir.kapanmaTarihi==undefined ) {
			 
				 kayit= kayit +1;
			 
			 }
		
		});

   }

	return kayit;	

}


function takipDurumu (vkno,vdkodu,vergiKodu,vdDonemBas,vdDonemBit) {
var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
const vdORGID=orgIDGetir(vdkodu);
var dizi=new Array();
var durumListe ={'-1':'KALDIRILMIŞ', '0':'İPTAL', '1':'GEÇERLİ', '2':'GÜNLENMİŞ'};
var tebligSekliListe={'0':'TEBLİĞ EDİLMEMİŞ', '1':'POSTA', '13':'ETEBLİGAT'};     
    var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTakipService_anaTakipleriGetir&callid=';



 var url=url.concat(callid + '202', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkno ,'%22%2C%22tckn%22%3A%22%22%2C%22vdkodu%22%3A%22',vdkodu,'%22%2C%22orgoid%22%3A%22',vdORGID,'%22%2C%22anavergikodu%22%3A%22', vergiKodu,'%22%2C%22vergilendirmedonemibas%22%3A%22',vdDonemBas,'%22%2C%22vergilendirmedonemibit%22%3A%22', vdDonemBit , '%22%2C%22anatkpdurum%22%3A%22%22%2C%22ebelgedurum%22%3A%220%22%2C%22tebligdurum%22%3A%2299%22%7D%7D');


    var url_thk = getRemote(url);
    var obj =tkParse(url_thk,'takipDurumu');

    var liste = obj.data.anatakipkayitlari; /// 
    var kayit_sayisi=liste.length;    

    if (liste.length==0) {
    
    return 'Takip Dosyası Bulunamadı';
    
    
	}else{
    
	var veri=obj.data.anatakipkayitlari[(liste.length-1)];

	var durum=veri.durum;

	var takipTarihi=tarihFormat(veri.anatkpdosyano);
	
	var tebligTarihi= tarihFormat(veri.tebligtarihi);  
    
    return takipTarihi + "-" +  durumListe[durum] + "-" + tebligTarihi + "-" + veri.anatkpdosyano  ;
    
    }
}


function eksiklikYaziKontrol(iadeTakipNo){

var myRegex= /[0-9]+/;



var callid=makeid(13) + '-';
var eksiklikYazisi=0;
var eksiklikYaziTarihi=0;	
var talepTarihi	=0;

		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeIzlemeService_iadeTakipIzlemeIadeAkisOzet&callid='; 
		var url5=url5.concat(callid + '30', '&token=', token(), '&jp=%7B%22input%22%3A%7B%22iadetakipno%22%3A%22',iadeTakipNo,'%22%2C%22merkez%22%3A%22%22%7D%7D');
		var liste = getRemote(url5);
		var obj =tkParse(liste,'eksiklikYaziKontrol');

		$.each( obj.data.iadeDetay, function(index, satir){
				
			if (satir.islemtip==4) { 

				eksiklikYazisi =eksiklikYazisi+1;
				eksiklikYaziTarihi= tarihFormat(satir.durumtarihi);
				}		

				if (satir.islemtip==6) {  talepTarihi= tarihFormat(satir.durumtarihi);	}		

				
		});
  
					return (eksiklikYazisi + "-"    + eksiklikYaziTarihi);

       

}


/*

function kdviraKontrol1(vkn,donem) {

	try{
		var myRegex= /[0-9]+/;
		
		
		
		var callid=makeid(13) + '-';
		var kdviraBilgileri="";
		var donem=donem.replace("-","");
		var kayitSayisi=0;
		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvKontrolRaporuService_raporDonemleriGetir&callid=';
		var url=url.concat(callid + '14', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22arsivMi%22%3Afalse%7D');
		var kdvira = getRemote(url);
		var obj =JSON.parse(kdvira);

		$.each(obj.data.raporlar, function(index, satir){

			if (satir.donem==donem) { 

					kayitSayisi=kayitSayisi+1;

//
					var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvKontrolRaporuService_kontolRaporuKilitMekanizmasi&callid=';
					var url1=url1.concat(callid + '112', '&token=', token(), '&jp=%7B%22raporOid%22%3A%22',satir.oid,'%22%2C%22vkn%22%3A%22',satir.vkn,'%22%2C%22donem%22%3A%22',donem,'%22%2C%22raporTuru%22%3A%22',raporTuru,'%22%2C%22raporCinsi%22%3A%22',raporCinsi,'%22%2C%22arsivMi%22%3Afalse%7D);
					var kdvira1 = getRemote(url1);
					var obj1 =JSON.parse(kdvira1);

					var aktarimTarihi=tarihFormat(obj1.data.rapor.aktarimTarihi);
					var gorunmekteOlanKontrolRaporunListelerininPasifBilgisi=obj1.data.gorunmekteOlanKontrolRaporunListelerininPasifBilgisi;
					if (gorunmekteOlanKontrolRaporunListelerininPasifBilgisi="false"){gorunmekteOlanKontrolRaporunListelerininPasifBilgisi="Pasife alınmış";}else{gorunmekteOlanKontrolRaporunListelerininPasifBilgisi="-";}
					var atu=obj1.data.raporBilgileri.atu;
					if(atu==2){atu="ATU";}else{atu="-"}
					kdviraBilgileri= "Var" + "-" +  aktarimTarihi + "-" + gorunmekteOlanKontrolRaporunListelerininPasifBilgisi + "-" + atu ;
					

		}

			});		

	
	if (kayitSayisi>0){

		return kdviraBilgileri;

	}else if (kayitSayisi==0){

		return  ("Yok" + "-" +  "" + "-" + "" + "-" + "") ;
}


	}


	catch(err){

	return ("Hata ile karşılaşıldı - " + err);
	}

}
*/


function iadeDetay(token,vkn,vergikodu,donem,vergiDairesi,iadetakipno){

var callid=makeid(13) + '-';
var kayit=0;
var iadehakdogislem="";				
var beyiadetutar="";
var iadeislemtaleptutar="";
var talepturu="";
var teminattalebi="";

		var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeIzlemeService_iadeTakipIzlemeIadeTalepTutarDetaylari&callid='; 
		var url6=url6.concat(callid + '16', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vKodu%22%3A%22',vergikodu,'%22%2C%22iadedonemi%22%3A%22',donem,'%22%2C%22vdkodu%22%3A%22',vergiDairesi,'%22%2C%22merkez%22%3A%22%22%7D%7D');
		var liste1 = getRemote(url6);
		var obj2 =tkParse(liste1,'iadeDetay');

			$.each( obj2.data.iadeDetay, function(index, satir1){
		
					if (iadetakipno==satir1.iadetakipno){
		
						 iadehakdogislem=satir1.iadehakdogislem;				
						 beyiadetutar=satir1.beyiadetutar;
						 iadeislemtaleptutar=satir1.iadeislemtaleptutar;
						 talepturu=satir1.talepturu;
						 teminattalebi=satir1.teminattalebi;
						/*var sure=iadeDosyaSure(satir1.iadetakipno,token);
						var sure1=sure.split("-");			
						var vdSure=sure1[0];
						var mukSure=sure1[1];*/
						kayit = kayit + 1;
					}
			});

			if (kayit==0){

				return("" + "-" + "" + "-" + "" + "-" +  "" + "-" + "");
			}else{
		
			return(iadehakdogislem + "-" + beyiadetutar + "-" + iadeislemtaleptutar + "-" +  talepturu + "-" + teminattalebi);
		}

	

	


}


function bildirimZamani9b(token,oid){

var callid=makeid(13) + '-';
try{
		var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvIstisnaBlgService_onayBekleyenIstisnaBlgDetayGoruntule&callid='; 
		var url6=url6.concat(callid + '42', '&token=', token, '&jp=%7B%22oid%22%3A%22',oid,'%22%2C%22turKodu%22%3A%229B%22%7D');
		var liste1 = getRemote(url6);
		var obj2 =JSON.parse(liste1);

		var tarih = tarihFormat(obj2.data.kayit_zamani);

		return tarih ;
			
	}

	catch(err){

		return err;
	}



}


function kdviraKontrol1(vkn,donem) {

	try{
		var myRegex= /[0-9]+/;
		
		
		
		var callid=makeid(13) + '-';
		var kdviraBilgileri="";
		var donem=donem.replace("-","");
		var kayitSayisi=0;
		var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvKontrolRaporuService_raporDonemleriGetir&callid=';
		var url=url.concat(callid + '14', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22arsivMi%22%3Afalse%7D');
		var kdvira = getRemote(url);
		var obj =JSON.parse(kdvira);

		$.each(obj.data.raporlar, function(index, satir){

		

			if (satir.donem==donem) { 

					kayitSayisi=kayitSayisi+1;
					var url1= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvKontrolRaporuService_raporVerisiGetir&callid=';
					var url1=url1.concat(callid + '77', '&token=', token(), '&jp=%7B%22raporOid%22%3A%22',satir.oid,'%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22donem%22%3A%22',donem,'%22%2C%22raporTarihi%22%3A%22',satir.raporTarihi,'%22%2C%22raporTuru%22%3A%220%22%2C%22arsivMi%22%3Afalse%2C%22isIntVdSorgusu%22%3A%220%22%7D');
					var kdvira1 = getRemote(url1);
					var obj1 =JSON.parse(kdvira1);

					var aktarimTarihi=tarihFormat(obj1.data.rapor.aktarimTarihi);
					var gorunmekteOlanKontrolRaporunListelerininPasifBilgisi=obj1.data.gorunmekteOlanKontrolRaporunListelerininPasifBilgisi;
					if (gorunmekteOlanKontrolRaporunListelerininPasifBilgisi="false"){gorunmekteOlanKontrolRaporunListelerininPasifBilgisi="Pasife alınmış";}else{gorunmekteOlanKontrolRaporunListelerininPasifBilgisi="-";}
					kdviraBilgileri= "Var" + "-" +  aktarimTarihi + "-" + gorunmekteOlanKontrolRaporunListelerininPasifBilgisi ;
					

		}

			});		

	
	if (kayitSayisi>0){

		return kdviraBilgileri;

	}else if (kayitSayisi==0){

		return  ("Yok" + "-" +  "" + "-" + "" + "-" + "") ;
}


	}


	catch(err){

	return ("Hata ile karşılaşıldı - " + err);
	}

}

function kacinciYuklenimListe(token,vkn,iadeDonem){

	var callid=makeid(13) + '-';
	var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=kdvIadeListeleriService_listeDetaylariniGetir&callid=';
	var url=url.concat(callid + '357', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22donem%22%3A%22',iadeDonem,'%22%2C%22listeTuru%22%3A%220%22%7D');
	var veri = getRemote(url);
	var obj =tkParse(veri,'kacinciYuklenimListe');

	var listeOid=obj.data.sonOlusanRaporBilgisi.listeOid;
	var sonKayit=obj.data.listeBilgileri.length-1;
	
	return (sonKayit + "-" + listeOid );

}


function yillikKDVYuklenimGetir(token,vkn,yil){



	var callid=makeid(13) + '-';
    var sdd = new Array();

	$.each(yil, function(index, yil){

		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=bynIslemleriService_yilKdvBynSorgula&callid='; 
		var url5=url5.concat(callid + '122', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22%22%2C%22yil%22%3A%22',yil,'%22%7D');
		var liste = getRemote(url5);
		var obj =tkParse(liste,'yillikKDVYuklenimGetir');


		  if (obj.data.liste[33].ay1==''){var veri=0;}else{ var veri=obj.data.liste[33].ay1;}
	      if (obj.data.liste[33].ay2==''){var veri1=0;}else{ var veri1=obj.data.liste[33].ay2;}
	      if (obj.data.liste[33].ay3==''){var veri2=0;}else{ var veri2=obj.data.liste[33].ay3;}
	      if (obj.data.liste[33].ay4==''){var veri3=0;}else{ var veri3=obj.data.liste[33].ay4;}
	      if (obj.data.liste[33].ay5==''){var veri4=0;}else{ var veri4=obj.data.liste[33].ay5;}
	      if (obj.data.liste[33].ay6==''){var veri5=0;}else{ var veri5=obj.data.liste[33].ay6;}
	      if (obj.data.liste[33].ay7==''){var veri6=0;}else{ var veri6=obj.data.liste[33].ay7;}
	      if (obj.data.liste[33].ay8==''){var veri7=0;}else{ var veri7=obj.data.liste[33].ay8;}
	      if (obj.data.liste[33].ay9==''){var veri8=0;}else{ var veri8=obj.data.liste[33].ay9;}
	      if (obj.data.liste[33].ay10==''){var veri9=0;}else{ var veri9=obj.data.liste[33].ay10;}
	      if (obj.data.liste[33].ay11==''){var veri10=0;}else{ var veri10=obj.data.liste[33].ay11;}
	      if (obj.data.liste[33].ay12==''){var veri11=0;}else{ var veri11=obj.data.liste[33].ay12;}
	      
	      sdd[yil + "01"] =  parseFloat(veri);
	      sdd[yil + "02"]= parseFloat(veri1);
	      sdd[yil + "03"]= parseFloat(veri2);
	      sdd[yil + "04"] = parseFloat(veri3);
	      sdd[yil + "05"] = parseFloat(veri4);
	      sdd[yil + "06"] = parseFloat(veri5);
	      sdd[yil + "07"] = parseFloat(veri6);
	      sdd[yil + "08"] = parseFloat(veri7);
	      sdd[yil + "09"] = parseFloat(veri8);
	      sdd[yil + "10"] = parseFloat(veri9);
	      sdd[yil + "11"] = parseFloat(veri10);
	      sdd[yil + "12"] = parseFloat(veri11);



	});



return sdd;

}


function tahakkukSorgula(token,vkn,vd,vergiKodu){

try{
var callid=makeid(13) + '-';
var org_id=orgIDGetir(vd);
     

		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTahakkukService_tahakkukSorgula&callid='; 
		var url5=url5.concat(callid + '154', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vergiKodu%22%3A%22',vergiKodu,'%22%2C%22basDonem%22%3A%22%22%2C%22bitDonem%22%3A%22%22%2C%22orgOid%22%3A%22',org_id,'%22%2C%22durum%22%3A%222%22%7D');
		var liste = getRemote(url5);
		var obj =JSON.parse(liste);

		var tahakkukSayisi=obj.data.length;

	    if (tahakkukSayisi==0) { return "Tahakkuk Yok" ; } else { return "Tahakkuk Var"; }


}

	catch(err){

		return (err);

	}	

}

function tarhiyatSorgula(token,vkn,vd,vergiKodu){

try{
var callid=makeid(13) + '-';
var org_id=orgIDGetir(vd);
     
	
		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTarhiyatService_tarhiyatSorgula&callid='; 
		var url5=url5.concat(callid + '19', '&token=', token, '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vergiKodu%22%3A%22',vergiKodu,'%22%2C%22basDonem%22%3A%22%22%2C%22bitDonem%22%3A%22%22%2C%22orgOid%22%3A%22',org_id,'%22%2C%22ihbDurum%22%3A%226%22%7D');
		var liste = getRemote(url5);
		var obj =JSON.parse(liste);


		var tarhiyatSayisi=obj.data.length;

		if (tarhiyatSayisi==0) { return "Tarhiyat Yok" ; } else { return "Tarhiyat Var"; }

}


catch(err){

return (err);

}
}


function updateRowNumbers() {
    const table = document.getElementById("myTable24");
    const rows = table.tBodies[0].rows;
    for (let i = 1; i < rows.length; i++) {
        rows[i].cells[0].innerText = i ;
    }
}

function topluIslemKayitGetir(token){


		var callid=makeid(13) + '-';


		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=tdiService_topluIslemKayitGetir&callid='; 
		var aktifVdKodu = (typeof vdKodu==='function' ? vdKodu() : '');
		var url5=url5.concat(callid + '174', '&token=', token, '&jp=%7B%22vdKodu%22%3A%22',aktifVdKodu,'%22%2C%22islemCesitNo%22%3A%221%22%7D');
		var liste = getRemote(url5);
		var obj =tkParse(liste,'topluIslemKayitGetir');
		var veri=obj.data[0].text;
		veri=veri.split("/");
		var yeni=veri[0] + "%2F" +  veri[1]  + "%2F" + veri[2]

		return yeni;


}


function tableToCSV() {
    // CSV verileri için array
    var csvData = [];
    
    // CSV başlık satırı
    var headers = [
        "Sorgu Tarihi",
        "Vergi Dairesi", 
        "VKN",
        "Ünvan",
        "Faal/Terk",
        "Tahsil Güçlüğü",
        "Toplam Borç Tutarı",
        "Toplam Vergi Borcu Aslı Tutarı",
        "Toplam Mahsup",
        "Zamanaşımlı Borç",
        "VD Borç tutarı",
        "VD Mahsup tutarı",
        "İhtisas Borç tutarı",
        "İhtisas Mahsup tutarı",
        "EHaciz Cari Adet",
        "EHaciz Son Tarih",
        "Taşıt Aktif Adet",
        "Taşıt Yakalama",
        "Taşıt Haciz Son Tarih",
        "Ortak Takip Son Tarih",
        "Mal Varlık Son Tarih",
        "Emanet Tutarı",
        "Cari Tahsilat",
        "Cari Tahsilat Son Tarih"
    ];
    
    // Başlıkları CSV'ye ekle
    csvData.push(headers.join(","));
    
    return csvData;
}


function escapeCsvField(field) {
    if (field === null || field === undefined) {
        return "";
    }
    
    field = String(field);
    
    // Virgül, çift tırnak veya satır sonu içeriyorsa çift tırnak ile sar
    if (field.includes(",") || field.includes('"') || field.includes("\n")) {
        // İçerideki çift tırnakları iki katına çıkar
        field = field.replace(/"/g, '""');
        field = '"' + field + '"';
    }
    
    return field;
}


function downloadCSV(csvContent, filename) {
    // BOM (Byte Order Mark) ekle - Türkçe karakterler için
    var BOM = "\uFEFF";
    var csvData = BOM + csvContent;
    
    // Blob oluştur
    var blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    
    // Download linki oluştur
    var link = document.createElement("a");
    if (link.download !== undefined) {
        var url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}


function exportTableToCSV(tableId, filename) {
    var csv = [];
    var table = document.getElementById(tableId);
    var rows = table.querySelectorAll("tr");
    
    for (var i = 0; i < rows.length; i++) {
        var row = [];
        var cols = rows[i].querySelectorAll("td, th");
        
        for (var j = 0; j < cols.length; j++) {
            var cellText = cols[j].innerText || cols[j].textContent || "";
            // CSV için escape et
            if (cellText.includes(",") || cellText.includes('"') || cellText.includes("\n")) {
                cellText = cellText.replace(/"/g, '""');
                cellText = '"' + cellText + '"';
            }
            row.push(cellText);
        }
        
        csv.push(row.join(","));
    }
    
    // CSV'yi indir
    downloadCSV(csv.join("\n"), filename);
}


function malvarligiSorgulama(token,vkn,vd){

try{
		var callid=makeid(13) + '-';

		var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=malVarligiService_mhkTumMalVarligiBilgileriPdfGetir&callid='; 
		var url5=url5.concat(callid + '23', '&token=', token, '&jp=%7B%22tckn%22%3A%22%22%2C%22vkn%22%3A%22',vkn,'%22%2C%22unvan%22%3A%22%22%2C%22basTar%22%3A%2220230811%22%2C%22bitTar%22%3A%222200-01-01%22%2C%22mukellefVdKodu%22%3A%22',vd,'%22%7D');
		var liste = getRemote(url5);
		var obj =JSON.parse(liste);

		var kayitSayisi=obj.data.malVarligiJSONArray.length;

		if (kayitSayisi>0) { 

		return tarihFormat3((obj.data.malVarligiJSONArray[(kayitSayisi-1)].optime).substr(0,8)); 

		}else{ 

		return "";

		}


}


catch(err){

return "Hata";

}


}


function borcDurumuGetir(vkn,token,tabloID,vadeTar1,vadeTar2){


	
	var callid=makeid(13) + '-';
	var vadesiGecmis=0;
//	var orgID=orgIDGetir(vdkodu);
    var vd_listesi= hangiVD4(vkn,token);
	

	$('#tablo'+ tabloID).after('<table id="myTable702" border=1> <caption>Borç Durumu Sorgulama</caption><tr><th>VD</th><th>Vergi Borcu Aslı</th><th>Gecikme Zammı</th><th>Toplam Ödenmesi Gereken</th><th>Vadesi Gelmemiş</th><th></th></tr></table>');


		$.each(vd_listesi, function(index, vd){
			 
			var url= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=borcService_borcBilgileriGetir&callid=';
			var url=url.concat(callid + '120', '&token=', token, '&jp=%7B%22input%22%3A%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22anaVergiKodu%22%3A%22%22%2C%22vergiKodu%22%3A%22%22%2C%22vergilendirmeDonemiBas%22%3A%22%22%2C%22vergilendirmeDonemiBit%22%3A%22%22%2C%22vadeBasTarih%22%3A%22',vadeTar1,'%22%2C%22vadeBitTarih%22%3A%22',vadeTar2,'%22%2C%22satirlar%22%3A%22447%22%2C%22detayliOzet%22%3A%222%22%7D%7D');
			var borc = getRemote(url);
			var obj =tkParse(borc,'borcDurumuGetir');
	
			if (obj.data.aVadesiGecmis!=undefined){ 
	
			 		$("#myTable702 tr:last").after( "<tr><td>" + vd  + "</td><td>" + tlCevir(obj.data.aVadesiGecmis)  + "</td><td>" + tlCevir(obj.data.kOdenmesiGerekenToplamGecikmeZammi)  + "</td><td>" + tlCevir(obj.data.mVadesiGecmisBugunOdenmesiGerekenTop)  + "</td><td>" + tlCevir(obj.data.bVadesiGelmemis)  + "</td><td><a href='diger_borc_detay_getir.html?vkn=" + vkn + "&token=" + token + "' target='_blank'>Borç detayı için tıklayınız</a></td></tr>");


			}

			
		});


}



function tlCevir(veri){

if (veri!="" || veri!="-" ){

	return ((Number(veri)).toLocaleString("tr-TR"));

}else{

	return 0;

}

}

function parseMoney(val){
    if (val === null || val === undefined) return 0;
    if (typeof val === "number") return val;

    val = String(val)
        .replace(/\./g, "")
        .replace(",", ".")
        .replace(/[^\d.-]/g, "");

    var num = parseFloat(val);
    return isNaN(num) ? 0 : num;
}



function mahsupKalanTutarSorgulama(token,vkn,vd,dosyaNo){

try{
var callid=makeid(13) + '-';

//

	var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=iadeMahsupService_iadeMahsupSorgulamaDetay&callid='; 
   
	var url6=url6.concat(callid + '159', '&token=', token , '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22iadeDosyaNo%22%3A%22',dosyaNo,'%22%2C%22dilekceTipi%22%3A%22%22%2C%22donem%22%3A%22%22%2C%22vKodu%22%3A%22%22%2C%22iadeSatir%22%3A%22%22%7D');
		

	var liste1 = getRemote(url6);
	var obj1 =JSON.parse(liste1);	
	
	var kalanTutar=obj1.data.genelbilgiler[0].emanetkalantutar;


	return kalanTutar;
	

}

catch(err){

console.log(err);

return "Hata ile karşılaşıldı";

}

}

function tecilEdilenTutar(token,vkn,vd,tecilDosyaNo){

try{
var callid=makeid(13) + '-';

var tecilDilekceNo="";

var tecilDilekceTarihi="";

var orgID=orgIDGetir(vd);

	var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTecilService_tecilDetayGetir&callid='; 
	var url6=url6.concat(callid + '45', '&token=', token , '&jp=%7B%22input%22%3A%7B%22tecilDosyaNo%22%3A%22',tecilDosyaNo,'%22%2C%22tecilDilekceNo%22%3A%22',tecilDilekceNo,'%22%2C%22tecilDilekceTarihi%22%3A%22',tecilDilekceTarihi,'%22%2C%22tecildenKaldirmaTarihi%22%3A%22%22%2C%22tecildenKaldirmaNedeni%22%3A%22Aktif%22%2C%22ortakVkn%22%3A%22%22%2C%22ortakTckn%22%3A%22%22%2C%22plakano%22%3A%22%22%2C%22tecilTuru%22%3A%226183%2F48%20Tecil%22%2C%22vdKodu%22%3A%22',vd,'%22%2C%22orgOid%22%3A%22',orgID,'%22%2C%22tecilTipi%22%3A%22%22%7D%7D');
	var liste1 = getRemote(url6);
	var obj1 =JSON.parse(liste1);	
	
	var tecilToplamVab=obj1.data.tecilToplamVab;
	var tecilToplamGz= obj1.data.tecilToplamGz;
	var tecilOdenenToplamVab=obj1.data.tecilOdenenToplamVab;
	var tecilOdenenToplamGz=obj1.data.tecilOdenenToplamGz;
	var tecilOdenenToplamTecilFaizi=obj1.data.tecilOdenenToplamTecilFaizi;


	return (tecilToplamVab + "-" + tecilToplamGz + "-" + tecilOdenenToplamVab + "-" + tecilOdenenToplamGz + "-" + tecilOdenenToplamTecilFaizi ) ;
	

}

	catch(err){

	console.log(err);

	return "Hata ile karşılaşıldı";
	}

}


function tahakkukTahsilat(token,vkn,vd,thkFisNo){

try{

var callid=makeid(13) + '-';

var orgID=orgIDGetir(vd);
var toplamOdenen=0;
var odemeBelgeNo="";
	var url6= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=mhkTahakkukService_tahakkukOPSSorgula&callid='; 
	var url6=url6.concat(callid + '143', '&token=', token , '&jp=%7B%22orgOid%22%3A%22',orgID,'%22%2C%22thkFisNo%22%3A%22',thkFisNo,'%22%7D');
	var liste1 = getRemote(url6);
	var obj1 =JSON.parse(liste1);	

	
	$.each(obj1.data, function(index, satir){

	toplamOdenen = toplamOdenen + satir.odenen;
	odemeBelgeNo =satir.odemeBelgeNo;


	});
	


	return (odemeBelgeNo + "-" + tlCevir(toplamOdenen) ) ;
	

}

	catch(err){

	console.log(err);

	return "Hata-Hata";
	}

}



function tahsilatSekli(veri) {

var liste={
"0": "Vezne",
"1": "Banka",
"4": "Başka Saymanlık Tarafından",
"8": "Hacizli Malların Satışı",
"16": "Tahsildar/İcra Memuru",
"32": "Manuel",
"64": "Mahsuben"
}

return liste[veri];

}


function emanetTuru(veri) {

var liste={
"17": "17 Ticaret Sicil Paylarından Oda Payları",
"18": "18 Esnaf ve Sanatkarlar Sicil Harçlarından Oda Payları",
"21": "21 Diğer Resmi Daire ve Kurumlara Ait Tahsilatlar",
"22": "22 Ölen Kimselere Ait Paralar",
"23": "23 Hacizli Mallar Satışından Artan Paralar",
"24": "24 2978 Sayılı Kanun Gereği Yapılacak Vergi İadeleri",
"25": "25 3065 Sayılı Kanun Gereği Yapılacak KDV İadesi",
"26": "26 Vergi Gelirlerinden Yapılacak İadeler",
"27": "27 İhracat İstisnasından Alınan KDV",
"28": "28 Özel Gider İndiriminden Emanet",
"29": "29 Vergi Dışı Gelirlerden Yapılacak İadeler",
"30": "30 4915 Sayılı Kanun Uyarınca Tahsil Edilen Tutarlardan Emanetler",
"31": "31 Bütçe Gelirlerinden Yersiz Tahsilat",
"32": "32 Diğer Fazla ve Yersiz Tahsilat",
"33": "33 Kişilere Ait Diğer Emanetler",
"34": "34 Niteliği Belli Olmayan Paralar",
"39": "39 Diğer Çeşitli Emanetler",
"42": "42 4811 Sayılı Kanun Uyarınca Yapılan Kesinlenmiş Kamu Al. Tahsilat",
"43": "43 Geçici Teminatlar",
"44": "44 Vergi Teminatları",
"45": "45 Akaryakıt Dışındaki Maddelerin İthalinde Sağlanan Fonlar",
"46": "46 Fonlar Adına Yapılan Diğer Kesintiler",
"47": "47 Şeker Fiyat Farkları",
"48": "48 Akaryakıt Fiyat Farkları",
"49": "49 Yiyecek Bedelleri",
"50": "50 Kur Farkları",
"51": "51 Yüksek Öğretim Kredi Borçları",
"52": "52 Yüksek Öğretim Harç Kredisi Borcu",
"53": "53 İhracatta Vergi İadesi",
"54": "54 Destekleme Ve Fiyat İstikrar Fonu",
"55": "55 3516 Sayılı Ölçüler Ve Ayarlar K.Göre Kes.İd.Para Cezaları",
"56": "56 Resmi Arabuluculuk Ücreti",
"57": "57 2634 S.K.Göre Kes.Para Cezaları",
"58": "58 3984 S.K.Göre Tahsil Ed.Reklam Gel.",
"59": "59 2547 sayılı Kanunun 46.Maddesine Göre Öğr.Al.Cari Hizmet Katkı Payları",
"60": "60 4054 saylı Rekabetin Korunması Hak.Kan.Ver.Para Cezaları",
"61": "61 Küçük ve Ortaboy işletmelere KDV Desteği",
"62": "62 Kaldırılan Özel Tahakkuk Artıkları",
"63": "63 Diğer Özel Tahakkuklar",
"64": "64 Sporda Şiddetin Önlenmesine İlişkin İdari Para Cezaları",
"65": "65 406 ve 2813 S. K. Ger. Tahsil Edilen İd. Para C.",
"66": "66 4857 Sayılı Kanunun 101 Maddesi  Uyarınca Kesilen İdari Para Cezaları",
"67": "67 Kapatılamayan Gönderme Emirleri",
"68": "68 Enerji Piyasasi Düzenleme Kurumu Analiz Bedelleri",
"69": "69 4447 sayılı İşsizlik Sigortası Kanunu Uyarınca Kesilen İdari Para Cezaları",
"70": "70 4904 sayılı İş Kurumu Kanunu Uyarınca Kesilen İdari Para Cezaları",
"71": "71 2762 Sayılı Kanuna Göre Alınan Taviz Bedelleri",
"72": "72 Kılavuzluk ve Romörkoj Hizmet Gelirleri",
"73": "73 Madenlerden Alınan Devlet Hakkının %30 Fazlaları (Orman Genel Müd.)",
"74": "74 Madenlerden Alınan Devlet Hakkından %50 İl Özel İdare Payı",
"75": "75 Enerji Piyasası Düzenleme Kurumu Petrol Katılım Payı",
"76": "76 Yabancı Devletlere Ait Vergi Tahsilatları",
"77": "77 Yerli ve Yabancı Film Gösterimler Bilet Bedellerinden Emanetler",
"78": "78 Savunma Sanayi Destekleme Fonu Katılım Payı(3238 S.K.13/2 Maddesi Uyarınca Alınan)",
"79": "79 Savunma Sanayi Destekleme Fonu Katılım Payı(1473 S.K. 4.Maddesi Uyarınca 6183 S.K. Göre Alınan %10 Fazlası ile Birlikte)",
"80": "80 3359 Say.Kan.Göre Tahsil Edilecek Fatura Bedelleri",
"81": "81 6001 S.K. Karayolları Kaçak Geçiş Ücretleri",
"82": "82 Suriye Uyruklulara Ait Taşınır ve Taşınmaz Mal Gelirleri",
"83": "83 Madenlerden Alınan Devlet Hak.dan %25 Köylere Hiz.Götürme Bir. Payı",
"84": "84 Kamu İhale Kurumu Gelirleri Tahsilatı",
"85": "85 3039 S. Çeltik Ekimi Kanunu Uyarınca Tahsil Edilen İdari Para Cezaları",
"86": "86 Bilgi Tek. Ve İletişim Kur.Adına Tahsil Ed.İdari Para Cez.",
"87": "87 Tarım Satış Koop.Birlik.Des.Fiy.İstk.Fonu Kayn.Alacak",
"88": "88 DSİ Genel Müdürlüğünün 6111 S.K. Alacak Tahsilatı",
"89": "89 Zirai Ürünlerden Borsada Yapılan Tevkifatlardan Emanete Alınanlar",
"90": "90 Eximbank AlacaklarÕ (Gel.Des.Fon.Tasfiyesi Irak AlacaklarÕ )",
"91": "91 5809 sayılı Elektronik Haberleşme Kanunu Kullanım Hakkı Ücretleri",
"92": "92 Bireysel Emeklilik Sistemi Kapsamında Yapılacak İadeler",
"93": "93 5809 S.K Gereğince B.T.K Adına Tahsil Edilen İdari Ücret",
"97": "97 ÇIPC Dönüşüm Gelirleri ve Karayolları Payı",
"98": "98 ÇKP Dön.Gel.",
"99": "99 Diğer Özel Tahakkuklardan Emanete Alınanlar",
"100": "100 2863 S.K. Taşınmaz Kültür Varlıklarının Korunmasına Ait Katkı Payı",
"101": "101 ÖTV Kanunu Eki (B) Cetvelindeki Mallar İçin Alınan Nakit Teminatlar",
"102": "102 GSM işletmecileri bürüt satışlarının %15 hazine payının %90ı",
"103": "Serbest Bölge Gelirleri",
"104": "104 VUK 153/A Maddesi Kapsamındaki Teminatlar",
"105": "105 GVK Mükerrer Madde 121 Vergiye Uyumlu Mükelleflere Vergi Indirimi",
"106": "106 İkale ve Karşılıklı Sonlandırma Sözleşmesi G. Stopaj İadesi",
"107": "107 İkale ve Karşılıklı Sonlandırma Sözleşmesi G. Stopaj İadesi Mahsup",
"108": "108 7183 sayılı Kanun Gereğince Ajanslara Aktarılacak Turizm Payı",
"109": "109 5809 S. K. Gereğince B.T.K. Adına Tahsil Edilen İdari Ücret",
"110": "110 2918 s.Karayolları Trafik Kanununun131 inci Md.Göre Aktarılmayan Paylar",
"111": "111 VUK 160/A Maddesi Kapsamındaki Teminatlar",
"112": "112 6306 S. Kanun Gereğince Belediyelerden Al. Çevre Katkı Payı",
"113": "113 VUKGT/531 5. Madde Kapsamındaki Teminatlar",
"114": "114 VUKGT/531 6. Madde Kapsamındaki Teminatlar",
"115": "115 5846 sayılı Fikir ve Sanat Eserleri Kanununun 44 üncü Maddesi Gereğince Elde Edilen Gelirler",
"116": "116 Tarımsal Destek Ödemesi Vergi Kesintisi İadeleri",
"117": "117 Diğer Kurumlar Adına Takip Edilen Kişilerden Alacaklar",
"118": "118 ÖTV (II) sayılı Liste Kapsamında Araç Ticareti Teminatı",
"119": "119 TERRA 2A KREDİSİ CEZAİ FAİZİ 6183 Sayılı Kanuna Göre Tahsil Edilen Diğer Tutarlar",
"120": "120 TERRA 2A KREDİSİ GECİKME ZAMMI 6183 Sayılı Kanuna Göre Tahsil Edilen Diğer Tutarlar",
"121": "121 Maden Arama Ruhsat Bedeli",
"122": "122 Maden İşletme Ruhsat Bedeli (Çevre Uyum Masraf Karşılıkları %30 Teminat İçin Alınan)",
"123": "123 Maden İşletme Ruhsat Bedeli (Çevre Uyum Masraf Karşılıkları %20 Kurum Geliri)",
"124": "124 Elektrik Piyasa Lisans Bedeli",
"125": "125 DoÄal Gaz Piyasası Lisans Bedeli",
"126": "126 DoÄal Gaz Piyasası Katılma Payı",
"127": "127 Ecrimisil Gelirleri (Gençlik ve Spor Bakanlığı)",
"128": "128 SGK KOSGEB Destek Ödeme Emanetleri",


}

if (liste[veri]==undefined){ return veri; } else { return (liste[veri]); } 

}




function tasitHacizDurum(veri) {

var liste={
"3": "HACİZ",
"35": "YAKALAMA",
"50": "SATIŞ ARZ",
"49": "KESİN SATIŞ",
}

return liste[veri];

}


function takdiyatDurum(veri) {

var liste={
"7": "MÜLKİYETLİ (M)",
"8": "REHİNLİ (R)",
"18": "HACİZLİ YAKALAMALI",
"41": "İHTİYATİ TEDBİR-2",
"4": "İH.TEDBİR (T)",
"3": "HACİZLİ",
"43": "İHTİYACİ HACİZ",
"35": "YAKALAMA",
"50": "SATIŞ ARZ",
"49": "KESİN SATIŞ",
"2": "DİĞER(D)"
}

if (liste[veri]==undefined){ return veri; } else { return (liste[veri]); } 


}


function ozesGirisNedeni(veri){

     var girisNedeni = {'001':'001 - Sahte Belge Düzenleme Raporu' ,
		      '002':'002 - Muhteviyatı İtibariyle Yanıltıcı Belge Düzenleme Raporu', 
		      '003':'003 - Sahte Belge Kullanma Raporu',
		      '004':'004 - Muhteviyatı İtibariyle Yanıltıcı Belge Kullanma Raporu',
		      '010':'010 - Sahte Belge Düzenleme Tespiti',
		      '011':'011 - Muhteviyatı itibariyle yanıltıcı Belge Düzenleme Tespiti',
		      '012':'012 - Sahte Belge Kullanma Tespiti',
		      '013':'013 - Muhteviyatı itibariyle yanıltıcı Belge Kullanma Tespiti',
		      '014':'014 - Adreste Bulunamama',
		      '015':'015 - Defter Belge İbraz Etmeme',
		      '016':'016 - İhtiyati Tahakkuk İhtiyati Haciz',
		      '017':'017 - Hakkında Olumsuz Rapor Bulunanlardan Mal ve Hizmet Alanlar',
		      '018':'018 - Hakkında Olumsuz Tespit  Bulunanlardan Mal ve Hizmet Alanlar',
		      '153':'153 - 153/A Kapsamında Sahte Belge Düzenleme Raporu',
		      '001.012' :'001.012 - Sahte Belge Kullanma Tespiti',
		      '153.012' : '153.012 - Sahte Belge Kullanma Tespiti',
		      '153.010' : '153.010 - Sahte Belge Düzenleme Tespiti',
		      '153.050' : '153.050 - 153A Kapsamında bulunan Mükellefin Ortağı',
		      '153.060.090' : '153.060.090 - 153A Kapsamında bulunan Mükellefin Kanuni Temsilcisinin Kanuni Temsilcisi Olduğu Şirket/İşletme',
			  '153.015' : '153.015-Defter Belge İbraz Etmeme',
			  '153.050.070':'153.050.070-Ortağının Ortak Olduğu Şirket/İşletme',
			  '010.050.070':'010.050.070-Ortağının Ortak Olduğu Şirket/İşletme'
};
  
if (girisNedeni[veri]==undefined){ return veri; } else { return (girisNedeni[veri]); } 

}



function ozesTabloGetir(tokenlink,vkn,tabloID='22') {

	
try{
	var callid=makeid(13) + '-';
	
$('#tablo'+ tabloID).after('<table id="myTable" border=1><caption>Mükellef Sicil Bilgilerine Göre Olumsuz Rapor / Olumsuz Tespit Sorgu Ekranı</caption><th>TESPİT TÜRÜ</th><th>İNCELEME DÖNEMİ</th><th>VİR TARİH/SAYI</th><th>GELİŞ TARİHİ</th><th>Diğer Açıklama</th></table>');

	var url= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_mukellefSorgulamaSonucListesiGetirDurumMain&callid=';
	var url=url.concat(callid + '122', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%7D');
	var olumsuzluk = getRemote(url);
	var obj =JSON.parse(olumsuzluk);
	
	if (obj.data.listBir=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listBir%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

	if (obj.data.listIki=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listIki%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);



			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td> Dayanak Firma :' + satir.vkn  + "-" + satir.unvan + "-" + satir.vd + '</td></tr>');

			});


		}

	if (obj.data.listUc=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listUc%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}
		    
	if (obj.data.listDort=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listDort%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

	if (obj.data.listBes=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listBes%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

	if (obj.data.listAlti=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listAlti%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

	if (obj.data.listYedi=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listYedi%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

	if (obj.data.listSekiz=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listSekiz%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

if (obj.data.listDokuz=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listDokuz%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}
	
	
	if (obj.data.listOn=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listOn%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}


if (obj.data.listOnbir=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listOnbir%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

if (obj.data.listOniki=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listOniki%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru)+ '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}
	
if (obj.data.listOnuc=="visible"){

			var url1= 'http://10.251.63.99/ozes_server/dispatch?cmd=ozesOlumsuzTespitService_olumsuzTespitDetayGetir&callid=';
			var url1=url1.concat(callid + '124', '&token=', tokenlink, '&jp=%7B%22mukVkn%22%3A%22',vkn,'%22%2C%22mukTckn%22%3A%22%22%2C%22durum%22%3A%222050%22%2C%22listName%22%3A%22listOnuc%22%7D');
			var liste1 = getRemote(url1);
			var obj1 =JSON.parse(liste1);

			$.each(obj1.data, function(index1, satir){



			$('#myTable tr:last').after( '<tr><td>' + ozesGirisNedeni(satir.tespitTuru) + '</td><td>' + satir.incelemeDonemi  + '</td><td>' + tarihFormat(satir.raporTarihi) + "//" + satir.raporSayisi   + '</td><td>' + tarihFormat(satir.intikalTarihi) + '</td><td></td></tr>');

			});


		}

	
}

catch(err){

console.log(err);
}	
	
	}


function getPreviousDayShort(date = new Date()) {
  const prev = new Date(date);
  prev.setDate(prev.getDate() - 1);
  return prev.toISOString().split('T')[0].replace(/-/g,'');
}

function getPreviousDayShort2(date = new Date()) {
  const prev = new Date(date);
  prev.setDate(prev.getDate() - 2);
  return prev.toISOString().split('T')[0].replace(/-/g,'');
}



   // ✅ Memory Management - Bellek sızıntılarını önleme
   function cleanupResources() {
       try {
           // Event delegation listener'ları temizle
           $(document).off('click', '[id^="go"]');
           $(document).off('click', '[data-action]');
           $(document).off('click', '.modal-actions button');
           
           // Eski event listener'ları temizle (geriye uyumluluk için)
           $(document).off('click.customHandler');
           
           // Global değişkenleri temizle
           if (typeof currentModalData !== 'undefined') {
               currentModalData = null;
           }
           
           // Cache'i temizle (eğer CacheManager varsa)
           if (typeof CacheManager !== 'undefined' && CacheManager.clear) {
               CacheManager.clear();
           }
           
           // Modal buton bayraklarını temizle
           if (typeof modalButtonsRunning !== 'undefined') {
               Object.keys(modalButtonsRunning).forEach(key => {
                   modalButtonsRunning[key] = false;
               });
           }
           
           // Global modal işlem bayrağını temizle
           if (typeof globalModalProcessing !== 'undefined') {
               globalModalProcessing = false;
           }
           
           console.log('🧹 Memory cleanup completed successfully');
       } catch (error) {
           console.warn('Memory cleanup warning:', error.message);
       }
   }
   
   // ✅ Page unload'ta bellek temizliği
   window.addEventListener('beforeunload', cleanupResources);
   
   // ✅ Periyodik bellek temizliği (5 dakikada bir)
   setInterval(cleanupResources, 300000);
   
   // ✅ Büyük veri işlemlerinden sonra bellek temizliği
   function performDataOperation(operation) {
       return new Promise(async (resolve, reject) => {
           try {
               const result = await operation();
               cleanupResources(); // İşlem sonrası bellek temizliği
               resolve(result);
           } catch (error) {
               cleanupResources(); // Hata durumunda da bellek temizliği
               reject(error);
           }
       });
   }



   // Global jQuery safety wrapper
   var jQueryReady = false;
   var jQueryCallbacks = [];
   
   // Safe jQuery wrapper function
   function safeJQuery(callback) {
     if (typeof $ !== 'undefined' && jQueryReady) {
       callback();
     } else {
       jQueryCallbacks.push(callback);
     }
   }
   
   // Wait for jQuery to be available
   function waitForJQuery() {
     if (typeof $ !== 'undefined') {
       jQueryReady = true;
       // Execute all pending callbacks
       jQueryCallbacks.forEach(function(callback) {
         try {
           callback();
         } catch (e) {
           console.warn('jQuery callback error:', e);
         }
       });
       jQueryCallbacks = [];
     } else {
       setTimeout(waitForJQuery, 50);
     }
   }
   
   // Start waiting for jQuery
   waitForJQuery();
   
   // Token Modal Management - Wait for jQuery to load
   function initTokenManagement() {
     // Check if token exists in localStorage
     var savedToken = localStorage.getItem('gibToken');
     if (!savedToken) {
       updateTokenStatus('invalid', '❌ Oturum gerekli');
     } else {
       updateTokenStatus('valid', '✅ Oturum aktif');
     }
   }
   
   // Initialize token management when jQuery is ready
   safeJQuery(initTokenManagement);

   function showTokenModal() {
     safeJQuery(function() {
       $('#tokenModal').show();
       $('#tokenInput').focus();
       updateTokenStatus('invalid', '❌ Oturum gerekli');
     });
   }

   function hideTokenModal() {
     safeJQuery(function() {
       $('#tokenModal').hide();
     });
   }

     function updateTokenStatus(status, message) {
    safeJQuery(function() {
      var statusElement = $('#floatingTokenStatus');
      var tokenEnterButton = $('#floatingTokenEnter');
      var tokenRefreshButton = $('#floatingTokenRefresh');
      
      statusElement.removeClass('valid invalid loading').addClass(status);
      
      if (status === 'invalid') {
        statusElement.show().text(message);
        tokenEnterButton.show();
        tokenRefreshButton.hide();
      } else if (status === 'valid') {
        //statusElement.show().text(message);
        tokenEnterButton.hide();
        tokenRefreshButton.show();
      } else {
        statusElement.show().text(message);
        tokenEnterButton.hide();
        tokenRefreshButton.hide();
      }
    });
  }

   function refreshToken() {
     localStorage.removeItem('gibToken');
     updateTokenStatus('invalid', '❌ Oturum gerekli');
   }

   // Token modal event handlers - Wait for jQuery
   function initTokenEventHandlers() {
     $('#tokenSubmit').click(function() {
       var tokenInput = $('#tokenInput').val().trim();
       if (!tokenInput) {
         alert('Lütfen GIB Intranet oturum linkini giriniz.');
         return;
       }

       /* Extract token from the link
       var myRegexp = /token=(\S+)/;
       var tokenMatch = myRegexp.exec(tokenInput);
       
       if (!tokenMatch || !tokenMatch[1]) {
         alert('Geçersiz oturum linki. Lütfen doğru GIB Intranet linkini giriniz.');
         return;
       }

       // Validate token format (basic check)
       var tokenValue = tokenMatch[1];
       if (tokenValue.length < 10) {
         alert('Token çok kısa görünüyor. Lütfen doğru GIB Intranet linkini giriniz.');
         return;
       }

	*/
       // Token validation temporarily disabled - directly save token
       localStorage.setItem('gibToken', tokenInput);
       
       // Hide modal and update status
       hideTokenModal();
       updateTokenStatus('valid', '✅ Oturum aktif');
       
       // Clear input
       $('#tokenInput').val('');
     });

     $('#tokenCancel').click(function() {
       hideTokenModal();
       // Show the "Oturum Gir" button if no token is saved
       if (!localStorage.getItem('gibToken')) {
         $('#floatingTokenEnter').show();
       }
     });

     // Close modal when clicking outside
     $('#tokenModal').click(function(e) {
       if (e.target === this) {
         hideTokenModal();
         // Show the "Oturum Gir" button if no token is saved
         if (!localStorage.getItem('gibToken')) {
           $('#floatingTokenEnter').show();
         }
       }
     });

     // Handle Enter key in token input
     $('#tokenInput').keypress(function(e) {
       if (e.which === 13) {
         $('#tokenSubmit').click();
       }
     });
   }
   
   // Initialize event handlers when jQuery is ready
   safeJQuery(initTokenEventHandlers);

   // Helper function to check token before executing functions
   function checkTokenBeforeExecute() {
     if (!token()) {
       updateTokenStatus('invalid', '❌ Oturum gerekli');
       return false;
     }
     return true;
   }

   // Helper function to get VKN/TCNO with localStorage support
   function getVKNWithDefault(message) {
     var defaultValue = localStorage.getItem('lastVKN') || '';
     var input = prompt(message, defaultValue);
     if (input && input.trim()) {
       localStorage.setItem('lastVKN', input.trim());
       return input.trim();
     }
     return null;
   }


function getTaxInvitationReasons(veri) {
  aciklama= {
    "1": "Ba-Bs Bildirim Formlarında Yer Alan Bilgilerin Analizi Sonucunda Mükelleflerin İzaha Davet Edilmesi",
    "2": "Kredi Kartı Satış Bilgileri ile Katma Değer Vergisi (KDV) Beyannamelerinin Karşılaştırılması Sonucunda Mükelleflerin İzaha Davet Edilmesi",
    "3": "Yıllık Beyannameler ile Muhtasar ve Prim Hizmet Beyannamelerinin Karşılaştırılması Sonucunda Mükelleflerin İzaha Davet Edilmesi",
    "4": "Çeşitli Kurum ve Kuruluşlardan Elde Edilen Bilgiler ile Asgari Ücret Tarifelerinin Karşılaştırılması Sonucunda Mükelleflerin İzaha Davet Edilmesi",
    "5": "Yıllık Gelir ve Kurumlar Vergisi Beyannameleri Üzerinde Yapılan İndirimleri, Kanuni Oranları Aşan Mükelleflerin İzaha Davet Edilmesi",
    "6": "Dağıttığı Kâr Üzerinden Tevkifat Yapmadığı Tespit Edilenlerin İzaha Davet Edilmesi",
    "7": "Geçmiş Yıl Zararlarının Mahsubu Yönünden Mükelleflerin İzaha Davet Edilmesi",
    "8": "İştirak Kazançlarını İlgili Hesapta Göstermeyen Mükelleflerin İzaha Davet Edilmesi",
    "9": "Kurumlar Vergisi Kanununun 5/1-e Maddesindeki İstisna ile İlgili Olarak Mükelleflerin İzaha Davet Edilmesi",
    "10": "Örtülü Sermaye Yönünden Mükelleflerin İzaha Davet Edilmesi",
    "11": "Ortaklardan Alacaklar İçin Hesaplanması Gereken Faizler Yönünden Mükelleflerin İzaha Davet Edilmesi",
    "12": "Ortaklık Hakları veya Hisselerini Elden Çıkardıkları Halde Beyanda Bulunmayan Limited Şirket Ortaklarının İzaha Davet Edilmesi",
    "13": "Gayrimenkul Alım/Satım Bedelinin Eksik Beyan Edilmiş Olabileceğine Dair Haklarında Tespit Bulunanların İzaha Davet Edilmesi",
    "14": "Gayrimenkullere İlişkin Değer Artışı Kazançları Yönünden Mükelleflerin İzaha Davet Edilmesi",
    "15": "Gayrimenkul Sermaye İratlarını Beyan Etmeyen veya Eksik/Hatalı Beyan Eden Mükelleflerin İzaha Davet Edilmesi",
    "17": "VUK Hükümlerine Göre Hatalı Reeskont İşlemleri",
    "18": "Değersiz Hale Gelen Alacaklarda KDV Düzeltmesi",
    "19": "Yurtdışından Para Transferi Suretiyle Elde Edilen Gelirin Beyan Edilmemesi",
    "20": "Yıllık Gelir Veya Kurumlar Vergisi Beyannamelerinde Vergi Matrahının Beyan Edilmemesi/Eksik Beyan Edilmesi",
    "21": "KDV Beyannamelerinde Vergi Matrahının Beyan Edilmemesi/Eksik Beyan Edilmesi",
    "22": "Damga Vergisi Yükümlülüklerini Eksik/Hatalı Beyan Edilmesi",
    "23": "Muhtasar ve Prim Hizmet Beyannameleri Nedeniyle Mükelleflerin İzaha Davet Edilmesi",
    "24": "BSMV'ye Yönelik Mükelleflerin İzaha Davet Edilmesi",
    "25": "Vergisiz Yapılan Akaryakıt Alımları Yönünden Mükelleflerin İzaha Davet Edilmesi"
  };

return aciklama[veri];
}

function izahaDavetİlkTarih(oid,token){

var callid=makeid(13) + '-';

	var url5= 'http://arkaofis.gelbim.gov.tr:32174/izah-server/dispatch?cmd=islemGunluguService_getIslemGunluguKayitlari&callid=';
	var url5=url5.concat(callid + '112', '&token=', token, '&jp=%7B%22izahaDavetOid%22%3A%22',oid,'%22%2C%22respKeyParam%22%3A%22list%22%2C%22pv%22%3A%7B%22start%22%3A0%2C%22limit%22%3A10%2C%22sorters%22%3A%5B%5D%7D%7D');
	var liste = getRemote(url5);
	var obj =tkParse(liste,'izahaDavetİlkTarih');

	return tarihFormat(obj.data.list[obj.data.list.length-1].kayitTarihi);

}


 let sortDirection = {};

        function sortTable(tableName, columnIndex, direction) {
            const table = document.getElementById(tableName);
            const tbody = table.querySelector('tbody');
            const allRows = Array.from(tbody.querySelectorAll('tr'));
            
            // İlk satırı ayır (sabit kalacak)
            const firstRow = allRows[0];
            const rows = allRows.slice(1); // İkinci satırdan itibaren al
            
            const headers = table.querySelectorAll('th');
            
            // Her tablo için ayrı sıralama yönü
            const key = tableName + '_' + columnIndex;
            
            // Sıralama yönünü belirle
            if (!direction) {
                sortDirection[key] = sortDirection[key] === 'asc' ? 'desc' : 'asc';
            } else {
                sortDirection[key] = direction;
            }
            
            const dir = sortDirection[key];
            
            // Tüm header'lardan sınıfları temizle
            headers.forEach(h => h.classList.remove('asc', 'desc'));
            headers[columnIndex].classList.add(dir);
            
            // Satırları sırala
            rows.sort((a, b) => {
                let aVal = a.cells[columnIndex].textContent.trim();
                let bVal = b.cells[columnIndex].textContent.trim();
                
                // Tarih sütunu için özel işlem
                if (columnIndex === 1) {
                    aVal = parseDate(aVal);
                    bVal = parseDate(bVal);
                    return dir === 'asc' ? aVal - bVal : bVal - aVal;
                }
                
                // Sayısal değerler için
                const aNum = parseFloat(aVal.replace(/[^\d,-]/g, '').replace(',', '.'));
                const bNum = parseFloat(bVal.replace(/[^\d,-]/g, '').replace(',', '.'));
                
                if (!isNaN(aNum) && !isNaN(bNum)) {
                    return dir === 'asc' ? aNum - bNum : bNum - aNum;
                }
                
                // Metin karşılaştırması
                return dir === 'asc' 
                    ? aVal.localeCompare(bVal, 'tr')
                    : bVal.localeCompare(aVal, 'tr');
            });
            
            // Sıralanmış satırları tabloya geri ekle
            rows.forEach(row => tbody.appendChild(row));
        }
        
        // Türkçe tarih formatını (GG.AA.YYYY) Date objesine çevir
        function parseDate(dateStr) {
            const parts = dateStr.split('.');
            if (parts.length === 3) {
                // GG.AA.YYYY formatı
                return new Date(parts[2], parts[1] - 1, parts[0]);
            }
            return new Date(dateStr);
        }


function belediyeKontrol(veri) {
  const belediyeVKN = [
    "1620049199", "1620049727", "1620050369", "1620051143", "1660016901",
    "1760038466", "1760954421", "1880055410", "1910006685", "1910023314",
    "1910025989", "1910546222", "1910586525", "1930410371", "1940055392",
    "3910019007", "3910320358", "4490003721", "4490286175", "4680505830",
    "4780031547", "4780031555", "4780836804", "4830348396", "4831360638",
    "4840022518", "6090039607", "6230965968", "6240046436", "6240415188",
    "6240520762", "6310548831", "6310642889", "6320056107", "6370194410",
    "6460366671", "6470000523", "6470762864", "6480053164", "8250083876",
    "9490030940", "9490748988", "9500474080", "9600017193"
  ];
  
  return belediyeVKN.includes(String(veri));
}


function faaliyetBaslangicTarihi(vkn){

try{

	var callid=makeid(13) + '-';

	var url5= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
	var url5=url5.concat(callid + '15', '&token=', token(), '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');
	var daireler = getRemote(url5);
	var obj =JSON.parse(daireler);
	var baslangicMerkezTarih="";
	var mesaj="";
	

	 $.each(obj.data.vdler.baglivd, function(index, satir){

	 	if (satir.isyerituru==1 && satir.isebaslamatarihi!="") { baslangicMerkezTarih= satir.isebaslamatarihi; }

	});

	if (obj.data.hatakontrol!=undefined){

		$.each(obj.data.hatakontrol, function(index, satir1){  // sicil mesajlarını getir

		 mesaj = mesaj + "/n" + satir1.mesaj

		});

	}

	return tarihFormat(baslangicMerkezTarih) + "-" + mesaj;

}

catch(err){

return "Hata-" + err;

}

}




/* ==== PATCH v3: myTable6 için sadece KDV(0015) ise sadece sevk dönemlerini sorgula ==== */
window.tkkomFullYearStart = function(token, vkn) {
  try {
    if (!token || !vkn) return;
    if (window.__TK_FULLYEAR_RUNNING__) return;
    window.__TK_FULLYEAR_RUNNING__ = true;

    function parseTlNum(v){
      if (v == null) return 0;
      var s = String(v).trim();
      if (!s || s === '-' || /^HATA/i.test(s)) return 0;
      s = s.replace(/\./g,'').replace(/,/g,'.');
      var n = parseFloat(s);
      return isNaN(n) ? 0 : n;
    }
    function formatTl(n){
      try { return Number(n||0).toLocaleString('tr-TR',{minimumFractionDigits:2, maximumFractionDigits:2}); }
      catch(e){ return String(n||0); }
    }
    function toPromise(jq){
      return new Promise(function(resolve, reject){ jq.done(resolve).fail(reject); });
    }
    function withRetry(fn, maxRetry){
      return new Promise(function(resolve, reject){
        var attempt=0;
        function run(){
          attempt++;
          Promise.resolve().then(fn).then(resolve).catch(function(err){
            if (attempt <= maxRetry) setTimeout(run, 500);
            else reject(err);
          });
        }
        run();
      });
    }
    function getEndAy(vk, donemStr, fallbackAy){
      try {
        if (vk === '0015') {
          var a = parseInt(String(fallbackAy||'').trim(), 10);
          return (a>=1 && a<=12) ? a : 12;
        }
        var d = String(donemStr||'').replace(/\D/g,'');
        if (d.length >= 12) {
          var endM = parseInt(d.substr(10,2),10);
          return (endM>=1 && endM<=12) ? endM : 12;
        }
        if (d.length >= 6) {
          var m = parseInt(d.substr(4,2),10);
          return (m>=1 && m<=12) ? m : 12;
        }
      } catch(e) {}
      return 12;
    }

    var tries = 0;
    var timer = setInterval(function(){
      tries++;
      var $tbl = $('#myTable6');
      if ($tbl.length === 0) {
        if (tries > 80) { clearInterval(timer); window.__TK_FULLYEAR_RUNNING__ = false; }
        return;
      }
      var $rows = $tbl.find('tr.takkom-row');
      if ($rows.length === 0) {
        if (tries > 80) { clearInterval(timer); window.__TK_FULLYEAR_RUNNING__ = false; }
        return;
      }
      clearInterval(timer);

      var allOnlyKdv = true;
      var yearsMap = {};
      var onlyKdvMonthsByYear = {};
      $rows.each(function(){
        var $tr = $(this);
        var vk = String($tr.attr('data-vergikodu') || '').trim();
        var yil = String($tr.attr('data-yil') || '').trim();
        var ownAy = String($tr.attr('data-ay') || '').trim();
        if (vk !== '0015') allOnlyKdv = false;
        if (yil) yearsMap[yil] = true;
        if (vk === '0015' && yil) {
          var ay = parseInt(ownAy, 10);
          if (!(ay>=1 && ay<=12)) {
            var d = String($tr.attr('data-donem') || '').replace(/\D/g,'');
            ay = parseInt(d.substr(4,2), 10);
          }
          if (ay>=1 && ay<=12) {
            if (!onlyKdvMonthsByYear[yil]) onlyKdvMonthsByYear[yil] = {};
            onlyKdvMonthsByYear[yil][(ay<10?'0'+ay:''+ay)] = true;
          }
        }
        $tr.find('td.col-satis').text('Yükleniyor');
        $tr.find('td.col-karsit').text('Yükleniyor');
        $tr.find('td.col-banka').text('Yükleniyor');
      });
      var years = Object.keys(yearsMap).sort();
      if (!years.length) { window.__TK_FULLYEAR_RUNNING__ = false; return; }

      var st = window.__TK_STATE__ = window.__TK_STATE__ || {};
      st.token = token; st.vkn = vkn;
      st.bsCache = st.bsCache || {};
      st.posCache = st.posCache || {};
      st.onlyKdvMonthsByYear = onlyKdvMonthsByYear;
      st.allOnlyKdv = allOnlyKdv;

      var tasks = [];
      if (allOnlyKdv) {
        years.forEach(function(y){
          var map = onlyKdvMonthsByYear[y] || {};
          Object.keys(map).sort().forEach(function(mm){ tasks.push({year:y, month:mm}); });
        });
      } else {
        years.forEach(function(y){ for (var m=1;m<=12;m++){ tasks.push({year:y, month:(m<10?'0'+m:''+m)}); } });
      }
      if (!tasks.length) { window.__TK_FULLYEAR_RUNNING__ = false; return; }

      var CONCURRENCY = 8, MAX_RETRY = 2, idx = 0, inFlight = 0;
      var doneDef = $.Deferred();

      function ensureMonth(y, mm){
        if (!st.bsCache[y]) st.bsCache[y] = {};
        if (!st.posCache[y]) st.posCache[y] = {};
        var bsNeed = !st.bsCache[y][mm] || st.bsCache[y][mm].err;
        var posNeed = !st.posCache[y][mm] || st.posCache[y][mm].err;
        var jobs = [];
        if (bsNeed) {
          jobs.push(withRetry(function(){ return toPromise(bsSorgulaAsync(vkn, y, mm, token)); }, MAX_RETRY)
            .then(function(res){
              if (res && !res.__err && res.bs != null && res.karsit != null) {
                st.bsCache[y][mm] = { err:false, bsStr:res.bs, karsitStr:res.karsit, bsNum:parseTlNum(res.bs), karsitNum:parseTlNum(res.karsit) };
              } else {
                st.bsCache[y][mm] = { err:true, bsStr:'HATA', karsitStr:'HATA', bsNum:0, karsitNum:0, msg:(res && res.errorMessage) || 'HATA' };
              }
            })
            .catch(function(){ st.bsCache[y][mm] = { err:true, bsStr:'HATA', karsitStr:'HATA', bsNum:0, karsitNum:0, msg:'HATA' }; }));
        }
        if (posNeed) {
          jobs.push(withRetry(function(){ return toPromise(posBankaAylikAsync(vkn, y, mm, token)); }, MAX_RETRY)
            .then(function(posVal){
              if (posVal != null && !(posVal && posVal.__err)) {
                var pStr = (typeof posVal === 'number') ? formatTl(posVal) : (posVal || '0,00');
                st.posCache[y][mm] = { err:false, str:pStr, num:parseTlNum(pStr) };
              } else {
                st.posCache[y][mm] = { err:true, str:'HATA', num:0, msg:(posVal && posVal.errorMessage) || 'HATA' };
              }
            })
            .catch(function(){ st.posCache[y][mm] = { err:true, str:'HATA', num:0, msg:'HATA' }; }));
        }
        return Promise.all(jobs);
      }

      function renderAll(){
        $rows.each(function(){
          var $tr = $(this);
          var vk = String($tr.attr('data-vergikodu') || '').trim();
          var donem = String($tr.attr('data-donem') || '').trim();
          var yil = String($tr.attr('data-yil') || '').trim();
          if (!vk || !donem || !yil) return;
          var months = [];
          if (vk === '0015') {
            var ownAy = parseInt(String($tr.attr('data-ay') || '').trim(), 10);
            if (!(ownAy>=1 && ownAy<=12)) ownAy = getEndAy(vk, donem, String($tr.attr('data-ay')||''));
            months = [ownAy];
          } else {
            var endAy = getEndAy(vk, donem, String($tr.attr('data-ay')||''));
            for (var m=1;m<=endAy;m++) months.push(m);
          }
          var sumBs=0,sumKa=0,sumPos=0,hataBS=false,hataPos=false;
          months.forEach(function(m){
            var mm = (m<10?'0'+m:''+m);
            var b = st.bsCache[yil] && st.bsCache[yil][mm];
            var p = st.posCache[yil] && st.posCache[yil][mm];
            if (b && !b.err) { sumBs += b.bsNum; sumKa += b.karsitNum; } else { hataBS = true; }
            if (p && !p.err) { sumPos += p.num; } else { hataPos = true; }
          });
          var $tdS = $tr.find('td.col-satis'), $tdK = $tr.find('td.col-karsit'), $tdB = $tr.find('td.col-banka');
          if (hataBS) {
            $tdS.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>');
            $tdK.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>');
          } else {
            $tdS.text(formatTl(sumBs));
            $tdK.text(formatTl(sumKa));
          }
          if (hataPos) $tdB.html('<span class="tk-retry" data-kind="pos" title="Tekrar dene">HATA &#x21bb;</span>');
          else $tdB.text(formatTl(sumPos));
        });
      }

      function pump(){
        while (inFlight < CONCURRENCY && idx < tasks.length) {
          (function(task){
            inFlight++;
            ensureMonth(task.year, task.month).then(function(){
              renderAll();
              inFlight--;
              if (idx >= tasks.length && inFlight === 0) doneDef.resolve();
              else pump();
            });
          })(tasks[idx++]);
        }
      }
      pump();

      doneDef.then(function(){
        if (!window.__TK_RETRY_BOUND__) {
          window.__TK_RETRY_BOUND__ = true;
          $(document).on('click', '.tk-retry', function(){
            try {
              var st = window.__TK_STATE__ || {};
              if (!st.token || !st.vkn) return;
              var $tr = $(this).closest('tr');
              var kind = String($(this).attr('data-kind') || '');
              var yil = String($tr.attr('data-yil') || '').trim();
              var vk = String($tr.attr('data-vergikodu') || '').trim();
              var donem = String($tr.attr('data-donem') || '').trim();
              if (!yil || !vk || !donem) return;
              var months = [];
              if (vk === '0015') {
                var ownAy = parseInt(String($tr.attr('data-ay')||''),10);
                if (!(ownAy>=1 && ownAy<=12)) ownAy = getEndAy(vk, donem, String($tr.attr('data-ay')||''));
                months = [ownAy];
              } else {
                var endAy = getEndAy(vk, donem, String($tr.attr('data-ay')||''));
                for (var m=1;m<=endAy;m++) months.push(m);
              }
              if (kind === 'bs') { $tr.find('td.col-satis,td.col-karsit').text('Yükleniyor'); }
              if (kind === 'pos') { $tr.find('td.col-banka').text('Yükleniyor'); }
              var q = months.slice(), inF=0, CONC=8;
              function runOne(m){
                var mm = (m<10?'0'+m:''+m);
                if (!st.bsCache[yil]) st.bsCache[yil] = {};
                if (!st.posCache[yil]) st.posCache[yil] = {};
                if (kind === 'bs') delete st.bsCache[yil][mm]; else delete st.posCache[yil][mm];
                return ensureMonth(yil, mm);
              }
              function pumpRetry(){
                while (inF < CONC && q.length) {
                  (function(m){
                    inF++;
                    runOne(m).then(function(){
                      renderAll();
                      inF--;
                      if (q.length) pumpRetry();
                    });
                  })(q.shift());
                }
              }
              pumpRetry();
            } catch(e) { console.log('tk-retry hata', e); }
          });
        }
        window.__TK_FULLYEAR_RUNNING__ = false;
        try { if (window.__tkProgressFinish) window.__tkProgressFinish('Takdir sorgu ve Satış / Karşıt Alış / Banka Kredi Kartı ön yüklemesi tamamlandı.'); } catch(e) {}
      });
    }, 400);
  } catch(e) {
    window.__TK_FULLYEAR_RUNNING__ = false;
    console.log('tkkomFullYearStart hata:', e);
  }
};

/* ==== PATCH v90: Takdir Sorgu Satış / Karşıt Alış çoklu VD akıllı arka plan sorgu ==== */
(function(){
  function __tkUniq(arr){
    var out=[], seen={};
    (arr||[]).forEach(function(x){
      x=String(x==null?'':x).replace(/\D/g,'').trim();
      if(!x) return;
      if(!seen[x]){ seen[x]=true; out.push(x); }
    });
    return out;
  }
  function __tkTryCall(fn){ try{ return fn(); }catch(e){ return null; } }
  function __tkVdList(vkn, tok){
    // Ekran, dropdown, option, body/table veya Türkiye VD listesi taraması yapılmaz.
    // Amaç: GENEL sorgu dışında sadece sicil kaydı olan VD kodlarına istek göndermek.
    var vd=[];
    var seenRaw={};
    function addOne(x){
      x=String(x==null?'':x).trim();
      if(!x) return;
      x=x.replace(/\D/g,'');
      if(/^0\d{5}$/.test(x) && !seenRaw[x]){ seenRaw[x]=true; vd.push(x); }
    }
    function addSicilRecord(satir){
      satir=satir||{};
      // Sicil servisinde alan adı çoğunlukla vdkodu geliyor; bazı ekranlarda vdKodu/vKodu da gelebiliyor.
      var kod=satir.vdkodu || satir.vdKodu || satir.vKodu || satir.vergiDairesiKodu || satir.vergiDairesiKod;
      // Sicil kaydı dışındaki listeler yanlışlıkla girerse VKN kontrolüyle ayıkla.
      var rowVkn=String(satir.vergino || satir.vkn || satir.vergiNumarasi || '').replace(/\D/g,'');
      var reqVkn=String(vkn||'').replace(/\D/g,'');
      if(rowVkn && reqVkn && rowVkn!==reqVkn) return;
      addOne(kod);
    }
    function addBagliVdList(obj){
      try{
        var data=(obj&&obj.data)||{};
        var list=data.vdler && data.vdler.baglivd;
        if($.isArray(list)) $.each(list,function(_i,satir){ addSicilRecord(satir); });
        // thGucalacakList / tahakkuku olan VD listesi sicil kaydı değildir; bu yüzden burada özellikle okunmaz.
      }catch(_e){}
    }
    function readSicil(cmd, jpObj){
      try{
        var tokVal = tok || (typeof token==='function' ? token() : (typeof GetUrlValue==='function' ? GetUrlValue('token') : ''));
        if(!(typeof getRemote==='function') || !tokVal) return;
        var callid=makeid(13)+'-';
        var url='http://10.251.63.99/gibintranet_server/dispatch?cmd='+cmd+'&callid=' + callid + '15&token=' + encodeURIComponent(tokVal) + '&jp=' + encodeURIComponent(JSON.stringify(jpObj));
        var txt=getRemote(url);
        var obj=JSON.parse(txt||'{}');
        addBagliVdList(obj);
      }catch(e){ try{ console.log(' sicil VD listesi okunamadı ('+cmd+')', e); }catch(_e){} }
    }

    // Öncelik, kullanıcının ekranda gördüğü Mükellefiyet Bilgileri listesini veren IlKodu servisi.
    readSicil('sicilService_sicilBilgileriSorgulaIlKodu', {vkn:String(vkn||''),tckn:'',vdKodu:'',ilKodu:''});
    // Yedek olarak eski sicil servisi denenir; yine sadece data.vdler.baglivd okunur.
    if(!vd.length) readSicil('sicilService_sicilBilgileriSorgula', {vkn:String(vkn||''),tckn:'',vdKodu:''});

    // Son yedek: sicil servisi hiç okunamazsa yalnız mevcut/aktif VD denenir.
    // Burada da ekranın tamamı veya VD dropdown'u taranmaz.
    if(!vd.length){
      try{ if(typeof vdKodu==='function') addOne(vdKodu()); }catch(e){}
      try{ if(typeof vd_kodu!=='undefined' && vd_kodu) addOne(vd_kodu); }catch(e){}
    }

    // Güvenlik: Sicil dışı/tüm Türkiye listesi yanlışlıkla yakalanırsa bunu kabul etme.
    // Gerçek sicil listesi birkaç VD olur; 50 üstü liste kesin şüpheli kabul edilir.
    if(vd.length>50){
      try{ console.warn(': Sicil VD listesi şüpheli uzunlukta geldi, liste iptal edildi:', vd.length); }catch(e){}
      vd=[];
      try{ if(typeof vdKodu==='function') addOne(vdKodu()); }catch(e){}
    }

    var out=__tkUniq(vd);
    try{ window.__TK_VD_LIST__=out; window.__TK_VD_LIST_SOURCE__='sicilService_sicilBilgileriSorgulaIlKodu.baglivd'; }catch(e){}
    return out;
  }
  
  function __tkOrg(vd){
    try{ if(vd && typeof orgIDGetir==='function') return orgIDGetir(vd) || ''; }catch(e){}
    return '';
  }
  function __tkNum(v){
    try{
      if(typeof parseMoney==='function') return parseMoney(v);
      if(v==null) return 0;
      if(typeof v==='number') return isFinite(v)?v:0;
      var s=String(v).trim();
      if(!s) return 0;
      s=s.replace(/\./g,'').replace(',', '.');
      var n=parseFloat(s); return isNaN(n)?0:n;
    }catch(e){ return 0; }
  }
  function __tkFmt(n){
    try{ return Number(n||0).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
    catch(e){ return String(n||0); }
  }
  function __tkAllowedPosBsVergiKodu(vk){
    var __vk=String(vk||'').replace(/\D/g,'');
    while(__vk.length<4) __vk='0'+__vk;
    // Takdir ekranında Satış/Karşıt Alış ve Banka/POS sorgusu sadece bu vergi kodlarında çalışacak.
    return (__vk==='0001' || __vk==='0032' || __vk==='0015' || __vk==='0010' || __vk==='0033');
  }
  function __tkSkipBsForVergiKodu(vk){
    return !__tkAllowedPosBsVergiKodu(vk);
  }
  function __tkMarkBsMonth(map,y,mm){
    y=String(y||'').trim(); mm=String(mm||'').trim();
    if(!y || !mm) return;
    if(mm.length===1) mm='0'+mm;
    if(!map[y]) map[y]={};
    map[y][mm]=true;
  }
  function __tkBsExtract(obj){
    var topFail = (obj && obj.success === false) || (obj && obj.data && obj.data.success === false);
    var errMsg = (obj && (obj.errorMessage || obj.error || obj.message)) || (obj && obj.data && (obj.data.errorMessage || obj.data.error || obj.data.message));
    if(topFail) return {__err:true, errorMessage:errMsg || 'Satış/Karşıt Alış sorgusu başarısız'};
    var data=(obj&&obj.data)||{};

    function firstDefined(row, names){
      row=row||{};
      for(var i=0;i<names.length;i++){
        if(row[names[i]]!==undefined && row[names[i]]!==null && String(row[names[i]]).trim()!=='') return row[names[i]];
      }
      return undefined;
    }

    function readList(list){
      list=$.isArray(list)?list:[];
      var topSeen=false, bestTop1=0, bestTop2=0, bestTopScore=-1;
      var sum1=0, sum2=0, detay=0;
      $.each(list,function(_i,satir){
        satir=satir||{};

        // GİB cevabında bazen ayrı bir TOPLAM satırı gelir. Bu satır varsa detayları ayrıca
        // toplamayız; toplam satırını tek kaynak kabul ederiz. Birden fazla toplam satırı
        // çıkarsa en yüksek toplamlı satırı seçeriz, satırları birbirine eklemeyiz.
        var top1 = firstDefined(satir, ['malHizmetBedeli1Top','malHizmetBedeli1Toplam','satisMalHizmetBedeliTop','satisTutarTop','satisToplam','toplamSatis','malHizmetBedeliTop','tutar1Top','bedel1Top']);
        var top2 = firstDefined(satir, ['malHizmetBedeli2Top','malHizmetBedeli2Toplam','karsitAlisMalHizmetBedeliTop','karsitAlisTutarTop','karsitAlisToplam','karsiAlisToplam','tutar2Top','bedel2Top']);
        var hasTopField = (top1!==undefined || top2!==undefined || satir.belgeSayisiTop!==undefined || satir.belgeSayisi1Top!==undefined);
        if(top1!==undefined || top2!==undefined){
          var n1=__tkNum(top1), n2=__tkNum(top2), sc=Math.abs(n1)+Math.abs(n2);
          if(!topSeen || sc>=bestTopScore){
            bestTop1=n1; bestTop2=n2; bestTopScore=sc; topSeen=true;
          }
        }

        if(hasTopField) return; // toplam satırını detay gibi tekrar toplama

        var v1 = firstDefined(satir, ['malHizmetBedeli1','satisMalHizmetBedeli','satisTutari','satisTutar','satis','tutar1','bedel1','malHizmetBedeli']);
        var v2 = firstDefined(satir, ['malHizmetBedeli2','karsitAlisMalHizmetBedeli','karsitAlisTutari','karsitAlisTutar','karsitAlis','karsiAlis','tutar2','bedel2']);
        if(v1!==undefined || v2!==undefined){
          detay++;
          sum1 += __tkNum(v1);
          sum2 += __tkNum(v2);
        }
      });
      var tutarBS = topSeen ? bestTop1 : sum1;
      var tutarKarsiAlis = topSeen ? bestTop2 : sum2;
      return {
        bsNum:tutarBS,
        karsitNum:tutarKarsiAlis,
        hasData:(list.length>0 || detay>0 || topSeen || tutarBS!==0 || tutarKarsiAlis!==0),
        detaySayisi:detay,
        rawCount:list.length,
        score:Math.abs(tutarBS)+Math.abs(tutarKarsiAlis),
        topSeen:topSeen
      };
    }

    // liste1 varsa boş/sıfır dahi olsa data.liste veya başka listeye geçilmez. Böylece alış tarafı
    // yanlışlıkla Satış kolonuna yazılmaz.
    var r=null, sourceList='liste1';
    if($.isArray(data.liste1)){
      r=readList(data.liste1);
    }else{
      var candidates=[];
      ['malHizmetSatilanListe','satisListesi','alisSatisListe','alisSatisAnalizListe','list','rows','dataList','liste'].forEach(function(k){
        if($.isArray(data[k])) candidates.push({key:k,val:readList(data[k])});
      });
      var best=null, first=null;
      candidates.forEach(function(c){
        if(!first) first=c;
        if(c && c.val && c.val.score>0 && (!best || c.val.score>best.val.score)) best=c;
      });
      var chosen=best || first;
      if(chosen){ r=chosen.val; sourceList=chosen.key; }
    }
    if(!r) r=readList([]);
    return {__err:false, bs:__tkFmt(r.bsNum), karsit:__tkFmt(r.karsitNum), bsNum:r.bsNum, karsitNum:r.karsitNum, hasData:r.hasData, detaySayisi:r.detaySayisi, rawCount:r.rawCount, sourceList:sourceList, topSeen:!!r.topSeen};
  }
  function __tkNormalizeBsScale(res){
    try{
      if(!res || res.__err || res.__tkScaleApplied) return res;
      // Önemli: Alış/Satış Analizi servisindeki malHizmetBedeli alanları TL formatında geliyor.
      // Önceki sürümde /10 veya /100 uygulanınca Takdir ekranında ve yıllık KDV/BA-BS-POS ekranıyla
      // karşılaştırmada tutarlar kayıyordu. Bu nedenle ham TL toplamı korunur.
      res.bsNum=Number(res.bsNum||0);
      res.karsitNum=Number(res.karsitNum||0);
      res.bs=__tkFmt(res.bsNum);
      res.karsit=__tkFmt(res.karsitNum);
      res.__tkScaleApplied=true;
      res.scaleInfo='GİB yıllık KDV/BA-BS-POS ekranı ile aynı ham TL tutarı kullanıldı';
    }catch(_e){}
    return res;
  }
  function __tkBsAsyncVd(vkn,yil,ay,token,vdKodu){
    var ay2=(String(ay).length===1)?('0'+String(ay)):String(ay);
    // Normal Yıllık KDV / BA-BS-POS ekranındaki çalışan sorgu formatı budur.
    // Önce VD'siz genel sorgu denenir; veri yoksa VD bazlı yedek sorgular devreye girer.
    // spTip/spDonem eklenince bazı dönemlerde farklı/yanlış toplam dönebildiği için kullanılmıyor.
    var clientObj={vergiNumarasi:String(vkn||''),tcKimlikNo:'',yil:String(yil),ay:ay2,hvBabsMi:true};
    if(vdKodu){
      clientObj.vdKodu=String(vdKodu);
      clientObj.vdkodu=String(vdKodu);
      clientObj.vergiDairesiKodu=String(vdKodu);
      // Ağ dinleyicide görülen çalışan BA/BS formatında orgOid -1 gönderiliyor.
      // VD org ID gönderilince bazı dönemlerde cevap farklı/boş dönebildiği için BA/BS'te -1 kullanılır.
      clientObj.orgOid='-1';
    }
    var jpObj={clientObj:clientObj};
    if(vdKodu){
      jpObj.vdKodu=String(vdKodu);
      jpObj.vdkodu=String(vdKodu);
      jpObj.vergiDairesiKodu=String(vdKodu);
      jpObj.orgOid='-1';
    }
    var callid=makeid(13)+'-';
    var url='http://10.251.63.99/gibintranet_server/dispatch?cmd=alisSatisAnaliziService_getAlisSatisAnaliz&callid='+callid+'176&token='+encodeURIComponent(token)+'&jp='+encodeURIComponent(JSON.stringify(jpObj));
    return $.ajax({type:'GET',url:url,dataType:'json',timeout:120000}).then(function(obj){
	      var r=__tkBsExtract(obj); r.sourceVd=vdKodu||'GENEL';
          try{
            window.__TK_BS_DEBUG__ = window.__TK_BS_DEBUG__ || {};
            var __dbgKey = String(yil)+'-'+ay2+'-'+(vdKodu||'GENEL');
            window.__TK_BS_DEBUG__[__dbgKey] = {
              jp:jpObj,
              sourceVd:(vdKodu||'GENEL'),
              sourceList:r.sourceList,
              topSeen:r.topSeen,
              rawCount:r.rawCount,
              detaySayisi:r.detaySayisi,
              satis:r.bsNum,
              karsit:r.karsitNum,
              satisYazilan:__tkFmt(r.bsNum),
              karsitYazilan:__tkFmt(r.karsitNum),
              raw:obj
            };
          }catch(_e){}
          return r;
	    });
  }
  function __tkBsAsyncCokluVd(vkn,yil,ay,token,vdList){
    // Sicil VD, çoklu VD veya Türkiye VD taraması yapılmaz; yalnız VD'siz GENEL sorgu gönderilir.
    return __tkBsAsyncVd(vkn,yil,ay,token,'').then(function(r){
      if(r && !r.__err){ r.sourceVd='GENEL'; r.triedVds=['GENEL']; }
      return r;
    });
  }
  function __tkPosAsyncVd(vkn,yil,ay,token,vdKodu){
    var ay2=(String(ay).length===1)?('0'+String(ay)):String(ay);
    var jpObj={vkn:String(vkn||''),tckn:'',satisDonemAy:ay2,satisDonemYil:String(yil),respKeyParam:'bankaSatisAylikListe',isFullData:false,isFullExport:true,pv:{start:0,limit:'50',sorters:[]}};
    if(vdKodu){ jpObj.vdKodu=String(vdKodu); jpObj.vdkodu=String(vdKodu); jpObj.vergiDairesiKodu=String(vdKodu); jpObj.orgOid=__tkOrg(vdKodu); }
    var callid=makeid(13)+'-';
    var url='http://10.251.63.99/gibintranet_server/dispatch?cmd=posKrediKartiService_bankaSatisBilgGoreAylikSorgula&callid='+callid+'22&token='+encodeURIComponent(token)+'&jp='+encodeURIComponent(JSON.stringify(jpObj));
    return $.ajax({type:'GET',url:url,dataType:'json',timeout:120000}).then(function(obj){
      try{
        var fail=(obj&&obj.success===false)||(obj&&obj.data&&obj.data.success===false);
        if(fail) return {__err:true,errorMessage:(obj.errorMessage||(obj.data&&obj.data.errorMessage)||'POS/Banka sorgusu başarısız'),sourceVd:vdKodu||''};
        var val=0;
        if(typeof __extractPosTotal==='function') val=__extractPosTotal(obj&&obj.data);
        else if(obj&&obj.data&&$.isArray(obj.data.bankaSatisAylikListe)){
          $.each(obj.data.bankaSatisAylikListe,function(_i,r){ r=r||{}; val += __tkNum(r.toplamGenel||r.tutar||r.toplam||0); });
        }
        try{
          window.__TK_POS_DEBUG__ = window.__TK_POS_DEBUG__ || {};
          window.__TK_POS_DEBUG__[String(yil)+'-'+ay2+'-'+(vdKodu||'GENEL')] = {jp:jpObj, sourceVd:(vdKodu||'GENEL'), toplam:val, yazilan:__tkFmt(val), raw:obj};
        }catch(_e){}
        return {__err:false,num:val,str:__tkFmt(val),hasData:(val!==0),sourceVd:vdKodu||''};
      }catch(e){ return {__err:true,errorMessage:e.message||String(e),sourceVd:vdKodu||''}; }
    });
  }
  function __tkPosAsyncCokluVd(vkn,yil,ay,token,vdList){
    // Çoklu VD denenmez; yalnız VD'siz GENEL sorgu gönderilir.
    return __tkPosAsyncVd(vkn,yil,ay,token,'').then(function(r){
      if(r && !r.__err){ r.sourceVd='GENEL'; r.triedVds=['GENEL']; }
      return r;
    });
  }

  window.tkkomFullYearStart = function(token, vkn) {
    try {
      if (!token || !vkn) return;
      var __tkRunVknKey = String(vkn||'').replace(/\D/g,'');
      // veya ay bazlı cache'i yeni ekrana 0,00 olarak taşınmasın.
      if (window.__TK_FULLYEAR_RUNNING__ && window.__TK_RUNNING_VKN__ && window.__TK_RUNNING_VKN__ !== __tkRunVknKey) {
        window.__TK_FULLYEAR_RUNNING__ = false;
      }
      if (window.__TK_FULLYEAR_RUNNING__) return;
      window.__TK_FULLYEAR_RUNNING__ = true;
      window.__TK_RUNNING_VKN__ = __tkRunVknKey;
      function parseTlNum(v){ return __tkNum(v); }
      function formatTl(n){ return __tkFmt(n); }
      function withRetry(fn, maxRetry){
        return new Promise(function(resolve,reject){
          var attempt=0;
          function run(){
            attempt++;
            Promise.resolve().then(fn).then(resolve).catch(function(err){
              if(attempt<=maxRetry) setTimeout(run,500); else reject(err);
            });
          }
          run();
        });
      }
      function getEndAy(vk,donemStr,fallbackAy){
        try{
          if(vk==='0015'){
            var a=parseInt(String(fallbackAy||'').trim(),10);
            return (a>=1&&a<=12)?a:12;
          }
          var d=String(donemStr||'').replace(/\D/g,'');
          if(d.length>=12){ var e=parseInt(d.substr(10,2),10); return (e>=1&&e<=12)?e:12; }
          if(d.length>=6){ var m=parseInt(d.substr(4,2),10); return (m>=1&&m<=12)?m:12; }
        }catch(e){}
        return 12;
      }
      function getAyRange(vk,donemStr,fallbackAy){
        // Eski doğru mantık korunur:
        // 0015 için sadece kendi ayı alınır.
        // Diğer vergi türlerinde dönem bitiş ayına kadar 1'den başlayarak toplanır.
        // Örn. 202504-202506 için 4-6 değil, 1-6 ayları dikkate alınır.
        var months=[];
        try{
          vk=String(vk||'').trim();
          if(vk==='0015'){
            var ownAy=parseInt(String(fallbackAy||'').trim(),10);
            if(!(ownAy>=1&&ownAy<=12)) ownAy=getEndAy(vk,donemStr,String(fallbackAy||''));
            months=[ownAy];
          }else{
            var endAy=getEndAy(vk,donemStr,String(fallbackAy||''));
            for(var m=1;m<=endAy;m++) months.push(m);
          }
        }catch(e){}
        return months.length?months:[12];
      }
      var vdList=[];

      var tries=0;
      var timer=setInterval(function(){
        tries++;
        var $tbl=$('#myTable6');
        if($tbl.length===0){ if(tries>80){clearInterval(timer);window.__TK_FULLYEAR_RUNNING__=false;} return; }
        var $rows=$tbl.find('tr.takkom-row');
        if($rows.length===0){ if(tries>80){clearInterval(timer);window.__TK_FULLYEAR_RUNNING__=false;} return; }
        clearInterval(timer);

        var allOnlyKdv=true, yearsMap={}, onlyKdvMonthsByYear={}, bsMonthsByYear={};
        $rows.each(function(){
          var $tr=$(this), vk=String($tr.attr('data-vergikodu')||'').trim(), yil=String($tr.attr('data-yil')||'').trim(), ownAy=String($tr.attr('data-ay')||'').trim();
          var skipBs=__tkSkipBsForVergiKodu(vk);
          if(skipBs){
            $tr.find('td.col-satis').text('-').attr('title','Bu vergi kodu için Satış/Karşıt Alış sorgusu yapılmaz. Sorgu sadece 0001, 0032, 0015, 0010, 0033 için çalışır.');
            $tr.find('td.col-karsit').text('-').attr('title','Bu vergi kodu için Satış/Karşıt Alış sorgusu yapılmaz. Sorgu sadece 0001, 0032, 0015, 0010, 0033 için çalışır.');
            $tr.find('td.col-banka').text('-').attr('title','Bu vergi kodu için Banka/POS sorgusu yapılmaz. Sorgu sadece 0001, 0032, 0015, 0010, 0033 için çalışır.');
            return;
          }
          if(vk!=='0015') allOnlyKdv=false;
          if(yil) yearsMap[yil]=true;
          if(vk==='0015'&&yil){
            var ay=parseInt(ownAy,10);
            if(!(ay>=1&&ay<=12)){ var d=String($tr.attr('data-donem')||'').replace(/\D/g,''); ay=parseInt(d.substr(4,2),10); }
            if(ay>=1&&ay<=12){
              if(!onlyKdvMonthsByYear[yil]) onlyKdvMonthsByYear[yil]={};
              var mm=(ay<10?'0'+ay:''+ay);
              onlyKdvMonthsByYear[yil][mm]=true;
              __tkMarkBsMonth(bsMonthsByYear,yil,mm);
            }
          } else if(yil) {
            var __months=getAyRange(vk,String($tr.attr('data-donem')||''),ownAy);
            for(var mi=0; mi<__months.length; mi++){
              var bm=__months[mi];
              __tkMarkBsMonth(bsMonthsByYear,yil,(bm<10?'0'+bm:''+bm));
            }
          }
          $tr.find('td.col-satis').text('Yükleniyor');
          $tr.find('td.col-karsit').text('Yükleniyor');
          $tr.find('td.col-banka').text('Yükleniyor');
        });
        var years=Object.keys(yearsMap).sort();
        if(!years.length){ window.__TK_FULLYEAR_RUNNING__=false; return; }
        var st=window.__TK_STATE__=window.__TK_STATE__||{};
        var __tkVknKey = String(vkn||'').replace(/\D/g,'');
        var __tkOldVknKey = String(st.__currentVkn || st.vkn || '').replace(/\D/g,'');
        if (__tkOldVknKey && __tkOldVknKey !== __tkVknKey) {
          // yeni mükellefe taşınabiliyordu. Yeni VKN'de tüm BA/BS-POS cache'i sıfırla.
          st.bsCache = {};
          st.posCache = {};
          st.onlyKdvMonthsByYear = {};
          st.bsMonthsByYear = {};
          try{ window.__TK_BS_DEBUG__ = {}; window.__TK_POS_DEBUG__ = {}; window.__TK_TAKKOM_BIREBIR__ = []; }catch(_e){}
        }
        st.__currentVkn = __tkVknKey;
        st.token=token; st.vkn=vkn; st.vdList=vdList; st.bsCache=st.bsCache||{}; st.posCache=st.posCache||{};
        st.onlyKdvMonthsByYear=onlyKdvMonthsByYear; st.bsMonthsByYear=bsMonthsByYear; st.allOnlyKdv=allOnlyKdv;

        var tasks=[];
        if(allOnlyKdv){
          years.forEach(function(y){ var map=onlyKdvMonthsByYear[y]||{}; Object.keys(map).sort().forEach(function(mm){ tasks.push({year:y,month:mm}); }); });
        }else{
          years.forEach(function(y){ for(var m=1;m<=12;m++) tasks.push({year:y,month:(m<10?'0'+m:''+m)}); });
        }
        if(!tasks.length){ window.__TK_FULLYEAR_RUNNING__=false; return; }
        var CONCURRENCY=4, MAX_RETRY=1, idx=0, inFlight=0, doneDef=$.Deferred();
        function ensureMonth(y,mm){
          if(!st.bsCache[y]) st.bsCache[y]={};
          if(!st.posCache[y]) st.posCache[y]={};
          var doBs=!!(st.bsMonthsByYear && st.bsMonthsByYear[y] && st.bsMonthsByYear[y][mm]);
          var __cacheVknKey = String(vkn||'').replace(/\D/g,'');
          var __oldBs = st.bsCache[y][mm];
          var __oldPos = st.posCache[y][mm];
          var bsNeed=doBs && (!__oldBs || __oldBs.err || String(__oldBs.vknKey||'') !== __cacheVknKey);
          var posNeed=!__oldPos || __oldPos.err || String(__oldPos.vknKey||'') !== __cacheVknKey;
          var jobs=[];
          if(bsNeed){
            jobs.push(withRetry(function(){ return __tkBsAsyncCokluVd(vkn,y,mm,token,vdList); },MAX_RETRY).then(function(res){
              res=__tkNormalizeBsScale(res);
              if(res && !res.__err && res.bs!=null && res.karsit!=null){
                st.bsCache[y][mm]={err:false,vknKey:String(vkn||'').replace(/\D/g,''),bsStr:res.bs,karsitStr:res.karsit,bsNum:res.bsNum, karsitNum:res.karsitNum,sourceVd:res.sourceVd||'',triedVds:vdList.slice(),hasData:!!res.hasData,scaleInfo:res.scaleInfo||''};
              }else{
                st.bsCache[y][mm]={err:true,vknKey:String(vkn||'').replace(/\D/g,''),bsStr:'HATA',karsitStr:'HATA',bsNum:0,karsitNum:0,msg:(res&&res.errorMessage)||'HATA',triedVds:vdList.slice()};
              }
            }).catch(function(){ st.bsCache[y][mm]={err:true,bsStr:'HATA',karsitStr:'HATA',bsNum:0,karsitNum:0,msg:'HATA',triedVds:vdList.slice()}; }));
          }
          if(posNeed){
            jobs.push(withRetry(function(){ return __tkPosAsyncCokluVd(vkn,y,mm,token,vdList); },MAX_RETRY).then(function(res){
              if(res && !res.__err){
                st.posCache[y][mm]={err:false,vknKey:String(vkn||'').replace(/\D/g,''),str:res.str||formatTl(res.num),num:parseTlNum(res.str||res.num),sourceVd:res.sourceVd||'',triedVds:vdList.slice(),hasData:!!res.hasData};
              }else{
                st.posCache[y][mm]={err:true,vknKey:String(vkn||'').replace(/\D/g,''),str:'HATA',num:0,msg:(res&&res.errorMessage)||'HATA',triedVds:vdList.slice()};
              }
            }).catch(function(){ st.posCache[y][mm]={err:true,str:'HATA',num:0,msg:'HATA',triedVds:vdList.slice()}; }));
          }
          return Promise.all(jobs);
        }
        function renderAll(){
          $rows.each(function(){
            var $tr=$(this), vk=String($tr.attr('data-vergikodu')||'').trim(), donem=String($tr.attr('data-donem')||'').trim(), yil=String($tr.attr('data-yil')||'').trim();
            if(!vk||!donem||!yil) return;
            var months=[];
            months=getAyRange(vk,donem,String($tr.attr('data-ay')||''));
            var sumBs=0,sumKa=0,sumPos=0,hataBS=false,hataPos=false, srcBs={}, srcPos={}, scaleInfo='';
            months.forEach(function(m){
              var mm=(m<10?'0'+m:''+m), b=st.bsCache[yil]&&st.bsCache[yil][mm], p=st.posCache[yil]&&st.posCache[yil][mm];
              if(b&&!b.err){ sumBs+=Number(b.bsNum||0); sumKa+=Number(b.karsitNum||0); if(b.sourceVd) srcBs[b.sourceVd]=true; if(b.scaleInfo) scaleInfo=b.scaleInfo; } else hataBS=true;
              if(p&&!p.err){ sumPos+=p.num; if(p.sourceVd) srcPos[p.sourceVd]=true; } else hataPos=true;
            });
            var $tdS=$tr.find('td.col-satis'), $tdK=$tr.find('td.col-karsit'), $tdB=$tr.find('td.col-banka');
            var __vdTitleList=(vdList&&vdList.length?vdList:['GENEL']); var titleBs='Denenen VD: '+__vdTitleList.join(', ')+(Object.keys(srcBs).length?' | Veri bulunan VD: '+Object.keys(srcBs).join(', '):'')+(scaleInfo?' | '+scaleInfo:'');
            var titlePos='Denenen VD: '+__vdTitleList.join(', ')+(Object.keys(srcPos).length?' | Veri bulunan VD: '+Object.keys(srcPos).join(', '):'');
            if(__tkSkipBsForVergiKodu(vk)){
              var skipTitle='Bu vergi kodu için sorgu yapılmaz. Satış/Karşıt Alış ve Banka/POS sorgusu sadece 0001, 0032, 0015, 0010, 0033 için çalışır.';
              $tdS.text('-').attr('title',skipTitle);
              $tdK.text('-').attr('title',skipTitle);
              $tdB.text('-').attr('title',skipTitle);
            }else{
              var __oldS=$tdS.text(), __oldK=$tdK.text(), __oldB=$tdB.text();
              var __sStr=formatTl(sumBs), __kStr=formatTl(sumKa), __pStr=formatTl(sumPos);
              try{
                window.__TK_TAKKOM_BIREBIR__ = window.__TK_TAKKOM_BIREBIR__ || [];
                window.__TK_TAKKOM_BIREBIR__.push({
                  vergiKodu:vk,
                  donem:donem,
                  yil:yil,
                  aylar:months.map(function(m){return (m<10?'0'+m:''+m);}),
                  eskiSatis:__oldS,
                  eskiKarsit:__oldK,
                  eskiBanka:__oldB,
                  yazilanSatis:__sStr,
                  yazilanKarsit:__kStr,
                  yazilanBanka:__pStr,
                  satisNum:sumBs,
                  karsitNum:sumKa,
                  bankaNum:sumPos,
                  kaynakBs:Object.keys(srcBs),
                  kaynakPos:Object.keys(srcPos),
                  denenenVd:(vdList&&vdList.length?vdList:['GENEL'])
                });
              }catch(_e){}
              if(hataBS){ $tdS.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>'); $tdK.html('<span class="tk-retry" data-kind="bs" title="Tekrar dene">HATA &#x21bb;</span>'); }
              else {
                $tdS.text(__sStr).attr('title',titleBs + ' | Gelen cevap toplamı birebir yazıldı');
                $tdK.text(__kStr).attr('title',titleBs + ' | Gelen cevap toplamı birebir yazıldı');
              }
              if(hataPos) $tdB.html('<span class="tk-retry" data-kind="pos" title="Tekrar dene">HATA &#x21bb;</span>');
              else $tdB.text(__pStr).attr('title',titlePos + ' | Gelen cevap toplamı birebir yazıldı');
            }
          });
        }
        function pump(){
          while(inFlight<CONCURRENCY && idx<tasks.length){
            (function(task){
              inFlight++;
              ensureMonth(task.year,task.month).then(function(){ renderAll(); inFlight--; if(idx>=tasks.length&&inFlight===0) doneDef.resolve(); else pump(); });
            })(tasks[idx++]);
          }
        }
        pump();
        doneDef.then(function(){
          if(!window.__TK_RETRY_BOUND__){
            window.__TK_RETRY_BOUND__=true;
            $(document).on('click','.tk-retry',function(){
              try{
                var st=window.__TK_STATE__||{}; if(!st.token||!st.vkn) return;
                var $tr=$(this).closest('tr'), kind=String($(this).attr('data-kind')||''), yil=String($tr.attr('data-yil')||'').trim(), vk=String($tr.attr('data-vergikodu')||'').trim(), donem=String($tr.attr('data-donem')||'').trim();
                if(!yil||!vk||!donem) return;
                if(__tkSkipBsForVergiKodu(vk)){
                  var skipTitle='Bu vergi kodu için sorgu yapılmaz. Satış/Karşıt Alış ve Banka/POS sorgusu sadece 0001, 0032, 0015, 0010, 0033 için çalışır.';
                  $tr.find('td.col-satis').text('-').attr('title',skipTitle);
                  $tr.find('td.col-karsit').text('-').attr('title',skipTitle);
                  $tr.find('td.col-banka').text('-').attr('title',skipTitle);
                  return;
                }
                var months=[];
                months=getAyRange(vk,donem,String($tr.attr('data-ay')||''));
                if(kind==='bs') $tr.find('td.col-satis,td.col-karsit').text('Yükleniyor');
                if(kind==='pos') $tr.find('td.col-banka').text('Yükleniyor');
                var q=months.slice(), inF=0, CONC=4;
                function runOne(m){ var mm=(m<10?'0'+m:''+m); if(!st.bsCache[yil]) st.bsCache[yil]={}; if(!st.posCache[yil]) st.posCache[yil]={}; if(kind==='bs') delete st.bsCache[yil][mm]; else delete st.posCache[yil][mm]; return ensureMonth(yil,mm); }
                function pumpRetry(){ while(inF<CONC&&q.length){ (function(m){ inF++; runOne(m).then(function(){ renderAll(); inF--; if(q.length) pumpRetry(); }); })(q.shift()); } }
                pumpRetry();
              }catch(e){ console.log('tk-retry çoklu VD hata',e); }
            });
          }
          window.__TK_FULLYEAR_RUNNING__=false;
          try{ if(window.__tkProgressFinish) window.__tkProgressFinish('Takdir sorgu Satış / Karşıt Alış / Banka sorgusu tamamlandı. Denenen: '+((vdList&&vdList.length?vdList:['GENEL']).join(', ')));  }catch(e){}
        });
      },400);
    } catch(e){ window.__TK_FULLYEAR_RUNNING__=false; console.log('tkkomFullYearStart çoklu VD hata:',e); }
  };
})();
/* ==== /PATCH v90 + v120 BA/BS birebir doğrulama + sadece sicil VD ==== */


/* ==== PATCH v112: Ortak para okuma/format düzeltmesi ====
   Noktalı ondalık (659.10) ile gelen servis tutarları artık binlik ayırıcı sanılmaz.
   Bu düzeltme KDV 0015, diğer vergi türleri, POS ve yıllık/ara dönem toplamlarında tutar kaymasını engeller. */
(function(){
  function __tkkomFixMalformedMoneyText(s){
    s=String(s==null?'':s).trim();
    // 22.000 doğru iken bazı akışlarda 22.00.000 gibi hatalı ara .00 grubu oluşabiliyordu.
    // Bu desen para formatı değildir; son 3 haneli binlik grubun önündeki gereksiz .00 grupları kaldırılır.
    if(/^\d{1,3}(?:\.00)+\.\d{3}(?:,\d{1,2})?$/.test(s)){
      s=s.replace(/(?:\.00)+(?=\.\d{3}(?:,\d{1,2})?$)/,'');
    }
    return s;
  }
  function __tkkomParseMoneyRobust(val){
    if(val===null || val===undefined) return 0;
    if(typeof val==='number') return isFinite(val)?val:0;
    var s=String(val).trim();
    if(!s || s==='-' || /^nan$/i.test(s) || /^hata$/i.test(s)) return 0;
    var neg=false;
    if(/^\(.*\)$/.test(s)){ neg=true; s=s.slice(1,-1); }
    s=s.replace(/\s/g,'').replace(/[^0-9,\.\-]/g,'');
    s=__tkkomFixMalformedMoneyText(s);
    if(s.charAt(0)==='-'){ neg=true; s=s.slice(1); }
    if(!s) return 0;
    var lastComma=s.lastIndexOf(','), lastDot=s.lastIndexOf('.');
    if(lastComma>=0 && lastDot>=0){
      if(lastComma>lastDot){
        // 1.234.567,89
        s=s.replace(/\./g,'').replace(',', '.');
      }else{
        // 1,234,567.89
        s=s.replace(/,/g,'');
      }
    }else if(lastComma>=0){
      var cp=s.split(','), cfrac=cp[cp.length-1]||'';
      if(cp.length>2){
        s=cp.slice(0,-1).join('').replace(/,/g,'') + (cfrac.length?'.'+cfrac:'');
      }else if(cfrac.length===1 || cfrac.length===2){
        s=s.replace(',', '.');
      }else if(cfrac.length===3 && cp[0].length<=3){
        s=s.replace(/,/g,'');
      }else{
        s=s.replace(',', '.');
      }
    }else if(lastDot>=0){
      var dp=s.split('.'), dfrac=dp[dp.length-1]||'';
      if(dp.length>2){
        var allThousand=true;
        for(var i=1;i<dp.length;i++){ if(dp[i].length!==3) allThousand=false; }
        if(allThousand) s=dp.join('');
        else s=dp.slice(0,-1).join('') + (dfrac.length?'.'+dfrac:'');
      }else if(dfrac.length===1 || dfrac.length===2){
        // 659.10 => 659,10 olarak yorumlanır
      }else if(dfrac.length===3 && dp[0].length<=3){
        s=s.replace(/\./g,'');
      }else{
        s=s.replace(/\./g,'');
      }
    }
    var n=parseFloat(s);
    if(!isFinite(n)) return 0;
    return neg ? -n : n;
  }
  window.__tkkomFixMalformedMoneyText = __tkkomFixMalformedMoneyText;
  window.parseMoney = __tkkomParseMoneyRobust;
  window.__parseNumberTR = __tkkomParseMoneyRobust;
  window.tlCevir = function(veri){
    var n=__tkkomParseMoneyRobust(veri);
    try{ return n.toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
    catch(e){ return String(n); }
  };
})();
/* ==== /PATCH v112 ==== */
/* ==== PATCH v119: BA/BS doğrulama: liste1 kesin kaynak + toplam satırı tekil + debug (__TK_BS_DEBUG__) ==== */


/* ==== PATCH v120 notu ====
   Takdire Sevk ekranındaki Satış / Karşıt Alış / Banka sütunlarında ekrana yazılan değer,
   gelen servis cevabından hesaplanan formatlı değerle aynı anda window.__TK_TAKKOM_BIREBIR__ içine kaydedilir.
   BA/BS/POS VD listesi sadece sicilService_sicilBilgileriSorgulaIlKodu -> data.vdler.baglivd listesinden alınır;
   thGucalacakList veya tahakkuku olan tüm VD listesi BA/BS/POS için kullanılmaz.
==== /PATCH v120 ==== */


/* ==== PATCH v146: Yeni mükellefe geçince BA/BS-POS cache temizliği ==== */
(function(){
  if (typeof window === 'undefined' || window.__TK_V146_CACHE_FIX__) return;
  window.__TK_V146_CACHE_FIX__ = true;
  window.tkkomResetBsPosCache = function(){
    try{
      var st = window.__TK_STATE__ = window.__TK_STATE__ || {};
      st.bsCache = {}; st.posCache = {}; st.onlyKdvMonthsByYear = {}; st.bsMonthsByYear = {};
      window.__TK_BS_DEBUG__ = {}; window.__TK_POS_DEBUG__ = {}; window.__TK_TAKKOM_BIREBIR__ = [];
      window.__TK_FULLYEAR_RUNNING__ = false;
    }catch(e){}
  };
})();
/* ==== /PATCH v146 ==== */
