TARH DEFTERİ SORGULAMA (Rapor Alma – EVDB Raporları içinde)

Rapor seçimi: "Tarh Defteri Sorgulama (geçici / tebliğ edilmemiş / … ihbarnameler · aylık PDF → liste)".
Kaynak (HAR 06.10.2026): EVDB Rapor › Tarh İşlemleri Listeleri › Tarh Defteri Sorgulama
  GET evdorapor_server/pdf  serviceName=evdoLRTarhiyatServices_geciciIhbarnameFisiListesi, reportName=RP_EVDO_GECICI_IHBARNAME_LISTESI
  Parametreler: BASLANGIC_TARIHI/BITIS_TARIHI (YYYYAAGG), BASLANGIC_VNO/BITIS_VNO, BASTCKN/BITTCKN, VKNYEGORESORGULAMA,
  IHBARNAME_DURUMU (+_ACIKLAMA), VERGI_KODU, DAYANAK (+_ACIKLAMA), SIRALAMA (+_SEKLI), MUDURLUK, MUDURLUKSTR.
  İhbarname durumu kodları: 1 Geçici İhbarname, 2 Onaylanmış, 3 Uzlaşılmış,
  4 Tebliğ Edilmiş, 5 Tebliğ Edilmemiş, 6 Uzlaşılmamış, 7 Tebliğ Edilemedi.
  Dayanak: Hepsi veya 10–46 ve 90 (KEYS listesinin tamamı).

Rapor yalnız PDF (her ihbarname bir sayfa). Başlangıç ay/yıl – bitiş ay/yıl arasındaki her ay ayrı istenir, PDF pdf.js ile
sayfa sayfa okunur: İHBARNAME FİŞİ BİLGİLERİ (29 alan, iki sütun, kaydırılmış ünvan satırları birleştirilir),
İHBARNAME EKLERİ ve CEZALAR tabloları (başlıkların konumundan sütunlar bulunur; varsa VERGİLER tablosu da), Toplam Ceza Tutarı.
"Sütunlar ▾" ile ihbarname bilgileri, ek ve ceza sütunları ayrı ayrı seçilir (saklanır); birden çok ek/ceza alt alta yazılır.
Ayrıca Sorumlu (personel VKN aralıkları) ve Sorgu Ayı sütunları. Süzgeç: İhbarname Durumu, Sorumlu, serbest arama.
Excel (.xlsx: liste + parametreler) ve yatay yazdırma.
PDF baytları için TAKKOM PDF Okuyucu uzantısı v1.1 (10.251.63.99/evdorapor_server/pdf izinli) gerekebilir; EVDO rapor tokeni gerekir.

v1.8: Gerçek PDF düzeltmeleri — (1) uzun ünvan sağ sütundaki etikete bitişik olduğunda ("MAKİNE Tebliğ Giriş Tarihi")
etiket artık değerle birleşmiyor; (2) bir sayfada birden çok ihbarname olabiliyor, her "İHBARNAME FİŞİ BİLGİLERİ" başlığı
ayrı kayıt; (3) başlığı olmayan sayfa/sayfa üstü (ek ve ceza tabloları sonraki sayfaya taşmışsa) önceki ihbarnameye eklenir,
boş fiş satırı oluşmaz.

v1.11: Kişi bazlı özet tablosu (Sorumlu · ihbarname sayısı · mükellef sayısı · toplam ceza tutarı · vergi farkı toplamı + Toplam);
süzgeçlere uyar, satıra tıklayınca o kişinin listesi süzülür. Excel'de 'Kişi Özeti' sayfası.
