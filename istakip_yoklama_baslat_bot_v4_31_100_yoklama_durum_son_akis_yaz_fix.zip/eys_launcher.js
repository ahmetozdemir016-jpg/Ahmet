(() => {
  'use strict';
  if (window.__istakipEysLauncherLoaded) return;
  window.__istakipEysLauncherLoaded = true;
  function hideLauncher(){ try { const x = document.getElementById('istakip-eys-launcher'); if (x) x.style.display = 'none'; } catch(_){} }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hideLauncher, { once:true }); else hideLauncher();
  try { setInterval(hideLauncher, 1000); } catch(_){}
})();
