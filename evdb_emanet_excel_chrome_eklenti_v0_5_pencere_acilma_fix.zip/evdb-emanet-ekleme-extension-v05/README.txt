EVDB Emanet Excel Aktarım Botu v0.5

Bu sürümde sayfa içi pencerenin ilk tıklamada açılıp hemen gizlenmesi sorunu düzeltildi.

Kurulum:
1) Zip dosyasını çıkarın.
2) chrome://extensions sayfasını açın.
3) Eski EVDB Emanet eklentisini kaldırın veya devre dışı bırakın.
4) Geliştirici modu açıkken Paketlenmemiş öğe yükle deyin.
5) evdb-emanet-ekleme-extension-v05 klasörünü seçin.
6) EVDB sayfasını Ctrl+R ile yenileyin.
7) Pencere görünmezse eklenti ikonuna bir kere tıklayın.

Not: Pencere sayfanın sağ üstünde açılır; sürüklenebilir.
