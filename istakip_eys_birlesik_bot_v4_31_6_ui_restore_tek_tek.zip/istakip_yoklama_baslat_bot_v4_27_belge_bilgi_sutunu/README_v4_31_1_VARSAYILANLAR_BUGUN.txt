v4.31.6 EYS Varsayılanlar + Bugün Butonu

Filtreli İşlem:
- Filtre başlangıç alanına Bugün butonu eklendi.
- Bugün butonuna basınca filtre başlangıcı bugünün tarihi olur.
- Varsayılanlar:
  Rol: Müdür
  Servis: 60 — Sicil yoklama
  Veri kaynağı: 0 — Kullanılan veriler
  Yoklama durumu: Hepsi / boş
  İşlem durumu: 1 — İşlem yapılacaklar
  VKN Başlangıç: 0000000000
  VKN Bitiş: 9999999999

Günlük PDF:
- Günlük tarih alanına dokunulmadı.
- Varsayılanlar:
  Rol: Memur
  Servis: 91 — İnteraktif VD
  Veri kaynağı: 0 — Kullanılan veriler
  Yoklama durumu: 60 — Yoklama sonuçlandı
  İşlem durumu: 1 — İşlem yapılacaklar
  PDF arası bekleme: 1800
  VKN Başlangıç: 0000000000
  VKN Bitiş: 9999999999
