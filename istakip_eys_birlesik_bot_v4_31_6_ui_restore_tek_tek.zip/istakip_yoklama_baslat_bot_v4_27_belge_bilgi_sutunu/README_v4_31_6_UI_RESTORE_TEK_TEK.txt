v4.31.6 UI Restore + EYS Akış Tek Tek Gönderim

Bu sürüm v4.31.4 sağlam arayüzü baz alınarak hazırlandı.
v4.31.5'te bozulan EYS panel görüntüsü geri alındı.

Korunanlar:
- Ana Modül / EYS Modülü sekmeli yapı
- EYS içindeki Akış / Filtreli İşlem / Günlük PDF görünümü
- Filtreli işlem varsayılanları
- Bugün butonu
- Günlük PDF VKN filtreleri
- Popup PDF açma mantığı
- CFG fix

Eklenen:
- EYS Akışta Memur → Müdür kayıtları tek tek gönderilir.
- EYS Akışta Müdür → Koordinatör kayıtları tek tek gönderilir.
- Müdür aşamasında önce srvcYoklama_getIadeler ile iade kayıtları sorgulanır.
- İade listesinde olan yKodu'lar tekrar koordinatöre gönderilmez.
