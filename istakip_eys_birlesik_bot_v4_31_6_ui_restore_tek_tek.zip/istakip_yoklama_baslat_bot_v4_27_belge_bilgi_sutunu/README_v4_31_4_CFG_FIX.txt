v4.31.6 CFG Fix

Düzeltilen hata:
- content.js içinde resize eventinde CFG.PANEL_ID dış scope'ta kullanıldığı için:
  Uncaught ReferenceError: CFG is not defined

Düzeltme:
- Hatalı satır güvenli hale getirildi.
- CFG yoksa sabit panel id kullanılır:
  istakip-yoklama-bot-panel-v419
- setupUnifiedModuleTabs interval çağrısı da güvenli hale getirildi.
