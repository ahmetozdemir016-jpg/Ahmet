Son çalışan v4.31.2.33 temel alınmıştır.
VKN filtresi bu kez dış DOM katmanı olarak değil, renderRows akışının içine entegre edilmiştir.
İşleri Tara sonrası gelen ham liste saklanır; VKN başlangıç/bitiş yazıldıkça tablo yeniden render edilerek süzülür.
VKN 10 hane ile sınırlandırılır. Boşsa tüm işler gösterilir.
