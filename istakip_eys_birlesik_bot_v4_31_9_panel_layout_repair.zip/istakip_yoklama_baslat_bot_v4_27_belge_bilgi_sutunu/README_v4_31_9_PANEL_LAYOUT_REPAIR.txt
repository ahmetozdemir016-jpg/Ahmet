v4.31.9 Panel Layout Repair

Düzeltilen sorun:
- Panelde sadece VKN/keşif alanı görünüp alt tarafın siyah boş kalması
- Çift/yanlış scroll bar görünümü
- Ana modül içeriğinin eski sekme taşıma mantığında kaybolması

Yapılanlar:
- Ana modül elemanları artık it_main_tab_page içine taşınmıyor.
- Eski taşınmış alan varsa otomatik geri çıkarılıyor.
- Ana Modül sekmesinde ana içerik zorla görünür yapılıyor.
- EYS Modülü sekmesinde EYS paneli ayrı alana taşınıyor.
- Bugün ve CFG düzeltmeleri korunuyor.
