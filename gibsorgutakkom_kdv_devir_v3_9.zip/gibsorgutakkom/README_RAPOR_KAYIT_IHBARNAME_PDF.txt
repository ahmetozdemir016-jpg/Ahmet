RAPOR KAYIT DEFTERİNE GÖRE KONTROL – İHBARNAME PDF KONTROLÜ (v2)

Düzeltme: İhbarname, EVDO ihbDurum=3 olduğu için "iptal" sayılıyordu; Onaylanmış (iptal olmayan) özel usulsüzlük ihbarnamesinde de
3 gelebildiği görüldü. Artık iptal = vergi ve tüm cezalar sıfır; kesin durum ihbarname sorgulama PDF'indeki "İhbarname Durumu"dan okunur.
PDF "iptal" demiyorsa üstü çizili fiş no ve "(EVDO: iptal)" ibaresi kaldırılır.

İhbarname Bazında Kontrol sütununda her fiş için (EVDB "İhbarname Sorgulama" PDF'i, ihbarname no'ya tıklayınca açılan belge, okunur):
- Durum: Onaylanmış / İPTAL
- Ceza tutarı: ihbarnamedeki her ceza (Toplam − Tek.) rapor kayıt defterindeki VİR tutarıyla (VZ / U / ÖU) karşılaştırılır
- Ek / dayanak: İhbarname Ekleri satırının türü (İNCE.RAPORU), numarası RAPOR KAYIT DEFTERİ NO (ör. 2026092950QAF0000005)
  ve tarihi rapor kayıt defteri tarihi (kayıt no'nun ilk 8 hanesi, ör. 29/09/2026) olmalı; değilse EK HATALI
- Tarhiyat/ceza açıklaması: tam metin; içinde rapor numarası ve rapor tarihi geçiyor mu
- Kesilen cezanın nedeni: ceza kaydındaki neden metni (ör. 77-Mük. 355/1-1 ... Gereğince), kısaltılmadan
- Tekerrür: her ceza için tarhiyatService_tekerrurUygulamasinasebepIhbListesi ile tekerrüre esas kesinleşmiş ceza var mı;
  ihbarnamede (PDF 'Tek.') tekerrür uygulanmış mı. 3080/3073'te VUK 339 artırımı hesaplanıp karşılaştırılır; diğer cezalarda
  esas ceza var ama tekerrür yoksa KONTROL, esas yokken tekerrür varsa HATA.
PDF baytları file:// sayfadan okunamazsa TAKKOM PDF Okuyucu uzantısı v1.1 gerekir (eklentiler/takkom_pdf_okuyucu_v1, yeniden yükleyin).
EVDB Rapor tokeni gerekir (ihbarname PDF'ini açan tokenle aynı). "İmza durumlarını yenile" PDF kontrolünü de yeniler.

v2.1: Ek kontrolü rapor kayıt defteri no/tarihine göre yapılıyor (önce yanlışlıkla evrak no ile kıyaslanıyordu).
İhbarname Durumu okunamama sorunu: PDF'te İ harfi ayrık (I + nokta) geldiğinde başlık tanınmıyordu; düzeltildi.
v2.2: 'İhbarname Durumu' etiketi ile değeri PDF'te farklı satıra düştüğünde (yükseklik farkı) konumdan eşleştiriliyor;
yine okunamazsa hücrede 'PDF metnini göster' açılır kutusu çıkar (sorun gidermek için).

v2.3 (09.10.2026)
- Bir dönemde birden çok ihbarname varsa, tarh bilgisiyle birlikte her ihbarnamenin EVDB sorgulama PDF'i de okunur ve
  "İhbarname Durumu: İptal" olan ihbarname kesin olarak iptal sayılır (artık "tekrar" sanılmaz; tutarları sıfır olmasa da).
  İhbarname No sütununda "(iptal)", kontrol sütununda "(EVDB: iptal)" yazar. PDF okunamazsa eski kural (vergi+ceza sıfır) geçerli.
- Vergi uyumu: raporda "Tarhı İstenen Vergi" 0 görünüp tarhiyat öncesi uzlaşmada aynı vergi kodu için uzlaşılan tutar
  ihbarnamedeki vergiye eşitse karşılaştırma uzlaşılan tutarla yapılır ("uzlaşılan" notu) → UYUMLU.
- v2.4: Tarhiyat öncesi uzlaşma yapılmış dönemde rapor satırının vergisi 0 gelir; ihbarnamedeki vergi UYUMSUZ sayılmaz,
  Vergi Uyum 'Uzlaşma' (ceza sütunundaki gibi), fark '-' olur. Satır rengi uyarı (sarı) kalır.

v2.5 (09.10.2026)
- Vergi Uyum: cezada tarhiyat öncesi uzlaşma olması vergiyi "Uzlaşma" saymaz. Vergi için "Uzlaşma" yalnız uzlaşma
  listesinde verginin kendi koduyla kayıt varsa yazılır; aksi halde raporun vergisi, iptal olmayan son ihbarnamedeki
  vergiyle doğrudan kıyaslanır (UYUMLU / UYUMSUZ + fark).
- İhbarname No sütunu: numaraya tıklayınca her zaman EVDB İhbarname Sorgulama PDF'i (tarh defteri belgesi) açılır;
  yanındaki küçük "e-Teb" bağlantısı e-Tebligat belgesini ekleriyle açar. (Önceden e-Tebligat'ta bulunursa oradan,
  bulunmazsa EVDB'den açılıyordu; bu tutarsızlık giderildi.)
- EVDB PDF'leri keys.ggm.bim üzerinden açılır.
