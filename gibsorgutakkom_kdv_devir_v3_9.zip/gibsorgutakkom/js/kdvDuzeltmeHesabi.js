(function(global){
  'use strict';

  var MAX_MONTHS = 60;

  function numberValue(value){
    if(value === null || value === undefined || value === '') return 0;
    if(typeof value === 'number') return isFinite(value) ? value : 0;
    var text=String(value).trim(), negative=false;
    if(!text || text==='-' || /^HATA$/i.test(text) || /^NaN$/i.test(text)) return 0;
    if(/^\(.*\)$/.test(text)){ negative=true; text=text.slice(1,-1); }
    text=text.replace(/\s/g,'').replace(/[^0-9,\.\-]/g,'');
    if(text.charAt(0)==='-'){ negative=true; text=text.slice(1); }
    var comma=text.lastIndexOf(','), dot=text.lastIndexOf('.');
    if(comma>=0 && dot>=0) text=comma>dot ? text.replace(/\./g,'').replace(',','.') : text.replace(/,/g,'');
    else if(comma>=0){ var cp=text.split(','); text=cp.length===2 && cp[1].length<=2 ? text.replace(',','.') : text.replace(/,/g,''); }
    else if(dot>=0){ var dp=text.split('.'); if(dp.length>2 || (dp.length===2 && dp[1].length===3)) text=text.replace(/\./g,''); }
    var parsed=parseFloat(text); if(!isFinite(parsed)) return 0;
    return negative ? -parsed : parsed;
  }
  function nonNegative(value){ return Math.max(0,numberValue(value)); }
  function roundMoney(value){ return Math.round((numberValue(value)+1e-9)*100)/100; }
  function money(value){ return roundMoney(value).toLocaleString('tr-TR',{minimumFractionDigits:2,maximumFractionDigits:2}); }
  function esc(value){ return String(value==null?'':value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function inputValue(value){ return numberValue(value) ? String(numberValue(value)).replace('.',',') : ''; }
  function differenceClass(value){ return numberValue(value)>0?'kdvh-increase':(numberValue(value)<0?'kdvh-decrease':''); }
  function defaultRateForPeriod(period){ return String(period||'')<'2023-07' ? 18 : 20; }
  function rateListForPeriod(period){ return String(period||'')<'2023-07' ? 'kdvhRatesOld' : 'kdvhRatesNew'; }
  function withholdingRatio(value){
    if(value===null || value===undefined || String(value).trim()==='') return 0;
    var text=String(value).trim().replace(/%/g,'').replace(/\s/g,'');
    if(text.indexOf('/')>=0){ var p=text.split('/'), n=numberValue(p[0]), d=numberValue(p[1]); return d>0 ? Math.max(0,Math.min(1,n/d)) : 0; }
    var n=numberValue(text); if(n>1) n=n/100; return Math.max(0,Math.min(1,n));
  }
  function withholdingDisplay(value){
    var ratio=withholdingRatio(value); if(!ratio) return '';
    var tenths=Math.round(ratio*10); if(Math.abs(ratio-tenths/10)<0.000001) return tenths+'/10';
    return String(roundMoney(ratio*100)).replace('.',',');
  }
  function adjustmentItems(adjustment,period,includeEmpty){
    adjustment=adjustment||{}; var items=[], raw=adjustment.items;
    if(Array.isArray(raw)){
      for(var i=0;i<raw.length;i++) items.push({base:roundMoney(nonNegative(raw[i]&&raw[i].base)),rate:nonNegative(raw[i]&&raw[i].rate),withholding:withholdingDisplay(raw[i]&&raw[i].withholding)});
    }else if(adjustment.base!==undefined || adjustment.rate!==undefined){
      items.push({base:roundMoney(nonNegative(adjustment.base)),rate:nonNegative(adjustment.rate)||defaultRateForPeriod(period),withholding:withholdingDisplay(adjustment.withholding)});
    }else{
      if(nonNegative(adjustment.base1)) items.push({base:roundMoney(nonNegative(adjustment.base1)),rate:1,withholding:''});
      if(nonNegative(adjustment.base10)) items.push({base:roundMoney(nonNegative(adjustment.base10)),rate:10,withholding:''});
      if(nonNegative(adjustment.base20)) items.push({base:roundMoney(nonNegative(adjustment.base20)),rate:20,withholding:''});
    }
    if(includeEmpty && !items.length) items.push({base:0,rate:defaultRateForPeriod(period),withholding:''});
    return items;
  }

  function calculate(sourceRows,adjustments){
    var rows=(sourceRows||[]).slice(0,MAX_MONTHS), output=[], previousCarryDifference=0;
    for(var i=0;i<rows.length;i++){
      var source=rows[i]||{}, adjustment=(adjustments&&adjustments[source.period])||{};
      var items=adjustmentItems(adjustment,source.period,false), additionalBase=0, additionalGrossVat=0, withheldVat=0, additionalVat=0;
      for(var j=0;j<items.length;j++){
        var lineGrossVat=roundMoney(items[j].base*items[j].rate/100);
        var lineWithheldVat=roundMoney(lineGrossVat*withholdingRatio(items[j].withholding));
        additionalBase=roundMoney(additionalBase+items[j].base);
        additionalGrossVat=roundMoney(additionalGrossVat+lineGrossVat);
        withheldVat=roundMoney(withheldVat+lineWithheldVat);
        additionalVat=roundMoney(additionalVat+lineGrossVat-lineWithheldVat);
      }
      var rejectedInputVat=roundMoney(nonNegative(adjustment.rejectedInputVat));
      // Beyan zincirinde düzeltme beyannamesi, yuvarlama veya başka bir nedenle bir ayın
      // sonraki devri ile takip eden ayın önceki devri farklı olabilir. Bu nedenle normal
      // beyanı yeniden kurmuyoruz; yalnızca yapılan düzeltmenin farkını beyan tutarlarına taşırız.
      var declaredPreviousCarry=roundMoney(source.declaredPreviousCarry);
      var adjustedPreviousCarry=roundMoney(Math.max(0,declaredPreviousCarry+previousCarryDifference));
      var appliedPreviousDifference=roundMoney(adjustedPreviousCarry-declaredPreviousCarry);
      var adjustedTotalDeductible=roundMoney(Math.max(0,roundMoney(source.declaredTotalDeductible)+appliedPreviousDifference-rejectedInputVat));
      // Bu döneme ait indirilecek KDV: ret bu kalemden düşülür. Ret, bu dönemin indiriminden büyükse uyarı verilir.
      var declaredCurrentDeduction=roundMoney(numberValue(source.declaredCurrentDeduction));
      var adjustedCurrentDeduction=roundMoney(Math.max(0,declaredCurrentDeduction-rejectedInputVat));
      var rejectionExceedsCurrent=rejectedInputVat>declaredCurrentDeduction+0.004;
      var adjustedMatrah=roundMoney(source.declaredMatrah+additionalBase);
      var adjustedCalculatedVat=roundMoney(source.declaredCalculatedVat+additionalVat);
      var declaredAddedVat=roundMoney(source.declaredAddedVat);
      var adjustedAddedVat=declaredAddedVat;
      var adjustedTotalVat=roundMoney(source.declaredTotalVat+additionalVat);
      var refundVat=roundMoney(nonNegative(source.declaredRefundVat));
      var adjustmentBurden=roundMoney(additionalVat+rejectedInputVat-appliedPreviousDifference);

      // Beyan devri ve iade KDV, iade öncesi toplam alacak bakiyesinin iki parçasıdır.
      // Düzeltme bu bakiyeyi azaltır. Önce beyan edilen iade korunabildiği kadar korunur;
      // bakiye yetmezse iade azalır/sıfırlanır, toplam bakiyeyi aşan kısım ödenecek olur.
      var declaredBalanceBeforeRefund=roundMoney(numberValue(source.declaredNextCarry)+refundVat);
      var adjustedBalanceBeforeRefund=roundMoney(Math.max(0,declaredBalanceBeforeRefund-adjustmentBurden));
      var adjustedRefundVat=roundMoney(Math.min(refundVat,adjustedBalanceBeforeRefund));
      var refundDifference=roundMoney(adjustedRefundVat-refundVat);
      var adjustedCarry=roundMoney(Math.max(0,adjustedBalanceBeforeRefund-adjustedRefundVat));
      var burdenBeyondBalance=roundMoney(Math.max(0,adjustmentBurden-declaredBalanceBeforeRefund));
      var payableDifference=burdenBeyondBalance;
      var adjustedPayable=roundMoney(numberValue(source.declaredPayableVat)+payableDifference);
      var carryDifference=roundMoney(adjustedCarry-roundMoney(source.declaredNextCarry));
      if(additionalVat===0 && rejectedInputVat===0 && appliedPreviousDifference===0){
        adjustedRefundVat=refundVat;
        refundDifference=0;
        adjustedCarry=roundMoney(source.declaredNextCarry);
        adjustedPayable=roundMoney(source.declaredPayableVat);
        payableDifference=0;
        carryDifference=0;
      }
      output.push({period:source.period,declaredMatrah:roundMoney(source.declaredMatrah),declaredCalculatedVat:roundMoney(source.declaredCalculatedVat),declaredAddedVat:declaredAddedVat,adjustedAddedVat:adjustedAddedVat,declaredPreviousCarry:declaredPreviousCarry,declaredCurrentDeduction:declaredCurrentDeduction,adjustedCurrentDeduction:adjustedCurrentDeduction,rejectionExceedsCurrent:rejectionExceedsCurrent,declaredTotalDeductible:roundMoney(source.declaredTotalDeductible),declaredTotalVat:roundMoney(source.declaredTotalVat),additionalItems:items,additionalBase:additionalBase,additionalGrossVat:additionalGrossVat,withheldVat:withheldVat,additionalVat:additionalVat,adjustedMatrah:adjustedMatrah,rejectedInputVat:rejectedInputVat,adjustedCalculatedVat:adjustedCalculatedVat,adjustedPreviousCarry:adjustedPreviousCarry,adjustedTotalDeductible:adjustedTotalDeductible,adjustedTotalVat:adjustedTotalVat,refundVat:refundVat,adjustedRefundVat:adjustedRefundVat,refundDifference:refundDifference,declaredPayableVat:roundMoney(source.declaredPayableVat),adjustedPayable:adjustedPayable,payableDifference:payableDifference,declaredNextCarry:roundMoney(source.declaredNextCarry),adjustedCarry:adjustedCarry,carryDifference:carryDifference});
      previousCarryDifference=carryDifference;
    }
    return output;
  }

  function storageKey(vkn){ return 'takkom_kdv_devir_hesabi_v2_'+String(vkn||'').replace(/\D/g,''); }
  function loadAdjustments(vkn){ try{ var d=JSON.parse(localStorage.getItem(storageKey(vkn))||'{}'); return d&&d.adjustments?d.adjustments:{}; }catch(e){ return {}; } }
  function saveAdjustments(vkn,adjustments){ try{ localStorage.setItem(storageKey(vkn),JSON.stringify({version:2,vkn:String(vkn||'').replace(/\D/g,''),updatedAt:(new Date()).toISOString(),adjustments:adjustments})); }catch(e){} }
  function readAdjustments(panel){
    var data={};
    Array.prototype.forEach.call(panel.querySelectorAll('tr[data-kdvh-period]'),function(row){
      var items=[];
      Array.prototype.forEach.call(row.querySelectorAll('.kdvh-entry'),function(entry){
        var base=roundMoney(nonNegative(entry.querySelector('[data-kdvh-field="base"]').value));
        var rate=nonNegative(entry.querySelector('[data-kdvh-field="rate"]').value);
        var withholding=entry.querySelector('[data-kdvh-field="withholding"]');
        if(base) items.push({base:base,rate:rate,withholding:withholdingDisplay(withholding&&withholding.value)});
      });
      var rejected=row.querySelector('[data-kdvh-field="rejectedInputVat"]');
      data[row.getAttribute('data-kdvh-period')]={items:items,rejectedInputVat:roundMoney(nonNegative(rejected&&rejected.value))};
    });
    return data;
  }

  function entryHtml(period,item){
    item=item||{};
    return '<div class="kdvh-entry"><input class="kdvh-base" data-kdvh-field="base" inputmode="decimal" value="'+esc(inputValue(item.base))+'" placeholder="Matrah"><span class="kdvh-rate-sep">×</span><input class="kdvh-rate" data-kdvh-field="rate" inputmode="decimal" list="'+rateListForPeriod(period)+'" value="'+esc(inputValue(item.rate||defaultRateForPeriod(period)))+'" placeholder="KDV"><span>%</span><span class="kdvh-withholding-label">Tevkifat</span><input class="kdvh-withholding" data-kdvh-field="withholding" inputmode="decimal" list="kdvhWithholdingRates" value="'+esc(withholdingDisplay(item.withholding))+'" placeholder="Yok"><button type="button" class="kdvh-entry-remove" title="Satırı kaldır">−</button></div>';
  }

  function renderRows(panel,sourceRows,adjustments){
    var result=calculate(sourceRows,adjustments), body=panel.querySelector('#kdvhBody'), html='';
    var totals={base:0,grossVat:0,withheldVat:0,vat:0,rejected:0,refund:0,adjustedRefund:0,payableDifference:0,rates:{}};
    for(var i=0;i<result.length;i++){
      var row=result[i], input=adjustments[row.period]||{};
      var entries=adjustmentItems(input,row.period,true), entriesHtml='';
      for(var e=0;e<entries.length;e++) entriesHtml+=entryHtml(row.period,entries[e]);
      for(var t=0;t<row.additionalItems.length;t++){
        var rateKey=String(row.additionalItems[t].rate).replace('.',',');
        totals.rates[rateKey]=roundMoney((totals.rates[rateKey]||0)+row.additionalItems[t].base);
      }
      totals.base+=row.additionalBase; totals.grossVat+=row.additionalGrossVat; totals.withheldVat+=row.withheldVat; totals.vat+=row.additionalVat; totals.rejected+=row.rejectedInputVat; totals.refund+=row.refundVat; totals.adjustedRefund+=row.adjustedRefundVat; totals.payableDifference+=row.payableDifference;
      html+='<tr data-kdvh-period="'+esc(row.period)+'"><td class="kdvh-period">'+esc(row.period)+'</td><td class="kdvh-entry-cell">'+entriesHtml+'<button type="button" class="kdvh-entry-add" data-kdvh-add="1">+ Matrah / Oran Ekle</button></td><td><input data-kdvh-field="rejectedInputVat" inputmode="decimal" value="'+esc(inputValue(input.rejectedInputVat))+'" placeholder="0,00"></td>'+
        '<td class="kdvh-money">'+money(row.declaredMatrah)+'</td><td class="kdvh-money">'+money(row.adjustedMatrah)+'</td>'+
        '<td class="kdvh-money">'+money(row.declaredCalculatedVat)+'</td><td class="kdvh-money">'+money(row.adjustedCalculatedVat)+'</td><td class="kdvh-money">'+money(row.declaredAddedVat)+'</td><td class="kdvh-money">'+money(row.adjustedAddedVat)+'</td>'+
        '<td class="kdvh-money">'+money(row.declaredTotalVat)+'</td><td class="kdvh-money">'+money(row.adjustedTotalVat)+'</td>'+
        '<td class="kdvh-money">'+money(row.declaredPreviousCarry)+'</td><td class="kdvh-money">'+money(row.adjustedPreviousCarry)+'</td>'+
        '<td class="kdvh-money">'+money(row.declaredCurrentDeduction)+'</td><td class="kdvh-money'+(row.rejectionExceedsCurrent?' kdvh-warn" title="Reddedilen indirim bu dönemin indirilecek KDV\'sinden büyük!':'"')+'>'+money(row.adjustedCurrentDeduction)+(row.rejectionExceedsCurrent?' ⚠':'')+'</td>'+
        '<td class="kdvh-money">'+money(row.declaredTotalDeductible)+'</td><td class="kdvh-money">'+money(row.adjustedTotalDeductible)+'</td>'+
        '<td class="kdvh-money">'+money(row.refundVat)+'</td><td class="kdvh-money">'+money(row.adjustedRefundVat)+'</td><td class="kdvh-money">'+money(row.declaredPayableVat)+'</td><td class="kdvh-money">'+money(row.adjustedPayable)+'</td>'+
        '<td class="kdvh-money '+differenceClass(row.payableDifference)+'">'+money(row.payableDifference)+'</td><td class="kdvh-money">'+money(row.declaredNextCarry)+'</td><td class="kdvh-money">'+money(row.adjustedCarry)+'</td></tr>';
    }
    body.innerHTML=html;
    var rateSummary=[], rateKeys=Object.keys(totals.rates).sort(function(a,b){ return numberValue(a)-numberValue(b); });
    for(var k=0;k<rateKeys.length;k++) rateSummary.push('%'+rateKeys[k]+' matrah: <b>'+money(totals.rates[rateKeys[k]])+'</b>');
    var asanlar=result.filter(function(r){return r.rejectionExceedsCurrent;}).map(function(r){return r.period+' (ret '+money(r.rejectedInputVat)+' > bu dönem indirimi '+money(r.declaredCurrentDeduction)+')';});
    panel.querySelector('#kdvhSummary').innerHTML=(asanlar.length?'<div class="kdvh-warn" style="padding:4px 6px;margin-bottom:4px">⚠ Reddedilen indirim o ayın "bu döneme ait indirilecek KDV" tutarını aşıyor: '+asanlar.join('; ')+'. Ret birden çok aya aitse her ayın kendi satırına girilmeli.</div>':'')+'<b>'+result.length+' dönem hesaplandı.</b> İlave matrah: <b>'+money(totals.base)+'</b>'+(rateSummary.length?' ('+rateSummary.join(' | ')+')':'')+' | Brüt ilave KDV: <b>'+money(totals.grossVat)+'</b> | Tevkif edilen KDV: <b>'+money(totals.withheldVat)+'</b> | Beyan edilecek ilave KDV: <b>'+money(totals.vat)+'</b> | Reddedilen indirim: <b>'+money(totals.rejected)+'</b> | Beyan iade KDV: <b>'+money(totals.refund)+'</b> | Düzeltilmiş iade KDV: <b>'+money(totals.adjustedRefund)+'</b> | Ödenecek farkı: <b>'+money(totals.payableDifference)+'</b>';
    return result;
  }

  function additionalItemsText(row){
    var parts=[];
    for(var i=0;i<row.additionalItems.length;i++){
      if(row.additionalItems[i].base) parts.push(money(row.additionalItems[i].base)+' × %'+String(row.additionalItems[i].rate).replace('.',',')+(withholdingRatio(row.additionalItems[i].withholding)?' (Tevkifat '+withholdingDisplay(row.additionalItems[i].withholding)+')':''));
    }
    return parts.length ? parts.join(' | ') : '—';
  }

  function printAdditionalItems(row){
    return esc(additionalItemsText(row)).replace(/ \| /g,'<br>');
  }

  function buildPrintSheet(result,vkn){
    var old=document.getElementById('kdvhPrintSheet'); if(old&&old.parentNode) old.parentNode.removeChild(old);
    var groups={}, order=[];
    for(var i=0;i<result.length;i++){
      var year=String(result[i].period).slice(0,4);
      if(!groups[year]){ groups[year]=[]; order.push(year); }
      groups[year].push(result[i]);
    }
    var html='';
    for(var g=0;g<order.length;g++){
      var y=order[g], rows=groups[y], body='', totals={base:0,grossVat:0,withheldVat:0,vat:0,rejected:0,refund:0,adjustedRefund:0,payable:0};
      for(var r=0;r<rows.length;r++){
        var x=rows[r]; totals.base+=x.additionalBase; totals.grossVat+=x.additionalGrossVat; totals.withheldVat+=x.withheldVat; totals.vat+=x.additionalVat; totals.rejected+=x.rejectedInputVat; totals.refund+=x.refundVat; totals.adjustedRefund+=x.adjustedRefundVat; totals.payable+=x.payableDifference;
        body+='<tr><td>'+esc(x.period)+'</td><td class="input">'+printAdditionalItems(x)+'</td><td class="num">'+money(x.rejectedInputVat)+'</td><td class="num old">'+money(x.declaredMatrah)+'</td><td class="num new">'+money(x.adjustedMatrah)+'</td><td class="num old">'+money(x.declaredCalculatedVat)+'</td><td class="num new">'+money(x.adjustedCalculatedVat)+'</td><td class="num old">'+money(x.declaredAddedVat)+'</td><td class="num new">'+money(x.adjustedAddedVat)+'</td><td class="num old">'+money(x.declaredTotalVat)+'</td><td class="num new">'+money(x.adjustedTotalVat)+'</td><td class="num old">'+money(x.declaredPreviousCarry)+'</td><td class="num new">'+money(x.adjustedPreviousCarry)+'</td><td class="num old">'+money(x.declaredCurrentDeduction)+'</td><td class="num new">'+money(x.adjustedCurrentDeduction)+(x.rejectionExceedsCurrent?' ⚠':'')+'</td><td class="num old">'+money(x.declaredTotalDeductible)+'</td><td class="num new">'+money(x.adjustedTotalDeductible)+'</td><td class="num old">'+money(x.refundVat)+'</td><td class="num new">'+money(x.adjustedRefundVat)+'</td><td class="num old">'+money(x.declaredPayableVat)+'</td><td class="num new">'+money(x.adjustedPayable)+'</td><td class="num strong">'+money(x.payableDifference)+'</td><td class="num old">'+money(x.declaredNextCarry)+'</td><td class="num new">'+money(x.adjustedCarry)+'</td></tr>';
      }
      html+='<section class="kdvh-print-year"><div class="kdvh-print-title">Yıllık KDV Devir Hesabı</div><div class="kdvh-print-meta"><b>VKN/TCKN:</b> '+esc(vkn||'-')+' &nbsp; <b>Yıl:</b> '+esc(y)+'</div><table class="kdvh-print-table"><colgroup><col class="kdvh-print-period-col"><col class="kdvh-print-input-col"><col class="kdvh-print-rejected-col"><col span="19" class="kdvh-print-number-col"></colgroup><thead><tr><th rowspan="2">Dönem</th><th rowspan="2">İlave Matrah / Oran / Tevkifat</th><th rowspan="2">Reddedilen İndirim</th><th colspan="2">Matrah</th><th colspan="2">Hesaplanan KDV</th><th colspan="2">İlave Edilecek KDV</th><th colspan="2">Toplam KDV</th><th colspan="2">Önceki Dönem Devri</th><th colspan="2">Bu Dönem İndirimi</th><th colspan="2">Toplam İndirim</th><th colspan="2">İade KDV</th><th colspan="3">Ödenecek KDV</th><th colspan="2">Devreden KDV</th></tr><tr><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Beyan</th><th>Düz.</th><th>Fark</th><th>Beyan</th><th>Düz.</th></tr></thead><tbody>'+body+'</tbody></table><div class="kdvh-print-summary"><b>Yıl toplamı:</b> İlave matrah '+money(totals.base)+' | Brüt ilave KDV '+money(totals.grossVat)+' | Tevkif edilen KDV '+money(totals.withheldVat)+' | Beyan edilecek ilave KDV '+money(totals.vat)+' | Reddedilen indirim '+money(totals.rejected)+' | Beyan iade KDV '+money(totals.refund)+' | Düzeltilmiş iade KDV '+money(totals.adjustedRefund)+' | Ödenecek farkı '+money(totals.payable)+'</div></section>';
    }
    var sheet=document.createElement('div'); sheet.id='kdvhPrintSheet'; sheet.innerHTML=html; document.body.appendChild(sheet);
  }

  function excelEsc(value){ return esc(value).replace(/\r?\n/g,'&#10;'); }
  function excelString(value,style,mergeAcross,mergeDown){
    return '<Cell ss:StyleID="'+(style||'txt')+'"'+(mergeAcross?' ss:MergeAcross="'+mergeAcross+'"':'')+(mergeDown?' ss:MergeDown="'+mergeDown+'"':'')+'><Data ss:Type="String">'+excelEsc(value)+'</Data></Cell>';
  }
  function excelNumber(value,style){ return '<Cell ss:StyleID="'+(style||'num')+'"><Data ss:Type="Number">'+roundMoney(value)+'</Data></Cell>'; }
  function exportExcel(result,vkn,sourceRows){
    if(!result||!result.length){ global.alert('Excel’e aktarılacak dönem bulunamadı.'); return; }
    var groups={}, order=[];
    for(var i=0;i<result.length;i++){ var year=String(result[i].period).slice(0,4); if(!groups[year]){groups[year]=[];order.push(year);} groups[year].push(result[i]); }
    var xml='<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>'+
      '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'+
      '<Styles><Style ss:ID="Default" ss:Name="Normal"><Font ss:FontName="Calibri" ss:Size="9"/><Alignment ss:Vertical="Center"/></Style><Style ss:ID="title"><Font ss:Bold="1" ss:Size="14"/><Alignment ss:Horizontal="Center"/></Style><Style ss:ID="meta"><Font ss:Bold="1"/></Style><Style ss:ID="hdr"><Font ss:Bold="1"/><Interior ss:Color="#E7E6E6" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders></Style><Style ss:ID="txt"><Alignment ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders></Style><Style ss:ID="num"><Alignment ss:Horizontal="Right" ss:Vertical="Center"/><NumberFormat ss:Format="#,##0.00"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/></Borders></Style></Styles>';
    for(var g=0;g<order.length;g++){
      var y=order[g], rows=groups[y];
      xml+='<Worksheet ss:Name="'+excelEsc(y)+'"><Table><Column ss:Width="60"/><Column ss:Width="210"/><Column ss:Width="90"/>';
      for(var c=0;c<21;c++)xml+='<Column ss:Width="82"/>';
      xml+='<Row ss:Height="24">'+excelString('Yıllık KDV Devir Hesabı','title',23,0)+'</Row><Row>'+excelString('VKN/TCKN: '+(vkn||'-')+'    Yıl: '+y,'meta',23,0)+'</Row>';
      xml+='<Row ss:Height="30">'+excelString('Dönem','hdr',0,1)+excelString('İlave Matrah / Oran / Tevkifat','hdr',0,1)+excelString('Reddedilen İndirim','hdr',0,1)+excelString('Matrah','hdr',1,0)+excelString('Hesaplanan KDV','hdr',1,0)+excelString('İlave Edilecek KDV','hdr',1,0)+excelString('Toplam KDV','hdr',1,0)+excelString('Önceki Dönem Devri','hdr',1,0)+excelString('Bu Döneme Ait İndirim','hdr',1,0)+excelString('Toplam İndirim','hdr',1,0)+excelString('İade KDV','hdr',1,0)+excelString('Ödenecek KDV','hdr',2,0)+excelString('Devreden KDV','hdr',1,0)+'</Row>';
      xml+='<Row>'+['Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Beyan','Düzeltilmiş','Fark','Beyan','Düzeltilmiş'].map(function(h){return excelString(h,'hdr');}).join('')+'</Row>';
      for(var r=0;r<rows.length;r++){
        var x=rows[r]; xml+='<Row>'+excelString(x.period,'txt')+excelString(additionalItemsText(x),'txt')+excelNumber(x.rejectedInputVat)+
          excelNumber(x.declaredMatrah)+excelNumber(x.adjustedMatrah)+excelNumber(x.declaredCalculatedVat)+excelNumber(x.adjustedCalculatedVat)+excelNumber(x.declaredAddedVat)+excelNumber(x.adjustedAddedVat)+excelNumber(x.declaredTotalVat)+excelNumber(x.adjustedTotalVat)+excelNumber(x.declaredPreviousCarry)+excelNumber(x.adjustedPreviousCarry)+excelNumber(x.declaredCurrentDeduction)+excelNumber(x.adjustedCurrentDeduction)+excelNumber(x.declaredTotalDeductible)+excelNumber(x.adjustedTotalDeductible)+excelNumber(x.refundVat)+excelNumber(x.adjustedRefundVat)+excelNumber(x.declaredPayableVat)+excelNumber(x.adjustedPayable)+excelNumber(x.payableDifference)+excelNumber(x.declaredNextCarry)+excelNumber(x.adjustedCarry)+'</Row>';
      }
      xml+='</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>4</SplitHorizontal><TopRowBottomPane>4</TopRowBottomPane><Selected/></WorksheetOptions></Worksheet>';
    }
    /* KDV beyan verileri (ham beyan tablosu) ayrı sayfa */
    if(sourceRows&&sourceRows.length){
      var bh=['Dönem','Matrah','Hesaplanan KDV','İlave Edilecek KDV','Toplam KDV','Önceki Dönem Devri','Bu Döneme Ait İndirim','Diğer İndirimler','Toplam İndirilecek KDV','Tecil Edilecek KDV','Ödenecek KDV','İade Edilecek KDV','Sonraki Döneme Devreden KDV'];
      xml+='<Worksheet ss:Name="KDV Beyanları"><Table><Column ss:Width="60"/>';for(var c2=0;c2<12;c2++)xml+='<Column ss:Width="95"/>';
      xml+='<Row ss:Height="24">'+excelString('KDV Beyan Verileri','title',12,0)+'</Row><Row>'+excelString('VKN/TCKN: '+(vkn||'-'),'meta',12,0)+'</Row>';
      xml+='<Row ss:Height="30">'+bh.map(function(h){return excelString(h,'hdr');}).join('')+'</Row>';
      for(var r2=0;r2<sourceRows.length;r2++){var q=sourceRows[r2];
        xml+='<Row>'+excelString(q.period,'txt')+excelNumber(q.declaredMatrah)+excelNumber(q.declaredCalculatedVat)+excelNumber(q.declaredAddedVat)+excelNumber(q.declaredTotalVat)+excelNumber(q.declaredPreviousCarry)+excelNumber(q.declaredCurrentDeduction)+excelNumber(q.declaredOtherDeduction)+excelNumber(q.declaredTotalDeductible)+excelNumber(q.declaredDeferredVat)+excelNumber(q.declaredPayableVat)+excelNumber(q.declaredRefundVat)+excelNumber(q.declaredNextCarry)+'</Row>';}
      xml+='</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>3</SplitHorizontal><TopRowBottomPane>3</TopRowBottomPane></WorksheetOptions></Worksheet>';}
    xml+='</Workbook>';
    var blob=new Blob([xml],{type:'application/vnd.ms-excel;charset=utf-8'}), url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download='Yillik_KDV_Devir_Hesabi_'+(vkn||'mukellef')+'.xls'; document.body.appendChild(a); a.click(); document.body.removeChild(a); setTimeout(function(){URL.revokeObjectURL(url);},1500);
  }

  function ensureStyle(){
    if(document.getElementById('kdvhStyle')) return;
    var style=document.createElement('style'); style.id='kdvhStyle';
    style.textContent='.kdvh-warn{background:#ffd8d8;color:#a00;font-weight:bold}#kdvhPrintSheet{display:none}#kdvhPanel{margin:16px 0;padding:12px;border:2px solid #1769aa;background:#eef7ff}#kdvhPanel h2{margin:0 0 6px;color:#0d4775}.kdvh-note{font-size:12px;margin-bottom:8px}.kdvh-actions{margin:8px 0}#kdvhPanel button{border:0;padding:8px 13px;margin-right:6px;cursor:pointer;color:#fff;background:#1769aa}#kdvhPanel button.kdvh-clear{background:#6c757d}#kdvhPanel button.kdvh-print{background:#28783e}#kdvhWrap{overflow:auto;max-height:72vh;border:1px solid #99b8d0;background:#fff}#kdvhTable{border-collapse:collapse;min-width:2600px;margin:0;padding:0}#kdvhTable th{position:sticky;top:0;z-index:2;background:#1769aa;color:#fff;font-size:11px}#kdvhTable td{font-size:11px;white-space:nowrap}#kdvhTable input{width:92px;padding:4px;border:1px solid #d59d00;background:#fff5bf;text-align:right}.kdvh-entry{display:flex;align-items:center;gap:3px;margin:2px 0}.kdvh-entry .kdvh-base{width:88px}.kdvh-entry .kdvh-rate{width:45px}.kdvh-entry .kdvh-withholding{width:62px}.kdvh-withholding-label{margin-left:5px}.kdvh-entry-remove{padding:2px 6px!important;margin:0!important;background:#a94442!important}.kdvh-entry-add{padding:3px 7px!important;margin-top:3px!important;font-size:10px}.kdvh-money{text-align:right}.kdvh-period{font-weight:bold}.kdvh-increase{background:#ffd9d9;color:#a00000;font-weight:bold}.kdvh-decrease{background:#e4f7e8;color:#176b2c;font-weight:bold}#kdvhSummary{margin-top:8px;padding:7px;background:#fff;border:1px solid #99b8d0;font-size:12px}@page{size:A4 landscape;margin:5mm}@media print{body.kdvh-print-mode>*:not(#kdvhPrintSheet){display:none!important}body.kdvh-print-mode{margin:0!important;background:#fff;color:#111}body.kdvh-print-mode #kdvhPrintSheet{display:block!important}.kdvh-print-year{break-after:page;page-break-after:always}.kdvh-print-year:last-child{break-after:auto;page-break-after:auto}.kdvh-print-title{text-align:center;font-size:12pt;font-weight:bold;margin:0 0 1mm}.kdvh-print-meta{font-size:8pt;margin-bottom:1.2mm}.kdvh-print-table{width:100%;border-collapse:collapse;table-layout:fixed;font-family:Arial,sans-serif;font-size:7pt;line-height:1.08;font-variant-numeric:tabular-nums}.kdvh-print-results{margin-top:3mm}.kdvh-print-period-col{width:7%}.kdvh-print-input-col{width:18%}.kdvh-print-main .kdvh-print-number-col{width:7.5%}.kdvh-print-results .kdvh-print-result-col{width:8.455%}.kdvh-print-table th,.kdvh-print-table td{border:0.2mm solid #555;padding:0.65mm 0.35mm;vertical-align:middle}.kdvh-print-table th{background:#d9eaf7!important;color:#111;text-align:center;font-weight:bold;white-space:normal}.kdvh-print-table td.num{text-align:right;white-space:nowrap}.kdvh-print-table td.strong{font-weight:bold}.kdvh-print-table td.old{background:#f5f5f5!important}.kdvh-print-table td.new{background:#eef8ff!important}.kdvh-print-summary{font-size:6.5pt;line-height:1.15;margin-top:1.2mm;padding:1mm;border:0.2mm solid #555;background:#eef7ff!important}}';
    style.textContent+='#kdvhPanel button.kdvh-excel{background:#1f6f43}@media print{.kdvh-print-table{font-size:4.2pt!important;line-height:1.04!important;break-inside:avoid!important;page-break-inside:avoid!important}.kdvh-print-period-col{width:4%!important}.kdvh-print-input-col{width:12%!important}.kdvh-print-rejected-col{width:5%!important}.kdvh-print-number-col{width:4.158%!important}.kdvh-print-table th,.kdvh-print-table td{padding:.45mm .16mm!important;overflow:hidden!important}.kdvh-print-table td.input{font-size:3.8pt!important;white-space:normal!important;overflow-wrap:anywhere!important}.kdvh-print-table td.num{white-space:nowrap!important}.kdvh-print-title{font-size:10pt!important}.kdvh-print-meta{font-size:6.5pt!important}.kdvh-print-summary{font-size:5.5pt!important}}';
    document.head.appendChild(style);
  }

  function init(options){
    options=options||{}; var sourceRows=(options.sourceRows||[]).slice(0,MAX_MONTHS); if(!sourceRows.length) return;
    ensureStyle(); var vkn=String(options.vkn||'').replace(/\D/g,''), old=document.getElementById('kdvhPanel'); if(old&&old.parentNode) old.parentNode.removeChild(old);
    var panel=document.createElement('div'); panel.id='kdvhPanel';
    panel.innerHTML='<h2>Yıllık KDV Devir Hesabı</h2><div class="kdvh-note">KDV beyan verileri otomatik alınmıştır. İlave matrahı ve yanındaki KDV oranını girin. İşlem tevkifatlıysa isteğe bağlı Tevkifat alanına 5/10, 7/10, 9/10 veya 50, 70, 90 yazabilirsiniz; boş bırakılırsa normal KDV hesaplanır. Aynı aya başka oran eklemek için “+ Matrah / Oran Ekle”yi kullanın. İade KDV de düzeltme sonucuna göre azalabilir veya sıfırlanabilir. En fazla 5 yıl (60 dönem) hesaplanır.</div><div class="kdvh-actions"><button type="button" id="kdvhCalculate">Hesapla ve Devret</button><button type="button" class="kdvh-clear" id="kdvhClear">Girdileri Temizle</button><button type="button" class="kdvh-print" id="kdvhPrint">Çıktı Al</button><button type="button" class="kdvh-excel" id="kdvhExcel">Excel’e Aktar</button></div><datalist id="kdvhRatesOld"><option value="1"><option value="8"><option value="18"></datalist><datalist id="kdvhRatesNew"><option value="1"><option value="10"><option value="20"></datalist><datalist id="kdvhWithholdingRates"><option value="2/10"><option value="3/10"><option value="4/10"><option value="5/10"><option value="7/10"><option value="9/10"></datalist><div id="kdvhWrap"><table id="kdvhTable"><thead><tr><th rowspan="2">Dönem</th><th rowspan="2">İlave Matrah / KDV Oranı / Tevkifat</th><th rowspan="2">Reddedilen İndirim</th><th colspan="2">Matrah</th><th colspan="2">Hesaplanan KDV</th><th colspan="2">İlave Edilecek KDV</th><th colspan="2">Toplam KDV</th><th colspan="2">Önceki Dönem Devri</th><th colspan="2">Bu Döneme Ait İndirim</th><th colspan="2">Toplam İndirilecek KDV</th><th colspan="2">İade KDV</th><th colspan="3">Ödenecek KDV</th><th colspan="2">Sonraki Döneme Devreden KDV</th></tr><tr><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Beyan</th><th>Düzeltilmiş</th><th>Fark</th><th>Beyan</th><th>Düzeltilmiş</th></tr></thead><tbody id="kdvhBody"></tbody></table></div><div id="kdvhSummary"></div>';
    var anchor=options.anchor||document.body; anchor.appendChild(panel);
    var adjustments=loadAdjustments(vkn); renderRows(panel,sourceRows,adjustments);
    panel.querySelector('#kdvhCalculate').onclick=function(){ adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments); renderRows(panel,sourceRows,adjustments); };
    panel.querySelector('#kdvhClear').onclick=function(){ if(!global.confirm('Bu mükellef için girilen ilave matrah ve indirim reddi tutarları temizlensin mi?')) return; adjustments={}; saveAdjustments(vkn,adjustments); renderRows(panel,sourceRows,adjustments); };
    panel.onclick=function(event){
      var add=event.target.closest&&event.target.closest('[data-kdvh-add]');
      if(add){ var row=add.closest('tr[data-kdvh-period]'); add.insertAdjacentHTML('beforebegin',entryHtml(row.getAttribute('data-kdvh-period'),{})); return; }
      var remove=event.target.closest&&event.target.closest('.kdvh-entry-remove');
      if(remove){ var entry=remove.closest('.kdvh-entry'), cell=entry.parentNode; if(cell.querySelectorAll('.kdvh-entry').length>1) entry.parentNode.removeChild(entry); else{ entry.querySelector('[data-kdvh-field="base"]').value=''; } }
    };
    panel.querySelector('#kdvhPrint').onclick=function(){
      adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments);
      var result=renderRows(panel,sourceRows,adjustments); buildPrintSheet(result,vkn);
      document.body.classList.add('kdvh-print-mode');
      function cleanup(){ document.body.classList.remove('kdvh-print-mode'); global.removeEventListener('afterprint',cleanup); }
      global.addEventListener('afterprint',cleanup); global.print(); setTimeout(cleanup,10000);
    };
    panel.querySelector('#kdvhExcel').onclick=function(){
      adjustments=readAdjustments(panel); saveAdjustments(vkn,adjustments);
      exportExcel(renderRows(panel,sourceRows,adjustments),vkn,sourceRows);
    };
  }

  global.KdvDuzeltmeHesabi={version:'3.9.0',maxMonths:MAX_MONTHS,calculate:calculate,init:init,numberValue:numberValue,roundMoney:roundMoney,defaultRateForPeriod:defaultRateForPeriod,withholdingRatio:withholdingRatio};
})(window);
