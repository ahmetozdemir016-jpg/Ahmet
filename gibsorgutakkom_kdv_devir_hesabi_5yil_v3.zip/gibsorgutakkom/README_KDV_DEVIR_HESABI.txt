YILLIK KDV DEVİR HESABI

Normal “Yıllık KDV-BS-POS” ekranı değiştirilmemiştir. Yeni hesaplama ayrı bir sayfadadır.

1. Ana ekranda “Yıllık KDV Devir Hesabı” düğmesine basın.
2. Hesabın başlayacağı yılı girin. Program başlangıç yılından itibaren en fazla 5 yılı getirir.
3. KDV beyan verileri otomatik çekilir.
4. Düzeltme bulunan aylarda yalnızca ilgili sarı alanları doldurun:
   - İlave Matrah %1
   - İlave Matrah %10
   - İlave Matrah %20
   - Reddedilen İndirim KDV
5. “Hesapla ve Devret” düğmesine basın.

Aynı ayda %1, %10 ve %20 oranlarından birden fazlasına ilave matrah girilebilir. Program oranlara ait KDV’leri ayrı ayrı hesaplayıp toplar; düzeltilmiş hesaplanan ve toplam KDV’ye ekler.

Reddedilen indirim toplam indirilecek KDV’den düşülür. Düzeltilmiş devreden KDV bir sonraki aya aktarılır. Beyannamedeki iade edilmesi gereken KDV de korunur; indirim bakiyesi hem toplam KDV’yi hem iadeyi karşılamazsa eksik kalan kısım düzeltilmiş ödenecek KDV’ye ve ödenecek farkına dahil edilir.

Girilen düzeltmeler mükellef VKN’sine göre tarayıcıda saklanır. “Girdileri Temizle” yalnızca bu mükellefe ait ilave matrah ve indirim reddi girişlerini siler.

İlave matrah ve reddedilen indirim girilmemişse beyan ödenecek/devreden sonuçları aynen korunur; iki fark sütunu da 0,00 olur. Bir ayın beyan edilen önceki devri ile önceki ayın sonraki devri farklı olsa bile bu beyan farklılığı düzeltme olarak ileri taşınmaz.
