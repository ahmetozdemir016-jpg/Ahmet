(function(){
  'use strict';

  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function clean(v){return String(v==null?'':v).trim();}
  function digits(v){return clean(v).replace(/\D/g,'');}
  function arr(v){if(Array.isArray(v))return v;if(v==null||v==='')return [];return [v];}
  function tok(){try{return (typeof window._tok==='function'&&window._tok())||(typeof window.token==='function'&&window.token())||'';}catch(e){return '';}}
  function remote(cmd,jp,suf,base){
    var u=(base||'http://10.251.63.99/gibintranet_server/dispatch')+'?cmd='+encodeURIComponent(cmd)+'&callid=ao'+Date.now()+(suf||'')+'&token='+encodeURIComponent(tok())+'&jp='+encodeURIComponent(JSON.stringify(jp||{}));
    var r=getRemote(u);return typeof r==='string'?JSON.parse(r):r;
  }
  function partners(vkn){
    try{return arr(((((remote('sicilService_mukunAdiOrtaklikBilgileriniGetir',{vkn:vkn,basTar:'',bitTar:''},'1')||{}).data||{}).ortakliklar||{}).adiortak));}
    catch(e){return [];}
  }
  function sicil(vkn){try{return remote('sicilService_sicilBilgileriSorgulaIlKodu',{vkn:vkn,tckn:'',vdKodu:'',ilKodu:''},'2');}catch(e){return null;}}
  function vdList(vkn){
    var s=sicil(vkn);
    var vdObj=((((s||{}).data||{}).vdler)||{});
    var a=arr(vdObj.baglivd),out=[];
    a.forEach(function(x){var k=digits(x&&(x.vdkodu||x.vdKodu||x.vergiDairesiKodu));if(k&&out.indexOf(k)<0)out.push(k);});
    if(!out.length){try{var cur=digits(typeof vdKodu==='function'?vdKodu():'');if(cur)out.push(cur);}catch(e){}}
    return out;
  }
  function status(x){
    var c=[];
    ['cevapGelen','cevapVerilmesiGereken','cevapVerilmis','iadeciTarafindanYenidenBaslatilan','arsivdeCevapGelmis','arsiveGonderilmis'].forEach(function(k){if(x&&x[k]!=null&&String(x[k])!=='0')c.push(k+': '+x[k]);});
    if(!c.length&&x){Object.keys(x).forEach(function(k){if(/^durum_/.test(k)&&x[k])c.push(k.replace('durum_','Durum ')+': '+x[k]);});}
    return c.join(' / ')||'';
  }
  function label(p){return clean(p&&(p.unvan||p.adsoyad))||'Adi Ortaklık'+' ('+digits(p&&(p.vergino||p.ortvergino))+')';}
  function fullLabel(p){var v=digits(p&&(p.vergino||p.ortvergino));var n=clean(p&&(p.unvan||p.adsoyad))||'Adi Ortaklık';return n+' ('+v+')';}
  function cell(tr,text){var td=document.createElement('td');td.textContent=text==null?'':String(text);tr.appendChild(td);return td;}

  function makeSummary(main,ps){
    var old=document.getElementById('myTableAOQuery');if(old)old.remove();
    var anchor=document.getElementById('myTable17')||document.getElementById('myTable10');if(!anchor||!ps.length)return;
    var t=document.createElement('table');t.id='myTableAOQuery';t.border='1';
    t.innerHTML='<caption>Adi Ortaklık Sorgu Sonuçları</caption><tr><th>VKN</th><th>Ünvan</th><th>Hisse</th><th>Giriş / Çıkış</th><th>SMS</th><th>Gönüllü Uyum</th><th>İzaha Davet / SMİYB</th><th>İstisna Dilekçesi</th><th>E-Tebligat</th><th>9047</th></tr>';
    anchor.parentNode.insertBefore(t,anchor.nextSibling);
    ps.forEach(function(p){
      var v=digits(p&&(p.vergino||p.ortvergino));if(!v)return;
      var vds=vdList(v),vd=vds[0]||'',vals=[];
      try{vals.push(smsVarmi(v,tok()));}catch(e){vals.push('Hata');}
      try{vals.push(gonulluUyum(v,tok()));}catch(e){vals.push('Hata');}
      try{vals.push(izahaDavetSmiybVarmi(v,'',tok()));}catch(e){vals.push('Hata');}
      try{vals.push(istisnaDilekcesiVarmi(v,tok()));}catch(e){vals.push('Hata');}
      try{vals.push(eTebligatVarmi(v,'2',tok()));}catch(e){vals.push('Hata');}
      var n='?';try{n=tahakkukSorgula(tok(),v,vd,'9047')+'-'+tarhiyatSorgula(tok(),v,vd,'9047');}catch(e){n='Hata';}
      var tr=document.createElement('tr');
      tr.innerHTML='<td>'+esc(v)+'</td><td>'+esc(p.unvan||p.adsoyad||'')+'</td><td>'+esc(p.orthisse||'')+'</td><td>'+esc((p.ortgiristar||'')+' / '+(p.ortcikistar||''))+'</td><td>'+vals[0]+'</td><td>'+vals[1]+'</td><td>'+vals[2]+'</td><td>'+vals[3]+'</td><td>'+vals[4]+'</td><td>'+esc(n)+'</td>';
      t.appendChild(tr);
    });
  }

  function kdviraAction(td,ctx){
    var a=document.createElement('a');a.href='#';a.textContent='Detay Göster';a.title='KDVİRA hata bildirim listesini aç';
    a.addEventListener('click',function(e){
      e.preventDefault();
      try{
        if(typeof window.__kvShowTopList!=='function')throw new Error('KDVİRA detay fonksiyonu yüklenemedi.');
        return window.__kvShowTopList(encodeURIComponent(JSON.stringify(ctx)));
      }catch(err){alert('KDVİRA detayı açılamadı: '+(err&&err.message?err.message:err));return false;}
    });
    td.appendChild(a);
  }

  function augmentKdvira(main,ps){
    var t=document.getElementById('myTable13');if(!t||!ps.length)return;
    var header=t.rows&&t.rows[0];if(!header)return;
    if(!header.querySelector('th[data-ao-origin]')){
      var th=document.createElement('th');th.textContent='Mükellef';th.setAttribute('data-ao-origin','1');header.insertBefore(th,header.cells[0]||null);
      for(var i=1;i<t.rows.length;i++){
        var r=t.rows[i];
        var oldPeriod=r.cells[1]?digits(r.cells[1].textContent).slice(0,6):'';if(oldPeriod.length===6)r.setAttribute('data-kdvira-period',oldPeriod);
        var td=r.insertCell(0);td.textContent='Ana - '+main;r.setAttribute('data-kdvira-owner',main);
      }
    }
    Array.prototype.slice.call(t.querySelectorAll('tr[data-ao-row="1"]')).forEach(function(r){r.remove();});
    var seen={};
    ps.forEach(function(p){
      var v=digits(p&&(p.vergino||p.ortvergino));if(!v)return;
      vdList(v).forEach(function(vd){
        [['Aktif','mukellefKarnesiYazismaService_mukellefListesiGetirVergilendirme',false],['Arşiv','mukellefKarnesiYazismaService_mukellefListesiGetirVergilendirme4Arsiv',true]].forEach(function(z){
          try{
            var jp=z[2]
              ?{vdKodu:vd,basVkn:v,bitVkn:v,iadeDonemi:'',gunSayisi:'0',vknIadeci:'',arsivBasTar:'',arsivBitTar:'',segmentKodu:'',faturaDonemi:'',yazismaDurum:'0',mudurluk:''}
              :{vdKodu:vd,faturaDonemi:'',yazismaDurum:'0',basVkn:v,bitVkn:v,segmentKodu:'',iadeDonemi:'',gunSayisi:'0',vknIadeci:'',mudurluk:''};
            var resp=remote(z[1],jp,'3'),lst=arr(((resp||{}).data||{}).liste);
            lst.forEach(function(x){
              var donem=clean(x&&(x.donem||x.faturaDonemi)),segment=clean(x&&(x.segmentKodu||x.segment));
              var key=z[0]+'|'+v+'|'+vd+'|'+donem+'|'+segment;if(seen[key])return;seen[key]=1;
              var ctx={durum:z[0],arsiv:z[2],vkn:v,vdKodu:vd,donem:donem,segmentKodu:segment,adiOrtaklik:true,mukellefEtiketi:fullLabel(p)};
              var tr=document.createElement('tr');tr.setAttribute('data-ao-row','1');tr.setAttribute('data-kdvira-owner',v);tr.setAttribute('data-kdvira-period',digits(donem).slice(0,6));
              cell(tr,fullLabel(p));cell(tr,z[0]);cell(tr,donem);cell(tr,segment);cell(tr,x.say||x.toplam||'');cell(tr,x.maxBekSur||x.sure||'');cell(tr,status(x));
              var action=cell(tr,'');kdviraAction(action,ctx);t.appendChild(tr);
            });
          }catch(e){}
        });
      });
    });
    if(window.__kdviraInitPeriodFilter)window.__kdviraInitPeriodFilter('myTable13');
  }

  function augmentReports(main,ps){
    var t=document.getElementById('myTable9');if(!t||!ps.length)return;
    if(!t.querySelector('th[data-ao-origin]')){
      var th=document.createElement('th');th.textContent='Mükellef';th.setAttribute('data-ao-origin','1');t.rows[0].insertBefore(th,t.rows[0].cells[0]);
      for(var i=1;i<t.rows.length;i++){var td=t.rows[i].insertCell(0);td.textContent='Ana - '+main;}
    }
    Array.prototype.slice.call(t.querySelectorAll('tr[data-ao-row="1"]')).forEach(function(r){r.remove();});
    ps.forEach(function(p){
      var v=digits(p&&(p.vergino||p.ortvergino));if(!v)return;
      vdList(v).forEach(function(vd){
        try{
          var r=remote('raporDefteriService_raporDefteriSorgula',{vkn:v,vdkodu:vd,durum:0},'4'),lst=arr(((r||{}).data||{}).raporDefterleri);
          lst.forEach(function(x){
            var tr=document.createElement('tr');tr.setAttribute('data-ao-row','1');var ev=x.evrakNo||'';
            tr.innerHTML='<td>'+esc(fullLabel(p))+'</td><td>'+esc(x.rapordefterino||'')+'</td><td>'+esc(x.aciklama||'')+'</td><td>'+esc(x.vergikodu||'')+'</td><td>'+esc(x.vergidonem||'')+'</td><td>'+esc(typeof tarih==='function'?tarih(x.raptuttarih):x.raptuttarih||'')+'</td><td>'+esc(x.raptutanakno||'')+'</td><td>'+esc(typeof tarih==='function'?tarih(x.raptutgelisno):x.raptutgelisno||'')+'</td><td>'+esc(ev)+'</td><td>'+(typeof __tkRaporEvrakButton==='function'?__tkRaporEvrakButton(v,vd,ev,x.raptutanakno||''):'')+'</td>';
            t.appendChild(tr);
          });
        }catch(e){}
      });
    });
  }

  function augmentOlumsuz(main,ps){
    var old=document.getElementById('myTableAOOlumsuz');if(old)old.remove();if(!ps.length)return;
    var anchor=document.querySelector('table#myTable');if(!anchor)return;
    var t=document.createElement('table');t.id='myTableAOOlumsuz';t.border='1';
    t.innerHTML='<caption>Adi Ortaklık Olumsuz Rapor / Olumsuz Tespit Sonuçları</caption><tr><th>Mükellef</th><th>Tespit Türü</th><th>İnceleme Dönemi</th><th>VİR Tarih/Sayı</th><th>Geliş Tarihi</th><th>Diğer Açıklama</th></tr>';
    anchor.parentNode.insertBefore(t,anchor.nextSibling);
    ps.forEach(function(p){
      var v=digits(p&&(p.vergino||p.ortvergino));if(!v)return;
      try{
        var m=remote('ozesOlumsuzTespitService_mukellefSorgulamaSonucListesiGetirDurumMain',{mukVkn:v,mukTckn:'',durum:'2050'},'5','http://10.251.63.99/ozes_server/dispatch'),data=(m||{}).data||{};
        ['listBir','listIki','listUc','listDort'].forEach(function(n){
          if(data[n]!=='visible')return;
          try{
            var d=remote('ozesOlumsuzTespitService_olumsuzTespitDetayGetir',{mukVkn:v,mukTckn:'',durum:'2050',listName:n},'6','http://10.251.63.99/ozes_server/dispatch'),lst=arr((d||{}).data);
            lst.forEach(function(x){
              var tr=document.createElement('tr');
              tr.innerHTML='<td>'+esc(fullLabel(p))+'</td><td>'+esc(typeof ozesGirisNedeni==='function'?ozesGirisNedeni(x.tespitTuru):x.tespitTuru||'')+'</td><td>'+esc(x.incelemeDonemi||'')+'</td><td>'+esc((typeof tarihFormat==='function'?tarihFormat(x.raporTarihi):x.raporTarihi||'')+' / '+(x.raporSayisi||''))+'</td><td>'+esc(typeof tarihFormat==='function'?tarihFormat(x.intikalTarihi):x.intikalTarihi||'')+'</td><td>'+esc(x.vkn?('Dayanak Firma: '+x.vkn+' - '+(x.unvan||'')+' - '+(x.vd||'')):'')+'</td>';
              t.appendChild(tr);
            });
          }catch(e){}
        });
      }catch(e){}
    });
  }

  function ensurePrevTable(){
    var t=document.getElementById('myTable11');
    if(!t){
      var anchor=document.getElementById('myTable6');if(!anchor)return null;
      t=document.createElement('table');t.id='myTable11';t.style.cssText='table-layout:fixed;width:100%';
      t.innerHTML='<caption>Önceki Takdir Komisyonu Kararları — Ana Mükellef ve Adi Ortaklıklar</caption><tr><th>Vergi Kodu</th><th>Dönem</th><th>TS Fiş No</th><th>Karar No</th><th>Karar Tarihi</th><th>Matrah</th><th data-ao-prev-owner="1">Mükellef</th></tr><tbody></tbody>';
      anchor.parentNode.insertBefore(t,anchor.nextSibling);
    }
    var cap=t.querySelector('caption');if(cap)cap.textContent='Önceki Takdir Komisyonu Kararları — Ana Mükellef ve Adi Ortaklıklar';
    var hr=t.rows&&t.rows[0];
    if(hr&&!hr.querySelector('th[data-ao-prev-owner]')){
      var th=document.createElement('th');th.textContent='Mükellef';th.setAttribute('data-ao-prev-owner','1');hr.appendChild(th);
    }
    return t;
  }
  function prevKey(v,vk,donem,tsf,kararNo,kararTar,matrah){return [digits(v),clean(vk),digits(donem),clean(tsf),clean(kararNo),digits(kararTar),clean(matrah)].join('|');}
  function periodHtml(d){var s=digits(d);if(s.length>=12)return esc(s.substr(0,4)+'-'+s.substr(4,2))+'<br>'+esc(s.substr(6,4)+'-'+s.substr(10,2));if(s.length>=6)return esc(s.substr(0,4)+'-'+s.substr(4,2));return esc(d);}
  function orgOidFor(ts,vd){
    try{var ih=arr(ts&&ts.ihbler);var o=ih[0]&&(ih[0].orgOid||ih[0].orgoid);if(o)return String(o);}catch(e){}
    try{return typeof orgIDGetir==='function'?String(orgIDGetir(vd)||''):'';}catch(e){return '';}
  }
  function isRealDecision(k){
    if(!k||typeof k!=='object')return false;
    var kn=clean(k.kararno||k.kararNo||k.karar_no),kt=digits(k.karartarihi||k.kararTarihi||k.karar_tarihi);
    if(!kn||kn==='0'||/^detay$/i.test(kn)||kt.length<8)return false;
    return true;
  }
  function addPrevRow(t,seen,ownerVkn,ownerLabel,vd,ts,k){
    if(!isRealDecision(k))return;
    var vk=clean(ts&&ts.vergikodu),donem=clean(ts&&ts.donem),tsf=clean(ts&&ts.tsfno),kn=clean(k&&(k.kararno||k.kararNo||k.karar_no)),kt=clean(k&&(k.karartarihi||k.kararTarihi||k.karar_tarihi)),mat=clean(k&&k.matrah);
    var key=prevKey(ownerVkn,vk,donem,tsf,kn,kt,mat);if(seen[key])return;seen[key]=1;
    var tr=document.createElement('tr');tr.setAttribute('data-ao-prev-row','1');tr.setAttribute('data-prev-vkn',ownerVkn);tr.setAttribute('data-prev-vd',vd);
    cell(tr,vk);
    var ptd=cell(tr,'');var pl=document.createElement('label');pl.title='Beyanname görüntülemek için tıklayınız';pl.style.cursor='pointer';pl.innerHTML=periodHtml(donem);pl.onclick=function(){
      try{
        var s=digits(donem),y1=s.substr(0,4),m1=s.substr(4,2),y2=s.length>=12?s.substr(6,4):y1,m2=s.length>=12?s.substr(10,2):m1;
        if(typeof window.beyanname_getir_guncel==='function')window.beyanname_getir_guncel(ownerVkn,vd,vk,y1,m1,y2,m2);
      }catch(e){}
      return false;
    };ptd.appendChild(pl);
    cell(tr,tsf);
    var ktd=cell(tr,'');var btn=document.createElement('button');btn.type='button';btn.textContent=kn||'Detay';btn.title='Karar detayını aç';btn.style.cssText='padding:3px 7px;cursor:pointer';btn.setAttribute('data-karar-no',kn);
    btn.onclick=function(){
      try{
        if(typeof window.__tkKararDetayAc!=='function')throw new Error('Karar detay fonksiyonu yüklenemedi.');
        return window.__tkKararDetayAc(kn,kt,orgOidFor(ts,vd),ownerVkn,'',vd);
      }catch(e){alert('Karar detayı açılamadı: '+(e&&e.message?e.message:e));return false;}
    };ktd.appendChild(btn);
    cell(tr,kt);
    var matText=mat;try{if(typeof tlCevir==='function')matText=tlCevir(mat);}catch(e){}cell(tr,matText);
    cell(tr,ownerLabel);
    var body=t.tBodies&&t.tBodies.length?t.tBodies[0]:t;body.appendChild(tr);
  }
  function augmentPreviousTakdir(main,ps){
    var t=ensurePrevTable();if(!t)return;
    Array.prototype.slice.call(t.querySelectorAll('tr[data-ao-prev-row="1"]')).forEach(function(r){r.remove();});
    var seen={};
    for(var i=t.rows.length-1;i>=1;i--){
      var rr=t.rows[i];if(!rr.cells||rr.cells.length<6)continue;
      var existingNo=clean(rr.cells[3]&&rr.cells[3].textContent),existingDate=digits(rr.cells[4]&&rr.cells[4].textContent);
      if(!existingNo||existingNo==='0'||/^detay$/i.test(existingNo)||existingDate.length<8)rr.remove();
    }
    for(var i=1;i<t.rows.length;i++){
      var r=t.rows[i];if(!r.cells||r.cells.length<6)continue;
      if(r.cells.length===6)cell(r,'Ana - '+main);else if(!clean(r.cells[6].textContent))r.cells[6].textContent='Ana - '+main;
      r.setAttribute('data-prev-vkn',main);
      seen[prevKey(main,r.cells[0].textContent,r.cells[1].textContent,r.cells[2].textContent,r.cells[3].textContent,r.cells[4].textContent,r.cells[5].textContent)]=1;
    }
    var scopes=[{vkn:main,label:'Ana - '+main}];
    ps.forEach(function(p){var v=digits(p&&(p.vergino||p.ortvergino));if(v)scopes.push({vkn:v,label:fullLabel(p)});});
    scopes.forEach(function(s){
      vdList(s.vkn).forEach(function(vd){
        try{
          var resp=remote('mhkTakdireSevkService_takdireSevkSorgulama',{vkn:s.vkn,tckn:'',vdkodu:vd,vergikodu:'',basdonem:'',bitdonem:''},'7'),list=arr(((resp||{}).data||{}).tsler);
          list.forEach(function(ts){arr(ts&&ts.kararlar).filter(isRealDecision).forEach(function(k){addPrevRow(t,seen,s.vkn,s.label,vd,ts,k);});});
        }catch(e){}
      });
    });
    try{var cb=document.getElementById('excludeMyTable11FromPrint');if(cb)cb.checked=false;}catch(e){}
  }

  function run(){
    var input=document.getElementById('input');if(!input)return;
    var main=digits(input.value);if(!main)return;
    var ps=partners(main);window.__tkAdiOrtakliklar=ps;
    if(ps.length){makeSummary(main,ps);augmentKdvira(main,ps);augmentReports(main,ps);augmentOlumsuz(main,ps);}
    augmentPreviousTakdir(main,ps);
  }
  function schedule(){
    var tries=0,id=setInterval(function(){
      tries++;
      if(document.getElementById('myTable6')&&document.getElementById('myTable13')&&document.getElementById('myTable9')){clearInterval(id);setTimeout(run,100);}
      else if(tries>160)clearInterval(id);
    },250);
  }
  document.addEventListener('click',function(e){var b=e.target&&e.target.closest&&e.target.closest('#go');if(b)setTimeout(schedule,100);},true);
})();
