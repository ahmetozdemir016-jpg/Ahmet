(function(){
  'use strict';

  function q(n){
    try{return new URL(location.href).searchParams.get(n)||'';}catch(e){return '';}
  }
  function esc(v){
    return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});
  }
  function cleanId(v){return String(v||'').replace(/\D/g,'');}
  function token(){return q('token')||localStorage.getItem('gib_token_keys')||localStorage.getItem('keysToken')||'';}
  function remote(url){
    if(typeof window.getRemote==='function')return window.getRemote(url);
    var x=new XMLHttpRequest();x.open('GET',url,false);x.send(null);return x.responseText;
  }
  function getPartners(vkn){
    try{
      var jp={vkn:vkn,basTar:'',bitTar:''};
      var u='http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukunAdiOrtaklikBilgileriniGetir&callid=aoScope'+Date.now()+'&token='+encodeURIComponent(token())+'&jp='+encodeURIComponent(JSON.stringify(jp));
      var r=JSON.parse(remote(u));
      return (((r||{}).data||{}).ortakliklar||{}).adiortak||[];
    }catch(e){return [];}
  }
  function urlFor(v,asFrame){
    var u=new URL(location.href);
    u.searchParams.set('vkn',v);
    u.searchParams.set('anaVkn',cleanId(q('anaVkn')||q('vkn')));
    if(asFrame)u.searchParams.set('aoFrame','1');else u.searchParams.delete('aoFrame');
    return u.href;
  }
  function note(){
    var p=location.pathname.toLowerCase();
    if(/kdvira|kdv_beyan|bs-karsilastirma|efatura|kesinti/.test(p))return 'Ana mükellef ve adi ortaklık sorguları ayrı sekmelerde tutulur. Sekmeler arasında geçiş yaptığınızda daha önce alınan sonuçlar silinmez.';
    if(/beyanname-matrah/.test(p))return 'Ana mükellef ve adi ortaklıkların sorgu ekranları ayrı ayrı açık kalır; sekme değiştirildiğinde girilen ve getirilen veriler korunur.';
    return 'Ana mükellef ve adi ortaklık sorguları ayrı sekmelerde tutulur; daha önce yaptığınız sorgular sekme değişiminde kaybolmaz.';
  }
  function buttonStyle(active,type){
    var bg=active?(type==='main'?'#176b43':'#b33535'):'#e2e2e2';
    var color=active?'#fff':'#222';
    return 'padding:6px 9px;border:1px solid #aaa;border-radius:3px;background:'+bg+';color:'+color+';cursor:pointer;font:12px Arial;';
  }

  function init(){
    if(q('aoFrame')==='1')return;

    var current=cleanId(q('vkn'));
    if(!current)return;
    var ana=cleanId(q('anaVkn')||current);
    var ps=getPartners(ana);
    if(!ps.length)return;

    var scopes=[];
    function addScope(v,title,type){
      v=cleanId(v);if(!v)return;
      for(var i=0;i<scopes.length;i++)if(scopes[i].vkn===v)return;
      scopes.push({vkn:v,title:title||v,type:type||'partnership'});
    }
    addScope(ana,'Ana: '+ana,'main');
    ps.forEach(function(x){
      var v=cleanId(x.vergino||x.ortvergino||'');
      if(v)addScope(v,'Adi Ortaklık: '+v+' - '+String(x.unvan||x.adsoyad||''),'partnership');
    });
    addScope(current,(current===ana?'Ana: ':'Mükellef: ')+current,current===ana?'main':'partnership');

    var old=document.getElementById('tkAdiScope');if(old)old.remove();
    var oldFrames=document.getElementById('tkAdiFrames');if(oldFrames)oldFrames.remove();

    var style=document.createElement('style');
    style.id='tkAdiScopeStyle';
    style.textContent='body.tk-ao-frame-active > *:not(#tkAdiScope):not(#tkAdiFrames){display:none!important;}#tkAdiFrames{width:100%;min-height:calc(100vh - 105px);}#tkAdiFrames iframe{width:100%;height:calc(100vh - 110px);min-height:650px;border:0;background:#fff;}';
    document.head.appendChild(style);

    var bar=document.createElement('div');
    bar.id='tkAdiScope';
    bar.style.cssText='position:sticky;top:0;z-index:2147483000;background:#eef8f1;border:2px solid #176b43;padding:8px 10px;margin:0 0 6px 0;font:12px Arial;box-sizing:border-box;';
    var h='<b>Sorgu Kapsamı — Ana mükellef ve adi ortaklıklar</b><div style="margin:4px 0;color:#444">'+esc(note())+'</div><div id="tkAdiButtons" style="display:flex;flex-wrap:wrap;gap:6px">';
    scopes.forEach(function(s){
      h+='<button type="button" class="tk-ao-tab" data-vkn="'+esc(s.vkn)+'" data-type="'+esc(s.type)+'" style="'+buttonStyle(s.vkn===current,s.type)+'">'+esc(s.title)+'</button>';
    });
    h+='<button id="tkAdiOpenAll" type="button" style="padding:6px 9px;cursor:pointer">Tüm ortaklıkları ayrı tarayıcı sekmesinde aç</button></div>';
    bar.innerHTML=h;

    var host=document.createElement('div');host.id='tkAdiFrames';host.style.display='none';
    document.body.insertBefore(bar,document.body.firstChild);
    document.body.insertBefore(host,bar.nextSibling);

    var originalVkn=current;
    var originalScrollY=0;
    var activeVkn=current;
    var frames={};

    function setButtonStates(v){
      Array.prototype.forEach.call(bar.querySelectorAll('.tk-ao-tab'),function(btn){
        var bv=cleanId(btn.getAttribute('data-vkn'));
        btn.setAttribute('style',buttonStyle(bv===v,btn.getAttribute('data-type')));
      });
    }
    function ensureFrame(v){
      if(frames[v])return frames[v];
      var fr=document.createElement('iframe');
      fr.setAttribute('data-vkn',v);
      fr.setAttribute('title','Mükellef sorgu ekranı '+v);
      fr.src=urlFor(v,true);
      fr.style.display='none';
      host.appendChild(fr);frames[v]=fr;return fr;
    }
    function activate(v){
      v=cleanId(v);if(!v||v===activeVkn)return;
      if(activeVkn===originalVkn)originalScrollY=window.pageYOffset||document.documentElement.scrollTop||0;
      activeVkn=v;setButtonStates(v);
      if(v===originalVkn){
        document.body.classList.remove('tk-ao-frame-active');
        host.style.display='none';
        Object.keys(frames).forEach(function(k){frames[k].style.display='none';});
        setTimeout(function(){try{window.scrollTo(0,originalScrollY);}catch(e){}},0);
        return;
      }
      document.body.classList.add('tk-ao-frame-active');
      host.style.display='block';
      Object.keys(frames).forEach(function(k){frames[k].style.display='none';});
      ensureFrame(v).style.display='block';
      try{window.scrollTo(0,0);}catch(e){}
    }

    bar.addEventListener('click',function(e){
      var b=e.target&&e.target.closest&&e.target.closest('.tk-ao-tab');
      if(!b)return;
      e.preventDefault();activate(b.getAttribute('data-vkn'));
    });
    document.getElementById('tkAdiOpenAll').onclick=function(){
      scopes.forEach(function(s,i){
        if(s.vkn===ana)return;
        setTimeout(function(){window.open(urlFor(s.vkn,false),'_blank');},i*180);
      });
    };
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else setTimeout(init,0);
})();
