
const TOKEN_KEY = 'takkom_token_cache_v1';
const CAPTURE_TTL = 8 * 60 * 60 * 1000;
const KEYS_CAPTURE_KEY = 'takkom_keys_capture_v1';
const KEYS_CAPTURE_MAX = 250;

function cleanToken(v){
  let t = String(v || '').trim();
  if(!t || t.includes('***') || t.includes('...')) return '';
  for(let i=0;i<4;i++){
    const m = /[?&]token=([^&\s#]+)/i.exec(t) || /token%3D([^%&#\s]+)/i.exec(t);
    if(m && m[1]) t = m[1];
    try{ const d = decodeURIComponent(t); if(d === t) break; t = d; }catch(e){ break; }
  }
  t = String(t || '').replace(/["'<>]/g,'').trim();
  if(!t || t.length < 20) return '';
  return t;
}
function normModule(m){
  m = String(m || '').trim().toLowerCase();
  if(!m) return '';
  if(m === 'g' || m.includes('gibintranet') || m.includes('gib_intranet')) return 'gibintranet';
  if(m === 'gp' || m === 'key' || m === 'keys' || m.includes('keyss')) return 'keys';
  if(m === 'evdo' || m === 'evdb' || m.includes('evdo') || m.includes('evdb') || m.includes('evdorapor')) return 'evdbrapor';
  if(m === 'izah' || m.includes('izah') || m.includes('smiyb')) return 'izah';
  if(m.includes('istakip')) return 'istakip';
  if(m === 'e' || m.includes('eys') || m.includes('edenetis')) return 'eys';
  if(m.includes('ebyn') || m.includes('vdintra')) return 'ebeyan';
  return '';
}
function moduleFromContext(url, body, source){
  const u = String(url || '').toLowerCase();
  const b = String(body || '').toLowerCase();
  const s = String(source || '').toLowerCase();
  const all = u + ' ' + b + ' ' + s;
  let mm = /(?:^|[?&\s])module=([^&\s]+)/i.exec(all);
  if(mm) return normModule(mm[1]);
  mm = /cssession\.gettoken\(([^\)]+)\)/i.exec(all);
  if(mm) return normModule(mm[1]);
  if(u.includes('/izah-server/') || all.includes('module=izah') || all.includes('smiybraporservice') || all.includes('izahraporservice')) return 'izah';
  if(u.includes('evdorapor_server') || all.includes('module=evdorapor')) return 'evdbrapor';
  if(u.includes('gibintranet_server') || u.includes('/gibintranet/') || all.includes('module=gibintranet') || all.includes('cssession.gettoken(g)')) return 'gibintranet';
  if(u.includes('keys.ggm') || u.includes('/keyss/') || u.includes('/gp/') || all.includes('module=gp') || all.includes('cssession.gettoken(gp)')) return 'keys';
  if(u.includes('istakip')) return 'istakip';
  if(u.includes('eyoklama') || u.includes('edenetis') || all.includes('module=eys') || all.includes('module=e')) return 'eys';
  if(u.includes('vdintra') || u.includes('/ebyn/')) return 'ebeyan';
  return '';
}
function aliases(mod){
  const m = normModule(mod); const out = [];
  const add = x => { if(x && !out.includes(x)) out.push(x); };
  add(m);
  if(m === 'gibintranet'){ add('g'); add('gibIntranet'); add('gib_intranet'); }
  if(m === 'keys'){ add('gp'); add('key'); add('keysToken'); add('gpToken'); }
  if(m === 'evdbrapor'){ add('evdo'); add('evdb'); add('evdbRapor'); add('evdbRaporToken'); add('evdorapor'); add('evdoRapor'); }
  if(m === 'izah'){ add('izahaDavet'); add('smiyb'); add('izahServer'); add('izahToken'); }
  if(m === 'istakip') add('isTakip');
  if(m === 'eys'){ add('e'); add('edenetis'); }
  return out;
}
async function storeTokens(list, meta={}){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  const cache = old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{}};
  cache.tokens = cache.tokens || {};
  cache.tokensByModule = cache.tokensByModule || {};
  cache.captureStatus = cache.captureStatus || {};
  const now = Date.now();
  let changed = 0;
  for(const item of (Array.isArray(list) ? list : [])){
    const token = cleanToken(item && item.token);
    const mod = normModule((item && item.module) || moduleFromContext(item && item.url, item && item.body, item && item.source));
    if(!token || !mod) continue; // modül belli değilse bilinçli olarak kaydetme; yanlış token karışmasın.
    for(const a of aliases(mod)){
      cache.tokens[a] = {token, time: now, source: (item.source || meta.source || ''), module: mod};
      cache.tokensByModule[a] = token;
    }
    cache[mod] = {token, time: now, source: item.source || meta.source || '', module: mod};
    changed++;
  }
  if(changed){
    cache.updatedAt = now;
    cache.captureStatus.lastSource = meta.source || '';
    cache.captureStatus.lastUrl = meta.url || '';
    cache.captureStatus.modules = Object.keys(cache.tokensByModule || {}).filter(k => ['gibintranet','g','keys','gp','evdbrapor','evdo','evdb','izah','smiyb','istakip','isTakip','eys','e','edenetis'].includes(k));
    await chrome.storage.local.set({[TOKEN_KEY]: cache});
  }
  return cache;
}


async function storeSessionMeta(meta){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  const cache = old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{}};
  cache.sessionByModule = cache.sessionByModule || {};
  const mod = normModule(meta && meta.module) || 'istakip';
  const prev = cache.sessionByModule[mod] || {};
  const next = Object.assign({}, prev);
  const orgoid = String(meta && meta.orgoid || '').trim();
  const userId = String(meta && meta.userId || '').trim();
  if(/^\d{6,24}$/.test(orgoid)) next.orgoid = orgoid;
  if(/^\d{5,24}$/.test(userId)) next.userId = userId;
  next.time = Date.now(); next.source = String(meta && meta.source || '');
  cache.sessionByModule[mod] = next;
  if(mod === 'istakip'){
    if(next.orgoid) cache.istakipOrgoid = next.orgoid;
    if(next.userId) cache.istakipUserId = next.userId;
  }
  cache.updatedAt = Date.now();
  await chrome.storage.local.set({[TOKEN_KEY]: cache});
  return cache;
}
async function storeKeyCaptures(items){
  const old = await chrome.storage.local.get(KEYS_CAPTURE_KEY).catch(()=>({}));
  let arr = old[KEYS_CAPTURE_KEY] || [];
  if(!Array.isArray(arr)) arr = [];
  const now = Date.now();
  for(const it of (Array.isArray(items) ? items : [items])){
    if(!it || !it.url) continue;
    const rec = Object.assign({}, it, {createdAtMs: it.createdAtMs || now});
    arr.push(rec);
  }
  arr = arr.filter(x => x && x.url && (!x.createdAtMs || now - x.createdAtMs < CAPTURE_TTL));
  if(arr.length > KEYS_CAPTURE_MAX) arr = arr.slice(arr.length - KEYS_CAPTURE_MAX);
  await chrome.storage.local.set({[KEYS_CAPTURE_KEY]: arr});
  return arr;
}
async function getKeyCaptures(){
  const old = await chrome.storage.local.get(KEYS_CAPTURE_KEY).catch(()=>({}));
  let arr = old[KEYS_CAPTURE_KEY] || [];
  if(!Array.isArray(arr)) arr = [];
  const now = Date.now();
  arr = arr.filter(x => x && x.url && (!x.createdAtMs || now - x.createdAtMs < CAPTURE_TTL));
  return arr;
}

async function getCache(){
  const old = await chrome.storage.local.get(TOKEN_KEY).catch(()=>({}));
  return old[TOKEN_KEY] || {tokens:{}, tokensByModule:{}, updatedAt:0};
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg) return;
  if(msg.type === 'TCMB_FETCH_XML'){
    const url = String(msg.url || '').trim();
    if(!/^https:\/\/www\.tcmb\.gov\.tr\/kurlar\/\d{6}\/\d{8}\.xml(?:\?.*)?$/i.test(url)){
      sendResponse({ok:false, kind:'invalid_url', status:0, error:'Geçersiz TCMB kur adresi'});
      return;
    }
    fetch(url, {method:'GET', cache:'no-store', credentials:'omit', redirect:'follow'})
      .then(async resp => {
        const text = await resp.text();
        if(resp.ok){
          sendResponse({ok:true, status:resp.status, text:text, url:resp.url || url});
        }else{
          sendResponse({ok:false, kind:resp.status === 404 ? 'notfound' : 'http', status:resp.status, text:text.slice(0,500), url:resp.url || url});
        }
      })
      .catch(err => sendResponse({ok:false, kind:'network', status:0, error:String(err && err.message || err), url:url}));
    return true;
  }
  if(msg.type === 'TOKEN_ONLY_META'){
    storeSessionMeta(msg.payload || {})
      .then(cache => sendResponse({ok:true, cache}))
      .catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'TOKEN_ONLY_CAPTURE'){
    const payload = msg.payload || {};
    const tokens = Array.isArray(payload.tokens) ? payload.tokens : [];
    storeTokens(tokens, {source: payload.reason || payload.source || '', url: payload.pageUrl || ''})
      .then(cache => sendResponse({ok:true, cache}))
      .catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'KEYS_CAPTURE'){
    storeKeyCaptures((msg.payload && msg.payload.items) || msg.items || [])
      .then(captures => sendResponse({ok:true, captures}))
      .catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'GET_CAPTURES'){
    getKeyCaptures().then(captures => sendResponse({ok:true, captures})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'GET_TOKENS'){
    getCache().then(cache => sendResponse({ok:true, cache})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
  if(msg.type === 'CLEAR_TOKENS'){
    chrome.storage.local.set({[TOKEN_KEY]: {tokens:{}, tokensByModule:{}, updatedAt:0, captureStatus:{clearedAt:Date.now()}}})
      .then(() => sendResponse({ok:true})).catch(err => sendResponse({ok:false, error:String(err && err.message || err)}));
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  getCache().then(cache => chrome.storage.local.set({[TOKEN_KEY]: cache})).catch(()=>{});
});


function __takkomBodyFromRequestBody(rb){
  try{
    if(!rb) return '';
    if(rb.formData){
      const parts=[];
      Object.keys(rb.formData).forEach(k=>{
        const vals=Array.isArray(rb.formData[k])?rb.formData[k]:[rb.formData[k]];
        vals.forEach(v=>parts.push(encodeURIComponent(k)+'='+encodeURIComponent(String(v==null?'':v))));
      });
      return parts.join('&');
    }
    if(rb.raw && rb.raw.length){
      let out='';
      for(const r of rb.raw){
        if(r && r.bytes){
          try{ out += new TextDecoder('utf-8').decode(r.bytes); }catch(e){}
        }
      }
      return out;
    }
  }catch(e){}
  return '';
}
try{
  if(chrome.webRequest && chrome.webRequest.onBeforeRequest && !globalThis.__TAKKOM_V126_WEBREQ_CAPTURE__){
    globalThis.__TAKKOM_V126_WEBREQ_CAPTURE__=true;
    chrome.webRequest.onBeforeRequest.addListener(function(details){
      try{
        const u=String(details.url||'');
        if(!/\/keyss\/external_dispatch|\/gibintranet_server\/dispatch/i.test(u)) return;
        const body=__takkomBodyFromRequestBody(details.requestBody);
        const item={
          kind:'webRequest.before',
          method:details.method||'',
          url:u,
          body:body,
          tabId:details.tabId,
          requestId:details.requestId,
          resourceType:details.type,
          source:'webRequest.requestBody',
          createdAt:new Date().toISOString(),
          createdAtMs:Date.now()
        };
        storeKeyCaptures([item]).catch(()=>{});
      }catch(e){}
    }, {urls:['http://keys.ggm.bim/*','http://10.251.63.99/*']}, ['requestBody']);
  }
}catch(e){}
