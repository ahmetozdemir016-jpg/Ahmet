EVDB Emanet Excel Chrome Eklentisi v1.1
- Emanet Türü alanı bu ekrandaki uzun sarı combo yapısına göre özel yakalanır.
- 39 Diğer Çeşitli Emanetler native select / ExtJS combo / koordinat / klavye yöntemleriyle seçilmeye çalışılır.
- Bot sadece eklenti ikonuna basınca açılır.
