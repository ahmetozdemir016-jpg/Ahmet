# v4.31.59

- EYS Modülü > Yoklama Giriş > İş Takip İşlerini Getir listesi Ana Modül görünümüne daha çok eşitlendi.
- İşlem sütununa Ana Modül tarzı üç nokta akış seçenekleri eklendi.
- Seç / Doldur butonu aynı sütunda korunur.
- Yoklama Durum ve Yoklama Kodu sütunları eklendi.
- Yoklama kodları tıklanınca EYS sonuc/PDF akışından açılır.
- VKN aralık filtresi korunur.
