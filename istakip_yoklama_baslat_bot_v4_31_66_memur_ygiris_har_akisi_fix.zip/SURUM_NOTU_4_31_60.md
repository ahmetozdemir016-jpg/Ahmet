# v4.31.60

- Son gönderilen HAR/README(11).md dosyasındaki İş Takip “İşi Bitir (Şef)” akışı incelendi.
- Ana Modül > İşlem sütunundaki gerçek akış menüsü artık sadece log yazmaz; seçilen akış adımını onay alarak `akisIslemleri_akisYeniAdimKaydet` ile gönderir.
- `akisIslemleri_isTakipSonrakiAdimlariBul` cevabındaki `durumNo`, `tip` ve `akisNo` bilgileri menüde korunur.
- İşi Bitir (Şef) için HAR’daki payload mantığına uygun olarak `hedefDurumNo=4`, `akisDurumTip=24`, `islemSahibi=3`, `isiUzerimeAl=1` ve iş satırındaki `is_beklenenIsBitisZamani` alanından 12 haneli `beklenenIsBitisZamani` gönderilir.
- Her tekil işlemden sonra aktif iş sayıları ve liste yenilenir.
