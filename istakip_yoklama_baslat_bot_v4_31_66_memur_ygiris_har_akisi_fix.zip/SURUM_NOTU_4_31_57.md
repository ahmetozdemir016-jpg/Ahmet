# v4.31.57

- Kapatınca çıkan “İş Takip Botunu Aç” geri-açma düğmesi kaldırıldı.
- Panel kapatma artık sadece mevcut sayfa oturumu için geçerli; sayfa yenilenince panel tekrar açılır.
- Eski sürümlerden kalan kalıcı `closed` bayrağı temizlenir/yok sayılır.
- Her 300 ms panel yüksekliğini zorlayan layout sabitleme yumuşatıldı; panelin önce düzgün gelip sonra altının siyah boşluğa dönmesi engellendi.
- Taşıma/sol-alt resize ve tüm tokenler yakalanınca hook durdurma davranışı korunur.
