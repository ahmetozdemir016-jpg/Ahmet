# Sürüm Notu v4.31.62

- EYS Modülü > Yoklama Giriş > İş Takip İşlerini Getir listesinden Belge Bilgi, Durum ve Ünvan sütunları kaldırıldı.
- Ünvan bilgisi İşTakip sütununa eklendi.
- İşlem, İşin Türü, Önizle, Yoklama Durum ve Yoklama Kodu sütunları korundu.
