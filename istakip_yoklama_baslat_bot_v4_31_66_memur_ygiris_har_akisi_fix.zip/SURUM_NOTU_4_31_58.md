# v4.31.58

- EYS Modülü > Yoklama Giriş > İş Takip İşlerini Getir listesi Ana Modül tablo düzenine alındı.
- Listeye İşlem, İşTakip, Belge Bilgi, İşin Türü, Ünvan, Durum ve Önizle sütunları eklendi.
- İşlem sütununda Seç / Doldur butonu korundu.
- Durum sütunu Ana Modül mantığıyla Hariç / Uygun değil / Yoklama Süreci Başlat bilgisini gösterir.
- İş Takip VKN Başlangıç / Bitiş filtresi eklendi.
