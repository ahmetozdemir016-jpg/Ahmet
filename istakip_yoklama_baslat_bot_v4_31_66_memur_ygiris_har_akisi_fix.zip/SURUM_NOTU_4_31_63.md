# Sürüm Notu v4.31.63

- EYS Modülü > Yoklama Giriş > İş Takip İşlerini Getir sorgusu Ana Modül > İşleri Tara ana payload mantığıyla eşitlendi.
- Yoklama Giriş formundaki VKN/TCKN artık İş Takip listesini daraltmaz; VKN aralığı sadece ekranda filtre uygular.
- Butona her basıldığında liste sıfırlanıp yeniden servisten güncel çekilir.
- İşin Türü sütunu Ana Modül gibi aktif iş sayıları/detay eşleştirme tablosundan doldurulur.
- Önceki sade liste düzeni korundu.
