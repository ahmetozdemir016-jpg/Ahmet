# Sürüm Notu v4.31.65

- EYS Modülü > Yoklama Giriş listesindeki Önizle Aç artık her tıklamada ayrı pencere/modal açar.
- Ana Modül önizleme akışı da çoklu önizlemeyi destekler.
- Yoklama PDF/getSonuc pencereleri artık aynı pencere adını kullanmaz; ikinci yoklama öncekinin içine yüklenmez.
- Birden fazla evrak ve birden fazla yoklama aynı anda açık tutulabilir.
