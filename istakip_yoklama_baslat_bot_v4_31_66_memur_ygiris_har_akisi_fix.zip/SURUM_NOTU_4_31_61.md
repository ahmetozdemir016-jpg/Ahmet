# v4.31.61

- EYS Modülü > Yoklama Giriş > İş Takip İşlerini Getir listesindeki İşlem sütunu artık sadece seçim/log yapmıyor.
- Üç nokta menüsünden seçilen akış adımı `akisIslemleri_akisYeniAdimKaydet` ile sisteme gönderiliyor.
- Yoklama Süreci Başlat ve İşi Bitir (Şef) gibi sonraki adım seçenekleri EYS/Yoklama Giriş tarafında da onayla çalışır.
- Seç / Doldur butonu ayrı kaldı; form doldurma işlevi korunuyor.
