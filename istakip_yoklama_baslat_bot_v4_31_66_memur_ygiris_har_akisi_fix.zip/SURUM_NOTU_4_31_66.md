# Sürüm Notu v4.31.66

- Gerçek sistemin memur modunda Yoklama Giriş açılış HAR akışı incelendi.
- Yoklama Giriş VKN sorgusunda memur session ile VD combo ve İl listesi ön hazırlığı eklendi.
- Bilinen adres servisi gerçek HAR komut adına göre düzeltildi: `srvcRemoteCall_getVDAdresleri`.
- Önceki yoklama sorgusuna gerçek HAR payloadındaki `vdkodu` alanı eklendi.
- VKN sorgusu sonrası VD listesi, bilinen adres ve önceki yoklama akışı gerçek memur ekranına yaklaştırıldı.
- Bilinen adres seçilince artık adres no zinciri otomatik çalışır: adres string, koordinat, il/ilçe/mahalle/CSBM/dışkapı/içkapı.
