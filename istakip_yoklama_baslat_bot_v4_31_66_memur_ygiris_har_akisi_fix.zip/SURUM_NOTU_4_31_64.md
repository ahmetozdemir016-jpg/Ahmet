# Sürüm Notu v4.31.64

- EYS Modülü > Yoklama Giriş > İş Takip İşlerini Getir listesindeki Önizle Aç butonu düzeltildi.
- Önizleme artık Ana Modül > İşleri Tara listesindeki çalışan önizleme akışını kullanır.
- EYS tarafındaki KEYS token çözme düzeltildi; ekranda kırpılmış görünen tokenlar artık önizlemede kullanılmaz.
- Ana Modül önizleme akışı bulunamazsa EYS içi yedek önizleme akışına düşer.
