/* Ek 20: pişmanlık ihlali nedeniyle 0029 -> 0030 dönüşümünde 3080 tutar kontrolü.
   Kaynak: GİB Pişmanlıkla Beyan Rehberi, bölüm 16 ve 31.
   Matrah, tahakkuk ve ödenecek vergi ayrı tutulur; faiz/zam/damga vergiye eklenmez. */
(function(){'use strict';
function norm(v){return String(v==null?'':v).replace(/İ/g,'I').replace(/ı/g,'i').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
function id(v){return String(v==null?'':v).replace(/[\s/-]/g,'').toUpperCase();}
function kod(v){var s=String(v==null?'':v).trim();return /^\d{1,4}$/.test(s)?s.padStart(4,'0'):s;}
function num(v){return IhbarnameTutar.num(v);}
function vzler(e,vk){return (e&&e.cezalar||[]).filter(function(c){return String(c.kodu)==='3080'&&(!vk||!c.vergiKodu||kod(c.vergiKodu)===vk);});}
function baglam(e){
 var ac=norm(e&&e.aciklama);
 return !!(e&&(e.eklerinDayanagi||[]).some(function(x){return String(x.turuKodu)==='20';})&&vzler(e).length&&/pismanlik.{0,70}ihlal/.test(ac)&&!/ihlal.{0,25}(degil|yok|edilmemis|olusmamis)/.test(ac));
}
function vergiAyrica(e,t){
 if(!baglam(e)||!Array.isArray(e.vergilerHarclar))return false;
 var rs=IhbarnameTutar.rows(e),tarh=IhbarnameTutar.tarh(t);
 return (tarh==null||tarh===0)&&rs.every(function(r){return IhbarnameTutar.fields.every(function(f){return r[f[0]]===0;});});
}
function ayniDonemVergi(x,donem,vk,vkn){
 var v=String(x.vkn||x.vergiNo||'').trim();
 return periodKey12(x.vergiDonem)===donem&&(!v||v.replace(/^0+/,'')===String(vkn).replace(/^0+/,''))&&
   (!x.vergiKodu||kod(x.vergiKodu)===vk)&&(x.mhktahakkukSatirlari||[]).some(function(s){return kod(s.vergiKodu)===vk;});
}
function satirToplam(x,vk){
 var rs=(x.mhktahakkukSatirlari||[]).filter(function(s){return kod(s.vergiKodu)===vk;}),o={};
 ['matrah','thkEden','mahsup','odnOlan'].forEach(function(k){var a=rs.map(function(r){return num(r[k]);});o[k]=!a.length||a.some(function(v){return v==null;})?null:a.reduce(function(t,v){return t+v;},0);});return o;
}
function refEsles(x,refs){return refs.some(function(r){return r===id(x.thkFisNo)||r===id(x.bynOid);});}
function tl(v){return v==null?'okunamadı':fmt(v);}
function sonuc(out,hata,uyari){return {h:out.join('<br>'),hata:!!hata,uyari:!!uyari};}
function tarih(v){
 var s=String(v==null?'':v).trim(),m,y,a,g;
 if((m=/^(\d{4})[-/.](\d{2})[-/.](\d{2})(?:[ T].*)?$/.exec(s))){y=+m[1];a=+m[2];g=+m[3];}
 else if((m=/^(\d{2})[-/.](\d{2})[-/.](\d{4})(?:[ T].*)?$/.exec(s))){y=+m[3];a=+m[2];g=+m[1];}
 else if((m=/^(\d{4})(\d{2})(\d{2})(?:\d{6})?$/.exec(s))&&+m[1]>=1900){y=+m[1];a=+m[2];g=+m[3];}
 else if((m=/^(\d{2})(\d{2})(\d{4})$/.exec(s))){y=+m[3];a=+m[2];g=+m[1];}
 else return '';
 var d=new Date(Date.UTC(y,a-1,g));return y>=1900&&y<=2199&&d.getUTCFullYear()===y&&d.getUTCMonth()===a-1&&d.getUTCDate()===g?String(y)+String(a).padStart(2,'0')+String(g).padStart(2,'0'):'';
}
function tarihMetni(s){return s?s.slice(6,8)+'.'+s.slice(4,6)+'.'+s.slice(0,4):'okunamadı';}
function esasNo(x){return String(x.ihbarnameNo||x.ihbno||x.fisno||x.ihbarname_fisno||'').trim();}
function mukellefAyni(x,vkn){
 var alanlar=String(vkn).length===11?['tcKimlikNo','tckimlikno','tckn']:['vergiNo','vkn','vergino','vergiKimlikNo'],vs=alanlar.map(function(a){return String(x[a]||'').trim();}).filter(Boolean);
 return !vs.length||vs.some(function(v){return v.replace(/^0+/,'')===String(vkn).replace(/^0+/,'');});
}
async function esasIhbarnameCeza(x,vkn,vd){
 if(!x.no)return {hata:'Dayanak ihbarname numarası okunamadı; ihbarname içeriği sorgulanamadı.'};
 var org=typeof orgIDGetir==='function'?(orgIDGetir(vd)||''):'',e;
 try{e=await evdoIhbarnameGetir(x.no,org);}catch(err){return {hata:x.no+': dayanak ihbarname sorgusu tamamlanamadı.'};}
 if(!e||id(e.fisNo)!==id(x.no))return {hata:x.no+': dayanak ihbarname içeriği veya fiş numarası doğrulanamadı.'};
 if(!mukellefAyni(e,vkn))return {hata:x.no+': dayanak ihbarnamenin mükellefi farklı.'};
 var durum=norm(e.ihbarnameDurumu),dzt=String(e.dztFisno||'').trim();
 if(/iptal/.test(durum)&&!/edilmemis|degil/.test(durum))return {hata:x.no+': dayanak ihbarname iptal durumunda; kesinleşmiş ceza yeniden doğrulanmalı.'};
 if(dzt&&dzt!=='0')return {hata:x.no+': dayanak ihbarnamede düzeltme bağlantısı var ('+dzt+'); kesinleşmiş ceza tutarı ayrıca doğrulanmalı.'};
 if(!Array.isArray(e.cezalar)||e.cezalar.some(function(c){return !c||typeof c!=='object';}))return {hata:x.no+': dayanak ihbarnamenin ceza satırları okunamadı.'};
 var cs=e.cezalar.filter(function(c){return String(c.kodu)==='3080';}),ts=cs.map(function(c){return num(c.tutari);});
 if(!cs.length||ts.some(function(t){return t==null||t<0;}))return {hata:x.no+': dayanak ihbarnamenin 3080 ceza tutarı okunamadı.'};
 if(cs.length>1){var fs=cs.map(function(c){return tarih(c.cezaYili);});if(fs.some(function(f){return !f||f!==fs[0];}))return {hata:x.no+': farklı fiillere ait 3080 satırlarının kesinleşmiş ceza kaydıyla eşleştirilmesi gerekiyor.'};}
 var tutar=Math.round(ts.reduce(function(a,b){return a+b;},0)*100)/100;
 if(tutar<=0)return {hata:x.no+': dayanak ihbarnamede pozitif 3080 ceza tutarı doğrulanamadı.'};
 if(x.listeTutari!=null&&Math.abs(x.listeTutari-tutar)>0.005)return {hata:x.no+': tekerrür listesinde '+fmt(x.listeTutari)+' TL / ihbarname 3080 satırlarında '+fmt(tutar)+' TL; kesinleşmiş ceza tutarı farklı, üst sınır otomatik onaylanmadı.'};
 return {tutar:tutar};
}
/* EVDO tekerrur alanı artırım tutarı değildir. Artırım, kesinleşmiş önceki
   cezalar sorgulanarak VUK 339 (%50, en yüksek kesinleşmiş ceza sınırı) ile bulunur. */
async function tekerrurKontrol(k,e,cs,temel,kesilen,vkn,vd){
 var out=[],hata=false,uyari=false;
 function belirsiz(m){out.push('<small>'+tag('TEKERRÜR DOĞRULANAMADI','warn')+' '+esc(m)+'</small>');return {out:out,hata:false,uyari:true,beklenen:null};}
 var fiiller=cs.map(function(c){return tarih(c.cezaYili);}),ihb=tarih(e.duzenlenmeTarihi)||tarih(String(k.belgeNo||'').slice(0,8));
 if(!/^\d{10,11}$/.test(String(vkn)))return belirsiz('Mükellefin VKN/TCKN bilgisi okunamadı.');
 if(fiiller.some(function(f){return !f;})||!ihb)return belirsiz('Fiil veya ihbarname düzenleme tarihi okunamadı; tekerrür yok kabul edilmedi.');
 if(fiiller.some(function(f){return f!==fiiller[0];}))return belirsiz('3080 satırlarının fiil tarihleri farklı; her fiile ait temel ceza ve tekerrür ayrı belirlenmeli.');
 var fiil=fiiller[0];
 if(fiil>ihb)return belirsiz('Fiil tarihi ihbarname tarihinden sonra; kaynak tarihleri kontrol edilmeli.');
 if(ihb<'20211026')return belirsiz('26.10.2021 öncesindeki ihbarname için döneminde geçerli tekerrür hükümleri ayrıca incelenmeli.');
 var esaslar;try{esaslar=await tekerrurEsas(vkn,k.unvan||'','3080',fiil);}catch(err){return belirsiz('Kesinleşmiş ceza sorgusu tamamlanamadı.');}
 if(!Array.isArray(esaslar))return belirsiz('Kesinleşmiş ceza listesi okunamadı; boş liste sayılmadı.');
 var uygun=[],elenen=[],eksik=[];
 esaslar.forEach(function(x){
  if(!x||typeof x!=='object'){eksik.push('Geçersiz ceza kaydı');return;}
  var no=esasNo(x),kes=tarih(x.kesinlesmetarihi),tutar=num(x.ceza_tutari),ceza=kod(x.cezaKodu||x.cezakodu||x.ceza_kodu||'');
  function ele(neden){elenen.push((no||'Numarasız kayıt')+': '+neden+(kes?' ('+tarihMetni(kes)+')':''));}
  if(!mukellefAyni(x,vkn)){ele('Mükellef farklı');return;}
  if(ceza&&ceza!=='3080'){ele('Ceza türü farklı');return;}
  if(no&&id(no)===id(k.belgeNo)){ele('İncelenen ihbarnamenin kendisi');return;}
  if(!kes){eksik.push((no||'Numarasız kayıt')+': kesinleşme tarihi okunamadı');return;}
  if(kes>=fiil){ele('Kesinleşme yeni fiilden önce değil');return;}
  var son=String(+kes.slice(0,4)+5)+'1231';
  if(ihb>son){ele('Beşinci yılın sonuna kadar olan süre dışında');return;}
  if(tutar!=null&&tutar<0){eksik.push((no||'Numarasız kayıt')+': kesinleşmiş ceza tutarı geçersiz');return;}
  if(tutar===0){ele('Tekerrüre esas pozitif ceza tutarı yok');return;}
  uygun.push({no:no,kes:kes,listeTutari:tutar,son:son});
 });
 out.push('<small><b>Tekerrür sorgusu:</b> '+esc(vkn)+' · fiil '+tarihMetni(fiil)+' · ihbarname '+tarihMetni(ihb)+' · koşullara uyan '+uygun.length+' kesinleşmiş ceza.</small>');
 if(elenen.length)out.push('<small>Dışlanan kayıtlar: '+esc(elenen.slice(0,5).join(' · '))+(elenen.length>5?' · diğer '+(elenen.length-5)+' kayıt':'')+'</small>');
 if(eksik.length)return belirsiz(eksik.slice(0,5).join(' · '));
 var detaylar={};
 for(var i=0;i<uygun.length;i++){
  var u=uygun[i],key=id(u.no),detay=detaylar[key];
  if(!detay){detay=await esasIhbarnameCeza(u,vkn,vd);detaylar[key]=detay;}
  /* Aynı ihbarname listede tekrar etse de her kayıtla tutar tutarlılığı aranır. */
  if(!detay.hata&&u.listeTutari!=null&&Math.abs(u.listeTutari-detay.tutar)>0.005)detay={hata:u.no+': aynı ihbarname için listedeki kesinleşmiş ceza tutarları farklı.'};
  if(detay.hata){eksik.push(detay.hata);continue;}
  u.tutar=detay.tutar;
  out.push('<small><b>Dayanak ihbarname sorgulandı:</b> '+esc(u.no)+' · 3080 cezası '+fmt(u.tutar)+' TL'+(u.listeTutari==null?' · listedeki eksik tutar ihbarname içeriğinden alındı.':' · kesinleşmiş ceza listesiyle aynı.')+'</small>');
 }
 if(eksik.length)return belirsiz(eksik.slice(0,5).join(' · '));
 var max=uygun.reduce(function(a,x){return !a||x.tutar>a.tutar?x:a;},null),teorik=Math.round(temel*0.5*100)/100,artis=max?Math.min(teorik,max.tutar):0,beklenen=Math.round((temel+artis)*100)/100;
 if(max)out.push('<small>'+tag('TEKERRÜRE ESAS CEZA VAR','good')+' dayanak '+esc(max.no||'numara okunamadı')+' · kesinleşme '+tarihMetni(max.kes)+' · en yüksek ceza '+fmt(max.tutar)+' TL · süre sonu '+tarihMetni(max.son)+'.</small>');
 else out.push('<small>'+tag('TEKERRÜRE ESAS CEZA YOK','good')+' sorguda tarih ve ceza koşullarına uyan kayıt bulunmadı.</small>');
 out.push('<small><b>Tekerrür artırımı:</b> '+(max?fmt(temel)+' × %50 = '+fmt(teorik)+' TL; kesinleşmiş ceza sınırıyla '+fmt(artis)+' TL':'0,00 TL')+'</small>');
 out.push('<small><b>Beklenen toplam 3080:</b> '+fmt(temel)+' + '+fmt(artis)+' = '+fmt(beklenen)+' TL · <b>Kesilen:</b> '+fmt(kesilen)+' TL</small>');
 var isaretler=cs.map(function(c){return num(c.tekerrur);});
 if(isaretler.some(function(v){return v==null||v<0;})){uyari=true;out.push('<small>'+tag('TEKERRÜR İŞARETİ OKUNAMADI','warn')+' önceki ceza sorgusu ile artırım hesaplandı; ihbarname işareti ayrıca kontrol edilmeli.</small>');}
 else if(isaretler.some(function(v){return max?v<=0:v>0;})){hata=true;out.push('<small>'+tag('TEKERRÜR İŞARETİ UYUMSUZ','bad')+' '+(max?'tekerrüre esas ceza var; ilgili 3080 satırlarında EVDO tekerrür işareti eksik.':'EVDO’da tekerrür işaretli; koşullara uyan kesinleşmiş ceza bulunmadı.')+'</small>');}
 else out.push('<small>EVDO tekerrür işareti '+(max?'var':'yok')+'; kesinleşmiş ceza sorgusuyla uyumlu.</small>');
 var duzeltmeler=cs.map(function(c){return [c.indirim==null?0:num(c.indirim),c.oncedenKesilen==null?0:num(c.oncedenKesilen)];});
 if(duzeltmeler.some(function(a){return a.some(function(v){return v==null||v!==0;});})){uyari=true;out.push('<small>'+tag('NİHAİ CEZA KONTROLÜ GEREKLİ','warn')+' indirim veya önceden kesilen tutar var/okunamadı; yukarıdaki toplam bunlar öncesindeki temel ceza ve tekerrür hesabıdır.</small>');beklenen=null;}
 else{
  var uygulananArtis=Math.round((kesilen-temel)*100)/100;
  if(max&&uygulananArtis-max.tutar>0.005){hata=true;out.push('<small>'+tag('TEKERRÜR ÜST SINIRI AŞILMIŞ','bad')+' uygulanan artırım '+fmt(uygulananArtis)+' TL / dayanak ihbarnameden doğrulanan sınır '+fmt(max.tutar)+' TL.</small>');}
  if(!nearly(beklenen,kesilen)){hata=true;out.push('<small>'+tag('CEZA TUTARI UYUMSUZ','bad')+' fark '+fmt(kesilen-beklenen)+' TL; temel ceza ve doğrulanan tekerrür artırımı birlikte karşılaştırıldı.</small>');}
  else if(!hata&&artis>0)out.push('<small>'+tag('TUTAR FARKI TEKERRÜRDEN KAYNAKLANIYOR','good')+' temel cezaya göre '+fmt(artis)+' TL fark doğrulandı.</small>');
 }
 return {out:out,hata:hata,uyari:uyari,beklenen:beklenen};
}
async function kontrol(k,t,vkn,vd){
 var e=k.__evdoIhb,donem=periodKey12(t.eDonemAraligi),vk=kod(t.vergikodu),out=['<small><b>Pişmanlık ihlali — Ek 20 / 3080</b></small>'];
 function incele(m){out.push('<small>'+tag('KONTROL GEREKLİ','warn')+' '+esc(m)+'</small>');return sonuc(out,false,true);}
 if(!baglam(e)||!donem||!vk)return incele('Ek, açıklama, dönem veya vergi kodu doğrulanamadı.');
 var refs=[t.DZTFISNO,e.dztFisno].concat((e.eklerinDayanagi||[]).filter(function(x){return String(x.turuKodu)==='20';}).map(function(x){return x.numarasi;})).map(id).filter(Boolean);
 var rows=await gibTahakkuklar(vkn,vd,vk,donem);
 if(!Array.isArray(rows))return incele('Tahakkuk servisi cevap vermedi.');
 // Sadece ilgili dönem/vergi ve geçerli 0030 fişleri adaydır. İlk tahakkuk seçilmez.
 var seen={},aday=rows.filter(function(x){var key=id(x.thkFisNo);if(!key||seen[key])return false;seen[key]=true;return String(x.durum)==='1'&&kod(x.islemTuru)==='0030'&&ayniDonemVergi(x,donem,vk,vkn);});
 if(!aday.length)return incele('İlgili dönem ve vergi için geçerli 0030 düzeltme tahakkuku bulunamadı.');
 var zincirler=await Promise.all(aday.map(async function(x){
   var once=await dztOncesi(x.thkFisNo,vd);if(!Array.isArray(once))return {x:x,hata:true,once:[]};
   return {x:x,once:once.filter(function(o){return kod(o.islemTuru)==='0029'&&ayniDonemVergi(o,donem,vk,vkn);})};
 }));
 var uygun=zincirler.filter(function(z){return z.once.length&&(!refs.length||refEsles(z.x,refs)||z.once.some(function(o){return refEsles(o,refs);}));});
 if(uygun.length!==1)return incele(uygun.length?'Birden fazla bağlantılı düzeltme zinciri var; fiş ilişkisi elle doğrulanmalı.':refs.length?'Dayanak numarasıyla bağlantılı 0030 → 0029 düzeltme zinciri doğrulanamadı.':'Pişmanlık talepli 0029 kaydına dönüşüm bağlantısı doğrulanamadı.');
 var z=uygun[0];
 // Bir zincir okunamadıysa referansla açıkça seçilemeyen adaylar elenmiş sayılmaz.
 if(!refs.length&&zincirler.some(function(x){return x.hata;}))return incele('Bazı düzeltme zincirleri okunamadı; tek aday olduğu doğrulanamadı.');
 var eski=z.once,eskiRef=eski.filter(function(x){return refEsles(x,refs);});if(eskiRef.length)eski=eskiRef;
 var oldSeen={};eski=eski.filter(function(x){var key=id(x.thkFisNo);if(!key||oldSeen[key])return false;oldSeen[key]=true;return true;});
 if(eski.length!==1)return incele('Cezaya esas pişmanlık talepli düzeltme kaydı tek olarak belirlenemedi.');
 var once=eski[0],s=satirToplam(once,vk),son=satirToplam(z.x,vk);
 out.push('<small>Bağlantı: '+esc(once.thkFisNo)+' (0029 pişmanlık talepli düzeltme) → '+esc(z.x.thkFisNo)+' (0030 kanuni süresinden sonra düzeltme)</small>');
 out.push('<small>Dönem '+esc(donem)+' · vergi kodu '+esc(vk)+'</small>');
 out.push('<small><b>Pişmanlık talepli düzeltme:</b> beyan matrahı '+tl(s.matrah)+' · tahakkuk eden vergi '+tl(s.thkEden)+' · mahsup '+tl(s.mahsup)+' · ödenecek vergi '+tl(s.odnOlan)+'</small>');
 if(s.odnOlan==null||s.thkEden==null)return incele('Cezaya esas tahakkuk/ödenecek vergi alanları okunamadı. Matrah yerine sıfır kullanılmadı.');
 if(s.odnOlan<=0)return incele('Pişmanlık talepli düzeltmede pozitif ödenecek vergi bulunamadı.');
 if(s.mahsup!=null&&!nearly(s.thkEden-s.mahsup,s.odnOlan))return incele('Tahakkuk − mahsup ile ödenecek vergi tutarı tutarlı değil.');
 if(son.odnOlan!=null&&!nearly(son.odnOlan,s.odnOlan))return incele('Dönüşüm öncesi ve sonrası vergi tutarı farklı; cezaya esas vergi ayrıca belirlenmeli.');
 var cs=vzler(e,vk),tutarlar=cs.map(function(c){return num(c.tutari);}),matrahlar=cs.map(function(c){return num(c.cezaVergiZiyaninaUgratilanVergiMiktari);});
 if(!cs.length||tutarlar.some(function(v){return v==null;}))return incele('3080 ceza tutarı okunamadı.');
 var beklenen=Math.round(s.odnOlan*0.5*100)/100,kesilen=tutarlar.reduce(function(a,b){return a+b;},0);
 out.push('<small><b>Beklenen temel ceza:</b> '+fmt(s.odnOlan)+' × %50 = '+fmt(beklenen)+' TL · <b>Kesilen 3080:</b> '+fmt(kesilen)+' TL</small>');
 var hata=false,uyari=false;
 var kats=cs.map(function(c){return num(c.kat);});if(kats.some(function(v){return v==null;})){uyari=true;out.push('<small>'+tag('CEZA KAT ALANI OKUNAMADI','warn')+'</small>');}else if(kats.some(function(v){return Math.abs(v-0.5)>0.01;})){hata=true;out.push('<small>'+tag('KAT UYUMSUZ','bad')+' bu kontrolün temel ceza katı 0,5 olmalıdır.</small>');}
 if(matrahlar.some(function(v){return v==null;})){uyari=true;out.push('<small>'+tag('CEZAYA ESAS VERGİ ALANI OKUNAMADI','warn')+'</small>');}
 else{var cm=matrahlar.reduce(function(a,b){return a+b;},0);if(!nearly(cm,s.odnOlan)){hata=true;out.push('<small>'+tag('CEZAYA ESAS VERGİ FARKLI','bad')+' ihbarname '+fmt(cm)+' / dayanak '+fmt(s.odnOlan)+'</small>');}}
 var tek=await tekerrurKontrol(k,e,cs,beklenen,kesilen,vkn,vd);out=out.concat(tek.out);hata=hata||tek.hata;uyari=uyari||tek.uyari;
 if(!vergiAyrica(e,t)){uyari=true;out.push('<small>'+tag('EK VERGİ ALANI KONTROLÜ','warn')+' bu hesap yalnız pişmanlık ihlali cezasına ilişkindir; ihbarnamenin vergi satırları ayrıca incelenmelidir.</small>');}
 var fisler=[once.thkFisNo];if(id(z.x.thkFisNo)!==id(once.thkFisNo))fisler.push(z.x.thkFisNo);
 var odemeler=await Promise.all(fisler.map(function(fis){return tahakkukOdemeleri(vd,fis);}));
 odemeler.forEach(function(ops,i){var odenen=0,belirsiz=!Array.isArray(ops);
  if(Array.isArray(ops))ops.forEach(function(x){var code=kod(x.vergiKodu||x.vergikodu||x.vergiKodu1),v=num(x.odenen);if(code&&code!==vk)return;if(!code||v==null){belirsiz=true;return;}odenen+=v;});
  if(belirsiz){uyari=true;out.push('<small>'+tag('ÖDEME KAYDI DOĞRULANAMADI','warn')+' '+esc(fisler[i])+': ceza hesabı kontrol edildi; ödeme durumu ayrıca incelenmeli.</small>');}
  else{out.push('<small>'+esc(fisler[i])+' fişinin '+esc(vk)+' vergi ödeme kayıtları toplamı: '+fmt(odenen)+' TL.</small>');if(odenen>0){uyari=true;out.push('<small>'+tag('ÖDEME TARİHİNİ KONTROL EDİN','warn')+' kayıtlı ödeme ihlalden sonra yapılmış olabilir; yalnız tutardan süresinde ödendiği sonucu çıkarılmaz.</small>');}}
 });
 out.push('<small>'+tag(hata?'CEZA KONTROLÜ UYUMSUZ':tek.beklenen==null?'KONTROL TAMAMLANAMADI':'CEZA TUTARI UYUMLU',hata?'bad':tek.beklenen==null?'warn':'good')+'</small>');
 return sonuc(out,hata,uyari);
}
window.PismanlikIhlali={baglam:baglam,vergiAyrica:vergiAyrica,kontrol:kontrol};
})();
