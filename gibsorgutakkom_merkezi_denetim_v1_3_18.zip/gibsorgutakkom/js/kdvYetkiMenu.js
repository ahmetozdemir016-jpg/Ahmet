/* Görsellerdeki menü sırası korunur. GİB ekranlarına ilişkin servis/URL
   bilgisi olmayan işlemlerde gerçek menü yolu gösterilir; endpoint tahmin edilmez. */
(function(){
  'use strict';
  var gruplar=[
    {ad:'İadeleri Yetki Kapsamına Girmeyenlerin Kayıt İşlemleri',kalemler:[
      {s:'gib_ek1_giris',ad:'EK 1 Formu Giriş (SBMİYB Düzenleme Kullanma Raporlarına İlişkin Giriş)',gib:true},
      {s:'ek1',ad:'EK 1 Formu Listeleme'},
      {s:'sem',ad:'Sonradan Eklenen Mükellefleri Listeleme'},
      {s:'sei',ad:'Sonradan Eklenen İştirakçileri Listeleme'},
      {s:'vdk1',ad:'VDK-EK 1 Formu Listeleme'},
      {s:'gib_ek2_giris',ad:'EK 2 Formu Giriş (Olumsuz Tespitlere İlişkin Giriş)',gib:true},
      {s:'ek2',ad:'EK 2 Formu Listeleme'},
      {s:'seo',ad:'Sonradan Eklenen Ortakları Listeleme'}
    ]},
    {ad:'Kullanma Tespiti Giriş İşlemleri',kalemler:[
      {s:'vdkt',ad:'VDK-Kullanma Tespiti Olan Mükellefleri Listeleme'},
      {s:'gib_ek6',ad:'EK6 Formu Listeleme (Onaylanmamış Kullanma Tespitleri)',gib:true},
      {s:'kt',ad:'Kullanma Tespiti Olan Mükellefleri Listeleme'},
      {s:'vuk',ad:'VUK 370/b Kullanma Tespiti Olan Mükellefleri Listeleme'}
    ]},
    {ad:'İadeleri Yetki Kapsamına Girmeyenlerin Çıkış İşlemleri',kalemler:[
      {s:'gib_ek4_cikis',ad:'EK 4 Formu Çıkış İşlemleri',gib:true},
      {s:'ek4',ad:'EK 4 Formu Listeleme'},
      {s:'gib_cikis_iptal',ad:'Çıkış Olayı İptal İşlemi',gib:true},
      {s:'gib_iptal_olay',ad:'Çıkış İptali Yapılmış Olayları Listeleme',gib:true},
      {s:'gib_iptal_mukellef',ad:'Çıkış İptali Yapılmış Mükellefleri Listeleme',gib:true},
      {s:'gib_tekrar_cikis_yok',ad:'Çıkış İptali Yapılmış, Tekrar Çıkışı Yapılmamış Olayları Listeleme',gib:true}
    ]},
    {ad:'İadeleri Yetki Kapsamına Girmeyenler',kalemler:[
      {s:'gib_sicil_sorgu',ad:'Mükellef Sicil Bilgilerine Göre Olumsuz Rapor / Olumsuz Tespit Sorgu Ekranı',gib:true},
      {s:'gib_vd_kullanma',ad:'Vergi Dairesi Bazında Kullanma Tespiti Olan Mükellefleri Listeleme',gib:true},
      {s:'gib_iptal_mukellef_sorgu',ad:'Çıkış İptali Yapılmış Mükellefler',gib:true}
    ]},
    {ad:'Diğer Mevcut Listeler',ek:true,kalemler:[
      {s:'ek3',ad:'EK 3 Formu Listeleme'},
      {s:'cik',ad:'Çıkış İptali (Akış Durumuna Göre)'}
    ]}
  ];
  var menu=document.getElementById('yetkiMenu');
  var arama=document.getElementById('yetkiMenuAra');
  var kalemler={bekleyen:{s:'bekleyen',ad:'Bekleyen İşler',grup:'Vergi Dairesi İşlemleri'}};
  var oncekiAcik=null;
  function eleman(ad,sinif,metin){var el=document.createElement(ad);if(sinif)el.className=sinif;if(metin)el.textContent=metin;return el;}
  function gibAdresi(){var t=gibTokenGetir();return 'http://keys.ggm.bim/gibintranet/welcome.jsp'+(t?'?token='+encodeURIComponent(t):'');}
  function dugme(k){
    var b=eleman('button','',null);b.type='button';b.dataset.s=k.s;
    b.setAttribute('aria-controls','sek_'+k.s);
    b.appendChild(eleman('span','',k.ad));
    if(k.gib){b.appendChild(eleman('span','yetki-gib','GİB'));b.title='GİB İntranet menü yolunu göster';}
    b.onclick=function(){
      // Arama yalnızca gezinmeyi daraltır; seçimden sonra tüm menü görünür.
      if(arama.value){arama.value='';filtrele();}
      sekmeAc(k.s);
      document.getElementById('yetkiBaslik').focus();
    };
    return b;
  }
  function gibPaneli(k){
    var bolum=eleman('div','kutu yetki-gib-panel');bolum.id='sek_'+k.s;bolum.style.display='none';
    bolum.appendChild(eleman('h4','','GİB İntranet üzerinden devam edin'));
    bolum.appendChild(eleman('p','','Bu işlem için GİB İntranet’i açın ve aşağıdaki menü yolunu izleyin. Bağlantı GİB ana ekranını açar.'));
    var yol=eleman('ol');
    ['Vergi Dairesi İşlemleri',k.grup,k.ad].forEach(function(ad){yol.appendChild(eleman('li','',ad));});
    bolum.appendChild(yol);
    var a=eleman('a','yetki-gib-ac','GİB İntranet’i aç');
    a.href='http://keys.ggm.bim/gibintranet/welcome.jsp';a.target='_blank';a.rel='noopener noreferrer';
    a.onclick=function(){a.href=gibAdresi();};
    bolum.appendChild(a);
    bolum.appendChild(eleman('p','mut','GİB oturumunuzun açık olması gerekir.'));
    document.getElementById('yetkiIcerik').insertBefore(bolum,document.getElementById('hamCevap'));
  }
  menu.appendChild(dugme(kalemler.bekleyen));
  menu.appendChild(eleman('div','yetki-kok','Vergi Dairesi İşlemleri'));
  gruplar.forEach(function(g,i){
    var d=eleman('details');d.dataset.grup=String(i);d.open=i===0;
    d.appendChild(eleman('summary','',g.ad));
    var alt=eleman('div','yetki-alt');
    g.kalemler.forEach(function(k){k.grup=g.ad;kalemler[k.s]=k;alt.appendChild(dugme(k));if(k.gib)gibPaneli(k);});
    d.appendChild(alt);menu.appendChild(d);
  });
  function norm(s){return String(s).toLocaleLowerCase('tr').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ı/g,'i');}
  function filtrele(){
    var metin=norm(arama.value.trim());
    var dallar=menu.querySelectorAll('details');
    if(metin&&oncekiAcik===null){oncekiAcik=[];dallar.forEach(function(d){oncekiAcik.push(d.open);});}
    var say=0;
    var bekleyen=menu.querySelector('button[data-s="bekleyen"]');
    bekleyen.hidden=!!metin&&norm(kalemler.bekleyen.ad).indexOf(metin)<0;
    if(!bekleyen.hidden)say++;
    dallar.forEach(function(d,i){
      var varMi=false;
      d.querySelectorAll('button[data-s]').forEach(function(b){
        var k=kalemler[b.dataset.s];b.hidden=!!metin&&norm(k.grup+' '+k.ad).indexOf(metin)<0;
        if(!b.hidden){varMi=true;say++;}
      });
      d.hidden=!varMi;
      if(metin){d.open=varMi;}else if(oncekiAcik){d.open=oncekiAcik[i];}
    });
    if(!metin)oncekiAcik=null;
    document.getElementById('yetkiMenuBos').hidden=say>0;
  }
  arama.addEventListener('input',filtrele);
  document.getElementById('btnBekleyenDon').onclick=function(){
    sekmeAc('bekleyen');
    var g=Array.isArray(window.SON)?ciz(window.SON):[];
    durumYaz('Bekleyen İşler'+(g.length?' — '+g.map(function(x){return x.ad+': '+x.say;}).join(' · '):''));
    document.getElementById('yetkiBaslik').focus();
  };
  window.yetkiMenuSec=function(s){
    var k=kalemler[s];if(!k)return;
    // Bekleyen işler içinden açılan listeler, menü aramasıyla gizli kalmamalı.
    if(arama.value){arama.value='';filtrele();}
    menu.querySelectorAll('button[data-s]').forEach(function(b){
      var aktif=b.dataset.s===s;b.classList.toggle('aktif',aktif);
      if(aktif){b.setAttribute('aria-current','page');var d=b.closest('details');if(d)d.open=true;}
      else b.removeAttribute('aria-current');
    });
    document.getElementById('yetkiBaslik').textContent=k.ad;
    document.getElementById('btnBekleyenDon').hidden=s==='bekleyen';
    document.getElementById('yetkiYol').textContent='Vergi Dairesi İşlemleri'+(s==='bekleyen'?'':' › '+k.grup);
    document.getElementById('hamCevap').hidden=!!k.gib;
  };
  window.yetkiMenuSec('bekleyen');
})();
