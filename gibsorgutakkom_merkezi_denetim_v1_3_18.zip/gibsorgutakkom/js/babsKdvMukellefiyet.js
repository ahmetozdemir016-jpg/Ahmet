/* Ana VKN'nin sicil geçmişindeki 0015 KDV mükellefiyetini BA/BS dönemiyle karşılaştırır. */
(function(){'use strict';
var KOLON='ANA MÜKELLEF KDV MÜKELLEFİYETİ (DÖNEM)';
function gun(y,a,g){var d=new Date(Date.UTC(y,a-1,g));return y>=1900&&y<=2199&&d.getUTCFullYear()===y&&d.getUTCMonth()===a-1&&d.getUTCDate()===g?String(y)+String(a).padStart(2,'0')+String(g).padStart(2,'0'):'';}
function tarih(v){var s=String(v==null?'':v).trim(),m;if((m=/^(\d{4})(\d{2})(\d{2})$/.exec(s)))return gun(+m[1],+m[2],+m[3]);if((m=/^(\d{4})[-/.](\d{2})[-/.](\d{2})$/.exec(s)))return gun(+m[1],+m[2],+m[3]);if((m=/^(\d{2})[-/.](\d{2})[-/.](\d{4})$/.exec(s)))return gun(+m[3],+m[2],+m[1]);return '';}
function ay(v,son){var s=String(v==null?'':v).trim(),m,y,a;if((m=/^(\d{4})-?(\d{2})$/.exec(s))){y=+m[1];a=+m[2];}else if((m=/^(\d{2})[/.](\d{4})$/.exec(s))){y=+m[2];a=+m[1];}else return '';return a>=1&&a<=12?gun(y,a,son?new Date(Date.UTC(y,a,0)).getUTCDate():1):'';}
function sinir(x,son){var t=x[son?'bittar':'bastar'],p=x[son?'donbittar':'donbastar'],q=x[son?'bitdonem':'basdonem'];if(String(t==null?'':t).trim())return tarih(t);if(String(p==null?'':p).trim())return ay(p,son)||tarih(p);if(String(q==null?'':q).trim())return ay(q,son);return son&&['bittar','donbittar','bitdonem'].some(function(k){return Object.prototype.hasOwnProperty.call(x,k);})?'99991231':'';}
function donem(s){var m=/^(\d{4}-\d{2})(?:\s*\/\s*(\d{4}-\d{2}))?$/.exec(String(s||'').trim());if(!m)return null;var b=ay(m[1],false),e=ay(m[2]||m[1],true);return b&&e&&b<=e?{bas:b,bit:e}:null;}
function ayni(d,vkn){var v=String(d.vergino||d.vkn||d.vergiNo||'').trim();return !v||v.replace(/^0+/,'')===String(vkn).replace(/^0+/,'');}
async function sicil(vkn,tok,durdu){
 var out={araliklar:[],eksik:false};
 if(!/^\d{10}$/.test(String(vkn)))return {araliklar:[],eksik:true};
 var r;try{r=await post(GIB_DISPATCH,'sicilService_sicilBilgileriSorgula',{vkn:vkn,tckn:''},tok);}catch(e){return {araliklar:[],eksik:true};}
 var d=r&&r.data,bv=d&&d.vdler&&d.vdler.baglivd;
 if(!d||r.error||!ayni(d,vkn)||!Array.isArray(bv)||!bv.length)return {araliklar:[],eksik:true};
 var seen={};
 for(var i=0;i<bv.length;i++){
  if(durdu&&durdu()){out.eksik=true;break;}
  var b=bv[i];if(!b||!b.vdkodu||(!b.birimoid&&!b.mukblgoid)){out.eksik=true;continue;}
  var jp={vkn:vkn,vdkodu:String(b.vdkodu),birimOid:String(b.birimoid||''),subeno:String(b.subeno||''),subeadi:String(b.subeadi||''),isyerituru:String(b.isyerituru||''),isyerinitelik:String(b.isyerinitelik||''),mukblgoid:String(b.mukblgoid||'')},key=JSON.stringify(jp);
  if(seen[key])continue;seen[key]=true;
  try{
   var rr=await post(GIB_DISPATCH,'sicilService_mukSicilDetayBilgileriGetir',jp,tok),dd=rr&&rr.data,ts=dd&&dd.mukellefBilgi&&dd.mukellefBilgi.mukellefiyet;
   if(!dd||rr.error||!ayni(dd,vkn)||!Array.isArray(ts)){out.eksik=true;continue;}
   ts.forEach(function(t){if(!t||!/^\d{1,4}$/.test(String(t.vergikodu||''))){out.eksik=true;return;}if(String(t.vergikodu).padStart(4,'0')!=='0015')return;
    var bas=sinir(t,false),bit=sinir(t,true);if(!bas||!bit||bas>bit){out.eksik=true;return;}out.araliklar.push({bas:bas,bit:bit});});
  }catch(e){out.eksik=true;}
 }
 return out;
}
function deger(s,per){var p=donem(per);if(!p)return 'Kontrol gerekli (dönem okunamadı)';if(s&&s.araliklar.some(function(a){return a.bas<=p.bit&&a.bit>=p.bas;}))return 'Var';return !s||s.eksik?'Kontrol gerekli (sicil bilgisi eksik)':'Yok';}
async function doldur(rows,tok,cache,opt){
 opt=opt||{};var gr={},gruplar=[],sonraki=0,bitti=0;rows.forEach(function(r){var i=r.basliklar.indexOf(KOLON);if(i<0)return;var v=String(r.vkn||'');if(!gr[v]){gr[v]=[];gruplar.push(v);}gr[v].push(r);});
 async function isci(){while(!(opt.durdu&&opt.durdu())){var ix=sonraki++;if(ix>=gruplar.length)return;var v=gruplar[ix];if(!cache[v])cache[v]=sicil(v,tok,opt.durdu);var s=await cache[v];gr[v].forEach(function(r){var ci=r.basliklar.indexOf(KOLON),di=r.basliklar.indexOf('DÖNEM');r.deger[ci]=deger(s,di<0?'':r.deger[di]);});bitti++;if(opt.ilerle)opt.ilerle(bitti,gruplar.length);}}
 var hs=[],n=Math.max(1,Math.min(10,parseInt(opt.paralel,10)||1));for(var i=0;i<Math.min(n,gruplar.length);i++)hs.push(isci());await Promise.all(hs);
 rows.forEach(function(r){var i=r.basliklar.indexOf(KOLON);if(i>=0&&r.deger[i]==='Sorgu bekliyor')r.deger[i]='Kontrol gerekli (sorgu durduruldu)';});
}
window.BabsKdv={kolon:KOLON,sicil:sicil,deger:deger,doldur:doldur};
})();
