/* EVDB Rapor: ihbarname ve tahakkuk PDF'leri. Durum kodu tahmin edilmez. */
(function(){'use strict';
function norm(v){return String(v||'').replace(/[\s/\-]/g,'').toUpperCase();}
function etiketOku(items,spec){
 var map={};spec.forEach(function(s){[s[0]].concat(s[1]||[]).forEach(function(a){map[tdKey(a)]=s[0];});});var val={},seen={};
 tdSatirlar(items,2.5).forEach(function(row){var it=row.items,labels=[];
  for(var i=0;i<it.length;i++){var found=null;
   for(var n=Math.min(5,it.length-i);n>=1;n--){var str=it.slice(i,i+n).map(function(x){return x.s;}).join(' ').trim(),ci=str.indexOf(':'),lab=ci>=0?str.slice(0,ci):str,k=map[tdKey(lab)];if(ci>=0&&n>1&&ci<it.slice(i,i+n-1).map(function(x){return x.s;}).join(' ').length+1)continue;if(k){found={k:k,i:i,end:i+n,inline:ci>=0?str.slice(ci+1).trim():''};break;}}
   if(found){labels.push(found);i=found.end-1;}
  }
  labels.forEach(function(l,j){seen[l.k]=true;var end=j<labels.length-1?labels[j+1].i:it.length,vs=l.inline?l.inline:it.slice(l.end,end).map(function(x){return x.s;}).join(' ').replace(/^\s*:\s*/,'').trim();if(val[l.k]===undefined||vs)val[l.k]=vs;});
 });return {values:val,seen:seen};
}
var THK=[['Tahakkuk Fiş Numarası',['Tahakkuk Fiş No']],['Durumu',['Durum']],['Vergi Kimlik Numarası'],['TC Kimlik Numarası',['T.C. Kimlik Numarası']],['Soyad (Ünvan) Ad'],['Ana Vergi Kodu'],['Vergilendirme Dönemi'],['Kabul Tarihi'],['Düzenleme Tarihi'],['Thk. İşlem Türü'],['Tahakkuk Türü'],['Plaka Numarası'],['Şasi Numarası'],['Dosya No'],['Rapor Kayıt No'],['Açıklama'],['Manuel Thk. Fiş No'],['Beyanname Durumu'],['Şube No'],['Düzeltme Fiş No'],['İhbarname Fiş No'],['Olay Kayıt Defter No'],['KATP Referans No'],['TPC Tutanak No'],['Tahakkuk Takipli Mi'],['Tahakkuk İhtirazi Mi'],['Tahakkuk İhtiyati Mi'],['Tahakkuk Kaynağı'],['Evrak No'],['Haciz Bildirisi E/Haciz No'],['Haciz Bildirisi Vergi No'],['Haciz Bildirisi T.C. No']];
function tahakkukCoz(items,no){var p=etiketOku(items,THK),v=p.values,fis=v['Tahakkuk Fiş Numarası']||'';
 if(norm(fis)!==norm(no))throw Error('Tahakkuk PDF fiş numarası eşleşmedi.');if(!v.Durumu)throw Error('Tahakkuk durumu okunamadı.');
 var a=items.filter(function(x){return tdN(x.s)==='tahakkuk satirlari';})[0],b=a&&items.filter(function(x){return x.y<a.y&&/^(tahakkuk vadeleri|takip dosya numaralari|kullanici bilgisi)$/.test(tdN(x.s));}).sort(function(a,b){return b.y-a.y;})[0];
 return {fis:fis,durum:v.Durumu,dzt:v['Düzeltme Fiş No']||'',dztBiliniyor:!!p.seen['Düzeltme Fiş No'],ihbarname:v['İhbarname Fiş No']||'',bilgi:v,satirlar:a?tdTablo(items,a.y,b?b.y:-1e9):{kolon:[],satir:[]}};
}
function raporUrl(tip,no,tok){var params=tip==='ihb'?{serviceName:'evdoLRTarhiyatServices_ihbarnameFisnoSorgulama',reportName:'RP_EVDO_IHBARNAME_FIS_SORGULAMA',IHBARNAME_FISNO:String(no)}:{serviceName:'evdoLRTahakkukServices_tahakkukFisiSorgulama',reportName:'RP_EVDO_MUKELLEF_LISTELERI_THK_FISI_SORGULAMA',FISNUMARASI:String(no)};return 'http://10.251.63.99/evdorapor_server/pdf?params='+encodeURIComponent(JSON.stringify(params))+'&cmd=evdorapor&token='+encodeURIComponent(tok);}
async function pdfItems(u){var doc=await pdfjsLib.getDocument({data:u}).promise,items=[];try{for(var i=1;i<=doc.numPages;i++){var pg=await doc.getPage(i),tc=await pg.getTextContent();tc.items.forEach(function(t){if(t.str&&t.str.trim())items.push({x:t.transform[4],y:t.transform[5]-(i-1)*2000,w:t.width||0,s:t.str});});}}finally{try{doc.destroy();}catch(e){}}return items;}
async function ihbarnameOku(no,tok){var u=await tdPdfAl(raporUrl('ihb',no,tok));if(!u)throw Error('İhbarname PDF alınamadı.');var rs=await tdPdfCoz(u),r=rs.find(function(r){return norm(r.fis['Fiş No'])===norm(no);});if(TD.dur)throw Error('Durduruldu.');if(!r)throw Error('İhbarname PDF fiş numarası eşleşmedi.');if(!r.fis['İhbarname Durumu'])throw Error('İhbarname durumu okunamadı.');return r;}
async function tahakkukOku(no,tok){var u=await tdPdfAl(raporUrl('thk',no,tok));if(!u)throw Error('Tahakkuk PDF alınamadı.');return tahakkukCoz(await pdfItems(u),no);}
function dztMetni(no,biliniyor){if(!biliniyor)return 'Düzeltme alanı okunamadı';if(!no)return 'Düzeltme fişi yok';var d=TD_DZT[tdDztNo(no)];return no+' · '+(!d?'Sorgu bekliyor':d.hata?d.hata:!d.durum?'Düzeltme durumu okunamadı':d.durum+(d.aciklama?' · '+d.aciklama:''));}
function tahDetay(r){if(r.__ihbAyrinti&&!(r.tah||[]).length)return 'Tahakkuk yok';return (r.tah||[]).map(function(t){return t.fis+': '+(!t.__detay?t.__hata||'Sorgu bekliyor':t.__detay.durum);}).join('\n');}
function tahDurumu(d){var n=tdN(d&&d.durum);if(/^(gecerli|onaylanmis|onayli|iptal edilmemis)$/.test(n))return 'var';if(/iptal/.test(n)&&!/edilmemis|degil/.test(n))return 'iptal';return 'belirsiz';}
function tahVergileri(d){var k=d.satirlar.kolon.filter(function(k){return tdKey(k)==='vergikodu';})[0],m=d.satirlar.kolon.filter(function(k){return /^odenecek(olan|miktar)$/.test(tdKey(k));})[0];if(!k||!m)return null;return d.satirlar.satir.filter(function(r){return /^\d{4}$/.test(String(r[k]||'').trim());}).map(function(r){return {kod:r[k],miktar:r[m]||''};});}
function tahDzt(r){if(r.__ihbAyrinti&&!(r.tah||[]).length)return 'Uygulanmaz (tahakkuk yok)';return (r.tah||[]).map(function(t){var d=t.__detay;return t.fis+': '+(d?dztMetni(d.dzt,d.dztBiliniyor):t.__hata||'Sorgu bekliyor');}).join('\n');}
var calisiyor=false,paralelAnahtar='takkom_evdb_fis_paralel';
function paralelSayisi(){var el=document.getElementById('tdFisParalel'),n=parseInt(el&&el.value,10);return Math.max(1,Math.min(10,isFinite(n)?n:10));}
async function ayrintiGetir(){if(calisiyor||TD.mod!=='tarh'||!TD.kayit.length)return;var tok=evdoRaporTokenGetir();if(!tok){alert('EVDB Rapor tokeni bulunamadı.');return;}
 var kayitlar=TD.kayit,cacheI={},cacheT={},cacheD={},i=0,bitti=0,hata=0,paralel=paralelSayisi();calisiyor=true;TD.__fisKontrolBasladi=true;TD.dur=false;TD_DZT={};kayitlar.forEach(function(r){delete r.__ihbAyrinti;delete r.__ihbHata;r.__ihbKontrol='Sorgu bekliyor';(r.tah||[]).forEach(function(t){delete t.__detay;delete t.__hata;});});
 function aktif(){return !TD.dur&&TD.kayit===kayitlar&&TD.mod==='tarh';}
 function ctl(on){['tdSorgula','tdExcel','tdYazdir','tdFisYenile','tdFisParalel'].forEach(function(id){var e=document.getElementById(id);if(e)e.disabled=on;});document.getElementById('tdDurdur').disabled=!on;}
 function once(c,no,fn){var k=norm(no);if(!c[k])c[k]=fn();return c[k];}
 async function dzt(no){if(!no||!aktif())return;return once(cacheD,no,async function(){try{TD_DZT[tdDztNo(no)]=await tdDztOku(no,tok);}catch(e){TD_DZT[tdDztNo(no)]={hata:'Düzeltme PDF okunamadı'};}});}
 async function isci(){while(aktif()&&i<kayitlar.length){var r=kayitlar[i++],no=r.fis['Fiş No'];delete r.__ihbHata;r.__ihbKontrol='Sorgulanıyor';
  try{var d=await once(cacheI,no,function(){return ihbarnameOku(no,tok);});if(!aktif())break;
   (d.alanlar||Object.keys(d.fis)).forEach(function(k){r.fis[k]=d.fis[k];});['ek','ceza','vergi','toplamCeza'].forEach(function(k){r[k]=d[k];});r.tah=JSON.parse(JSON.stringify(d.tah||[]));r.__ihbAyrinti=d;r.__ihbKontrol='EVDB ihbarname sorgusundan alındı';
   if((d.alanlar||[]).indexOf('Düzeltme Fiş No')>=0)await dzt(r.fis['Düzeltme Fiş No']);
   for(var j=0;j<r.tah.length&&aktif();j++){var t=r.tah[j];if(!t.fis)continue;try{var dt=await once(cacheT,t.fis,function(){return tahakkukOku(t.fis,tok);});if(!aktif())break;if(dt.ihbarname&&norm(dt.ihbarname)!==norm(no))throw Error('Tahakkuk başka ihbarnameye bağlı.');t.__detay=dt;t.dzt=dt.dzt;t.anaKod=dt.bilgi['Ana Vergi Kodu']||t.anaKod;t.islem=dt.bilgi['Thk. İşlem Türü']||t.islem;t.tur=dt.bilgi['Tahakkuk Türü']||t.tur;var vs=tahVergileri(dt);if(vs!==null)t.vergi=vs;await dzt(dt.dzt);}catch(e){t.__hata=e.message;hata++;}}
  }catch(e){if(!aktif())break;r.__ihbHata=e.message;r.__ihbKontrol=e.message;delete r.__ihbAyrinti;hata++;}
  if(!aktif())break;bitti++;if(bitti%5===0||bitti===kayitlar.length){tdKolonlariTopla();tdFiltreDoldur();tdCiz();durumYaz('EVDB fiş ayrıntıları: '+bitti+' / '+kayitlar.length+' · '+hata+' okunamayan');}
 }}
 ctl(true);tdCiz();try{var isciler=[];for(var w=0;w<Math.min(paralel,kayitlar.length);w++)isciler.push(isci());await Promise.all(isciler);}finally{calisiyor=false;ctl(false);if(TD.kayit===kayitlar&&TD.mod==='tarh'){tdKolonlariTopla();tdFiltreDoldur();tdCiz();durumYaz((TD.__listeSorguOzeti?TD.__listeSorguOzeti+' · ':'')+(TD.dur?'Durduruldu: ':'EVDB fiş ayrıntıları tamamlandı: ')+bitti+' / '+kayitlar.length+' · '+hata+' okunamayan.');}}
}
// Existing column selections are migrated so the status is directly after service date.
var eskiSecim=tdSecim;tdSecim=function(){var s=eskiSecim();if(TD.mod!=='tarh')return s;s=Object.assign({},s);s.fis=(s.fis||[]).filter(function(k){return k!=='İhbarname Durumu';});var ix=s.fis.indexOf('Tebliğ Tarihi');if(ix<0){s.fis.push('Tebliğ Tarihi');ix=s.fis.length-1;}s.fis.splice(ix+1,0,'İhbarname Durumu');return s;};
var eskiKolonlar=tdKolonlar;tdKolonlar=function(){var ks=eskiKolonlar();if(TD.mod!=='tarh'||!TD.__fisKontrolBasladi)return ks;
 ks.push({ad:'İhbarname Kontrolü',f:function(r){return r.__ihbKontrol||'Fiş ayrıntısı sorgulanmadı';}});
 ks.push({ad:'İhbarname Düzeltme Kontrolü',f:function(r){return r.__ihbHata||dztMetni(r.fis['Düzeltme Fiş No'],!!(r.__ihbAyrinti&&(r.__ihbAyrinti.alanlar||[]).indexOf('Düzeltme Fiş No')>=0));}});
 ks.push({ad:'Tahakkuk Durumu',cok:true,f:tahDetay});ks.push({ad:'Tahakkuk Düzeltme Kontrolü',cok:true,f:tahDzt});
 ks.push({ad:'Tahakkuk Satır Bilgileri',cok:true,f:function(r){return (r.tah||[]).map(function(t){var d=t.__detay;return t.fis+': '+(d?d.satirlar.satir.map(function(x){return Object.keys(x).map(function(k){return k+': '+x[k];}).join(' · ');}).join('\n'):t.__hata||'Sorgu bekliyor');}).join('\n');}});return ks;};
var eskiKontrol=tdTahKontrol;tdTahKontrol=function(r){if(TD.mod!=='tarh'||!TD.__fisKontrolBasladi)return eskiKontrol(r);if(r.__ihbHata)return {k:'belirsiz',m:r.__ihbHata};if(!r.__ihbAyrinti)return {k:'belirsiz',m:'EVDB fiş ayrıntısı sorgulanmadı'};
 if(/^iptal( edilmis)?$/.test(tdN(r.fis['İhbarname Durumu'])))return {k:'iptal',m:'İhbarname iptal durumunda'};
 var ts=(r.tah||[]).filter(function(t){return !!t.fis;}),gecerli=ts.filter(function(t){return tahDurumu(t.__detay)==='var';});if(gecerli.length)return {k:'var',m:gecerli.length+' geçerli tahakkuk'+(ts.some(function(t){return tahDurumu(t.__detay)==='belirsiz';})?' · bazı fişler doğrulanamadı':'')};
 if(ts.some(function(t){return !t.__detay||tahDurumu(t.__detay)==='belirsiz';}))return {k:'belirsiz',m:'Tahakkuk PDF durumu doğrulanamadı'};
 var d=r.__ihbAyrinti;if((d.alanlar||[]).indexOf('Düzeltme Fiş No')<0)return {k:'belirsiz',m:'İhbarname düzeltme alanı okunamadı'};
 var no=r.fis['Düzeltme Fiş No'],dz=no?TD_DZT[tdDztNo(no)]:null;if(no&&(!dz||dz.hata||!dz.durum))return {k:'belirsiz',m:'İhbarname düzeltme durumu doğrulanamadı'};
 var tmp=Object.assign({},r,{tah:[]}),v=eskiKontrol(tmp);if(ts.length)v.m+=' · tahakkuklar iptal durumunda';return v;};
var sorgu=tdSorgula,anaSorgu=false;tdSorgula=async function(){if(calisiyor||anaSorgu)return;anaSorgu=true;var el=document.getElementById('tdFisYenile');el.disabled=true;try{return await sorgu();}finally{anaSorgu=false;el.disabled=TD.mod!=='tarh'||!TD.kayit.length;kaynakCiz();}};
var btn=document.createElement('button');btn.id='tdFisYenile';btn.type='button';btn.className='w3-btn';btn.textContent='EVDB Güncel Durum Sorgula';btn.title='Listedeki ihbarname ve bağlı tahakkukların güncel durum ve düzeltme bilgilerini sorgular';btn.disabled=true;btn.onclick=ayrintiGetir;var eskiMod=tdModAyarla;tdModAyarla=function(m){eskiMod(m);btn.style.display=m==='tarh'?'':'none';paralelKutu.style.display=m==='tarh'?'':'none';kaynak.style.display=m==='tarh'?'':'none';btn.disabled=calisiyor||anaSorgu||!TD.kayit.length;};document.getElementById('tdSutunBtn').after(btn);
var paralelKutu=document.createElement('label');paralelKutu.id='tdFisParalelKutu';paralelKutu.style.cssText='min-width:auto;margin-left:8px;margin-right:8px';paralelKutu.textContent='Paralel sorgu ';var paralelSec=document.createElement('select');paralelSec.id='tdFisParalel';paralelSec.title='İhbarname ve bağlı tahakkuklar için aynı anda çalışacak sorgu sayısı';for(var p=1;p<=10;p++){var sec=document.createElement('option');sec.value=String(p);sec.textContent=String(p);paralelSec.appendChild(sec);}var kayitli=10;try{var n=parseInt(localStorage.getItem(paralelAnahtar),10);if(n>=1&&n<=10)kayitli=n;}catch(e){}paralelSec.value=String(kayitli);paralelSec.onchange=function(){this.value=String(paralelSayisi());try{localStorage.setItem(paralelAnahtar,this.value);}catch(e){}};paralelKutu.appendChild(paralelSec);btn.after(paralelKutu);
var kaynak=document.createElement('div');kaynak.id='tdFisKaynak';kaynak.className='mut';kaynak.style.marginTop='4px';btn.parentNode.after(kaynak);
function kaynakCiz(){kaynak.textContent=anaSorgu?'Liste getiriliyor…':calisiyor?'EVDB güncel durum sorgusu çalışıyor…':!TD.kayit.length?'Önce listeyi getirin.':!TD.__fisKontrolBasladi?'Liste bilgileri gösteriliyor. Güncel EVDB kontrolünü isterseniz başlatabilirsiniz.':TD.dur?'EVDB kontrolü durduruldu; doğrulanamayan kayıtlar belirtilmiştir.':'EVDB kontrolü sonuçları gösteriliyor; okunamayan kayıtlar belirtilmiştir.';}
var eskiCiz=tdCiz;tdCiz=function(){eskiCiz();kaynakCiz();};kaynakCiz();
[['belirsiz','Fiş bilgisi doğrulanamadı'],['iptal','İhbarname iptal']].forEach(function(o){var op=document.createElement('option');op.value=o[0];op.textContent=o[1];document.getElementById('tdFTah').appendChild(op);});
window.EVDBFis={etiketOku:etiketOku,tahakkukCoz:tahakkukCoz,url:raporUrl,ihbarnameOku:ihbarnameOku,tahakkukOku:tahakkukOku,yenile:ayrintiGetir};tdSutunPanel();
})();
