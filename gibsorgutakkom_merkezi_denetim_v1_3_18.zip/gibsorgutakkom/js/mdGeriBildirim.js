(function(){
  'use strict';
  var H=['Rapor','Açıklama','İşlem Durumu','Sorumlu','Bölüm','Liste Ayı','Vergi Dairesi','İş Anahtarı','Önceki Geri Bildirim'];
  var records=[],groups=[],choices=Object.create(null),currentIndex=new Map(),issues=[],busy=false;
  function text(v){return String(v==null?'':v).trim();}
  function norm(v){return trN(text(v)).replace(/[^a-z0-9]+/g,' ').trim();}
  function month(d){return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2);}
  function office(v){var s=text(v).replace(/\D/g,'');return s&&s.length<=6?s.padStart(6,'0'):s;}
  function vkn(v){var s=text(v).replace(/\D/g,'');return s&&s.length<=10?s.padStart(10,'0'):s;}
  function status(v){var n=norm(v);if(!n||/^(bekliyor|yapilmadi|islem yapilmadi)$/.test(n))return 'Bekliyor';if(/^(tamamlandi|yapildi|bitti)$/.test(n))return 'Tamamlandı';if(/^(devam ediyor|devam|islemde)$/.test(n))return 'Devam Ediyor';return '';}
  function ay(id){return document.getElementById(id).value;}
  function stableValue(b,v){var s=text(v);if(kolTur(b)==='tutar'&&s&&isFinite(sayiCoz(s)))return sayiCoz(s).toFixed(2);if(kolTur(b)==='tarih')s=text(excelTarih(s));return norm(s);}
  function key(r){
    var code=text(r.islemAdi),id=vkn(r.vkn),vd=office(r.vd||(document.getElementById('vd')||{}).value);
    if(!code||code==='??'||!id||!vd||/^0+$/.test(id)||/^0+$/.test(vd)||!/^\d{10,11}$/.test(id)||!/^\d{6}$/.test(vd))return '';
    var fields=r.basliklar.map(function(b,i){return [norm(b),stableValue(b,r.deger[i])];});
    var periods=fields.filter(function(x){return /donem/.test(x[0])&&!/onay|ceza|sure/.test(x[0])&&x[1];});
    if(/^BABS(?:D)?-/.test(code)){
      if(!periods.length)return '';
      return 'MD2:'+JSON.stringify([code,vd,id,periods.sort()]);
    }
    var ids=fields.filter(function(x){return /(?:fis|evrak|belge|rapor|tespit|karar|yoklama) (?:numarasi|no|numara|kodu)$/.test(x[0])&&x[1];});
    var others=fields.filter(function(x){return x[1]&&!/^(aciklama|sorumlu|bolum|islem durumu|liste ayi|is anahtari|sira|sira no|unvan|soyad ad unvan|ad soyad)$/.test(x[0])&&!/vergi kimlik|^vkn$|^tckn$|t c kimlik|vergi dairesi|kdv mukellefiyeti|kontrol|onay zamani|son guncelleme|^durum$/.test(x[0]);});
    var dimensions=fields.filter(function(x){return /(?:vergi|ceza|form|islem) (?:kodu|turu)$/.test(x[0])&&x[1];});
    var parts=ids.length?ids.concat(periods,dimensions):others;
    if(!parts.length||(!ids.length&&!periods.length&&parts.every(function(x){return /vkn|tckn|kimlik/.test(x[0]);})))return '';
    return 'MD2:'+JSON.stringify([code,vd,id,parts.sort(function(a,b){return a[0].localeCompare(b[0])||a[1].localeCompare(b[1]);})]);
  }
  function xml(s){var d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('Excel XML içeriği okunamadı.');return d;}
  function tags(d,n){return Array.from(d.getElementsByTagNameNS('*',n));}
  function allText(d){return tags(d,'t').map(function(t){return t.textContent;}).join('');}
  function colNo(s){return s.split('').reduce(function(n,c){return n*26+c.charCodeAt(0)-64;},0)-1;}
  async function readBook(file){
    if(!/\.xlsx$/i.test(file.name))throw Error('Dosyayı .xlsx biçiminde kaydedin.');
    if(file.size>25*1024*1024)throw Error('Dosya 25 MB sınırını aşıyor.');
    var z=await JSZip.loadAsync(await file.arrayBuffer()),total=0;
    async function part(path,optional){var f=z.file(path);if(!f){if(optional)return '';throw Error('Eksik Excel parçası: '+path);}var s=await f.async('string');total+=s.length;if(total>100*1024*1024)throw Error('Açılmış dosya boyutu sınırı aşıldı.');return s;}
    var shared=await part('xl/sharedStrings.xml',true),ss=shared?tags(xml(shared),'si').map(allText):[];
    var wb=xml(await part('xl/workbook.xml')),rels=tags(xml(await part('xl/_rels/workbook.xml.rels')),'Relationship'),map={};
    rels.forEach(function(r){if(r.getAttribute('TargetMode')==='External')return;var t=r.getAttribute('Target')||'';var p=t[0]==='/'?t.slice(1):'xl/'+t;var a=[];p.split('/').forEach(function(x){if(x==='..')a.pop();else if(x&&x!=='.')a.push(x);});p=a.join('/');if(p.startsWith('xl/worksheets/'))map[r.getAttribute('Id')]=p;});
    var result=[];
    for(var sheet of tags(wb,'sheet')){
      var rid=sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id')||sheet.getAttribute('r:id');if(!map[rid])continue;
      var rows=tags(xml(await part(map[rid])),'row');if(rows.length>100000)throw Error('Bir sayfada en fazla 100.000 satır okunabilir.');
      var header=null,found=false;
      rows.forEach(function(row){var vals=[];tags(row,'c').forEach(function(c){var ref=/^([A-Z]+)\d+$/.exec(c.getAttribute('r')||'');if(!ref)return;var vv=tags(c,'v')[0],t=c.getAttribute('t'),v=t==='s'?(ss[vv?+vv.textContent:0]||''):t==='inlineStr'?allText(c):(vv?vv.textContent:'');vals[colNo(ref[1])]=text(v);});
        var names=vals.map(norm);if(names.includes('rapor')&&names.includes('aciklama')&&names.includes('sorumlu')){header=vals;found=true;return;}
        if(!header)return;
        var m={},mi={};header.forEach(function(h,i){var n=norm(h);if(mi[n]===undefined){m[n]=vals[i]||'';mi[n]=i;}});
        var code=text(m.rapor);if(!/^(?:\d{2}\.\d{2}|BABSD?-\d{4}(?:-?\d{2})?)$/.test(code))return;
        var meta=H.map(norm),bs=[],data=[];header.forEach(function(h,i){if(h&&(!meta.includes(norm(h))||mi[norm(h)]!==i)){bs.push(h);data.push(vals[i]||'');}});
        var vi=bs.findIndex(function(b){return /vergi kimlik/.test(norm(b))&&!/gecerli/.test(norm(b));});if(vi<0)vi=bs.findIndex(function(b){return /^(vkn|vergi no)$/.test(norm(b));});
        if(vi<0){issues.push(file.name+' / '+sheet.getAttribute('name')+': VKN sütunu bulunamadı.');return;}
        var r={islemAdi:code,basliklar:bs,deger:data,vkn:data[vi],vd:m['vergi dairesi']||ayVd(),sorumlu:m.sorumlu,bolum:m.bolum};
        var derived=key(r),given=text(m['is anahtari']);
        if(given&&given!==derived){issues.push(file.name+' / '+sheet.getAttribute('name')+' satır '+row.getAttribute('r')+': İş anahtarı ile iş bilgileri uyuşmuyor; aktarılmadı.');return;}
        var k=given||derived;if(!k){issues.push(file.name+': Güvenilir iş kimliği oluşturulamayan satır aktarılmadı.');return;}
        var mo=text(m['liste ayi'])||ay('mdEskiAy');if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(mo)){issues.push(file.name+': Liste ayı geçersiz; satır aktarılmadı.');return;}
        var st=status(m['islem durumu']);if(!st){issues.push(file.name+': Tanınmayan işlem durumu; satır aktarılmadı.');return;}
        var completedMonth=st==='Tamamlandı'?mo:'',feedbackMonth=mo,feedbackOwner=text(m.sorumlu)||'(sorumlu yok)',feedbackDept=text(m.bolum),base;
        try{base=JSON.parse(m['onceki geri bildirim']||'null');}catch(e){issues.push(file.name+': Önceki geri bildirim bilgisi okunamadı; satır aktarılmadı.');return;}
        if(base){if(typeof base.note!=='string'||typeof base.status!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(base.month||'')||typeof base.owner!=='string'||typeof base.dept!=='string'){issues.push(file.name+': Önceki geri bildirim bilgisi geçersiz; satır aktarılmadı.');return;}if(st==='Tamamlandı'&&base.status==='Tamamlandı')completedMonth=base.completedMonth||base.month;if(text(m.aciklama)===base.note&&st===base.status){feedbackMonth=base.month;feedbackOwner=base.owner;feedbackDept=base.dept;}}
        result.push({completedMonth:completedMonth,feedbackMonth:feedbackMonth,feedbackOwner:feedbackOwner,feedbackDept:feedbackDept,key:k,month:mo,code:code,owner:text(m.sorumlu)||'(sorumlu yok)',dept:text(m.bolum),note:text(m.aciklama),status:st,file:file.name,sheet:sheet.getAttribute('name'),row:row.getAttribute('r'),legacy:!given});
      });
      if(found)result.found=true;
    }
    if(!result.found)throw Error('Rapor / Açıklama / Sorumlu başlıkları olan iş sayfası bulunamadı.');
    return result;
  }
  function ayVd(){return office((document.getElementById('vd')||{}).value);}
  function signature(r){return JSON.stringify([r.owner,r.dept,r.note,r.status,r.feedbackMonth,r.feedbackOwner,r.feedbackDept,r.completedMonth]);}
  function meaningful(r){return !!r.note||r.status!=='Bekliyor';}
  function rebuild(){
    var m=new Map();records.forEach(function(r){var k=r.month+'|'+r.key;if(!m.has(k))m.set(k,[]);var a=m.get(k);if(!a.some(function(x){return signature(x)===signature(r);}))a.push(r);});
    groups=Array.from(m,function(x){var list=x[1],filled=list.filter(meaningful),pool=filled.length?filled:list;var owners=new Set(list.map(function(r){return r.owner+'|'+r.dept;}));if(owners.size>1)pool=list;
      var g={id:x[0],variants:pool,conflict:pool.length>1};if(!g.conflict)g.value=pool[0];else if(choices[g.id]!==undefined)g.value=pool.find(function(v){return signature(v)===choices[g.id];});return g;});
    currentIndex=new Map();groups.forEach(function(g){if(g.value&&g.value.month===ay('mdEskiAy'))currentIndex.set(g.value.key,g.value);});
  }
  function apply(){
    var counts=new Map();IC.forEach(function(r){var k=key(r);if(k)counts.set(k,(counts.get(k)||0)+1);});
    var stats={matched:0,noted:0,ambiguous:0};
    IC.forEach(function(r){var k=key(r),old=currentIndex.get(k);
      if(r._mdAuto){if(text(r.aciklama)===r._mdAuto.note&&status(r.islemDurumu)===r._mdAuto.status){r.aciklama='';r.islemDurumu='Bekliyor';}delete r._mdAuto;}
      if(!old)return;if(counts.get(k)!==1){stats.ambiguous++;return;}
      if((text(r.aciklama)&&text(r.aciklama)!==old.note)||(r.islemDurumu&&status(r.islemDurumu)!=='Bekliyor'&&status(r.islemDurumu)!==old.status)){stats.ambiguous++;return;}
      r.aciklama=old.note;r.islemDurumu=old.status;r._mdAuto={note:old.note,status:old.status,month:old.feedbackMonth||old.month,completedMonth:old.completedMonth||'',owner:old.feedbackOwner||old.owner,dept:old.feedbackDept||old.dept};r.geriBildirimKaynak=old.file;stats.matched++;if(old.note)stats.noted++;
    });return stats;
  }
  function summary(){
    var seen=new Set(),codes=new Set(IC.map(function(r){return r.islemAdi;})),keys=new Set(IC.map(key)),out=new Map();
    groups.forEach(function(g){var r=g.value;if(!r||r.month!==ay('mdEskiAy'))return;var unique=r.month+'|'+r.key;if(seen.has(unique))return;seen.add(unique);
      var k=JSON.stringify([r.month,r.owner,r.dept,r.code]);if(!out.has(k))out.set(k,{month:r.month,owner:r.owner,dept:r.dept,code:r.code,total:0,notes:0,done:0,progress:0,pending:0,noFeedback:0,workedThisMonth:0,doneThisMonth:0,still:0,missing:0,unchecked:0});var s=out.get(k);s.total++;if(r.note)s.notes++;if(r.status==='Tamamlandı')s.done++;else if(r.status==='Devam Ediyor')s.progress++;else s.pending++;if(!meaningful(r))s.noFeedback++;if(meaningful(r)&&(r.feedbackMonth||r.month)===r.month)s.workedThisMonth++;if(r.status==='Tamamlandı'&&(r.completedMonth||r.feedbackMonth||r.month)===r.month)s.doneThisMonth++;
      if(!codes.has(r.code))s.unchecked++;else if(keys.has(r.key))s.still++;else s.missing++;
    });return Array.from(out.values()).sort(function(a,b){return a.dept.localeCompare(b.dept,'tr')||a.owner.localeCompare(b.owner,'tr')||a.code.localeCompare(b.code);});
  }
  var SH=['Liste Ayı','Sorumlu','Bölüm','Rapor','Rapor Adı','Toplam İş','Açıklaması Var','Bu Ay Geri Bildirim','Bu Ay Tamamlanan','Tamamlandı (Durum)','Devam Ediyor','Bekliyor / Yapılmadı','Geri Bildirim Yok','Yeni Listede Devam Eden','Yeni Listede Görülmeyen','Karşılaştırılmadı'];
  function reportName(code){return RAPOR_ADLARI[code]||(/^BABSD?-/.test(code)?'Form BA/BS '+code.replace(/^BABS(D)?-/,function(m,d){return d?'düzeltme ':'';}):code);}
  function sr(s){return [s.month,s.owner,s.dept,s.code,reportName(s.code),s.total,s.notes,s.workedThisMonth,s.doneThisMonth,s.done,s.progress,s.pending,s.noFeedback,s.still,s.missing,s.unchecked];}
  function render(applied){
    var box=document.getElementById('mdGeriSonuc');if(!box)return;var st=applied||apply(),a=summary(),conf=groups.filter(function(g){return g.conflict&&!g.value;}),h='<p>'+records.length+' okunan satır · '+groups.length+' tekil aylık iş · '+st.matched+' eşleşen iş · '+st.noted+' açıklama aktarıldı · '+conf.length+' çözülmemiş çakışma · '+st.ambiguous+' belirsiz/mevcut geri bildirimi farklı iş.</p>';
    var months=Array.from(new Set(records.map(function(r){return r.month;}))).sort();if(months.length)h+='<p>Dosyalardaki liste ayları: '+esc(months.join(', '))+' · Seçili ay: '+esc(ay('mdEskiAy'))+'</p>';
    if(a.length)h+='<div style="overflow:auto"><table><thead><tr>'+SH.map(function(x){return '<th>'+esc(x)+'</th>';}).join('')+'</tr></thead><tbody>'+a.map(function(s){return '<tr>'+sr(s).map(function(v){return '<td>'+esc(v)+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';
    var cg=groups.filter(function(g){return g.conflict;});if(cg.length){h+='<details><summary>'+cg.length+' çakışan iş — kullanılacak geri bildirimi seçin</summary>';cg.forEach(function(g,i){h+='<p>'+esc(g.variants[0].code+' · '+g.variants[0].month)+' <select data-md-conf="'+groups.indexOf(g)+'"><option value="">— aktarılmasın —</option>'+g.variants.map(function(v,j){return '<option value="'+j+'"'+(g.value===v?' selected':'')+'>'+esc(v.file+' / '+v.owner+' / '+v.status+' / '+v.note)+'</option>';}).join('')+'</select></p>';});h+='</details>';}
    var currentKeys=new Set(IC.map(key));var unmatched=groups.filter(function(g){return g.value&&g.value.month===ay('mdEskiAy')&&meaningful(g.value)&&!currentKeys.has(g.value.key);});if(unmatched.length)h+='<details><summary>'+unmatched.length+' geri bildirimli iş yeni listede eşleşmedi (ilk 100)</summary><ul>'+unmatched.slice(0,100).map(function(g){var r=g.value;return '<li>'+esc(r.code+' / '+r.owner+' / '+r.file+' / '+r.note)+'</li>';}).join('')+'</ul></details>';
    if(issues.length)h+='<details><summary>'+issues.length+' okuma/eşleştirme uyarısı</summary><ul>'+issues.map(function(s){return '<li>'+esc(s)+'</li>';}).join('')+'</ul></details>';
    box.innerHTML=h;box.querySelectorAll('[data-md-conf]').forEach(function(el){el.onchange=function(){var g=groups[+el.getAttribute('data-md-conf')];if(el.value==='')delete choices[g.id];else choices[g.id]=signature(g.variants[+el.value]);rebuild();icCiz();};});
  }
  function feedbackCell(r){var src=r._mdAuto?('Geri bildirim: '+r._mdAuto.owner+' / '+r._mdAuto.month+' / '+(r.geriBildirimKaynak||'')):'';return '<td title="'+esc(src)+'" style="min-width:220px;white-space:pre-wrap">'+esc(r.aciklama||'')+'</td><td style="white-space:nowrap">'+esc(r.islemDurumu||'Bekliyor')+'</td>';}
  function baseline(r){var a=r._mdAuto;if(!a||!meaningful({note:a.note,status:a.status}))return '';return JSON.stringify(a);}
  function detailRows(g){var rows=[R([(RAPOR_ADLARI[g.islemAdi]||g.islemAdi)+' · '+g.rows.length+' iş'],'baslik'),R(H.concat(g.bas),'hdr')];
    g.rows.forEach(function(r){rows.push(R([r.islemAdi,r.aciklama||'',r.islemDurumu||'Bekliyor',r.sorumlu||'',r.bolum||'',ay('mdYeniAy'),office(r.vd||ayVd()),key(r),baseline(r)].concat(r.deger.map(function(v,j){return kolTur(g.bas[j])==='tarih'?excelTarih(v):v;}))));});rows._hideCols=[6,7,8];rows._statusCol=2;return rows;}
  function addPersonSheets(l,sheets,summaryRows){var persons=new Map();l.forEach(function(r){var k=(r.sorumlu||'Sorumlu yok')+'|'+(r.bolum||'');if(!persons.has(k))persons.set(k,[]);persons.get(k).push(r);});
    summaryRows.push(R([]),R(['Kişi bazlı özet'],'baslik'),R(['Sorumlu','Bölüm','Satır','Tekil VKN'],'hdr'));
    Array.from(persons).sort(function(a,b){return a[0].localeCompare(b[0],'tr');}).forEach(function(entry){var list=entry[1],r=list[0],rows=[];gruplaRows(list).forEach(function(g){rows=rows.concat(detailRows(g));});rows._hideCols=[6,7,8];rows._statusCol=2;var sheet={ad:r.sorumlu||'Sorumlu yok',rows:rows},s=R([r.sorumlu||'Sorumlu yok',r.bolum||'',list.length,new Set(list.map(function(x){return x.vkn;}).filter(Boolean)).size]);s._links={0:{sheet:sheet,row:1}};summaryRows.push(s);sheets.push(sheet);});}
  function exportCurrent(personFirst){
    var l=icGorunen();if(!l.length){alert('Satır yok.');return;}if(!/^\d{4}-\d{2}$/.test(ay('mdYeniAy'))){alert('Yeni liste ayını seçin.');return;}
    var departments=Array.from(new Set(l.map(function(r){return r.bolum||'Bölümsüz';}))).sort();
    var oz=[R(['Merkezi Denetim · '+ay('mdYeniAy')+' · '+l.length+' iş'],'baslik'),R(['Rapor','Rapor Adı','Tarih','Satır','Tekil VKN'].concat(departments.flatMap(function(b){return [b+' – satır',b+' – tekil VKN'];})),'hdr')],reports=[],sheets=[{ad:'Özet',rows:oz}];
    gruplaRows(l).forEach(function(g){var sheet={ad:sayfaAdi(g),rows:detailRows(g)},r=R([g.islemAdi,RAPOR_ADLARI[g.islemAdi]||g.islemAdi,g.kaynak.split(' · ')[1]||'',g.rows.length,new Set(g.rows.map(function(x){return x.vkn;}).filter(Boolean)).size]);departments.forEach(function(b){var list=g.rows.filter(function(x){return (x.bolum||'Bölümsüz')===b;});r.push(list.length,new Set(list.map(function(x){return x.vkn;}).filter(Boolean)).size);});r._links={0:{sheet:sheet,row:1},1:{sheet:sheet,row:1},3:{sheet:sheet,row:1}};oz.push(r);reports.push(sheet);});
    var total=R(['Toplam','','',l.length,new Set(l.map(function(r){return r.vkn;}).filter(Boolean)).size]);departments.forEach(function(b){var list=l.filter(function(r){return (r.bolum||'Bölümsüz')===b;});total.push(list.length,new Set(list.map(function(r){return r.vkn;}).filter(Boolean)).size);});oz.push(total);
    var person=[];addPersonSheets(l,person,oz);sheets=sheets.concat(personFirst?person.concat(reports):reports.concat(person));
    var a=summary();if(a.length){oz.push(R([]),R(['Önceki ay çalışma özeti · yüklenen dosyalara göre'],'baslik'),R(SH,'hdr'));a.forEach(function(s){oz.push(R(sr(s)));});}
    return excelYaz(sheets,personFirst?'merkezi_denetim_kisi_bazli.xlsx':'merkezi_denetim_rapor.xlsx');
  }
  async function importFiles(files){
    if(busy)return;busy=true;document.getElementById('mdGeriDosya').disabled=true;var added=0;
    try{if(files.length>100)throw Error('Tek seferde en fazla 100 dosya yükleyin.');for(var f of files){document.getElementById('mdGeriDurum').textContent=f.name+' okunuyor…';try{var rows=await readBook(f);records=records.concat(rows);added+=rows.length;}catch(e){issues.push(f.name+': '+e.message);}}
      rebuild();icCiz();document.getElementById('mdGeriDurum').textContent=files.length+' dosyadan '+added+' satır okundu. Veriler bu ekranda tutulur; sayfa kapanınca dosyaları yeniden yükleyin.';
    }catch(e){document.getElementById('mdGeriDurum').textContent=e.message;}finally{busy=false;document.getElementById('mdGeriDosya').disabled=false;}
  }
  function init(){
    var now=new Date(),prev=new Date(now.getFullYear(),now.getMonth()-1,1),box=document.createElement('div');box.className='kutu';box.id='mdGeriKutu';
    box.innerHTML='<b>Önceki listelerden geri bildirim aktar</b><p>Yeni listeyi yükleyip dağıttıktan sonra kullanıcıların doldurduğu .xlsx dosyalarını birlikte seçin. Aynı işin açıklaması ve işlem durumu taşınır; yeni dağıtım korunur.</p><label>Eski liste / istatistik ayı</label> <input type="month" id="mdEskiAy" value="'+month(prev)+'"> <label>Yeni liste ayı</label> <input type="month" id="mdYeniAy" value="'+month(now)+'"><p><input type="file" id="mdGeriDosya" accept=".xlsx" multiple> <button class="btn" id="mdGeriTemizle">Yüklenen geri bildirimleri temizle</button> <button class="btn" id="mdGeriExcel">Aylık çalışma özetini indir</button></p><p class="mut">Eski dosyalarda vergi dairesi bilgisi yoksa ekranda seçili daire kullanılır. Eski dosyada liste ayı yoksa seçtiğiniz eski ay kullanılır. Kullanıcılar Açıklama ve İşlem Durumu (Bekliyor / Devam Ediyor / Tamamlandı) alanlarını doldurur. Yalnız açıklama yazılması tamamlanma sayılmaz. Yeni listede görülmeyen iş, tamamlanmış kabul edilmez; süzgeçler ve yüklenen raporlar sonucu etkiler. Aynen taşınan önceki geri bildirim yeni ayın çalışmasına eklenmez; açıklama veya durum değişirse o aya yazılır. Özet yalnız yüklenen kullanıcı dosyalarını kapsar.</p><div id="mdGeriDurum" role="status"></div><div id="mdGeriSonuc"></div>';
    document.getElementById('icerikKutu').before(box);
    document.getElementById('mdGeriDosya').onchange=function(){var files=Array.from(this.files);this.value='';importFiles(files);};
    document.getElementById('mdEskiAy').onchange=function(){rebuild();icCiz();};
    document.getElementById('mdGeriTemizle').onclick=function(){records=[];groups=[];choices=Object.create(null);issues=[];rebuild();icCiz();document.getElementById('mdGeriDurum').textContent='Yüklenen geri bildirimler temizlendi.';};
    document.getElementById('mdGeriExcel').onclick=function(){var a=summary();if(!a.length){alert('Seçili ay için önce kullanıcı dosyalarını yükleyin.');return;}excelYaz([{ad:'Aylık Çalışma Özeti',rows:[R(SH,'hdr')].concat(a.map(function(s){return R(sr(s));}))}],'merkezi_denetim_aylik_calisma.xlsx');};
    var oldDraw=icCiz;icCiz=function(){var applied=apply();oldDraw();render(applied);};
    icExcel=function(){return exportCurrent(false);};icExcelKisi=function(){return exportCurrent(true);};document.getElementById('icExcel').onclick=icExcel;document.getElementById('icExcelKisi').onclick=icExcelKisi;
    render();
  }
  window.MdGeriBildirim={key:key,readBook:readBook,importFiles:importFiles,summary:summary,hucre:feedbackCell,detailRows:detailRows,status:status};
  init();
})();
