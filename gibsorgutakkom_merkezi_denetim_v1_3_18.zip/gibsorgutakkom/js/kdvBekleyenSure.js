/* Takvim günü esaslı bekleme kontrolü. Rapor tarihi bekleme başlangıcı sayılmaz. */
(function(){'use strict';
var GUN=86400000;
function tarih(v){var s=String(v==null?'':v).trim(),m,y,a,g;
 if((m=/^(\d{4})[-/.](\d{2})[-/.](\d{2})(?:[ T].*)?$/.exec(s))){y=+m[1];a=+m[2];g=+m[3];}
 else if((m=/^(\d{2})[-/.](\d{2})[-/.](\d{4})(?:[ T].*)?$/.exec(s))){y=+m[3];a=+m[2];g=+m[1];}
 else if((m=/^(\d{4})(\d{2})(\d{2})(?:\d{6})?$/.exec(s))){y=+m[1];a=+m[2];g=+m[3];}else return null;
 var n=Date.UTC(y,a-1,g),d=new Date(n);return y>=1900&&y<=2199&&d.getUTCFullYear()===y&&d.getUTCMonth()===a-1&&d.getUTCDate()===g?n:null;
}
function iso(n){return new Date(n).toISOString().slice(0,10);}
function yaz(n){return n==null?'':iso(n).slice(8,10)+'/'+iso(n).slice(5,7)+'/'+iso(n).slice(0,4);}
function bugun(){var ps=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()),o={};ps.forEach(function(p){o[p.type]=p.value;});return o.year+'-'+o.month+'-'+o.day;}
function esik(o){var ref=tarih(o.referans);if(ref==null)throw Error('Geçerli kontrol tarihi seçin.');var kes;
 if(o.tur==='oncekiAy'){var d=new Date(ref);kes=Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),0);}
 else if(o.tur==='tarih'){kes=tarih(o.sinir);if(kes==null||kes>ref)throw Error('Sınır tarihi kontrol tarihinden sonra olamaz.');}
 else {var n=o.tur==='ozel'?Number(o.gun):Number(o.tur);if(!Number.isInteger(n)||n<1||n>36500)throw Error('Gün sayısı 1–36500 arasında tam sayı olmalı.');kes=ref-n*GUN;}
 return {referans:ref,sinir:kes};
}
function vdde(e){return /^(N10|N15|N20|N25|N16|C10|C15|C20|C25|C16|E10|E15|E20|E25|E16|I10|I15|I20|I25|I16|K10|KE1|KT1|KT2|K15|K11|K09|D10|DE1|DI1|DI2|D15|D11|V01|V10|V15|V20|V25|VE4|VE5|V03|T10|TE1|TI1|TI2|T20|T21|T15|T11|T32|T09)$/.test(e.job.akis);}
var ALAN={lastUpdateOptime:'Son güncelleme',akisOptime:'Son akış işlemi',bilgilendirmeTarihi:'VD’ye bilgilendirme',vdGelisTarihi:'VD geliş tarihi',createOptime:'Oluşturulma'};
function alanOku(r,fields,son){
 var aday=[];for(var i=0;i<fields.length;i++){var v=r[fields[i]];if(v!=null&&String(v).trim()!==''){var x={tarih:tarih(v),kaynak:ALAN[fields[i]],ham:String(v)};if(x.tarih==null)return x;aday.push(x);}}
 if(aday.length)return son?aday.reduce(function(a,b){return b.tarih>a.tarih?b:a;}):aday[0];
 return null;
}
function esas(e,tip){var r=e.row.raw,x;
 if(tip==='auto'){
  // Kullanma tespitindeki vdGelisTarihi ana rapora aittir. Tespitin kendi
  // bilgilendirme tarihi yoksa ana raporun tarihine geri dönme.
  var tespit=/^(kt|vdkt|vk)$/.test(e.job.k||'')||!!(e.L&&e.L.kol.some(function(c){return c[1]==='bilgilendirmeTarihi';}));
  x=alanOku(r,tespit?['bilgilendirmeTarihi']:['vdGelisTarihi']);
  if(!x)x=alanOku(r,['akisOptime','lastUpdateOptime'],true);
  if(!x)x=alanOku(r,['createOptime']);
  return x||{tarih:null,kaynak:'',ham:''};
 }
 var fields=tip==='gelis'?['bilgilendirmeTarihi','vdGelisTarihi']:tip==='olus'?['createOptime']:['akisOptime','lastUpdateOptime'];
 return alanOku(r,fields,tip==='son')||{tarih:null,kaynak:'',ham:''};
}
function mevcut(e){var r=e.row.raw;return Object.keys(ALAN).map(function(k){var t=tarih(r[k]);return t==null?'':ALAN[k]+': '+yaz(t);}).filter(Boolean).join(' · ');}

function incele(entries,o){var k=esik(o),uygun=[],belirsiz=[],kapsamDisi=0;
 entries.forEach(function(e){if(o.vd!==false&&!vdde(e)){kapsamDisi++;return;}var x=esas(e,o.esas);if(x.tarih==null||x.tarih>k.referans){belirsiz.push(Object.assign({},e,{sure:{tarih:x.tarih,kaynak:x.kaynak,gun:null,neden:x.tarih>k.referans?'Esas tarih kontrol tarihinden sonra':x.ham?'Esas tarih geçersiz ('+x.kaynak+')':o.esas==='auto'?'Kullanılabilir işlem tarihi yok':'Seçili tarih alanı boş',mevcut:mevcut(e)}}));return;}
 if(x.tarih<=k.sinir)uygun.push(Object.assign({},e,{sure:{tarih:x.tarih,kaynak:x.kaynak,gun:Math.round((k.referans-x.tarih)/GUN)}}));});
 uygun.sort(function(a,b){return b.sure.gun-a.sure.gun;});return {uygun:uygun,belirsiz:belirsiz,kapsamDisi:kapsamDisi,sinir:k.sinir,referans:k.referans};
}
window.bekleyenSure={tarih:tarih,yaz:yaz,bugun:bugun,esik:esik,incele:incele,vdde:vdde};
})();
