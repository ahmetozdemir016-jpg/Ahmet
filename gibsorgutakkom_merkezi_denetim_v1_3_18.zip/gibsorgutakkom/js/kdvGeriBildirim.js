(function(){
  'use strict';
  var H=['Rapor','Açıklama (Geri Bildirim)','İşlem Durumu','Sorumlu','Bölüm','Liste Ayı','Liste Vergi Dairesi','İş Anahtarı','Önceki Geri Bildirim','İş Türü','Kayıt Kimliği'];
  var records=[],groups=[],choices=Object.create(null),currentIndex=new Map(),issues=[],busy=false;
  function text(v){return String(v==null?'':v).trim();}
  function norm(v){return trN(text(v)).replace(/[^a-z0-9]+/g,' ').trim();}
  function month(d){return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2);}
  function office(v){var s=text(v).replace(/\D/g,'');return s&&s.length<=6?s.padStart(6,'0'):s;}
  function vkn(v){var s=text(v).replace(/\D/g,'');return s&&s.length<=10?s.padStart(10,'0'):s;}
  function status(v){var n=norm(v);if(!n||/^(bekliyor|yapilmadi|islem yapilmadi)$/.test(n))return 'Bekliyor';if(/^(tamamlandi|yapildi|bitti)$/.test(n))return 'Tamamlandı';if(/^(devam ediyor|devam|islemde)$/.test(n))return 'Devam Ediyor';return '';}
  function ay(id){return document.getElementById(id).value;}
  function key(r){
    var vd=office(r.vd||ayVd()),id=vkn(r.vkn),type=text(r.recordType),rid=text(r.recordId);
    if(!/^\d{6}$/.test(vd)||/^0+$/.test(vd)||!/^\d{10}$/.test(id)||/^0+$/.test(id)||!type||!rid||/^(undefined|null)$/.test(rid))return '';
    return 'OE2:'+JSON.stringify([vd,type,id,rid]);
  }
  function xml(s){var d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('Excel XML içeriği okunamadı.');return d;}
  function tags(d,n){return Array.from(d.getElementsByTagNameNS('*',n));}
  function allText(d){return tags(d,'t').map(function(t){return t.textContent;}).join('');}
  function colNo(s){return s.split('').reduce(function(n,c){return n*26+c.charCodeAt(0)-64;},0)-1;}
  async function readBook(file){
    if(!/\.xlsx$/i.test(file.name))throw Error('Dosyayı .xlsx biçiminde kaydedin.');
    if(file.size>25*1024*1024)throw Error('Dosya 25 MB sınırını aşıyor.');
    var z=await JSZip.loadAsync(await file.arrayBuffer()),total=0;
    async function part(path,optional){var f=z.file(path);if(!f){if(optional)return '';throw Error('Eksik Excel parçası: '+path);}var s=await f.async('string');total+=s.length;if(total>100*1024*1024)throw Error('Açılmış dosya boyutu sınırı aşıldı.');return s;}
    var shared=await part('xl/sharedStrings.xml',true),ss=shared?tags(xml(shared),'si').map(allText):[];
    var wb=xml(await part('xl/workbook.xml')),rels=tags(xml(await part('xl/_rels/workbook.xml.rels')),'Relationship'),map={};
    rels.forEach(function(r){if(r.getAttribute('TargetMode')==='External')return;var t=r.getAttribute('Target')||'';var p=t[0]==='/'?t.slice(1):'xl/'+t;var a=[];p.split('/').forEach(function(x){if(x==='..')a.pop();else if(x&&x!=='.')a.push(x);});p=a.join('/');if(p.startsWith('xl/worksheets/'))map[r.getAttribute('Id')]=p;});
    var result=[];
    for(var sheet of tags(wb,'sheet')){
      var rid=sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id')||sheet.getAttribute('r:id');if(!map[rid])continue;
      var rows=tags(xml(await part(map[rid])),'row');if(rows.length>100000)throw Error('Bir sayfada en fazla 100.000 satır okunabilir.');
      var header=null,found=false,legacy=false,legacySeen=false;
      rows.forEach(function(row){var vals=[];tags(row,'c').forEach(function(c){var ref=/^([A-Z]+)\d+$/.exec(c.getAttribute('r')||'');if(!ref)return;var vv=tags(c,'v')[0],t=c.getAttribute('t'),v=t==='s'?(ss[vv?+vv.textContent:0]||''):t==='inlineStr'?allText(c):(vv?vv.textContent:'');vals[colNo(ref[1])]=text(v);});
        var names=vals.map(norm);if(names.includes('rapor')&&names.includes('aciklama geri bildirim')&&names.includes('sorumlu')){header=vals;found=true;legacy=false;return;}if(names.includes('is basligi')&&names.includes('sorumlu')&&names.includes('vkn')&&names.includes('aciklama')){legacySeen=true;if(document.getElementById('oeEskiBicim').checked){header=vals;found=true;legacy=true;}return;}
        if(!header)return;
        var m={},mi={};header.forEach(function(h,i){var n=norm(h);if(mi[n]===undefined){m[n]=vals[i]||'';mi[n]=i;}});
        var legacyModel;if(legacy){var matches=legacyMatch(header,vals,m);if(matches.length!==1){issues.push(file.name+' / '+sheet.getAttribute('name')+' satır '+row.getAttribute('r')+': Eski iş tek bir kayıtla eşleşmedi; aktarılmadı.');return;}legacyModel=matches[0];m.rapor=legacyModel.islemAdi;m['is turu']=legacyModel.recordType;m['kayit kimligi']=text(legacyModel.recordId);m['liste vergi dairesi']=legacyModel.vd;m['aciklama geri bildirim']=m.aciklama;}
        var code=text(m.rapor);if(!/^OE:[a-zA-Z0-9_-]+:.+$/.test(code))return;
        var meta=H.map(norm),bs=[],data=[];header.forEach(function(h,i){if(h&&(!meta.includes(norm(h))||mi[norm(h)]!==i)){bs.push(h);data.push(vals[i]||'');}});
        var vi=bs.findIndex(function(b){return /vergi kimlik/.test(norm(b))&&!/gecerli/.test(norm(b));});if(vi<0)vi=bs.findIndex(function(b){return /^(vkn|vergi no)$/.test(norm(b));});
        if(vi<0){issues.push(file.name+' / '+sheet.getAttribute('name')+': VKN sütunu bulunamadı.');return;}
        var r={islemAdi:code,basliklar:bs,deger:data,vkn:data[vi],vd:m['liste vergi dairesi']||ayVd(),sorumlu:m.sorumlu,bolum:m.bolum,recordType:m['is turu'],recordId:m['kayit kimligi']};namesByCode[code]=m['is basligi']||namesByCode[code]||code;
        if(legacyModel)r.vkn=legacyModel.vkn;var derived=key(r),given=text(m['is anahtari']);
        if(given&&given!==derived){issues.push(file.name+' / '+sheet.getAttribute('name')+' satır '+row.getAttribute('r')+': İş anahtarı ile iş bilgileri uyuşmuyor; aktarılmadı.');return;}
        var k=given||derived;if(!k){issues.push(file.name+': Güvenilir iş kimliği oluşturulamayan satır aktarılmadı.');return;}
        var mo=text(m['liste ayi'])||ay('oeEskiAy');if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(mo)){issues.push(file.name+': Liste ayı geçersiz; satır aktarılmadı.');return;}
        var st=status(m['islem durumu']);if(!st){issues.push(file.name+': Tanınmayan işlem durumu; satır aktarılmadı.');return;}
        var completedMonth=st==='Tamamlandı'?mo:'',feedbackMonth=mo,feedbackOwner=text(m.sorumlu)||'(sorumlu yok)',feedbackDept=text(m.bolum),base;
        try{base=JSON.parse(m['onceki geri bildirim']||'null');}catch(e){issues.push(file.name+': Önceki geri bildirim bilgisi okunamadı; satır aktarılmadı.');return;}
        if(base){if(typeof base.note!=='string'||typeof base.status!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(base.month||'')||typeof base.owner!=='string'||typeof base.dept!=='string'){issues.push(file.name+': Önceki geri bildirim bilgisi geçersiz; satır aktarılmadı.');return;}if(st==='Tamamlandı'&&base.status==='Tamamlandı')completedMonth=base.completedMonth||base.month;if(text(m['aciklama geri bildirim'])===base.note&&st===base.status){feedbackMonth=base.month;feedbackOwner=base.owner;feedbackDept=base.dept;}}
        result.push({completedMonth:completedMonth,feedbackMonth:feedbackMonth,feedbackOwner:feedbackOwner,feedbackDept:feedbackDept,key:k,month:mo,code:code,owner:text(m.sorumlu)||'(sorumlu yok)',dept:text(m.bolum),note:text(m['aciklama geri bildirim']),status:st,file:file.name,sheet:sheet.getAttribute('name'),row:row.getAttribute('r'),legacy:!given});
      });
      if(found)result.found=true;if(legacySeen)result.legacySeen=true;
    }
    if(!result.found&&result.legacySeen)throw Error('Eski dosyayı okumak için Eski dosyadaki Açıklama kullanıcı geri bildirimidir seçeneğini işaretleyin.');if(!result.found)throw Error('Geri bildirim ve kayıt kimliği alanları olan iş sayfası bulunamadı; güncel toplu Excel çıktısını kullanın.');
    return result;
  }
  function ayVd(){return office(document.getElementById('vdTx').textContent);}
  function signature(r){return JSON.stringify([r.owner,r.dept,r.note,r.status,r.feedbackMonth,r.feedbackOwner,r.feedbackDept,r.completedMonth]);}
  function meaningful(r){return !!r.note||r.status!=='Bekliyor';}
  function rebuild(){
    var m=new Map();records.forEach(function(r){var k=r.month+'|'+r.key;if(!m.has(k))m.set(k,[]);var a=m.get(k);if(!a.some(function(x){return signature(x)===signature(r);}))a.push(r);});
    groups=Array.from(m,function(x){var list=x[1],filled=list.filter(meaningful),pool=filled.length?filled:list;var owners=new Set(list.map(function(r){return r.owner+'|'+r.dept;}));if(owners.size>1)pool=list;
      var g={id:x[0],variants:pool,conflict:pool.length>1};if(!g.conflict)g.value=pool[0];else if(choices[g.id]!==undefined)g.value=pool.find(function(v){return signature(v)===choices[g.id];});return g;});
    currentIndex=new Map();groups.forEach(function(g){if(g.value&&g.value.month===ay('oeEskiAy'))currentIndex.set(g.value.key,g.value);});
  }
  function apply(){
    var counts=new Map();currentRows().forEach(function(r){var k=key(r);if(k)counts.set(k,(counts.get(k)||0)+1);});
    var stats={matched:0,noted:0,ambiguous:0};
    currentRows().forEach(function(r){var k=key(r),old=currentIndex.get(k);
      if(r._mdAuto){if(text(r.aciklama)===r._mdAuto.note&&status(r.islemDurumu)===r._mdAuto.status){r.aciklama='';r.islemDurumu='Bekliyor';}r._mdAuto=undefined;}
      if(!old)return;if(counts.get(k)!==1){stats.ambiguous++;return;}
      if((text(r.aciklama)&&text(r.aciklama)!==old.note)||(r.islemDurumu&&status(r.islemDurumu)!=='Bekliyor'&&status(r.islemDurumu)!==old.status)){stats.ambiguous++;return;}
      r.aciklama=old.note;r.islemDurumu=old.status;r._mdAuto={note:old.note,status:old.status,month:old.feedbackMonth||old.month,completedMonth:old.completedMonth||'',owner:old.feedbackOwner||old.owner,dept:old.feedbackDept||old.dept};r.geriBildirimKaynak=old.file;stats.matched++;if(old.note)stats.noted++;
    });return stats;
  }
  function summary(){
    var seen=new Set(),codes=new Set(api.loadedJobs().map(codeFor)),keys=new Set(currentRows().map(key)),out=new Map();
    groups.forEach(function(g){var r=g.value;if(!r||r.month!==ay('oeEskiAy'))return;var unique=r.month+'|'+r.key;if(seen.has(unique))return;seen.add(unique);
      var k=JSON.stringify([r.month,r.owner,r.dept,r.code]);if(!out.has(k))out.set(k,{month:r.month,owner:r.owner,dept:r.dept,code:r.code,total:0,notes:0,done:0,progress:0,pending:0,noFeedback:0,workedThisMonth:0,doneThisMonth:0,still:0,missing:0,unchecked:0});var s=out.get(k);s.total++;if(r.note)s.notes++;if(r.status==='Tamamlandı')s.done++;else if(r.status==='Devam Ediyor')s.progress++;else s.pending++;if(!meaningful(r))s.noFeedback++;if(meaningful(r)&&(r.feedbackMonth||r.month)===r.month)s.workedThisMonth++;if(r.status==='Tamamlandı'&&(r.completedMonth||r.feedbackMonth||r.month)===r.month)s.doneThisMonth++;
      if(keys.has(r.key))s.still++;else if(!codes.has(r.code))s.unchecked++;else s.missing++;
    });return Array.from(out.values()).sort(function(a,b){return a.dept.localeCompare(b.dept,'tr')||a.owner.localeCompare(b.owner,'tr')||a.code.localeCompare(b.code);});
  }
  var SH=['Liste Ayı','Sorumlu','Bölüm','İş başlığı','Toplam İş','Açıklaması Var','Bu Ay Geri Bildirim','Bu Ay Tamamlanan','Tamamlandı (Durum)','Devam Ediyor','Bekliyor / Yapılmadı','Geri Bildirim Yok','Yeni Listede Devam Eden','Yeni Listede Görülmeyen','Karşılaştırılmadı'];
  function reportName(code){return namesByCode[code]||code;}
  function sr(s){return [s.month,s.owner,s.dept,reportName(s.code),s.total,s.notes,s.workedThisMonth,s.doneThisMonth,s.done,s.progress,s.pending,s.noFeedback,s.still,s.missing,s.unchecked];}
  function render(applied){
    var box=document.getElementById('oeGeriSonuc');if(!box)return;var st=applied||apply(),a=summary(),conf=groups.filter(function(g){return g.conflict&&!g.value;}),h='<p>'+records.length+' okunan satır · '+groups.length+' tekil aylık iş · '+st.matched+' eşleşen iş · '+st.noted+' açıklama aktarıldı · '+conf.length+' çözülmemiş çakışma · '+st.ambiguous+' belirsiz/mevcut geri bildirimi farklı iş.</p>';
    var months=Array.from(new Set(records.map(function(r){return r.month;}))).sort();if(months.length)h+='<p>Dosyalardaki liste ayları: '+esc(months.join(', '))+' · Seçili ay: '+esc(ay('oeEskiAy'))+'</p>';
    if(a.length)h+='<div style="overflow:auto"><table><thead><tr>'+SH.map(function(x){return '<th>'+esc(x)+'</th>';}).join('')+'</tr></thead><tbody>'+a.map(function(s){return '<tr>'+sr(s).map(function(v){return '<td>'+esc(v)+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';
    var cg=groups.filter(function(g){return g.conflict;});if(cg.length){h+='<details><summary>'+cg.length+' çakışan iş — kullanılacak geri bildirimi seçin</summary>';cg.forEach(function(g,i){h+='<p>'+esc(reportName(g.variants[0].code)+' · '+g.variants[0].month)+' <select data-oe-conf="'+groups.indexOf(g)+'"><option value="">— aktarılmasın —</option>'+g.variants.map(function(v,j){return '<option value="'+j+'"'+(g.value===v?' selected':'')+'>'+esc(v.file+' / '+v.owner+' / '+v.status+' / '+v.note)+'</option>';}).join('')+'</select></p>';});h+='</details>';}
    var currentKeys=new Set(currentRows().map(key));var unmatched=groups.filter(function(g){return g.value&&g.value.month===ay('oeEskiAy')&&meaningful(g.value)&&!currentKeys.has(g.value.key);});if(unmatched.length)h+='<details><summary>'+unmatched.length+' geri bildirimli iş yeni listede eşleşmedi (ilk 100)</summary><ul>'+unmatched.slice(0,100).map(function(g){var r=g.value;return '<li>'+esc(reportName(r.code)+' / '+r.owner+' / '+r.file+' / '+r.note)+'</li>';}).join('')+'</ul></details>';
    if(issues.length)h+='<details><summary>'+issues.length+' okuma/eşleştirme uyarısı</summary><ul>'+issues.map(function(s){return '<li>'+esc(s)+'</li>';}).join('')+'</ul></details>';
    box.innerHTML=h;box.querySelectorAll('[data-oe-conf]').forEach(function(el){el.onchange=function(){var g=groups[+el.getAttribute('data-oe-conf')];if(el.value==='')delete choices[g.id];else choices[g.id]=signature(g.variants[+el.value]);rebuild();api.refresh();};});
  }
  function baseline(r){var a=r._mdAuto;if(!a||!meaningful({note:a.note,status:a.status}))return '';return JSON.stringify(a);}
  async function importFiles(files){
    if(busy)return;busy=true;document.getElementById('oeGeriDosya').disabled=true;var added=0;
    try{if(files.length>100)throw Error('Tek seferde en fazla 100 dosya yükleyin.');for(var f of files){document.getElementById('oeGeriDurum').textContent=f.name+' okunuyor…';try{var rows=await readBook(f);records=records.concat(rows);added+=rows.length;}catch(e){issues.push(f.name+': '+e.message);}}
      rebuild();api.refresh();document.getElementById('oeGeriDurum').textContent=files.length+' dosyadan '+added+' satır okundu. Veriler bu ekranda tutulur; sayfa kapanınca dosyaları yeniden yükleyin.';
    }catch(e){document.getElementById('oeGeriDurum').textContent=e.message;}finally{busy=false;document.getElementById('oeGeriDosya').disabled=false;}
  }
  function legacyMatch(header,vals,m){
    var id=vkn(m.vkn),label=text(m['is basligi']),ids=[];
    header.forEach(function(h,i){var n=norm(h),v=text(vals[i]);if(v&&/(?:form (?:no|numarasi)|(?:rapor|dayanak belge|giris olay|cikis olay) (?:no|numarasi))$/.test(n))ids.push([n,norm(v)]);});
    if(!id||!label||!ids.length)return [];
    var periods=[];header.forEach(function(h,i){var n=norm(h),v=text(vals[i]);if(v&&/(?:donem|donemi|yil)$/.test(n))periods.push([n,norm(v)]);});
    return currentRows().filter(function(r){if(r.vkn!==id||api.title(r.entry.job)!==label)return false;var pairs=api.columns(r.entry).map(function(p){return [norm(p[0]),norm(p[1])];});return ids.concat(periods).every(function(p){return pairs.some(function(q){return p[0]===q[0]&&p[1]===q[1];});});});
  }
  function trN(v){return String(v||'').replace(/İ/g,'I').replace(/ı/g,'i').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
  function R(a,st){a._s=st||'';return a;}
  var api=window.BekleyenIsAkisi,namesByCode=Object.create(null),models=new WeakMap(),lastStats=null;
  function codeFor(j){return 'OE:'+j.k+':'+j.id;}
  function currentRows(){return api.entries().map(function(e){
    var r=models.get(e.row);if(!r){r={};models.set(e.row,r);[['sorumlu','kisi'],['bolum','bolum'],['aciklama','geriAciklama'],['islemDurumu','geriIslemDurumu'],['_mdAuto','_geriAuto'],['geriBildirimKaynak','geriBildirimKaynak']].forEach(function(p){Object.defineProperty(r,p[0],{get:function(){return e.row[p[1]];},set:function(v){e.row[p[1]]=v;},configurable:true});});}
    r.islemAdi=codeFor(e.job);r.vkn=e.row.vkn;r.vd=ayVd();r.recordType=e.job.k;r.recordId=e.L.anahtar(e.row.raw);r.entry=e;namesByCode[r.islemAdi]=api.title(e.job);
    return r;
  });}
  function decorate(rows,entries){
    var list=currentRows(),by=new Map(list.map(function(r){return [r.entry.row,r];}));
    var meta=['Liste Ayı','Liste Vergi Dairesi','İş Anahtarı','Önceki Geri Bildirim','İş Türü','Kayıt Kimliği','Rapor'];
    var oldLength=rows[0].length;rows[0].splice(5,0,'Açıklama (Geri Bildirim)','İşlem Durumu');rows[0].push.apply(rows[0],meta);
    entries.forEach(function(e,i){var r=by.get(e.row);if(!r)return;rows[i+1].splice(5,0,r.aciklama||'',r.islemDurumu||'Bekliyor');rows[i+1].push(ay('oeYeniAy'),ayVd(),key(r),baseline(r),r.recordType,text(r.recordId),r.islemAdi);});
    rows._hideCols=Array.from({length:7},function(_,i){return oldLength+2+i;});rows._statusCol=6;
    if(rows._compactCount!=null)rows._compactCount+=2;
    if(rows._widths){rows._widths.splice(5,0,38,20);rows._widths.push(14,10,10,10,10,10,10);}
    return rows;
  }
  function appendSummary(rows){var a=summary();if(a.length){rows.push(R([]),R(['Önceki ay çalışma özeti — yüklenen dosyalara göre'],'baslik'),R(SH,'hdr'));a.forEach(function(x){rows.push(R(sr(x)));});}}
  function init(){
    var now=new Date(),prev=new Date(now.getFullYear(),now.getMonth()-1,1),box=document.createElement('details');box.className='kutu';box.id='oeGeriKutu';
    box.innerHTML='<summary>Önceki listelerden geri bildirim aktar ve aylık çalışmayı göster</summary><p>İşleri getirin ve dağıtın; kullanıcıların doldurduğu .xlsx dosyalarını birlikte seçin. Aynı kaydın geri bildirimi taşınır, yeni kişi/bölüm dağılımı korunur. Sistemin Açıklama alanı değişmez.</p><label>Eski liste / istatistik ayı <input type="month" id="oeEskiAy" value="'+month(prev)+'"></label> <label>Yeni liste ayı <input type="month" id="oeYeniAy" value="'+month(now)+'"></label><p><label><input type="checkbox" id="oeEskiBicim"> Eski dosyadaki Açıklama kullanıcı geri bildirimidir</label></p><p><input type="file" id="oeGeriDosya" accept=".xlsx" multiple> <button type="button" class="btn" id="oeGeriTemizle">Geri bildirimleri temizle</button> <button type="button" class="btn" id="oeGeriExcel">Aylık çalışma özetini indir</button></p><p class="mut">Kullanıcılar Açıklama (Geri Bildirim) ve İşlem Durumu alanlarını doldurur. Yalnız açıklama yazılması tamamlanma sayılmaz. Aynen taşınan geri bildirim yeni ayın çalışmasına eklenmez. Yeni listede görülmeyen iş tamamlandı sayılmaz; özet yalnız yüklenen dosyaları ve tamamı alınan seçili iş listelerini kapsar. Sayfa kapanınca dosyaları yeniden yükleyin. Eski biçimi yalnız Açıklama alanının kullanıcı tarafından doldurulduğunu biliyorsanız seçin; önce yeni listeleri getirin. Eski satırlar form/rapor numarası ve dönem bilgileriyle tek bir işe karşılık gelmezse aktarılmaz. VKN tek başına eşleştirme için kullanılmaz.</p><div id="oeGeriDurum" role="status"></div><div id="oeGeriSonuc"></div>';
    document.getElementById('btSonuc').before(box);
    document.getElementById('oeGeriDosya').onchange=function(){var files=Array.from(this.files);this.value='';importFiles(files);};
    document.getElementById('oeEskiAy').onchange=function(){rebuild();api.refresh();};
    document.getElementById('oeGeriTemizle').onclick=function(){records=[];groups=[];choices=Object.create(null);issues=[];rebuild();api.refresh();document.getElementById('oeGeriDurum').textContent='Yüklenen geri bildirimler temizlendi.';};
    document.getElementById('oeGeriExcel').onclick=function(){var a=summary();if(!a.length){alert('Seçili ay için kullanıcı dosyalarını yükleyin.');return;}window.bekleyenExcelYaz([{ad:'Aylık Çalışma Özeti',rows:[R(SH,'hdr')].concat(a.map(function(s){return R(sr(s));}))}],'ozel_esaslar_aylik_calisma.xlsx');};
    render();
  }
  window.OeGeriBildirim={key:key,readBook:readBook,importFiles:importFiles,summary:summary,status:status,decorate:decorate,appendSummary:appendSummary,apply:function(){lastStats=apply();},render:function(){render(lastStats);}};
  init();
})();
