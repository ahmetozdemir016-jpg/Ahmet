/* Matrah ile hesaplanan vergiyi ayırır. Eksik alan sıfır kabul edilmez. */
(function(){'use strict';
function num(v){if(v==null||String(v).trim()==='')return null;if(typeof v==='number')return isFinite(v)?v:null;var s=String(v).trim();if(/^-?\d+(\.\d+)?$/.test(s))return Number(s);if(/^-?(?:\d{1,3}(?:\.\d{3})*|\d+),\d+$/.test(s))return Number(s.replace(/\./g,'').replace(',','.'));return null;}
function key(s){return String(s).replace(/İ/g,'I').replace(/ı/g,'i').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');}
function pick(o,names){var keys=Object.keys(o||{});for(var i=0;i<names.length;i++){var k=keys.find(function(k){return key(k)===key(names[i]);});if(k!=null&&o[k]!=null&&String(o[k]).trim()!=='')return num(o[k]);}return null;}
var fields=[['ilk','İlk T.E. Olan',['ilkTarhEdilen','ilkTarhEdilenOlan','ilkTarhEdilenMatrah','ilkTEOlan','ilkTeOlan','ilkTarhiyat','İlk T.E. Olan']],['eklenen','Eklenen',['eklenen']],['toplam','Toplam',['toplam']],['miktar','Miktar',['miktar']],['once','Ö.T. Edilen',['oncedenTarhEdilen','onceTarhEdilen','oncedenTarhEdilenMiktar','onceTarhEdilenMiktar','otEdilen','Ö.T. Edilen']],['fark','Fark',['tarhEdilenFark','fark']]];
function row(v){var r={kod:String(v.kodu||v.vergiKodu||v.vergikodu||'').trim()};fields.forEach(function(f){r[f[0]]=pick(v,f[2]);});return r;}
function rows(e,kod){return ((e&&e.vergilerHarclar)||[]).map(row).filter(function(r){return !kod||r.kod===String(kod);});}
function sum(rs,k){if(!rs.length||rs.some(function(r){return r[k]==null;}))return null;return rs.reduce(function(s,r){return s+r[k];},0);}
function tarh(t){var h=t&&t.tahriyatVergiHashMap||{},v=pick(h,['topIhbTarhEdilenFark']);if(v!=null)return v;var l=h.tahriyatVergiList;if(!Array.isArray(l)||!l.length)return null;var vals=l.map(function(r){return pick(r,['tarhEdilenFark','fark']);});return vals.some(function(v){return v==null;})?null:vals.reduce(function(a,b){return a+b;},0);}
window.IhbarnameTutar={num:num,fields:fields,rows:rows,sum:sum,tarh:tarh};
})();
