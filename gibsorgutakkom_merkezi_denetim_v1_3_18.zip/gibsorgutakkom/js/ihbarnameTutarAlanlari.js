/* Matrah ile hesaplanan vergiyi ayırır. Eksik alan sıfır kabul edilmez. */
(function(){'use strict';
function num(v){if(v==null||String(v).trim()==='')return null;if(typeof v==='number')return isFinite(v)?v:null;var s=String(v).trim();if(/^-?\d+(\.\d+)?$/.test(s))return Number(s);if(/^-?(?:\d{1,3}(?:\.\d{3})*|\d+),\d+$/.test(s))return Number(s.replace(/\./g,'').replace(',','.'));return null;}
function key(s){return String(s).replace(/İ/g,'I').replace(/ı/g,'i').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');}
function pick(o,names){var keys=Object.keys(o||{});for(var i=0;i<names.length;i++){var k=keys.find(function(k){return key(k)===key(names[i]);});if(k!=null&&o[k]!=null&&String(o[k]).trim()!=='')return num(o[k]);}return null;}
var fields=[['ilk','İlk T.E. Olan',['oncedenTarhEdilmisVergiMatrahi','oncedenTarhEdilmisVergiMatrahiDal','ilkTarhEdilen','ilkTarhEdilenOlan','ilkTarhEdilenMatrah','ilkTEOlan','ilkTeOlan','ilkTarhiyat','İlk T.E. Olan']],['eklenen','Eklenen',['eklenen','eklenenDal']],['toplam','Toplam',['toplam','toplamDal']],['miktar','Miktar',['miktar','miktarDal']],['once','Ö.T. Edilen',['tahakkukTutari','tahakkukTutariDal','oncedenTarhEdilen','onceTarhEdilen','oncedenTarhEdilenMiktar','onceTarhEdilenMiktar','otEdilen','Ö.T. Edilen']],['fark','Fark',['tarhEdilenFark','tarhEdilenFarkDal','fark']]];
function row(v){var r={kod:String(v.kodu||v.vergiKodu||v.vergikodu||'').trim()};fields.forEach(function(f){r[f[0]]=pick(v,f[2]);});return r;}
function rows(e,kod){return ((e&&e.vergilerHarclar)||[]).map(row).filter(function(r){return !kod||r.kod===String(kod);});}
function sum(rs,k){if(!rs.length||rs.some(function(r){return r[k]==null;}))return null;return rs.reduce(function(s,r){return s+r[k];},0);}
function tarh(t){var h=t&&t.tahriyatVergiHashMap||{},v=pick(h,['topIhbTarhEdilenFark']);if(v!=null)return v;var l=h.tahriyatVergiList;if(!Array.isArray(l)||!l.length)return null;var vals=l.map(function(r){return pick(r,['tarhEdilenFark','fark']);});return vals.some(function(v){return v==null;})?null:vals.reduce(function(a,b){return a+b;},0);}
function beyannameCezasi(e,t){
 if(!e||!(e.eklerinDayanagi||[]).some(function(x){return String(x.turuKodu)==='15';}))return false;
 var cs=e.cezalar||[];if(!cs.length||!cs.every(function(c){return String(c.kodu)==='3074'&&String(c.nedenKodu)==='77';}))return false;
 var tv=tarh(t);if(tv!=null&&tv!==0)return false;
 return !rows(e).some(function(r){return fields.some(function(f){return r[f[0]]!=null&&r[f[0]]!==0;});});
}
function yalnizOzelCeza(e,t){
 if(!e||!Array.isArray(e.vergilerHarclar))return false;
 var cs=e.cezalar||[];if(!cs.length||!cs.every(function(c){return String(c.kodu)==='3074';}))return false;
 var tv=tarh(t),rs=rows(e);return (tv==null||tv===0)&&rs.every(function(r){return fields.every(function(f){return r[f[0]]===0;});});
}
function vzKontrol(e,baseKod){
 var groups={};(e&&e.cezalar||[]).filter(function(c){return String(c.kodu)==='3080';}).forEach(function(c){var kod=String(c.vergiKodu||baseKod||'');(groups[kod]=groups[kod]||[]).push(c);});
 return Object.keys(groups).map(function(kod){var cs=groups[kod],rs=rows(e,kod),vergi=sum(rs,'fark'),ms=cs.map(function(c){return num(c.cezaVergiZiyaninaUgratilanVergiMiktari);}),matrah=ms.some(function(v){return v==null;})?null:ms.reduce(function(a,b){return a+b;},0);
  var ok=vergi==null||matrah==null?null:Math.abs(vergi-matrah)<=0.05;
  var es=rs.length===cs.length&&matrah!=null&&vergi!=null,aa=rs.map(function(r){return r.fark;}).sort(function(a,b){return a-b;}),bb=ms.slice().sort(function(a,b){return a-b;});if(es)es=aa.every(function(a,i){return Math.abs(a-bb[i])<=0.05;});
  return {kod:kod,vergi:vergi,matrah:matrah,ok:ok,birebir:es,dagilimBelirsiz:ok===true&&rs.length>1&&cs.length>1&&!es,parcali:cs.length>1,kalemler:cs.map(function(c){return {matrah:num(c.cezaVergiZiyaninaUgratilanVergiMiktari),kat:num(c.kat),tutar:num(c.tutari)};})};
 });
}
window.IhbarnameTutar={num:num,fields:fields,rows:rows,sum:sum,tarh:tarh,beyannameCezasi:beyannameCezasi,yalnizOzelCeza:yalnizOzelCeza,vzKontrol:vzKontrol};
})();
