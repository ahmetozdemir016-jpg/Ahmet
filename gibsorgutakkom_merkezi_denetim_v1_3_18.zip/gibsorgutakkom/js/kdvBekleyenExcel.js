/* Merkezi Denetim ile aynı XLSX yazıcı ve biçimlendirme. */
(function(){
function trN(s){return String(s||'').replace(/İ/g,'I').replace(/ı/g,'i').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
function kolTur(b){var n=trN(b);if(/tutar|miktar|toplam|fark|borcu|bokgz|odenecek|sum\b|\(vabsum\)|kgzsum|ceza miktari/.test(n))return 'tutar';if(/vergi kimlik|t\.c\. kimlik|tckn|vkn/.test(n))return 'kimlik';if(/ihbarname fis/.test(n))return 'ihb';if(/tarihi$|tarih$|^vade$|zamani$/.test(n))return 'tarih';return '';}
function sayiCoz(s){s=String(s==null?'':s).trim();if(!/^-?[\d.,]+$/.test(s))return NaN;var vi=s.lastIndexOf(','),ni=s.lastIndexOf('.'),x;
  if(vi>-1&&ni>-1)x=vi>ni?s.replace(/\./g,'').replace(',','.'):s.replace(/,/g,'');else if(vi>-1)x=(s.split(',').length>2)?s.replace(/,/g,''):s.replace(',','.');else if(ni>-1&&s.split('.').length>2)x=s.replace(/\./g,'');else x=s;return parseFloat(x);}

function xe(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function col(c){var s='';c++;while(c>0){var m=(c-1)%26;s=String.fromCharCode(65+m)+s;c=Math.floor((c-1)/26);}return s;}
function sayfaXml(rows){ /* rows: dizi; r._s = 'baslik' | 'hdr' | '' */
  var hdr=null;for(var i=0;i<rows.length;i++)if(rows[i]._s==='hdr'){hdr=rows[i];break;}hdr=hdr||rows[0]||[];
  var nk=Math.max.apply(null,rows.map(function(r){return r.length;}).concat([1]));
  /* sütun genişliği içeriğe göre: verideki en uzun metin (üst sınır 60), başlıktaki en uzun kelime alt sınır */
  var W=Array.apply(null,{length:nk}).map(function(_,c){var b=hdr[c]||'',n=trN(b);
    if(/^rapor$/.test(n))return 9;if(/^rapor adi$/.test(n))return 70;if(/^aciklama$/.test(n))return 40;
    var mx=0;rows.forEach(function(r){if(r._s)return;var L=String(r[c]==null?'':r[c]).length;if(L>mx)mx=L;});
    var kel=Math.max.apply(null,String(b).split(/\s+/).map(function(k){return k.length;}).concat([6]));
    var w=Math.ceil(Math.max(kel*1.3,Math.min(mx,58)*1.1)+2);if(kolTur(b)==='tutar')w=Math.max(w,14);return Math.min(Math.max(w,9),60);});
  var cols='<cols>'+W.map(function(w,c){return '<col min="'+(c+1)+'" max="'+(c+1)+'" width="'+w+'" customWidth="1"/>';}).join('')+'</cols>';
  var topW=W.reduce(function(a,b){return a+b;},0);
  /* otomatik metin dağılımı: sığmayan metinler sarılır, satır yüksekliği içeriğe göre hesaplanır (LibreOffice otomatik büyütmez) */
  function satirYuk(r){var mx=1,kat=r._s==='hdr'?1.3:1.15;r.forEach(function(v,c){var w=r._s==='baslik'?topW:(W[c]||12);var ln=Math.ceil(String(v==null?'':v).length*kat/w);if(ln>mx)mx=ln;});return Math.min(mx,8)*13.5+2;}
  var ilkHdr=rows.findIndex(function(r){return r._s==='hdr';});
  var sd=rows.map(function(r,ri){var st=r._s==='baslik'?2:(r._s==='hdr'?1:3);var cells=r.map(function(v,c){var num=st===3&&(typeof v==='number'||kolTur(hdr[c]||'')==='tutar')&&isFinite(sayiCoz(v))&&String(v).trim()!=='';
      var stx=(st===3&&String(v==null?'':v).length*1.15>(W[c]||12))?4:st;
      return num?'<c r="'+col(c)+(ri+1)+'" s="'+st+'"><v>'+sayiCoz(v)+'</v></c>':'<c r="'+col(c)+(ri+1)+'" s="'+stx+'" t="inlineStr"><is><t xml:space="preserve">'+xe(v)+'</t></is></c>';}).join('');
    if(r._s==='baslik')cells='<c r="A'+(ri+1)+'" s="'+(String(r[0]||'').length*1.15>topW?5:2)+'" t="inlineStr"><is><t xml:space="preserve">'+xe(r[0]||'')+'</t></is></c>';
    var ht=r._s==='hdr'?Math.max(30,satirYuk(r)+4):satirYuk(r); /* başlıklar da içeriğe göre büyür */
    return '<row r="'+(ri+1)+'"'+(ht>16?' ht="'+ht+'" customHeight="1"':'')+'>'+cells+'</row>';}).join('');
  var merges=rows.map(function(r,ri){return r._s==='baslik'?'<mergeCell ref="A'+(ri+1)+':'+col(nk-1)+(ri+1)+'"/>':'';}).filter(Boolean);
  var pane=ilkHdr>=0?'<sheetViews><sheetView workbookViewId="0"><pane ySplit="'+(ilkHdr+1)+'" topLeftCell="A'+(ilkHdr+2)+'" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>':'';
  var tekHdr=rows.filter(function(r){return r._s==='hdr';}).length===1;
  return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'+pane+cols+'<sheetData>'+sd+'</sheetData>'+
    (tekHdr&&ilkHdr>=0?'<autoFilter ref="A'+(ilkHdr+1)+':'+col(nk-1)+rows.length+'"/>':'')+(merges.length?'<mergeCells count="'+merges.length+'">'+merges.join('')+'</mergeCells>':'')+
    '<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/></worksheet>';}
function excelYaz(sayfalar,ad){var zip=new JSZip();
  zip.file('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+sayfalar.map(function(s,i){return '<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';}).join('')+'</Types>');
  zip.file('_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  var kul={};sayfalar.forEach(function(s){var ad=String(s.ad||'Sayfa').replace(/[\[\]\*\/\\?:]/g,'_').slice(0,31),k=ad.toLowerCase(),n=1;while(kul[k]){n++;ad=ad.slice(0,31-(String(n).length+1))+' '+n;k=ad.toLowerCase();}kul[k]=1;s.ad=ad;});
  zip.file('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+sayfalar.map(function(s,i){return '<sheet name="'+xe(String(s.ad).replace(/[\[\]\*\/\\?:]/g,'_').slice(0,31))+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>';}).join('')+'</sheets></workbook>');
  zip.file('xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sayfalar.map(function(s,i){return '<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>';}).join('')+'<Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
  /* stiller: 0 normal, 1 başlık satırı (kalın, gri, kenarlık, kaydırma), 2 rapor adı (kalın, büyük), 3 veri (kenarlık, kaydırma) */
  zip.file('xl/styles.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts><fonts count="3"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="12"/><color rgb="FF1769AA"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7E6E6"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"/><right style="thin"/><top style="thin"/><bottom style="thin"/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyNumberFormat="1" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
  sayfalar.forEach(function(s,i){zip.file('xl/worksheets/sheet'+(i+1)+'.xml',sayfaXml(s.rows));});
  return zip.generateAsync({type:'blob',mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}).then(function(b){var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=ad;document.body.appendChild(a);a.click();return new Promise(function(resolve){setTimeout(function(){resolve(b);},0);setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();},2000);});});}
function R(arr,st){arr._s=st||'';return arr;}

window.bekleyenExcelYaz=excelYaz;
})();
