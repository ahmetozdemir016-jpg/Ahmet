/* VDK-Kullanma Tespiti: komut, akış kodları, kriterler ve alan adları
   sağlanan GİB ağ kaydından alınır. Sayılar çalışma sırasında sorgulanır. */
(function(){
  'use strict';
  var CMD='ozesKullanmaTespitiService_vdkKullanmaTespitiGetir';
  var AKIS=[
    ['T10','Kullanma tespiti olanların VD’ye bilgilendirilmesi'],
    ['TE1','Kullanma tespitine EK5 bilgisi girilmiş'],
    ['TI1','Kullanma tespitine alınması için taslak kaydedilmiş'],
    ['TI2','Kullanma tespitine alınmaması için taslak kaydedilmiş'],
    ['T20','Kullanma tespitine alınması için müdür onayına gönderilmiş'],
    ['T21','Kullanma tespitine alınmaması için müdür onayına gönderilmiş'],
    ['T15','Kullanma tespitine alınması reddedilmiş'],
    ['T11','Kullanma tespitine alınmaması reddedilmiş'],
    ['T30','Kullanma tespitine alınması için Defterdarlığa gönderilmiş'],
    ['T31','Kullanma tespitine alınmaması için Defterdarlığa gönderilmiş'],
    ['T32','Defterdarlıktan VD’ye geri gönderilmiş'],
    ['T99','VUK 370/B kapsamına alınan kullanma tespiti'],
    ['T60','Yetkili onaylamış'],
    ['T14','Kullanma tespitine alınmaması onaylanmış (7440 KDV Artırımı)'],
    ['T26','Kullanma tespitine alınmaması onaylanmış (Düzeltme)'],
    ['T25','Kullanma tespitine alınmaması onaylanmış (İspat)'],
    ['T13','Kullanma tespitine alınmaması onaylanmış (%5 Limit Altı)'],
    ['T09','KDV artırımı ihlali sonucu kullanma tespiti'],
    ['TT3','Bağlı olduğu ana mükellefin çıkışı yapılmış'],
    ['TVDB','Defterdarlıkta işlem sürüyor']
  ];
  var sayilar={},yukleme=null,yukleniyor=false,sonBilgi='Bekleyen İşleri Getir ile sayılar güncellenir.';
  function el(tag,cls,text){var n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
  function bosKriter(akis){return {vdIlKodu:document.getElementById('vdTx').textContent,basVkn:'',bitVkn:'',basTckn:'',bitTckn:'',akisDurumu:akis,parafSayisi:'',raporTarihiBas:'',raporTarihiBit:'',lastUpdateOptimeBas:'',lastUpdateOptimeBit:'',listFilter:'VD_MEMUR',respKeyParam:'liste'};}
  function oku(r){
    if(!r||r.error)throw new Error(hataMetni(r)||'VDK-Kullanma Tespiti yanıtı alınamadı.');
    var d=r.data,t=d&&(d.toplam!=null?d.toplam:d.totalCount);
    if(!d||!Array.isArray(d.liste)||t===null||t===undefined||t===''||!/^\d+$/.test(String(t)))throw new Error('VDK-Kullanma Tespiti listesi veya toplamı okunamadı.');
    return d;
  }
  function kriter(){
    [['Rap','Rapor Tarihi'],['Gun','Son Güncelleme']].forEach(function(a){var b=v('vkt'+a[0]+'Bas'),s=v('vkt'+a[0]+'Bit');if(b&&s&&b>s)throw new Error(a[1]+': başlangıç tarihi bitiş tarihinden sonra olamaz.');});
    return Object.assign(bosKriter(v('vktAkis')),{basVkn:v('vktVknBas'),bitVkn:v('vktVknBit'),basTckn:v('vktTcBas'),bitTckn:v('vktTcBit'),parafSayisi:v('vktParaf'),raporTarihiBas:d8('vktRapBas'),raporTarihiBit:d8('vktRapBit'),lastUpdateOptimeBas:d8('vktGunBas'),lastUpdateOptimeBit:d8('vktGunBit')});
  }
  function donem(x){x=String(x||'');return /^\d{12}$/.test(x)?x.slice(0,4)+'/'+x.slice(4,6)+' – '+x.slice(6,10)+'/'+x.slice(10,12):x;}
  function listeAc(akis){listeTemizle('vdkt');document.getElementById('vktAkis').value=akis;sekmeAc('vdkt');listeSorgula('vdkt');}
  function sayilariCiz(){
    var ul=document.getElementById('vdkKtAkislar');if(!ul)return;ul.textContent='';
    var toplam=0,bilinen=0,gorunen=0,sadece=document.getElementById('sadeceVar').checked;
    AKIS.forEach(function(a){
      var x=sayilar[a[0]],hazir=!!x&&typeof x.sayi==='number';if(hazir){toplam+=x.sayi;bilinen++;}
      if(sadece&&hazir&&x.sayi===0)return;gorunen++;
      var li=el('li'),b=el('button','vdk-akis'+(hazir&&x.sayi>0?' var':''));b.type='button';b.dataset.vdkKtAkis=a[0];
      b.appendChild(el('span','',a[1]));b.appendChild(el('span','vdk-sayi',hazir?String(x.sayi):(x&&x.hata?'Alınamadı':'—')));
      b.setAttribute('aria-label',a[1]+': '+(hazir?x.sayi+' kayıt':x&&x.hata?'sayı alınamadı':'sayı henüz alınmadı')+'; listeyi aç');
      if(x&&x.hata)b.title=x.hata;b.onclick=function(){listeAc(a[0]);};li.appendChild(b);ul.appendChild(li);
    });
    if(!gorunen)ul.appendChild(el('li','vdk-bos','Seçili görünümde kayıt yok.'));
    var top=document.getElementById('vdkKtToplam');top.textContent=bilinen===AKIS.length?String(toplam):(bilinen?toplam+'+':'—');
    top.title=bilinen===AKIS.length?'20 akışın toplam kayıt sayısı':'Tüm akışların sayısı henüz alınmadı.';
    document.getElementById('vdkKtSayimDurum').textContent=yukleniyor?'Akış sayıları alınıyor… '+bilinen+' / '+AKIS.length:sonBilgi;
    document.getElementById('vdkKtSayYenile').disabled=yukleniyor;window.dispatchEvent(new Event('takkom-bekleyen-degisti'));
  }
  window.vdkKtBekleyenIsleri=function(){return AKIS.map(function(a){var x=sayilar[a[0]];return {id:'vdkt:'+a[0],k:'vdkt',akis:a[0],ust:'VDK-Kullanma Tespiti',alt:a[1],sayi:x&&typeof x.sayi==='number'?x.sayi:null};});};
  function sayilariGetir(){
    if(yukleme)return yukleme;sayilar={};sonBilgi='';
    if(!gibTokenGetir()){sonBilgi='Sayıları almak için GİB oturumu gerekir.';sayilariCiz();return Promise.resolve();}
    yukleniyor=true;sayilariCiz();
    yukleme=(async function(){
      var index=0;
      async function isci(){while(index<AKIS.length){var a=AKIS[index++];try{var d=oku(await ozes(CMD,Object.assign(bosKriter(a[0]),{pv:{start:0,limit:'50',sorters:[]}})));sayilar[a[0]]={sayi:Number(d.toplam!=null?d.toplam:d.totalCount)};}catch(e){sayilar[a[0]]={hata:e.message||'Sayı alınamadı.'};}sayilariCiz();}}
      try{await Promise.all([isci(),isci(),isci()]);var hata=AKIS.filter(function(a){return sayilar[a[0]]&&sayilar[a[0]].hata;}).length;sonBilgi=hata?hata+' akışın sayısı alınamadı. Sayıları Yenile ile tekrar deneyin.':'20 akış güncellendi • '+new Date().toLocaleTimeString('tr-TR');}
      finally{yukleniyor=false;yukleme=null;sayilariCiz();}
    })();return yukleme;
  }
  function kutuMetni(t){document.getElementById('vdktKutu').textContent=t;document.getElementById('vktSay').textContent='';}
  window.vdkKtSayilariGetir=sayilariGetir;window.vdkKtSayilariCiz=sayilariCiz;
  window.vdkKtInit=function(){
    var bolum=document.getElementById('sek_kt').cloneNode(true);bolum.id='sek_vdkt';
    bolum.querySelectorAll('[id]').forEach(function(n){n.id=n.id==='ktKutu'?'vdktKutu':n.id.replace(/^kt/,'vkt');});
    // K ve T akışları farklı ekranlardır; K ekranındaki VUK açıklaması kopyalanmaz.
    var not=bolum.querySelector('.form > .mut');if(not)not.remove();
    var akis=bolum.querySelector('#vktAkis');akis.textContent='';var hepsi=el('option','','Tüm akış durumları');hepsi.value='';akis.appendChild(hepsi);
    AKIS.forEach(function(a){AKIS_AD[a[0]]=a[1];var o=el('option','',a[1]);o.value=a[0];akis.appendChild(o);});akis.value='T10';
    document.getElementById('sek_kt').before(bolum);
    LISTELER.vdkt={ad:'VDK-Kullanma Tespiti',cmd:CMD,p:'vkt',ilkAkis:'T10',limit:50,kriter:kriter,oku:oku,anahtar:function(r){return r.oid;},
      bosMetin:'Kriterleri seçip Sorgula’ya basın. Tüm sayfalar alınır; her tespit, paraflarıyla tek satırda gösterilir.',
      metin:['vkn','tckn','vdKodu','mukvkn','mukTckn','mukVdKodu','raporNo'],uzun:'aciklama',
      ara:['vkn','tckn','unvan','mukvkn','mukTckn','mukUnvan','raporNo','aciklama','mudurRedAciklama','akisKullaniciKodu','donem'],
      gruplar:[['Kullanma Tespiti Olan Mükellefin Bilgileri',4],['',7],['EK 1 Düzenlenen Mükellefin Bilgileri',4],['',4]],
      kol:[['VKN','vkn'],['TCKN','tckn'],['Unvan','unvan'],['Vergi Dairesi','vdKodu'],['Tespit Türü','girisNedeni',gNed],['Dönem Aralığı','donem',donem],['Açıklama','aciklama'],['VD’ye Bilgilendirme Tarihi','bilgilendirmeTarihi',t14],['Kullanıcı Kodu','akisKullaniciKodu'],['Akış Durumu','akisDurumu',function(x){return AKIS_AD[x]||x;}],['Son Güncelleme Tarihi','akisOptime',t14],
        ['VKN','mukvkn'],['TCKN','mukTckn'],['Unvan','mukUnvan'],['Vergi Dairesi','mukVdKodu'],['Rapor Tarihi','raporTarihi',t8],['Rapor Numarası','raporNo'],['VD Geliş Tarihi','vdGelisTarihi',t8],['Akış Durumu','mukAkisDurumu',function(x){return AKIS_AD[x]||x;}],
        ['Müdür Red Açıklaması','mudurRedAciklama'],['Ana Mükellef Giriş Nedeni','ataGirisNedeni',function(x){return String(x||'').split(/[.,;\s]+/).filter(Boolean).map(gNed).join('\n');}],['Oluşturulma Tarihi','createOptime',t14]],
      baslat:function(){kutuMetni('VDK-Kullanma Tespiti listesi alınıyor…');},hata:function(e){kutuMetni('Liste alınamadı: '+e.message);}
    };
    var kart=el('section','grup vdk-grup');kart.id='vdkKtBekleyen';kart.setAttribute('aria-label','VDK-Kullanma Tespiti akışlara göre kayıt sayıları');
    var h=el('h3');h.appendChild(el('span','','VDK-Kullanma Tespiti'));var top=el('span','say','—');top.id='vdkKtToplam';h.appendChild(top);kart.appendChild(h);
    var ust=el('div','vdk-sayim-ust');ust.appendChild(el('span','mut','Tüm akış durumlarındaki tespit sayıları'));var yenile=el('button','btn','Sayıları Yenile');yenile.id='vdkKtSayYenile';yenile.type='button';yenile.onclick=sayilariGetir;ust.appendChild(yenile);kart.appendChild(ust);
    var ul=el('ul','vdk-akis-liste');ul.id='vdkKtAkislar';kart.appendChild(ul);var durum=el('p','mut vdk-sayim-durum');durum.id='vdkKtSayimDurum';durum.setAttribute('role','status');kart.appendChild(durum);
    document.getElementById('vdkBekleyen').after(kart);sayilariCiz();
  };
})();
