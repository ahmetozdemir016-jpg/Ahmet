/* Bekleyen İşler: seçili akışların tüm sayfaları, VKN aralığıyla dağıtım ve tek XLSX. */
(function(){
'use strict';
var BKEY='takkom_rapor_personel_bolumler',PLANKEY='takkom_bekleyen_dagitim_plani_v1';
var secili=new Set(),sonuclar=new Map(),isler=[],imza='',mesgul=false,durdur=false;
var HAZIR_DAGILIM={
  'Vergilendirme-1':[['001','084','Nalan SERİF'],['085','168','Özge TARIM'],['169','238','Halim YARAR'],['239','324','Sebile YILMAZ'],['','','Çağatay TÜRKOĞLU']],
  'Vergilendirme-2':[['325','419','Ahmet TARANCI'],['420','497','Resul MEYDAN'],['498','585','Nuran KARAKAYA'],['586','639','Nur Berru YENİÇERİ']],
  'Vergilendirme-3':[['640','733','Canan YILDIZOĞLU'],['734','814','Ali BEŞTAŞ'],['815','919','Hikmet ŞAHİN'],['920','999','Ömer DÜNDAR']],
  'KDV-ÖTV İade':[['001','180','Fadime SARIÇOBAN'],['181','420','Kader KONUR GÜNE'],['421','621','Melik Fırat TEKİN'],['622','762','Ayşegül ADSAY'],['763','999','Yücel ÖZTÜRK']],
  'İcra':[['001','269','Mehmet Ali PADIR'],['270','539','İ.Serbülent ÜNSAL'],['540','729','Şenol ŞENGÜL'],['730','999','Ayfer ŞEN']],
  'Satış':[['001','999','Abdülcelil AYDAŞ']],
  'Takip':[['000','250','Hasan TURAN'],['251','500','Kemal KAYAL'],['501','750','Abdülgani YILMAZ'],['751','999','Nergis UÇAN']],
  'Sicil Yoklama':[['001','999','Mehmet SÜRER'],['001','999','Melek YILDIZ']],
  'Muhasebe Kayıt':[['001','999','Canan ÖZADALI'],['001','999','Hatice AKPINAR'],['001','999','Ömer KIRAR']],
  'Tarama ve Kontrol':[['001','999','Melek YILDIZ (İhtilaflı İşler)'],['001','999','Serkan ÖZER (İzaha Davet)'],['001','999','Gülnur SAVAŞERİ (Diğer İş ve İşlemler)'],['','','Ayşe AKTAŞ (Doğum sonrası ücretsiz izinde)']],
  'Yazışma Arşiv ve Özlük':[['','','Vahide ÖZTÜRK (Özlük-Uzlaşma-Taşınır Kayıt)'],['','','Hulusi KAYA (Evrak Kayıt)'],['','','Necati AKTAŞ (Hizmetli)'],['','','Hatice YILDIZ (Hizmetli)']]
};
function $(id){return document.getElementById(id);}
function oku(k,f){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x||f;}catch(e){return f;}}
function yaz(k,x){localStorage.setItem(k,JSON.stringify(x));}
function personel(){var o=oku(BKEY,{});if(!o.bolumler)o={aktif:'KDV-ÖTV İade',aktifler:['KDV-ÖTV İade'],bolumler:{}};return o;}
function plan(){return oku(PLANKEY,{});}
function bilgi(t){$('btDurum').textContent=t;}
function katalog(){
 var a=[],cur=[];(SON||[]).forEach(function(x){if(/TOP$/.test(x.key||'')){var ust=GRUP_ADI[x.key]||x.name;cur.forEach(function(y){var z=LISTE_AKIS_ANAHTAR[y.key];if(z)a.push({id:'g:'+y.key,k:z[0],akis:z[1],ust:ust,alt:String(y.name||'').replace(/\s+/g,' ').trim(),sayi:Number(y.value)||0});});cur=[];}else cur.push(x);});
 cur.forEach(function(y){var z=LISTE_AKIS_ANAHTAR[y.key];if(z)a.push({id:'g:'+y.key,k:z[0],akis:z[1],ust:'Diğer',alt:y.name,sayi:Number(y.value)||0});});
 if(window.vdkBekleyenIsleri)a=a.concat(window.vdkBekleyenIsleri());if(window.vdkKtBekleyenIsleri)a=a.concat(window.vdkKtBekleyenIsleri());return a;
}
function yenile(){
 isler=katalog();var sig=JSON.stringify(isler);if(sig===imza)return;imza=sig;
 $('btIsler').innerHTML=isler.map(function(j){return '<label class="bt-job'+(j.sayi>0?' var':'')+'"><input type="checkbox" data-job="'+esc(j.id)+'"'+(secili.has(j.id)?' checked':'')+(mesgul?' disabled':'')+'><span>'+esc(j.ust+' → '+j.alt)+'<small>'+esc(AKIS_AD[j.akis]||j.akis)+'</small></span><b>'+(j.sayi===null?'—':j.sayi)+'</b></label>';}).join('')||'<p>Önce Bekleyen İşleri Getir düğmesine basın.</p>';
 $('btIsler').querySelectorAll('[data-job]').forEach(function(cb){cb.onchange=function(){if(cb.checked)secili.add(cb.dataset.job);else secili.delete(cb.dataset.job);secimCiz();};});secimCiz();
}
function secilen(){return isler.filter(function(j){return secili.has(j.id);});}
function secimCiz(){var a=secilen(),once=$('btPlanIs').value;$('btSecim').textContent=a.length+' iş seçildi';$('btPlanIs').innerHTML=a.map(function(j){return '<option value="'+esc(j.id)+'">'+esc(j.ust+' → '+j.alt)+'</option>';}).join('');if(a.some(function(j){return j.id===once;}))$('btPlanIs').value=once;planCiz();istatistik();}
function bolumSecCiz(){var o=personel(),keys=Object.keys(o.bolumler),sel=$('btBolum');sel.innerHTML=keys.map(function(b){return '<option>'+esc(b)+'</option>';}).join('');sel.value=o.bolumler[o.aktif]?o.aktif:(keys[0]||'');
 $('btBolumler').innerHTML=keys.map(function(b){return '<label><input type="checkbox" data-bolum="'+esc(b)+'"'+((o.aktifler||[o.aktif]).includes(b)?' checked':'')+'> '+esc(b)+'</label> ';}).join('')||'<span class="mut">Personel aralıklarını ekleyin veya hazır dağılımı yükleyin.</span>';
 $('btBolumler').querySelectorAll('input').forEach(function(c){c.onchange=function(){var x=personel();x.aktifler=aktifBolumler();yaz(BKEY,x);};});personelCiz();planCiz();}
function aktifBolumler(){return Array.from($('btBolumler').querySelectorAll('input:checked')).map(function(x){return x.dataset.bolum;});}
function personelCiz(){var o=personel(),b=$('btBolum').value;$('btPersonel').querySelector('tbody').innerHTML=(o.bolumler[b]||[]).map(function(p){return '<tr><td><input class="bt-bas" maxlength="10" value="'+esc(p.bas)+'" aria-label="Başlangıç VKN"></td><td><input class="bt-bit" maxlength="10" value="'+esc(p.bit)+'" aria-label="Bitiş VKN"></td><td><input class="bt-kisi" value="'+esc(p.kisi)+'" aria-label="Kişi"></td><td><button type="button" class="btn bt-sil">Sil</button></td></tr>';}).join('');
 $('btPersonel').querySelectorAll('.bt-sil').forEach(function(b){b.onclick=function(){b.closest('tr').remove();};});}
function satirEkle(){$('btPersonel').querySelector('tbody').insertAdjacentHTML('beforeend','<tr><td><input class="bt-bas" maxlength="10" aria-label="Başlangıç VKN"></td><td><input class="bt-bit" maxlength="10" aria-label="Bitiş VKN"></td><td><input class="bt-kisi" aria-label="Kişi"></td><td><button type="button" class="btn bt-sil">Sil</button></td></tr>');$('btPersonel').querySelector('tbody tr:last-child .bt-sil').onclick=function(){this.closest('tr').remove();};}
function kaydet(){var b=$('btBolum').value;if(!b)throw Error('Bölüm seçin veya yeni bölüm ekleyin.');var rows=Array.from($('btPersonel').querySelectorAll('tbody tr')).map(function(tr){return {bas:tr.querySelector('.bt-bas').value.trim(),bit:tr.querySelector('.bt-bit').value.trim(),kisi:tr.querySelector('.bt-kisi').value.trim()};}).filter(function(p){return p.bas||p.bit||p.kisi;});
 rows.forEach(function(p){if(!p.kisi)throw Error('Kişi adı boş bırakılamaz.');if(!p.bas&&!p.bit)return;if(!/^\d{1,10}$/.test(p.bas)||!/^\d{1,10}$/.test(p.bit))throw Error('VKN aralığı 1–10 rakam olmalı.');p.bas=p.bas.padStart(10,'0');p.bit=p.bit.padStart(10,'0');if(p.bas>p.bit)throw Error('Başlangıç VKN bitişten büyük olamaz.');});var o=personel();o.bolumler[b]=rows;o.aktif=b;yaz(BKEY,o);bilgi('Personel aralıkları kaydedildi. Değişiklikleri uygulamak için Dağıt düğmesine basın.');}
function planCiz(){var p=plan(),sec=p[$('btPlanIs').value]||[],o=personel();$('btPlanBolumler').innerHTML=Object.keys(o.bolumler).map(function(b){return '<label><input type="checkbox" data-plan-bolum="'+esc(b)+'"'+(sec.includes(b)?' checked':'')+'> '+esc(b)+'</label> ';}).join('');}
function planKaydet(){var id=$('btPlanIs').value;if(!id)throw Error('Önce iş seçin.');var p=plan(),b=Array.from($('btPlanBolumler').querySelectorAll('input:checked')).map(function(x){return x.dataset.planBolum;});if(b.length)p[id]=b;else delete p[id];yaz(PLANKEY,p);bilgi('İşin bölüm planı kaydedildi. Seçim boşsa genel bölümler kullanılır. Dağıt ile uygulayın.');}
function temizKriter(j){
 var L=LISTELER[j.k],fields=Array.from(document.querySelectorAll('#sek_'+j.k+' input, #sek_'+j.k+' select')),saved=fields.map(function(n){return n.value;});
 try{fields.forEach(function(n){n.value='';});$(L.p+'Akis').value=j.akis;return L.kriter();}
 finally{fields.forEach(function(n,i){n.value=saved[i];});}
}
async function getirBir(j){
 var L=Object.assign({},LISTELER[j.k],{kol:LISTELER[j.k].kol.slice()}),kr=temizKriter(j),start=0,lim=L.limit||50,top=null,tum=[];
 do{if(durdur)throw Error('Durduruldu.');var r=await ozes(L.cmd,Object.assign({},kr,{pv:{start:start,limit:L.sayisalLimit?lim:String(lim),sorters:[]}}));if(r&&r.error)throw Error(hataMetni(r)||'Servis hatası.');var d=L.oku?L.oku(r):r&&r.data;
  if(!d||!Array.isArray(d.liste))throw Error('Liste yanıtı okunamadı.');var t=d.toplam!=null?d.toplam:d.totalCount;if(t==null||!/^\d+$/.test(String(t)))throw Error('Toplam kayıt sayısı okunamadı.');if(top===null)top=Number(t);else if(top!==Number(t))throw Error('Sorgu sırasında kayıt sayısı değişti; yeniden deneyin.');
  if(!d.liste.length&&start<top)throw Error('Liste tamamlanmadan boş sayfa döndü.');tum=tum.concat(d.liste);start+=lim;
 }while(start<top);
 if(durdur)throw Error('Durduruldu.');
 if(L.parafYok){var m=new Map();tum.forEach(function(r){m.set(L.anahtar(r),Object.assign({},r));});L.veri=Array.from(m.values());}else L.veri=birlestir(L,tum);
 if(L.veri.length!==top)throw Error('Servis toplamı '+top+', alınan tekil kayıt '+L.veri.length+'. Liste eksik olabilir; yeniden deneyin.');
 if(L.dinamik)L.kol=dinamikKol(L);if(L.ekAlan)ekAlanKol(L);
 return {job:j,L:L,rows:L.veri.map(function(r){return {raw:r,vkn:String(r.vkn||r.anaMukellefVkn||r.alinanVkn||r.aliciVkn||r.saticiVkn||'').trim(),kisi:'',bolum:'',durum:'Dağıtılmadı'};}),zaman:new Date().toLocaleString('tr-TR')};
}
function kilit(b){mesgul=b;$('bekleyenToplu').querySelectorAll('input,select,button').forEach(function(n){n.disabled=b;});$('btDurdur').disabled=!b;istatistik();}
async function listeleriGetir(){var a=secilen();if(!a.length){bilgi('En az bir iş seçin.');return;}durdur=false;a.forEach(function(j){sonuclar.delete(j.id);});kilit(true);var hata=0;
 try{for(var i=0;i<a.length;i++){if(durdur)break;var j=a[i];sonuclar.delete(j.id);bilgi((i+1)+' / '+a.length+' — '+j.ust+' → '+j.alt+' alınıyor…');try{sonuclar.set(j.id,await getirBir(j));}catch(e){hata++;sonuclar.set(j.id,{job:j,hata:e.message});}istatistik();}
 bilgi(durdur?'Durduruldu. Tamamlanmayan seçili işler için tekrar liste getirin.':a.length+' iş sorgulandı'+(hata?'; '+hata+' iş alınamadı. Excel için tüm seçili listeler tamamlanmalı.':'. Dağıtım yapabilir veya Excel indirebilirsiniz.'));
 }finally{kilit(false);}
}
function dagit(){kaydet();var p=plan(),o=personel(),genel=aktifBolumler();if(!genel.length&&!Object.keys(p).length)throw Error('Dağıtılacak bölümleri seçin.');
 secilen().forEach(function(j){var s=sonuclar.get(j.id);if(!s||s.hata)return;var bs=p[j.id]||genel,ar=[];bs.forEach(function(b){(o.bolumler[b]||[]).forEach(function(x){if(x.bas&&x.bit&&x.kisi)ar.push(Object.assign({bolum:b},x));});});s.rows.forEach(function(r){var v=/^\d{1,10}$/.test(r.vkn)?r.vkn.padStart(10,'0'):'',es=ar.filter(function(x){return v&&v>=x.bas&&v<=x.bit;}),uniq=new Map();es.forEach(function(x){uniq.set(x.bolum+'\0'+x.kisi,x);});es=Array.from(uniq.values());var x=es.length===1?es[0]:null;r.kisi=x?x.kisi:'';r.bolum=x?x.bolum:'';r.durum=x?'Atandı':es.length>1?'Çakışan VKN aralığı':v?'Aralık dışı':'VKN yok';});});istatistik();bilgi('Seçili listeler VKN aralıklarına göre dağıtıldı. Aralık dışı, VKN’si olmayan ve çakışan kayıtlar atanmadı.');}
function R(a,s){a._s=s||'';return a;}
function tablo(bas,rows){return '<div class="bt-scroll"><table><thead><tr>'+bas.map(function(x){return '<th>'+esc(x)+'</th>';}).join('')+'</tr></thead><tbody>'+rows.map(function(r){return '<tr>'+r.map(function(x){return '<td>'+esc(x)+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';}
function tekil(rows){return new Set(rows.map(function(r){return r.vkn;}).filter(Boolean)).size;}
function ozet(){var a=secilen(),sat=[],all=[],kisiler=new Map(),bolumler=new Map();
 a.forEach(function(j){var s=sonuclar.get(j.id),rows=s&&!s.hata?s.rows:[],atanan=rows.filter(function(r){return r.kisi;}).length;sat.push([j.ust,j.alt,j.akis,rows.length,tekil(rows),atanan,rows.length-atanan,s?s.hata?'Hata: '+s.hata:'Tamamlandı':'Henüz alınmadı']);all=all.concat(rows);rows.forEach(function(r){var k=(r.kisi||'Atanmayan')+'\0'+(r.bolum||'Bölümsüz');if(!kisiler.has(k))kisiler.set(k,[]);kisiler.get(k).push(r);var b=r.bolum||'Bölümsüz';if(!bolumler.has(b))bolumler.set(b,[]);bolumler.get(b).push(r);});});
 return {isler:sat,all:all,kisiler:Array.from(kisiler).map(function(x){var a=x[0].split('\0');return [a[0],a[1],x[1].length,tekil(x[1])];}),bolumler:Array.from(bolumler).map(function(x){return [x[0],x[1].length,tekil(x[1])];})};}
var OZB=['Üst başlık','Alt başlık','Akış kodu','Kayıt','Tekil VKN','Atanan','Atanmayan','Durum'];
function istatistik(){var o=ozet(),a=secilen(),tam=a.length>0&&a.every(function(j){var s=sonuclar.get(j.id);return s&&!s.hata;});$('btExcel').disabled=mesgul||!tam;$('btDagit').disabled=mesgul||!a.some(function(j){var s=sonuclar.get(j.id);return s&&!s.hata;});
 $('btSonuc').innerHTML='<b>İş bazında istatistik</b>'+tablo(OZB,o.isler)+'<p>'+a.length+' seçili iş · '+o.all.length+' kayıt · '+tekil(o.all)+' tekil VKN · '+o.all.filter(function(r){return r.kisi;}).length+' atanan</p>'+(o.kisiler.length?'<b>Kişi bazında istatistik</b>'+tablo(['Kişi','Bölüm','Kayıt','Tekil VKN'],o.kisiler)+'<br><b>Bölüm bazında istatistik</b>'+tablo(['Bölüm','Kayıt','Tekil VKN'],o.bolumler):'');}
function excel(){var a=secilen();if(!a.length||a.some(function(j){var s=sonuclar.get(j.id);return !s||s.hata;}))throw Error('Önce seçili işlerin tüm listelerini getirin.');var o=ozet(),oz=[R(['Bekleyen İşler · '+$('vdTx').textContent+' · '+new Date().toLocaleString('tr-TR')],'baslik'),R(OZB,'hdr')].concat(o.isler.map(function(r){return R(r);}));
 oz.push(R(['Toplam','','',o.all.length,tekil(o.all),o.all.filter(function(r){return r.kisi;}).length,o.all.filter(function(r){return !r.kisi;}).length]));
 oz.push(R([]),R(['Kişi bazında istatistik'],'baslik'),R(['Kişi','Bölüm','Kayıt','Tekil VKN'],'hdr'));o.kisiler.forEach(function(r){oz.push(R(r));});oz.push(R([]),R(['Bölüm bazında istatistik'],'baslik'),R(['Bölüm','Kayıt','Tekil VKN'],'hdr'));o.bolumler.forEach(function(r){oz.push(R(r));});
 var sheets=[{ad:'Özet ve İstatistik',rows:oz}];a.forEach(function(j){var s=sonuclar.get(j.id),L=s.L,names=L.kol.map(function(c,i){var n=0,group='';(L.gruplar||[]).some(function(g){n+=g[1];if(i<n){group=g[0];return true;}return false;});return (group?group+' – ':'')+c[0];});var ust=j.ust.replace('TASLAK OLARAK BEKLEYEN','Taslak').replace('MÜDÜR ONAYINDA REDDEDİLEN','Müdür Red').replace("DEFTERDARLIKTAN VD'YE GERİ GÖNDERİLEN",'VD Geri').replace('İŞLEM YAPILACAK KULLANMA TESPİTİ','Kullanma Tespiti');
 var rows=[R([j.ust+' → '+j.alt+' · '+(AKIS_AD[j.akis]||j.akis)],'baslik'),R(['Vergi Dairesi: '+$('vdTx').textContent+' · Sorgu: '+s.zaman+' · '+s.rows.length+' kayıt'],'baslik'),R(['Üst başlık','Alt başlık','Akış kodu','Sorumlu','Bölüm','Dağıtım durumu','Paraflar'].concat(names),'hdr')];
 s.rows.forEach(function(r){rows.push(R([j.ust,j.alt,j.akis,r.kisi,r.bolum,r.durum,(r.raw.paraflar||[]).map(function(p){return (p.ok?'☑ ':'☐ ')+p.ad;}).join('\n')].concat(L.kol.map(function(c){return deger(c,r.raw);}))))});sheets.push({ad:ust+' '+j.akis+' '+j.alt,rows:rows});});
 $('btExcel').disabled=true;bilgi('Excel hazırlanıyor…');return window.bekleyenExcelYaz(sheets,'bekleyen_isler_'+$('vdTx').textContent+'.xlsx').then(function(){bilgi('Excel hazır: özet, istatistik ve '+a.length+' ayrı iş sekmesi.');}).finally(function(){istatistik();});
}
function guvenli(fn){return function(){try{var p=fn();if(p&&p.catch)p.catch(function(e){bilgi(e.message);});}catch(e){bilgi(e.message);}};}
var box=document.createElement('details');box.id='bekleyenToplu';box.innerHTML='<summary>İş seçimi, kişilere dağıtım ve toplu Excel</summary><p class="mut">İşleri seçin → listeleri getirin → personel VKN aralıklarına göre dağıtın → tek Excel indirin. Liste ekranlarındaki ek filtreler bu sorguya uygulanmaz.</p><div class="bt-grid"><div><div class="bt-tools"><button type="button" class="btn" id="btVarSec">Kayıt olanları seç</button><button type="button" class="btn" id="btHepsi">Tümünü seç</button><button type="button" class="btn" id="btSecimSil">Seçimi kaldır</button><span id="btSecim"></span></div><div class="bt-jobs" id="btIsler"></div></div><div><b>Personel VKN aralıkları</b><p class="mut">Merkezi Denetim ile aynı bölüm/personel listesi bu tarayıcıda kullanılır. Çakışan aralıklar atanmaz.</p><div class="bt-tools"><button type="button" class="btn" id="btHazir">Hazır dağılımı yükle</button><button type="button" class="btn" id="btTekrarOku">Personel listesini yenile</button></div><div id="btBolumler"></div><div class="bt-tools"><select id="btBolum" aria-label="Düzenlenen bölüm"></select><button type="button" class="btn" id="btYeniBolum">Yeni bölüm</button><button type="button" class="btn" id="btSatir">Kişi ekle</button><button type="button" class="btn" id="btKaydet">Kaydet</button></div><div class="bt-scroll"><table id="btPersonel"><thead><tr><th>Başlangıç VKN</th><th>Bitiş VKN</th><th>Kişi</th><th></th></tr></thead><tbody></tbody></table></div><details><summary>İşe özel bölüm planı</summary><select id="btPlanIs" aria-label="Dağıtım planı işi" style="max-width:100%"></select><div id="btPlanBolumler"></div><button type="button" class="btn" id="btPlanKaydet">Bu işin planını kaydet</button><p class="mut">Planı olmayan işler yukarıdaki genel bölümlere dağıtılır. Planı kaldırmak için bölümleri boş bırakıp kaydedin.</p></details></div></div><div class="bt-tools"><button type="button" class="btn mavi" id="btGetir">Seçili listeleri getir</button><button type="button" class="btn" id="btDurdur" disabled>Durdur</button><button type="button" class="btn" id="btDagit">Kişilere dağıt</button><button type="button" class="btn" id="btExcel" disabled>Tek Excel indir (.xlsx)</button></div><p id="btDurum" role="status">İş seçimi bekleniyor.</p><div id="btSonuc"></div>';
$('gruplar').before(box);
$('btVarSec').onclick=function(){isler.forEach(function(j){if(j.sayi>0)secili.add(j.id);});imza='';yenile();};$('btHepsi').onclick=function(){isler.forEach(function(j){secili.add(j.id);});imza='';yenile();};$('btSecimSil').onclick=function(){secili.clear();imza='';yenile();};
$('btGetir').onclick=guvenli(listeleriGetir);$('btDurdur').onclick=function(){durdur=true;bilgi('Mevcut istek bitince durdurulacak.');};$('btDagit').onclick=guvenli(dagit);$('btExcel').onclick=guvenli(excel);$('btKaydet').onclick=guvenli(kaydet);$('btSatir').onclick=satirEkle;$('btPlanKaydet').onclick=guvenli(planKaydet);$('btPlanIs').onchange=planCiz;
$('btBolum').onchange=personelCiz;$('btTekrarOku').onclick=bolumSecCiz;$('btYeniBolum').onclick=guvenli(function(){var b=prompt('Yeni bölüm adı:');if(!b||!b.trim())return;b=b.trim();var o=personel();if(Object.prototype.hasOwnProperty.call(o.bolumler,b))throw Error('Bölüm zaten var.');if(['__proto__','constructor','prototype'].includes(b))throw Error('Başka bir bölüm adı seçin.');o.bolumler[b]=[];o.aktif=b;yaz(BKEY,o);bolumSecCiz();});
$('btHazir').onclick=guvenli(function(){var o=personel();Object.keys(HAZIR_DAGILIM).forEach(function(b){if(!o.bolumler[b]||!o.bolumler[b].length)o.bolumler[b]=HAZIR_DAGILIM[b].map(function(p){return {bas:p[0]?p[0]+'0000000':'',bit:p[1]?p[1]+'9999999':'',kisi:p[2]};});});if(!(o.aktifler||[]).length)o.aktifler=['KDV-ÖTV İade'];if(!o.bolumler[o.aktif])o.aktif='KDV-ÖTV İade';yaz(BKEY,o);bolumSecCiz();bilgi('Hazır bölümler eklendi; dolu personel listeleri korundu.');});
window.addEventListener('takkom-bekleyen-degisti',yenile);window.addEventListener('storage',function(e){if(e.key===BKEY&&!mesgul)bolumSecCiz();});bolumSecCiz();yenile();
})();
