/* VDK-EK 1: komut, alan adları ve akış kodları kullanıcının sağladığı
   GİB ağ kaydı ve ekran tanımlarından alınmıştır. Oturum/örnek kayıt saklanmaz. */
(function(){
  'use strict';
  var CMD='ozesEkBirService_vdkEkBirListesiGetir';
  var AKIS=[
    ['V01','VD’ye bilgilendirilmesi'],
    ['V10','Taslak olarak kaydedilmiş'],
    ['V15','Müdür onayında reddedilmiş'],
    ['V20','Müdür onayına gönderilmiş'],
    ['V25','Defterdarlıktan VD’ye geri gönderilmiş'],
    ['V30','Müdür onaylamış, Defterdarlığa gönderilmiş'],
    ['V60','Yetkili onaylamış'],
    ['VE4','Eksiklik Yazısı Başlatılmış (Ana Mükellef)'],
    ['VE5','Eksiklik Yazısı Başlatılmış'],
    ['V03','VDK Tarafından Düzeltilmiş EK 1'],
    ['V55','Kısmen onaylanmış'],
    ['VVDB','Defterdarlıkta işlem sürüyor']
  ];
  var sayilar={},yukleme=null,yukleniyor=false,sonBilgi='',detayNo=0;
  function el(tag,cls,text){var n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
  function bosKriter(akis){return {vdIlKodu:document.getElementById('vdTx').textContent,basVkn:'',bitVkn:'',basTckn:'',bitTckn:'',akisDurumu:akis,girisNedeni:'',parafSayisi:'',vdGelisTarihiBas:'',vdGelisTarihiBit:'',raporTarihiBas:'',raporTarihiBit:'',createOptimeBas:'',createOptimeBit:'',lastUpdateOptimeBas:'',lastUpdateOptimeBit:'',listFilter:'VD_MEMUR',respKeyParam:'liste'};}
  function oku(r){
    if(!r||r.error)throw new Error(hataMetni(r)||'VDK yanıtı alınamadı.');
    var d=r.data,t=d&&(d.toplam!=null?d.toplam:d.totalCount);
    if(!d||!Array.isArray(d.liste)||t===null||t===undefined||t===''||!/^\d+$/.test(String(t)))throw new Error('VDK liste yanıtı veya kayıt toplamı okunamadı.');
    return d;
  }
  function kriter(){
    var k=bosKriter(v('v1Akis'));
    [['Gel','VD Geliş Tarihi'],['Rap','Rapor Tarihi'],['Olus','Oluşturma Tarihi'],['Gun','Son Güncelleme']].forEach(function(a){
      var b=v('v1'+a[0]+'Bas'),s=v('v1'+a[0]+'Bit');
      if(b&&s&&b>s)throw new Error(a[1]+': başlangıç tarihi bitiş tarihinden sonra olamaz.');
    });
    return Object.assign(k,{basVkn:v('v1VknBas'),bitVkn:v('v1VknBit'),basTckn:v('v1TcBas'),bitTckn:v('v1TcBit'),girisNedeni:v('v1Giris'),parafSayisi:v('v1Paraf'),vdGelisTarihiBas:d8('v1GelBas'),vdGelisTarihiBit:d8('v1GelBit'),raporTarihiBas:d8('v1RapBas'),raporTarihiBit:d8('v1RapBit'),createOptimeBas:d8('v1OlusBas'),createOptimeBit:d8('v1OlusBit'),lastUpdateOptimeBas:d8('v1GunBas'),lastUpdateOptimeBit:d8('v1GunBit')});
  }
  function kutuMetni(t){document.getElementById('vdk1Kutu').textContent=t;document.getElementById('v1Say').textContent='';}
  function listeAc(akis){
    listeTemizle('vdk1');document.getElementById('v1Akis').value=akis;
    sekmeAc('vdk1');listeSorgula('vdk1');
  }
  function sayilariCiz(){
    var ul=document.getElementById('vdkAkislar');if(!ul)return;
    ul.textContent='';var toplam=0,bilinen=0,gorunen=0;
    var sadece=document.getElementById('sadeceVar').checked;
    AKIS.forEach(function(a){
      var x=sayilar[a[0]],hazir=!!x&&typeof x.sayi==='number';
      if(hazir){toplam+=x.sayi;bilinen++;}
      if(sadece&&hazir&&x.sayi===0)return;
      gorunen++;
      var li=el('li'),b=el('button','vdk-akis'+(hazir&&x.sayi>0?' var':''));
      b.type='button';b.dataset.vdkAkis=a[0];
      b.appendChild(el('span','',a[1]));
      var n=el('span','vdk-sayi',hazir?String(x.sayi):(x&&x.hata?'Alınamadı':'—'));b.appendChild(n);
      b.setAttribute('aria-label',a[1]+': '+(hazir?x.sayi+' kayıt':(x&&x.hata?'sayı alınamadı':'sayı henüz alınmadı'))+'; listeyi aç');
      if(x&&x.hata)b.title=x.hata;
      b.onclick=function(){listeAc(a[0]);};li.appendChild(b);ul.appendChild(li);
    });
    if(!gorunen)ul.appendChild(el('li','vdk-bos','Seçili görünümde kayıt yok.'));
    var toplamEl=document.getElementById('vdkToplam');
    toplamEl.textContent=bilinen===AKIS.length?String(toplam):(bilinen?toplam+'+':'—');
    toplamEl.title=bilinen===AKIS.length?'12 akışın toplam kayıt sayısı':'Tüm akışların sayısı henüz alınmadı.';
    document.getElementById('vdkSayimDurum').textContent=yukleniyor?'Akış sayıları alınıyor… '+bilinen+' / '+AKIS.length:sonBilgi;
    document.getElementById('vdkSayYenile').disabled=yukleniyor;
  }
  function sayilariGetir(){
    if(yukleme)return yukleme;
    sayilar={};sonBilgi='';
    if(!gibTokenGetir()){sonBilgi='Sayıları almak için GİB oturumu gerekir.';sayilariCiz();return Promise.resolve();}
    yukleniyor=true;sayilariCiz();
    yukleme=(async function(){
      var index=0;
      async function isci(){
        while(index<AKIS.length){
          var a=AKIS[index++];
          try{
            var r=await ozes(CMD,Object.assign(bosKriter(a[0]),{pv:{start:0,limit:10,sorters:[]}}));
            var d=oku(r);sayilar[a[0]]={sayi:Number(d.toplam!=null?d.toplam:d.totalCount)};
          }catch(e){sayilar[a[0]]={hata:e.message||'Sayı alınamadı.'};}
          sayilariCiz();
        }
      }
      try{
        await Promise.all([isci(),isci(),isci()]);
        var hatalar=AKIS.filter(function(a){return sayilar[a[0]]&&sayilar[a[0]].hata;}).length;
        sonBilgi=hatalar?hatalar+' akışın sayısı alınamadı. Sayıları Yenile ile tekrar deneyin.':'12 akış güncellendi • '+new Date().toLocaleTimeString('tr-TR');
      }finally{yukleniyor=false;yukleme=null;sayilariCiz();}
    })();
    return yukleme;
  }
  function tablo(baslik,kol,satirlar){
    var bolum=el('section');bolum.appendChild(el('h4','',baslik));
    if(!satirlar.length){bolum.appendChild(el('p','','Kayıt yok.'));return bolum;}
    var t=el('table','lst'),head=el('thead'),tr=el('tr');
    kol.forEach(function(c){tr.appendChild(el('th','',c[0]));});head.appendChild(tr);t.appendChild(head);
    var body=el('tbody');satirlar.forEach(function(r){var row=el('tr');kol.forEach(function(c){row.appendChild(el('td','sol',c[2]?c[2](r[c[1]]):String(r[c[1]]==null?'':r[c[1]])));});body.appendChild(row);});
    t.appendChild(body);bolum.appendChild(t);return bolum;
  }
  async function detayGoster(oid,tur){
    var dialog=document.getElementById('vdkDetay'),icerik=document.getElementById('vdkDetayIcerik'),no=++detayNo;
    document.getElementById('vdkDetayBaslik').textContent=tur==='ozet'?'EK 1 Formu Değerlendirme Özeti':'KEYS Sevk Günlük';
    icerik.textContent='Bilgiler alınıyor…';if(!dialog.open)dialog.showModal();
    try{
      var cmd=tur==='ozet'?'ozesEkBirService_ek1VdkDegerlendirmeListesiGetir':'ozesEkBirService_eksiklikYazisiKeysBilgiGetir';
      var r=await ozes(cmd,{oid:oid});
      if(no!==detayNo||!dialog.open)return;
      if(!r||r.error)throw new Error(hataMetni(r)||'Ayrıntı alınamadı.');
      var d=r.data;icerik.textContent='';
      if(tur==='ozet'){
        if(!Array.isArray(d))throw new Error('Değerlendirme özeti okunamadı.');
        var satirlar=d.map(function(x){return Object.assign({},x,{aciklama:String(x.degerlendirmeDurumu)==='1'?'Eksiklik Yazısı Başlatılmalıdır.':''});});
        icerik.appendChild(tablo('Değerlendirme',[['Alan','degerlendirmeAlanAdi'],['Durum','degerlendirmeDurumu',function(x){return String(x)==='1'?'Eksiklik var':String(x)==='0'?'Eksiklik yok':String(x||'');}],['Açıklama','aciklama']],satirlar));
      }else{
        if(!d||typeof d!=='object')throw new Error('KEYS sevk günlüğü okunamadı.');
        icerik.appendChild(tablo('Sevk Günlüğü',[['İşlem Zamanı','islemZamani',t14],['Gönderen Birim','gonderenBirimAdi'],['Açıklama','sevkAciklama'],['Alan Birim','alanBirimAdi'],['Durum','mevcutDurumuStr']],d.sevkGunlukListesi||[]));
        icerik.appendChild(tablo('Onay Listesi',[['Onay Tarihi','onayTarihi',t14],['Kullanıcı','onayKullanici'],['Birim','onayBirim'],['Onay Türü','onayTuru']],d.onayListesi||[]));
      }
    }catch(e){if(no===detayNo&&dialog.open)icerik.textContent='Bilgiler alınamadı: '+e.message;}
  }
  window.vdkSayilariGetir=sayilariGetir;
  window.vdkSayilariCiz=sayilariCiz;
  window.vdkEk1Init=function(){
    var bolum=document.getElementById('sek_ek1').cloneNode(true);bolum.id='sek_vdk1';
    bolum.querySelectorAll('[id]').forEach(function(n){n.id=n.id==='ek1Kutu'?'vdk1Kutu':n.id.replace(/^e1/,'v1');});
    var form=bolum.querySelector('.form'),olus=el('div');
    olus.appendChild(el('label','','Oluşturma Tarihi'));
    ['Bas','Bit'].forEach(function(ek,i){if(i)olus.appendChild(document.createTextNode(' – '));var n=el('input');n.type='date';n.id='v1Olus'+ek;n.setAttribute('aria-label','Oluşturma tarihi '+(i?'bitiş':'başlangıç'));olus.appendChild(n);});
    form.insertBefore(olus,bolum.querySelector('#v1GunBas').parentElement);
    var akis=bolum.querySelector('#v1Akis');akis.classList.remove('akisSec');akis.textContent='';
    var hepsi=el('option','','Tüm akış durumları');hepsi.value='';akis.appendChild(hepsi);
    AKIS.forEach(function(a){AKIS_AD[a[0]]=a[1];var o=el('option','',a[1]);o.value=a[0];akis.appendChild(o);});akis.value='V01';
    var ned=el('option','','005 - Defter Belge İbraz Etmeme');ned.value='005';bolum.querySelector('#v1Giris').appendChild(ned);
    bolum.querySelector('#v1Ara').placeholder='listede ara: VKN / unvan / rapor no / açıklama';
    document.getElementById('sek_ek1').before(bolum);
    LISTELER.vdk1={ad:'VDK-EK 1',cmd:CMD,p:'v1',ilkAkis:'V01',limit:10,sayisalLimit:true,kriter:kriter,oku:oku,
      anahtar:function(r){return r.oid;},
      bosMetin:'Kriterleri seçip Sorgula’ya basın. Tüm sayfalar alınır; aynı formun parafları tek satırda birleştirilir.',
      metin:['vkn','tckn','raporDefterNo','raporNo','vdKodu','vergiKodu'],uzun:'aciklama',
      ara:['vkn','tckn','unvan','raporNo','raporDefterNo','girisNedeni','akisDurumu','aciklama','kullaniciKodu'],
      kol:[['Giriş Nedeni','girisNedeni',gNed],['VD Geliş Tarihi','vdGelisTarihi',t8],['Rapor Tarihi','raporTarihi',t8],['Rapor Defter Numarası','raporDefterNo'],['Rapor Numarası','raporNo'],['Rapor Türü','raporTuru'],
        ['Vergi Kimlik Numarası','vkn'],['T.C. Kimlik Numarası','tckn'],['Unvan','unvan'],['Vergi Dairesi','vdKodu'],['Akış Durumu','akisDurumu',function(x){return AKIS_AD[x]||x;}],['Dönem','donemAraligi',donemTx],['Kullanıcı Adı','kullaniciKodu'],['Oluşturulma Tarihi','createOptime',t14],['Son Güncellenme Tarihi','lastUpdateOptime',t14],
        ['EK 1 Formu Değerlendirme Özeti','__vdkOzet',null,function(){return 'Ayrıntı sorgusu';}],['KEYS Sevk Günlük','__vdkKeys',null,function(r){return r.eksiklikTalebiGoruntule?'Var':'Yok';}],['Vergi Kodu','vergiKodu'],['Tarhiyat Tutarı','tarhiyatTutari',para],['Açıklama','aciklama']],
      baslat:function(){kutuMetni('VDK-EK 1 listesi alınıyor…');},hata:function(e){kutuMetni('Liste alınamadı: '+e.message);},
      hucre:function(c,r){
        var tur=c[1]==='__vdkOzet'?'ozet':c[1]==='__vdkKeys'?'keys':'';
        if(!tur)return null;if(tur==='keys'&&!r.eksiklikTalebiGoruntule)return 'Yok';
        return '<button type="button" class="btn" data-vdk-detay="'+tur+'" data-vdk-oid="'+esc(r.oid)+'">Görüntüle</button>';
      },
      bagla:function(kutu){kutu.querySelectorAll('[data-vdk-detay]').forEach(function(b){b.onclick=function(){detayGoster(b.dataset.vdkOid,b.dataset.vdkDetay);};});}
    };
    var kart=el('section','grup vdk-grup');kart.id='vdkBekleyen';kart.setAttribute('aria-label','VDK-EK 1 akışlara göre kayıt sayıları');
    var h=el('h3');h.appendChild(el('span','','VDK-EK 1'));var top=el('span','say','—');top.id='vdkToplam';h.appendChild(top);kart.appendChild(h);
    var ust=el('div','vdk-sayim-ust');ust.appendChild(el('span','mut','Tüm akış durumlarındaki kayıt sayıları'));
    var yenile=el('button','btn','Sayıları Yenile');yenile.type='button';yenile.id='vdkSayYenile';yenile.onclick=sayilariGetir;ust.appendChild(yenile);kart.appendChild(ust);
    var ul=el('ul','vdk-akis-liste');ul.id='vdkAkislar';kart.appendChild(ul);
    var durum=el('p','mut vdk-sayim-durum','Bekleyen İşleri Getir ile sayılar güncellenir.');durum.id='vdkSayimDurum';durum.setAttribute('role','status');kart.appendChild(durum);
    document.getElementById('gruplar').after(kart);sonBilgi=durum.textContent;sayilariCiz();
    var dialog=el('dialog','vdk-detay');dialog.id='vdkDetay';dialog.setAttribute('aria-labelledby','vdkDetayBaslik');
    var bas=el('div','vdk-detay-baslik'),title=el('h3');title.id='vdkDetayBaslik';bas.appendChild(title);
    var kapat=el('button','btn','Kapat');kapat.type='button';kapat.onclick=function(){dialog.close();};bas.appendChild(kapat);dialog.appendChild(bas);
    var ic=el('div');ic.id='vdkDetayIcerik';dialog.appendChild(ic);dialog.addEventListener('close',function(){detayNo++;});document.body.appendChild(dialog);
  };
})();
