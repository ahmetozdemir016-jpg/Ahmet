/* TAKKOM rapor köprüsü: tanımlı GİB adreslerinden PDF/rapor okur; TDİ için yalnızca iki listeleme komutunu çalıştırır. */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'TK_TDI_FETCH') {
    if (!['tdiService_raporTalepleriniListele','tdiService_raporSonucGoster'].includes(msg.cmd)) {sendResponse({ok:false,error:'TDİ sorgusu desteklenmiyor'});return;}
    const jp=msg.cmd==='tdiService_raporSonucGoster'?{requestID:String(msg.jp&&msg.jp.requestID||'')}:{};
    if(msg.cmd==='tdiService_raporSonucGoster'&&!/^\d+$/.test(jp.requestID)){sendResponse({ok:false,error:'Rapor kimliği geçersiz'});return;}
    const body=new URLSearchParams({cmd:msg.cmd,jp:JSON.stringify(jp),token:String(msg.token||''),callid:'tdi'+Date.now()});
    fetch('http://keys.ggm.bim/gibintranet_server/dispatch',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),credentials:'include',cache:'no-store'}).then(async r=>sendResponse({ok:r.ok,status:r.status,text:await r.text()})).catch(()=>sendResponse({ok:false,error:'TDİ bağlantı hatası'}));return true;
  }
  if (msg && msg.type === 'TK_MD_FETCH') { /* Merkezi Denetim (YBS VD Ön Kontrol) JSON servisleri: POST, token başlıkları sayfadan gelir */
    const murl = String(msg.url || '');
    if (!/^http:\/\/gibintranet\.gelirler\.gov\.tr:32505\/gibintranet\/authgateway\//i.test(murl)) { sendResponse({ ok: false, error: 'izin verilmeyen adres' }); return; }
    const hdr = { 'Content-Type': 'application/json', 'Accept': 'application/json, text/plain, */*' };
    if (msg.token) { hdr['Authorization'] = 'Bearer ' + msg.token; hdr['X-Auth-Token'] = msg.token; }
    fetch(murl, { method: 'POST', headers: hdr, body: msg.body == null ? '' : String(msg.body), credentials: 'include', cache: 'no-store' })
      .then(async r => sendResponse({ ok: r.ok, status: r.status, text: await r.text() }))
      .catch(e => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  if (!msg || msg.type !== 'TK_PDF_FETCH') { sendResponse({ ok: false, error: 'bilinmeyen mesaj: ' + (msg && msg.type) }); return; }
  const url = String(msg.url || '');
  if (!/^http:\/\/(eyoklama\.gelirler\.gov\.tr(:32516)?\/|10\.251\.63\.99\/evdorapor_server\/pdf|keys\.ggm\.bim\/evdorapor_server\/pdf|keys\.ggm\.bim\/etebligat_server\/|10\.251\.67\.110:30080\/ebyn\/|10\.251\.63\.99\/gibintranet_server\/|keys\.ggm\.bim\/gibintranet_server\/)/i.test(url)) { sendResponse({ ok: false, error: 'izin verilmeyen adres' }); return; }
  fetch(url, { method: 'GET', credentials: 'include', cache: 'no-store', redirect: 'follow' })
    .then(async r => {
      const ct = r.headers.get('content-type') || '';
      const buf = await r.arrayBuffer();
      const u8 = new Uint8Array(buf); let bin = '';
      for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
      sendResponse({ ok: r.ok, status: r.status, contentType: ct, base64: btoa(bin) });
    })
    .catch(e => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});
