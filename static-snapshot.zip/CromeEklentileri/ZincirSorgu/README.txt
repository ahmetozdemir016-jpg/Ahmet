Kurulum:
1. chrome://extensions
2. Geliştirici modu
3. Paketlenmemiş öğe yükle
4. Bu klasörü seç
5. Sayfayı yenile

Özellik:
- Sağ altta "Zincir Sorgu" açıcı düğmesi
- Sağ üstte kabuk panel
- Küçült / kapat
- İç zincir sorgu panelini birlikte göster/gizle
