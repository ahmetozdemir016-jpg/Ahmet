
(() => {
  'use strict';
  if (window.__zincirSorguExtV4Loaded) return;
  window.__zincirSorguExtV4Loaded = true;

  const run = () => {
/* ==========================================================================
       GİB HİBRİT MOTOR - V50.11 (SENIOR PATCH)
       Features:
       - FIXED: Memory leak & DOM performance issues (appendRow refactor)
       - FIXED: Logic scope issues in nested loops (processSingleId)
       - IMPROVED: Audio Context handling for browser autoplay policies
       ========================================================================== */
    const SERVICE_COUNT = 4;
    const $ = s => {
      if (s == null) return null;
      const str = String(s);
      if (str.startsWith('#') || str.startsWith('.') || str.startsWith('[') || str.includes(' ')) {
        return document.querySelector(str);
      }
      return document.getElementById(str);
    };
    let isRunning=false, stopRequested=false, lastIndex=0, ids=[], rowsOut=[];
    let fieldLists = Array(SERVICE_COUNT+1).fill(null).map(()=>[]);
    let selected   = Array(SERVICE_COUNT+1).fill(null).map(()=>[]);
    let columnsConfig = [], waitMsGlobal = 1500;
    let discoveriesBySvc = Array(SERVICE_COUNT+1).fill(null).map(()=>[]);
    let chosenPathBySvc  = Array(SERVICE_COUNT+1).fill('');

    const TPL_KEY = 'gib4sorgu_tpls_v49';
    const SESS_KEY = 'gib4sorgu_session_v49';
    
    // --- SES SİSTEMİ (AUDIO CONTEXT) İYİLEŞTİRMESİ ---
    let audioCtx = null;
    function initAudio() {
        if (!audioCtx) {
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                audioCtx = new AudioContext();
            } catch (e) {
                console.warn("Web Audio API desteklenmiyor.");
            }
        }
        if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
    }

    function playTone(freq=600, dur=0.1, type='sine') {
        if(!$('#soundMode').checked) return;
        if(!audioCtx) return; 
        
        try {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = type; 
            osc.frequency.value = freq;
            osc.connect(gain); 
            gain.connect(audioCtx.destination);
            
            const now = audioCtx.currentTime;
            osc.start(now); 
            gain.gain.setValueAtTime(0.1, now); 
            gain.gain.exponentialRampToValueAtTime(0.00001, now + dur);
            osc.stop(now + dur);
        } catch(e) { /* silent fail */ }
    }
    
    function playSuccess() { playTone(800, 0.1); setTimeout(()=>playTone(1200, 0.2), 100); }
    function playError() { playTone(200, 0.3, 'sawtooth'); }
    function playDone() { playTone(500,0.1); setTimeout(()=>playTone(500,0.1), 150); setTimeout(()=>playTone(800,0.4), 300); }

    // --- UTILITY FUNCTIONS ---
    function parseToken(s){ 
        if(!s)return''; 
        const i=s.indexOf('token='); 
        return i>=0?s.substring(i+6).split(/[&#\s]/)[0]:s.trim(); 
    }
    
    function wait(ms){ return new Promise(r=>setTimeout(r,ms)); }

    function getHumanWaitTime(baseTime) {
        const isHuman = $('#humanMode')?.checked;
        if (!isHuman) return baseTime;
        const variance = baseTime * 0.3;
        let randomWait = baseTime + ((Math.random() * variance * 2) - variance);
        if (Math.random() < 0.10) { randomWait += (500 + Math.random() * 1500); }
        return Math.floor(randomWait);
    }

    function makeCallIdSafe() { return Date.now(); }
    
    function nextCallIdFromInputs(baseInput, counterInput){
      const base = (baseInput?.value || '').trim(); const n = parseInt((counterInput?.value ?? '9'), 10);
      const counter = (isNaN(n) || n < 0) ? 9 : n;
      if(!base) return makeCallIdSafe();
      const callid = String(base) + "_" + String(counter);
      if(counterInput) counterInput.value = String(counter + 1); return callid;
    }

    function getPayloadRoot(obj){
      if (obj == null) return obj;
      if (typeof obj !== 'object') return obj;
      if (obj.data !== undefined && obj.data !== null) return obj.data;
      return obj;
    }

    function getSmart(obj, path){
      const root = getPayloadRoot(obj);
      let v = get(root, path);
      if (v == null) v = get(obj, path);
      return v;
    }

    function getArraySmart(obj, path){
      const root = getPayloadRoot(obj);
      if (!path) {
        if (Array.isArray(root)) return root;
        if (root && Array.isArray(root.data)) return root.data;
        return root ? [root] : [];
      }
      const v1 = get(root, path);
      if (v1 != null) return ensureArray(v1);
      const v2 = get(obj, path);
      if (v2 != null) return ensureArray(v2);
      return [];
    }

    function autoFillAuth(){
      try {
        const qs = new URLSearchParams(location.search);
        const t = qs.get('token');
        if (t && $('#token') && !$('#token').value.trim()) {
          $('#token').value = t;
        }
        const jsidMatch = document.cookie.match(/(?:^|;\s*)JSESSIONID=([^;]+)/i);
        if (jsidMatch && $('#cookie') && !$('#cookie').value.trim()) {
          $('#cookie').value = 'JSESSIONID=' + jsidMatch[1];
        }
      } catch(e) {
        console.warn('autoFillAuth hata', e);
      }
    }

    function collectKeysFromSample(arr, fallbackRec, opts = {}) {
      const maxItems = Math.max(1, parseInt(opts.maxItems || 8, 10));
      const out = new Set();

      const list = Array.isArray(arr) ? arr.slice(0, maxItems) : [];
      if (!list.length && fallbackRec && typeof fallbackRec === 'object') {
        collectKeysDeep(fallbackRec, '', out, { maxDepth: 14, maxArrayDepth: 4, includeLeafOnly: true });
        return Array.from(out).sort();
      }

      for (const item of list) {
        if (item && typeof item === 'object') {
          collectKeysDeep(item, '', out, { maxDepth: 14, maxArrayDepth: 4, includeLeafOnly: true });
        }
      }

      if (!out.size && fallbackRec && typeof fallbackRec === 'object') {
        collectKeysDeep(fallbackRec, '', out, { maxDepth: 14, maxArrayDepth: 4, includeLeafOnly: true });
      }

      return Array.from(out).sort();
    }

    function isUsefulField(path) {
      if (!path) return false;
      const p = String(path).trim();
      if (!p) return false;
      const blocked = new Set(['data','list','liste','motorluTasit','tapu','isMakinalari','sivilHavacilik','denizTasit']);
      return !blocked.has(p);
    }

    function ensureRowMeta(row, rowKey){
      row.__rowKey = String(row.__rowKey || rowKey || '').trim();
      row.__svcErrors = row.__svcErrors || {};
      row.__recs = row.__recs || {};
      return row;
    }

    function upsertResultRow(newRow){
      const key = String(newRow.__rowKey || '').trim();
      if (!Array.isArray(resultRows)) resultRows = [];
      if (!key) {
        resultRows.push(newRow);
        return;
      }

      const idx = resultRows.findIndex(r => String(r.__rowKey || '').trim() === key);
      if (idx < 0) {
        resultRows.push(newRow);
        return;
      }

      const oldRow = resultRows[idx];
      Object.keys(newRow).forEach(k => {
        if (k === '__svcErrors' || k === '__recs') return;
        const v = newRow[k];
        if (v !== undefined && v !== null && String(v) !== '') {
          oldRow[k] = v;
        }
      });

      oldRow.__svcErrors = Object.assign({}, oldRow.__svcErrors || {}, newRow.__svcErrors || {});
      oldRow.__recs = Object.assign({}, oldRow.__recs || {}, newRow.__recs || {});
    }

    function getFailedRows(){
      return (Array.isArray(resultRows) ? resultRows : []).filter(r =>
        Object.values(r.__svcErrors || {}).some(Boolean)
      );
    }

    function updateExecutionModeLabel(){
      const tc = Math.max(1, parseInt($('#threadCount')?.value || '1', 10) || 1);
      const stat = $('#stat');
      if (!stat) return;
      stat.textContent = tc === 1 ? 'Sıralı Mod' : ('Paralel Mod (' + tc + ' thread)');
    }

    function migrateLegacySessionOnce(){
      const FLAG = 'gib4sorgu_migrated_sess_v50';
      if (localStorage.getItem(FLAG) === '1') return;
      localStorage.setItem(FLAG, '1');
    }
    
    function saveSession(showToastMsg=false){
      try {
        const cfg = collectConfigFromUI();
      if (cfg?.classic) { cfg.classic.token = ''; cfg.classic.cookie = ''; cfg.classic.ids = ''; }
        localStorage.setItem(SESS_KEY, JSON.stringify(cfg));
        if (showToastMsg) showToast('Oturum kaydedildi.', 'success');
        log('OTURUM', 'Kaydedildi');
      } catch(e) {
        showToast('Oturum kaydedilemedi: ' + e.message, 'error');
      }
    }

    function loadSession(showToastMsg=false){
      try {
        const raw = localStorage.getItem(SESS_KEY);
        if (!raw) { if (showToastMsg) showToast('Kayıtlı oturum yok.', 'error'); return; }
        let cfg;
        try { cfg = JSON.parse(raw); }
        catch(e) { if (showToastMsg) showToast('Oturum bozuk (JSON).', 'error'); return; }
        applyConfigToUI(cfg);
        if (showToastMsg) showToast('Oturum yüklendi.', 'success');
        log('OTURUM', 'Yüklendi');
      } catch(e) {
        showToast('Oturum yüklenemedi: ' + e.message, 'error');
      }
    }

    window.addEventListener('error', (ev) => { try { log('JS-ERROR', (ev&&ev.message)?ev.message:'Hata'); } catch(_) {} });

    function escapeHtml(text) {
        if (text == null) return '';
        return String(text)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function showToast(msg, type = 'info') {
        const map = { ok: 'success', err: 'error', warn: 'info' };
        const finalType = map[type] || type || 'info';
        const container = $('#toast-container');
        const toast = document.createElement('div');
        toast.className = 'toast' + (finalType === 'error' ? ' err' : finalType === 'success' ? ' ok' : '');
        toast.textContent = msg; container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 300); }, 3000);
    }
    
    function toast(msg, type='info') { showToast(msg, type); }

    function get(obj, path, defaultValue = '') {
        if (obj == null) return defaultValue;
        const raw = String(path || '').trim();
        if (!raw) return obj;

        const candidates = [raw];
        if (raw.startsWith('data.')) candidates.push(raw.slice(5));
        else candidates.push('data.' + raw);

        const toParts = (p) => String(p || '')
            .replace(/\[(\d+)\]/g, '.$1')
            .replace(/^\./, '')
            .split('.')
            .filter(Boolean);

        const read = (base, parts, idx) => {
                if (idx >= parts.length) return base;
                if (base == null) return undefined;

                const token = String(parts[idx] || '').trim();
                if (!token) return read(base, parts, idx + 1);

                const parseFilter = (t) => {
                    const tt = String(t || '').trim();
                    if (tt.startsWith('{') && tt.endsWith('}')) return { wild: false, expr: tt.slice(1, -1).trim() };
                    if (tt.startsWith('*{') && tt.endsWith('}')) return { wild: true, expr: tt.slice(2, -1).trim() };
                    return null;
                };

                const unquote = (s) => {
                    const v = String(s ?? '').trim();
                    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) return v.slice(1, -1);
                    return v;
                };

                const matchFilter = (item, expr) => {
                    const e = String(expr || '').trim();
                    if (!e) return true;
                    const parts = e.split(',').map(x => x.trim()).filter(Boolean);
                    for (const part of parts) {
                        const m = part.match(/^(.+?)(==|=)(.+)$/);
                        if (!m) continue;
                        const keyPath = String(m[1]).trim();
                        const wantRaw = unquote(m[3]);
                        const got = (function getSimple(o, pathStr){
                            const ps = String(pathStr||'').replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
                            let cur = o;
                            for (const k of ps) {
                                if (cur == null) return undefined;
                                const kk = /^\d+$/.test(k) ? Number(k) : k;
                                cur = cur[kk];
                            }
                            return cur;
                        })(item, keyPath);

                        if (got === undefined || got === null) return false;
                        const gotStr = String(got);
                        const gotNum = Number(gotStr);
                        const wantNum = Number(wantRaw);
                        if (!Number.isNaN(gotNum) && !Number.isNaN(wantNum)) {
                            if (gotNum !== wantNum) return false;
                        } else {
                            if (gotStr !== String(wantRaw)) return false;
                        }
                    }
                    return true;
                };

                const f = parseFilter(token);
                if (f) {
                    const arr = Array.isArray(base) ? base : (base && typeof base === 'object' ? Object.values(base) : []);
                    const matches = arr.filter(it => it && typeof it === 'object' && matchFilter(it, f.expr));
                    if (f.wild) {
                        const out = [];
                        for (const it of matches) {
                            const v = read(it, parts, idx + 1);
                            if (Array.isArray(v)) out.push(...v);
                            else if (v !== undefined) out.push(v);
                        }
                        return out;
                    }
                    const first = matches.length ? matches[0] : undefined;
                    return read(first, parts, idx + 1);
                }

                if (token === '*') {
                    if (!Array.isArray(base)) return undefined;
                    const results = [];
                    for (const it of base) {
                        const v = read(it, parts, idx + 1);
                        if (Array.isArray(v)) results.push(...v);
                        else if (v !== undefined) results.push(v);
                    }
                    return results;
                }

                const k = (/^\d+$/.test(token)) ? Number(token) : token;
                return read(base ? base[k] : undefined, parts, idx + 1);

        };

        for (const cand of candidates) {
            const parts = toParts(cand);
            const v = read(obj, parts, 0);
            if (v !== undefined && v !== null) {
                if (Array.isArray(v) && v.length === 0) continue;
                return v;
            }
        }
        return defaultValue;
    }

    function resolvePlaceholdersInString(str, idValue, recs) {
        let s = String(str ?? '');
        const id = (idValue == null) ? '' : String(idValue);
        const bag = recs || {};
        s = s.replace(/\[ID\]/g, id);
        const pick = (svcNum, path) => {
            const rec0 = bag[svcNum] || bag[String(svcNum)] || null;
            if (!rec0) return '';
            const p = String(path||'').trim();
            const candidates = [];
            candidates.push({ base: rec0, path: p });
            if (rec0 && typeof rec0 === 'object' && 'data' in rec0) {
                candidates.push({ base: rec0, path: 'data.' + p });
                const d = rec0.data;
                if (Array.isArray(d) && d.length) candidates.push({ base: d[0], path: p });
            }
            if (p.startsWith('data.')) candidates.push({ base: rec0, path: p.slice(5) });
            for (const c of candidates) {
                const v = get(c.base, c.path, '');
                if (v !== '' && v !== undefined && v !== null) return v;
            }
            const v2 = get(rec0, p, '');
            return (v2 === undefined || v2 === null) ? '' : v2;
        };
        s = s.replace(/\[\[S([1-5])\:([^\]]+)\]\]/g, (_m, svc, path) => {
            const v = pick(Number(svc), String(path).trim());
            if (typeof v === 'object') {
                try { return JSON.stringify(v); } catch (_) { return ''; }
            }
            if (typeof v === 'number' || typeof v === 'boolean') return String(v);
            return String(v ?? '');
        });
        s = s.replace(/\[S([1-5])\:([^\]]+)\]/g, (_m, svc, path) => {
            const v = pick(Number(svc), String(path).trim());
            if (Array.isArray(v)) {
                const allPrim = v.every(x => x === null || x === undefined || ['string','number','boolean'].includes(typeof x));
                if (allPrim) return v.filter(x=>x!==undefined && x!==null).map(x=>String(x)).join(', ');
                try { return JSON.stringify(v); } catch (_) { return ''; }
            }
            if (typeof v === 'object') {
                try { return JSON.stringify(v); } catch (_) { return ''; }
            }
            return String(v ?? '');
        });
        return s;
    }

    let __activeTplTextarea = null;
    function insertAtCursor(el, text) {
        const start = (typeof el.selectionStart === 'number') ? el.selectionStart : el.value.length;
        const end = (typeof el.selectionEnd === 'number') ? el.selectionEnd : el.value.length;
        el.value = el.value.slice(0, start) + text + el.value.slice(end);
        if (typeof el.selectionStart === 'number') {
            el.selectionStart = el.selectionEnd = start + text.length;
        }
        el.focus();
    }
    function ensurePickerBox() {
        let box = document.getElementById('jpFieldPicker');
        if (box) return box;
        box = document.createElement('div');
        box.id = 'jpFieldPicker';
        box.style.cssText = 'position:absolute;z-index:99999;background:#0b1019;border:1px solid #3b475e;border-radius:6px;padding:6px;max-height:260px;overflow:auto;font-family:Consolas,monospace;font-size:12px;display:none;min-width:260px;box-shadow:0 10px 30px rgba(0,0,0,.5)';
        document.body.appendChild(box);
        document.addEventListener('mousedown', (e) => {
            const b = document.getElementById('jpFieldPicker');
            if (!b || b.style.display === 'none') return;
            if (b.contains(e.target)) return;
            if (__activeTplTextarea && __activeTplTextarea.contains(e.target)) return;
            b.style.display = 'none';
        });
        return box;
    }
    function normalizePickerPath(p){
        return String(p||'').replace(/\[\*\]/g, '.0').replace(/\[(\d+)\]/g, '.$1').replace(/\.\./g, '.').replace(/^\./, '').trim();
    }
    function makeDraggableItem(labelText, insertText) {
        const item = document.createElement('div');
        item.textContent = labelText;
        item.style.cssText = 'cursor:grab;padding:2px 4px;border-radius:4px;user-select:none;';
        item.draggable = true;
        item.onmouseenter = () => item.style.background = '#1e293b';
        item.onmouseleave = () => item.style.background = 'transparent';
        item.addEventListener('dragstart', (e) => {
            item.style.cursor = 'grabbing';
            try { e.dataTransfer.setData('text/plain', insertText); e.dataTransfer.effectAllowed = 'copy'; } catch (_) {}
        });
        item.addEventListener('dragend', () => { item.style.cursor = 'grab'; });
        item.onclick = () => {
            if (__activeTplTextarea) insertAtCursor(__activeTplTextarea, insertText);
            const box = document.getElementById('jpFieldPicker');
            if (box) box.style.display = 'none';
        };
        return item;
    }
    function showPickerForTextarea(textarea, svcList) {
        const box = ensurePickerBox();
        box.innerHTML = '';
        const title = document.createElement('div');
        title.textContent = 'Alan Seç (Sürükle-Bırak / Tıkla)';
        title.style.cssText = 'color:#ffd700;font-weight:700;margin:2px 0 8px;';
        box.appendChild(title);
        svcList.forEach(svc => {
            const fields = getSvcFieldsForPicker(svc) || [];
            if (!fields.length) return;
            const head = document.createElement('div');
            head.textContent = `S${svc}`;
            head.style.cssText = 'color:#6ea8fe;font-weight:bold;margin:8px 0 4px;';
            box.appendChild(head);
            const wildcardDone = new Set();
            fields.forEach(path => {
                const normalizedPath = normalizePickerPath(path);
                const insertText = `[S${svc}:${normalizedPath}]`;
                const item = makeDraggableItem(path, insertText);
                box.appendChild(item);
                const wc = normalizedPath.replace(/\.(\d+)\./, '.*.');
                if (wc !== normalizedPath && !wildcardDone.has(wc)) {
                    wildcardDone.add(wc);
                    const wcLabel = `${path}  (tümü)`;
                    const wcInsert = `[S${svc}:${wc}]`;
                    const wcItem = makeDraggableItem(wcLabel, wcInsert);
                    box.appendChild(wcItem);
                }
            });
        });
        const idItem = makeDraggableItem('[ID]', '[ID]');
        idItem.style.cssText += 'margin-top:10px;color:#a6e3a1;font-weight:700;';
        box.appendChild(idItem);
        const r = textarea.getBoundingClientRect();
        const top = Math.min(window.scrollY + r.bottom + 6, window.scrollY + window.innerHeight - 280);
        const left = Math.min(window.scrollX + r.left, window.scrollX + window.innerWidth - 300);
        box.style.left = left + 'px';
        box.style.top = top + 'px';
        box.style.display = 'block';
    }
    function bindTplPicker(id, svcList) {
        const ta = document.getElementById(id);
        if (!ta) return;
        ta.addEventListener('keydown', (e) => {
            if (e.key === '[') {
              e.preventDefault();
                __activeTplTextarea = ta;
                const anyFields = (svcList || []).some(s => (getSvcFieldsForPicker(s) || []).length);
                if (!anyFields) { toast('Önce 1) Ön İzleme yap (alanlar keşfedilsin). Sonra [ ile liste açılır.', 'warn'); }
                setTimeout(() => showPickerForTextarea(ta, svcList), 0);
            }
        });
        ta.addEventListener('focus', () => { __activeTplTextarea = ta; });
    }
    function bindDropToTpl(id) {
        const ta = document.getElementById(id);
        if (!ta) return;
        ta.addEventListener('dragover', (e) => { e.preventDefault(); ta.style.borderColor = 'var(--turbo)'; });
        ta.addEventListener('dragleave', () => { ta.style.borderColor = '#273048'; });
        ta.addEventListener('drop', (e) => {
            e.preventDefault();
            ta.style.borderColor = '#273048';
            const text = (e.dataTransfer && e.dataTransfer.getData('text/plain')) || '';
            if (!text) return;
            ta.focus();
            insertAtCursor(ta, text);
        });
    }

    /* --- CONFIG --- */
    function collectConfigFromUI() {
        const mode = document.querySelector('input[name="opMode"]:checked')?.value || 'normal';
        const cfg = { version: 'v50.11', mode, classic: {}, services: {}, columnsConfig: columnsConfig || [], selected: selected || [] };
        cfg.classic.token = '';
        cfg.classic.cookie = '';
        cfg.classic.ids = '';
        cfg.classic.callIdBase = $('#callIdBase')?.value || '';
        cfg.classic.callIdCounter = $('#callIdCounter')?.value || '9';
        cfg.classic.idType = $('#idType')?.value || 'vkn';
        cfg.classic.waitMs = $('#waitMs')?.value || '1500';
        cfg.classic.idColName = $('#idColName')?.value || '';
        cfg.classic.idPath = $('#idPath')?.value || '';
        cfg.classic.humanMode = $('#humanMode')?.checked || false;
        cfg.classic.threadCount = $('#threadCount')?.value || '1';
        cfg.classic.soundMode = $('#soundMode')?.checked || false;
        for (let i = 1; i <= SERVICE_COUNT; i++) {
            cfg.services[i] = {
                dispatch: $('#dispatch' + i)?.value || '',
                cmd: $('#cmd' + i)?.value || '',
                arrayPath: $('#arrayPath' + i)?.value || '',
                tpl: $('#tpl' + i)?.value || '',
                use: $('#useS' + i)?.checked || false,
                expand: $('#expand' + i)?.checked || false,
                filterPath: (i === 3 ? $('#filterPath3')?.value : ''),
                filterValues: (i === 3 ? $('#filterValues3')?.value : ''),
                s2OzelEsas: (i === 2 ? $('#s2OzelEsas')?.checked : false),
                s2SingleRow: (i === 2 ? $('#s2SingleRow')?.checked : false),
                s2AutoSave: (i === 2 ? $('#s2AutoSave')?.checked : false),
                oeMergeCols: (i === 2 ? $('#oeMergeCols')?.checked : false),
                oeMergeMode: (i === 2 ? $('#oeMergeMode')?.value : 'leaf'),
                oeFilter: (i === 2 ? $('#oeFilter')?.value : ''),
                smartStatus: (i === 2 ? $('#smartStatus')?.checked : false),            };
        }
        if (!$('#saveSecrets')?.checked) { cfg.classic.token = ''; cfg.classic.cookie = ''; }
        return cfg;
    }

    function applyConfigToUI(cfg) {
        if (!cfg) return;
        const classic = cfg.classic || {};
        const currentMode = document.querySelector('input[name="opMode"]:checked')?.value || 'normal';
        const hasNewFormat = !!cfg.classic;
        const applyClassic = hasNewFormat || currentMode === 'normal';
        if (applyClassic) {
            $('#token').value = classic?.token || '';
            $('#cookie').value = classic?.cookie || '';
            if (classic?.ids !== undefined) $('#ids').value = classic.ids;
            if (classic?.callIdBase !== undefined) $('#callIdBase').value = classic.callIdBase;
            if (classic?.callIdCounter !== undefined && $('#callIdCounter')) $('#callIdCounter').value = classic.callIdCounter || '9';
            if (classic?.idType !== undefined) $('#idType').value = classic.idType;
            if (classic?.waitMs !== undefined) $('#waitMs').value = classic.waitMs;
            if (classic?.idColName !== undefined) $('#idColName').value = classic.idColName;
            if (classic?.idPath !== undefined) $('#idPath').value = classic.idPath;
            if (classic?.humanMode !== undefined) $('#humanMode').checked = !!classic.humanMode;
            if (classic?.threadCount !== undefined) $('#threadCount').value = classic.threadCount;
            if (classic?.soundMode !== undefined) $('#soundMode').checked = !!classic.soundMode;
        }
        const services = cfg.services;
        if (services) {
            for (let i = 1; i <= SERVICE_COUNT; i++) {
                const s = services[i];
                if (!s) continue;
                if ($('#dispatch' + i)) $('#dispatch' + i).value = s.dispatch;
                if ($('#cmd' + i)) $('#cmd' + i).value = s.cmd;
                if ($('#arrayPath' + i)) $('#arrayPath' + i).value = s.arrayPath;
                if ($('#tpl' + i)) $('#tpl' + i).value = s.tpl;
                if ($('#useS' + i)) $('#useS' + i).checked = s.use;
                if ($('#expand' + i)) $('#expand' + i).checked = s.expand;
                if (i === 3) {
                    if ($('#filterPath3')) $('#filterPath3').value = s.filterPath || '';
                    if ($('#filterValues3')) $('#filterValues3').value = s.filterValues || '';
                }
                if (i === 2) {
                    if ($('#s2OzelEsas')) $('#s2OzelEsas').checked = !!s.s2OzelEsas;
                    if ($('#s2SingleRow')) $('#s2SingleRow').checked = !!s.s2SingleRow;
                    if ($('#s2AutoSave')) $('#s2AutoSave').checked = !!s.s2AutoSave;
                    if ($('#oeMergeCols')) $('#oeMergeCols').checked = !!s.oeMergeCols;
                    if ($('#oeMergeMode')) $('#oeMergeMode').value = s.oeMergeMode || 'leaf';
                    if ($('#oeFilter')) $('#oeFilter').value = s.oeFilter || '';
                    if ($('#smartStatus')) $('#smartStatus').checked = !!s.smartStatus;
                }
            }
        }
        if (cfg.columnsConfig) columnsConfig = cfg.columnsConfig;
        if (cfg.selected) selected = cfg.selected;
        renderColumnsTable();
        for (let i = 1; i <= SERVICE_COUNT; i++) {
            document.querySelectorAll(`.fld[data-svc="${i}"]`).forEach(el => el.checked = false);
            if (selected[i] && selected[i].length) {
                selected[i].forEach(val => {
                    const el = document.querySelector(`.fld[data-svc="${i}"][value="${CSS.escape(val)}"]`);
                    if (el) el.checked = true;
                });
            }
        }
    }

    function toggleMode() {
      const classicInputs = document.getElementById('classicInputs');
      const originalCards = document.getElementById('originalTemplateAndServiceCards');
      const tplCard = document.getElementById('tplCard');
      const services1to4 = document.getElementById('services1to4Wrap');
      const fieldSel = document.getElementById('fieldSelectionPanel');
      const resultCard = document.getElementById('resultCard');
      const consoleWrap = document.getElementById('consoleLogWrap');
      const normalActionRow = document.getElementById('normalActionRow');
      if (classicInputs) classicInputs.style.display = 'block';
      if (originalCards) originalCards.style.display = 'block';
      if (tplCard) tplCard.style.display = 'block';
      if (services1to4) services1to4.style.display = 'block';
      if (fieldSel) fieldSel.style.display = 'block';
      if (resultCard) resultCard.style.display = 'block';
      if (consoleWrap) consoleWrap.style.display = 'block';
      if (normalActionRow) normalActionRow.style.display = 'flex';
    }

    
    async function fillColumnsFromService(targetRow, recs, svc, detailIndex) {
      const cfg = Array.isArray(columnsConfig) ? columnsConfig : [];
      for (const col of cfg) {
        if (Number(col?.svc) !== Number(svc)) continue;
        const alias = col.alias || ('S' + svc + ':' + col.field);
        const value = getFromRecs(recs, svc, col.field, detailIndex);
        if (value !== undefined && value !== null && String(value) !== '') {
          targetRow[alias] = value;
        }
      }
    }

    function isSvcEnabled(svc){
      const cb = document.querySelector('#svc' + svc + 'Enabled, #enable' + svc + ', #s' + svc + 'on');
      if (!cb) return true;
      return !!cb.checked;
    }

    async function retryFailedRow(row){
      const recs = Object.assign({}, row.__recs || {});
      const id = String(row.__rowKey || '').trim();
      const token = $('#token')?.value?.trim() || '';
      if (!id) return;

      const failedSvcs = Object.entries(row.__svcErrors || {})
        .filter(([svc, isErr]) => !!isErr)
        .map(([svc]) => Number(svc))
        .sort((a,b) => a-b);

      if (!failedSvcs.length) return;

      const startSvc = failedSvcs[0];
      const patchRow = ensureRowMeta({}, id);
      patchRow.__recs = recs;
      patchRow.__svcErrors = Object.assign({}, row.__svcErrors || {});

      for (const svc of [1,2,3,4]) {
        if (svc < startSvc) continue;
        if (!isSvcEnabled(svc)) continue;

        const resp = await fetchService(id, token, svc, recs);
        if (resp.error) {
          patchRow.__svcErrors[svc] = true;
          break;
        }

        recs[svc] = resp.full || resp.root || resp.rec || {};
        patchRow.__recs[svc] = recs[svc];
        patchRow.__svcErrors[svc] = false;
        fillColumnsFromService(patchRow, recs, svc);
      }

      upsertResultRow(patchRow);
      try { writeHeader(); } catch(_) {}
      try { paintRows(); } catch(_) {}
    }

    async function retryAllFailedRows(){
      const failed = getFailedRows();
      if (!failed.length) {
        showToast('Hatalı kayıt kalmadı', 'success');
        return;
      }

      showToast('Hatalı kayıtlar tekrar sorgulanıyor', 'info');
      for (const row of failed) {
        await retryFailedRow(row);
      }
      showToast('Hatalı kayıtların tekrar sorgusu bitti', 'success');
    }

function initUIOnce(){
        log("SİSTEM", "V50.11 Senior Patch - Hazır.");
        try {
            const d1 = $('#dispatch1');
            if (d1 && /etebligat_server\/dispatch/i.test(d1.value || '')) {
                d1.value = 'http://keys.ggm.bim/gibintranet_server/dispatch';
            }
        } catch(_) {}
        autoFillAuth();
        updateExecutionModeLabel();
        toggleMode();
        migrateLegacySessionOnce();
        loadSession(false);
        refreshTplSel();
        if ($('#btnSessSave')) $('#btnSessSave').onclick = () => saveSession(true);
        if ($('#btnSessLoad')) $('#btnSessLoad').onclick = () => loadSession(true);
        try {
            bindTplPicker('tpl2', [1]);
            bindTplPicker('tpl3', [2,1]);
            bindTplPicker('tpl4', [3,2,1]);
            bindDropToTpl('tpl2');
            bindDropToTpl('tpl3');
            bindDropToTpl('tpl4');
        } catch(e) { console.warn('JP picker bind failed', e); }
        if ($('#btnPreview')) $('#btnPreview').onclick = () => runPreview();
        
        // SES SİSTEMİNİ TETİKLEMEK İÇİN INIT EKLENDİ
        if ($('#btnRun')) $('#btnRun').onclick = () => { initAudio(); runTurbo(); };
    }
    document.addEventListener('DOMContentLoaded', initUIOnce);

    function discoverDataStructure(data, opts = {}) {
      const { path = "", maxDepth = 24, maxArrayScan = 12, minKeys = 2 } = opts;
      const seen = new WeakSet(); const out = [];
      const isObj = x => x && typeof x === 'object';
      const isPlainObj = x => isObj(x) && !Array.isArray(x);
      function score(arrLen, headers, p){
        const h = headers.map(s=>String(s).toLowerCase());
        let bonus = 0;
        if (h.some(k=>k.includes('vkn')||k.includes('tckn'))) bonus += 20;
        if (h.some(k=>k.includes('id')||k.includes('no'))) bonus += 10;
        return Math.min(arrLen, 500) + headers.length*3 + bonus;
      }
      function walk(node, p, depth){
        if(!isObj(node) || depth>maxDepth) return;
        if(seen.has(node)) return; seen.add(node);
        if(Array.isArray(node)){
          if(node.length>0 && isPlainObj(node[0])){
            const union = new Set();
            const scanN = Math.min(node.length, maxArrayScan);
            for(let i=0;i<scanN;i++){ if(isPlainObj(node[i])) Object.keys(node[i]).forEach(k=>union.add(k)); }
            const headers = [...union];
            if(headers.length >= minKeys){
              out.push({ yol: p, kayitSayisi: node.length, sutunlar: headers, ornekVeri: node[0], skor: score(node.length, headers, p) });
            }
            walk(node[0], p ? (p+'[0]') : '[0]', depth+1);
          }
          return;
        }
        for(const k of Object.keys(node)){ walk(node[k], p ? (p + '.' + k) : k, depth+1); }
      }
      walk(data, path, 0); out.sort((a,b)=>b.skor-a.skor); return out;
    }

    function log(label, msg, isJson=false) {
        const time = new Date().toLocaleTimeString();
        const box = $('#consoleLog');
        if(!box) return;
        const div = document.createElement('div'); div.className = 'log-line';
        const spanLabel = document.createElement('span');
        spanLabel.className = 'log-lbl'; spanLabel.textContent = label + ': ';
        const spanTime = document.createElement('span');
        spanTime.className = 'log-time'; spanTime.textContent = '['+time+'] ';
        const spanMsg = document.createElement('span');
        spanMsg.className = isJson ? 'log-json' : 'log-val';
        spanMsg.textContent = msg; 
        div.appendChild(spanTime); div.appendChild(spanLabel); div.appendChild(spanMsg);
        box.appendChild(div); box.scrollTop = box.scrollHeight;
    }

    function normalizeFieldPath(p){ return String(p || '').replaceAll('[*]','[0]').replaceAll('\\u200B','').trim(); }
    function isFieldSelected(svc, field){
      const list = selected[svc] || []; const f = normalizeFieldPath(field);
      for(const raw of list){
        const s = normalizeFieldPath(raw); if(!s) continue;
        if(s === f) return true;
        if(s.endsWith('.' + f) || s.endsWith('].' + f)) return true;
      }
      return false;
    }

    function renderColumnsTable(){
      const tbody = document.getElementById('colOrderBody');
      if(!tbody) return;
      const safe = (v)=> (v==null? '' : String(v));
      const cfg = Array.isArray(columnsConfig) ? columnsConfig : [];
      tbody.innerHTML = '';
      if(!cfg.length){
        const tr = document.createElement('tr');
        const td = document.createElement('td');
        td.colSpan = 7;
        td.textContent = 'Kolon yok. Alan Seçimi panelinden alan seçip “Seçili Alanları Aktar”a bas.';
        tr.appendChild(td); tbody.appendChild(tr); return;
      }
      cfg.forEach((c, idx)=>{
        const tr = document.createElement('tr');
        const svc = Number(c?.svc || 0);
        const field = safe(c?.field);
        const label = safe(c?.label || c?.title || field);
        const type = safe(c?.type || 'text');
        const detailMode = safe(c?.detailMode || c?.detail || 'auto');
        tr.setAttribute('data-svc', String(svc || ''));
        tr.setAttribute('data-field', field);
        tr.setAttribute('data-label', label);
        tr.setAttribute('data-type', type);
        tr.setAttribute('data-detail', detailMode);
        const tdN = document.createElement('td'); tdN.textContent = String(idx+1);
        const tdSvc = document.createElement('td'); tdSvc.textContent = svc ? ('S'+svc) : '';
        const tdPath = document.createElement('td'); tdPath.textContent = field;
        const tdLbl = document.createElement('td'); tdLbl.textContent = label; tdLbl.className = 'colLabel';
        const tdType = document.createElement('td'); tdType.textContent = type;
        const tdDet = document.createElement('td'); tdDet.textContent = detailMode;
        const tdOrder = document.createElement('td');
        tdOrder.style.whiteSpace = 'nowrap';
        const up = document.createElement('button');
        up.type='button'; up.textContent='↑'; up.className='secondary'; up.style.padding='2px 8px';
        const dn = document.createElement('button');
        dn.type='button'; dn.textContent='↓'; dn.className='secondary'; dn.style.padding='2px 8px'; dn.style.marginLeft='6px';
        up.onclick = ()=>{
          const prev = tr.previousElementSibling;
          if(prev) tbody.insertBefore(tr, prev);
          rebuildColumnsFromDOM(); renderColumnsTable();
        };
        dn.onclick = ()=>{
          const next = tr.nextElementSibling;
          if(next) tbody.insertBefore(next, tr);
          rebuildColumnsFromDOM(); renderColumnsTable();
        };
        tdOrder.appendChild(up); tdOrder.appendChild(dn);
        tr.appendChild(tdN); tr.appendChild(tdSvc); tr.appendChild(tdPath);
        tr.appendChild(tdLbl); tr.appendChild(tdType); tr.appendChild(tdDet); tr.appendChild(tdOrder);
        tbody.appendChild(tr);
      });
    }

    function rebuildColumnsFromDOM(){
      const tbody = document.getElementById('colOrderBody');
      if(!tbody) return;
      const rows = Array.from(tbody.querySelectorAll('tr[data-svc][data-field]'));
      if(!rows.length) return;
      const nextCfg = rows.map(tr=>{
        const svc = Number(tr.getAttribute('data-svc') || 0);
        const field = tr.getAttribute('data-field') || '';
        const label = tr.getAttribute('data-label') || (tr.querySelector('.colLabel')?.textContent || '');
        const type = tr.getAttribute('data-type') || 'text';
        const detailMode = tr.getAttribute('data-detail') || 'auto';
        return { svc, field, label, type, detailMode };
      });
      columnsConfig = nextCfg;
    }

    async function requestWithRetry(dispatch, tokenInput, cmd, jpObj, options = {}) {
      const config = { retryCount: 3, method: 'POST', paramsLocation: 'body', extraParams: {}, cookieValue: null, callIdBaseEl: null, callIdCounterEl: null, ...options };
      const token = parseToken(tokenInput);
      let logPayload = (typeof jpObj === 'string') ? jpObj : JSON.stringify(jpObj);
      if(logPayload.length > 150) logPayload = logPayload.substring(0, 150) + "...";
      log("GİDEN", `CMD: ${cmd} | ${logPayload}`, true);
      for (let attempt = 1; attempt <= config.retryCount; attempt++) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 90000); 
        try {
          const params = new URLSearchParams();
          if (cmd) params.append('cmd', cmd);
          let callid = nextCallIdFromInputs(config.callIdBaseEl || $('#callIdBase'), config.callIdCounterEl || $('#callIdCounter'));
          params.append('callid', callid);
          if (token) params.append('token', token);
          if (jpObj) params.append('jp', (typeof jpObj === 'string') ? jpObj : JSON.stringify(jpObj));
          for (const [k, v] of Object.entries(config.extraParams)) params.append(k, v);
          let fetchUrl = dispatch;
          const cookieVal = (config.cookieValue != null ? String(config.cookieValue) : ($('#cookie')?.value?.trim() || '')).trim();
          if(cookieVal && !fetchUrl.includes(';jsessionid=')) {
             let justId = cookieVal;
             if(justId.toUpperCase().includes('JSESSIONID=')) {
                 const part = justId.split(';').find(p => p.trim().toUpperCase().startsWith('JSESSIONID='));
                 if(part) justId = part.split('=')[1];
             }
             if(justId && justId.length > 5) fetchUrl += ';jsessionid=' + justId;
          }
          let fetchOptions = { 
              method: config.method, 
              headers: { 'Accept': 'application/json' }, 
              credentials: 'include',
              signal: controller.signal
          };
          if(cookieVal) { try { fetchOptions.headers['Cookie'] = cookieVal; } catch(e){} }
          if (config.paramsLocation === 'url' || config.method === 'GET') {
            fetchUrl += (fetchUrl.includes('?') ? '&' : '?') + params.toString();
            if(config.method==='POST') fetchOptions.headers['Content-Type']='application/x-www-form-urlencoded; charset=UTF-8';
          } else {
            fetchOptions.headers['Content-Type']='application/x-www-form-urlencoded; charset=UTF-8'; fetchOptions.body = params;
          }
          const res = await fetch(fetchUrl, fetchOptions);
          clearTimeout(timeoutId);
          if(!res.ok) throw new Error(res.status + ' ' + res.statusText);
          const txt = await res.text();
          try {
            const json = JSON.parse(txt);
            if (json.error === "1" || (json.messages?.[0]?.type === "1")) {
                log("HATA (GİB)", json.messages?.[0]?.text || "Bilinmeyen Hata");
                return { ok: false, error: json.messages?.[0]?.text };
            }
            return { ok: true, json };
          } catch (e) { 
            log("HATA (PARSE)", "Yanıt JSON değil"); 
            return { ok: false, error: 'JSON Parse Hatası', text: txt }; 
          }
        } catch (e) { 
            clearTimeout(timeoutId);
            if(e.name === 'AbortError') log("HATA", "Zaman aşımı (90sn)");
            else log("HATA (AĞ)", e.message);
        }
        if (attempt < config.retryCount) await wait(1200);
      }
      return { ok: false, error: "İstek başarısız" };
    }
    function postWithRetry(dispatch, tokenInput, cmd, jpObj, retryCount=3, options={}) {
        if (typeof retryCount === 'object' && retryCount !== null) { options = retryCount;
        retryCount = options.retryCount || 3; }
        return requestWithRetry(dispatch, tokenInput, cmd, jpObj, { retryCount, ...options });
    }

    function collectKeysDeep(node, prefix = '', out = new Set(), opts = {}){
      const { maxDepth = 12, maxArrayDepth = 4, includeLeafOnly = true } = opts;
      function walk(x, p, depth, arrDepth){
        if (x === null || x === undefined) { if (!includeLeafOnly && p) out.add(p); return; }
        if (typeof x !== 'object') { if (p) out.add(p); return; }
        if (Array.isArray(x)) {
          if (!x.length) { if (!includeLeafOnly && p) out.add(p); return; }
          const sample = x.find(v => v && typeof v === 'object') ?? x[0];
          if (arrDepth < maxArrayDepth) walk(sample, p + '[0]', depth + 1, arrDepth + 1); 
          else if (!includeLeafOnly && p) out.add(p);
          return;
        }
        if (depth >= maxDepth) { if (!includeLeafOnly && p) out.add(p); return; }
        const keys = Object.keys(x);
        if (!keys.length) { if (!includeLeafOnly && p) out.add(p); return; }
        for (const k of keys) walk(x[k], p ? (p + '.' + k) : k, depth + 1, arrDepth);
      }
      walk(node, prefix, 0, 0); return [...out];
    }

    function ensureArray(x){ return Array.isArray(x) ? x : (x==null ? [] : [x]); }
    function findS4ArrayBase() {
      const paths = [];
      if (columnsConfig && columnsConfig.length) { columnsConfig.filter(c => c.svc === 4).forEach(c => paths.push(c.field)); } 
      else { (selected[4] || []).forEach(f => paths.push(f)); }
      for (const p of paths) { const m = /^(.*)\[(\d+)\]\.[^.]+$/.exec(p); if (m) return m[1]; } return null;
    }
    function parseMultiField(field){ if(field == null) return []; return String(field).split('||').map(x=>x.trim()).filter(Boolean); }
    function getFromRecs(recs, svc, field, detailIndex) {
      const fields = parseMultiField(field);
      const svcObj = getPayloadRoot(recs[svc] || {});

      if (svc === 4 && detailIndex != null) {
        for (const f of fields) {
          const m = /^(.*)\[(\d+)\]\.(.+)$/.exec(String(f || ''));
          if (m) {
            const arr = getSmart(recs[4] || {}, m[1]);
            if (Array.isArray(arr) && arr[detailIndex]) {
              const v = get(arr[detailIndex], m[3]);
              if (v != null && v !== '') return v;
            }
          }
        }
      }

      for (const f of fields) {
        let v = get(svcObj, f);
        if (v == null) v = get(recs[svc] || {}, f);

        if (Array.isArray(v)) {
          if (typeof detailIndex === 'number' && v[detailIndex] != null) return v[detailIndex];
          if (v[0] != null) return v[0];
        }

        if (v != null && v !== '') return v;
      }

      return '';
    }

    function malvarlikAyrintiliAnaliz(fullJson) {
      if (!fullJson) return null;
      const d = fullJson.data || fullJson;
      let counts = [];
      let res = { ozet: 'YOK', arac: '', tapu: '', ismak: '', deniz: '', hava: '' };
      try {
        const aracList = d.motorluTasit?.tumMotorluTasitBilgileri?.veriler || [];
        if (aracList.length) {
            counts.push(`${aracList.length} Araç`);
            res.arac = aracList.map(a => {
                const marka = a.marka || '';
                const model = a.tipi || a.model || '';
                const yil = a.modelYili || '';
                let detay = marka;
                if(model) detay += ` ${model}`;
                if(yil) detay += ` - ${yil}`;
                return `${a.plaka} (${detay})`;
            }).join(' | ');
        }
        const tapuList = d.tapu?.takbisBilgileri?.summary || [];
        if (tapuList.length) {
            counts.push(`${tapuList.length} Tapu`);
            res.tapu = tapuList.map(t => `${t.il}/${t.ilce} (${t.nitelik})`).join(' | ');
        }
        const hvRoot = d.sivilHavacilik;
        let havaList = hvRoot?.sivilHavacilikBilgileri || [];
        if(!Array.isArray(havaList) && havaList?.data) havaList = havaList.data; 
        if (Array.isArray(havaList) && havaList.length) {
            counts.push(`${havaList.length} Uçak`);
            res.hava = havaList.map(h => `${h.tescilisareti} (${h.model})`).join(' | ');
        }
        const denizRoot = d.denizTasit;
        let denizList = [];
        if(denizRoot?.gemiBilgileri?.data) denizList = denizRoot.gemiBilgileri.data; 
        else if(denizRoot?.denizTasit?.gemiBilgileri?.data) denizList = denizRoot.denizTasit.gemiBilgileri.data; 
        if (denizList.length) {
            counts.push(`${denizList.length} Gemi`);
            res.deniz = denizList.map(g => `${g.gemiadi} (${g.gemicins})`).join(' | ');
        }
        const ismakList = d.isMakinalari?.isMakinalariBilgileri?.vehicleDetail || [];
        if (ismakList.length) {
            counts.push(`${ismakList.length} İş Mak.`);
            res.ismak = ismakList.map(i => {
                const plaka = i.platenumber ? i.platenumber + ' ' : '';
                const marka = i.vehiclebrand || 'BELİRSİZ';
                return `${plaka}(${marka})`;
            }).join(' | ');
        }
        if (counts.length > 0) res.ozet = counts.join(' + ');
      } catch (e) { 
          console.error("Analiz Hatası:", e); 
          return { ozet: "HATA" }; 
      }
      return res;
    }

    async function kaydetMalvarligi(token, dispatch, fullJson, id, rec1){
      const d = fullJson.data || fullJson; const pdf = get(d, 'jasperObjPdf') || get(d, 'tumMalvarPdfByteArray');
      if(!pdf) return { durum:'PDF YOK' };
      const r = await postWithRetry(dispatch, token, 'malVarligiService_tumMalVarligiKaydet', { tumMalVarPdfByteArray: pdf, vkn: rec1.vkn || id, unvan: rec1.unvan || '', optTime: get(fullJson, 'metadata.optime') || '' }, { retryCount: 1 });
      return { durum: r.ok ? 'BAŞARILI' : 'HATA' };
    }

    async function fetchService(id, token, sidx, recs){
      let dispatch = $('#dispatch'+sidx).value.trim() || $('#dispatch1').value.trim();
      const cmd = $('#cmd'+sidx).value.trim(), tpl = $('#tpl'+sidx).value;
      let arrPath = $('#arrayPath'+sidx).value.trim();
      if(!dispatch || !cmd) return {error:true, msg:'Eksik', rec:{}, arr:[], full:null};

      const jpObj = buildJp(tpl, id, recs);
      const jpList = Array.isArray(jpObj) ? jpObj : [jpObj];

      let mergedArr = [];
      let lastFull = null;
      let lastRoot = null;

      for (let i = 0; i < jpList.length; i++) {
        const r = await postWithRetry(dispatch, token, cmd, jpList[i]);
        if(!r.ok) return {error:true, msg:r.error, rec:{}, arr:[], full:null, svc:sidx};

        const json = r.json;
        const root = getPayloadRoot(json);

        lastFull = json;
        lastRoot = root;

        let arr = [];
        if(arrPath) {
          arr = getArraySmart(json, arrPath);
        } else {
          if(root && (root.motorluTasit || root.tapu || root.isMakinalari || root.sivilHavacilik || root.denizTasit)) arr = [root];
          else if(Array.isArray(root)) arr = root;
          else if(root && Array.isArray(root.data)) arr = root.data;
          else arr = [root || {}];
        }
        mergedArr = mergedArr.concat(arr);
      }

      const rec = mergedArr.length ? mergedArr[0] : (lastRoot || {});
      return {error:false, msg:'', rec, arr: mergedArr, full: lastFull, root: lastRoot};
    }

    function getSvcFieldsForPicker(svc){
      const uniq = new Set();
      try{
        const box = document.getElementById('fields' + String(svc));
        if(box){ box.querySelectorAll('input.fld').forEach(inp=>{ const v = (inp?.value || '').trim(); if(v) uniq.add(v); }); }
      }catch(_){}
      try{
        if (typeof fieldLists !== 'undefined' && Array.isArray(fieldLists[svc])) {
          fieldLists[svc].forEach(v=>{ v = String(v||'').trim(); if(v) uniq.add(v); });
        }
      }catch(_){}
      try{
        if (typeof discoveriesBySvc !== 'undefined' && discoveriesBySvc && discoveriesBySvc[svc]) {
          const d = discoveriesBySvc[svc];
          if (Array.isArray(d)) { d.forEach(it=>{ if (it && Array.isArray(it.sutunlar)) { it.sutunlar.forEach(k=>{ const v = String(k||'').trim(); if(v) uniq.add(v); }); } });
          } else if (Array.isArray(d.paths)) { d.paths.forEach(v=>{ v=String(v||'').trim(); if(v) uniq.add(v); }); }
        }
      }catch(_){}
      return Array.from(uniq);
    }

    function applyPlaceholdersToValue(val, idValue, recs){
      if (val == null) return val;
      if (typeof val === 'string') { return resolvePlaceholdersInString(val, idValue, recs); }
      if (Array.isArray(val)) { return val.map(v => applyPlaceholdersToValue(v, idValue, recs)); }
      if (typeof val === 'object') {
        const out = {};
        for (const k of Object.keys(val)) { out[k] = applyPlaceholdersToValue(val[k], idValue, recs); }
        return out;
      }
      return val;
    }

    function buildJp(tplText, idValue, recs) {
      const raw = String(tplText ?? '').trim();
      if (!raw) return { vkn: String(idValue ?? '') };
      const looksJson = raw.startsWith('{') || raw.startsWith('[');
      function expandJpFanout(obj, maxVariants = 50) {
        const isPrimitive = (v) => (v === null || v === undefined || typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean');
        const leaves = [];
        const walk = (node, path = []) => {
          if (!node || typeof node !== 'object') return;
          if (Array.isArray(node)) return; 
          for (const k of Object.keys(node)) {
            const v = node[k];
            if (Array.isArray(v) && v.length > 0 && v.every(isPrimitive)) {
              leaves.push({ path: [...path, k], values: v.map(x => (x === null || x === undefined) ? '' : x) });
            } else if (v && typeof v === 'object' && !Array.isArray(v)) {
              walk(v, [...path, k]);
            }
          }
        };
        walk(obj, []);
        if (!leaves.length) return [obj];
        const getAt = (o, p) => p.reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : undefined), o);
        const setAt = (o, p, val) => {
          let cur = o;
          for (let i = 0; i < p.length - 1; i++) {
            const key = p[i];
            if (!cur[key] || typeof cur[key] !== 'object' || Array.isArray(cur[key])) cur[key] = {};
            cur = cur[key];
          }
          cur[p[p.length - 1]] = val;
        };
        const clone = (o) => JSON.parse(JSON.stringify(o));
        let variants = [obj];
        for (const leaf of leaves) {
          const next = [];
          for (const base of variants) {
            for (const val of leaf.values) {
              const c = clone(base);
              setAt(c, leaf.path, val);
              next.push(c);
              if (next.length >= maxVariants) break;
            }
            if (next.length >= maxVariants) break;
          }
          variants = next;
          if (variants.length >= maxVariants) break;
        }
        return variants;
      }

      const toJsonLiteral = (v) => {
        if (v === null || v === undefined) return 'null';
        if (typeof v === 'number' || typeof v === 'boolean') return String(v);
        if (typeof v === 'object') { try { return JSON.stringify(v); } catch(_) { return 'null'; } }
        try { return JSON.stringify(String(v)); } catch(_) { return '""'; }
      };

      function resolveJsonTemplateString(tplStr){
        let s = String(tplStr ?? '');
        const id = (idValue == null) ? '' : String(idValue);
        const bag = recs || {};
        const pick = (svcNum, path) => {
          const rec0 = bag[svcNum] || bag[String(svcNum)] || null;
          if (!rec0) return '';
          const p = String(path||'').trim();
          const candidates = [];
          candidates.push({ base: rec0, path: p });
          if (rec0 && typeof rec0 === 'object' && 'data' in rec0) {
            candidates.push({ base: rec0, path: 'data.' + p });
            const d = rec0.data;
            if (Array.isArray(d) && d.length) candidates.push({ base: d[0], path: p });
          }
          if (p.startsWith('data.')) candidates.push({ base: rec0, path: p.slice(5) });
          for (const c of candidates) {
            const v = get(c.base, c.path, '');
            if (v !== '' && v !== undefined && v !== null) return v;
          }
          const v2 = get(rec0, p, '');
          return (v2 === undefined || v2 === null) ? '' : v2;
        };
        s = s.replace(/\[\[S([1-5])\:([^\]]+)\]\]/g, (_m, svc, path) => {
          const v = pick(Number(svc), String(path).trim());
          if (v === null || v === undefined) return '';
          if (typeof v === 'object') { try { return JSON.stringify(v); } catch(_) { return ''; } }
          return String(v);
        });
        function replaceWithContext(fullToken, value){
          const idx = s.indexOf(fullToken);
          if (idx < 0) return toJsonLiteral(value);
          const left = s.slice(0, idx);
          const inQuotes = (left.match(/"/g) || []).length % 2 === 1;
          if (inQuotes) {
            if (value === null || value === undefined) return '';
            if (typeof value === 'object') { try { return JSON.stringify(value); } catch(_) { return ''; } }
            return String(value);
          }
          return toJsonLiteral(value);
        }
        s = s.replace(/\[ID\]/g, (full)=> replaceWithContext(full, id));
        s = s.replace(/\[S([1-5])\:([^\]]+)\]/g, (full, svc, path) => {
          const v = pick(Number(svc), String(path).trim());
          return replaceWithContext(full, v);
        });
        return s;
      }

      if (looksJson) {
        const resolvedStr = resolveJsonTemplateString(raw);
        try {
          const parsed = JSON.parse(resolvedStr);
          const variants = expandJpFanout(parsed);
          return (variants.length > 1) ? variants : parsed;
        } catch (e) {
          try {
            const obj2 = JSON.parse(raw);
            const resolvedObj = applyPlaceholdersToValue(obj2, idValue, recs);
            const variants2 = expandJpFanout(resolvedObj);
            return (variants2.length > 1) ? variants2 : resolvedObj;
          } catch(_) {}
          return { vkn: String(idValue ?? '') };
        }
      }
      return resolvePlaceholdersInString(raw, idValue, recs);
    }

    // --- SENIOR PATCH: OPTIMIZED TABLE RENDERING (NO INNERHTML TRASHING) ---
    function createTrFromRow(rowArray) {
        const tr = document.createElement('tr');
        if (rowArray && rowArray[0]) tr.setAttribute('data-id', rowArray[0]);
        rowArray.forEach(v => {
            const td = document.createElement('td');
            td.textContent = (v === null || v === undefined) ? '' : String(v);
            tr.appendChild(td);
        });
        return tr;
    }

    function appendRow(rowArray) {
        let arr = null;
        if (Array.isArray(rowArray)) {
            arr = rowArray;
        } else if (rowArray && typeof rowArray === 'object') {
            const msg = rowArray.Detay || rowArray.detail || rowArray.error || rowArray.message || JSON.stringify(rowArray);
            const idv = rowArray.id || rowArray.vkn || '';
            const status = rowArray.Durum || rowArray.durum || '❌';
            const colsLen = (Array.isArray(columnsConfig) && columnsConfig.length) ? columnsConfig.length : 1;
            arr = [String(idv), String(status).includes('❌') ? String(status) : ('❌ ' + String(status))];
            for (let i = 0; i < colsLen; i++) arr.push('');
            if (!columnsConfig.length) arr[2] = String(msg);
            else arr[1] = '❌ ' + String(msg || status);
        } else {
            arr = [String(rowArray ?? ''), '❌', ''];
        }
        if (!Array.isArray(rowsOut)) rowsOut = [];
        rowsOut.push(arr);
        const tb = document.getElementById('tbody');
        // Eğer tabloda sadece "Veri yok" yazıyorsa temizle
        if (tb.rows.length > 0 && tb.innerText.includes('Veri yok')) {
        tb.innerHTML = '';
        }
        tb.appendChild(createTrFromRow(arr));
    }

    function paintRows(){
        const tb = document.getElementById('tbody');
        tb.innerHTML = '';
        if(!rowsOut || !rowsOut.length){ tb.innerHTML='<tr><td colspan="2">Henüz veri yok</td></tr>'; return; }
        const frag = document.createDocumentFragment();
        rowsOut.forEach(r => { frag.appendChild(createTrFromRow(r)); });
        tb.appendChild(frag);
    }

    function writeHeader() {
      const th = $('#thead');
      if (!th) return;
      const idColName = $('#idColName')?.value || 'Vergi No';
      let html = `<tr><th>${escapeHtml(idColName)}</th><th>Durum</th>`;
      if (columnsConfig && columnsConfig.length > 0) {
        columnsConfig.forEach(col => {
          const title = col.label || col.alias || col.field;
          html += `<th>${escapeHtml(title)}</th>`;
        });
      } else { html += `<th>Detay</th>`; }
      html += `</tr>`;
      th.innerHTML = html;
    }

    function extractRow(id, recs, detailIndex = null) {
      const row = [id, '✅'];
      if (columnsConfig && columnsConfig.length > 0) {
        columnsConfig.forEach(col => {
          let val = getFromRecs(recs, col.svc, col.field, detailIndex);
          if (col.type === 'number') { val = formatTrNumber(val); }
          row.push(val === undefined || val === null ? '' : String(val));
        });
      } else { row.push(''); }
      return row;
    }

    function updateBar(current, total) {
      const bar = document.getElementById('progressInner');
      const txt = document.getElementById('barText');
      const etaLabel = document.getElementById('etaText');
      if (!total || total <= 0) total = 1;
      let pct = (current / total) * 100;
      if (pct > 100) pct = 100; if (pct < 0) pct = 0;
      if (bar) bar.style.width = pct + '%';
      if (txt) txt.textContent = Math.floor(pct) + '% (' + current + '/' + total + ')';
      if (etaLabel && window.startTime && current > 0) {
         const elapsed = Date.now() - window.startTime;
         const msPerItem = elapsed / current;
         const remainingItems = total - current;
         const remainingMs = remainingItems * msPerItem;
         const finishTime = new Date(Date.now() + remainingMs);
         const timeStr = finishTime.toTimeString().split(' ')[0];
         etaLabel.textContent = 'Tahmini Bitiş: ' + timeStr;
      }
    }

    function getErrorIdsFromDOM(){
      const trs = [...document.querySelectorAll('#tbody tr')];
      const ids = trs.filter(tr => (tr.innerText || '').includes('❌')).map(tr => tr.getAttribute('data-id')).filter(Boolean);
      return [...new Set(ids)];
    }

    function replaceRowsForId(id, newRows){
      const tb = document.getElementById('tbody');
      if(!tb) return;
      const safeId = (window.CSS && CSS.escape) ? CSS.escape(String(id)) : String(id).replace(/"/g,'');
      const trs = [...tb.querySelectorAll(`tr[data-id="${safeId}"]`)];
      const errTrs = trs.filter(tr => (tr.innerText || '').includes('❌'));
      if(!errTrs.length) return;
      const anchor = errTrs[0];
      const next = anchor.nextSibling;
      errTrs.forEach(tr => tr.remove());
      rowsOut = rowsOut.filter(r => !(String(r?.[0]||'')===String(id) && String(r?.[1]||'').includes('❌')));
      (newRows || []).forEach(row => {
        rowsOut.push(row);
        const tr = createTrFromRow(row);
        tb.insertBefore(tr, next);
      });
    }

    async function autoRetryFailedOnce(token){
      if(!document.getElementById('autoRetryErrors')?.checked) return;
      const errIds = getErrorIdsFromDOM();
      if(!errIds.length) return;
      const threadCount = Math.max(1, parseInt(document.getElementById('threadCount')?.value || '1', 10) || 1);
      const maxPass = 2; 
      for(let pass=1; pass<=maxPass; pass++){
        const idsNow = getErrorIdsFromDOM();
        if(!idsNow.length) break;
        log("RETRY", `♻️ Hatalılar yeniden deneniyor (Tur ${pass}/${maxPass}) • ${idsNow.length} kayıt`);
        for(let i=0; i<idsNow.length; i+=threadCount){
          const batch = idsNow.slice(i, i+threadCount);
          const results = await Promise.all(batch.map(id => processSingleId(id, token)));
          for(let bi=0; bi<batch.length; bi++){
            const id = batch[bi];
            const res = results[bi];
            if(res && res.ok && Array.isArray(res.rows) && res.rows.length){ replaceRowsForId(id, res.rows); }
          }
          await wait(getHumanWaitTime(Math.min(1200, waitMsGlobal || 1200)));
        }
      }
    }

    function applyDetailModes(blockRows){
      if(!columnsConfig.length || blockRows.length <= 1) return;
      for(let colIdx=0; colIdx<columnsConfig.length; colIdx++){
        const cfg = columnsConfig[colIdx], mode = cfg.detailMode || 'auto', ci = 2 + colIdx;
        if(mode === 'first'){ for(let r=1; r<blockRows.length; r++) blockRows[r][ci] = ''; }
        else if(mode === 'join'){
          const vals = blockRows.map(r => r[ci]).filter(v => v!=null && v!=='');
          blockRows[0][ci] = vals.join(' | '); for(let r=1; r<blockRows.length; r++) blockRows[r][ci] = '';
        }
      }
    }

    function formatTrNumber(value) {
      if (value === null || value === undefined) return "";
      if (typeof value === "string") {
        const s = value.trim();
        if (/^\d{1,3}(\.\d{3})*(,\d+)?$/.test(s)) return s;
        if (/^\d+(,\d+)$/.test(s)) return s;
        if (s.includes(",") && /[0-9]/.test(s)) {
          const tr = s.replace(/\./g, "").replace(",", ".");
          const num = Number(tr);
          if (!Number.isNaN(num)) return num.toLocaleString("tr-TR");
        }
        const num2 = Number(s.replace(/\s+/g,""));
        if (!Number.isNaN(num2)) return num2.toLocaleString("tr-TR");
        return s;
      }
      if (typeof value === "number") {
        if (!Number.isFinite(value)) return "";
        return value.toLocaleString("tr-TR");
      }
      return String(value);
    }

    function renderFields(idx){
      const box = $('#fields'+idx), list = fieldLists[idx] || [];
      const findings = discoveriesBySvc[idx] || [];
      let discHtml = '';
      if(findings.length){
        const top = findings.slice(0, 6); const current = ($('#arrayPath'+idx)?.value?.trim()) || chosenPathBySvc[idx] || '';
        discHtml = `<div style="border:1px solid #2a3750; padding:8px; border-radius:8px; background:#0b1019; margin-bottom:8px">
            <div style="font-weight:700; color:#cfe0ff; margin-bottom:6px">🔎 Kâşif Adayları</div>
            ${top.map((f)=>`<label class="checkbox-row" style="align-items:flex-start"><input type="radio" name="disc_s${idx}" class="discPick" data-svc="${idx}" value="${escapeHtml(f.yol)}" ${f.yol===current?'checked':''}><span><b style="color:#6ea8fe">${escapeHtml(f.yol)}</b><br><span style="color:#9aa6bf; font-size:11px">Kayıt: ${f.kayitSayisi} • Kolon: ${f.sutunlar.length}</span></span></label>`).join('')}
            <div class="row" style="margin-top:8px; gap:8px"><button type="button" class="secondary btnApplyDiscovery" data-svc="${idx}">Uygula</button></div></div>`;
      }
      if(!list.length){ box.innerHTML = discHtml + '<span class="err">Veri yok</span>'; return; }
      box.innerHTML = discHtml + list.map(f=>{
        const checked = isFieldSelected(idx, f);
        return `<label class="checkbox-row"><input type="checkbox" class="fld" data-svc="${idx}" value="${escapeHtml(f)}" ${checked?'checked':''}><span>${escapeHtml(f)}</span></label>`;
      }).join('');
    }
    
    // --- SENIOR PATCH: SAFE LOGIC PROCESSOR ---
    async function processSingleId(id, token) {
      const emptyRecs = {1:{},2:{},3:{},4:{}};
      try {
        const r1 = await fetchService(id, token, 1, {});
        if (r1.error) return { ok:false, error:'S1: ' + (r1.msg||'Hata'), recs: emptyRecs, rows: [] };
        const rec1 = r1.rec || {};

        let arr2 = [{}], rec2_Base = {};
        const useS2 = !!$('#useS2')?.checked;
        const useOe = useS2 && !!$('#s2OzelEsas')?.checked;
        let analiz = null;

        if (useOe) {
          /* Özel Esas Mock/Placeholder Logic (Keep original structure if external funcs exist, else simplified) */
          /* Note: fetchOzelEsasMain is not defined in provided snippet, assuming it exists or skipping */
           // Placeholder for safety if functions missing:
           if(typeof fetchOzelEsasMain === 'function') {
               const [m2050, m60] = await Promise.all([ fetchOzelEsasMain(id, token, 2050), fetchOzelEsasMain(id, token, 60) ]);
               if (!m2050.ok && !m60.ok) return { ok:false, error:'ÖE: Hata', recs: {1:rec1}, rows: [] };
               arr2 = []; const base = { __oe_m2050: m2050, __oe_m60: m60 };
               if (m2050.ok) arr2.push(buildOeS2Row(2050, m2050));
               if (m60.ok)   arr2.push(buildOeS2Row(60, m60));
               if (!arr2.length) arr2.push({});
               rec2_Base = Object.assign(base, (arr2[0]||{}));
               arr2 = arr2.map(x => Object.assign({}, x, base));
           } else {
               arr2 = [{}]; // Fallback
           }
        } else if (useS2) {
          const r2 = await fetchService(id, token, 2, { 1: rec1 });
          if (r2.error) return { ok:false, error:'S2: ' + (r2.msg||'Hata'), recs: {1:rec1}, rows: [] };
          rec2_Base = r2.rec || {};
          arr2 = ($('#expand2')?.checked && (r2.arr||[]).length) ? r2.arr : [rec2_Base];
          if (String($('#cmd2')?.value || '').includes('malVarligiService')) {
            analiz = malvarlikAyrintiliAnaliz(r2.full);
            if (analiz) Object.assign(rec2_Base, { __mv_Ozet: analiz.ozet, __mv_Detay_Arac: analiz.arac, __mv_Detay_Tapu: analiz.tapu, __mv_Detay_IsMak: analiz.ismak, __mv_Detay_Deniz: analiz.deniz, __mv_Detay_Hava: analiz.hava });
            if ($('#s2SingleRow')?.checked) arr2 = [rec2_Base];
            if ($('#s2AutoSave')?.checked) { try { rec2_Base.__malvarlikKayitDurumu = (await kaydetMalvarligi(token, $('#dispatch2')?.value, r2.full, id, rec1)).durum; } catch(_){} }
          }
        }

        let smartStatus = "";
        if($('#smartStatus')?.checked) {
          if(useOe) {
            const has2050 = arr2.some(r => String(r?.__oe_durum||'') === '2050' && Number(r?.__oe_visibleCount||0) > 0);
            const has60   = arr2.some(r => String(r?.__oe_durum||'') === '60'   && Number(r?.__oe_visibleCount||0) > 0);
            if(has2050) smartStatus = "GÜNCEL"; else if(has60) smartStatus = "ARŞİV"; else smartStatus = "TEMİZ";
          } else if(useS2) {
            if(analiz && analiz.ozet !== 'YOK') smartStatus = "Mal Varlığı Var"; else smartStatus = "YOK";
          }
        }

        const rowsBuffer = [];
        const s4ArrayBase = findS4ArrayBase();

        for (const rec2Item of (arr2 || [{}])) {
          const currentRec2 = Object.keys(rec2Item||{}).length ? rec2Item : rec2_Base;
          if(rec2_Base && rec2_Base.__mv_Ozet && !currentRec2.__mv_Ozet) {
            Object.assign(currentRec2, { __mv_Ozet: rec2_Base.__mv_Ozet, __mv_Detay_Arac: rec2_Base.__mv_Detay_Arac, __mv_Detay_Tapu: rec2_Base.__mv_Detay_Tapu, __mv_Detay_IsMak: rec2_Base.__mv_Detay_IsMak, __mv_Detay_Deniz: rec2_Base.__mv_Detay_Deniz, __mv_Detay_Hava: rec2_Base.__mv_Detay_Hava, __malvarlikKayitDurumu: rec2_Base.__malvarlikKayitDurumu });
          }

          let arr3 = [{}];
          const useS3 = !!$('#useS3')?.checked;
          if (useOe && typeof fetchOzelEsasDetay === 'function') {
             // OE Logic placeholder
             const d = String(currentRec2.__oe_durum || '');
             const visibleLists = String(currentRec2.__oe_visibleLists || '').split(',').map(x=>x.trim()).filter(Boolean);
             if (visibleLists.length) {
                const tmp = [];
                for (const ln of visibleLists) {
                    const det = await fetchOzelEsasDetay(id, token, d, ln);
                    (det.arr || [{}]).forEach(it => tmp.push({ __oe_listName: ln, __oe_durum: d, ...it }));
                }
                arr3 = tmp.length ? tmp : [{ __oe_listName: '', __oe_durum: d }];
             } else { arr3 = [{ __oe_listName: '', __oe_durum: d }]; }
          } else if (useS3) {
            const r3 = await fetchService(id, token, 3, { 1: rec1, 2: currentRec2 });
            if (!r3.error) {
              let baseArr = (r3.arr && r3.arr.length) ? r3.arr : [r3.rec];
              const fp = $('#filterPath3')?.value;
              const fv = $('#filterValues3')?.value;
              if (fp && fv) {
                const allowed = fv.split(',').map(x=>x.trim()).filter(Boolean);
                baseArr = baseArr.filter(it => allowed.includes(String(get(it, fp))));
              }
              arr3 = ($('#expand3')?.checked && baseArr.length) ? baseArr : [baseArr[0] || {}];
            }
          }

          for (const rec3Item of (arr3 || [{}])) {
            const currentRec3 = useS3 ? (rec3Item||{}) : {};
            let arr4 = [{}];
            const useS4 = !!$('#useS4')?.checked;
            if (useS4) {
              const r4 = await fetchService(id, token, 4, { 1: rec1, 2: currentRec2, 3: currentRec3 });
              if (!r4.error) arr4 = ($('#expand4')?.checked && (r4.arr||[]).length) ? r4.arr : [r4.rec];
            }

            for (const rec4Item of (arr4 || [{}])) {
              const currentRec4 = useS4 ? (rec4Item||{}) : {};
              const recs = { 1: rec1, 2: currentRec2, 3: currentRec3, 4: currentRec4 };
              
              let detailArray = null;
              if (useS4 && s4ArrayBase) {
                const arr = getSmart(currentRec4, s4ArrayBase);
                if (Array.isArray(arr) && arr.length) detailArray = arr;
              }

              if (!detailArray) {
                const row = extractRow(id, recs);
                if (smartStatus) row[1] = smartStatus;
                rowsBuffer.push(row);
              } else {
                const blockRows = detailArray.map((_x, di) => extractRow(id, recs, di));
                applyDetailModes(blockRows);
                if (smartStatus) blockRows.forEach(r => r[1] = smartStatus);
                blockRows.forEach(r => rowsBuffer.push(r));
              }
            }
          }
        }
        return { ok:true, rows: rowsBuffer, recs: {1:rec1} };
      } catch (e) {
        return { ok:false, error: (e?.message || String(e)), recs: emptyRecs, rows: [] };
      }
    }

    async function runPreview(){
      try{
        const token = $('#token')?.value || '';
        const list = String($('#ids')?.value || '').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
        if(!list.length){ showToast('VKN listesi boş.', 'error'); return; }
        
        const n = Math.max(1, parseInt($('#previewCount')?.value || '5', 10) || 5);
        const sample = list.slice(0, n);
        
        // --- S1 ---
        const r1 = await fetchService(sample[0], token, 1, {});
        if(!r1.error){
          fieldLists[1] = collectKeysDeep(r1.rec || {}, '', new Set(), { maxDepth: 14, maxArrayDepth: 4, includeLeafOnly: true });
          renderFields(1);
        }

        // --- S2 (DÜZELTME BURADA YAPILDI) ---
        if($('#useS2')?.checked){
          const r2 = await fetchService(sample[0], token, 2, {1: (r1.rec||{})});
          if(!r2.error){
            
            // >>> EKLENEN BÖLÜM BAŞLANGIÇ: Malvarlığı Analizi Enjeksiyonu
            if (String($('#cmd2')?.value || '').includes('malVarligiService')) {
                const analiz = malvarlikAyrintiliAnaliz(r2.full);
                if (analiz) {
                    // Ham veriye (rec) sanal alanları ekliyoruz
                    Object.assign(r2.rec, { 
                        __mv_Ozet: analiz.ozet, 
                        __mv_Detay_Arac: analiz.arac, 
                        __mv_Detay_Tapu: analiz.tapu, 
                        __mv_Detay_IsMak: analiz.ismak, 
                        __mv_Detay_Deniz: analiz.deniz, 
                        __mv_Detay_Hava: analiz.hava,
                        // PDF kaydetme durumunu simüle edebiliriz (opsiyonel)
                        __malvarlikKayitDurumu: "KAYIT_DURUMU" 
                    });
                }
            }
            // <<< EKLENEN BÖLÜM BİTİŞ

            fieldLists[2] = collectKeysFromSample(r2.arr, r2.rec, { maxItems: 8 });
            renderFields(2);
          }
        }

        // --- S3 ---
        if($('#useS3')?.checked){
          const base = {1:(r1.rec||{}), 2:{}};
          const r3 = await fetchService(sample[0], token, 3, base);
          if(!r3.error){
            fieldLists[3] = collectKeysFromSample(r3.arr, r3.rec, { maxItems: 8 });
            renderFields(3);
          }
        }

        // --- S4 ---
        if($('#useS4')?.checked){
          const base = {1:(r1.rec||{}), 2:{}, 3:{}};
          const r4 = await fetchService(sample[0], token, 4, base);
          if(!r4.error){
            fieldLists[4] = collectKeysFromSample(r4.arr, r4.rec, { maxItems: 8 });
            renderFields(4);
          }
        }
        
        showToast('Ön izleme tamam. Alanlar güncellendi.', 'success');
      }catch(e){ showToast('Ön izleme hata: ' + (e?.message||e), 'error'); }
    }
    async function runTurbo(){
  // 1. EKSİK OLAN BU ÇAĞRI: Arayüzdeki seçili alanları okur.
  rebuildColumnsFromDOM(); 

  if(isRunning){
    stopRequested = true;
    showToast('Durduruluyor... (mevcut istekler bitsin)', 'info');
    return;
  }
  stopRequested = false;
  isRunning = true;
      rowsOut = [];
      paintRows();
      $('#btnCSV').disabled = true;
      writeHeader();
      ids = String($('#ids')?.value || '').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      window.startTime = Date.now();
      if(!ids.length){ isRunning = false; showToast('VKN listesi boş.', 'error'); return; }
      const sIdx = Math.max(0, parseInt($('#startIdx')?.value || '0', 10) || 0);
      let eIdx = parseInt($('#endIdx')?.value || '', 10);
      if(!eIdx || isNaN(eIdx) || eIdx <= 0) eIdx = ids.length;
      eIdx = Math.min(eIdx, ids.length);
      const token = $('#token')?.value || '';
      const tc = Math.max(1, parseInt($('#threadCount')?.value || '1', 10) || 1);
      const threadCount = Math.min(20, tc);
      const wm = parseInt($('#waitMs')?.value || '1500', 10);
      waitMsGlobal = (isNaN(wm) ? 1500 : Math.max(0, wm));
      $('#btnRun').textContent = 'Durdur';
      $('#stat').textContent = 'Başladı...';
      updateBar(sIdx, eIdx);
      let processed = 0;
      let nextPtr = sIdx;
      async function workerLoop(workerNo){
        while(true){
          if(stopRequested) return;
          const cur = nextPtr;
          if(cur >= eIdx) return;
          nextPtr++;
          const id = ids[cur];
          $('#stat').textContent = `⚡ İşleniyor: ${cur+1}/${eIdx} (W${workerNo})`;
          const res = await processSingleId(id, token);
          if(res && res.ok){
            const rr = (Array.isArray(res.rows) && res.rows.length) ? res.rows : [];
            rr.forEach(r => appendRow(r));
          } else {
            const msg = res?.error || res?.msg || 'Bilinmeyen';
            const errRow = extractRow(id, (res && res.recs) ? res.recs : {1:{},2:{},3:{},4:{}});
            errRow[1] = '❌ ' + String(msg);
            appendRow(errRow);
          }
          processed++;
          updateBar(sIdx + processed, eIdx);
          const calcWait = getHumanWaitTime(waitMsGlobal);
          if(calcWait > 0) await wait(calcWait);
        }
      }
      const workers = [];
      for(let w=1; w<=threadCount; w++) workers.push(workerLoop(w));
      await Promise.allSettled(workers);
      isRunning = false;
      if(stopRequested){
        $('#stat').textContent = 'Durduruldu';
        $('#btnRun').textContent = 'Kaldığı yerden devam';
        showToast('Durduruldu.', 'info');
        return;
      }
      await autoRetryFailedOnce(token);
      $('#stat').textContent = 'Bitti';
      $('#btnRun').textContent = '2) TURBO ZİNCİR SORGULA';
      $('#btnCSV').disabled = false;
      updateBar(eIdx, eIdx);
      showToast('Bitti', 'success');
      try{ playDone(); }catch(_){}
    }

    $('#btnColsSync').onclick = () => {
        try {
            const prev = Array.isArray(columnsConfig) ? columnsConfig : [];
            const newConfig = [];

            for (let s = 1; s <= SERVICE_COUNT; s++) {
                const checkedBoxes = document.querySelectorAll('.fld[data-svc="' + s + '"]:checked');
                checkedBoxes.forEach(cb => {
                    if (!isUsefulField(cb.value)) return;
                    const exists = newConfig.some(x => Number(x.svc) === Number(s) && String(x.field) === String(cb.value));
                    if (!exists) {
                        newConfig.push({
                            svc: s,
                            field: cb.value,
                            label: cb.getAttribute('data-label') || cb.value,
                            alias: ('S' + s + ':' + cb.value),
                            type: 'text',
                            detailMode: 'auto'
                        });
                    }
                });
            }

            newConfig.forEach(col => {
                const old = prev.find(x => Number(x?.svc) === Number(col.svc) && String(x?.field) === String(col.field));
                if (old) {
                    col.alias = old.alias || col.alias;
                    col.type = old.type || col.type;
                    col.detailMode = old.detailMode || col.detailMode;
                    col.label = old.label || col.label;
                }
            });

            columnsConfig = newConfig;
            renderColumnsTable();
            writeHeader();
            try { paintRows(); } catch(_) {}
            showToast('Seçili alanlar aşağı aktarıldı', 'success');
        } catch (e) {
            showToast('Kolon aktarımında hata: ' + (e?.message || e), 'error');
        }
    };

    function loadTplMap(){ try{ return JSON.parse(localStorage.getItem(TPL_KEY)||'{}'); }catch(e){return {};} }
    function saveTplMap(m){ localStorage.setItem(TPL_KEY, JSON.stringify(m)); }
    function refreshTplSel(){ $('#tplSelect').innerHTML='<option value="">(şablon yok)</option>'+Object.keys(loadTplMap()).sort().map(n=>`<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join(''); }
    
    $('#btnTplSave').onclick = () => {
      const name = $('#tplName').value.trim(); if(!name){ showToast('Ad yaz','error'); return; }
      for(let s=1;s<=SERVICE_COUNT;s++) selected[s] = [...document.querySelectorAll('.fld[data-svc="'+s+'"]:checked')].map(c=>c.value);
      rebuildColumnsFromDOM();
      const map = loadTplMap(); map[name] = collectConfigFromUI(); saveTplMap(map); refreshTplSel(); $('#tplSelect').value = name; showToast('Kaydedildi','success');
    };
    $('#btnTplUpdate').onclick = () => {
      const name = $('#tplSelect').value; if(!name){ showToast('Listeden bir şablon seçin','error'); return; }
      if(!confirm(name + ' şablonu güncellenecek. Emin misiniz?')) return;
      for(let s=1;s<=SERVICE_COUNT;s++) selected[s] = [...document.querySelectorAll('.fld[data-svc="'+s+'"]:checked')].map(c=>c.value);
      rebuildColumnsFromDOM();
      const map = loadTplMap(); map[name] = collectConfigFromUI(); saveTplMap(map); 
      showToast('Güncellendi','success');
    };
    $('#btnTplLoad').onclick = () => {
      const name = $('#tplSelect').value; if(!name){ showToast('Seçim yok','error'); return; }
      const aktifToken = $('#token')?.value || '';
      const aktifCookie = $('#cookie')?.value || '';
      const aktifIds = $('#ids')?.value || '';
      const loadedCfg = loadTplMap()[name];
      if (loadedCfg?.classic) { loadedCfg.classic.token = ''; loadedCfg.classic.cookie = ''; loadedCfg.classic.ids = ''; }
      applyConfigToUI(loadedCfg);
      if ($('#token') && aktifToken) $('#token').value = aktifToken;
      if ($('#cookie') && aktifCookie) $('#cookie').value = aktifCookie;
      if ($('#ids')) $('#ids').value = aktifIds;
      showToast('Yüklendi (token/cookie/liste korundu)','success');
      try { const n = $('#stat'); if (n && !String(n.textContent).includes('Token/Cookie')) n.textContent = 'Token/Cookie şablona kaydedilmez.'; } catch(_) {}
    };
    $('#btnTplDelete').onclick = () => {
      const name = $('#tplSelect').value; if(!name || !confirm('Silinsin mi?')) return;
      const map = loadTplMap();
      delete map[name]; saveTplMap(map); refreshTplSel(); showToast('Silindi','success');
    };
    $('#btnTplExport').onclick = () => {
      const blob = new Blob([JSON.stringify(loadTplMap(),null,2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'gib_sablonlar.json'; document.body.appendChild(a); a.click();
    };
    $('#btnTplImport').onclick = () => { $('#tplFile').click(); };
    $('#tplFile').onchange = (e) => {
      const f = e.target.files[0]; if(!f) return;
      const r = new FileReader(); r.onload = (evt) => { try { saveTplMap(Object.assign(loadTplMap(), JSON.parse(evt.target.result))); refreshTplSel(); showToast('İçe aktarıldı','success');
      } catch(e){ showToast('Hatalı dosya','error'); } }; r.readAsText(f);
    };

    $('#btnSessSave').onclick = () => saveSession(false);
    $('#btnSessLoad').onclick = () => {
        const d = JSON.parse(localStorage.getItem(SESS_KEY)); if(!d){ showToast('Oturum yok','error'); return;
        }
        applyConfigToUI(d.cfg); ids=d.ids||[]; lastIndex=d.lastIndex||0; rowsOut=d.rowsOut||[];
        $('#ids').value = ids.join('\n'); renderColumnsTable(); writeHeader(); paintRows(); showToast('Oturum yüklendi','success');
    };

    $('#btnCSV').onclick=()=>{
      if(!rowsOut.length) return;
      const rows = [[...document.querySelectorAll('#thead th')].map(th=>th.textContent)]; 
      rebuildColumnsFromDOM();
      rowsOut.forEach(orig=>{ 
          const row = [...orig]; 
          if(columnsConfig.length) columnsConfig.forEach((c,i)=>{ if(row[i+2]!=null && c.type==='text') row[i+2]="'"+row[i+2]; }); 
          upsertResultRow(row); 
      });
      const blob = new Blob(['\ufeff'+rows.map(a=>a.map(v=>'"'+String(v||'').replace(/"/g,'""').replace(/[\r\n]+/g,' ').trim()+'"').join(',')).join('\n')],{type:'text/csv;charset=utf-8'});
      const url = URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='gib_turbo_sonuc.csv'; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(url);a.remove();},0);
    };

    $('#btnRetryList').onclick = () => {
        const errTrs = [...document.querySelectorAll('#tbody tr')].filter(tr => tr.innerText.includes('❌'));
        if(!errTrs.length) { showToast('Hatalı kayıt bulunamadı','success'); return; }
        const errorIds = errTrs.map(tr => tr.getAttribute('data-id')).filter(Boolean);
        if(!errorIds.length) { showToast('ID verisi okunamadı','error'); return; }
        $('#ids').value = errorIds.join('\n');
        showToast(`${errorIds.length} hatalı kayıt listeye alındı.`,'info');
    };

    document.addEventListener('click',e=>{
      if(e.target.classList.contains('btnApplyDiscovery')){
        const svc = Number(e.target.getAttribute('data-svc'));
        const picks = [...document.querySelectorAll(`.discPick[data-svc="${svc}"]:checked`)].map(x=>x.value);
        if(picks.length === 1) { $('#arrayPath'+svc).value = picks[0]; chosenPathBySvc[svc] = picks[0]; }
        showToast('Uygulandı','success');
      }
      if(e.target.classList.contains('btnUp') || e.target.classList.contains('btnDown')){
        rebuildColumnsFromDOM(); const tr = e.target.closest('tr'), idx = columnsConfig.findIndex(c=>c.svc===Number(tr.getAttribute('data-svc')) && c.field===tr.getAttribute('data-field'));
        if(idx>=0){ 
            if(e.target.classList.contains('btnUp') && idx>0) [columnsConfig[idx-1], columnsConfig[idx]] = [columnsConfig[idx], columnsConfig[idx-1]];
            if(e.target.classList.contains('btnDown') && idx<columnsConfig.length-1) [columnsConfig[idx+1], columnsConfig[idx]] = [columnsConfig[idx], columnsConfig[idx+1]];
            renderColumnsTable();
        }
      }
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run, { once: true });
  } else {
    run();
  }
})();



(() => {
  'use strict';
  if (window.__zincirShellLoaded) return;
  window.__zincirShellLoaded = true;

  const SHELL_ID = '__zs_shell__';
  const BTN_ID = '__zs_launcher__';

  function ensureShellStyle() {
    if (document.getElementById('__zs_shell_style__')) return;
    const s = document.createElement('style');
    s.id = '__zs_shell_style__';
    s.textContent = `
      #${BTN_ID}{
        position:fixed; right:12px; bottom:12px; z-index:2147483647;
        background:#121826; color:#eaf0ff; border:1px solid #2b3852; border-radius:999px;
        padding:10px 14px; font:12px/1.2 'Segoe UI',sans-serif; cursor:pointer;
        box-shadow:0 8px 24px rgba(0,0,0,.35)
      }
      #${SHELL_ID}{
        position:fixed; right:12px; top:12px; z-index:2147483647;
        background:#060912; color:#eaf0ff; border:1px solid #232b3a; border-radius:8px;
        box-shadow:0 20px 50px rgba(0,0,0,.8); font:12px/1.4 'Segoe UI',sans-serif;
        min-width:260px; max-width:90vw;
      }
      #${SHELL_ID} .zs-head{
        display:flex; align-items:center; justify-content:space-between;
        padding:8px 10px; background:#121826; border-bottom:1px solid #232b3a;
        border-radius:8px 8px 0 0;
      }
      #${SHELL_ID} .zs-title{font-weight:700}
      #${SHELL_ID} .zs-actions button{
        background:none; border:0; color:#9ddcff; cursor:pointer; font-size:18px; margin-left:8px;
      }
      #${SHELL_ID} .zs-body{padding:8px}
      #${SHELL_ID}.minimized .zs-body{display:none}
    `;
    document.head.appendChild(s);
  }

  function createLauncher() {
    if (document.getElementById(BTN_ID)) return;
    const b = document.createElement('button');
    b.id = BTN_ID;
    b.textContent = 'Zincir Sorgu';
    b.addEventListener('click', () => {
      const shell = document.getElementById(SHELL_ID);
      if (shell) shell.style.display = 'block';
      b.style.display = 'none';
      showTargetPanels(true);
    });
    document.body.appendChild(b);
  }

  function createShell() {
    let shell = document.getElementById(SHELL_ID);
    if (shell) return shell;
    shell = document.createElement('div');
    shell.id = SHELL_ID;
    shell.innerHTML = `
      <div class="zs-head">
        <div class="zs-title">Zincir Sorgu</div>
        <div class="zs-actions">
          <button type="button" id="__zs_min__" title="Küçült">−</button>
          <button type="button" id="__zs_hide__" title="Kapat">×</button>
        </div>
      </div>
      <div class="zs-body">
        <div style="color:#9aa6bf">Panel yüklendi. İç panel sağ tarafta gösterilir.</div>
      </div>
    `;
    document.body.appendChild(shell);

    shell.querySelector('#__zs_min__').addEventListener('click', () => {
      shell.classList.toggle('minimized');
      showTargetPanels(!shell.classList.contains('minimized'));
    });
    shell.querySelector('#__zs_hide__').addEventListener('click', () => {
      shell.style.display = 'none';
      const b = document.getElementById(BTN_ID);
      if (b) b.style.display = 'block';
      showTargetPanels(false);
    });
    return shell;
  }

  function candidatePanels() {
    const ids = [
      'gib-panel','gib-hybrid-panel','zincir-panel','gib-zincir-panel',
      'gib-otomasyon-panel','hybrid-panel','gib-borc-panel','eys-akis-panel'
    ];
    const found = [];
    ids.forEach(id => {
      const el = document.getElementById(id);
      if (el) found.push(el);
    });

    const extra = Array.from(document.querySelectorAll('body > div')).filter(el => {
      const id = el.id || '';
      const txt = ((el.innerText || '').slice(0, 120)).toLowerCase();
      const style = getComputedStyle(el);
      const fixedish = style.position === 'fixed';
      return fixedish && (
        id.includes('zincir') || id.includes('gib') || id.includes('panel') ||
        txt.includes('hibrit otomasyon') || txt.includes('zincir sorgu')
      );
    });
    extra.forEach(el => { if (!found.includes(el)) found.push(el); });
    return found;
  }

  function showTargetPanels(show) {
    candidatePanels().forEach(el => {
      if (el.id === SHELL_ID || el.id === BTN_ID) return;
      el.style.display = show ? 'block' : 'none';
    });
  }

  function normalizeTargetPanels() {
    candidatePanels().forEach(el => {
      if (el.id === SHELL_ID || el.id === BTN_ID) return;
      el.style.top = '54px';
      el.style.right = '12px';
      el.style.zIndex = '2147483646';
    });
  }

  function bootShell() {
    ensureShellStyle();
    createShell();
    createLauncher();
    setTimeout(() => {
      normalizeTargetPanels();
      showTargetPanels(true);
      const b = document.getElementById(BTN_ID);
      if (b) b.style.display = 'none';
    }, 1200);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootShell, { once:true });
  } else {
    bootShell();
  }
})();
