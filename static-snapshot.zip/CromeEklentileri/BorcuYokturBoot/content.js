(() => {
  'use strict';

  if (window.__gibBorcPanelLoaded) return;
  window.__gibBorcPanelLoaded = true;

  const PANEL_ID = 'gib-borc-panel';

  const ddmmyyyy_to_yyyymmdd = (dateStr) => {
    if (!dateStr) return "";
    const parts = dateStr.split('.');
    if (parts.length === 3) return parts[2] + parts[1] + parts[0];
    return dateStr;
  };

  const randomBetween = (min, max) => {
    const lo = Math.min(min, max);
    const hi = Math.max(min, max);
    return Math.floor(Math.random() * (hi - lo + 1)) + lo;
  };

  const today = new Date();
  const formattedDate = String(today.getDate()).padStart(2, '0') + '.'
                      + String(today.getMonth() + 1).padStart(2, '0') + '.'
                      + today.getFullYear();

  const AUTO_DELAY_MIN_MS = 900;
  const AUTO_DELAY_MAX_MS = 2200;
  const AUTO_RESCAN_MIN_SEC = 240;
  const AUTO_RESCAN_MAX_SEC = 420;

  let detectedVdKodu = "016253";
  let detectedVdAdi = "ÇEKİRGE VERGİ DAİRESİ";

  try {
    if (window.CSSession) {
      const c = window.CSSession;

      const tryCall = (fnName) => {
        try {
          return (typeof c[fnName] === 'function') ? c[fnName]() : undefined;
        } catch (e) {
          return undefined;
        }
      };

      const firstFilled = (...vals) => vals.find(v => v !== undefined && v !== null && String(v).trim() !== '');

      const rawVdKodu = firstFilled(
        tryCall('getVdKodu'),
        c.vdKodu,
        c.vdkodu,
        c.vdKoduValue,
        c.vdkoduValue,
        tryCall('getVergiDairesiKodu'),
        c.vergiDairesiKodu,
        c.vergidairesikodu,
        tryCall('getOrgOid'),
        Array.isArray(c.orgOidList) ? c.orgOidList[0] : undefined,
        c.orgOid,
        c.orgoid
      );

      const rawVdAdi = firstFilled(
        tryCall('getVdAdi'),
        tryCall('getBirimAdi'),
        c.vdAdi,
        c.vdadi,
        c.birimAdi,
        c.birimadi,
        tryCall('getVergiDairesiAdi'),
        c.vergiDairesiAdi,
        c.vergidairesiadi
      );

      if (rawVdKodu) detectedVdKodu = String(rawVdKodu).trim();
      if (rawVdAdi) detectedVdAdi = String(rawVdAdi).trim();
    }
  } catch (e) {
    console.warn('CSSession bilgileri alınamadı, varsayılan değerler kullanılacak.', e);
  }

  const panelContainer = document.createElement('div');
  panelContainer.id = PANEL_ID;
  panelContainer.innerHTML = `
    <style>
      #gib-borc-panel-inner {
        position: fixed; top: 10%; right: 2%;
        width: 400px; max-width: 95vw; z-index: 999999;
        background: #060912; color: #eaf0ff; font: 12px/1.5 'Segoe UI', sans-serif;
        border: 1px solid #232b3a; border-radius: 8px; box-shadow: 0 20px 50px rgba(0,0,0,0.8);
      }
      #gib-borc-panel-inner .header { display: flex; justify-content: space-between; align-items: center; padding: 10px 15px;
        border-bottom: 1px solid #232b3a; background: #121826; border-radius: 8px 8px 0 0; }
      #gib-borc-panel-inner .header h3 { margin: 0; font-size: 14px; }
      #gib-borc-panel-inner .header-btns button { background: none; border: 0; cursor: pointer; font-weight: bold; margin-left: 10px; }
      #gib-borc-panel-inner .wrap { padding: 15px; transition: all 0.3s; }
      #gib-borc-panel-inner input { width: 100%; box-sizing: border-box; background: #050814; border: 1px solid #273048;
        padding: 8px; color: #eaf0ff; margin-bottom: 10px; border-radius: 4px; }
      #gib-borc-panel-inner button.action-btn { width: 100%; padding: 10px; border-radius: 4px; border: 0; font-weight: bold; cursor: pointer; transition: 0.2s; }
      #gib-borc-panel-inner #logBox { background: #000; color: #0f0; font-family: monospace; font-size: 11px;
        padding: 8px; height: 150px; overflow-y: auto; margin-top: 10px; border: 1px solid #333; }
    </style>
    <div id="gib-borc-panel-inner">
      <div class="header">
          <h3>📄 GİB İş Emri Onay Botu</h3>
          <div class="header-btns">
              <button id="gib-borc-toggle" style="color:#00d2ff; font-size:18px;" title="Küçült/Büyüt">−</button>
              <button id="gib-borc-close" style="color:red; font-size:18px;" title="Kapat">×</button>
          </div>
      </div>
      <div class="wrap" id="panel-wrap">
          <label>VD Kodu</label>
          <input id="u_vdkodu" value="${detectedVdKodu}" disabled title="Sistemden otomatik çekildi">
          <label>VD Adı</label>
          <input id="u_vdadi" value="${detectedVdAdi}" disabled title="Sistemden otomatik çekildi">
          <label>Başlangıç Tarihi</label>
          <input id="u_tarih_bas" value="${formattedDate}">
          <label>Bitiş Tarihi</label>
          <input id="u_tarih_bit" value="${formattedDate}">
          <button id="u_run" class="action-btn" style="background: #3ccf91; color: #00170c;">İŞLEMLERİ BAŞLAT</button>
          <div id="logBox"></div>
      </div>
    </div>
  `;
  document.body.appendChild(panelContainer);

  window._botRunning = false;
  window._botTimeout = null;

  const panelWrap = document.getElementById('panel-wrap');
  document.getElementById('gib-borc-toggle').addEventListener('click', () => {
    panelWrap.style.display = panelWrap.style.display === 'none' ? 'block' : 'none';
  });
  document.getElementById('gib-borc-close').addEventListener('click', () => {
    panelContainer.style.display = 'none';
  });

  window._log = (m, e=false) => {
    const b = document.querySelector('#logBox');
    if (b) {
      b.innerHTML += `<div><span style="color:#777">[${new Date().toLocaleTimeString()}]</span> ${e ? '<span style="color:red">HATA: </span>' : ''}${m}</div>`;
      b.scrollTop = b.scrollHeight;
    }
  };

  window.toggleBot = () => {
    const btn = document.getElementById('u_run');
    if (window._botRunning) {
      window._botRunning = false;
      clearTimeout(window._botTimeout);
      btn.innerText = "İŞLEMLERİ BAŞLAT";
      btn.style.background = "#3ccf91";
      btn.style.color = "#00170c";
      window._log("🛑 Otomatik onaylama döngüsü DURDURULDU.");
    } else {
      window._botRunning = true;
      btn.innerText = "🛑 İŞLEMLERİ DURDUR";
      btn.style.background = "#cf3c3c";
      btn.style.color = "#fff";
      window._log("🟢 Otomatik onaylama BAŞLATILDI.");
      window._log(`⚙️ Otomatik tempo aktif: onay ${AUTO_DELAY_MIN_MS}-${AUTO_DELAY_MAX_MS} ms, yeniden tarama ${AUTO_RESCAN_MIN_SEC}-${AUTO_RESCAN_MAX_SEC} sn.`);
      window.onaylamayiBaslat();
    }
  };

  document.getElementById('u_run').addEventListener('click', window.toggleBot);

  window._api = async (cmd, jp) => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const targetUrl = "/gibintranet_server/dispatch";

    const ALLOWED_PREFIXES = ["isEmriIslemleriService_"];
    if (cmd && !ALLOWED_PREFIXES.some(p => cmd.startsWith(p))) {
      return { ok: false, skipped: true, status: 0, data: null };
    }

    const p = new URLSearchParams();
    if (cmd) p.append('cmd', cmd);
    p.append('callid', Date.now().toString());
    if (token) p.append('token', token);
    if (jp) p.append('jp', JSON.stringify(jp));

    try {
      const r = await fetch(targetUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: p
      });
      if (!r.ok) return { ok: false, status: r.status, data: null };

      let j = null;
      try { j = await r.json(); } catch(e) { return { ok: false, status: 200, data: null }; }
      return { ok: true, status: 200, data: j };
    } catch (err) {
      return { ok: false, status: -1, data: null };
    }
  };

  window.onaylamayiBaslat = async () => {
    if (!window._botRunning) return;

    const basTxt = document.getElementById('u_tarih_bas').value;
    const bitTxt = document.getElementById('u_tarih_bit').value;

    try {
      const bas = ddmmyyyy_to_yyyymmdd(basTxt);
      const bit = ddmmyyyy_to_yyyymmdd(bitTxt);
      const vdkodu = (document.getElementById('u_vdkodu')?.value || detectedVdKodu || "016253").trim();
      const vdAdi = (document.getElementById('u_vdadi')?.value || detectedVdAdi || "").trim();

      const globalMinDelay = Math.min(AUTO_DELAY_MIN_MS, AUTO_DELAY_MAX_MS);
      const globalMaxDelay = Math.max(AUTO_DELAY_MIN_MS, AUTO_DELAY_MAX_MS);
      const cycleDelayMin = randomBetween(globalMinDelay, globalMaxDelay);
      const cycleDelayMax = randomBetween(cycleDelayMin, globalMaxDelay);
      const nextRescanSec = randomBetween(Math.min(AUTO_RESCAN_MIN_SEC, AUTO_RESCAN_MAX_SEC), Math.max(AUTO_RESCAN_MIN_SEC, AUTO_RESCAN_MAX_SEC));
      window._nextRescanMs = nextRescanSec * 1000;

      window._log(`🏢 Aktif birim: ${vdkodu}${vdAdi ? " - " + vdAdi : ""}`);
      window._log(`🎲 Bu tur için onay aralığı üretildi: ${cycleDelayMin}-${cycleDelayMax} ms`);
      window._log(`🎲 Bu tur sonrası yeniden tarama: ${nextRescanSec} sn`);
      window._log(`🔄 Liste kontrol ediliyor... (${basTxt} - ${bitTxt})`);

      const sResWrap = await window._api("isEmriIslemleriService_onaylanmayaiBekleyenIsEmriListesiGetir", {
        vdkodu, baszaman: bas, bitzaman: bit
      });

      if (!sResWrap.ok) {
        window._log("Sorgu çalışmadı veya yetki hatası.", true);
        return;
      }

      const responseData = sResWrap.data || {};
      const isEmirleri = responseData.data?.isEmirleri || responseData.isEmirleri || [];

      if (!isEmirleri.length) {
        window._log("Onay bekleyen yeni iş emri yok.");
      } else {
        window._log(`${isEmirleri.length} iş emri bulundu. Onaylanıyor...`);

        for (const item of isEmirleri) {
          if (!window._botRunning) break;

          const oid = item?.oid;
          if (!oid) continue;

          const oResWrap = await window._api("isEmriIslemleriService_isEmriOnayla", { oid, vdkodu });
          const oPayload = oResWrap.data || {};
          const msg = oPayload.data?.msgTBS || oPayload.msgTBS;

          if (msg) {
            window._log(`✅ ${oid} → ${msg}`);
          } else if (oResWrap.ok) {
            window._log(`✅ ${oid} - Onaylandı.`);
          }

          if (window._botRunning) {
            const bekleme = randomBetween(cycleDelayMin, cycleDelayMax);
            window._log(`⏳ Sonraki onay için ${bekleme} ms bekleniyor...`);
            await new Promise(r => setTimeout(r, bekleme));
          }
        }
      }
    } catch (err) {
      window._log(err.message || String(err), true);
    } finally {
      if (window._botRunning) {
        const beklemeMs = Number.isFinite(window._nextRescanMs) ? window._nextRescanMs : (5 * 60 * 1000);
        window._log(`⏳ Bu tur bitti. ${Math.round(beklemeMs / 1000)} sn sonra yeniden taranacak...`);
        window._botTimeout = setTimeout(() => {
          window.onaylamayiBaslat();
        }, beklemeMs);
      }
    }
  };
})();