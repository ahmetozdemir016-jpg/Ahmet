Chrome eklentisi kullanımı

1. Bu klasörü bilgisayarına çıkar.
2. Chrome adres satırına şunu yaz:
   chrome://extensions
3. Sağ üstten Geliştirici modu'nu aç.
4. Paketlenmemiş öğe yükle'ye bas.
5. Bu klasörü seç.
6. GİB sayfasını yenile.

Bu eklenti BorcuYoktur otomasyon kodunu Chrome eklentisi olarak çalıştırır.
Sayfada 'GİB İş Emri Onay Botu' paneli açılır.
