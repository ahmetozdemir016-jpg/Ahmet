 
function faaliyet(vkno) {

var myRegex= /[0-9]+/;
var tokenlink =$('#token').val();
var myRegexp= /token=(\S+)/;
var token = myRegexp.exec(tokenlink)
var callid=makeid(13) + '-';

var url5= 'http://keys.ggm.bim/gibintranet_server/dispatch?cmd=sicilService_sicilBilgileriSorgulaIlKodu&callid=';
var url5=url5.concat(callid + '15', '&token=', token[1], '&jp=%7B%22vkn%22%3A%22',vkno,'%22%2C%22tckn%22%3A%22%22%2C%22vdKodu%22%3A%22%22%2C%22ilKodu%22%3A%22%22%7D');

var daireler = getRemote(url5);
var obj =JSON.parse(daireler);

      var vkn=obj.data.vkn; 
      var daireListesi = obj.data.vdler.baglivd; /// vergi dairesi listeliyor
      var b=0;    

	  var faaliyetDizi =new Array();
	 var faaliyetKodu=new Array();
	 
	$.each(daireListesi, function(index, satir){
	
	  var isyerinitelik = satir.isyerinitelik;
	  var birimOid= satir.birimoid;
	  var subeno = satir.subeno;
	  var subeadi=satir.subeadi;
	  var isyerinitelik=satir.isyerinitelik;
	  var isyerituru= satir.isyerituru;
	  var mukblgoid=satir.mukblgoid;
	  var vdkodu=satir.vdkodu;
	  
	
	 
	  
	  ////////////fAALİYET BİLGİLERİNİ GETİRECEZ
	
	  if (vdkodu=="016253") {

//&jp=%7B%22vkn%22%3A%220010083274%22%2C%22vdkodu%22%3A%22016253%22%2C%22birimOid%22%3A%220chr3onnhp1rrt%22%2C%22subeno%22%3A%221%22%2C%22subeadi%22%3A%22%22%2C%22isyerituru%22%3A%221%22%2C%22isyerinitelik%22%3A%221%22%2C%22mukblgoid%22%3A%220chr3onnhp1rrs%22%7D
	  
	      var urlFaaliyet= 'http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukSicilDetayBilgileriGetir&callid=';
	      var urlFaaliyet=urlFaaliyet.concat(callid + '101', '&token=', token[1], '&jp=%7B%22vkn%22%3A%22',vkn,'%22%2C%22vdkodu%22%3A%22016253%22%2C%22birimOid%22%3A%22',birimOid,'%22%2C%22subeno%22%3A%22',subeno,'%22%2C%22subeadi%22%3A%22%22%2C%22isyerituru%22%3A%22',isyerituru,'%22%2C%22isyerinitelik%22%3A%22',isyerinitelik,'%22%2C%22mukblgoid%22%3A%22',mukblgoid,'%22%7D');
	      var faaliyet = getRemote(urlFaaliyet);
	      var objFaaliyet =JSON.parse(faaliyet);
	      
		  var faaliyetListesi=objFaaliyet.data.faaliyetListesi.faaliyet;
		  
		  $.each(faaliyetListesi, function(index, satir1){
		  
		  if (faaliyetKodu.includes(satir1.faaliyetkod)){
		  
		  }else{
		  faaliyetKodu[b]=satir1.faaliyetkod;
		  faaliyetDizi[b]=satir1.faaliyetkod + "-" + satir1.faaliyetad + "<br>";
		  
		  b=b+1;
		  
		  }
		  
		  });
  
	  }

});

return faaliyetDizi;


}

