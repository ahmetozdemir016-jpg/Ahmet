// v4.31.54: Panel yerleşimi, kapatma ve boyutlandırma düzeltildi; hook tüm tokenleri bekler.
(() => {
  'use strict';
  if (window.__istakipYoklamaBotLoadedV419) return;
  window.__istakipYoklamaBotLoadedV419 = true;

  const CFG = {
    PANEL_ID: 'istakip-yoklama-bot-panel-v419',
    STYLE_ID: 'istakip-yoklama-bot-style-v419',
    STORAGE_KEY: 'istakip_yoklama_bot_v419_settings',
    DISCOVERY_KEY: 'istakip_yoklama_bot_v419_discovery',
    UI_KEY: 'istakip_yoklama_bot_v419_ui',
    RESTORE_ID: 'istakip-yoklama-bot-restore-v419',
    DISPATCH_URL: `${location.origin}/istakip_server/dispatch`,
    KEYS_DISPATCH_URL: `${location.origin}/keyss/external_dispatch`,
    FLEXPAPER_URL: `${location.origin}/keyss/flexpaper/pdf/`,
    DEFAULT_LIMIT: 50,
    COMMANDS: {
      LIST: 'isTakipSorgulamalarServices_isleriSorgula',
      NEXT_STEPS: 'akisIslemleri_isTakipSonrakiAdimlariBul',
      SAVE_STEP: 'akisIslemleri_akisYeniAdimKaydet',
      ACTIVE_COUNTS: 'isTakipSorgulamalarServices_aktifIsSayilariniBul',
      USER_SESSION: 'userSessionService_getUserSessionInfo'
    }
  };


  const PAGE_HOOK_EVENT = '__ISTAKIP_BOT_V4_DISCOVERY__';

  function wirePageMessages() {
    if (window.__istakipV419MsgWired) return;
    window.__istakipV419MsgWired = true;
    window.addEventListener('message', ev => {
      try {
        if (ev.source !== window) return;
        const d = ev.data;
        if (!d || d.type !== PAGE_HOOK_EVENT) return;
                if (d.cmd) state.discovery.lastCmd = d.cmd;
        const src = (d.source || 'page-hook') + (d.cmd ? `:${d.cmd}` : '');
        const rawModule = d.moduleName || d.payload?.moduleName || d.payload?.modulAdi || d.payload?.module || '';
        const moduleName = normalizeModuleName(rawModule);
        if (moduleName) setPendingModule(moduleName, src);

        if (/assos-login-response/i.test(src)) {
          if (d.token) logBaseDiscovery('token', d.token, src);
          if (d.userId) logBaseDiscovery('userId', d.userId, src);
          if (d.orgoid) logBaseDiscovery('orgoid', d.orgoid, src);
          if (state.discovery.pendingModule && d.token) {
            rememberModuleToken(state.discovery.pendingModule, d.token, src + ':pending-bound');
          }
        }

        if (d.token) logDiscovery('token', d.token, src);
        if (d.userId) logDiscovery('userId', d.userId, src);
        if (d.orgoid) logDiscovery('orgoid', d.orgoid, src);
        if (d.payload && typeof d.payload === 'object') {
          if (Array.isArray(d.payload.tokens)) rememberPageTokenList(d.payload.tokens, src);
          learnFromObject(d.payload, d.source || 'page-hook:payload');
        }
        persistDiscovery();
        renderDiscovery();
        maybeStopHooksAfterDiscovery(src);
      } catch (_) {}
    });
  }

  function injectPageHook() {
    // v4.31.49: Sayfa CSP'si script etiketi enjeksiyonunu engelleyebiliyor.
    // page_hook.js artık manifestte world:"MAIN" content script olarak çalışıyor.
    try { window.postMessage({ type: '__ISTAKIP_EYS_SESSION_REQUEST__' }, '*'); } catch (_) {}
  }

  const REQUIRED_HOOK_TOKEN_MODULES = ['gp', 'g', 'istakip', 'evdo', 'e'];

  function discoveryHasEnoughTokens() {
    try {
      const d = state.discovery || {};
      const mods = d.tokensByModule || {};
      const userId = d.userId || d.baseUserId || '';
      const orgoid = d.orgoid || d.baseOrgoid || '';
      const hasAllModuleTokens = REQUIRED_HOOK_TOKEN_MODULES.every(m => !!String(mods[m] || '').trim());
      return !!(userId && orgoid && hasAllModuleTokens);
    } catch (_) { return false; }
  }

  function moduleNameFromPageTokenSource(source) {
    const s = String(source || '');
    let m = '';
    const m1 = s.match(/CSSession\.getToken\((?:module:)?([^\)]+)\)/i);
    if (m1) m = m1[1];
    if (!m) {
      const m2 = s.match(/getToken[:\s]+(gp|g|istakip|evdo|e)\b/i);
      if (m2) m = m2[1];
    }
    return normalizeModuleName(String(m || '').replace(/^module:/i, '').trim());
  }

  function rememberPageTokenList(tokens, sourcePrefix = 'page-token-list') {
    try {
      if (!Array.isArray(tokens)) return;
      for (const item of tokens) {
        const token = String(item && item.token || '').trim();
        if (!token) continue;
        const src = `${sourcePrefix}:${item.source || 'token'}`;
        const moduleName = moduleNameFromPageTokenSource(item.source || '');
        if (moduleName) {
          rememberModuleToken(moduleName, token, src);
          if (moduleName === 'gp' || moduleName === 'g') logBaseDiscovery('token', token, src);
        } else {
          logDiscovery('token', token, src);
        }
      }
    } catch (_) {}
  }

  function stopPageNetworkHook(reason = 'tokens-captured') {
    try {
      if (state.discovery) state.discovery.hookStopped = true;
      window.__istakipDiscoveryStopped = true;
      window.postMessage({ type: '__ISTAKIP_EYS_STOP_HOOK__', reason }, '*');
    } catch (_) {}
  }

  function maybeStopHooksAfterDiscovery(reason = 'discovery-update') {
    try {
      if (!state.discovery || state.discovery.hookStopped) return;
      if (discoveryHasEnoughTokens()) stopPageNetworkHook(reason);
    } catch (_) {}
  }


  const state = {
    jobs: [],
    eligibleJobs: [],
    running: false,
    stopRequested: false,
    discovery: {
      token: '',
      userId: '',
      orgoid: '',
      baseToken: '',
      baseUserId: '',
      baseOrgoid: '',
      baseUserLocked: false,
      baseOrgoidLocked: false,
      baseSource: { token: '', userId: '', orgoid: '' },
      pendingModule: '',
      tokensByModule: { gp: '', g: '', istakip: '', evdo: '', e: '' },
      tokenSourceByModule: { gp: '', g: '', istakip: '', evdo: '', e: '' },
      source: { token: '', userId: '', orgoid: '' },
      lastCmd: '',
      lastModuleName: '',
      lastUsedToken: '',
      lastUsedTokenSource: '',
      hookStopped: false,
      history: []
    },
    detailMap: {},
    ykStatusCache: new Map()
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = (sel, root = document) => root.querySelector(sel);

  function itHtmlEscape(v) {
    return String(v ?? '').replace(/[&<>"']/g, ch => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[ch]));
  }

  function textOf(el) {
    return ((el?.innerText || el?.textContent || el?.value || '') + '').replace(/\s+/g, ' ').trim();
  }

  function safeCall(obj, fn) {
    try { return obj && typeof obj[fn] === 'function' ? obj[fn]() : undefined; }
    catch (_) { return undefined; }
  }

  function isGenericUserValue(v) {
    const s = String(v || '').trim().toLowerCase();
    return !s || s === 'g.i.b.' || s === 'gib' || s === 'g.i.b' || s === 'gelir idaresi başkanlığı';
  }

  function isMeaningfulUserValue(v) {
    return !!String(v || '').trim() && !isGenericUserValue(v);
  }

  function logBaseDiscovery(kind, value, source) {
    if (!value) return;
    const next = String(value).trim();
    if (!next) return;
    const keyMap = { token: 'baseToken', userId: 'baseUserId', orgoid: 'baseOrgoid' };
    const srcKey = kind;
    const valueKey = keyMap[kind];
    if (!valueKey) return;

    if (kind === 'userId') {
      const current = String(state.discovery.baseUserId || '').trim();
      const locked = !!state.discovery.baseUserLocked;
      if (locked && current && current !== next) return;
      if (!current && isMeaningfulUserValue(next)) {
        state.discovery.baseUserId = next;
        state.discovery.baseSource[srcKey] = source;
        state.discovery.baseUserLocked = true;
        state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.userId <= ${next} (${source}) [locked]`);
        if (state.discovery.history.length > 60) state.discovery.history.shift();
        return;
      }
      if (current && isMeaningfulUserValue(current) && isGenericUserValue(next)) return;
    }

    if (kind === 'orgoid') {
      const current = String(state.discovery.baseOrgoid || '').trim();
      const locked = !!state.discovery.baseOrgoidLocked;
      if (locked && current && current !== next) return;
      if (!current && next) {
        state.discovery.baseOrgoid = next;
        state.discovery.baseSource[srcKey] = source;
        state.discovery.baseOrgoidLocked = true;
        state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.orgoid <= ${next} (${source}) [locked]`);
        if (state.discovery.history.length > 60) state.discovery.history.shift();
        return;
      }
    }

    if (state.discovery[valueKey] && state.discovery[valueKey] === next && state.discovery.baseSource[srcKey] == source) return;
    state.discovery[valueKey] = next;
    state.discovery.baseSource[srcKey] = source;
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] base.${kind} <= ${next} (${source})`);
    if (state.discovery.history.length > 60) state.discovery.history.shift();
  }

  function setPendingModule(moduleName, source='') {
    const m = normalizeModuleName(moduleName);
    if (!m) return;
    state.discovery.pendingModule = m;
    state.discovery.lastModuleName = m;
    if (source) {
      state.discovery.history.push(`[${new Date().toLocaleTimeString()}] pendingModule <= ${m} (${source})`);
      if (state.discovery.history.length > 60) state.discovery.history.shift();
    }
    persistDiscovery();
    renderDiscovery();
  }

  function normalizeModuleName(v) {
    const s = String(v || '').trim().toLowerCase();
    if (!s) return '';
    if (['gp', 'g', 'istakip', 'evdo', 'e'].includes(s)) return s;
    if (s.includes('istakip')) return 'istakip';
    if (s.includes('evdo') || s.includes('evdb')) return 'evdo';
    if (s === 'eys' || s.includes('edenetis') || s === 'e') return 'e';
    if (s.includes('gibintranet') || s == 'g') return 'g';
    if (s.includes('gp')) return 'gp';
    return s;
  }

  function moduleTokenPriority(moduleName, source) {
    const m = normalizeModuleName(moduleName);
    const s = String(source || '').toLowerCase();
    if (s.includes('pending-bound')) return 300;
    if (m === 'istakip') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:istakip')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'evdo') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:evdo')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'e') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 180;
      if (s.includes('cssession.gettoken:e')) return 120;
      if (s.includes('assos-login-response')) return 110;
    }
    if (m === 'g' || m === 'gp') {
      if (s.includes('module-bound')) return 280;
      if (s.includes('side.get_module_info')) return 170;
      if (s.includes('side.get_service_def_list')) return 160;
      if (s.includes('assos-login-response')) return 150;
      if (s.includes('cssession.gettoken')) return 120;
    }
    return 50;
  }

  function rememberModuleToken(moduleName, token, source) {
    const m = normalizeModuleName(moduleName);
    const t = String(token || '').trim();
    if (!m || !t) return;
    const cur = state.discovery.tokensByModule[m] || '';
    const curSrc = state.discovery.tokenSourceByModule[m] || '';
    if (!cur || moduleTokenPriority(m, source) >= moduleTokenPriority(m, curSrc)) {
      state.discovery.tokensByModule[m] = t;
      state.discovery.tokenSourceByModule[m] = source;
      state.discovery.lastModuleName = m;
      state.discovery.history.push(`[${new Date().toLocaleTimeString()}] tokenByModule.${m} <= ${t} (${source})`);
      if (state.discovery.history.length > 40) state.discovery.history.shift();
      if (m === 'istakip') {
        state.discovery.token = t;
        state.discovery.source.token = `tokenByModule.${m} <= ${source}`;
      }
      persistDiscovery();
      renderDiscovery();
      try { maybeStopHooksAfterDiscovery(`tokenByModule.${m}`); } catch (_) {}
    }
  }

  function resolveTokenForModule(moduleName) {
    const m = normalizeModuleName(moduleName);
    if (m && state.discovery.tokensByModule[m]) return state.discovery.tokensByModule[m];
    const cssToken = safeGetCssToken(m);
    if (cssToken) return cssToken;
    if (!m) return state.discovery.token || getTokenFromUrl() || '';
    return '';
  }

  function sourcePriority(kind, source) {
    const s = String(source || '').toLowerCase();
    if (kind === 'token') {
      if (s.includes('module-bound')) return 260;
      if (s.includes('assos-login-response')) return 250;
      if (s.includes('side.get_module_info')) return 200;
      if (s.includes('side.get_service_def_list')) return 190;
      if (s.includes('assos-login') && s.includes('form-token')) return 130;
      if (s.includes('main.jsp')) return 100;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 90;
      if (s.includes('cssession.gettoken')) return 50;
      if (s.includes('url:token')) return 10;
    }
    if (kind === 'orgoid') {
      if (s.includes('akisislemleri_istakipsonrakiadimlaribul')) return 200;
      if (s.includes('akisislemleri_akisyeniadimkaydet')) return 190;
      if (s.includes('usersessionservice_getusersessioninfo')) return 170;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 150;
      if (s.includes('page-xhr') || s.includes('page-fetch')) return 70;
      if (s.includes('cssession.getorgoid')) return 50;
    }
    if (kind === 'userId') {
      if (s.includes('assos-login-response')) return 140;
      if (s.includes('usersessionservice_getusersessioninfo')) return 130;
      if (s.includes('page-xhr-response') || s.includes('page-fetch-response')) return 110;
      if (s.includes('page-xhr') || s.includes('page-fetch')) return 80;
      if (s.includes('cssession.getuserid')) return 60;
    }
    return 20;
  }

  function shouldOverwrite(kind, nextValue, nextSource) {
    const current = String(state.discovery[kind] || '').trim();
    const currentSource = state.discovery.source[kind] || '';
    if (!current) return true;
    if (current === String(nextValue).trim()) return sourcePriority(kind, nextSource) >= sourcePriority(kind, currentSource);
    return sourcePriority(kind, nextSource) >= sourcePriority(kind, currentSource);
  }

  function logDiscovery(kind, value, source) {
    if (!value) return;
    const next = String(value).trim();
    if (!next) return;
    if (!shouldOverwrite(kind, next, source)) return;
    const current = state.discovery[kind];
    if (current === next && state.discovery.source[kind] === source) return;
    state.discovery[kind] = next;
    state.discovery.source[kind] = source;
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] ${kind} <= ${next} (${source})`);
    if (state.discovery.history.length > 30) state.discovery.history.shift();
    persistDiscovery();
    renderDiscovery();
  }

  function persistDiscovery() {
    try {
      itChromeStorageSetSafe({ [CFG.DISCOVERY_KEY]: state.discovery });
    } catch (_) {}
  }

  function restoreDiscovery(cb) {
    try {
      itChromeStorageGetSafe([CFG.DISCOVERY_KEY], out => {
        const d = out?.[CFG.DISCOVERY_KEY];
        if (d && typeof d === 'object') {
          state.discovery = {
            token: d.token || '',
            userId: d.userId || '',
            orgoid: d.orgoid || '',
            baseToken: d.baseToken || '',
            baseUserId: d.baseUserId || '',
            baseOrgoid: d.baseOrgoid || '',
            baseUserLocked: !!d.baseUserLocked,
            baseOrgoidLocked: !!d.baseOrgoidLocked,
            baseSource: d.baseSource || { token: '', userId: '', orgoid: '' },
            pendingModule: d.pendingModule || '',
            tokensByModule: d.tokensByModule || { gp: '', g: '', istakip: '', evdo: '', e: '' },
            tokenSourceByModule: d.tokenSourceByModule || { gp: '', g: '', istakip: '', evdo: '', e: '' },
            source: d.source || { token: '', userId: '', orgoid: '' },
            lastCmd: d.lastCmd || '',
            lastModuleName: d.lastModuleName || '',
            lastUsedToken: d.lastUsedToken || '',
            lastUsedTokenSource: d.lastUsedTokenSource || '',
            history: Array.isArray(d.history) ? d.history.slice(-50) : []
          };
        }
        cb?.();
      });
    } catch (_) { cb?.(); }
  }


  function safeGetCssToken(moduleName) {
    try {
      const css = window.CSSession || {};
      if (typeof css.getToken === 'function') {
        return moduleName ? css.getToken(moduleName) : css.getToken();
      }
      return css.token || '';
    } catch (_) { return ''; }
  }

  function deepScan(obj, out = {}, depth = 0, seen = new WeakSet()) {
    try {
      if (!obj || typeof obj !== 'object' || depth > 6) return out;
      if (seen.has(obj)) return out;
      seen.add(obj);
      const pick = (key, val) => {
        if (val === undefined || val === null || val === '') return;
        const k = String(key || '').toLowerCase();
        const v = typeof val === 'string' ? val.trim() : val;
        if (!v) return;
        if (!out.token && k === 'token') out.token = v;
        if (!out.orgoid && k === 'orgoid') out.orgoid = v;
        if (!out.userId && /^(userid|kullanicikodu|atamayapankullaniciuserid|islemyapanuserid)$/i.test(String(key))) out.userId = v;
        if (!out.moduleName && /^(moduladi|modulename|module|modul)$/i.test(String(key))) out.moduleName = v;
      };
      if (Array.isArray(obj)) {
        obj.forEach(v => deepScan(v, out, depth + 1, seen));
        return out;
      }
      for (const [k, v] of Object.entries(obj)) {
        pick(k, v);
        if (typeof v === 'string') {
          const j = parseMaybeJson(v);
          if (j) deepScan(j, out, depth + 1, seen);
        } else if (v && typeof v === 'object') {
          deepScan(v, out, depth + 1, seen);
        }
      }
    } catch (_) {}
    return out;
  }

  function getTokenFromUrl() {
    return new URLSearchParams(location.search).get('token') || '';
  }

  function learnFromObject(obj, source) {
    if (!obj || typeof obj !== 'object') return;
    const found = deepScan(obj, {});
    const maybeUser = found.userId;
    const maybeOrg = found.orgoid;
    const maybeToken = found.token;
    const moduleName = normalizeModuleName(found.moduleName || obj.moduleName || obj.modulAdi || obj.module || '');
    if (moduleName) state.discovery.lastModuleName = moduleName;
    if (maybeUser) logDiscovery('userId', maybeUser, source);
    if (maybeOrg) logDiscovery('orgoid', maybeOrg, source);
    if (maybeToken) {
      logDiscovery('token', maybeToken, source);
      if (moduleName) rememberModuleToken(moduleName, maybeToken, source);
      else if (/assos-login-response/i.test(source) && /istakip/i.test(location.href)) {
        rememberModuleToken('istakip', maybeToken, source + ':location-bound');
      }
    }
  }

  function learnFromStorageBag(source, bag) {
    if (!bag) return;
    try {
      for (let i = 0; i < bag.length; i++) {
        const k = bag.key(i);
        const v = bag.getItem(k);
        if (!v) continue;
        if (!state.discovery.token && /token/i.test(k) && String(v).length > 10) logDiscovery('token', v, `${source}:${k}`);
        if (!state.discovery.orgoid && /org.?oid/i.test(k) && String(v).trim()) logDiscovery('orgoid', v, `${source}:${k}`);
        if (!state.discovery.userId && /(user.?id|userid|kullanici)/i.test(k) && String(v).trim()) logDiscovery('userId', v, `${source}:${k}`);
        if ((v.startsWith('{') || v.startsWith('[')) && v.length < 50000) {
          try { learnFromObject(JSON.parse(v), `${source}:${k}`); } catch (_) {}
        }
      }
    } catch (_) {}
  }

  function discoverFromPage() {
    const css = window.CSSession || {};
    logBaseDiscovery('token', getTokenFromUrl(), 'url:token');
    logDiscovery('token', getTokenFromUrl(), 'url:token');
    logBaseDiscovery('token', safeGetCssToken('gp') || safeGetCssToken(), 'CSSession.getToken:base');
    logDiscovery('token', safeGetCssToken('istakip') || safeGetCssToken('gp') || safeGetCssToken(), 'CSSession.getToken');
    ['gp','g','istakip','evdo','e'].forEach(m => {
      const mt = safeGetCssToken(m);
      if (mt) rememberModuleToken(m, mt, `CSSession.getToken:${m}`);
    });
    const cssUser = safeCall(css, 'getUserId') || css.userId || css.userid || css.USERID || css.kullaniciKodu;
    const cssOrg = safeCall(css, 'getOrgOid') || css.orgOid || css.orgoid || window.orgOid || window.ORGOID;
    logBaseDiscovery('userId', cssUser, 'CSSession.getUserId:base');
    logBaseDiscovery('orgoid', cssOrg, 'CSSession.getOrgOid:base');
    logDiscovery('userId', cssUser, 'CSSession.getUserId');
    logDiscovery('orgoid', cssOrg, 'CSSession.getOrgOid');
    learnFromObject(window.userSession || window.session || window.__session || {}, 'window.session');
    learnFromStorageBag('localStorage', window.localStorage);
    learnFromStorageBag('sessionStorage', window.sessionStorage);
    maybeStopHooksAfterDiscovery('discoverFromPage');
  }

  function parseMaybeJson(str) {
    if (!str || typeof str !== 'string') return null;
    const s = str.trim();
    if (!s || (s[0] !== '{' && s[0] !== '[')) return null;
    try { return JSON.parse(s); } catch { return null; }
  }

  function inspectPayload(cmd, payload, source) {
    if (cmd) state.discovery.lastCmd = cmd;
    if (!payload || typeof payload !== 'object') return;
    learnFromObject(payload, source + (cmd ? `:${cmd}` : ''));
    if (payload.jp && typeof payload.jp === 'string') {
      const parsed = parseMaybeJson(payload.jp);
      if (parsed) learnFromObject(parsed, `${source}:jp` + (cmd ? `:${cmd}` : ''));
    }
    if (payload.sorgulamaKriterleri) learnFromObject(payload.sorgulamaKriterleri, `${source}:sorgulamaKriterleri`);
  }

  function inspectBody(body, source) {
    if (!body) return;
    try {
      if (typeof body === 'string') {
        const usp = new URLSearchParams(body);
        if ([...usp.keys()].length) {
          const cmd = usp.get('cmd') || '';
          const token = usp.get('token') || '';
          const jpText = usp.get('jp') || '';
          if (token) logDiscovery('token', token, `${source}:form-token` + (cmd ? `:${cmd}` : ''));
          if (jpText) {
            const jp = parseMaybeJson(jpText);
            if (jp) inspectPayload(cmd, jp, `${source}:form-jp`);
          }
        } else {
          const parsed = parseMaybeJson(body);
          if (parsed) inspectPayload('', parsed, `${source}:json-body`);
        }
      } else if (body instanceof URLSearchParams) {
        inspectBody(body.toString(), source);
      } else if (typeof FormData !== 'undefined' && body instanceof FormData) {
        const data = {};
        for (const [k, v] of body.entries()) data[k] = v;
        inspectPayload(data.cmd || '', data, `${source}:formdata`);
      }
    } catch (_) {}
  }

  function patchNetwork() {
    if (window.__istakipDiscoveryPatched) return;
    window.__istakipDiscoveryPatched = true;

    const origFetch = window.fetch;
    if (origFetch) {
      window.fetch = async function(...args) {
        try {
          const [input, init] = args;
          const url = typeof input === 'string' ? input : input?.url || '';
          const body = init?.body || (typeof input !== 'string' ? input?.body : undefined);
          if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch|assos-login|index\.jsp/i.test(url)) inspectBody(body, `fetch:${url}`);
        } catch (_) {}
        const res = await origFetch.apply(this, args);
        try {
          const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';
          if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch/i.test(url)) {
            const clone = res.clone();
            clone.text().then(txt => {
              const parsed = parseMaybeJson(txt);
              if (parsed) learnFromObject(parsed?.data || parsed, `fetch-response:${url}`);
            }).catch(() => {});
          }
        } catch (_) {}
        return res;
      };
    }

    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__it_url = url;
      this.__it_method = method;
      return origOpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(body) {
      try {
        if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch|assos-login|index\.jsp/i.test(this.__it_url || '')) inspectBody(body, `xhr:${this.__it_url}`);
        this.addEventListener('load', () => {
          try {
            if (!state.discovery?.hookStopped && !window.__istakipDiscoveryStopped && /dispatch/i.test(this.__it_url || '')) {
              const parsed = parseMaybeJson(this.responseText);
              if (parsed) learnFromObject(parsed?.data || parsed, `xhr-response:${this.__it_url}`);
            }
          } catch (_) {}
        });
      } catch (_) {}
      return origSend.call(this, body);
    };
  }

  function getDiscovered(moduleName = 'istakip') {
    discoverFromPage();
    const m = normalizeModuleName(moduleName || 'istakip') || 'istakip';
    return {
      token: resolveTokenForModule(m),
      userId: state.discovery.baseUserId || state.discovery.userId || '',
      orgoid: state.discovery.baseOrgoid || state.discovery.orgoid || '',
      tokensByModule: Object.assign({}, state.discovery.tokensByModule),
      moduleName: m
    };
  }

  function makeCallId() {
    return `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
  }

  async function post(cmd, jp) {
    const p = new URLSearchParams();
    p.append('cmd', cmd);
    p.append('callid', makeCallId());
    const discovered = getDiscovered('istakip');
    const token = discovered.token;
    if (!token) {
      throw new Error(`İş Takip tokenı bulunamadı. pendingModule=${state.discovery.pendingModule || '-'} baseToken=${state.discovery.baseToken ? 'var' : 'yok'} istakipToken=${state.discovery.tokensByModule?.istakip ? 'var' : 'yok'}`);
    }
    p.append('token', token);
    state.discovery.lastUsedToken = token;
    state.discovery.lastUsedTokenSource = state.discovery.tokenSourceByModule?.istakip || 'resolveTokenForModule(istakip)';
    const jpText = JSON.stringify(jp || {});
    state.discovery.history.push(`[${new Date().toLocaleTimeString()}] outbound:${cmd} jp=${jpText}`);
    if (state.discovery.history.length > 80) state.discovery.history.shift();
    persistDiscovery();
    renderDiscovery();
    p.append('jp', jpText);

    const res = await fetch(CFG.DISPATCH_URL, {
      method: 'POST',
      body: p,
      credentials: 'include'
    });
    if (!res.ok) throw new Error(`Ağ hatası ${res.status} (${cmd})`);
    const txt = await res.text();
    try { return JSON.parse(txt); } catch { return txt; }
  }

  function exposeIstakipDiscoveryBridge() {
    try {
      window.__istakipBotGetDiscovered = (moduleName = 'istakip') => {
        try { return getDiscovered(moduleName || 'istakip'); } catch (_) { return {}; }
      };
      window.__istakipBotResolveToken = (moduleName = 'istakip') => {
        try { return resolveTokenForModule(moduleName || 'istakip') || ''; } catch (_) { return ''; }
      };
      window.__istakipBotDiscoverFromPage = () => {
        try {
          discoverFromPage();
          persistDiscovery();
          renderDiscovery();
          return getDiscovered('istakip');
        } catch (_) { return {}; }
      };
      window.__istakipBotPostIstakip = async (cmd, jp) => {
        return await post(cmd, jp);
      };
    } catch (_) {}
  }
  exposeIstakipDiscoveryBridge();

  function injectStyle() {
    if (document.getElementById(CFG.STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = CFG.STYLE_ID;
    s.textContent = `
      #${CFG.PANEL_ID}{position:fixed;top:118px;right:16px;left:auto;width:min(980px, calc(100vw - 32px));height:min(660px, calc(100vh - 140px));max-width:calc(100vw - 32px);max-height:calc(100vh - 140px);min-width:540px;min-height:320px;overflow:hidden;resize:none;z-index:2147483647;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.38);font:12px/1.35 'Segoe UI',Arial,sans-serif;display:flex;flex-direction:column}
      #${CFG.PANEL_ID} *{box-sizing:border-box}
      #${CFG.PANEL_ID}.collapsed{width:300px!important;height:38px!important;min-height:38px!important;max-height:38px!important;overflow:hidden!important}
      #${CFG.PANEL_ID}.collapsed .body{display:none!important}
      #${CFG.PANEL_ID} .hdr{display:flex;justify-content:space-between;align-items:center;padding:4px 8px;background:#0d1b31;border-bottom:1px solid #22324f;border-radius:14px 14px 0 0;cursor:move;user-select:none;touch-action:none;height:44px;flex:0 0 44px;box-sizing:border-box}
      #${CFG.PANEL_ID} .body{padding:10px;flex:1 1 auto;min-height:0;max-height:none;overflow:auto;background:#08111f}
      #${CFG.PANEL_ID} .row{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .row3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .row4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} label{display:block;font-size:11px;color:#9fb4d2;margin-bottom:2px}
      #${CFG.PANEL_ID} input,#${CFG.PANEL_ID} select{width:100%;padding:5px 7px;border-radius:7px;border:1px solid #314867;background:#081523;color:#eaf2ff}
      #${CFG.PANEL_ID} input[readonly]{background:#0d1524;color:#b9cae8}
      #${CFG.PANEL_ID} button{padding:9px 10px;border-radius:7px;border:0;cursor:pointer;font-weight:600}
      #${CFG.PANEL_ID} .btn-green{background:#39d98a;color:#032611}
      #${CFG.PANEL_ID} .btn-blue{background:#3478f6;color:#fff}
      #${CFG.PANEL_ID} .btn-violet{background:#8b5cf6;color:#fff}
      #${CFG.PANEL_ID} .btn-red{background:#dc4c4c;color:#fff}
      #${CFG.PANEL_ID} .btn-amber{background:#f59e0b;color:#111}
      #${CFG.PANEL_ID} .mini{width:28px;height:28px;padding:0;background:#132643;color:#fff;border:1px solid #38527a}
      #${CFG.PANEL_ID} .sub{font-size:11px;color:#95a8c4;margin:6px 0 10px}
      #${CFG.PANEL_ID} .log{height:82px;min-height:82px;max-height:82px;overflow:auto;background:#02060d;color:#9cff9c;font-family:ui-monospace,monospace;border:1px solid #1f2d42;padding:6px;border-radius:10px;resize:vertical}
      #${CFG.PANEL_ID} .disc{background:#091525;border:1px solid #233752;border-radius:10px;padding:8px;margin-bottom:8px}
      #${CFG.PANEL_ID} .kv{display:grid;grid-template-columns:110px 1fr;gap:6px;margin-bottom:4px}
      #${CFG.PANEL_ID} .muted{color:#8ca0bf}
      #${CFG.PANEL_ID} table{width:100%;border-collapse:collapse;margin-top:8px;font-size:11px}
      #${CFG.PANEL_ID} th,#${CFG.PANEL_ID} td{border-bottom:1px solid #1f2d42;padding:6px 4px;vertical-align:top;text-align:left}
      #${CFG.PANEL_ID} .eligible{color:#88ffb2;font-weight:700}
      #${CFG.PANEL_ID} .bad{color:#ff8f8f}
      #${CFG.PANEL_ID} .tblwrap{max-height:420px;overflow:auto;border:1px solid #1f2d42;border-radius:10px}
      #${CFG.PANEL_ID} .tiny{font-size:10px;color:#99a7c0}

      #${CFG.PANEL_ID} .yk-line{display:block;line-height:1.25;margin:1px 0;white-space:normal}
      #${CFG.PANEL_ID} .yk-kod .preview-link{font-family:monospace;font-size:11px}
      #${CFG.PANEL_ID} .yk-muted{color:#8b98b7}

      #${CFG.PANEL_ID} .it-module-tabs{display:flex;gap:6px;margin:0 0 8px 0;padding:6px;border:1px solid #273048;border-radius:8px;background:#071225}
      #${CFG.PANEL_ID} .it-module-tab{flex:1;padding:8px 10px;border:1px solid #33415f;border-radius:7px;background:#0b1729;color:#cbd7eb;font-weight:700;cursor:pointer}
      #${CFG.PANEL_ID} .it-module-tab.active{background:#2563eb;color:#fff;border-color:#60a5fa}

      #${CFG.PANEL_ID} .it-main-advanced{display:none !important}
      #${CFG.PANEL_ID} .it-resize-left{position:absolute;left:-5px;top:44px;bottom:12px;width:10px;cursor:ew-resize;z-index:25}
      #${CFG.PANEL_ID} .it-resize-bottom{position:absolute;left:12px;right:12px;bottom:-5px;height:10px;cursor:ns-resize;z-index:25}
      #${CFG.PANEL_ID} .it-resize-bottom-left{position:absolute;left:-7px;bottom:-7px;width:18px;height:18px;cursor:nesw-resize;z-index:30;border-left:2px solid rgba(96,165,250,.65);border-bottom:2px solid rgba(96,165,250,.65);border-bottom-left-radius:10px;background:rgba(37,99,235,.10)}
      #${CFG.PANEL_ID} .it-resize-left:hover,#${CFG.PANEL_ID} .it-resize-bottom:hover,#${CFG.PANEL_ID} .it-resize-bottom-left:hover{background:rgba(96,165,250,.18)}
      #${CFG.PANEL_ID} .hdr,#${CFG.PANEL_ID} label,#${CFG.PANEL_ID} button{user-select:none}
      #eys-tabbed-bot-panel.it-embedded-eys{position:relative!important;top:auto!important;right:auto!important;left:auto!important;bottom:auto!important;width:100%!important;max-width:none!important;z-index:auto!important;box-shadow:none!important;margin:0!important;border-radius:8px!important}
      #eys-tabbed-bot-panel.it-embedded-eys>.h{display:none!important}


      #${CFG.PANEL_ID} .hide-above-buttons{display:none !important}
      #${CFG.PANEL_ID} .vkn-range-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0 8px 0}
      #${CFG.PANEL_ID} .vkn-range-row input{height:28px;min-height:28px;padding:4px 8px}
#${CFG.PANEL_ID} .disc{display:block !important}
      #${CFG.PANEL_ID} .tokcard{display:block !important}
      #${CFG.PANEL_ID} .tiny{font-size:10px;color:#99a7c0}
      #${CFG.PANEL_ID} .hide-above-buttons{display:none !important}
      #${CFG.PANEL_ID} .vkn-range-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:6px 0 8px 0}
      #${CFG.PANEL_ID} .vkn-range-row input{height:28px;min-height:28px;padding:4px 8px}
      #${CFG.PANEL_ID} .disc{max-height:none !important;overflow:visible !important;background:#091525}
      #${CFG.PANEL_ID} .disc > .row3,
      #${CFG.PANEL_ID} .disc > .row,
      #${CFG.PANEL_ID} .disc > .tokcard,
      #${CFG.PANEL_ID} .disc > .tokgrid,
      #${CFG.PANEL_ID} .disc > .sub,
      #${CFG.PANEL_ID} .disc > .tiny{display:none !important}
      #${CFG.PANEL_ID} .disc .vkn-range-row{display:grid !important}
      #${CFG.PANEL_ID} .it-module-tabs{flex:0 0 auto}

      #${CFG.PANEL_ID} .tblwrap thead th{position:sticky;top:0;z-index:5;background:#0d1b31}
      #${CFG.PANEL_ID} .disc{padding:4px;margin-bottom:6px;max-height:120px;overflow:auto}
      #${CFG.PANEL_ID} .tokcard{margin:4px 0 !important;padding:4px !important;max-height:90px;overflow:auto}
      #${CFG.PANEL_ID} .sub{margin:4px 0 6px 0;font-size:11px}
      #${CFG.PANEL_ID} .disc{max-height:none !important;overflow:visible !important;background:#091525 !important}
      #${CFG.PANEL_ID} .disc > .row3,
      #${CFG.PANEL_ID} .disc > .row,
      #${CFG.PANEL_ID} .disc > .tokcard,
      #${CFG.PANEL_ID} .disc > .tokgrid,
      #${CFG.PANEL_ID} .disc > .sub,
      #${CFG.PANEL_ID} .disc > .tiny{display:none !important}

      #it_preview_modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.58);z-index:2147483647;padding:20px}
      #it_preview_modal.open{display:flex}
      #it_preview_box{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:min(1280px,96vw);height:min(900px,92vh);min-width:520px;min-height:320px;background:#fff;border-radius:12px;overflow:hidden;resize:both;box-shadow:0 20px 50px rgba(0,0,0,.45);display:flex;flex-direction:column;border:1px solid #cfd8e3}
      #it_preview_head{height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;background:#0d1b31;color:#fff;border-bottom:1px solid #22324f;flex:0 0 auto;cursor:move;user-select:none}
      #it_preview_title{font:600 14px/1.2 'Segoe UI',Arial,sans-serif;padding-right:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #it_preview_actions{display:flex;gap:8px;align-items:center}
      #it_preview_actions .it-btn-mini{padding:7px 10px;border-radius:7px;border:1px solid #38527a;background:#132643;color:#fff;cursor:pointer;font:600 12px/1 'Segoe UI',Arial,sans-serif}
      #it_preview_frame{width:100%;height:100%;border:0;display:block;background:#eef3f8;flex:1 1 auto}
      #it_preview_msg{padding:16px;font:13px/1.5 'Segoe UI',Arial,sans-serif;color:#17212f;background:#fff;border-top:1px solid #e5ebf3;flex:0 0 auto}
    `;
    document.head.appendChild(s);
  }

  function createPanel() {
    const existing = document.getElementById(CFG.PANEL_ID);
    if (existing) return existing;
    const el = document.createElement('div');
    el.id = CFG.PANEL_ID;
    el.innerHTML = `
      <div class="it-resize-left" title="Sola doğru genişlet/daralt"></div>
      <div class="it-resize-bottom" title="Aşağı doğru büyüt/küçült"></div>
      <div class="it-resize-bottom-left" title="Sol alt köşeden büyüt/küçült"></div>
      <div class="hdr">
        <strong class="drag-title">İş Takip + EYS Botu v4.31.54</strong>
        <div>
          <button class="mini" id="it_toggle" title="Gövdeyi aç/kapat">−</button>
          <button class="mini" id="it_panel_reset" title="Boyut ve konumu sıfırla">□</button>
          <button class="mini" id="it_close" style="color:#ff8f8f" title="Kapat">×</button>
        </div>
      </div>
      <div class="body" id="it_wrap">
        <div class="disc">
          <div class="vkn-range-row">
          <div><label>VKN Başlangıç</label><input id="it_vkn_start" placeholder="örn 0000000000"></div>
          <div><label>VKN Bitiş</label><input id="it_vkn_end" placeholder="örn 3000000000"></div>
        </div>
        <div class="row3" style="margin-bottom:6px">
            <div><label>Keşfedilen Kullanıcı</label><input id="it_user" readonly></div>
            <div><label>Keşfedilen OrgOid</label><input id="it_orgoid" readonly></div>
            <div><label>Keşfedilen Token</label><input id="it_token" readonly></div>
          </div>
          <div class="row3" style="margin-bottom:0">
            <div class="tiny" id="it_user_src"></div>
            <div class="tiny" id="it_org_src"></div>
            <div class="tiny" id="it_tok_src"></div>
          </div>
          <div class="tokcard" style="margin:8px 0">
            <div class="tokname">İlk Giriş Oturumu</div>
            <div class="tokval" id="it_base_tok">-</div>
            <div class="toksrc" id="it_base_tok_src">Token kaynağı: -</div>
            <div class="tokval" id="it_base_user">-</div>
            <div class="toksrc" id="it_base_user_src">Kullanıcı kaynağı: -</div>
            <div class="tokval" id="it_base_org">-</div>
            <div class="toksrc" id="it_base_org_src">OrgID kaynağı: -</div>
          </div>
          <div class="sub" id="it_used_tok">Kullanılan İş Takip tokenı: -</div>
          <div class="sub" id="it_used_tok_src">Kullanılan token kaynağı: -</div>
          <div class="row" style="margin-top:6px;margin-bottom:0">
            <button class="btn-violet" id="it_discover">XHR KEŞFİNİ YENİLE</button>
            <div class="tiny" id="it_last_cmd"></div>
          </div>
          <div class="tokgrid">
            <div class="tokcard"><div class="tokname">İş Takip (istakip)</div><div class="tokval" id="it_tok_istakip">-</div><div class="toksrc" id="it_toksrc_istakip">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">EVDB (evdo)</div><div class="tokval" id="it_tok_evdo">-</div><div class="toksrc" id="it_toksrc_evdo">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">EYS (e)</div><div class="tokval" id="it_tok_e">-</div><div class="toksrc" id="it_toksrc_e">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">GİB İntranet (g)</div><div class="tokval" id="it_tok_g">-</div><div class="toksrc" id="it_toksrc_g">Kaynak: -</div></div>
            <div class="tokcard"><div class="tokname">Portal (gp)</div><div class="tokval" id="it_tok_gp">-</div><div class="toksrc" id="it_toksrc_gp">Kaynak: -</div></div>
          </div>
          <div class="tiny" style="margin-top:6px">Eklenti açılır açılmaz sayfa bağlamında XHR/fetch dinlenir. İlk tıkladığın işte giden sorgulardan orgoid, userId, akisOid ve cmd yakalanır.</div>
        </div>
        <div class="row4 hide-above-buttons">
          <div><label>Vergi No / TCKN / Ünvan</label><input id="it_filter" placeholder="Boş = hepsi"></div>
          <div><label>İş Takip No</label><input id="it_istakip" placeholder="İsteğe bağlı"></div>
          <div><label>İş Tipi</label><input id="it_istipi" value="5"></div>
          <div><label>Sonuç limiti</label><input id="it_limit" value="50"></div>
        </div>
        <div class="row4 it-main-advanced">
          <div><label>Uygun değil işleri sil</label><select id="it_atama_sil"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div>
          <div><label>hedefDurumNo</label><input id="it_hedef_durum" value="4"></div>
          <div><label>akisDurumTip</label><input id="it_durum_tip" value="21"></div>
          <div><label>islemSahibi</label><input id="it_islem_sahibi" value="3"></div>
        </div>
        <div class="row3 it-main-advanced">
          <div><label>isiUzerimeAl</label><select id="it_uzerime_al"><option value="1" selected>Evet</option><option value="0">Hayır</option></select></div>
          <div><label>Manuel OrgOid (boş kalırsa keşfedilen)</label><input id="it_orgoid_override" placeholder="İsteğe bağlı"></div>
          <div><label>Manuel UserId (boş kalırsa keşfedilen)</label><input id="it_user_override" placeholder="İsteğe bağlı"></div>
        </div>
        <div class="row3">
          <button class="btn-green" id="it_scan">İŞLERİ TARA</button>
          <button class="btn-blue" id="it_send">UYGUNLARI GÖNDER</button>
          <button class="btn-amber" id="it_refresh">LİSTEYİ YENİLE</button>
        </div>
        <button class="btn-red" id="it_stop" style="display:none;width:100%;margin-bottom:8px">DURDUR</button>
        <div class="sub">Akış: auto-discovery ile token / userId / orgoid bul → işleri çek → sonraki adımları kontrol et → uygun olanları <b>akisIslemleri_akisYeniAdimKaydet</b> ile gönder.</div>
        <div class="log" id="it_log"></div>
        <div class="tblwrap">
          <table>
            <thead><tr><th>#</th><th>İşlem</th><th>İşTakip</th><th>Belge Bilgi</th><th>İşin Türü</th><th>Ünvan</th><th>Durum</th><th>Önizle</th><th>Yoklama Durum</th><th>Yoklama Kodu</th></tr></thead>
            <tbody id="it_rows"></tbody>
          </table>
        </div>
      </div>`;
    (document.body || document.documentElement).appendChild(el);
    return el;
  }

  function renderDiscovery() {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    const shortTok = v => v ? `${String(v).slice(0, 22)}...` : '-';
    const setVal = (sel, val) => { const el = $(sel, panel); if (el) el.value = val; };
    const setTxt = (sel, val) => { const el = $(sel, panel); if (el) el.textContent = val; };

    const shownUser = state.discovery.baseUserId || state.discovery.userId || '';
    const shownOrg = state.discovery.baseOrgoid || state.discovery.orgoid || '';
    const ist = state.discovery.tokensByModule?.istakip || state.discovery.token || '';

    setVal('#it_user', shownUser);
    setVal('#it_orgoid', shownOrg);
    setVal('#it_token', ist ? `${ist.slice(0, 18)}...` : '');

    setTxt('#it_user_src', state.discovery.baseSource?.userId ? `Kaynak: ${state.discovery.baseSource.userId} (ilk giriş)` : (state.discovery.source.userId ? `Kaynak: ${state.discovery.source.userId}` : 'Kaynak: -'));
    setTxt('#it_org_src', state.discovery.baseSource?.orgoid ? `Kaynak: ${state.discovery.baseSource.orgoid} (ilk giriş)` : (state.discovery.source.orgoid ? `Kaynak: ${state.discovery.source.orgoid}` : 'Kaynak: -'));
    setTxt('#it_tok_src', state.discovery.tokenSourceByModule?.istakip ? `İş Takip token kaynağı: ${state.discovery.tokenSourceByModule.istakip}` : (state.discovery.source.token ? `Genel token kaynağı: ${state.discovery.source.token}` : 'Kaynak: -'));

    setTxt('#it_base_tok', state.discovery.baseToken ? `${String(state.discovery.baseToken).slice(0,22)}...` : '-');
    setTxt('#it_base_tok_src', state.discovery.baseSource?.token ? `Token kaynağı: ${state.discovery.baseSource.token}` : 'Token kaynağı: -');
    setTxt('#it_base_user', state.discovery.baseUserId || '-');
    setTxt('#it_base_user_src', state.discovery.baseSource?.userId ? `Kullanıcı kaynağı: ${state.discovery.baseSource.userId}` : 'Kullanıcı kaynağı: -');
    setTxt('#it_base_org', state.discovery.baseOrgoid || '-');
    setTxt('#it_base_org_src', state.discovery.baseSource?.orgoid ? `OrgID kaynağı: ${state.discovery.baseSource.orgoid}` : 'OrgID kaynağı: -');

    setTxt('#it_used_tok', state.discovery.lastUsedToken ? `Kullanılan İş Takip tokenı: ${String(state.discovery.lastUsedToken).slice(0,22)}...` : 'Kullanılan İş Takip tokenı: -');
    setTxt('#it_used_tok_src', state.discovery.lastUsedTokenSource ? `Kullanılan token kaynağı: ${state.discovery.lastUsedTokenSource}` : 'Kullanılan token kaynağı: -');

    const modText = ['gp','g','istakip','evdo','e'].map(m => `${m}:${state.discovery.tokensByModule?.[m] ? 'var' : '-'}`).join(' | ');
    setTxt('#it_last_cmd', `${state.discovery.lastCmd ? `Son cmd: ${state.discovery.lastCmd}` : 'Son cmd: -'} | Son modül: ${state.discovery.lastModuleName || '-'} | ${modText}`);

    const fill = (m, id1, id2) => {
      const val = state.discovery.tokensByModule?.[m] || '';
      const src = state.discovery.tokenSourceByModule?.[m] || '';
      setTxt(id1, shortTok(val));
      setTxt(id2, src ? `Kaynak: ${src}` : 'Kaynak: -');
    };
    fill('istakip', '#it_tok_istakip', '#it_toksrc_istakip');
    fill('evdo', '#it_tok_evdo', '#it_toksrc_evdo');
    fill('e', '#it_tok_e', '#it_toksrc_e');
    fill('g', '#it_tok_g', '#it_toksrc_g');
    fill('gp', '#it_tok_gp', '#it_toksrc_gp');
  }

  function logger(panel) {
    const box = $('#it_log', panel);
    return (msg, err = false) => {
      const line = `[${new Date().toLocaleTimeString()}] ${err ? 'HATA: ' : ''}${msg}`;
      console.log('[ISTAKIP-BOT-V4]', line);
      box.innerHTML += `<div style="overflow-wrap:anywhere;word-break:break-word">${err ? '<span class="bad">HATA:</span> ' : ''}${msg}</div>`;
      box.scrollTop = box.scrollHeight;
    };
  }


function readUrlToken() {
  try { return new URL(location.href).searchParams.get('token') || ''; }
  catch (_) { return ''; }
}

function resolveKeysToken() {
  const preferred = ['gp', 'g'];
  for (const m of preferred) {
    const t = resolveTokenForModule(m);
    if (t) return t;
  }
  if (state.discovery.baseToken && state.discovery.baseToken !== state.discovery.token) {
    return state.discovery.baseToken;
  }
  const mods = ['gp', 'g', 'evdo', 'e', 'istakip'];
  for (const m of mods) {
    const t = resolveTokenForModule(m);
    if (t) return t;
  }
  return state.discovery.baseToken || '';
}

function collectMessageText(resp) {
  try {
    const msgs = Array.isArray(resp?.messages) ? resp.messages : [];
    return msgs.map(m => String(m?.text || '').trim()).filter(Boolean).join(' | ');
  } catch (_) {
    return '';
  }
}

function findDeepValue(obj, keys, depth = 0, seen = new WeakSet()) {
  try {
    if (!obj || typeof obj !== 'object' || depth > 6) return '';
    if (seen.has(obj)) return '';
    seen.add(obj);
    for (const k of keys) {
      if (obj[k] != null && obj[k] !== '') return obj[k];
    }
    for (const v of Object.values(obj)) {
      if (v && typeof v === 'object') {
        const found = findDeepValue(v, keys, depth + 1, seen);
        if (found != null && found !== '') return found;
      }
    }
  } catch (_) {}
  return '';
}

async function fetchKeysPreviewInfo(keysEvrakOid) {
  const token = resolveKeysToken();
  if (!token) throw new Error('KEYS token bulunamadı');
  const p = new URLSearchParams();
  p.append('cmd', 'evrakOrtakServis_evrakOnizle');
  p.append('callid', makeCallId());
  p.append('token', token);
  p.append('jp', JSON.stringify({
    evrakOid: String(keysEvrakOid || '').trim(),
    konteynerOid: null,
    evrakVersiyonOid: null,
    yetkisiz: true,
    barkod: true
  }));

  const res = await fetch(CFG.KEYS_DISPATCH_URL, {
    method: 'POST',
    body: p,
    credentials: 'include'
  });
  if (!res.ok) throw new Error(`Önizleme sorgusu ağ hatası: ${res.status}`);
  const txt = await res.text();
  let json = null;
  try { json = JSON.parse(txt); } catch (_) {
    throw new Error('Önizleme cevabı JSON değil');
  }
  if (String(json?.error || '') === '1') {
    throw new Error(collectMessageText(json) || 'Evrak önizleme hatası');
  }

  const data = json?.data || json || {};
  const directUrl = findDeepValue(data, ['previewUrl', 'pdfUrl', 'url', 'link']);
  if (directUrl) {
    return { token, url: directUrl, response: json };
  }

  const uuid = findDeepValue(data, ['uuid', 'fileID', 'fileId']);
  const dosyaId = findDeepValue(data, ['dosyaId', 'dosyaID', 'fn', 'fileName']);
  if (!uuid) throw new Error('Önizleme linki için fileID bulunamadı');

  const cleanedFileId = String(uuid || '').trim();
  const fileIdForUrl = cleanedFileId.endsWith('.pdf') ? cleanedFileId : `${cleanedFileId}.pdf`;
  const url = `${CFG.FLEXPAPER_URL}?token=${encodeURIComponent(token)}&fileID=${fileIdForUrl}#navpanes=0`;
  return { token, url, response: json, fileID: cleanedFileId, dosyaId };
}

function ensurePreviewModal() {
  let modal = document.getElementById('it_preview_modal');
  if (modal) return modal;
  modal = document.createElement('div');
  modal.id = 'it_preview_modal';
  modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.58);z-index:2147483647;padding:20px;';
  modal.innerHTML = `
    <div id="it_preview_box">
      <div id="it_preview_head">
        <div id="it_preview_title">Evrak Önizleme</div>
        <div id="it_preview_actions">
          <button type="button" class="it-btn-mini" id="it_preview_min">_</button>
          <button type="button" class="it-btn-mini" id="it_preview_reset">□</button>
          <button type="button" class="it-btn-mini" id="it_preview_reload">Yenile</button>
          <button type="button" class="it-btn-mini" id="it_preview_close">Kapat</button>
        </div>
      </div>
      <iframe id="it_preview_frame" referrerpolicy="no-referrer"></iframe>
      <div id="it_preview_msg" style="display:none"></div>
    </div>`;
  (document.body || document.documentElement).appendChild(modal);
  modal.addEventListener('click', ev => {
    if (ev.target === modal) { modal.classList.remove('open'); modal.style.display = 'none'; }
  });
  modal.querySelector('#it_preview_close').onclick = () => { modal.classList.remove('open'); modal.style.display = 'none'; };
  modal.querySelector('#it_preview_min').onclick = () => {
    const frame = modal.querySelector('#it_preview_frame');
    const msg = modal.querySelector('#it_preview_msg');
    const box = modal.querySelector('#it_preview_box');
    const hidden = frame.style.display === 'none' && msg.style.display === 'none';
    if (hidden) {
      frame.style.display = '';
      box.style.height = box.dataset.prevHeight || 'min(900px,92vh)';
      box.style.width = box.dataset.prevWidth || 'min(1280px,96vw)';
    } else {
      box.dataset.prevHeight = box.style.height || '';
      box.dataset.prevWidth = box.style.width || '';
      frame.style.display = 'none';
      msg.style.display = 'none';
      box.style.height = '48px';
      box.style.width = '520px';
    }
  };
  modal.querySelector('#it_preview_reset').onclick = () => {
    resetPreviewBoxSize();
  };
  modal.querySelector('#it_preview_reload').onclick = () => {
    const frame = modal.querySelector('#it_preview_frame');
    const src = frame.getAttribute('src');
    if (src) frame.setAttribute('src', src);
  };
  requestAnimationFrame(() => {
    const box = modal.querySelector('#it_preview_box');
    const head = modal.querySelector('#it_preview_head');
    enableDrag(box, head, { clearTransform: true });
  });
  return modal;
}

function showPreviewModal(url, titleText) {
  const modal = ensurePreviewModal();
  const frame = modal.querySelector('#it_preview_frame');
  const msg = modal.querySelector('#it_preview_msg');
  const title = modal.querySelector('#it_preview_title');
  title.textContent = titleText || 'Evrak Önizleme';
  msg.style.display = 'none';
  msg.textContent = '';
  frame.style.display = '';
  frame.src = url;
  modal.classList.add('open');
  modal.style.display = 'flex';
  const box = modal.querySelector('#it_preview_box');
  if (box && box.style.height === '48px') { resetPreviewBoxSize(); }

  let loaded = false;
  const timer = setTimeout(() => {
    if (loaded) return;
    msg.style.display = '';
    msg.innerHTML = 'Önizleme iframe içinde açılamadıysa sunucu buna izin vermiyor olabilir.<br><br>Bağlantıyı kopyalayıp adres çubuğunda açmayı deneyebilirsin.';
  }, 4000);

  frame.onload = () => {
    loaded = true;
    clearTimeout(timer);
  };
}


function enableDrag(el, handle, opts = {}) {
  if (!el || !handle) return;
  if (handle.__dragBound) return;
  handle.__dragBound = true;

  let dragging = false;
  let startX = 0, startY = 0, startLeft = 0, startTop = 0;

  const onMove = (ev) => {
    if (!dragging) return;
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;
    const rect = el.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - Math.min(rect.width, window.innerWidth));
    const maxTop = Math.max(0, window.innerHeight - 44);
    el.style.left = `${Math.max(0, Math.min(maxLeft, startLeft + dx))}px`;
    el.style.top = `${Math.max(0, Math.min(maxTop, startTop + dy))}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    if (opts.clearTransform) el.style.transform = 'none';
  };

  const onUp = () => {
    dragging = false;
    document.body.style.userSelect = '';
    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('mouseup', onUp, true);
  };

  handle.addEventListener('mousedown', (ev) => {
    if (ev.button !== 0) return;
    if (ev.target && ev.target.closest('button,a,input,select,textarea,iframe')) return;
    const rect = el.getBoundingClientRect();
    dragging = true;
    startX = ev.clientX;
    startY = ev.clientY;
    startLeft = rect.left;
    startTop = rect.top;
    el.style.left = `${rect.left}px`;
    el.style.top = `${rect.top}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
    if (opts.clearTransform) el.style.transform = 'none';
    document.body.style.userSelect = 'none';
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('mouseup', onUp, true);
    ev.preventDefault();
    ev.stopPropagation();
  }, true);
}


function enablePanelResizeHandles(panel) {
  if (!panel || panel.__itResizeHandlesBound) return;
  panel.__itResizeHandlesBound = true;

  const minW = 540;
  const minH = 220;
  const margin = 8;

  const bind = (sel, mode) => {
    const h = panel.querySelector(sel);
    if (!h) return;
    h.addEventListener('mousedown', (ev) => {
      if (ev.button !== 0) return;
      const r = panel.getBoundingClientRect();
      const startX = ev.clientX;
      const startY = ev.clientY;
      const startLeft = r.left;
      const startTop = r.top;
      const startRight = r.right;
      const startW = r.width;
      const startH = r.height;
      panel.style.left = `${r.left}px`;
      panel.style.top = `${r.top}px`;
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
      panel.style.width = `${r.width}px`;
      panel.style.height = `${r.height}px`;
      panel.style.transform = 'none';
      document.body.style.userSelect = 'none';

      const onMove = (e) => {
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        if (mode.includes('left')) {
          const maxW = Math.max(minW, Math.min(window.innerWidth - margin, startRight - margin));
          let newW = Math.max(minW, Math.min(maxW, startW - dx));
          let newLeft = startRight - newW;
          if (newLeft < margin) {
            newLeft = margin;
            newW = startRight - margin;
          }
          panel.style.left = `${Math.max(margin, newLeft)}px`;
          panel.style.width = `${Math.max(minW, newW)}px`;
        }

        if (mode.includes('bottom')) {
          const maxH = Math.max(minH, window.innerHeight - startTop - margin);
          const newH = Math.max(minH, Math.min(maxH, startH + dy));
          panel.style.height = `${newH}px`;
          panel.style.maxHeight = `${Math.max(minH, window.innerHeight - startTop - margin)}px`;
        }

        e.preventDefault();
        e.stopPropagation();
      };

      const onUp = () => {
        document.body.style.userSelect = '';
        document.removeEventListener('mousemove', onMove, true);
        document.removeEventListener('mouseup', onUp, true);
        fitPanelToViewport(panel);
      };

      document.addEventListener('mousemove', onMove, true);
      document.addEventListener('mouseup', onUp, true);
      ev.preventDefault();
      ev.stopPropagation();
    }, true);
  };

  bind('.it-resize-left', 'left');
  bind('.it-resize-bottom', 'bottom');
  bind('.it-resize-bottom-left', 'left-bottom');
}

function bindMainPanelMoveAndResize(panel) {
  try {
    if (!panel) return;
    const header = panel.querySelector('.hdr');
    enableDrag(panel, header, { clearTransform: true });
    enablePanelResizeHandles(panel);
    panel.style.resize = 'none';
    fitPanelToViewport(panel);
  } catch (_) {}
}



function onlyDigits(v){ return String(v || '').replace(/\D+/g, ''); }

function limit10InputValue(inp){
  if (!inp) return;
  inp.value = onlyDigits(inp.value).slice(0, 10);
}

function getRowsFromTable(panel){
  try{
    const table = panel.querySelector('.tblwrap table');
    if (!table || !table.tBodies || !table.tBodies[0]) return [];
    return Array.from(table.tBodies[0].rows || []);
  }catch(e){
    return [];
  }
}

function getVknFromRow(tr){
  try{
    const isTakipCell = tr.querySelector('.it-is-takip-cell') || (tr.cells ? tr.cells[2] : null) || (tr.cells ? tr.cells[1] : null);
    if (!isTakipCell) return '';
    const raw = String(isTakipCell.innerText || isTakipCell.textContent || '');
    const nums = raw.match(/\d{10,11}/g) || [];
    const vkn = nums.find(x => String(x).length === 10);
    return vkn || '';
  }catch(e){
    return '';
  }
}

function getHeaderFilter(panel){
  const startInp = panel.querySelector('#it_header_vkn_start');
  const endInp = panel.querySelector('#it_header_vkn_end');
  return {
    start: onlyDigits(startInp?.value || '').slice(0,10),
    end: onlyDigits(endInp?.value || '').slice(0,10)
  };
}

function inVknRange(vkn, start, end){
  if (!start && !end) return true;
  if (!vkn || String(vkn).length !== 10) return false;
  if (start && start.length !== 10) start = '';
  if (end && end.length !== 10) end = '';
  if (!start && !end) return true;
  if (start && !end) return vkn >= start;
  if (!start && end) return vkn <= end;
  return vkn >= start && vkn <= end;
}

function applyHeaderVknFilter(panel){
  try{
    const { start, end } = getHeaderFilter(panel);
    const rows = getRowsFromTable(panel);
    let visible = 0;
    rows.forEach(tr => {
      const vkn = getVknFromRow(tr);
      const ok = inVknRange(vkn, start, end);
      tr.style.display = ok ? '' : 'none';
      if (ok) visible++;
    });
    const log = panel.querySelector('#it_log');
    if (log) {
      const tag = `[VKN filtre] başlangıç=${start || '-'} bitiş=${end || '-'} görünür=${visible}/${rows.length}`;
      const lines = String(log.textContent || '').split('\n').filter(Boolean).filter(x => !x.startsWith('[VKN filtre]'));
      log.textContent = [tag].concat(lines).join('\n');
    }
  }catch(e){}
}

function ensureHeaderVknFilter(panel){
  try{
    const wrap = panel.querySelector('.tblwrap');
    const table = wrap?.querySelector('table');
    const theadRow = table?.querySelector('thead tr');
    if (!wrap || !table || !theadRow) return;

    if (!panel.querySelector('#it_header_vkn_filter_box')) {
      const box = document.createElement('div');
      box.id = 'it_header_vkn_filter_box';
      box.style.cssText = 'display:none; position:absolute; z-index:20; background:#0d1b31; border:1px solid #32486f; border-radius:8px; padding:8px; box-shadow:0 10px 24px rgba(0,0,0,.35); width:260px;';
      box.innerHTML = `
        <div style="font-size:12px; margin-bottom:6px;">VKN Aralığı</div>
        <div style="display:grid; gap:6px;">
          <input id="it_header_vkn_start" placeholder="VKN Başlangıç" maxlength="10" style="height:28px; padding:4px 8px;" />
          <input id="it_header_vkn_end" placeholder="VKN Bitiş" maxlength="10" style="height:28px; padding:4px 8px;" />
          <div style="display:flex; gap:6px;">
            <button type="button" id="it_header_vkn_apply" style="flex:1;">Uygula</button>
            <button type="button" id="it_header_vkn_clear" style="flex:1;">Temizle</button>
          </div>
        </div>
      `;
      wrap.style.position = 'relative';
      wrap.appendChild(box);

      const startInp = box.querySelector('#it_header_vkn_start');
      const endInp = box.querySelector('#it_header_vkn_end');
      const applyBtn = box.querySelector('#it_header_vkn_apply');
      const clearBtn = box.querySelector('#it_header_vkn_clear');

      [startInp, endInp].forEach(inp => {
        inp.addEventListener('input', () => {
          limit10InputValue(inp);
          applyHeaderVknFilter(panel);
        });
      });
      applyBtn.addEventListener('click', () => applyHeaderVknFilter(panel));
      clearBtn.addEventListener('click', () => {
        startInp.value = '';
        endInp.value = '';
        applyHeaderVknFilter(panel);
      });

      document.addEventListener('click', (ev) => {
        const headBtn = panel.querySelector('#it_istakip_head_filter_btn');
        if (!box.contains(ev.target) && ev.target !== headBtn) box.style.display = 'none';
      }, true);
    }

    const ths = Array.from(table.querySelectorAll('thead th'));
    const isTakipTh = ths.find(th => /İşTakip/i.test((th.textContent || '').replace(/\s+/g,'')));
    if (isTakipTh && !panel.querySelector('#it_istakip_head_filter_btn')) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.id = 'it_istakip_head_filter_btn';
      btn.textContent = '↕';
      btn.title = 'VKN aralık filtresi';
      btn.style.cssText = 'margin-left:6px; width:20px; height:20px; padding:0; line-height:18px; font-size:11px;';
      isTakipTh.appendChild(btn);

      btn.addEventListener('click', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const box = panel.querySelector('#it_header_vkn_filter_box');
        const rect = btn.getBoundingClientRect();
        const wrapRect = wrap.getBoundingClientRect();
        box.style.left = '0px';
      });
    }

    const btn = panel.querySelector('#it_istakip_head_filter_btn');
    const box = panel.querySelector('#it_header_vkn_filter_box');
    if (btn && box) {
      btn.onclick = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const b = btn.getBoundingClientRect();
        const w = wrap.getBoundingClientRect();
        const left = Math.max(0, b.left - w.left);
        const top = Math.max(24, b.bottom - w.top + 4);
        box.style.left = left + 'px';
        box.style.top = top + 'px';
        box.style.display = box.style.display === 'block' ? 'none' : 'block';
      };
    }
  }catch(e){}
}

function hideUpperFilterRows(panel){
  try{
    const rows = Array.from(panel.querySelectorAll('.row4, .row3'));
    rows.forEach(row => {
      const txt = String(row.textContent || '');
      if (
        /Vergi No\s*\/\s*TCKN\s*\/\s*Ünvan/.test(txt) ||
        /Uygun değil işleri sil/.test(txt) ||
        /isiUzerimeAl/.test(txt)
      ) {
        row.style.display = 'none';
      }
    });
  }catch(e){}
}

function isValidTckn(v){
  const s = String(v || '').trim();
  return /^\d{11}$/.test(s);
}
function normalizeDiscoveredUser(v){
  const s = String(v || '').trim();
  return isValidTckn(s) ? s : '';
}

function fitPanelToViewport(panel){
  try{
    if (!panel) return;
    const margin = 16;
    const body = panel.querySelector('.body');
    if (body) {
      body.style.flex = '1 1 auto';
      body.style.minHeight = '0';
      body.style.maxHeight = 'none';
      body.style.overflowY = 'auto';
      body.style.overflowX = 'hidden';
      body.style.background = '#08111f';
    }
    if (panel.classList.contains('collapsed')) return;
    panel.style.display = 'flex';
    panel.style.flexDirection = 'column';
    panel.style.overflow = 'hidden';
    panel.style.minWidth = '540px';
    panel.style.minHeight = '320px';
    panel.style.maxWidth = `${Math.max(540, window.innerWidth - margin * 2)}px`;
    const rect0 = panel.getBoundingClientRect();
    const top = Math.max(margin, rect0.top || parseInt(panel.style.top || '118', 10) || 118);
    const maxH = Math.max(320, window.innerHeight - top - margin);
    const maxW = Math.max(540, window.innerWidth - margin * 2);
    panel.style.maxHeight = `${maxH}px`;

    const rect = panel.getBoundingClientRect();
    if (!panel.style.height || /^auto$/i.test(panel.style.height)) {
      panel.style.height = `${Math.min(660, maxH)}px`;
    } else if (rect.height < 300 || rect.height > maxH) {
      panel.style.height = `${Math.max(320, Math.min(rect.height || 660, maxH))}px`;
    }
    if (rect.width < 540) panel.style.width = '540px';
    if (rect.width > maxW) panel.style.width = `${maxW}px`;

    const rect2 = panel.getBoundingClientRect();
    if (rect2.left < margin) {
      panel.style.left = `${margin}px`;
      panel.style.right = 'auto';
    }
    if (rect2.right > window.innerWidth - margin && panel.style.left && panel.style.left !== 'auto') {
      panel.style.left = `${Math.max(margin, window.innerWidth - margin - rect2.width)}px`;
      panel.style.right = 'auto';
    }
    if (rect2.top < margin) panel.style.top = `${margin}px`;
    if (rect2.bottom > window.innerHeight - margin) {
      panel.style.top = `${Math.max(margin, window.innerHeight - margin - rect2.height)}px`;
    }
  }catch(e){}
}

function resetPreviewBoxSize() {
  const box = document.getElementById('it_preview_box');
  if (!box) return;
  box.style.width = 'min(1280px,96vw)';
  box.style.height = 'min(900px,92vh)';
  box.style.left = '50%';
  box.style.top = '50%';
  box.style.right = 'auto';
  box.style.bottom = 'auto';
  box.style.transform = 'translate(-50%,-50%)';
}





function ykDigits(v) {
  return String(v || '').replace(/\D+/g, '');
}

function ykFormatDateYYYYMMDD(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}${m}${day}`;
}

function ykDateRangeSixMonths() {
  const end = new Date();
  const start = new Date(end);
  start.setMonth(start.getMonth() - 6);
  return {
    start: ykFormatDateYYYYMMDD(start),
    end: ykFormatDateYYYYMMDD(end)
  };
}

function ykGetSessionSeed() {
  try {
    const c = window.CSSession || {};
    const vd =
      (typeof c.getVdKodu === 'function' ? c.getVdKodu() : '') ||
      c.vdKodu || c.vdkodu || c.birim || state.discovery?.baseOrgoid || state.discovery?.orgoid || '';
    const user =
      (typeof c.getUserId === 'function' ? c.getUserId() : '') ||
      c.userId || window.userId || state.discovery?.baseUserId || state.discovery?.userId || '';
    const adi =
      (typeof c.getUserName === 'function' ? c.getUserName() : '') ||
      c.adi || window.userName || '';
    const birim = String(vd || '').trim();
    return {
      user: String(user || '').trim(),
      giris: String(user || '').trim(),
      birim,
      il: birim.slice(0, 3),
      adi: String(adi || '').trim(),
      userx: String(user || '').trim()
    };
  } catch (_) {
    const birim = String(state.discovery?.baseOrgoid || state.discovery?.orgoid || '').trim();
    const user = String(state.discovery?.baseUserId || state.discovery?.userId || '').trim();
    return { user, giris: user, birim, il: birim.slice(0, 3), adi: '', userx: user };
  }
}

function ykBuildSessionData(role = '20') {
  const seed = ykGetSessionSeed();
  return {
    rol: String(role),
    user: seed.user,
    giris: seed.giris,
    birim: seed.birim,
    il: seed.il,
    adi: seed.adi,
    userx: seed.userx
  };
}

function ykResolveToken() {
  try {
    return state.discovery?.tokensByModule?.e
      || state.discovery?.tokensByModule?.g
      || state.discovery?.tokensByModule?.gp
      || state.discovery?.tokensByModule?.evdo
      || state.discovery?.tokensByModule?.istakip
      || state.discovery?.baseToken
      || state.discovery?.token
      || new URLSearchParams(location.search).get('token')
      || '';
  } catch (_) {
    return '';
  }
}

async function ykPostEys(cmd, jp) {
  const p = new URLSearchParams();
  p.append('cmd', cmd);
  p.append('callid', String(Date.now()));
  const token = ykResolveToken();
  if (token) p.append('token', token);
  p.append('jp', JSON.stringify(jp || {}));

  const res = await fetch('http://eyoklama.gelirler.gov.tr:32516/edenetis/dispatch', {
    method: 'POST',
    body: p,
    credentials: 'include'
  });

  const txt = await res.text();
  if (!res.ok) throw new Error(`E-Yoklama ağ hatası: ${res.status} ${cmd}`);
  try { return JSON.parse(txt); }
  catch (_) { throw new Error('E-Yoklama cevabı JSON değil: ' + txt.slice(0, 160)); }
}

function ykDurumText(d) {
  const n = Number(d);
  switch (n) {
    case 10: return 'Yoklama Giriş';
    case 20: return 'Müdür Onay';
    case 30: return 'Koordinatör Onay';
    case 40: return 'Ekibe Atandı';
    case 50: return 'Yoklama Memuru';
    case 60: return 'Görev Başladı';
    case 70: return 'Devam Ediyor';
    case 80: return 'Sonuç Alındı';
    case 81: return 'Sonuçlandı';
    default: return n ? `Durum ${n}` : '-';
  }
}

function ykBuildSonucUrl(ykodu) {
  const y = String(ykodu || '').trim();
  return y ? `http://eyoklama.gelirler.gov.tr:32516/edenetis/getSonuc?yKodu=${encodeURIComponent(y)}` : '';
}

function ykLooksLikeKod(value) {
  return typeof value === 'string' && /^\d{8}Y\d{6}[A-Z0-9]+$/i.test(value);
}

function ykCollectObjects(root, out = []) {
  if (Array.isArray(root)) {
    for (const item of root) ykCollectObjects(item, out);
    return out;
  }
  if (root && typeof root === 'object') {
    out.push(root);
    for (const value of Object.values(root)) ykCollectObjects(value, out);
  }
  return out;
}

function ykExtractItems(resp) {
  const rows = [];
  const seen = new Set();
  for (const obj of ykCollectObjects(resp)) {
    if (!obj || typeof obj !== 'object') continue;
    const kod = ykGetKod(obj);
    const hasUseful =
      kod ||
      obj.vkn || obj.tckn || obj.unvan || obj.adsoyadunvan ||
      obj.durum || obj.optime || obj.ilkislem || obj.sonislem;
    if (!hasUseful) continue;
    const key = kod || JSON.stringify(obj).slice(0, 120);
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push(obj);
  }
  return rows;
}

function ykGetKod(item) {
  const direct = item?.ykodu || item?.yKod || item?.ykod || item?.yKodu ||
    item?.yoklamaKodu || item?.yoklamakodu || item?.kod || item?.ykodu1 || '';
  return String(direct || '').trim();
}

function ykGetOptime(item) {
  const raw = String(
    item?.optime ||
    item?.sonislem ||
    item?.ilkislem ||
    item?.islemZamani ||
    item?.tarih ||
    item?.giris ||
    ykGetKod(item).slice(0, 8) ||
    ''
  ).replace(/\D+/g, '');
  return Number(raw || 0);
}

function ykGetLastStatus(items) {
  if (!items || !items.length) return { durum: '-', kod: '', item: null };
  const last = items.reduce((a, b) => ykGetOptime(b) > ykGetOptime(a) ? b : a, items[0]);
  return {
    durum: ykDurumText(last?.durum),
    kod: ykGetKod(last),
    item: last
  };
}

async function ykFetchYoklamalarForJob(job) {
  const vkn = String(job?.is_vergiNo || job?.vergiNo || job?.vkn || '').trim();
  const tckn = String(job?.is_tcKimlikNo || job?.tcKimlikNo || job?.tckn || '').trim();
  if (!vkn && !tckn) throw new Error('VKN/TCKN bulunamadı.');

  const range = ykDateRangeSixMonths();
  range.start = ykGetJobStartDate(job) || range.start;
  const sessionData = ykBuildSessionData('20');

  // EYS Tam Bot Full eklentisindeki doğru yapı:
  // cmd: srvcYoklama_getYoklamalar
  // jp: { data:{...}, sessionData }
  return ykPostEys('srvcYoklama_getYoklamalar', {
    data: {
      koor: '',
      vd: sessionData.birim,
      vdkodu: sessionData.birim,
      sorgukaynak: '0',
      icdis: '0',
      disil: '',
      disvd: '',
      basvkn: vkn,
      sonvkn: vkn,
      bastckn: tckn,
      sontckn: tckn,
      yabanci: 0,
      vkn,
      tckn,
      yturu: [],
      ydurum: '',
      sonucislem: '1',
      servis: '',
      bastar: range.start,
      bittar: range.end,
      unvan: '',
      ym: '',
      usekullanici: false,
      eosusergiris: sessionData.giris,
      eosuser: sessionData.user,
      ihbaraDayali: false
    },
    sessionData
  });
}

async function ykFetchGunlukAkis(ykodu) {
  if (!ykodu) return [];
  const sessionData = ykBuildSessionData('20');
  try {
    const json = await ykPostEys('srvcYoklama_getYoklamaGunluk', {
      ykodu,
      yKodu: ykodu,
      sessionData
    });
    return ykExtractItems(json);
  } catch (_) {
    return [];
  }
}

function ykEnsureModal() {
  let modal = document.getElementById('it_yoklama_modal');
  if (modal) return modal;
  modal = document.createElement('div');
  modal.id = 'it_yoklama_modal';
  modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.50);z-index:2147483647;padding:18px;';
  modal.innerHTML = `
    <div id="it_yoklama_box" style="position:fixed;right:28px;top:120px;width:min(980px,94vw);height:min(760px,88vh);min-width:520px;min-height:320px;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.42);display:flex;flex-direction:column;resize:both;overflow:hidden;">
      <div id="it_yoklama_head" style="height:42px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;background:#0d1b31;border-bottom:1px solid #22324f;cursor:move;user-select:none;">
        <div style="font-weight:700;">Yoklama</div>
        <div><button type="button" id="it_yoklama_close" class="mini" style="color:#ff8f8f">×</button></div>
      </div>
      <div id="it_yoklama_body" style="padding:10px;overflow:auto;flex:0 0 auto;max-height:210px;font:12px/1.45 'Segoe UI',Arial,sans-serif;"></div>
      <iframe id="it_yoklama_frame" style="display:none;border:0;width:100%;flex:1;background:#eef3f8;"></iframe>
    </div>`;
  (document.body || document.documentElement).appendChild(modal);
  modal.querySelector('#it_yoklama_close').onclick = () => {
    modal.style.display = 'none';
    modal.querySelector('#it_yoklama_frame').src = 'about:blank';
  };
  return modal;
}

function ykRenderModalItems(job, items, selectedKod) {
  const modal = ykEnsureModal();
  const body = modal.querySelector('#it_yoklama_body');
  const frame = modal.querySelector('#it_yoklama_frame');
  const list = items || [];

  if (!list.length) {
    body.innerHTML = `<div style="color:#ff8f8f">Yoklama kaydı bulunamadı.</div>`;
    frame.style.display = 'none';
    return;
  }

  body.innerHTML = list.map((it, idx) => {
    const kod = ykGetKod(it);
    const url = ykBuildSonucUrl(kod);
    const durum = ykDurumText(it?.durum);
    return `<div style="border-top:1px solid #22324f;padding:7px 0;">
      <b>${idx + 1}. ${it.unvan || it.adsoyadunvan || it.adSoyadUnvan || 'Yoklama Kaydı'}</b>
      <div style="font-size:11px;color:#cbd7eb">Durum: ${durum} | Kod: ${kod || '-'} | Zaman: ${it.optime || it.sonislem || it.ilkislem || '-'}</div>
      ${url ? `<button type="button" class="it_yoklama_pdf_btn" data-url="${url}" style="margin-top:5px;">PDF Aç</button>` : `<span style="color:#ff8f8f">yKodu yok</span>`}
    </div>`;
  }).join('');

  body.querySelectorAll('.it_yoklama_pdf_btn').forEach(btn => {
    btn.onclick = () => { frame.src = btn.dataset.url; frame.style.display = 'block'; };
  });

  const targetUrl = selectedKod ? ykBuildSonucUrl(selectedKod) : (body.querySelector('.it_yoklama_pdf_btn')?.dataset?.url || '');
  if (targetUrl) {
    frame.src = targetUrl;
    frame.style.display = 'block';
  } else {
    frame.style.display = 'none';
  }
}

async function ykOpenYoklamaForJob(job, cachedItems, cachedKod, logFn) {
  const modal = ykEnsureModal();
  modal.style.display = 'flex';
  const body = modal.querySelector('#it_yoklama_body');
  const frame = modal.querySelector('#it_yoklama_frame');
  frame.style.display = 'none';
  frame.src = 'about:blank';
  body.innerHTML = '<div style="color:#9cff9c">Yoklama yükleniyor...</div>';
  try {
    let items = cachedItems;
    if (!items || !items.length) {
      const resp = await ykFetchYoklamalarForJob(job);
      items = ykExtractItems(resp);
    }
    ykRenderModalItems(job, items, cachedKod);
    if (typeof logFn === 'function') logFn('Yoklama görüntülendi.');
  } catch (e) {
    body.innerHTML = `<div style="color:#ff8f8f">Yoklama alınamadı: ${e.message || String(e)}</div>`;
    if (typeof logFn === 'function') logFn('Yoklama alınamadı: ' + (e.message || String(e)), true);
  }
}



function ykOpenPdfPopup(url) {
  if (!url) return null;
  const safeOpenFallback = () => {
    try { return window.open(url, '_blank'); } catch (_) { return null; }
  };
  try {
    const sw = window.screen && window.screen.availWidth ? window.screen.availWidth : 1366;
    const sh = window.screen && window.screen.availHeight ? window.screen.availHeight : 768;
    const sl = window.screen && Number.isFinite(window.screen.availLeft) ? window.screen.availLeft : 0;
    const st = window.screen && Number.isFinite(window.screen.availTop) ? window.screen.availTop : 0;
    const w = Math.min(980, Math.max(720, Math.floor(sw * 0.62)));
    const h = Math.min(900, Math.max(620, Math.floor(sh * 0.88)));
    const left = Math.max(0, Math.floor(sl + sw - w - 20));
    const top = Math.max(0, Math.floor(st + 40));
    const features = [
      'popup=yes',
      'noopener=no',
      'noreferrer=no',
      'resizable=yes',
      'scrollbars=yes',
      'toolbar=no',
      'menubar=no',
      'location=yes',
      'status=no',
      `width=${w}`,
      `height=${h}`,
      `left=${left}`,
      `top=${top}`
    ].join(',');
    const win = window.open(url, 'YK_PDF_POPUP', features);
    if (win) {
      try { win.focus(); } catch (_) {}
      return win;
    }
    return safeOpenFallback();
  } catch (_) {
    return safeOpenFallback();
  }
}



function ykNormalizeYmdDate(value) {
  const s = String(value || '').trim();
  if (!s) return '';

  let m = s.match(/(20\d{2})\D?([01]\d)\D?([0-3]\d)/);
  if (m) return `${m[1]}${m[2]}${m[3]}`;

  m = s.match(/([0-3]?\d)\D+([01]?\d)\D+(20\d{2})/);
  if (m) return `${m[3]}${String(m[2]).padStart(2, '0')}${String(m[1]).padStart(2, '0')}`;

  m = s.match(/tarih\s*[:=]\s*([0-3]?\d)[./-]([01]?\d)[./-](20\d{2})/i);
  if (m) return `${m[3]}${String(m[2]).padStart(2, '0')}${String(m[1]).padStart(2, '0')}`;

  return '';
}

function ykDeepFindDateByKey(obj) {
  const wanted = ['gelis', 'geliş', 'kaynak', 'talep', 'basvuru', 'başvuru', 'evrak', 'tarih', 'olusturma', 'oluşturma'];
  const seen = new Set();
  const stack = [obj];

  while (stack.length) {
    const cur = stack.pop();
    if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
    seen.add(cur);

    if (Array.isArray(cur)) {
      cur.forEach(x => stack.push(x));
      continue;
    }

    for (const [k, v] of Object.entries(cur)) {
      const lk = String(k).toLowerCase();
      if (wanted.some(w => lk.includes(w))) {
        const ymd = ykNormalizeYmdDate(v);
        if (ymd) return ymd;
      }
      if (v && typeof v === 'object') stack.push(v);
    }
  }
  return '';
}

function ykGetJobStartDate(job) {
  const candidates = [
    job?.is_gelisTarihi,
    job?.gelisTarihi,
    job?.is_tarih,
    job?.tarih,
    job?.is_kaynakTarihi,
    job?.kaynakTarihi,
    job?.talepTarihi,
    job?.basvuruTarihi,
    job?.evrakTarihi,
    job?.olusturmaTarihi,
    job?.createDate,
    job?.createdDate,
    job?.is_kaynakbilgisi,
    job?.is_kaynakBilgisi,
    job?.belgeBilgi,
    job?.evrakBilgisi
  ];

  for (const c of candidates) {
    const ymd = ykNormalizeYmdDate(c);
    if (ymd) return ymd;
  }

  const deep = ykDeepFindDateByKey(job);
  if (deep) return deep;

  try { return ykDateRangeSixMonths().start; } catch (_) { return ''; }
}

function itEnsureActionMenu() {
  let menu = document.getElementById('it_is_takip_action_menu');
  if (menu) return menu;
  menu = document.createElement('div');
  menu.id = 'it_is_takip_action_menu';
  menu.style.cssText = 'position:fixed;display:none;z-index:2147483647;min-width:220px;max-width:340px;background:#08111f;color:#eaf2ff;border:1px solid #274063;border-radius:8px;box-shadow:0 12px 30px rgba(0,0,0,.45);padding:6px;font:12px/1.35 Segoe UI,Arial,sans-serif';
  document.documentElement.appendChild(menu);
  menu.addEventListener('mouseenter', () => menu.__inside = true);
  menu.addEventListener('mouseleave', () => {
    menu.__inside = false;
    setTimeout(() => { if (!menu.__inside) menu.style.display = 'none'; }, 180);
  });
  return menu;
}

function itGetActionList(job) {
  const raw = [job?.sonrakiAdimlar, job?.sonraki_adimlar, job?.akisSonrakiAdimlar, job?.nextSteps, job?.actions, job?.adimlar, job?.islemListesi].find(Array.isArray) || [];
  const mapped = raw.map(x => ({
    text: x?.text || x?.label || x?.ad || x?.adi || x?.aciklama || x?.islemAdi || x?.name || '',
    value: x?.value || x?.kod || x?.id || x?.akisNo || x?.adimNo || x?.tip || ''
  })).filter(x => x.text || x.value);
  const fallback = [
    { text: 'Yoklamaya Sevk Et', value: 'yoklama' },
    { text: 'Önizle Aç', value: 'preview' },
    { text: 'Satır Bilgisini Göster', value: 'info' }
  ];
  const seen = new Set();
  return mapped.concat(fallback).filter(x => {
    const k = `${x.text}|${x.value}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

function itShowActionMenuForJob(job, anchor, bot) {
  const menu = itEnsureActionMenu();
  const actions = itGetActionList(job);
  menu.innerHTML = actions.map((a, i) => `<div class="it-menu-item" data-idx="${i}" style="padding:7px 9px;border-radius:6px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06);">${String(a.text || a.value || '-')}</div>`).join('');
  menu.querySelectorAll('.it-menu-item').forEach(el => {
    el.onmouseenter = () => el.style.background = '#12315a';
    el.onmouseleave = () => el.style.background = '';
    el.onclick = () => {
      const a = actions[Number(el.dataset.idx)];
      menu.style.display = 'none';
      const txt = String(a?.text || '').toLowerCase();
      if (txt.includes('önizle') || a?.value === 'preview') {
        try { bot.openPreview(job); } catch (_) {}
        return;
      }
      if (a?.value === 'info') {
        alert(JSON.stringify(job, null, 2).slice(0, 4000));
        return;
      }
      try { bot.log(`İşTakip seçenek seçildi: ${a?.text || a?.value || '-'} / isTakip=${job?.is_isTakipNo || job?.akis_isTakipNo || '-'}`); } catch (_) {}
    };
  });
  const r = anchor.getBoundingClientRect();
  const w = 260;
  let left = r.left, top = r.bottom + 4;
  if (left + w > innerWidth) left = Math.max(4, innerWidth - w - 8);
  if (top + 240 > innerHeight) top = Math.max(4, r.top - 220);
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  menu.style.display = 'block';
}


function itFindAkisOid(job) {
  const candidates = [
    job?.akisOid,
    job?.akis_oid,
    job?.akis_akisOid,
    job?.akis_islemOid,
    job?.is_akisOid,
    job?.isAkisOid,
    job?.akisoid,
    job?.oid,
    job?.kaynakEkBilgiler?.akisOid,
    job?.kaynakEkBilgiler?.akis_oid,
    job?.kaynakEkBilgiler?.akis_islemOid
  ].map(x => String(x || '').trim()).filter(Boolean);

  return candidates[0] || '';
}

function itFindOrgoid(job) {
  return String(
    job?.akis_orgoid ||
    job?.is_orgoid ||
    job?.orgoid ||
    job?.orgOid ||
    job?.kaynakEkBilgiler?.is_sicil_orgoid ||
    job?.kaynakEkBilgiler?.orgoid ||
    state.discovery?.baseOrgoid ||
    state.discovery?.orgoid ||
    ''
  ).trim();
}

async function itFetchRealActions(job) {
  const orgoid = itFindOrgoid(job);
  const akisOid = itFindAkisOid(job);

  if (!orgoid) throw new Error('orgoid bulunamadı');
  if (!akisOid) throw new Error('akisOid bulunamadı');

  const resp = await post(CFG.COMMANDS.NEXT_STEPS || 'akisIslemleri_isTakipSonrakiAdimlariBul', {
    orgoid,
    akisOid
  });

  const list = resp?.data?.hedefAdimlar || resp?.hedefAdimlar || [];
  return Array.isArray(list) ? list : [];
}

function itActionLabel(a) {
  return String(
    a?.aciklama ||
    a?.durumAciklama ||
    a?.asJSONObject?.aciklama ||
    a?.text ||
    a?.label ||
    a?.name ||
    '-'
  ).trim();
}

function itActionSub(a) {
  const bits = [];
  if (a?.durumNo !== undefined) bits.push('durumNo=' + a.durumNo);
  if (a?.tip !== undefined) bits.push('tip=' + a.tip);
  if (a?.akisNo !== undefined) bits.push('akisNo=' + a.akisNo);
  return bits.join(' / ');
}

function itShowLoadingActionMenu(anchor, text = 'Akış seçenekleri yükleniyor...') {
  const menu = itEnsureActionMenu();
  menu.innerHTML = `<div style="padding:8px 10px;color:#9cff9c">${text}</div>`;
  const r = anchor.getBoundingClientRect();
  const w = 300;
  let left = r.left;
  let top = r.bottom + 4;
  if (left + w > innerWidth) left = Math.max(4, innerWidth - w - 8);
  if (top + 260 > innerHeight) top = Math.max(4, r.top - 240);
  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  menu.style.display = 'block';
  return menu;
}

function itRenderRealActionMenu(job, anchor, bot, actions) {
  const menu = itEnsureActionMenu();

  if (!actions || !actions.length) {
    menu.innerHTML = `<div style="padding:8px 10px;color:#ffb86b">Akış seçeneği bulunamadı.</div>`;
    return;
  }

  menu.innerHTML = actions.map((a, i) => {
    const label = itActionLabel(a);
    const sub = itActionSub(a);
    return `
      <div class="it-menu-item" data-idx="${i}" style="padding:7px 9px;border-radius:6px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06);">
        <div style="font-weight:700">${label}</div>
        ${sub ? `<div style="font-size:10px;color:#aeb9d4;margin-top:2px">${sub}</div>` : ''}
      </div>`;
  }).join('');

  menu.querySelectorAll('.it-menu-item').forEach(el => {
    el.onmouseenter = () => el.style.background = '#12315a';
    el.onmouseleave = () => el.style.background = '';
    el.onclick = () => {
      const a = actions[Number(el.dataset.idx)];
      menu.style.display = 'none';

      // Şimdilik seçimi logluyoruz; istersen sonraki adımda SAVE_STEP ile gönderimi bağlarız.
      try {
        bot.log(`Akış seçildi: ${itActionLabel(a)} | durumNo=${a?.durumNo ?? '-'} tip=${a?.tip ?? '-'} akisNo=${a?.akisNo ?? '-'} | isTakip=${job?.is_isTakipNo || job?.akis_isTakipNo || '-'}`);
      } catch (_) {}
    };
  });
}

async function itShowRealActionMenuForJob(job, anchor, bot) {
  const menu = itShowLoadingActionMenu(anchor);
  try {
    const cacheKey = '__realActions';
    if (!job[cacheKey]) {
      job[cacheKey] = await itFetchRealActions(job);
    }
    itRenderRealActionMenu(job, anchor, bot, job[cacheKey]);
  } catch (e) {
    menu.innerHTML = `
      <div style="padding:8px 10px;color:#ff8f8f">Akış seçenekleri alınamadı</div>
      <div style="padding:0 10px 8px;font-size:10px;color:#aeb9d4">${String(e.message || e)}</div>`;
    try { bot.log('Akış seçenekleri alınamadı: ' + (e.message || String(e)), true); } catch (_) {}
  }
}


async function itToggleRealActionMenuForJob(job, anchor, bot) {
  const menu = itEnsureActionMenu();
  if (menu.style.display === 'block' && menu.__activeAnchor === anchor) {
    menu.style.display = 'none';
    menu.__activeAnchor = null;
    return;
  }
  menu.__activeAnchor = anchor;
  await itShowRealActionMenuForJob(job, anchor, bot);
  menu.__activeAnchor = anchor;
}



function itLocalFallbackGet(key) {
  try {
    const k = Array.isArray(key) ? key[0] : key;
    const raw = localStorage.getItem('it_storage_' + k);
    return raw ? { [k]: JSON.parse(raw) } : {};
  } catch (_) { return {}; }
}

function itLocalFallbackSet(obj) {
  try {
    Object.entries(obj || {}).forEach(([k, v]) => {
      localStorage.setItem('it_storage_' + k, JSON.stringify(v));
    });
  } catch (_) {}
}

function itChromeStorageGetSafe(key, cb) {
  try {
    if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) {
      cb(itLocalFallbackGet(key));
      return;
    }
    chrome.storage.local.get(key, out => {
      try {
        if (chrome.runtime && chrome.runtime.lastError) {
          cb(itLocalFallbackGet(key));
          return;
        }
      } catch (_) {
        cb(itLocalFallbackGet(key));
        return;
      }
      cb(out || itLocalFallbackGet(key));
    });
  } catch (_) {
    cb(itLocalFallbackGet(key));
  }
}

function itChromeStorageSetSafe(obj, cb) {
  try {
    itLocalFallbackSet(obj);
    if (!globalThis.chrome || !chrome.storage || !chrome.storage.local) {
      if (cb) cb();
      return;
    }
    chrome.storage.local.set(obj, () => {
      try {
        if (chrome.runtime && chrome.runtime.lastError) {}
      } catch (_) {}
      if (cb) cb();
    });
  } catch (_) {
    if (cb) cb();
  }
}


function setupUnifiedModuleTabs() {
  try {
    const mainPanel = document.getElementById(CFG.PANEL_ID);
    const mainWrap = mainPanel?.querySelector('#it_wrap');
    if (!mainPanel || !mainWrap) return;

    if (!document.getElementById('it_module_tabs')) {
      const tabs = document.createElement('div');
      tabs.id = 'it_module_tabs';
      tabs.className = 'it-module-tabs';
      tabs.innerHTML = `
        <button type="button" id="it_tab_main" class="it-module-tab active">Ana Modül</button>
        <button type="button" id="it_tab_eys" class="it-module-tab">EYS Modülü</button>
      `;

      const mainPage = document.createElement('div');
      mainPage.id = 'it_main_tab_page';

      const eysPage = document.createElement('div');
      eysPage.id = 'it_eys_tab_page';
      eysPage.style.display = 'none';

      const children = Array.from(mainWrap.childNodes);
      mainWrap.appendChild(tabs);
      mainWrap.appendChild(mainPage);
      mainWrap.appendChild(eysPage);

      children.forEach(ch => {
        if (ch !== tabs && ch !== mainPage && ch !== eysPage) mainPage.appendChild(ch);
      });

      const activate = (tab) => {
        const mainBtn = document.getElementById('it_tab_main');
        const eysBtn = document.getElementById('it_tab_eys');
        const mainPg = document.getElementById('it_main_tab_page');
        const eysPg = document.getElementById('it_eys_tab_page');
        const eysPanel = document.getElementById('eys-tabbed-bot-panel');

        if (tab === 'eys') {
          if (eysPanel && eysPg && eysPanel.parentElement !== eysPg) {
            eysPg.appendChild(eysPanel);
            eysPanel.classList.add('it-embedded-eys');
            eysPanel.style.display = '';
          }
          if (mainPg) mainPg.style.display = 'none';
          if (eysPg) eysPg.style.display = 'block';
          if (mainBtn) mainBtn.classList.remove('active');
          if (eysBtn) eysBtn.classList.add('active');
        } else {
          if (mainPg) mainPg.style.display = 'block';
          if (eysPg) eysPg.style.display = 'none';
          if (mainBtn) mainBtn.classList.add('active');
          if (eysBtn) eysBtn.classList.remove('active');
        }
      };

      tabs.querySelector('#it_tab_main').onclick = () => activate('main');
      tabs.querySelector('#it_tab_eys').onclick = () => activate('eys');

      window.__itActivateModuleTab = activate;
    }

    const eysPanel = document.getElementById('eys-tabbed-bot-panel');
    const eysPg = document.getElementById('it_eys_tab_page');
    if (eysPanel && eysPg && eysPanel.parentElement !== eysPg) {
      eysPg.appendChild(eysPanel);
      eysPanel.classList.add('it-embedded-eys');
      if (!document.getElementById('it_tab_eys')?.classList.contains('active')) {
        eysPg.style.display = 'none';
      }
    }

    const launcher = document.getElementById('istakip-eys-launcher');
    if (launcher) launcher.style.display = 'none';
  } catch (_) {}
}

function switchModulePanel(target) {
  try {
    setupUnifiedModuleTabs();
    if (typeof window.__itActivateModuleTab === 'function') {
      window.__itActivateModuleTab(target === 'eys' ? 'eys' : 'main');
      return true;
    }
  } catch (_) {}
  return false;
}

try { window.__istakipSwitchModule = switchModulePanel; } catch (_) {}

  class Bot {
    constructor(panel) {
      this.panel = panel;
      this.log = logger(panel);
      this.bind();
      this.loadSettings();
      discoverFromPage();
      renderDiscovery();
      this.log('XHR dinleme açıldı. İlk tıklamalarda giden sorgulardan userId / orgoid / token yakalanacak.');
    }

    bind() {
      $('#it_close', this.panel).onclick = () => {
        try {
          window.__istakipBotManualClosed = true;
          itChromeStorageSetSafe({ [CFG.UI_KEY]: { closed: true, minimized: false } });
          this.panel.remove();
          ensureRestoreButton(true);
        } catch (_) { this.panel.remove(); }
      };
      $('#it_panel_reset', this.panel).onclick = () => {
        this.panel.classList.remove('collapsed');
        $('#it_wrap', this.panel).style.display = '';
        this.panel.style.top = '118px';
        this.panel.style.right = '16px';
        this.panel.style.left = 'auto';
        this.panel.style.bottom = 'auto';
        this.panel.style.width = '980px';
        this.panel.style.height = 'min(660px, calc(100vh - 140px))';
        this.panel.style.minHeight = '320px';
        this.panel.style.display = 'flex';
        this.panel.style.flexDirection = 'column';
        this.panel.style.resize = 'none';
        this.panel.style.transform = 'none';
        fitPanelToViewport(this.panel);
      };
      $('#it_toggle', this.panel).onclick = () => {
        const wrap = $('#it_wrap', this.panel);
        const collapsed = this.panel.classList.contains('collapsed');
        if (collapsed) {
          this.panel.classList.remove('collapsed');
          wrap.style.display = '';
          this.panel.style.width = this.panel.dataset.prevWidth || 'min(980px, calc(100vw - 32px))';
          const prevH = parseInt(this.panel.dataset.prevHeight || '', 10);
          this.panel.style.height = (prevH && prevH >= 320) ? this.panel.dataset.prevHeight : 'min(660px, calc(100vh - 140px))';
          this.panel.style.minHeight = '320px';
          this.panel.style.display = 'flex';
          this.panel.style.flexDirection = 'column';
          this.panel.style.resize = 'none';
          this.panel.style.top = this.panel.dataset.prevTop || '118px';
          this.panel.style.right = this.panel.dataset.prevRight || '16px';
          this.panel.style.left = this.panel.dataset.prevLeft || 'auto';
          this.panel.style.bottom = this.panel.dataset.prevBottom || 'auto';
          fitPanelToViewport(this.panel);
        } else {
          this.panel.dataset.prevWidth = this.panel.style.width || `${this.panel.getBoundingClientRect().width}px`;
          this.panel.dataset.prevHeight = this.panel.style.height || `${this.panel.getBoundingClientRect().height}px`;
          this.panel.dataset.prevTop = this.panel.style.top || `${this.panel.getBoundingClientRect().top}px`;
          this.panel.dataset.prevRight = this.panel.style.right || '16px';
          this.panel.dataset.prevLeft = this.panel.style.left || 'auto';
          this.panel.dataset.prevBottom = this.panel.style.bottom || 'auto';
          this.panel.classList.add('collapsed');
          wrap.style.display = 'none';
          this.panel.style.width = '300px';
          this.panel.style.height = '38px';
          this.panel.style.minHeight = '38px';
          this.panel.style.resize = 'none';
          this.panel.style.top = '118px';
          this.panel.style.right = '16px';
          this.panel.style.left = 'auto';
          this.panel.style.bottom = 'auto';
        }
      };
      $('#it_discover', this.panel).onclick = () => {
        discoverFromPage();
        renderDiscovery();
        this.log(`Keşif yenilendi. userId=${state.discovery.userId || '-'} orgoid=${state.discovery.orgoid || '-'} istakipToken=${state.discovery.tokensByModule?.istakip ? 'var' : 'yok'}`);
      };
      $('#it_scan', this.panel).onclick = () => this.scan();
      $('#it_send', this.panel).onclick = () => this.sendEligible();
      $('#it_refresh', this.panel).onclick = () => this.refreshAfterSave();
      $('#it_stop', this.panel).onclick = () => { state.stopRequested = true; this.log('Durdurma istendi.'); };
      ['#it_limit','#it_filter','#it_istakip','#it_istipi','#it_atama_sil','#it_hedef_durum','#it_durum_tip','#it_islem_sahibi','#it_uzerime_al','#it_orgoid_override','#it_user_override']
        .forEach(sel => {
          const el = $(sel, this.panel);
          if (el) el.addEventListener('change', () => this.saveSettings());
        });

      ['#it_vkn_start', '#it_vkn_end'].forEach(sel => {
        const el = $(sel, this.panel);
        if (!el) return;
        ['input','change','keyup'].forEach(ev => el.addEventListener(ev, () => {
          el.value = this.digitsOnly(el.value).slice(0, 10);
          this.rerenderCurrentRows();
        }));
      });
    }

    loadSettings() {
      itChromeStorageGetSafe([CFG.STORAGE_KEY], out => {
        const s = out?.[CFG.STORAGE_KEY] || {};
        const keys = {
          limit:'#it_limit', filter:'#it_filter', istakip:'#it_istakip', isTipi:'#it_istipi',
          atamaSil:'#it_atama_sil', hedefDurum:'#it_hedef_durum', durumTip:'#it_durum_tip',
          islemSahibi:'#it_islem_sahibi', uzerimeAl:'#it_uzerime_al', orgoidOverride:'#it_orgoid_override', userOverride:'#it_user_override'
        };
        Object.entries(keys).forEach(([k, sel]) => {
          if (s[k] !== undefined && $(sel, this.panel)) $(sel, this.panel).value = s[k];
        });
      });
    }

    saveSettings() {
      const s = this.getSettings();
      itChromeStorageSetSafe({ [CFG.STORAGE_KEY]: {
        limit:String(s.limit), filter:s.filterRaw, istakip:s.istakipRaw, isTipi:String(s.isTipi),
        atamaSil:String(s.atamaSil), hedefDurum:String(s.hedefDurumNo), durumTip:String(s.akisDurumTip),
        islemSahibi:String(s.islemSahibi), uzerimeAl:String(s.isiUzerimeAl),
        orgoidOverride:s.orgoidOverride, userOverride:s.userOverride
      }});
    }

    getSettings() {
      discoverFromPage();
      const discovered = getDiscovered();
      return {
        discovered,
        userOverride: $('#it_user_override', this.panel).value.trim(),
        orgoidOverride: $('#it_orgoid_override', this.panel).value.trim(),
        userId: $('#it_user_override', this.panel).value.trim() || state.discovery.baseUserId || discovered.userId,
        orgoid: $('#it_orgoid_override', this.panel).value.trim() || state.discovery.baseOrgoid || discovered.orgoid,
        limit: 50,
        filterRaw: $('#it_filter', this.panel).value.trim(),
        istakipRaw: $('#it_istakip', this.panel).value.trim(),
        isTipi: Math.max(0, Number($('#it_istipi', this.panel).value || 5)),
        atamaSil: 1,
        hedefDurumNo: Number($('#it_hedef_durum', this.panel).value || 4),
        akisDurumTip: Number($('#it_durum_tip', this.panel).value || 21),
        islemSahibi: Number($('#it_islem_sahibi', this.panel).value || 3),
        isiUzerimeAl: Number($('#it_uzerime_al', this.panel).value || 1)
      };
    }

    assertDiscovery(s) {
      const missing = [];
      if (!s.userId) missing.push('userId');
      if (!s.orgoid) missing.push('orgoid');
      if (!s.discovered.token) missing.push('token');
      if (missing.length) {
        this.log(`Auto-discovery eksik: ${missing.join(', ')}. Önce ilgili ekranlarda birkaç işlem yap veya manuel alanları doldur.`, true);
        return false;
      }
      this.log(`Kullanılacak değerler → userId=${s.userId}, orgoid=${s.orgoid}, token=${s.discovered.token ? 'var' : 'yok'}`);
      return true;
    }

    buildListPayload(s, start = 0, pageLimit = null) {
      const raw = s.filterRaw;
      const isDigits = /^\d+$/.test(raw);
      return {
        userId: String(s.userId || ''),
        nodeId: "",
        isTipi: 5,
        atamaYapilamayacakIsleriSil: 1,
        sonucSayisi: String(pageLimit || s.limit || 50),
        sorgulamaKriterleri: {
          vergiNo: raw && isDigits && raw.length === 10 ? raw : "",
          tcKimlikNo: raw && isDigits && raw.length === 11 ? raw : "",
          belgeTarihi: "",
          sayi: "",
          basTar: "",
          bitTar: "",
          unvan: raw && !isDigits ? raw : "",
          isTuru: "",
          basBeklenenTamamlanmaTarihi: "",
          bitBeklenenTamamlanmaTarihi: "",
          etiket: "",
          istakipNo: s.istakipRaw || ""
        },
        respKeyParam: "isler",
        isTakipAkisNo: -1,
        isTakipDurumNo: -1,
        pv: { start: Number(start || 0), limit: String(pageLimit || s.limit || 50), sorters: [] }
      };
    }

    extractJobsFromListResponse(resp) {
      const key = resp?.respKeyParam || 'isler';
      return resp?.data?.isler || resp?.data?.[key] || [];
    }

    extractTotalCountFromListResponse(resp, fallbackCount = 0) {
      const vals = [
        resp?.data?.totalCount,
        resp?.data?.total,
        resp?.data?.toplam,
        resp?.data?.rowCount,
        resp?.data?.kayitSayisi,
        resp?.totalCount,
        resp?.total
      ];
      for (const v of vals) {
        const n = Number(v);
        if (Number.isFinite(n) && n >= 0) return n;
      }
      return Number(fallbackCount || 0);
    }

    async fetchAllJobsPaged(s, reason = 'İş listesi') {
      const pageLimit = Math.max(1, Number(s.limit || CFG.DEFAULT_LIMIT || 50) || 50);
      const all = [];
      let start = 0;
      let total = null;
      let pageNo = 1;

      while (true) {
        const resp = await post(CFG.COMMANDS.LIST, this.buildListPayload(s, start, pageLimit));
        const rows = this.extractJobsFromListResponse(resp);
        const respTotal = this.extractTotalCountFromListResponse(resp, all.length + rows.length);
        if (total === null) total = respTotal;

        all.push(...rows);
        this.log(`${reason}: sayfa ${pageNo} alındı. start=${start}, gelen=${rows.length}, toplam=${total}`);

        if (!rows.length) break;
        if (total && all.length >= total) break;
        if (rows.length < pageLimit) break;

        start += pageLimit;
        pageNo += 1;

        // Güvenlik sınırı: beklenmeyen sonsuz döngüyü önler.
        if (pageNo > 25) {
          this.log(`${reason}: 25 sayfa sınırına ulaşıldı, durduruldu. Alınan=${all.length}`, true);
          break;
        }
      }

      return { jobs: all, totalCount: total ?? all.length, pages: pageNo };
    }


    buildSavePayload(job, step, s) {
      return {
        atanacakNodeId: '',
        atamaYapanKullaniciUserId: s.userId,
        orgoid: s.orgoid,
        isTakipNo: job.is_isTakipNo || job.akis_isTakipNo || '',
        akisOid: job.akis_oid || '',
        atamaYapilacaklar: [],
        akisDurumKullanicilari: [],
        akisDurumNodeIdler: [],
        islemSahibi: s.islemSahibi,
        akisDurum: 1,
        userId: s.userId,
        islemYapanUserId: s.userId,
        isiUzerimeAl: s.isiUzerimeAl,
        aciklama: '',
        hedefDurumNo: Number(step?.durumNo ?? s.hedefDurumNo),
        akisDurumTip: Number(step?.tip ?? s.akisDurumTip),
        geriGonderimSebepleri: [],
        beklenenIsBitisZamani: ''
      };
    }

    shouldExcludeFromYoklama(job) {
      const texts = [
        job?.is_kaynakbilgi,
        job?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakbilgi,
        job?.kaynakEkBilgiler?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakBilgisi,
        job?.kaynakEkBilgiler?.isKaynakBilgisi,
        job?.kaynakEkBilgiler?.is_kaynak_bilgi,
        job?.kaynakEkBilgiler?.is_kaynak_bilgisi
      ]
        .filter(Boolean)
        .map(v => String(v).toLowerCase());

      const joined = texts.join(' | ');
      if (!joined) return '';

      if (joined.includes('muhtasar dönem değişikliği bildirimi')) {
        return 'is_kaynakbilgi içinde Muhtasar Dönem Değişikliği Bildirimi geçtiği için hariç';
      }
      if (joined.includes('mersis no')) {
        return 'is_kaynakbilgi içinde Mersis No geçtiği için hariç';
      }
      return '';
    }



    getKaynakText(job) {
      const vals = [
        job?.is_kaynakbilgi,
        job?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakbilgi,
        job?.kaynakEkBilgiler?.isKaynakBilgi,
        job?.kaynakEkBilgiler?.is_kaynakBilgisi,
        job?.kaynakEkBilgiler?.isKaynakBilgisi
      ].filter(Boolean);
      return vals.map(v => String(v)).join(' | ');
    }

    isMersisKaydi(job) {
      return this.getKaynakText(job).toLowerCase().includes('mersis no');
    }

    rebuildDetailMapFromCounts(counts) {
      const grouped = counts?.data?.gruplanmisIsler || counts?.data?.groupedJobs || [];
      const map = {};
      for (const row of grouped) {
        const id = Number(row?.txtGizliDetayId ?? row?.is_detayId ?? 0);
        const text = String(row?.txtIsTuru || row?.isTuru || '').trim();
        if (id > 0 && text && text !== 'TOPLAM:') map[id] = text;
      }
      state.detailMap = map;
      return map;
    }

    getIsTuruText(job) {
      const detailId = Number(job?.is_detayId ?? job?.txtGizliDetayId ?? 0);
      const dynamicText = state.detailMap?.[detailId];
      if (dynamicText) return dynamicText;
      return job?.txtIsTuru || job?.isTuru || job?.is_kaynakbilgi || job?.kaynakEkBilgiler?.is_kaynakbilgi || '-';
    }

    getBelgeBilgiText(job) {
      const k = job?.kaynakEkBilgiler || {};
      const vals = [
        job?.belgeBilgi,
        job?.is_belgeBilgi,
        job?.belge_bilgi,
        job?.is_kaynakbilgi,
        k?.belgeBilgi,
        k?.is_belgeBilgi,
        k?.belge_bilgi,
        k?.is_kaynakbilgi,
        k?.isKaynakBilgi
      ].filter(v => String(v ?? '').trim());
      const uniq = [];
      const seen = new Set();
      vals.forEach(v => {
        const txt = String(v).replace(/\s+/g, ' ').trim();
        const key = txt.toLowerCase();
        if (txt && !seen.has(key)) { seen.add(key); uniq.push(txt); }
      });
      return uniq.join(' | ') || '-';
    }

    getYoklamaStatusCacheKey(job) {
      const parts = [
        job?.akis_oid,
        job?.is_isTakipNo || job?.akis_isTakipNo,
        job?.is_vergiNo || job?.is_tcKimlikNo,
        job?.keysEvrakOid || job?.kaynakEkBilgiler?.keysEvrakOid
      ].map(v => String(v || '').trim()).filter(Boolean);
      return parts.join('|') || JSON.stringify(job || {}).slice(0, 200);
    }

getPreviewPayload(job) {
  const k = job?.kaynakEkBilgiler || {};
  const keysEvrakOid = k?.keysEvrakOid || job?.keysEvrakOid || k?.evrakOid || job?.evrakOid || k?.belgeOid || job?.belgeOid || '';
  return {
    belgeTuru: String(k?.belgeTuru ?? job?.belgeTuru ?? '').trim(),
    keysEvrakOid: String(keysEvrakOid || '').trim(),
    isGeldigiYer: k?.is_geldigiyer || job?.is_geldigiyer || '',
    kaynak: this.getKaynakText(job)
  };
}

async openPreview(job) {
  try {
    if (this.isMersisKaydi(job)) {
      this.log('Mersis No geçen kayıtta önizleme açılmadı.');
      return;
    }
    const p = this.getPreviewPayload(job);
    if (!p.keysEvrakOid) {
      this.log('Bu kayıtta keysEvrakOid bulunamadı, önizleme açılamadı.', true);
      return;
    }
    this.log(`Önizleme sorgulanıyor. keysEvrakOid=${p.keysEvrakOid}`);
    const info = await fetchKeysPreviewInfo(p.keysEvrakOid);
    this.log(`Önizleme cevabı alındı. keysEvrakOid=${p.keysEvrakOid} fileID=${info.fileID || ''} dosyaId=${info.dosyaId || ''}`);
    this.log(`Üretilen önizleme linki: ${info.url}`);
    showPreviewModal(info.url, p.kaynak || `Evrak ${p.keysEvrakOid}`);
    this.log(`Önizleme modal içinde açıldı. keysEvrakOid=${p.keysEvrakOid}`);
  } catch (e) {
    this.log(e.message || String(e), true);
  }
}

    escapeHtml(v) {
      return itHtmlEscape(v);
    }

    digitsOnly(v) {
      return String(v || '').replace(/\D+/g, '');
    }

    getVknRangeFilter() {
      const sEl = $('#it_vkn_start', this.panel);
      const eEl = $('#it_vkn_end', this.panel);
      if (sEl) sEl.value = this.digitsOnly(sEl.value).slice(0, 10);
      if (eEl) eEl.value = this.digitsOnly(eEl.value).slice(0, 10);
      return {
        start: sEl ? sEl.value : '',
        end: eEl ? eEl.value : ''
      };
    }

    getJobVkn(job) {
      const direct = this.digitsOnly(job?.is_vergiNo || job?.vergiNo || job?.vkn || '');
      if (direct.length === 10) return direct;

      // yedek: iş takip hücresinde gösterilen değerlerden 10 haneli olanı bul
      const blob = [
        job?.is_vergiNo,
        job?.is_tcKimlikNo,
        job?.is_isTakipNo,
        job?.akis_isTakipNo
      ].map(x => String(x || '')).join(' ');
      const nums = blob.match(/\d{10,11}/g) || [];
      return nums.find(n => String(n).length === 10) || '';
    }

    getJobTckn(job) {
      const direct = this.digitsOnly(job?.is_tcKimlikNo || job?.tcKimlikNo || job?.tckn || '');
      if (direct.length === 11) return direct;
      const blob = [
        job?.is_vergiNo,
        job?.is_tcKimlikNo,
        job?.is_isTakipNo,
        job?.akis_isTakipNo
      ].map(x => String(x || '')).join(' ');
      const nums = blob.match(/\d{10,11}/g) || [];
      return nums.find(n => String(n).length === 11) || '';
    }

    isVknInRange(vkn, start, end) {
      if (!start && !end) return true;
      if (!vkn || vkn.length !== 10) return false;
      if (start && start.length !== 10) start = '';
      if (end && end.length !== 10) end = '';
      if (!start && !end) return true;
      if (start && !end) return vkn >= start;
      if (!start && end) return vkn <= end;
      return vkn >= start && vkn <= end;
    }

    filterJobsByVkn(list) {
      const { start, end } = this.getVknRangeFilter();
      const arr = list || [];
      if (!start && !end) return arr;
      return arr.filter(job => this.isVknInRange(this.getJobVkn(job), start, end));
    }

    updateVknFilterInfo(total, shown) {
      let info = $('#it_vkn_filter_info', this.panel);
      const startEl = $('#it_vkn_start', this.panel);
      if (!info && startEl) {
        info = document.createElement('div');
        info.id = 'it_vkn_filter_info';
        info.style.cssText = 'font-size:11px;color:#9cff9c;margin-top:4px;';
        startEl.closest('div')?.parentNode?.appendChild(info);
      }
      if (info) info.textContent = `VKN filtre: ${shown}/${total} gösteriliyor`;
    }

    rerenderCurrentRows() {
      if (Array.isArray(this.__lastRowsRaw)) this.renderRows(this.__lastRowsRaw, true);
    }


    getYoklamaStatusForJob(job) {
      const st = job?.__ykStatus || {};
      return {
        durum: st.durum || '-',
        kod: st.kod || '',
        items: Array.isArray(st.items) ? st.items : [],
        error: st.error || ''
      };
    }

    renderYoklamaDurumCell(job) {
      const st = this.getYoklamaStatusForJob(job);
      const items = st.items || [];

      if (items.length) {
        return items.map((it) => {
          const durum = ykDurumText(it?.durum);
          const optime = it?.optime || it?.sonislem || it?.ilkislem || '';
          const title = optime ? ` title="${this.escapeHtml(optime)}"` : '';
          return `<div class="yk-line"${title}>${this.escapeHtml(durum)}</div>`;
        }).join('');
      }

      return `<span class="yk-line">${this.escapeHtml(st.durum || '-')}</span>`;
    }

    renderYoklamaKodCell(job) {
      const st = this.getYoklamaStatusForJob(job);
      const items = st.items || [];

      if (items.length) {
        return items.map((it) => {
          const kod = ykGetKod(it);
          if (!kod) return `<div class="yk-line yk-muted">Kod yok</div>`;
          return `<div class="yk-line"><a class="preview-link yk-kod-link" data-ykodu="${this.escapeHtml(kod)}">${this.escapeHtml(kod)}</a></div>`;
        }).join('');
      }

      if (st.kod) {
        return `<a class="preview-link yk-kod-link" data-ykodu="${this.escapeHtml(st.kod)}">${this.escapeHtml(st.kod)}</a>`;
      }

      return '<span class="yk-muted">-</span>';
    }

    async fetchAndCacheYoklamaStatus(job) {
      const cacheKey = this.getYoklamaStatusCacheKey(job);
      const cached = state.ykStatusCache?.get(cacheKey);
      if (cached) {
        job.__ykStatus = cached;
        return cached;
      }

      const resp = await ykFetchYoklamalarForJob(job);
      let items = ykExtractItems(resp).filter(x => ykGetKod(x) || x?.durum || x?.optime);

      const seen = new Set();
      items = items.filter(it => {
        const k = ykGetKod(it) || JSON.stringify(it).slice(0, 120);
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });

      const enriched = [];
      for (const it of items) {
        const kod = ykGetKod(it);
        let merged = it;
        if (kod) {
          try {
            const flow = await ykFetchGunlukAkis(kod);
            if (flow && flow.length) {
              const lastFlow = ykGetLastStatus(flow);
              merged = Object.assign({}, it, {
                durum: lastFlow?.item?.durum || it?.durum,
                optime: lastFlow?.item?.optime || it?.optime,
                __flow: flow
              });
            }
          } catch (_) {}
        }
        enriched.push(merged);
      }

      const last = ykGetLastStatus(enriched);
      const status = {
        durum: last.durum || '-',
        kod: last.kod || '',
        items: enriched,
        cacheKey,
        fetchedAt: Date.now()
      };
      state.ykStatusCache?.set(cacheKey, status);
      job.__ykStatus = status;
      return status;
    }

    async loadYoklamaStatusesForRenderedRows() {
      const raw = Array.isArray(this.__lastRowsRaw) ? this.__lastRowsRaw : [];
      if (!raw.length) return;

      const batchSeq = (this.__ykStatusBatchSeq || 0) + 1;
      this.__ykStatusBatchSeq = batchSeq;
      this.__ykRenderTimer = this.__ykRenderTimer || null;

      const jobsToFetch = raw.filter(job => !state.ykStatusCache?.has(this.getYoklamaStatusCacheKey(job)));
      if (!jobsToFetch.length) {
        raw.forEach(job => {
          const cached = state.ykStatusCache?.get(this.getYoklamaStatusCacheKey(job));
          if (cached) job.__ykStatus = cached;
        });
        this.renderRows(raw, true);
        this.log(`Yoklama durum/kod cache kullanıldı. kayıt=${raw.length}`);
        return;
      }

      this.log(`Yoklama durum/kod sorgusu başlıyor. yeni=${jobsToFetch.length}, cache=${raw.length - jobsToFetch.length}`);
      let index = 0;
      let done = 0;
      const concurrency = 3;
      const scheduleRender = () => {
        if (this.__ykStatusBatchSeq !== batchSeq) return;
        if (this.__ykRenderTimer) return;
        this.__ykRenderTimer = setTimeout(() => {
          this.__ykRenderTimer = null;
          if (this.__ykStatusBatchSeq === batchSeq) this.renderRows(raw, true);
        }, 350);
      };

      const worker = async () => {
        while (index < jobsToFetch.length && this.__ykStatusBatchSeq === batchSeq) {
          const job = jobsToFetch[index++];
          try {
            await this.fetchAndCacheYoklamaStatus(job);
          } catch (e) {
            const status = {
              durum: 'Alınamadı',
              kod: '',
              items: [],
              error: e.message || String(e),
              fetchedAt: Date.now()
            };
            job.__ykStatus = status;
            state.ykStatusCache?.set(this.getYoklamaStatusCacheKey(job), status);
          }
          done += 1;
          if (done === 1 || done % 10 === 0 || done === jobsToFetch.length) {
            this.log(`Yoklama durum/kod ilerleme: ${done}/${jobsToFetch.length}`);
          }
          scheduleRender();
        }
      };

      await Promise.all(Array.from({ length: Math.min(concurrency, jobsToFetch.length) }, worker));
      if (this.__ykStatusBatchSeq === batchSeq) {
        if (this.__ykRenderTimer) { clearTimeout(this.__ykRenderTimer); this.__ykRenderTimer = null; }
        this.renderRows(raw, true);
        this.log(`Yoklama durum/kod sorgusu tamamlandı. yeni=${jobsToFetch.length}, cache=${raw.length - jobsToFetch.length}`);
      }
    }

    renderRows(list, fromFilter = false) {
      if (!fromFilter) this.__lastRowsRaw = list || [];
      const body = $('#it_rows', this.panel);
      if (!body) return;
      body.innerHTML = '';

      const sourceList = Array.isArray(list) ? list : [];
      const filteredList = this.filterJobsByVkn(sourceList);
      this.updateVknFilterInfo(sourceList.length, filteredList.length);

      if (!sourceList.length) {
        body.innerHTML = '<tr><td colspan="10" class="muted">Liste boş. Önce İŞLERİ TARA ile işleri çek.</td></tr>';
        return;
      }

      if (!filteredList.length) {
        body.innerHTML = '<tr><td colspan="10" class="muted">Kayıt geldi fakat VKN aralık filtresi nedeniyle görünür kayıt yok. VKN Başlangıç/Bitiş alanlarını temizle.</td></tr>';
        return;
      }

      filteredList.forEach((job, idx) => {
        const step = job.__step;
        const status = job.__sent
          ? 'Gönderildi'
          : job.__eligible
            ? `Yoklama Süreci Başlat (${step?.durumNo}/${step?.tip})`
            : (job.__excludeReason ? `Hariç: ${job.__excludeReason}` : (job.__error || 'Uygun değil'));

        const disabledPreview = this.isMersisKaydi(job);
        const p = this.getPreviewPayload(job);
        const hasPreviewData = !!p.keysEvrakOid;

        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${idx + 1}</td>
          <td class="it-action-cell"><button class="it-row-action-btn" data-it-actions="1" title="İş seçeneklerini aç/kapat">⋮</button></td>
          <td class="it-is-takip-cell">${this.escapeHtml(job.is_isTakipNo || job.akis_isTakipNo || '')}<br><span class="muted">${this.escapeHtml((job.is_vergiNo || '') + ' ' + (job.is_tcKimlikNo || ''))}</span></td>
          <td>${this.escapeHtml(this.getBelgeBilgiText(job))}</td>
          <td>${this.escapeHtml(this.getIsTuruText(job))}</td>
          <td>${this.escapeHtml(job.is_unvan || job.is_unvan_unvan || '')}</td>
          <td class="${job.__sent || job.__eligible ? 'eligible' : job.__error ? 'bad' : ''}">${this.escapeHtml(status)}</td>
          <td>${
            disabledPreview
              ? '<a class="preview-link disabled">Mersis</a>'
              : hasPreviewData
                ? '<a class="preview-link" data-preview="1">Önizle Aç</a>'
                : '<a class="preview-link disabled">Veri Yok</a>'
          }</td>
          <td class="yk-durum">${this.renderYoklamaDurumCell(job)}</td>
          <td class="yk-kod">${this.renderYoklamaKodCell(job)}</td>`;

        const link = tr.querySelector('[data-preview="1"]');
        if (link) {
          link.onclick = (ev) => {
            ev.preventDefault();
            this.openPreview(job);
          };
        }

        tr.querySelectorAll('[data-ykodu]').forEach(ykLink => {
          ykLink.onclick = (ev) => {
            ev.preventDefault();
            const kod = ykLink.getAttribute('data-ykodu');
            const url = ykBuildSonucUrl(kod);
            if (url) ykOpenPdfPopup(url);
          };
        });

        const actionBtn = tr.querySelector('[data-it-actions="1"]');
        if (actionBtn && !actionBtn.__itMenuBound) {
          actionBtn.style.cursor = 'pointer';
          actionBtn.onclick = (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            itToggleRealActionMenuForJob(job, actionBtn, this);
          };
          actionBtn.__itMenuBound = true;
        }

        body.appendChild(tr);
      });
    }

    async scan() {
      this.saveSettings();
      const s = this.getSettings();
      renderDiscovery();
      if (!this.assertDiscovery(s)) return;
      this.log('İş türleri ve iş listesi çekiliyor...');
      try {
        const counts = await post(CFG.COMMANDS.ACTIVE_COUNTS, { userId: s.userId, nodeId: '' });
        const map = this.rebuildDetailMapFromCounts(counts);
        this.log(`İş türü eşleştirmeleri yüklendi. adet=${Object.keys(map).length}`);
      } catch (e) {
        state.detailMap = {};
        this.log(`İş türü eşleştirmeleri yüklenemedi: ${e.message || String(e)}`, true);
      }
      let pageResult;
      try {
        pageResult = await this.fetchAllJobsPaged(s, 'İşleri Tara');
      } catch (e) {
        this.log(e.message || String(e), true);
        return;
      }
      state.jobs = pageResult.jobs || [];
      state.eligibleJobs = [];
      this.renderRows(state.jobs);
      this.log(`Toplam ${state.jobs.length}/${pageResult.totalCount} iş geldi. Listeye döküldü; sonraki adımlar kontrol ediliyor...`);
      for (let i = 0; i < state.jobs.length; i++) {
        if (state.stopRequested) break;
        const job = state.jobs[i];
        try {
          const excludeReason = this.shouldExcludeFromYoklama(job);
          if (excludeReason) {
            job.__eligible = false;
            job.__excludeReason = excludeReason;
            const tag = job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid;
            this.log(`${i + 1}/${state.jobs.length} ${tag} → hariç (${excludeReason})`);
            continue;
          }

          const next = await post(CFG.COMMANDS.NEXT_STEPS, { orgoid: s.orgoid, akisOid: job.akis_oid });
          const steps = next?.data?.hedefAdimlar || [];
          job.__steps = steps;
          const step = steps.find(x => String(x?.aciklama || '').toLowerCase().includes('yoklama süreci başlat')) || null;
          job.__step = step;
          job.__eligible = !!step;
          if (job.__eligible) state.eligibleJobs.push(job);
          const tag = job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid;
          this.log(`${i + 1}/${state.jobs.length} ${tag} → ${job.__eligible ? `uygun (durumNo=${step?.durumNo}, tip=${step?.tip}, akisNo=${step?.akisNo})` : 'uygun değil'}`);
          if (i === 0 || job.__eligible || (i + 1) % 5 === 0 || i === state.jobs.length - 1) {
            this.renderRows(state.jobs, true);
          }
        } catch (e) {
          job.__eligible = false;
          job.__error = e.message || String(e);
          this.log(`${i + 1}/${state.jobs.length} ${job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid} kontrol hatası: ${job.__error}`, true);
          if (i === 0 || (i + 1) % 5 === 0 || i === state.jobs.length - 1) {
            this.renderRows(state.jobs, true);
          }
        }
      }
      this.renderRows(state.jobs);
        this.loadYoklamaStatusesForRenderedRows();
      this.log(`Tarama bitti. Uygun iş sayısı: ${state.eligibleJobs.length}`);
    }

    async sendEligible() {
      const s = this.getSettings();
      renderDiscovery();
      if (!this.assertDiscovery(s)) return;
      const list = state.eligibleJobs.length ? state.eligibleJobs : state.jobs.filter(x => x.__eligible);
      if (!list.length) {
        this.log('Gönderilecek uygun iş yok. Önce İŞLERİ TARA çalıştır.', true);
        return;
      }
      state.running = true;
      state.stopRequested = false;
      $('#it_stop', this.panel).style.display = '';
      if (!confirm(`Uygun ${list.length} iş Yoklama Süreci Başlat adımına gönderilecek. Devam edilsin mi?`)) {
        state.running = false;
        $('#it_stop', this.panel).style.display = 'none';
        this.log('Gönderim kullanıcı tarafından iptal edildi.');
        return;
      }
      this.log(`Uygun işleri doğrudan servisten gönderme başlıyor. Adet=${list.length}`);
      for (let i = 0; i < list.length; i++) {
        if (state.stopRequested) break;
        const job = list[i];
        const tag = job.is_isTakipNo || job.akis_isTakipNo || job.akis_oid;
        try {
          if (!job.__step) {
            this.log(`${tag} için adım bilgisi yok; atlandı.`, true);
            continue;
          }
          const payload = this.buildSavePayload(job, job.__step, s);
          await post(CFG.COMMANDS.SAVE_STEP, payload);
          job.__sent = true;
          this.log(`${i + 1}/${list.length} ${tag} gönderildi. hedefDurumNo=${payload.hedefDurumNo}, akisDurumTip=${payload.akisDurumTip}, orgoid=${payload.orgoid}`);
        } catch (e) {
          job.__sendErr = e.message || String(e);
          this.log(`${i + 1}/${list.length} ${tag} gönderim hatası: ${job.__sendErr}`, true);
        }
      }
      this.renderRows(state.jobs);
        this.loadYoklamaStatusesForRenderedRows();
      await this.refreshAfterSave();
      $('#it_stop', this.panel).style.display = 'none';
      state.running = false;
      this.log(state.stopRequested ? 'İşlem durduruldu.' : 'Gönderim tamamlandı.');
    }

    async refreshAfterSave() {
      const s = this.getSettings();
      renderDiscovery();
      if (!this.assertDiscovery(s)) return;
      try {
        const counts = await post(CFG.COMMANDS.ACTIVE_COUNTS, { userId: s.userId, nodeId: '' });
        const toplam = counts?.data?.toplamIs;
        const map = this.rebuildDetailMapFromCounts(counts);
        if (typeof toplam !== 'undefined') this.log(`Aktif iş sayıları yenilendi. toplamIs=${toplam}`);
        this.log(`İş türü eşleştirmeleri yenilendi. adet=${Object.keys(map).length}`);
      } catch (e) {
        this.log(`Aktif iş sayıları yenilenemedi: ${e.message || String(e)}`, true);
      }
      try {
        const pageResult = await this.fetchAllJobsPaged(s, 'Liste yenileme');
        state.jobs = pageResult.jobs || [];
        this.log(`Liste yenilendi. Güncel iş sayısı=${state.jobs.length}/${pageResult.totalCount}`);
        this.renderRows(state.jobs);
        this.loadYoklamaStatusesForRenderedRows();
      } catch (e) {
        this.log(`Liste yenilenemedi: ${e.message || String(e)}`, true);
      }
    }
  }


  function ensureRestoreButton(show = true) {
    try {
      const old = document.getElementById(CFG.RESTORE_ID);
      if (!show) { if (old) old.remove(); return; }
      if (old) return old;
      const host = document.body || document.documentElement;
      if (!host) return null;
      const btn = document.createElement('button');
      btn.id = CFG.RESTORE_ID;
      btn.type = 'button';
      btn.textContent = 'İş Takip Botunu Aç';
      btn.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#2563eb;color:#fff;border:1px solid #60a5fa;border-radius:10px;padding:9px 12px;font:12px Segoe UI,Arial,sans-serif;font-weight:700;box-shadow:0 10px 24px rgba(0,0,0,.35);cursor:pointer;';
      btn.addEventListener('click', () => {
        try {
          window.__istakipBotManualClosed = false;
          itChromeStorageSetSafe({ [CFG.UI_KEY]: { closed: false, minimized: false } });
          btn.remove();
          ensurePanelLive(true);
        } catch (_) {}
      }, true);
      host.appendChild(btn);
      return btn;
    } catch (_) { return null; }
  }

  function shouldLoad() {
    const href = String(location.href || '').toLowerCase();
    const host = String(location.hostname || '').toLowerCase();
    return host.includes('keys.ggm.bim') || href.includes('keys.ggm.bim') || href.includes('/gp/') || href.includes('takdire-sevk');
  }

  function ensurePanelLive(forceOpen = false) {
    try {
      injectStyle();
      if (!document.body && !document.documentElement) {
        setTimeout(() => ensurePanelLive(forceOpen), 300);
        return;
      }
      itChromeStorageGetSafe([CFG.UI_KEY], out => {
        const ui = out?.[CFG.UI_KEY] || {};
        const closed = !!window.__istakipBotManualClosed || (forceOpen ? false : !!ui.closed);
        if (closed) {
          ensureRestoreButton(true);
          return;
        }
        ensureRestoreButton(false);
        if (!document.getElementById(CFG.PANEL_ID)) {
          const panel = createPanel();
          window.__istakipBotInstanceV427 = new Bot(panel);
          setupUnifiedModuleTabs();
          bindMainPanelMoveAndResize(panel);
        }
      });
    } catch (_) {
      if (document.body || document.documentElement) {
        if (!document.getElementById(CFG.PANEL_ID)) {
          const panel = createPanel();
          window.__istakipBotInstanceV427 = new Bot(panel);
          setupUnifiedModuleTabs();
          bindMainPanelMoveAndResize(panel);
        }
      } else {
        setTimeout(() => ensurePanelLive(forceOpen), 300);
      }
    }
  }

  if (!shouldLoad()) return;
  wirePageMessages();
  injectPageHook();
  patchNetwork();
  restoreDiscovery(() => {
    ensurePanelLive(false);
    document.addEventListener('DOMContentLoaded', () => setTimeout(() => ensurePanelLive(false), 150));
    window.addEventListener('pageshow', () => setTimeout(() => ensurePanelLive(false), 300));
    window.addEventListener('load', () => setTimeout(() => ensurePanelLive(false), 500));
    document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(() => ensurePanelLive(), 200); });
    setInterval(() => {
      if (!document.getElementById(CFG.PANEL_ID) && shouldLoad()) ensurePanelLive();
    }, 1500);
  });


// v4.31.46: Sonradan eklenen VKN filtre patch'lerinin kullandığı yardımcılar.
// Önceki pakette bu fonksiyonlar tanımlı olmadığı için arka planda hata oluşabiliyor
// ve liste renderı kararsızlaşabiliyordu. Boş filtrede hiçbir satırı gizlemez.
function getCurrentVknFilter(panel){
  try {
    return onlyDigits(panel?.querySelector('#it_filter')?.value || '').slice(0, 11);
  } catch (_) { return ''; }
}

function rowMatchesTypedVkn(tr, vkn){
  try {
    const needle = onlyDigits(vkn || '');
    if (!needle) return true;
    const raw = onlyDigits(tr?.innerText || tr?.textContent || '');
    return raw.includes(needle);
  } catch (_) { return true; }
}

function getVknRange(panel){
  try {
    const start = onlyDigits(panel?.querySelector('#it_vkn_start')?.value || '').slice(0,10);
    const end = onlyDigits(panel?.querySelector('#it_vkn_end')?.value || '').slice(0,10);
    return { start, end };
  } catch (_) { return { start:'', end:'' }; }
}

function parseTaxNoFromRow(tr){
  try { return getVknFromRow(tr); } catch (_) { return ''; }
}

function getVknFromIsTakipRow(tr){
  try { return getVknFromRow(tr); } catch (_) { return ''; }
}

function applyVknRangeFilter(panel){
  try {
    const range = getVknRange(panel);
    const rows = getRowsFromTable(panel);
    if (!range.start && !range.end) {
      rows.forEach(tr => { tr.style.display = ''; });
      return;
    }
    rows.forEach(tr => {
      const vkn = getVknFromRow(tr);
      tr.style.display = inVknRange(vkn, range.start, range.end) ? '' : 'none';
    });
  } catch (_) {}
}

function ensureVknRangeRow(panel){
  // Alanlar ana HTML içinde zaten var; burada sadece eksik paket hatasını önlüyoruz.
  return panel;
}

window.addEventListener('resize', () => {
  const panel = document.getElementById(CFG.PANEL_ID);
  if (panel) fitPanelToViewport(panel);
}, { passive: true });


setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;

    // Uzun metinleri tek satıra indir
    panel.querySelectorAll('code, .mono, .token, .src, small').forEach(el => {
      el.style.maxHeight = '16px';
      el.style.overflow = 'hidden';
      el.style.textOverflow = 'ellipsis';
      el.style.whiteSpace = 'nowrap';
      el.style.lineHeight = '16px';
      el.style.display = 'block';
      el.style.fontSize = el.tagName === 'SMALL' ? '10px' : '11px';
    });

    // Üstteki bilgi bloklarını küçült
    panel.querySelectorAll('div').forEach(el => {
      const t = (el.textContent || '').trim();
      if (/Keşfedilen Kullanıcı|Keşfedilen OrgOid|Keşfedilen Token|İlk Giriş Oturumu|Kullanılan İş Takip tokeni|Kullanılan token kaynağı|Kullanıcı kaynağı|OrgID kaynağı/i.test(t)) {
        el.style.paddingTop = '2px';
        el.style.paddingBottom = '2px';
        el.style.marginTop = '0';
        el.style.marginBottom = '0';
        el.style.lineHeight = '1.2';
      }
    });

    // İç alan scroll kalsın
    const body = panel.querySelector('.body');
    if (body) {
      body.style.overflowY = 'auto';
      body.style.overflowX = 'hidden';
    }
  } catch (e) {}
}, 700);


setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;

    const buttons = Array.from(panel.querySelectorAll('button'));
    const isleriTaraBtn = buttons.find(b => /İŞLERİ TARA/i.test((b.textContent || '').trim()));
    if (isleriTaraBtn) {
      const row = isleriTaraBtn.closest('div');
      if (row) {
        row.style.position = 'sticky';
        row.style.top = '0';
        row.style.zIndex = '6';
        row.style.background = '#0d1b31';
        row.style.paddingTop = '4px';
        row.style.paddingBottom = '4px';
      }
    }

    const candidates = Array.from(panel.querySelectorAll('textarea, div, pre'));
    candidates.forEach(el => {
      const txt = (el.textContent || '').trim();
      const isLog = /XHR dinleme açıldı|Kullanılacak değerler|İş türleri ve iş listesi çekiliyor|Toplam \d+ iş geldi|haric|uygun/i.test(txt) ||
                    (el.id && /log|monitor/i.test(el.id)) ||
                    (el.className && /log|monitor/i.test(String(el.className)));
      if (isLog) {
        el.style.minHeight = '110px';
        el.style.height = '140px';
        el.style.maxHeight = '160px';
        el.style.overflow = 'auto';
        el.style.resize = 'vertical';
      }
    });

    const body = panel.querySelector('.body');
    if (body) {
      body.style.overflowY = 'auto';
      body.style.overflowX = 'hidden';
    }
  } catch (e) {}
}, 700);



setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    const log = panel.querySelector('#it_log');
    if (log) {
      log.style.height = '82px';
      log.style.minHeight = '82px';
      log.style.maxHeight = '82px';
      log.style.overflow = 'auto';
    }
    const tblwrap = panel.querySelector('.tblwrap');
    if (tblwrap) {
      tblwrap.style.maxHeight = '420px';
      tblwrap.style.overflow = 'auto';
      const ths = tblwrap.querySelectorAll('thead th');
      ths.forEach(th => {
        th.style.position = 'sticky';
        th.style.top = '0';
        th.style.zIndex = '5';
        th.style.background = '#0d1b31';
      });
    }
    const disc = panel.querySelector('.disc');
    if (disc) {
      disc.style.maxHeight = '120px';
      disc.style.overflow = 'auto';
      disc.style.padding = '4px';
    }
    panel.querySelectorAll('.tokcard').forEach(el => {
      el.style.maxHeight = '90px';
      el.style.overflow = 'auto';
      el.style.padding = '4px';
    });
  } catch (e) {}
}, 500);



setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;

    // Üst keşif alanlarını gizle
    panel.querySelectorAll('.disc,.tokcard,.tiny').forEach(el => {
      el.style.display = 'none';
    });

    // Vergi No / TCKN alanına yazılan değere göre sadece İşTakip sütununun alt satırındaki
    // vergi no / tc no eşleşen işleri göster. Boşsa hepsini göster.
    const vkn = getCurrentVknFilter(panel);
    const tbl = panel.querySelector('.tblwrap table');
    if (tbl && tbl.tBodies && tbl.tBodies[0]) {
      Array.from(tbl.tBodies[0].rows).forEach(tr => {
        tr.style.display = rowMatchesTypedVkn(tr, vkn) ? '' : 'none';
      });
    }
  } catch(e) {}
}, 700);

setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    const vkn = getCurrentVknFilter(panel);
    const log = panel.querySelector('#it_log');
    if (log && vkn) {
      const tag = `VKN filtresi aktif: ${vkn}`;
      if (!String(log.textContent || '').includes(tag)) {
        log.textContent = tag + "\n" + log.textContent;
      }
    }
  } catch(e) {}
}, 2500);


setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;

    panel.querySelectorAll('.hide-above-buttons').forEach(el => {
      el.style.display = 'none';
    });

    const tbl = panel.querySelector('.tblwrap table');
    if (tbl && tbl.tBodies && tbl.tBodies[0]) {
      const range = getVknRange(panel);
      Array.from(tbl.tBodies[0].rows).forEach(tr => {
        const no = parseTaxNoFromRow(tr);
        tr.style.display = inVknRange(no, range.start, range.end) ? '' : 'none';
      });
    }
  } catch(e) {}
}, 500);


setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    const s = panel.querySelector('#it_vkn_start');
    const e = panel.querySelector('#it_vkn_end');
    if (s && !s.__rangeBind) {
      const apply = () => {
        const range = getVknRange(panel);
        const table = panel.querySelector('.tblwrap table');
        if (table && table.tBodies && table.tBodies[0]) {
          Array.from(table.tBodies[0].rows).forEach(tr => {
            const no = parseTaxNoFromRow(tr);
            tr.style.display = inVknRange(no, range.start, range.end) ? '' : 'none';
          });
        }
      };
      s.addEventListener('input', apply);
      e && e.addEventListener('input', apply);
      s.__rangeBind = true;
      if (e) e.__rangeBind = true;
    }
  } catch(e) {}
}, 600);


setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;

    panel.querySelectorAll('.hide-above-buttons').forEach(el => {
      el.style.display = 'none';
    });

    const { start, end } = getVknRange(panel);
    const table = panel.querySelector('.tblwrap table');
    if (table && table.tBodies && table.tBodies[0]) {
      Array.from(table.tBodies[0].rows).forEach(tr => {
        const vkn = getVknFromIsTakipRow(tr);
        tr.style.display = inVknRange(vkn, start, end) ? '' : 'none';
      });
    }
  } catch(e) {}
}, 300);


setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;

    panel.querySelectorAll('.hide-above-buttons').forEach(el => {
      el.style.display = 'none';
    });

    applyVknRangeFilter(panel);

    const s = panel.querySelector('#it_vkn_start');
    const e = panel.querySelector('#it_vkn_end');
    if (s && !s.__vknRangeBind) {
      const fn = () => applyVknRangeFilter(panel);
      s.addEventListener('input', fn);
      s.addEventListener('change', fn);
      if (e) {
        e.addEventListener('input', fn);
        e.addEventListener('change', fn);
      }
      s.__vknRangeBind = true;
      if (e) e.__vknRangeBind = true;
    }
  } catch(e) {}
}, 300);


setInterval(() => {
  try{
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel || panel.__vknObserverBound) return;
    const wrap = panel.querySelector('.tblwrap');
    if (!wrap) return;
    const mo = new MutationObserver(() => applyVknRangeFilter(panel));
    mo.observe(wrap, { childList:true, subtree:true, characterData:true });
    panel.__vknObserverBound = true;
  }catch(e){}
}, 500);


setInterval(() => {
  try {
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;

    ensureVknRangeRow(panel);
    hideUpperFilterRows(panel);
    applyVknRangeFilter(panel);

    const s = panel.querySelector('#it_vkn_start');
    const e = panel.querySelector('#it_vkn_end');
    if (s && !s.__vknBind) {
      const run = () => applyVknRangeFilter(panel);
      ['input','change','keyup'].forEach(ev => s.addEventListener(ev, run));
      if (e) ['input','change','keyup'].forEach(ev => e.addEventListener(ev, run));
      const scan = panel.querySelector('#it_scan');
      const refresh = panel.querySelector('#it_refresh');
      if (scan) scan.addEventListener('click', () => setTimeout(run, 1200));
      if (refresh) refresh.addEventListener('click', () => setTimeout(run, 400));
      s.__vknBind = true;
      if (e) e.__vknBind = true;
    }
  } catch(e) {}
}, 300);


setInterval(() => {
  try{
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel) return;
    hideUpperFilterRows(panel);
    ensureHeaderVknFilter(panel);
    applyHeaderVknFilter(panel);

    const scan = panel.querySelector('#it_scan');
    const refresh = panel.querySelector('#it_refresh');
    if (scan && !scan.__headerVknBind) {
      const run = () => setTimeout(() => {
        ensureHeaderVknFilter(panel);
        applyHeaderVknFilter(panel);
      }, 1200);
      scan.addEventListener('click', run);
      if (refresh) refresh.addEventListener('click', () => setTimeout(() => {
        ensureHeaderVknFilter(panel);
        applyHeaderVknFilter(panel);
      }, 500));
      scan.__headerVknBind = true;
    }
  }catch(e){}
}, 300);


setInterval(() => {
  try{
    const panel = document.getElementById(CFG.PANEL_ID);
    if (!panel || panel.__headVknObserverBound) return;
    const wrap = panel.querySelector('.tblwrap');
    if (!wrap) return;
    const mo = new MutationObserver(() => {
      ensureHeaderVknFilter(panel);
      applyHeaderVknFilter(panel);
    });
    mo.observe(wrap, { childList:true, subtree:true, characterData:true });
    panel.__headVknObserverBound = true;
  }catch(e){}
}, 500);

try { setInterval(setupUnifiedModuleTabs, 700); } catch (_) {}
try { setInterval(() => bindMainPanelMoveAndResize(document.getElementById(CFG.PANEL_ID)), 700); } catch (_) {}

})();
