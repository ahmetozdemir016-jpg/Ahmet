chrome.action.onClicked.addListener(async (tab) => {
  try {
    if (!tab || !tab.id || !tab.url || !/^https?:/i.test(tab.url)) return;
    await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true}, world:'MAIN', files:['page_hook.js']}).catch(()=>{});
    await chrome.scripting.executeScript({target:{tabId:tab.id}, files:['content.js']}).catch(()=>{});
    await chrome.scripting.executeScript({target:{tabId:tab.id}, files:['eys_content.js']}).catch(()=>{});
    await chrome.scripting.executeScript({target:{tabId:tab.id}, files:['eys_launcher.js']}).catch(()=>{});
  } catch (e) { console.error('İş Takip + EYS açma hatası', e); }
});
