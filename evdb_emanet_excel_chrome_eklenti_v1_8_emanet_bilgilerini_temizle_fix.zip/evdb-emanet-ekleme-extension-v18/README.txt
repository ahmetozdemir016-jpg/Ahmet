EVDB Emanet Excel Bot v1.8

Referans: v1.5.

Düzeltmeler:
- Vergi Kimlik No alanına ekstra tıklama kaldırıldı.
- İlk kayıt eklendikten ve onay verildikten sonra 2. ve sonraki kayıtlar öncesinde sadece "Emanet Bilgilerini Temizle" butonuna basılır.
- Alttaki genel "Temizle" butonuna otomatik basılmaz.
- Çalışan v1.5 akışı korunmuştur: Belge Türü=Diğer, TC/VKN, Belge No, Tutar, Tarihler, Emanet Türü=39, Emanet Ekle, onay.

Kurulum:
1) Chrome uzantılarından eski sürümü kaldırın.
2) Paketlenmemiş öğe yükle ile bu klasörü seçin.
3) EVDB ekranını yenileyin.
4) Eklenti ikonuna basarak paneli açın.
