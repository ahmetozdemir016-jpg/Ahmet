/* Takdire Sevk 2 endpoint düzeltmesi
   - Eski doğrudan IP'deki gibintranet_server çağrılarını keys.ggm.bim'e yönlendirir.
   - 503 / Service Unavailable gelirse aynı çağrıyı alternatif uçlarla bir kez daha dener.
   - Senkron (async:false) eski kod akışını bozmaz.
*/
(function(){
  if (window.__TAKDIRE_SEVK2_ENDPOINT_PATCH__) return;
  window.__TAKDIRE_SEVK2_ENDPOINT_PATCH__ = true;

  var MAIN = 'http://keys.ggm.bim/gibintranet_server/dispatch';
  var OLD_IP = 'http://10.251.63.99/gibintranet_server/dispatch';
  var ALT = [
    MAIN,
    'http://10.251.63.99/gibintranet_server/dispatch'
  ];

  function isGibIntranetDispatch(url){
    return /\/gibintranet_server\/dispatch/i.test(String(url || ''));
  }

  function normalizeUrl(url){
    url = String(url || '');
    if (!url) return url;
    return url.replace(/^http:\/\/10\.251\.63\.99\/gibintranet_server\/dispatch/i, MAIN)
              .replace(/^https?:\/\/keys\.ggm\.bim\/gibintranet_server\/dispatch/i, MAIN);
  }

  function swapBase(url, base){
    url = String(url || '');
    if (!isGibIntranetDispatch(url)) return url;
    return url.replace(/^https?:\/\/[^/]+\/gibintranet_server\/dispatch/i, base)
              .replace(/^\/gibintranet_server\/dispatch/i, base);
  }

  function isUnavailable(xhr){
    try {
      var status = Number(xhr && xhr.status || 0);
      var txt = String(xhr && xhr.responseText || '');
      return status === 0 || status >= 500 || /Service Unavailable|HTTP\/1\.1\s+Service Unavailable/i.test(txt);
    } catch(e) { return false; }
  }

  function patchAjax(){
    if (!window.jQuery || !window.jQuery.ajax || window.jQuery.ajax.__tkEndpointPatched) return;
    var realAjax = window.jQuery.ajax;
    function patchedAjax(opts){
      if (typeof opts === 'string') opts = { url: opts };
      opts = opts || {};
      if (!opts.url || !isGibIntranetDispatch(opts.url)) {
        return realAjax.apply(this, arguments);
      }
      var firstUrl = normalizeUrl(opts.url);
      var sameOrigin = false;
      try { sameOrigin = (new URL(firstUrl, location.href)).origin === location.origin; } catch(e) {}
      var firstOpts = window.jQuery.extend(true, {}, opts, {
        url: firstUrl,
        crossDomain: !sameOrigin,
        xhrFields: sameOrigin ? (opts.xhrFields || {}) : window.jQuery.extend(true, {}, opts.xhrFields || {}, { withCredentials: true })
      });
      var xhr = realAjax.call(this, firstOpts);
      if (opts.async === false && isUnavailable(xhr)) {
        for (var i=0; i<ALT.length; i++) {
          var nextUrl = swapBase(opts.url, ALT[i]);
          if (nextUrl === firstUrl) continue;
          var retrySameOrigin = false;
          try { retrySameOrigin = (new URL(nextUrl, location.href)).origin === location.origin; } catch(e) {}
          var retryOpts = window.jQuery.extend(true, {}, opts, {
            url: nextUrl,
            crossDomain: !retrySameOrigin,
            xhrFields: retrySameOrigin ? (opts.xhrFields || {}) : window.jQuery.extend(true, {}, opts.xhrFields || {}, { withCredentials: true })
          });
          try {
            var retryXhr = realAjax.call(this, retryOpts);
            if (!isUnavailable(retryXhr)) return retryXhr;
            xhr = retryXhr;
          } catch(e) {}
        }
      }
      return xhr;
    }
    patchedAjax.__tkEndpointPatched = true;
    window.jQuery.ajax = patchedAjax;
    if (window.$ && window.$.ajax) window.$.ajax = patchedAjax;
  }

  // jQuery geldikten sonra, fonksiyon.js kendi queue patch'ini kurmadan önce çalıştırılır.
  patchAjax();
  document.addEventListener('DOMContentLoaded', patchAjax);
})();
