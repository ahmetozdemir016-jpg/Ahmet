/*
 * Takdire Sevk 2 - MV3 CSP uyumluluk katmanı
 * Orijinal dosyada inline onclick kullanımları vardı. Chrome Manifest V3 inline script
 * çalıştırmadığı için bilinen onclick komutlarını burada event delegation ile çalıştırıyoruz.
 */
(function () {
  'use strict';

  function callGlobal(name, args) {
    var fn = window[name];
    if (typeof fn === 'function') {
      fn.apply(window, args || []);
      return true;
    }
    console.warn('[TakdireSevk2] Fonksiyon bulunamadı:', name);
    return true;
  }

  function parseSingleQuotedArgs(code) {
    var args = [];
    var re = /'((?:\\'|[^'])*)'/g;
    var m;
    while ((m = re.exec(code)) !== null) {
      args.push(m[1].replace(/\\'/g, "'"));
    }
    return args;
  }

  function handleInlineCommand(code) {
    code = String(code || '').trim().replace(/;$/, '');

    var simple = {
      'filterMyTable6ByTsFisNo()': ['filterMyTable6ByTsFisNo'],
      'clearMyTable6TsFilter()': ['clearMyTable6TsFilter'],
      'mergeAciklamaCells()': ['mergeAciklamaCells'],
      'unmergeAciklamaCells()': ['unmergeAciklamaCells'],
      'customSortByYearAndVergiKodu()': ['customSortByYearAndVergiKodu'],
      'saveVdKodu()': ['saveVdKodu'],
      'showVdKoduModal()': ['showVdKoduModal']
    };

    if (simple[code]) return callGlobal(simple[code][0]);

    if (code === "set0003Mode('natural')") return callGlobal('set0003Mode', ['natural']);
    if (code === "set0003Mode('special')") return callGlobal('set0003Mode', ['special']);

    if (code.indexOf("document.getElementById('vdKoduModal').style.display='none'") === 0) {
      var modal = document.getElementById('vdKoduModal');
      if (modal) modal.style.display = 'none';
      return true;
    }

    if (/^beyanname_getir_guncel\s*\(/.test(code)) {
      return callGlobal('beyanname_getir_guncel', parseSingleQuotedArgs(code));
    }

    return false;
  }

  document.addEventListener('click', function (ev) {
    var el = ev.target && ev.target.closest ? ev.target.closest('[onclick]') : null;
    if (!el) return;
    var code = el.getAttribute('onclick');
    if (!code) return;
    if (handleInlineCommand(code)) {
      ev.preventDefault();
      ev.stopPropagation();
      if (typeof ev.stopImmediatePropagation === 'function') ev.stopImmediatePropagation();
    }
  }, true);
})();
