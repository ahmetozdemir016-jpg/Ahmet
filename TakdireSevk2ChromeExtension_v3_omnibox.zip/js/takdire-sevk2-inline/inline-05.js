/**
 * mergeAciklamaCells()
 * -------------------
 * Amaç: myTable6 içindeki "Açıklama" sütununda, seçilen (checkbox) ardışık satırların
 * açıklama hücrelerini tek hücreye dönüştürmek (rowspan).
 *
 * Kullanım:
 * 1) myTable6 satırlarında soldaki checkbox'ları işaretle
 * 2) Satırlar alt alta (ardışık) olmalı
 * 3) "Seçilenleri Birleştir (Açıklama)" butonuna bas
 */
function mergeAciklamaCells() {
  const table = document.getElementById('myTable6');
  if (!table) { alert('myTable6 bulunamadı'); return; }

  // ✅ Checkbox ile seçilen satırlar
  const rows = Array.from(
    table.querySelectorAll('tbody tr')
  ).filter(tr => {
    const cb = tr.querySelector('input[type="checkbox"]');
    return cb && cb.checked;
  });

  if (rows.length < 2) {
    alert('Birleştirmek için en az 2 satır seçmelisiniz (soldaki Seç kutularını işaretleyin).');
    return;
  }

  // sıraya sok
  rows.sort((a,b) => a.rowIndex - b.rowIndex);

  // Açıklama td’si: textarea.aciklama-textarea içeren td
  const getAciklamaTd = (tr) => {
    const ta = tr.querySelector('textarea.aciklama-textarea');
    return ta ? ta.closest('td') : null;
  };

  // Ardışık satır kontrolü (alt alta seçilmeli)
  for (let i = 1; i < rows.length; i++) {
    if (rows[i].rowIndex !== rows[i-1].rowIndex + 1) {
      alert('Lütfen alt alta (ardışık) satırları seçin.');
      return;
    }
  }

  const firstTd = getAciklamaTd(rows[0]);
  if (!firstTd) { alert('İlk satırda açıklama hücresi bulunamadı.'); return; }

  const currentRowspan = parseInt(firstTd.getAttribute('rowspan') || '1', 10);
  firstTd.setAttribute('rowspan', String(currentRowspan + rows.length - 1));

  // aşağıdaki satırların açıklama hücresini kaldır
  for (let i = 1; i < rows.length; i++) {
    const td = getAciklamaTd(rows[i]);
    if (td) td.remove();
  }
}
