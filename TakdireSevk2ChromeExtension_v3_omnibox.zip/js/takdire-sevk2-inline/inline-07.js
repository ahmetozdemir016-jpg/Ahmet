// === PATCH: takdire-sevk1 mantığıyla menü + beyanname için token / tok düzeltmeleri ===
(function(){
  function tokenAl(){
    // 1) fonksiyon.js / foksiyon.js içinden token() varsa kullan
    try{
      if (window.token && typeof window.token === "function"){
        var t = window.token();
        if (t) return String(t);
      }
    }catch(e){}

    // 2) Sayfadaki token inputundan (welcome.jsp?token=...) çek
    try{
      var tokenlink = (window.jQuery ? ($('#token').val()||'') : (document.getElementById('token')?.value||'')).trim();
      var m = /token=([^&\s]+)/.exec(tokenlink);
      if (m && m[1]) return m[1];
    }catch(e){}

    // 3) localStorage fallback
    try{
      var ls = localStorage.getItem('gibToken') || localStorage.getItem('token');
      if (ls) return ls;
    }catch(e){}
    return "";
  }

  // Eski kod uyumluluğu
  window._tok = function(){ return tokenAl(); };
  window.tok = window.tok || ""; // bazı fonksiyonlar tok bekliyor

  function vknAl(){
    try{ return (window.jQuery ? ($('#input').val()||'') : (document.getElementById('input')?.value||'')).trim(); }
    catch(e){ return ""; }
  }

  function guard(){
    var vkn = vknAl();
    var t = tokenAl();
    if (!vkn){ alert("VKN/TCKN giriniz."); return null; }
    if (!t){ alert("Token bulunamadı. Token linkini yapıştırın veya fonksiyon.js içindeki token() çalışmalı."); return null; }
    return {vkn:vkn, token:t};
  }

  function openDiger(file){
    var g = guard(); if(!g) return;
    var url = "diger/" + file + "?vkn=" + encodeURIComponent(g.vkn) + "&token=" + encodeURIComponent(g.token);
    window.open(url, "_blank");
  }

  function bind(){
    if (!window.jQuery) return;

    // Menü butonları (takdire-sevk1 mantığı)
    $('#go85').off('click.taksevkPatch').on('click.taksevkPatch', function(e){ e.preventDefault(); e.stopPropagation(); openDiger("beyanname_getir.html"); });
    $('#go22').off('click.taksevkPatch').on('click.taksevkPatch', function(e){ e.preventDefault(); e.stopPropagation(); var g=guard(); if(!g) return; var yil=prompt('Hangi Yıldan itibaren başlasın',''); if(yil===null) return; yil=String(yil).trim(); if(!yil){ alert('Yıl Girilmesi Gerekiyor'); return; } window.open('diger/kdv_beyanlari_bs_pos.html?tekYil=Evet&vkn=' + encodeURIComponent(g.vkn) + '&token=' + encodeURIComponent(g.token) + '&yil=' + encodeURIComponent(yil), '_blank'); });
    $('#go3').off('click.taksevkPatch').on('click.taksevkPatch',  function(e){ e.preventDefault(); e.stopPropagation(); openDiger("kesinti-getir.html"); });
    $('#go5').off('click.taksevkPatch').on('click.taksevkPatch',  function(e){ e.preventDefault(); e.stopPropagation(); openDiger("gelen-giden-evrak.html"); });
    $('#go6').off('click.taksevkPatch').on('click.taksevkPatch',  function(e){ e.preventDefault(); e.stopPropagation(); openDiger("bs-karsilastirma.html"); });
    $('#go81').off('click.taksevkPatch').on('click.taksevkPatch', function(e){ e.preventDefault(); e.stopPropagation(); openDiger("efatura-earsiv-sorgulama-aylik.html"); });
    $('#go82').off('click.taksevkPatch').on('click.taksevkPatch', function(e){ e.preventDefault(); e.stopPropagation(); openDiger("tum-motorlu-tasitlar.html"); });
    $('#go86').off('click.taksevkPatch').on('click.taksevkPatch', function(e){ e.preventDefault(); e.stopPropagation(); openDiger("takbis-gMenkulAlanSatan.html"); });
    $('#go84').off('click.taksevkPatch').on('click.taksevkPatch', function(e){ e.preventDefault(); e.stopPropagation(); openDiger("kdviraHata.html"); });

    // Beyanname fonksiyonunda "tok" undefined hatasını önle
    // Eğer fonksiyon globalde varsa, wrapper ile tok set edelim
    if (typeof window.beyanname_getir_guncel === "function"){
      var _old = window.beyanname_getir_guncel;
      window.beyanname_getir_guncel = function(){
        try{ window.tok = tokenAl(); }catch(e){}
        return _old.apply(this, arguments);
      };
    }
  }

  if (document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }
})();
