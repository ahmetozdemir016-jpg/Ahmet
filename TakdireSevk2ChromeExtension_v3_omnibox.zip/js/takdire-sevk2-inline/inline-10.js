// === PATCH3: 0012 veya 0003 tek başına ise "Yükleniyor" yazılarını kaldır (otomatik POS/BS çağrısı atlanınca ekranda takılı kalmasın) ===
(function(){
  if(!window.jQuery) return;

  function uniqVergiKodlari(){
    var set = {};
    // Takdire sevk tablosundaki ilk kolonda genelde 4 haneli vergi kodu var (0003/0012 gibi)
    $('table tr').each(function(){
      var tds = $(this).find('td');
      if(!tds.length) return;
      var first = ($(tds[0]).text()||'').trim();
      var m = /^(\d{4})$/.exec(first);
      if(m) set[m[1]] = true;
    });
    return Object.keys(set);
  }

  function shouldSkipOnly(){
    var codes = uniqVergiKodlari();
    if(codes.length !== 1) return null;
    if(codes[0] === '0012' || codes[0] === '0003') return codes[0];
    return null;
  }

  function replaceLoading(label){
    // Satış / Karşıt Alış / Banka sütunlarında "Yükleniyor" geçen hücreleri düzelt
    $('td').each(function(){
      var txt = ($(this).text()||'').trim();
      if(txt === 'Yükleniyor'){
        $(this).text(label);
      }
    });
  }

  function run(){
    var code = shouldSkipOnly();
    if(!code) return false;

    // Daha anlaşılır bir metin
    var label = '-';
    replaceLoading(label);

    // Eğer varsa, bazı sürümlerde loader class'ları
    $('.loading, .is-loading, .pending').removeClass('loading is-loading pending');

    return true;
  }

  // Tablo AJAX ile dolduktan sonra çalışsın diye birkaç kez dene
  var tries = 0;
  var timer = setInterval(function(){
    tries++;
    try{
      if(run()){
        clearInterval(timer);
      }else if(tries > 30){
        clearInterval(timer);
      }
    }catch(e){
      if(tries > 30) clearInterval(timer);
    }
  }, 300);
})();
