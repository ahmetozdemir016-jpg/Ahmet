/* === GÜVENLİ JSON PARSE (RECURSION-PROOF) + AJAX HATA GÜNLÜĞÜ === */
(function(){
  // recursion-proof parse helper
  window.safeJsonParse = function(payload, label){
    if (payload && typeof payload === "object") return payload;
    if (payload == null) {
      console.warn("[GİB] Boş cevap (null).", label || "");
      return null;
    }
    var txt = String(payload);
    if (!txt || txt.trim() === "") {
      console.warn("[GİB] Boş cevap (empty).", label || "");
      return null;
    }
    try {
      return window.JSON.parse(txt);
    } catch (e) {
      console.error("[GİB] JSON parse edilemedi.", label || "", e, "Cevap(ilk 500):", txt.slice(0,500));
      return null;
    }
  };

  window.safeJsonParseText = function(text, label){
    if (!text || typeof text !== "string" || text.trim() === "") {
      console.warn("[GİB] Boş cevap (text).", label || "");
      return null;
    }
    try { return window.JSON.parse(text); }
    catch(e){
      console.error("[GİB] JSON parse edilemedi (text).", label || "", e, "Cevap(ilk 500):", text.slice(0,500));
      return null;
    }
  };



  window.showTakdirServiceError = function(message, url, responseText){
    try {
      var msg = message || 'GİB servisinden JSON cevap alınamadı.';
      var shortResp = String(responseText || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 350);
      var detail = url ? ('\nURL: ' + url) : '';
      if (shortResp) detail += '\nCevap: ' + shortResp;
      console.error('[TakdireSevk2]', msg, url || '', shortResp || '');
      var box = document.getElementById('error-container');
      if (!box) {
        box = document.createElement('div');
        box.id = 'error-container';
        (document.body || document.documentElement).prepend(box);
      }
      box.innerHTML = '<div style="margin:10px 0;padding:12px;border:2px solid #b00020;background:#fff3f3;color:#7a0015;font-weight:bold;white-space:pre-wrap">'
        + msg.replace(/[&<>]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c]; })
        + detail.replace(/[&<>]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c]; })
        + '</div>';
      if (!window.__tkServiceErrorAlerted) {
        window.__tkServiceErrorAlerted = true;
        alert(msg + detail);
      }
    } catch(e) {}
  };


  if (window.jQuery && jQuery.ajaxSetup) {
    jQuery.ajaxSetup({
      cache: false,
      error: function(xhr, status, err){
        var resp = (xhr && xhr.responseText) ? xhr.responseText : "";
        console.error("[GİB] AJAX hata:", (xhr?xhr.status:"?"), status, err || "", "Cevap(ilk 500):", resp.slice(0,500));
      }
    });
  }
})();
