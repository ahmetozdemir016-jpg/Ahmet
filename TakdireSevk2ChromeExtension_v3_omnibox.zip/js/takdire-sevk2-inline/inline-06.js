/**
 * unmergeAciklamaCells()
 * ---------------------
 * Amaç: Birleştirilmiş (rowspan>1) açıklama bloğunu tekrar satırlara ayırmak.
 *
 * Not: Birleştirilmiş bloğun baş satırını seçmek zorunda değilsin.
 * Bloğun herhangi bir satırı seçiliyse (checkbox), fonksiyon yukarı doğru tarayıp
 * ilgili rowspan hücresini bulur.
 *
 * Kullanım:
 * 1) Birleştirilmiş bloğun içinden en az 1 satırı checkbox ile seç
 * 2) "Birleştirmeyi Kaldır (Açıklama)" butonuna bas
 */
function unmergeAciklamaCells() {
  const table = document.getElementById('myTable6');
  if (!table) { alert('myTable6 bulunamadı'); return; }

  // Checkbox ile seçilen satırlar
  const selectedRows = Array.from(table.querySelectorAll('tbody tr')).filter(tr => {
    const cb = tr.querySelector('input[type="checkbox"]');
    return cb && cb.checked;
  });

  if (selectedRows.length === 0) {
    alert('Önce soldaki Seç kutularından en az 1 satır seçin.');
    return;
  }

  // Seçilenlerden ilkini baz alalım
  selectedRows.sort((a,b) => a.rowIndex - b.rowIndex);
  const anyRow = selectedRows[0];

  // Açıklama hücresini (td) bulma yardımcıları
  const getAciklamaTd = (tr) => {
    const ta = tr.querySelector('textarea.aciklama-textarea');
    return ta ? ta.closest('td') : null;
  };

  // 1) Eğer seçilen satırda açıklama td varsa: burası blok başı olabilir
  // 2) Eğer yoksa: yukarı doğru çıkıp rowspan ile bu satırı kapsayan "baş" satırı bul
  let headRow = null;
  let headTd = getAciklamaTd(anyRow);

  if (headTd) {
    headRow = anyRow;
  } else {
    // yukarı doğru tara
    let r = anyRow.previousElementSibling;
    while (r) {
      const td = getAciklamaTd(r);
      if (td) {
        const rs = parseInt(td.getAttribute('rowspan') || '1', 10);
        // td'nin kapsadığı aralık anyRow'u içeriyor mu?
        const start = r.rowIndex;
        const end = start + rs - 1;
        if (anyRow.rowIndex >= start && anyRow.rowIndex <= end) {
          headRow = r;
          headTd = td;
          break;
        }
      }
      r = r.previousElementSibling;
    }
  }

  if (!headRow || !headTd) {
    alert('Birleştirilmiş açıklama bloğu bulunamadı. (Seçtiğiniz satırlar birleşik değil gibi)');
    return;
  }

  const rowspan = parseInt(headTd.getAttribute('rowspan') || '1', 10);
  if (rowspan <= 1) {
    alert('Seçtiğiniz blokta kaldırılacak bir birleştirme yok (rowspan=1).');
    return;
  }

  // Açıklama sütununun index’i (hangi kolonda duruyor)
  const aciklamaCellIndex = headTd.cellIndex;

  // Head textarea değeri (istersen diğerlerine kopyalayabiliriz; şimdilik sadece head’de kalsın)
  const headTextarea = headTd.querySelector('textarea.aciklama-textarea');
  const headValue = headTextarea ? headTextarea.value : '';

  // Head td'yi 1'e düşür
  headTd.setAttribute('rowspan', '1');

  // Aşağıdaki satırlara td ekle
  let current = headRow.nextElementSibling;
  for (let i = 1; i < rowspan; i++) {
    if (!current) break;

    // Eğer bu satırda zaten açıklama td yoksa, geri ekle
    // (bazı durumlarda yanlışlıkla kalmış olabilir)
    let existingTd = getAciklamaTd(current);

    if (!existingTd) {
      const td = document.createElement('td');
      td.className = 'aciklama-td';
      td.style.textAlign = 'center';

      // textarea oluştur
      const ta = document.createElement('textarea');
      ta.className = 'aciklama-textarea';
      ta.placeholder = 'Açıklama yazınız';

      // İstersen aynı metni hepsine koymak için:
      // ta.value = headValue;

      td.appendChild(ta);

      // doğru kolona ekle
      const cells = current.children;
      if (aciklamaCellIndex >= cells.length) {
        current.appendChild(td);
      } else {
        current.insertBefore(td, cells[aciklamaCellIndex]);
      }
    }

    current = current.nextElementSibling;
  }

  // Varsayılan davranış: Kaldırma işleminde sadece "baş" satırda yazılı metin kalır.
  // Alttaki satırlara geri eklenen textarea'lar boş gelir.
  // İstersen aşağıdaki satırı açarak hepsine aynı metni kopyalayabilirsin:
  // ta.value = headValue;

}
