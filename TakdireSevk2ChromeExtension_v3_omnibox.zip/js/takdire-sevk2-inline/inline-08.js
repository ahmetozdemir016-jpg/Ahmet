// === PATCH2: Menü tıklamasında çift pencere açılmasını engelle ===
(function(){
  if (!window.jQuery) return;
  var ids = ['go85','go22','go3','go5','go6','go81','go82','go86','go84'];

  function tokenAl(){
    try{ if (window.token && typeof window.token==='function'){ var t=window.token(); if(t) return String(t);} }catch(e){}
    try{ var tokenlink = ($('#token').val()||'').trim(); var m=/token=([^&\s]+)/.exec(tokenlink); if(m&&m[1]) return m[1]; }catch(e){}
    try{ var ls=localStorage.getItem('gibToken')||localStorage.getItem('token'); if(ls) return ls; }catch(e){}
    return "";
  }
  function vknAl(){ return ($('#input').val()||'').trim(); }
  function guard(){
    var vkn=vknAl(), t=tokenAl();
    if(!vkn){ alert('VKN/TCKN giriniz.'); return null; }
    if(!t){ alert('Token bulunamadı.'); return null; }
    return {vkn:vkn, token:t};
  }
  function openDiger(file){
    var g=guard(); if(!g) return;
    var url="diger/"+file+"?vkn="+encodeURIComponent(g.vkn)+"&token="+encodeURIComponent(g.token);
    window.open(url,'_blank');
  }
  var map={
    go85:"beyanname_getir.html",
    go22:"__PROMPT_KDV_BS_POS__",
    go3:"kesinti-getir.html",
    go5:"gelen-giden-evrak.html",
    go6:"bs-karsilastirma.html",
    go81:"efatura-earsiv-sorgulama-aylik.html",
    go82:"tum-motorlu-tasitlar.html",
    go86:"takbis-gMenkulAlanSatan.html",
    go84:"kdviraHata.html"
  };

  // Basit debounce: aynı butona 800ms içinde ikinci tıklama olursa yut
  var lastClick = {};
  function shouldBlock(id){
    var now=Date.now();
    if(lastClick[id] && (now-lastClick[id] < 800)) return true;
    lastClick[id]=now;
    return false;
  }

  $(function(){
    ids.forEach(function(id){
      var el=document.getElementById(id);
      if(!el) return;

      // inline onclick varsa temizle (çift açılmanın ana sebebi bu)
      try{ el.onclick = null; el.removeAttribute('onclick'); }catch(e){}

      // tüm eski handler'ları temizlemek için clone yöntemi
      var $el=$(el);
      var $clone=$el.clone(false); // event taşımadan kopyala
      $el.replaceWith($clone);

      var $btn=$('#'+id);
      $btn.on('click', function(e){
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        if (shouldBlock(id)) return false;
        if(map[id]==='__PROMPT_KDV_BS_POS__'){ var g=guard(); if(!g) return false; var yil=prompt('Hangi Yıldan itibaren başlasın',''); if(yil===null) return false; yil=String(yil).trim(); if(!yil){ alert('Yıl Girilmesi Gerekiyor'); return false; } window.open('diger/kdv_beyanlari_bs_pos.html?tekYil=Evet&vkn=' + encodeURIComponent(g.vkn) + '&token=' + encodeURIComponent(g.token) + '&yil=' + encodeURIComponent(yil), '_blank'); } else { openDiger(map[id]); }
        return false;
      });
    });
  });
})();
