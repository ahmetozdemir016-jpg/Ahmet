// =====================
// 3) TABLO6 FİLTRE/SIRALAMA + PRINT KONTROL
// - TS Fiş No çoklu filtre
// - Filtre sonrası otomatik sıralama
// - Yıl/Vergi/TS bazlı sıralama
// - Yazdırmada myTable11'i opsiyonel gizleme
// =====================
// === Yardımcılar ===
function _text(el){ return (el && el.textContent || "").trim(); }
function _toYYYYMMDD(s){
  if(!s) return null; s=s.trim();
  if(/^\d{8}$/.test(s)) return s;
  if(/^\d{4}-\d{2}-\d{2}$/.test(s)) return s.replace(/-/g,'');
  var m=s.match(/^(\d{2})[./](\d{2})[./](\d{4})$/); if(m) return m[3]+m[2]+m[1];
  var d=new Date(s); if(!isNaN(d)){var y=d.getFullYear(),mm=('0'+(d.getMonth()+1)).slice(-2),dd=('0'+d.getDate()).slice(-2);return ''+y+mm+dd;}
  return null;
}

// ---- ESNEK TS Fiş No filtresi (ör. 2025052206FRx00000003) ----

function findColumnIndexByHeader(tbl, keywords){
  if(!tbl || !tbl.rows || !tbl.rows.length) return -1;
  var keys = (keywords || []).map(function(k){ return (k||'').toLowerCase(); }).filter(Boolean);
  var maxHeaderRows = Math.min(3, tbl.rows.length); // genelde 1-2 satır başlık var
  for(var r=0; r<maxHeaderRows; r++){
    var row = tbl.rows[r];
    if(!row || !row.cells) continue;
    var idx = 0;
    for(var c=0; c<row.cells.length; c++){
      var cell = row.cells[c];
      var txt = (cell.textContent || cell.innerText || '').replace(/\s+/g,' ').trim().toLowerCase();
      var span = cell.colSpan ? parseInt(cell.colSpan,10) : 1;
      if(!isFinite(span) || span<1) span = 1;
      for(var k=0; k<keys.length; k++){
        if(txt.indexOf(keys[k]) !== -1){
          return idx; // bu hücrenin başladığı kolon index'i
        }
      }
      idx += span;
    }
  }
  return -1;
}

function filterMyTable6ByTsFisNo(){
  var input = document.getElementById('tsfisnoFilterInput');
  var raw = (input && input.value ? input.value : '').trim().toLowerCase();
  var tbl = document.getElementById('myTable6');
  if(!tbl){ alert('myTable6 bulunamadı'); return; }

  // Çoklu arama: virgül / noktalı virgül / boşluk / satır sonu
  var parts = raw.split(/[\s,;]+/).map(function(x){ return x.trim(); }).filter(Boolean);
  var needles = parts.map(function(x){
    return x.replace(/[^a-z0-9]/gi,'');
  }).filter(Boolean);

  var onlyVisible = !!(document.getElementById('tsOnlyVisible') && document.getElementById('tsOnlyVisible').checked);

  var rows = tbl.getElementsByTagName('tr');
  var visibleCount = 0;

  // Eğer "Sadece mevcut listede ara" kapalıysa tüm satırları önce görünür yap
  if(!onlyVisible){
    for(var r=2; r<rows.length; r++){
      var tds0 = rows[r].getElementsByTagName('td');
      if(!tds0 || tds0.length===0) continue;
      rows[r].style.display = '';
    }
  }

  for(var i=2; i<rows.length; i++){
    var tds = rows[i].getElementsByTagName('td');
    if(!tds || tds.length===0) continue;

    // onlyVisible=true ise, halihazırda gizli satırları hiç elleme
    if(onlyVisible && rows[i].style.display === 'none') continue;

    var tsCol = findColumnIndexByHeader(tbl, ['ts fiş no','ts fis no','ts fiş','ts fis']);
    if(tsCol < 0) tsCol = 3; // yedek: TS Fiş No genelde 4. sütun (0-index 3)
    var ts = ((tds[tsCol] && (tds[tsCol].innerText || tds[tsCol].textContent)) ? (tds[tsCol].innerText || tds[tsCol].textContent) : '').trim().toLowerCase();
    var tsClean = ts.replace(/[^a-z0-9]/gi,'');

    var show;
    if(needles.length === 0){
      show = true;
    } else {
      show = false;
      for(var k=0; k<needles.length; k++){
        if(tsClean.indexOf(needles[k]) !== -1){ show = true; break; }
      }
    }

    rows[i].style.display = show ? '' : 'none';
    if(show) visibleCount++;
  }

  var counter = document.getElementById('tsfisnoMatchCount');
  if(counter) counter.textContent = visibleCount + ' kayıt';

  // Filtre sonrası sıralamayı da uygula
  try { customSortByYearAndVergiKodu(); } catch(e) {}
}

function clearMyTable6TsFilter(){
  var inp = document.getElementById('tsfisnoFilterInput');
  if(inp) inp.value = '';
  var tbl = document.getElementById('myTable6');
  if(tbl){
    var rows = tbl.getElementsByTagName('tr');
    for(var i=2;i<rows.length;i++){
      var tds = rows[i].getElementsByTagName('td');
      if(!tds || tds.length===0) continue;
      rows[i].style.display='';
    }
  }
  var counter=document.getElementById('tsfisnoMatchCount');
  if(counter) counter.textContent='';
  try { customSortByYearAndVergiKodu(); } catch(e) {}
}




// Enter ile TS Fiş filtresini çalıştır
document.addEventListener('DOMContentLoaded', function(){
  var inp=document.getElementById('tsfisnoFilterInput');
  if(inp){ inp.addEventListener('keydown',function(e){ if(e.key==='Enter') filterMyTable6ByTsFisNo();}); }
});
// ====== SIRALAMA / FİLTRE + FİŞ TARİH FİLTRESİ (v3) ======
// Tablo ID'n farklıysa aç ve şunu aktif et: window.__TABLE_ID__='seninTabloIdin';
window.__TABLE_ID__ = window.__TABLE_ID__ || 'myTable6';

// 0003 (Muhtasar) modu:
//  - 'natural'  => 3 Aylık (Çeyrek) muhtasar: 1-3, 4-6, 7-9, 10-12
//  - 'special'  => Aylık muhtasar: 1,2,3,...,12
var __KOD0003_MODE__ = window.__KOD0003_MODE__ || 'natural';
var __VERGI_SIRA__   = ["0003","0015","0032","0033","0001","0010"]; // yıl içi vergi kodu önceliği

function set0003Mode(mode){
  __KOD0003_MODE__ = (mode === 'special') ? 'special' : 'natural';
  var label = document.getElementById('mode-label');
  if (label) label.textContent = 'Aktif: ' + (__KOD0003_MODE__ === 'natural' ? '3 Aylık Muhtasar' : 'Aylık Muhtasar');
}

function __parseDonemRange_kb(text){
  // Dönem hücresi bazen 2 satır gelir: "2020-07\n2020-09" (çeyrek) veya "2020-06\n2020-06" (aylık)
  var t = (text == null) ? "" : String(text);
  t = t.replace(/\r/g, "\n");
  var lines = t.split("\n").map(function(s){ return s.trim(); }).filter(Boolean);

  function ym(s){
    var m = String(s).match(/(\d{4})\D*(\d{2})/);
    if (!m) return null;
    return {y: parseInt(m[1],10), m: parseInt(m[2],10)};
  }

  var first = null, last = null;
  if (lines.length){
    first = ym(lines[0]);
    last  = ym(lines[lines.length-1]);
  }
  if (!first){
    var m0 = t.match(/(\d{4})\D*(\d{2})/);
    if (m0) first = {y:parseInt(m0[1],10), m:parseInt(m0[2],10)};
  }
  if (!last) last = first;

  return {
    y: first ? first.y : 0,
    start: first ? first.m : 0,
    end: last ? last.m : (first ? first.m : 0),
    isRange: !!(first && last && (first.m !== last.m))
  };
}

function __parseYearMonth_kb(text){
  // Geriye dönük uyumluluk: mevcut çağrılar {y,m} bekliyor.
  var p = __parseDonemRange_kb(text);
  return {y: p.y, m: p.start};
}

function __monthOrderFor(vergiKodu, month, donemText){
  // month: __parseYearMonth_kb()'den gelen başlangıç ayı
  var m = parseInt(month,10) || 0;

  // ay -> çeyrek başlangıç ayına çevir (1,4,7,10)
  function quarterStart(mm){
    mm = parseInt(mm,10) || 0;
    if (mm <= 0) return 0;
    return mm - ((mm - 1) % 3);
  }

  // Dönem aralık mı? (örn: 2020-07 / 2020-09)
  var p = __parseDonemRange_kb(donemText);

  // 0015 (KDV) aylık: doğal sıra
  if (vergiKodu === '0015') return m;

  // 0032 / 0033: ekranda çeyrek dönem (1-3,4-6,7-9,10-12) gösteriliyor.
  // Aralıklı dönemlerde çeyrek başlangıç ayına göre (1,4,7,10) sıralamak gerekiyor.
  if (vergiKodu === '0032' || vergiKodu === '0033'){
    return p.isRange ? p.start : quarterStart(m);
  }

  // 0003 (Muhtasar) için de aralıklı dönemler olabiliyor: aralıkta doğal çeyrek sırası, aylıkta mod uygulanır.
  if (vergiKodu === '0003'){
    // 3 Aylık Muhtasar (Doğal): çeyrek sırası (1,4,7,10)
    if (__KOD0003_MODE__ === 'natural'){
      return p.isRange ? p.start : quarterStart(m);
    }
    // Aylık Muhtasar (Özel): ay sırası (1..12)
    return m;
  }

  return m;
}


function __tsKey(text){ return String(text||'').trim().toUpperCase(); }

// Tablo hazır olana kadar güvenli çalıştır
function withTable(fn){
  var tries = 0;
  (function wait(){
    var table = document.getElementById(window.__TABLE_ID__ || 'myTable6');
    if (table) fn(table);
    else if (tries++ < 60) setTimeout(wait, 100);  // ~6 sn
    else alert("Tablo ("+(window.__TABLE_ID__||'myTable6')+") bulunamadı.");
  })();
}


// --- KOLON INDEX BULUCU (başlıklara göre, colspan destekli)
function __getColIndexes(table){
  // default fallbacks (Seç, Vergi Kodu, Dönemi, TS Fiş No)
  var fallback = {vergi: 1, donem: 2, ts: 3};

  function norm(s){
    return String(s||"").replace(/\s+/g," ").trim().toLowerCase();
  }
  function matchAny(text, patterns){
    for (var i=0;i<patterns.length;i++){
      if (patterns[i].test(text)) return true;
    }
    return false;
  }

  var want = {
    vergi: [/^vergi\s*kodu$/i, /^vergi\s*kod/i],
    donem: [/^dönem/i, /^donem/i],
    ts:    [/^ts\s*fiş/i, /^ts\s*fis/i, /fiş\s*no/i, /fis\s*no/i]
  };

  // header rows: first few rows
  var headerRows = [];
  var max = Math.min(5, table.rows.length);
  for (var r=0; r<max; r++){
    headerRows.push(table.rows[r]);
  }

  var found = {vergi: null, donem: null, ts: null};

  headerRows.forEach(function(row){
    if (found.vergi!==null && found.donem!==null && found.ts!==null) return;
    var col = 0;
    Array.from(row.cells).forEach(function(cell){
      var txt = norm(cell.innerText);
      // bazı başlık hücreleri boş olabilir
      if (txt){
        if (found.vergi===null && matchAny(txt, want.vergi)) found.vergi = col;
        if (found.donem===null && matchAny(txt, want.donem)) found.donem = col;
        if (found.ts===null    && matchAny(txt, want.ts))    found.ts    = col;
      }
      col += (cell.colSpan || 1);
    });
  });

  return {
    vergi: (found.vergi!==null ? found.vergi : fallback.vergi),
    donem: (found.donem!==null ? found.donem : fallback.donem),
    ts:    (found.ts!==null ? found.ts : fallback.ts)
  };
}

// --- ANA SIRALAMA: Yıl ↑ → Vergi Kodu önceliği → TS Fiş No ↑ → Ay (kod-bazlı)
function customSortByYearAndVergiKodu(){
  withTable(function(table){
    var idx = __getColIndexes(table);
    var allRows = Array.from(table.rows).slice(2); // veri satırları
    var tbody = table.tBodies[0] || table;

    // Seçim sorusu
    var choice = prompt("Yıl+Vergi Sırala:\n1) Tüm yıllar\n2) Tek yıl\n3) Seçili yıllar (virgülle)\n\nSeçim (1/2/3):", "1");
    if (choice === null) return;
    choice = (choice || "1").trim();

    var selectedYears = null; // null => tüm yıllar
    if (choice === "2"){
      var y = prompt("Hangi yıl? (örn: 2020)", "");
      if (y === null) return;
      y = (y || "").trim();
      if (!/^\d{4}$/.test(y)){ alert("Yıl formatı hatalı. Örn: 2020"); return; }
      selectedYears = [parseInt(y,10)];
    } else if (choice === "3"){
      var ys = prompt("Yılları virgülle yazın (örn: 2020,2021,2023)", "");
      if (ys === null) return;
      ys = (ys || "").trim();
      var parts = ys.split(/[,; ]+/).filter(Boolean);
      var arr = [];
      parts.forEach(function(p){
        p = p.trim();
        if (/^\d{4}$/.test(p)) arr.push(parseInt(p,10));
      });
      if (!arr.length){ alert("Geçerli yıl bulunamadı."); return; }
      // uniq + sıralı
      arr = Array.from(new Set(arr)).sort(function(a,b){return a-b;});
      selectedYears = arr;
    } else {
      selectedYears = null;
    }

    // satırları ayır (seçili yıllar / diğerleri)
    var inScope = [];
    var outScope = [];

    allRows.forEach(function(r){
      // Dönem hücresinden yıl/ay parse
      var ym = __parseYearMonth_kb((r.cells[idx.donem] ? r.cells[idx.donem].innerText : ""));
      if (selectedYears && selectedYears.indexOf(ym.y) === -1){
        outScope.push(r);
      } else {
        inScope.push(r);
      }
    });

    // Seçili değilse gizle (liste oluşturma)
    if (selectedYears){
      outScope.forEach(function(r){ r.style.display = "none"; });
      inScope.forEach(function(r){ r.style.display = ""; });
    } else {
      // tüm yıllar: hepsi görünür
      allRows.forEach(function(r){ r.style.display = ""; });
    }

    // Sıralama: yıl -> vergi önceliği -> dönem(ay) -> TS
    inScope.sort(function(a,b){
      var aDonemTxt = (a.cells[idx.donem] ? a.cells[idx.donem].innerText : "");
      var bDonemTxt = (b.cells[idx.donem] ? b.cells[idx.donem].innerText : "");
      var aYM = __parseYearMonth_kb(aDonemTxt);
      var bYM = __parseYearMonth_kb(bDonemTxt);

      if (aYM.y !== bYM.y) return aYM.y - bYM.y;

      var aVergi = (a.cells[idx.vergi] ? a.cells[idx.vergi].innerText : "").trim();
      var bVergi = (b.cells[idx.vergi] ? b.cells[idx.vergi].innerText : "").trim();
      var aIdx = __VERGI_SIRA__.indexOf(aVergi);
      var bIdx = __VERGI_SIRA__.indexOf(bVergi);

      // listede olmayan kodlar en sona
      if (aIdx === -1) aIdx = 999;
      if (bIdx === -1) bIdx = 999;
      if (aIdx !== bIdx) return aIdx - bIdx;

      // dönem/ay sırası (0003 için mod dikkate alınır)
      var aM = __monthOrderFor(aVergi, aYM.m, aDonemTxt);
      var bM = __monthOrderFor(bVergi, bYM.m, bDonemTxt);
      if (aM !== bM) return aM - bM;

      // TS Fiş No
      var aTS = __tsKey((a.cells[idx.ts] ? a.cells[idx.ts].innerText : ""));
      var bTS = __tsKey((b.cells[idx.ts] ? b.cells[idx.ts].innerText : ""));
      return aTS.localeCompare(bTS);
    });

    // DOM'a yaz
    inScope.forEach(function(r){ tbody.appendChild(r); });

    // Seçili yıllar varsa, gizlenenleri en alta al ama gizli kalsın (düzen bozulmasın)
    if (selectedYears){
      outScope.forEach(function(r){ tbody.appendChild(r); });
    }
  });
}


// --- YIL FİLTRESİ (seçili yıl → grup önceliği → TS → ay)
function filterByYear(selectedYear){
  withTable(function(table){
    var idx = __getColIndexes(table);
    var rows = Array.from(table.rows).slice(2);
    var tbody = table.tBodies[0] || table;

    rows.forEach(function(row){
      var donemTxt = (row.cells[idx.donem] ? row.cells[idx.donem].innerText : "");
      var y = __parseYearMonth_kb(donemTxt).y;
      row.style.display = (selectedYear === "all" || y === selectedYear) ? "" : "none";
    });

    if (selectedYear !== "all"){
      var vis = rows.filter(function(r){ return r.style.display !== "none"; });
      vis.sort(function(a,b){
        var aDonemTxt = (a.cells[idx.donem] ? a.cells[idx.donem].innerText : "");
        var bDonemTxt = (b.cells[idx.donem] ? b.cells[idx.donem].innerText : "");
        var aYM = __parseYearMonth_kb(aDonemTxt);
        var bYM = __parseYearMonth_kb(bDonemTxt);

        var aVergi = (a.cells[idx.vergi] ? a.cells[idx.vergi].innerText : "").trim();
        var bVergi = (b.cells[idx.vergi] ? b.cells[idx.vergi].innerText : "").trim();
        var aIdx = __VERGI_SIRA__.indexOf(aVergi);
        var bIdx = __VERGI_SIRA__.indexOf(bVergi);
        if (aIdx !== -1 && bIdx !== -1 && aIdx !== bIdx) return aIdx - bIdx;

        // dönem sırası (kod + 0003 modu)
        var aMon = __monthOrderFor(aVergi, aYM.m, aDonemTxt);
        var bMon = __monthOrderFor(bVergi, bYM.m, bDonemTxt);
        if (aMon !== bMon) return aMon - bMon;

        var aTS = __tsKey(a.cells[idx.ts] ? a.cells[idx.ts].innerText : "");
        var bTS = __tsKey(b.cells[idx.ts] ? b.cells[idx.ts].innerText : "");
        return aTS.localeCompare(bTS);
      });

      vis.forEach(function(r){ tbody.appendChild(r); });
    }
  });
}

// === TS Fiş No tarih filtresi ===
// 1) Başta 8 hane (YYYYMMDD) varsa onu al;
// 2) değilse YYYY-MM-DD / YYYY.MM.DD / YYYY/MM/DD;
// 3) değilse DD.MM.YYYY / DD/MM/YYYY gibi biçimleri dene.
function parseDateFromFis(fisText){
  if (!fisText) return NaN;
  var t = String(fisText);

  var m1 = t.match(/(^|\D)(\d{8})(\D|$)/); // 8 haneli blok
  if (m1){
    var s = m1[2];
    var y = parseInt(s.substr(0,4),10), mo = parseInt(s.substr(4,2),10)-1, d = parseInt(s.substr(6,2),10);
    var dt = new Date(y, mo, d);
    if (!isNaN(dt)) return dt;
  }
  var m2 = t.match(/(\d{4})[-\/\.](\d{2})[-\/\.](\d{2})/); // 2023-05-22 vb.
  if (m2){
    var dt2 = new Date(parseInt(m2[1],10), parseInt(m2[2],10)-1, parseInt(m2[3],10));
    if (!isNaN(dt2)) return dt2;
  }
  var m3 = t.match(/(\d{2})[\/\.](\d{2})[\/\.](\d{4})/); // 22.05.2023 vb.
  if (m3){
    var dt3 = new Date(parseInt(m3[3],10), parseInt(m3[2],10)-1, parseInt(m3[1],10));
    if (!isNaN(dt3)) return dt3;
  }
  return NaN;
}

function filterByFisNoDate(){
  var basVal = document.getElementById('fisBas').value;
  var bitVal = document.getElementById('fisBit').value;
  if (!basVal || !bitVal){
    alert("Lütfen başlangıç ve bitiş tarihlerini seçiniz.");
    return;
  }
  var bas = new Date(basVal);
  var bit = new Date(bitVal);
  bit.setHours(23,59,59,999); // bitiş gününü kapsasın

  withTable(function(table){
    var rows = Array.from(table.rows).slice(2);
    rows.forEach(function(row){
      var fisText = row.cells[2].innerText;  // TS Fiş No sütunu: 3. sütun (0-based: 2)
      var dt = parseDateFromFis(fisText);
      if (isNaN(dt)) {
        row.style.display = "none";
      } else {
        row.style.display = (dt >= bas && dt <= bit) ? "" : "none";
      }
    });
    // Filtre sonrası mevcut sıralamayı da uygula
    customSortByYearAndVergiKodu();
  });
}

function clearFisNoDateFilter(){
  document.getElementById('fisBas').value = "";
  document.getElementById('fisBit').value = "";
  withTable(function(table){
    var rows = Array.from(table.rows).slice(2);
    rows.forEach(function(row){ row.style.display = ""; });
    customSortByYearAndVergiKodu();
  });
}

// İlk yüklemede 0003 modu etiketi
document.addEventListener('DOMContentLoaded', function(){
  set0003Mode(__KOD0003_MODE__);
});
// Print hook for myTable11 yazdırma kontrolü
(function(){
  var before = function(){
    var cb = document.getElementById('excludeMyTable11FromPrint');
    var t  = document.getElementById('myTable11');
    if(cb && t){ t.__prevDisplay = t.style.display; if(cb.checked) t.style.display='none'; }
  };
  var after = function(){
    var t = document.getElementById('myTable11');
    if(t && typeof t.__prevDisplay !== 'undefined'){ t.style.display = t.__prevDisplay || ''; }
  };
  if(window.matchMedia){
    window.matchMedia('print').addListener(function(m){ m.matches ? before() : after(); });
  }
  window.onbeforeprint = before;
  window.onafterprint  = after;
})();
