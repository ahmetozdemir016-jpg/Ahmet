(() => {
  'use strict';

  if (window.__TAKDIRE_SEVK2_INJECTOR__) return;
  window.__TAKDIRE_SEVK2_INJECTOR__ = true;

  function chooseResource() {
    const url = new URL(location.href);
    const path = decodeURIComponent(url.pathname.replace(/^\/+/, ''));

    if (url.searchParams.get('takdir') === '1' || /takdir-sevk2/i.test(location.hash) || /takdire-sevk2\.html$/i.test(path)) {
      return 'takdire-sevk2.html';
    }

    // Relative popup pages such as diger/kdv_beyanlari_bs_pos.html?... are kept on keys.ggm.bim
    // and this loader replaces the server 404/blank response with the bundled local HTML.
    if (/^diger\/[a-z0-9_\-\.]+\.html$/i.test(path)) {
      return path;
    }

    return '';
  }

  const resource = chooseResource();
  if (!resource) return;

  function extensionUrl(path) {
    return chrome.runtime.getURL(path.replace(/^\/+/, ''));
  }

  function isRelativeAsset(value) {
    return !!value && !/^(?:[a-z]+:)?\/\//i.test(value) && !/^(?:data:|blob:|mailto:|#)/i.test(value);
  }

  function rewriteAsset(el, attr) {
    const value = el.getAttribute(attr);
    if (isRelativeAsset(value)) el.setAttribute(attr, extensionUrl(value));
  }

  function clear(node) {
    while (node && node.firstChild) node.removeChild(node.firstChild);
  }

  function runScript(item) {
    return new Promise(resolve => {
      const s = document.createElement('script');
      if (item.type) s.type = item.type;
      if (item.src) {
        s.src = isRelativeAsset(item.src) ? extensionUrl(item.src) : item.src;
        s.onload = () => resolve();
        s.onerror = () => resolve();
      } else {
        s.textContent = item.text || '';
        resolve();
      }
      (document.head || document.documentElement).appendChild(s);
      if (!item.src) setTimeout(resolve, 0);
    });
  }

  async function inject() {
    try {
      const response = await fetch(extensionUrl(resource), { cache: 'no-store' });
      const html = await response.text();
      const parsed = new DOMParser().parseFromString(html, 'text/html');

      const scripts = Array.from(parsed.querySelectorAll('script')).map(script => {
        const item = {
          src: script.getAttribute('src') || '',
          text: script.textContent || '',
          type: script.getAttribute('type') || ''
        };
        script.remove();
        return item;
      });

      if (!document.head) document.documentElement.appendChild(document.createElement('head'));
      if (!document.body) document.documentElement.appendChild(document.createElement('body'));

      clear(document.head);
      clear(document.body);

      // Keep a same-origin page URL, but load static assets from the extension package.
      Array.from(parsed.head.children).forEach(node => {
        if (node.tagName && node.tagName.toLowerCase() === 'script') return;
        const clone = node.cloneNode(true);
        if (clone.tagName) {
          const tag = clone.tagName.toLowerCase();
          if (tag === 'link') rewriteAsset(clone, 'href');
          if (tag === 'img') rewriteAsset(clone, 'src');
        }
        document.head.appendChild(clone);
      });

      document.body.innerHTML = parsed.body.innerHTML;
      Array.from(document.body.querySelectorAll('[src]')).forEach(el => rewriteAsset(el, 'src'));
      Array.from(document.body.querySelectorAll('[href]')).forEach(el => rewriteAsset(el, 'href'));

      document.documentElement.setAttribute('data-takdir-sevk2-loaded', resource);

      for (const item of scripts) {
        await runScript(item);
      }
    } catch (err) {
      console.error('[TakdireSevk2] Sayfa yüklenemedi:', err);
      document.body.innerHTML = '<pre style="padding:20px;color:#b00020;font:14px Arial">Takdire Sevk 2 yüklenemedi: ' + String(err && err.message || err) + '</pre>';
    }
  }

  inject();
})();
