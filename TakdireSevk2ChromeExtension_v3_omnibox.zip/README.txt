Takdire Sevk 2 Bot - Chrome Eklentisi v1.0.2

Kurulum:
1) Zip'i çıkarın.
2) Chrome adres çubuğuna chrome://extensions yazın.
3) Sağ üstten Geliştirici modu'nu açın.
4) Eski Takdire Sevk 2 Bot eklentisini kaldırın.
5) Paketlenmemiş öğe yükle deyip bu klasörü seçin.

Kullanım:
- Adres çubuğuna takdir yazın.
- Chrome eklenti arama moduna geçmek için takdir yazdıktan sonra Space veya Tab gerekebilir.
- Ardından Enter'a basınca http://keys.ggm.bim/?takdir=1#takdir-sevk2 açılır ve Takdire Sevk 2 ekranı bu sayfanın içinde yüklenir.
- Eklenti simgesine tıklayarak da aynı ekran açılabilir.

Bu sürümdeki değişiklikler:
- Yeni sekme/boş sayfa değiştirme kaldırıldı.
- Omnibox keyword eklendi: takdir.
- Sayfa artık chrome-extension:// adresinde değil, keys.ggm.bim sayfası içinde çalışır. Böylece gibintranet_server/dispatch istekleri aynı origin üzerinden gider.
- Servis JSON yerine HTML hata cevabı döndürürse SyntaxError ile kırılmak yerine ekranda anlaşılır hata gösterir.
