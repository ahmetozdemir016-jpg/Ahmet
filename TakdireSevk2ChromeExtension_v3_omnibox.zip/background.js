'use strict';

const TAKDIR_URL = 'http://keys.ggm.bim/?takdir=1#takdir-sevk2';

function openTakdir(disposition) {
  if (disposition === 'newForegroundTab') {
    chrome.tabs.create({ url: TAKDIR_URL, active: true });
    return;
  }
  if (disposition === 'newBackgroundTab') {
    chrome.tabs.create({ url: TAKDIR_URL, active: false });
    return;
  }
  chrome.tabs.update({ url: TAKDIR_URL }, () => {
    if (chrome.runtime.lastError) {
      chrome.tabs.create({ url: TAKDIR_URL, active: true });
    }
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.omnibox.setDefaultSuggestion({
    description: 'Takdire Sevk 2 ekranını aç'
  });
});

chrome.omnibox.onInputStarted.addListener(() => {
  chrome.omnibox.setDefaultSuggestion({
    description: 'Takdire Sevk 2 ekranını açmak için Enter'
  });
});

chrome.omnibox.onInputEntered.addListener((text, disposition) => {
  openTakdir(disposition);
});

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: TAKDIR_URL, active: true });
});
