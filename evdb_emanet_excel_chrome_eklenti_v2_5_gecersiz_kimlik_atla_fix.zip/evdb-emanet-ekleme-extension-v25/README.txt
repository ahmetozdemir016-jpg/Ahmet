EVDB Emanet Excel Bot v2.5

Referans çalışan sürüm: v1.8.

Düzeltmeler / ekler:
- v1.8/v2.1 çalışan akış korunmuştur.
- Vergi No ve T.C. No ikisi de boş olan satırlar hata sayılmadan atlanır.
- EVDB'de "Mükellef Bulunamadı" uyarısı gelirse bot Tamam'a basar, kaydı "Vergi No hatalı" veya "T.C. No hatalı" olarak atlar ve sonraki kayda geçer.
- Atlanan boş kimlik ve hatalı kimlik kayıtlarının sayısı ile Fiş No listeleri panelde/logda görünür.
- Başarılı eklenen kayıtlar hafızaya alınır. Aynı Excel tekrar okunup Başlat dendiğinde başarılı satırlar atlanır, kaldığı yerden devam eder.
- 2. ve sonraki satırlarda üstteki "Emanet Bilgilerini Temizle" kullanılır; alttaki genel "Temizle" kullanılmaz.
- Vergi Kimlik No alanına ekstra tıklama yoktur.

Kurulum:
1) Chrome uzantılarından eski sürümü kaldırın.
2) Paketlenmemiş öğe yükle ile evdb-emanet-ekleme-extension-v25 klasörünü seçin.
3) EVDB ekranını yenileyin.
4) Eklenti ikonuna basarak paneli açın.

Kullanım notu:
Bir hata olduğunda Durdur / sayfayı yenile / Excel'i tekrar Dosyayı Oku / Başlat yaparsanız, "Başarılı kayıtları hatırla" seçili olduğu sürece daha önce eklenen kayıtlar atlanır.


v2.3: Emanete eklemek istenen tutar/kayıt zaten emanet tablosunda varsa gelen uyarıda Tamam denir; kayıt "Emanette mevcut / tekrar kayıt" olarak atlanır ve Fiş No log/panelde listelenir.


v2.4: İşlem Yönü Çıkış/Aktarım olan satırlar banka çıkışı kabul edilir; emanet girişine işlenmez. Bu satırlar atlanan kayıt olarak sayılır ve Fiş No listesi panel/log ekranında gösterilir.


v2.5: EVDB tarafından gösterilen "Girilen vergi kimlik numarası geçerli değil" / "T.C. kimlik numarası geçerli değil" uyarılarında Tamam butonuna basılır; kayıt hatalı kimlik olarak Fiş No ile loglanır ve otomasyon sonraki kayıttan devam eder.
