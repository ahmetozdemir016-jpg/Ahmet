v4.31.11 No Embed Panel Switch

Sorun:
- EYS'i ana panel içine gömme/sekme taşıma kodu ana modül içeriğini bozuyordu.
- Ekranda siyah boş alan ve çift scroll oluşuyordu.

Çözüm:
- EYS gömme/taşıma mantığı kapatıldı.
- Ana panel kendi HTML düzenini korur.
- EYS paneli ayrı panel olarak kalır fakat ilk açılışta gizlidir.
- Ana panel üstündeki EYS butonuna basınca ana panel gizlenir, EYS paneli görünür.
- EYS panelindeki ANA butonuna basınca EYS gizlenir, ana panel görünür.

Korunanlar:
- v4.31.2 tabanındaki sağlam ana panel yapısı
- EYS modülü içerikleri
- Bugün butonu düzeltmesi
- CFG düzeltmesi
