(function(){
  'use strict';
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function pick(o,keys,def){for(var i=0;i<keys.length;i++){var v=o&&o[keys[i]];if(v!==undefined&&v!==null&&String(v).trim()!=='')return v;}return def==null?'':def;}
  function onlyDate(v){var raw=String(v==null?'':v).trim();var m=raw.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);if(m)return ('0'+m[1]).slice(-2)+'/'+('0'+m[2]).slice(-2)+'/'+m[3];var s=raw.replace(/\D/g,'');if(s.length>=8&&/^(19|20)/.test(s))return s.slice(6,8)+'/'+s.slice(4,6)+'/'+s.slice(0,4);return raw||'—';}
  function period(v){var s=String(v==null?'':v).replace(/\D/g,'');if(s.length===6)return s.slice(4,6)+'/'+s.slice(0,4);if(s.length===8)return s.slice(4,6)+'/'+s.slice(0,4);return v||'—';}
  function tok(){try{return (typeof window.token==='function'&&window.token())||(typeof window._tok==='function'&&window._tok())||localStorage.getItem('gib_token_keys')||localStorage.getItem('keysToken')||'';}catch(e){return '';}}
  function mapVal(v,map){var k=String(v==null?'':v);return map[k]||v||'—';}
  var maps={
    cinsiyet:{'1':'KADIN','2':'ERKEK'},
    uyruk:{'1':'T.C.','2':'YABANCI'},
    isyeri:{'1':'1 - Merkez','2':'2 - Şube','3':'3 - Depo','4':'4 - KDV İhtisas Şubesi'},
    nitelik:{'1':'1 - Merkez','2':'2 - Şube','3':'3 - Depo','4':'4 - KDV İhtisas Şubesi'},
    gelir:{'0001':'1 - Ticari Kazanç','0011':'2 - Zirai Kazanç','0021':'3 - Serbest Meslek Kazancı','0031':'4 - Ücret','0041':'5 - Gayrimenkul Sermaye İradı','0051':'6 - Menkul Sermaye İradı','0061':'7 - Diğer Kazanç ve İratlar'}
  };
  function ensureModal(){
    var d=document.getElementById('tk179_sicil_modal');
    if(d)return d;
    d=document.createElement('div');d.id='tk179_sicil_modal';
    d.style.cssText='display:none;position:fixed;z-index:2147483647;inset:10px;background:#f4f4f4;border:2px solid #255d3c;box-shadow:0 0 0 9999px rgba(0,0,0,.38);font:12px Arial;overflow:auto';
    d.innerHTML='<div style="position:sticky;top:0;z-index:10;background:#176b43;color:#fff;padding:8px 12px;font-weight:bold">Mükellef / Sicil Detayı <button id="tk179_sicil_close" style="float:right;background:#b73b35;color:#fff;border:0;padding:4px 12px;cursor:pointer">Kapat</button></div><div id="tk179_sicil_body" style="padding:10px"></div>';
    document.body.appendChild(d);document.getElementById('tk179_sicil_close').onclick=function(){d.style.display='none';};return d;
  }
  function section(title,content){return '<section style="border:1px solid #9ab5a5;background:#fff;margin:7px 0"><div style="background:#176b43;color:#fff;font-weight:bold;padding:6px 9px">'+esc(title)+'</div>'+content+'</section>';}
  function kvGrid(left,right){
    function side(rows){var h='<table style="width:100%;border-collapse:collapse">';rows.forEach(function(r){h+='<tr><th style="width:175px;text-align:left;padding:5px 7px;border-bottom:1px solid #e5e5e5;color:#333">'+esc(r[0])+'</th><td style="padding:5px 7px;border-bottom:1px solid #e5e5e5">'+esc(r[1]||'—')+'</td></tr>';});return h+'</table>';}
    return '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;padding:8px">'+side(left)+side(right)+'</div>';
  }
  function table(headers,rows){var h='<div style="overflow:auto;padding:7px"><table style="width:100%;border-collapse:collapse"><thead><tr>';headers.forEach(function(x){h+='<th style="background:#e9eceb;border:1px solid #aebbb4;padding:5px;white-space:nowrap">'+esc(x)+'</th>';});h+='</tr></thead><tbody>';if(!rows.length)h+='<tr><td colspan="'+headers.length+'" style="border:1px solid #ccc;padding:7px">Kayıt bulunamadı.</td></tr>';rows.forEach(function(r){h+='<tr>';r.forEach(function(v){h+='<td style="border:1px solid #c9d0cc;padding:5px;vertical-align:top">'+esc(v==null?'':v)+'</td>';});h+='</tr>';});return h+'</tbody></table></div>';}
  function addressCard(title,a){if(!a)return '<div style="border:1px solid #aebbb4"><div style="background:#eef2f0;font-weight:bold;padding:6px">'+esc(title)+'</div><div style="padding:8px">Kayıt bulunamadı.</div></div>';var rows=[['ADRES NO',pick(a,['adresno'])],['MAHALLE - SEMT',pick(a,['mahallesemt'])],['CADDE / SOKAK',pick(a,['caddesokak'])],['DIŞ KAPI NO',pick(a,['diskapino'])],['İÇ KAPI NO',pick(a,['ickapino'])],['İL',(pick(a,['ilkodu'])?pick(a,['ilkodu'])+' - ':'')+pick(a,['iladi'])],['İLÇE',(pick(a,['ilcekodu'])?pick(a,['ilcekodu'])+' - ':'')+pick(a,['ilceadi'])],['BELDE / BUCAK',pick(a,['beldebucak'])],['KÖY',pick(a,['koy'])]];var h='<table style="width:100%;border-collapse:collapse">';rows.forEach(function(r){h+='<tr><th style="width:145px;text-align:left;padding:5px 7px;border-bottom:1px solid #e5e5e5">'+esc(r[0])+'</th><td style="padding:5px 7px;border-bottom:1px solid #e5e5e5">'+esc(r[1]||'—')+'</td></tr>';});return '<div style="border:1px solid #aebbb4"><div style="background:#eef2f0;font-weight:bold;padding:6px">'+esc(title)+'</div>'+h+'</table></div>';}
  function render(resp,row,vkn){
    var d=resp&&resp.data||{}, m=d.mukellefBilgi||{}, kim=d||{}, taxes=m.mukellefiyet||[], acts=m.faaliyet||((d.faaliyetListesi||{}).faaliyet)||[], addrs=m.adresbilgi||[], gel=((d.gelirUnsur||{}).gelirunsurlari)||[], sor=d.sorumlu||[], huk=d.hukukiDurum||{};
    var left=[['VERGİ NO',pick(d,['vergino'],vkn)],['T.C. KİMLİK NO',pick(d,['tckimlikno','tckn'])],['ADI',pick(d,['ad'])],['SOYADI',pick(d,['soyad'])],['BABA ADI',pick(d,['babaadi'])],['ANA ADI',pick(d,['anaadi'])],['DOĞUM TARİHİ',onlyDate(pick(d,['dogumtarihi','dogumtarihiformatli']))],['DOĞUM YERİ',pick(d,['dogumyeritext','dogumyeri'])],['CİNSİYET',mapVal(pick(d,['cinsiyet']),maps.cinsiyet)],['İŞE BAŞLAMA TARİHİ',onlyDate(pick(m,['isebaslamatarihi','birimbastar'],pick(d,['isebaslamatarihi'])))],['İŞİ BIRAKMA TARİHİ',onlyDate(pick(m,['isibirakmatarihi'],pick(d,['isibirakmatarihi'])))],['TEL NO',pick(d,['telefon','telno'])],['BAŞLAYAN HUKUKİ DURUM',pick(huk,['baslayanHukukiDurum','baslangicDurum'])],['BİTEN HUKUKİ DURUM',pick(huk,['bitenHukukiDurum','bitisDurum'])]];
    var right=[['VERGİ DAİRESİ',(pick(row,['vdkodu'],pick(d,['vdkodu']))||'')+' - '+(pick(row,['vdadi'],pick(d,['vdadi']))||'')],['MÜKELLEF TÜRÜ',(pick(d,['sirketturu'])?pick(d,['sirketturu'])+' - ':'')+pick(d,['sirketturuad'])],['İŞ YERİ TÜRÜ',mapVal(pick(m,['isyerituru'],pick(d,['isyerituru'])),maps.isyeri)],['İŞ YERİ NİTELİĞİ',mapVal(pick(m,['isyerinitelik'],pick(d,['isyerinitelik'])),maps.nitelik)],['ŞUBE NO',pick(m,['subeno'],pick(d,['subeno']))],['ŞUBE ADI',pick(m,['subeadi'],pick(d,['subeadi']))],['UYRUĞU',mapVal(pick(d,['uyruk']),maps.uyruk)],['ÜLKE',String(pick(d,['ulkekodu']))==='052'?'TÜRKİYE':pick(d,['ulkekodu'])],['TABELA ÜNVANI',pick(m,['tblunvani'])],['HUKUKİ DURUM BAŞLAMA TARİHİ',onlyDate(pick(huk,['baslamaTarihi','baslangicTarihi']))],['HUKUKİ DURUM BİTİŞ TARİHİ',onlyDate(pick(huk,['bitisTarihi']))]];
    var taxRows=taxes.map(function(x){return [pick(x,['vergikodutext'])||pick(x,['vergikodu']),pick(x,['basdonemkodutext']),onlyDate(pick(x,['bastar'])),pick(x,['basdonem'])||period(pick(x,['donbastar'])),onlyDate(pick(x,['bittar'])),pick(x,['bitdonem'])||period(pick(x,['donbittar'])),pick(x,['bitislemturutext']),String(pick(x,['muafbilgisi']))==='1'?'Var':'—'];});
    var gelRows=gel.map(function(x){return [maps.gelir[pick(x,['vergikodu'])]||pick(x,['vergikodu']),String(pick(x,['durum']))==='1'?'Faal':'Terk',onlyDate(pick(x,['bastar'])),onlyDate(pick(x,['bittar']))];});
    var sorRows=sor.map(function(x){return [pick(x,['vergino']),pick(x,['tckimlikno','tckn']),pick(x,['unvan','adsoyad']),pick(x,['sorumluturu']),onlyDate(pick(x,['baslangictarihi','bastar'])),onlyDate(pick(x,['bitistarihi','bittar']))];});
    var actRows=acts.map(function(x){return [mapVal(pick(x,['merkezsube']),{'1':'MERKEZ','2':'ŞUBE'}),pick(x,['sira']),onlyDate(pick(x,['bastar'])),onlyDate(pick(x,['bittar'])),pick(x,['faaliyetkod'])+' - '+pick(x,['faaliyetad'])];});
    var yer=null,is=null;addrs.forEach(function(a){if(String(a.adrestip)==='1')yer=a;else if(String(a.adrestip)==='2')is=a;});
    var html='<div style="background:#fff;border:1px solid #aebbb4;padding:7px;margin-bottom:7px"><b>VERGİ KİMLİK NO:</b> '+esc(vkn)+' &nbsp; <b>VERGİ DAİRESİ:</b> '+esc((pick(row,['vdkodu'])||'')+' - '+(pick(row,['vdadi'])||''))+'</div>';
    html+=section('Kimlik / Mükellef Bilgileri',kvGrid(left,right));
    html+=section('Vergi Bilgileri',table(['VERGİ KODU','DÖNEM','BAŞLAMA TARİHİ','BAŞLAMA DÖNEMİ','BIRAKMA TARİHİ','BIRAKMA DÖNEMİ','TERK NEDENİ','İSTİSNA / MUAFİYET'],taxRows));
    html+=section('Gelir Unsuru Bilgileri',table(['GELİR UNSURU','FAAL / TERK','BAŞLAMA TARİHİ','BİTİŞ TARİHİ'],gelRows));
    html+=section('Sorumlu Bilgileri',table(['VERGİ NO','T.C. KİMLİK NO','ÜNVAN','SORUMLU TÜRÜ','BAŞLANGIÇ TARİHİ','BİTİŞ TARİHİ'],sorRows));
    html+=section('Adres Bilgileri','<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:8px">'+addressCard('YERLEŞİM YERİ ADRESİ (MERNİS)',yer)+addressCard('İŞYERİ ADRESİ',is)+'</div>');
    html+=section('Faaliyet Bilgileri',table(['İŞ YERİ TÜRÜ','SIRA NO','BAŞLAMA TARİHİ','BİTİŞ TARİHİ','FAALİYET KODU - ADI'],actRows));
    html+='<details style="background:#fff;border:1px solid #aebbb4;padding:7px;margin-top:8px"><summary>Ham detay cevabı (hata kontrolü için)</summary><pre style="white-space:pre-wrap;font-size:11px">'+esc(JSON.stringify(resp,null,2))+'</pre></details>';
    return html;
  }
  window.__tkMukVdDetayAc=function(idx){
    var row=(window.__tkMukVdRows||[])[idx];if(!row){alert('Seçilen mükellefiyet kaydı bulunamadı.');return false;}
    var modal=ensureModal(),body=document.getElementById('tk179_sicil_body');modal.style.display='block';body.innerHTML='<div style="padding:15px">Sicil detayı sorgulanıyor...</div>';
    var vkn=String(window.__tkMukVkn||(document.querySelector('#input')||{}).value||'').trim();
    var jp={vkn:vkn,vdkodu:String(row.vdkodu||''),birimOid:String(row.birimoid||row.birimOid||''),subeno:String(row.subeno||''),subeadi:String(row.subeadi||''),isyerituru:String(row.isyerituru||''),isyerinitelik:String(row.isyerinitelik||''),mukblgoid:String(row.mukblgoid||'')};
    try{var url='http://10.251.63.99/gibintranet_server/dispatch?cmd=sicilService_mukSicilDetayBilgileriGetir&callid=tk179'+Date.now()+'&token='+encodeURIComponent(tok())+'&jp='+encodeURIComponent(JSON.stringify(jp));var raw=getRemote(url),resp=typeof raw==='string'?JSON.parse(raw):raw;body.innerHTML=render(resp,row,vkn);}catch(e){body.innerHTML='<div style="background:#fee;color:#a00;padding:12px">Sicil detayı alınamadı: '+esc(e&&e.message||e)+'</div>';}
    return false;
  };
})();
