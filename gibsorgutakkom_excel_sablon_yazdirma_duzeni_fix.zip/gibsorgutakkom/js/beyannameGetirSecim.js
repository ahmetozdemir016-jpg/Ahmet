(function(){
  'use strict';

  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function cleanId(v){return String(v||'').replace(/\D/g,'');}
  function getToken(){
    try{if(typeof window._tok==='function'){var t=window._tok();if(t)return String(t);}}catch(e){}
    try{if(typeof window.token==='function'){var t2=window.token();if(t2)return String(t2);}}catch(e){}
    try{
      var el=document.getElementById('token');var txt=el?String(el.value||''):'';
      var m=/token=([^&\s]+)/.exec(txt);if(m&&m[1])return m[1];
    }catch(e){}
    try{return localStorage.getItem('gib_token_gibintranet')||localStorage.getItem('takkom_gibintranet_token')||localStorage.getItem('gibIntranetToken')||localStorage.getItem('gibToken')||'';}catch(e){return '';}
  }
  function getRemoteObj(cmd,jp,token,suffix){
    if(typeof window.getRemote!=='function')throw new Error('getRemote fonksiyonu bulunamadı.');
    var url='http://10.251.63.99/gibintranet_server/dispatch?cmd='+encodeURIComponent(cmd)+'&callid=bynSec'+Date.now()+(suffix||'')+'&token='+encodeURIComponent(token)+'&jp='+encodeURIComponent(JSON.stringify(jp));
    var raw=window.getRemote(url);return typeof raw==='string'?JSON.parse(raw):raw;
  }
  function taxpayers(main,token){
    var out=[{vkn:main,label:'Ana mükellef - '+main,type:'main'}];
    try{
      var r=getRemoteObj('sicilService_mukunAdiOrtaklikBilgileriniGetir',{vkn:main,basTar:'',bitTar:''},token,'1');
      var ps=((((r||{}).data||{}).ortakliklar||{}).adiortak)||[];
      if(!Array.isArray(ps))ps=[ps];
      ps.forEach(function(x){
        var v=cleanId(x.vergino||x.ortvergino||'');if(!v)return;
        for(var i=0;i<out.length;i++)if(out[i].vkn===v)return;
        out.push({vkn:v,label:'Adi ortaklık - '+v+(x.unvan||x.adsoyad?' - '+String(x.unvan||x.adsoyad):''),type:'partnership'});
      });
    }catch(e){}
    return out;
  }
  function taxOffices(vkn,token){
    var out=[];
    try{
      var r=getRemoteObj('sicilService_sicilBilgileriSorgulaIlKodu',{vkn:vkn,tckn:'',vdKodu:'',ilKodu:''},token,'2');
      var list=((((r||{}).data||{}).vdler||{}).baglivd)||[];
      if(!Array.isArray(list))list=[list];
      list.forEach(function(x){
        var code=cleanId(x.vdkodu||x.vdKodu||x.vergiDairesiKodu||'');
        if(!code)return;
        var name=String(x.vdadi||x.vdAdi||x.vergiDairesiAdi||x.birimadi||'').trim();
        for(var i=0;i<out.length;i++)if(out[i].code===code)return;
        out.push({code:code,name:name,label:code+(name?' - '+name:'')});
      });
    }catch(e){}
    if(!out.length){
      try{
        var d=cleanId(typeof window.vdKodu==='function'?window.vdKodu():'');
        if(d)out.push({code:d,name:'',label:d});
      }catch(e){}
    }
    return out;
  }
  function ensureModal(){
    var old=document.getElementById('tkBeyannameModal');if(old)return old;
    var wrap=document.createElement('div');wrap.id='tkBeyannameModal';
    wrap.style.cssText='display:none;position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,.55);align-items:center;justify-content:center;padding:15px;box-sizing:border-box;';
    wrap.innerHTML='<div style="width:min(620px,96vw);background:#fff;border-radius:7px;box-shadow:0 8px 30px rgba(0,0,0,.4);font:14px Arial;overflow:hidden">'+
      '<div style="background:#176b43;color:#fff;padding:12px 15px;font-size:18px;font-weight:bold">Beyanname Getir</div>'+
      '<div style="padding:15px">'+
        '<label style="display:block;font-weight:bold;margin-bottom:5px">1. Sorgulanacak mükellefi seçin</label><select id="tkBynMuk" style="width:100%;padding:8px;margin-bottom:14px"><option value="">Mükellef seçiniz</option></select>'+
        '<label style="display:block;font-weight:bold;margin-bottom:5px">2. Kayıtlı vergi dairesini seçin</label><select id="tkBynVd" disabled style="width:100%;padding:8px;margin-bottom:14px"><option value="">Önce mükellef seçiniz</option></select>'+
        '<label style="display:block;font-weight:bold;margin-bottom:5px">3. Vergi kodunu yazın</label><input id="tkBynVergiKod" value="0015" maxlength="4" inputmode="numeric" style="width:100%;padding:8px;box-sizing:border-box;margin-bottom:8px">'+
        '<div id="tkBynStatus" style="min-height:20px;color:#555;margin:4px 0 10px"></div>'+
        '<div style="display:flex;justify-content:flex-end;gap:8px"><button type="button" id="tkBynCancel" style="padding:8px 14px">Vazgeç</button><button type="button" id="tkBynOpen" style="padding:8px 14px;background:#176b43;color:#fff;border:0">Beyanname Listesini Aç</button></div>'+
      '</div></div>';
    document.body.appendChild(wrap);return wrap;
  }
  function show(main,token){
    var modal=ensureModal();
    var muk=modal.querySelector('#tkBynMuk'),vd=modal.querySelector('#tkBynVd'),kod=modal.querySelector('#tkBynVergiKod'),status=modal.querySelector('#tkBynStatus');
    muk.innerHTML='<option value="">Mükellef seçiniz</option>';
    taxpayers(main,token).forEach(function(x){var o=document.createElement('option');o.value=x.vkn;o.textContent=x.label;muk.appendChild(o);});
    vd.innerHTML='<option value="">Önce mükellef seçiniz</option>';vd.disabled=true;kod.value='0015';status.textContent='';
    modal.style.display='flex';
    muk.onchange=function(){
      var v=cleanId(muk.value);vd.innerHTML='';
      if(!v){vd.disabled=true;vd.innerHTML='<option value="">Önce mükellef seçiniz</option>';return;}
      status.textContent='Kayıtlı vergi daireleri alınıyor...';
      var list=taxOffices(v,token);vd.disabled=false;
      vd.innerHTML='<option value="">Vergi dairesi seçiniz</option>';
      list.forEach(function(x){var o=document.createElement('option');o.value=x.code;o.textContent=x.label;vd.appendChild(o);});
      status.textContent=list.length?list.length+' kayıtlı vergi dairesi bulundu.':'Kayıtlı vergi dairesi bulunamadı.';
      if(list.length===1)vd.value=list[0].code;
    };
    modal.querySelector('#tkBynCancel').onclick=function(){modal.style.display='none';};
    modal.onclick=function(e){if(e.target===modal)modal.style.display='none';};
    modal.querySelector('#tkBynOpen').onclick=function(){
      var vkn=cleanId(muk.value),vdk=cleanId(vd.value),vergiKodu=cleanId(kod.value);
      if(!vkn){alert('Önce sorgulanacak mükellefi seçiniz.');return;}
      if(!vdk){alert('Kayıtlı vergi dairesini seçiniz.');return;}
      if(!/^\d{4}$/.test(vergiKodu)){alert('Vergi kodunu 4 haneli giriniz. Örnek: 0015');return;}
      status.textContent='Beyanname listesi hazırlanıyor...';
      try{
        var r=getRemoteObj('bynIslemleriService_bynSorgula',{vkn:vkn,vdKodu:vdk,vergiKodu:vergiKodu,donemBas:'',donemBit:'',arsiv:'T'},token,'25');
        var ip=r&&r.data?r.data.kullaniciIp:'';
        if(!ip)throw new Error('Kullanıcı IP bilgisi alınamadı.');
        var openUrl='http://10.251.67.110:30080/ebyn/vdintraDispatch?SVERGINO='+encodeURIComponent(vkn)+
          '&VERGIKODU='+encodeURIComponent(vergiKodu)+'&VDKODU='+encodeURIComponent(vdk)+
          '&tD1yil=&tD2yil=&tD1ay=&tD2ay=&ARSIV=F&BFORMUCIKAR=1&KESINMIZANCIKAR=1&cmd=BEYANNAMELISTESIVDO&origin=vdintra&USERID=tcnumaran&USERIP='+encodeURIComponent(ip);
        window.open(openUrl,'_blank');modal.style.display='none';
      }catch(err){status.textContent='Hata: '+(err&&err.message?err.message:err);alert('Beyanname Getir çalışırken hata: '+(err&&err.message?err.message:err));}
    };
  }
  function bind(){
    var el=document.getElementById('go85');if(!el)return;
    try{el.onclick=null;el.removeAttribute('onclick');}catch(e){}
    var clone=el.cloneNode(true);el.parentNode.replaceChild(clone,el);
    clone.addEventListener('click',function(e){
      e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();
      var main=cleanId((document.getElementById('input')||{}).value||'');
      var token=getToken();
      if(!main){alert('VKN/TCKN giriniz.');return false;}
      if(!token){alert('Token bulunamadı.');return false;}
      show(main,token);return false;
    },true);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(bind,0);});else setTimeout(bind,0);
})();
