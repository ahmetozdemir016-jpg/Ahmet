Rapor Kayıt Defteri doğrudan rapor/tutanak eki açma düzeltmesi
- Artık önce genel 'Rapor Kayıt Defteri Evrak Önizle' ekranı açılmaz.
- Evrak OID bulunduktan sonra getEvrakBelgeListeleriMap ile Üst Yazı/Ekler alınır.
- Rapor/Tutanak No ile aynı olan ek bulunur ve doğrudan PDF önizlemesi açılır.
- Kullanıcı Listeleri Göster / Önizle adımlarını görmez.
