# v4.31.53

- Hook/XHR dinlemesi artık ilk token bulunduğunda değil, tüm modül tokenleri yakalanınca durur.
- Beklenen modül tokenleri: gp, g, istakip, evdo, e.
- Tokenler 10 saniye içinde tamamlanmazsa önceki güvenlik davranışı korunur ve hook otomatik durur.
- Panel kapatma/taşıma/boyutlandırma düzeltmeleri korunmuştur.
