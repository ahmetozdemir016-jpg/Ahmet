# v4.31.48 HAR seçim-sorgu akışı notları

Bu sürümde Filtreli İşlem ve Günlük PDF sorgusunda iki mod var:

- Birebir EYS sorgu modu: seçilen seçenekler aynen `srvcYoklama_getYoklamalar` payload içine yazılır. Sonuç boşsa otomatik olarak Hepsi sorgusuna düşmez.
- v4.31.50: Filtreli İşlem ve Günlük PDF ekranlarından HAR yedek tiki kaldırıldı; seçilen seçenekler birebir servise gönderilir.

HAR'da görülen temel eşleşmeler:

| EYS alanı | Payload alanı | Örnek değer | Not |
|---|---:|---:|---|
| Veri Kaynağı: Kullanılan veriler | `sorgukaynak` | `0` | Normal kullanılan veri |
| Veri Kaynağı: Sadece arşiv verileri | `sorgukaynak` | `1` | Sadece arşiv |
| Veri Kaynağı: Arşiv dahil bütün veriler | `sorgukaynak` | `2` | Günlük PDF için en geniş çalışan akış |
| Görev Yeri: Hepsi | `icdis` | `0` | HAR'da 20 kayıt döndüren çalışan akış |
| Görev Yeri: Sadece Yetki Alanı | `icdis` | `1` | Kaynak/hedef il-VD boş gider |
| Görev Yeri: Kaynak/Gelen Dış | `icdis` | `2` | İl/VD seçilirse `disil`/`disvd` dolar |
| Görev Yeri: Hedef/Giden Dış | `icdis` | `3` | İl/VD seçilirse `disil`/`disvd` dolar |
| Görev Yeri: Yetki Alanı + Gelen | `icdis` | `4` | Kaynak/hedef il-VD boş gider |
| Yoklama Durumu: Yoklama sonuçlandı | `ydurum` | `60` | Günlük PDF varsayılanı |
| İşlem Durumu: Hepsi | `sonucislem` | `0` | Günlük PDF varsayılanı |
| Yoklama kodu ile arama | `ykodu` | `2026...` | Bu varsa diğer filtreler gönderilmez |
| Benzersiz kod ile arama | `hashcode`, `belgekoorno` | `S170...`, `DKOOR-016-01` | Bu varsa diğer filtreler gönderilmez |

Çalışan günlük HAR payload özeti:

```json
{"sorgukaynak":"2","icdis":"0","disil":"","disvd":"","ydurum":"60","sonucislem":"0","servis":"91","bastar":"YYYYMMDD","bittar":"YYYYMMDD"}
```



## v4.31.49 CSP düzeltmesi
- Inline `<script>` enjeksiyonu kaldırıldı.
- `page_hook.js` manifest üzerinden `world: MAIN` content script olarak çalışır.
- EYS oturum bilgisi `ISTAKIP_EYS_PAGE_SESSION` ve `__ISTAKIP_BOT_V4_DISCOVERY__` mesajlarından alınır.
