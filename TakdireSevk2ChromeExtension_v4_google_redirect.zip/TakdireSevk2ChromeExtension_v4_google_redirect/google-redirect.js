(() => {
  'use strict';
  const TAKDIR_URL = 'http://keys.ggm.bim/?takdir=1#takdir-sevk2';

  function getQuery() {
    try {
      const u = new URL(location.href);
      const q = (u.searchParams.get('q') || u.searchParams.get('query') || '').trim().toLocaleLowerCase('tr-TR');
      return q;
    } catch (e) {
      return '';
    }
  }

  function shouldRedirect() {
    const q = getQuery();
    return q === 'takdir' || q === 'takdire sevk' || q === 'takdir sevk';
  }

  if (shouldRedirect()) {
    location.replace(TAKDIR_URL);
  }
})();
