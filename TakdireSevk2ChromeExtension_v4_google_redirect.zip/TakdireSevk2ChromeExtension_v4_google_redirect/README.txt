Takdire Sevk 2 Bot - Chrome Eklentisi v1.0.3

Kurulum:
1) Zip'i çıkarın.
2) Chrome adres çubuğuna chrome://extensions yazın.
3) Sağ üstten Geliştirici modu'nu açın.
4) Eski Takdire Sevk 2 Bot eklentisini kaldırın.
5) Paketlenmemiş öğe yükle deyip bu klasörü seçin.

Kullanım:
- Adres çubuğuna doğrudan takdir yazıp Enter'a basın.
- Chrome önce Google araması başlatırsa, bu sürüm Google'daki q=takdir aramasını otomatik yakalayıp http://keys.ggm.bim/?takdir=1#takdir-sevk2 adresine çevirir.
- Alternatif kullanım: adres çubuğuna takdir yazıp Space/Tab basın, sonra Enter'a basın. Bu Chrome'un resmi omnibox kısayol modudur.
- Eklenti simgesine tıklayınca da aynı ekran açılır.

Notlar:
- Chrome eklentileri tek kelimelik adres satırı girişini doğrudan sahiplenemez; bu yüzden v1.0.3 Google aramasına düşen "takdir" sorgusunu yakalayan ek yönlendirme içerir.
- Servis JSON yerine HTML hata sayfası döndürürse, sorgu ekranında uyarı gösterilir. Bu genelde kurum içi servis/oturum/endpoint kaynaklıdır.
