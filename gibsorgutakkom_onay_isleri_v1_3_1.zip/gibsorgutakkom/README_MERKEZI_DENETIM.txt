MERKEZİ DENETİM RAPORLARI (diger/merkezi-denetim.html) – v1.0 (13.10.2026)
Ana ekran: "Diğer Sorgulamalar" › Merkezi Denetim Raporları (go99). gibintranet tokeni ile açılır.
Kaynak: GİBİNTRANET › YBS › VD Ön Kontrol › Denetim Raporları (gibintranet.gelirler.gov.tr:32505 authgateway/svcevdb/vdOnKontrol/).
  - vdOnKontrolSorgulamaLoad: VD listesi, işlem grupları (01–12), işlem adları (67), ay/yıl listeleri → açılışta çekilir.
  - vdOnKontrolSorgulama {vdkodu, islemGrubu, islemAdi, donemBaslangic, donemBitis}: rapor listesi (raporTarihi, islemSayisi, filePath).
    İşlem adı boş bırakılırsa seçili grubun (grup da boşsa tüm grupların) her işlem adı için sırayla sorgulanır.
    Tarih aralığı ay/yıl seçilirse YYYYAA01–YYYYAA31, boşsa 00000000–9999999.
  - dosyaIndirS3?filepath=…: Excel dosyası base64 gelir.
  İstekler TAKKOM PDF Okuyucu uzantısı v1.3 üzerinden (TAKKOM_MD_REQUEST) gider; uzantı yoksa doğrudan fetch denenir.
Rapor listesi: her satırda "İndir" (dosya tarayıcının İndirilenler klasörüne, KEYS'teki adıyla) ve "Yükle" (içerik tablosuna).
  "Tümünü İndir (Downloads)" ve "Tümünü Yükle" bütün listeyi sırayla işler (Durdur, bekleme süresi).
Rapor içeriği: Excel'in başlık satırı olduğu gibi sütun olur; VERGİ KİMLİK NUMARASI sütunundan VKN alınır.
  Personel VKN aralıkları (EVDB Rapor Alma ile aynı localStorage anahtarı, bölüm bazında) → "Sorumlu" sütunu; kişi bazlı özet
  (satır / tekil VKN; satıra tıklayınca süzer); rapor / sorumlu / arama süzgeçleri; Excel (süzülen) ve kişi bazlı sayfalı Excel.
Rapor türüne özel ekranlar (işleme göre kontrol/aksiyon) rapor rapor eklenecek.
